package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Дублирующий запрос при зависшем ответе: дубль по порогу, первый успешный ответ, отмена второй попытки, потолок
 * ожидания, ошибки попыток и занятый пул дублей.
 */
class GigaChatHedgeTest {

    private static final String TIMEOUT = "Страховочный timeout LLM-вызова: ответ не получен за 1 с";

    private final ExecutorService primary = Executors.newFixedThreadPool(4);
    private final List<String> notices = new ArrayList<>();

    @AfterEach
    void tearDown() {
        primary.shutdownNow();
    }

    /** Вызов, у которого попытки по очереди ведут себя по сценарию: первая — {@code first}, остальные — {@code next}. */
    private static Callable<String> attempts(AtomicInteger counter, Callable<String> first, Callable<String> next) {
        return () -> counter.incrementAndGet() == 1 ? first.call() : next.call();
    }

    /** Зависший ответ GigaChat: ждёт 10 с, пока попытку не отменят. */
    private static Callable<String> hang(AtomicBoolean interrupted) {
        return () -> {
            try {
                pause(10_000);
            } catch (InterruptedException e) {
                interrupted.set(true);
                Thread.currentThread().interrupt();
            }
            return "недостижимо";
        };
    }

    /** Ответ GigaChat через {@code millis} мс. */
    private static Callable<String> after(long millis, String answer) {
        return () -> {
            pause(millis);
            return answer;
        };
    }

    /** Ожидание, прерываемое отменой попытки. */
    private static void pause(long millis) throws InterruptedException {
        boolean released = new CountDownLatch(1).await(millis, TimeUnit.MILLISECONDS);
        assertFalse(released);
    }

    @Test
    void fastAnswerIsReturnedWithoutHedge() {
        var hedge = new GigaChatHedge(200, 2);
        var counter = new AtomicInteger();

        String result = hedge.call(attempts(counter, () -> "ответ", () -> "дубль"), primary, 1000, TIMEOUT, notices::add, null);

        assertEquals("ответ", result);
        assertEquals(1, counter.get());
        assertTrue(notices.isEmpty());
    }

    @Test
    void hungAttemptIsHedgedAndCancelled() {
        var hedge = new GigaChatHedge(100, 2);
        var counter = new AtomicInteger();
        var interrupted = new AtomicBoolean();
        long start = System.nanoTime();

        String result = hedge.call(attempts(counter, hang(interrupted), () -> "дубль"), primary, 5000, TIMEOUT, notices::add, null);

        assertEquals("дубль", result);
        assertEquals(2, counter.get());
        assertTrue(TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start) < 3000);
        assertEquals(1, notices.size());
        assertTrue(notices.get(0).contains("дублирующий запрос"), notices.get(0));
        assertInterrupted(interrupted);
    }

    @Test
    void bothHungAttemptsEndWithTimeoutText() {
        var hedge = new GigaChatHedge(100, 2);
        var counter = new AtomicInteger();
        var interrupted = new AtomicBoolean();

        GigaChatException e = assertThrows(GigaChatException.class, () -> hedge.call(
                attempts(counter, hang(interrupted), hang(new AtomicBoolean())), primary, 400, TIMEOUT, notices::add, null));

        assertEquals(TIMEOUT, e.getMessage());
        assertEquals(2, counter.get());
        assertTrue(GigaChatClient.isRequestTimeout(e.getMessage()));
        assertInterrupted(interrupted);
    }

    @Test
    void errorBeforeThresholdIsThrownWithoutHedge() {
        var hedge = new GigaChatHedge(500, 2);
        var counter = new AtomicInteger();
        Callable<String> failing = () -> {
            throw new IllegalStateException("422 context too long");
        };

        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> hedge.call(attempts(counter, failing, () -> "дубль"), primary, 2000, TIMEOUT, notices::add, null));

        assertEquals("422 context too long", e.getMessage());
        assertEquals(1, counter.get());
    }

    @Test
    void errorOfOneAttemptWaitsForTheOther() {
        var hedge = new GigaChatHedge(50, 2);
        var counter = new AtomicInteger();
        // первая попытка обрывается уже после отправки дубля
        Callable<String> failsLater = () -> {
            pause(200);
            throw new IllegalStateException("EOF reached while reading");
        };

        String result = hedge.call(attempts(counter, failsLater, after(400, "дубль")), primary, 3000, TIMEOUT, notices::add, null);

        assertEquals("дубль", result);
        assertEquals(2, counter.get());
    }

    @Test
    void errorsOfBothAttemptsThrowTheFirst() {
        var hedge = new GigaChatHedge(50, 2);
        var counter = new AtomicInteger();
        // первая ошибка приходит раньше второй
        Callable<String> first = () -> {
            pause(150);
            throw new IllegalStateException("первая");
        };
        Callable<String> second = () -> {
            pause(300);
            throw new IllegalStateException("вторая");
        };

        IllegalStateException e = assertThrows(IllegalStateException.class,
                () -> hedge.call(attempts(counter, first, second), primary, 3000, TIMEOUT, notices::add, null));

        assertEquals("первая", e.getMessage());
    }

    @Test
    void busyHedgePoolWaitsForFirstAttempt() throws Exception {
        var hedge = new GigaChatHedge(50, 1);
        var holdPool = new CountDownLatch(1);
        var other = Executors.newSingleThreadExecutor();
        try {
            // первый вызов занимает единственный поток пула дублей зависшим дублем
            var firstCounter = new AtomicInteger();
            Future<String> busy = other.submit(() -> hedge.call(attempts(firstCounter, hang(new AtomicBoolean()), () -> {
                holdPool.await();
                return "дубль первого";
            }), primary, 3000, TIMEOUT, null, null));
            waitUntil(() -> firstCounter.get() == 2);
            var counter = new AtomicInteger();

            String result = hedge.call(attempts(counter, after(300, "ответ"), () -> "дубль"), primary, 3000, TIMEOUT,
                    notices::add, null);

            assertEquals("ответ", result);
            assertEquals(1, counter.get());
            assertTrue(notices.isEmpty());
            holdPool.countDown();
            assertEquals("дубль первого", busy.get(5, TimeUnit.SECONDS));
        } finally {
            other.shutdownNow();
            hedge.shutdown();
        }
    }

    @Test
    void keyWithOneStreamGetsNoHedge() {
        var hedge = new GigaChatHedge(50, 2);
        var limiter = new GigaChatConcurrencyLimiter(1, true, 1000);
        var counter = new AtomicInteger();
        // первая попытка держит единственное разрешение ключа
        try (var original = limiter.acquire(null, null)) {
            String result = hedge.call(attempts(counter, after(300, "ответ"), () -> "дубль"), primary, 3000, TIMEOUT,
                    notices::add, limiter);

            assertEquals("ответ", result);
            assertEquals(1, counter.get());
            assertTrue(notices.isEmpty());
            assertEquals(1, limiter.inFlight());
        }
    }

    @Test
    void hedgePermitIsReturnedAfterCall() {
        var hedge = new GigaChatHedge(50, 2);
        var limiter = new GigaChatConcurrencyLimiter(2, true, 1000);
        var counter = new AtomicInteger();
        try (var original = limiter.acquire(null, null)) {
            String result = hedge.call(attempts(counter, hang(new AtomicBoolean()), () -> "дубль"), primary, 3000, TIMEOUT,
                    notices::add, limiter);

            assertEquals("дубль", result);
            assertEquals(2, counter.get());
            waitUntil(() -> limiter.inFlight() == 1);
            assertEquals(1, limiter.inFlight());
        }
    }

    @Test
    void disabledHedgeIsReportedAsDisabled() {
        assertFalse(GigaChatHedge.disabled().enabled());
        assertFalse(new GigaChatHedge(0, 2).enabled());
        assertFalse(new GigaChatHedge(100, 0).enabled());
        assertTrue(new GigaChatHedge(100, 1).enabled());
    }

    private static void assertInterrupted(AtomicBoolean interrupted) {
        waitUntil(interrupted::get);
        assertTrue(interrupted.get(), "зависшая попытка не отменена");
    }

    private static void waitUntil(BooleanSupplier condition) {
        long end = System.currentTimeMillis() + 5000;
        while (!condition.getAsBoolean() && System.currentTimeMillis() < end) {
            Thread.onSpinWait();
        }
    }
}
