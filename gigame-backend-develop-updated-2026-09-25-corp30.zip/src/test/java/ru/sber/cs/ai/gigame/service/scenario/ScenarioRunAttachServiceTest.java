package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputViews;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Повторная подписка на прогон по run_id: STATUS при подключении и смене статуса, по завершении —
 * FILE_OUTPUT готовых файловых узлов и итоговый STATUS; доступ только автору прогона.
 */
@ExtendWith(MockitoExtension.class)
class ScenarioRunAttachServiceTest {

    @Mock
    private ScenarioRunRepository scenarioRunRepository;
    @Mock
    private ScenarioRepository scenarioRepository;
    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;

    @InjectMocks
    private ScenarioRunAttachService service;

    private UUID runId;
    private Scenario scenario;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(service, "pollSeconds", 1);
        runId = UUID.randomUUID();
        scenario = new Scenario();
        scenario.setId(UUID.randomUUID());
        scenario.setUserId("ALICE");
        NodeDto excel = NodeDto.builder().id("out").type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Итог").mode("EXCEL").rules("{\"разметка_документов\": {}}").build()).build();
        NodeDto textWithoutStep = NodeDto.builder().id("txt").type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Текст").mode("TEXT_FILE").build()).build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(excel, textWithoutStep), List.of())));
        when(scenarioRepository.findById(scenario.getId())).thenReturn(Optional.of(scenario));
    }

    private ScenarioRun run(String status, String result) {
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenario.getId());
        run.setUserId("ALICE");
        run.setStatus(status);
        run.setResult(result);
        return run;
    }

    @Test
    void attach_reportsRunningThenFileOutputsAndFinalStatus() {
        AtomicInteger polls = new AtomicInteger();
        when(scenarioRunRepository.findById(runId)).thenAnswer(inv ->
                Optional.of(polls.getAndIncrement() < 2 ? run("running", null) : run("completed", "итог прогона")));
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(runId, "out"))
                .thenReturn(List.of(StepOutputViews.of("out", "output", Map.of("result", "[{\"а\":1}]"))));
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(runId, "txt")).thenReturn(List.of());

        List<ServerSentEvent<Map<String, Object>>> events = CurrentUserHolder.withUser("ALICE", () -> service.attach(runId))
                .collectList().block(Duration.ofSeconds(15));

        List<Map<String, Object>> data = events.stream().map(ServerSentEvent::data).toList();
        // RUNNING один раз (статус не менялся между опросами), затем FILE_OUTPUT готового узла и COMPLETED
        assertEquals(3, data.size(), data.toString());
        assertEquals("status", String.valueOf(data.get(0).get("type")));
        assertEquals(ScenarioStatus.RUNNING, data.get(0).get("status"));
        assertEquals(runId.toString(), data.get(0).get("run_id"));
        assertEquals("file_output", String.valueOf(data.get(1).get("type")));
        assertEquals("out", data.get(1).get("node_id"));
        assertEquals("result.zip", data.get(1).get("filename"));
        assertEquals(Boolean.TRUE, data.get(1).get("file_ready"));
        assertEquals("status", String.valueOf(data.get(2).get("type")));
        assertEquals(ScenarioStatus.COMPLETED, data.get(2).get("status"));
        assertEquals("итог прогона", data.get(2).get("result"));
    }

    @Test
    void attach_toFinishedRunEndsAfterFirstPoll() {
        when(scenarioRunRepository.findById(runId)).thenReturn(Optional.of(run("failed", "ошибка узла")));
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(any(), any())).thenReturn(List.of());

        List<ServerSentEvent<Map<String, Object>>> events = CurrentUserHolder.withUser("ALICE", () -> service.attach(runId))
                .collectList().block(Duration.ofSeconds(10));

        assertEquals(1, events.size());
        assertEquals(ScenarioStatus.FAILED, events.get(0).data().get("status"));
    }

    @Test
    void attach_isRefusedForForeignRunAndUnknownRun() {
        when(scenarioRunRepository.findById(runId)).thenReturn(Optional.of(run("running", null)));

        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("BOB", () -> service.attach(runId)));
        UUID unknown = UUID.randomUUID();
        when(scenarioRunRepository.findById(unknown)).thenReturn(Optional.empty());
        ScenarioException error = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser("ALICE", () -> service.attach(unknown)));
        assertTrue(error.getMessage().contains("не найден"), error.getMessage());
    }
}
