package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatModel;
import chat.giga.springai.GigaChatOptions;
import chat.giga.springai.api.chat.GigaChatApi;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.metadata.ChatGenerationMetadata;
import org.springframework.ai.chat.metadata.ChatResponseMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.exception.GigaFilterBlockedException;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.notNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * GigaChatClient под фильтром GigaFilter: откат настройками даёт прежние запросы, цензор выключается только после
 * чистого входа, блокировка входа не вызывает модель, блокировка выхода — ошибка без использования ответа, фильтр
 * недоступен — цензор включён (для ответа, полученного без цензора, — повтор с цензором), фрагмент документа узла и
 * результат инструмента агента заменяются пометкой.
 */
class GigaChatClientProfanityTest {

    private static final String TRIGGER = GigaFilterGuardTest.TRIGGER;
    private static final String ANSWER = "{\"предмет\": \"аудит пожарной безопасности\"}";

    private final ChatModel chatModel = Mockito.mock(ChatModel.class);
    private final List<Prompt> prompts = new CopyOnWriteArrayList<>();
    private final List<GigaFilterCheck.Request> filterRequests = new CopyOnWriteArrayList<>();
    private final List<String> notices = new CopyOnWriteArrayList<>();
    private Function<GigaFilterCheck.Request, GigaFilterCheck.Outcome> filter =
            request -> GigaFilterCheck.Outcome.verdict(request.messages().get(0).content().contains(TRIGGER));
    private GigaFilterGuard guard;
    private GigaChatClient client;

    @BeforeEach
    void setUp() {
        guard = new GigaFilterGuard(new GigaFilterTransport(() -> null) {
            @Override
            public GigaFilterCheck.Outcome check(GigaFilterCheck.Request request) {
                filterRequests.add(request);
                return filter.apply(request);
            }
        });
        ReflectionTestUtils.setField(guard, "chunkChars", 400);
        ReflectionTestUtils.setField(guard, "retryMaxDelayMillis", 1L);
        client = client(guard, null);
        GigaChatClient.setRunWaitNotice(notices::add);
    }

    @AfterEach
    void tearDown() {
        GigaChatClient.clearRunCancelCheck();
        GigaChatClient.clearRunWaitNotice();
    }

    @Test
    void rollbackSettingsKeepLegacyPromptsWithoutFilterCalls() {
        ReflectionTestUtils.setField(guard, "input", false);
        ReflectionTestUtils.setField(guard, "output", false);
        ReflectionTestUtils.setField(guard, "agent", true);
        List<Prompt> legacy = new CopyOnWriteArrayList<>();
        ChatModel legacyModel = Mockito.mock(ChatModel.class);
        when(legacyModel.call(any(Prompt.class))).thenAnswer(inv -> {
            legacy.add(inv.getArgument(0));
            return response("ok " + TRIGGER, "stop");
        });
        GigaChatClient legacyClient = new GigaChatClient(legacyModel, mock(EmbeddingModel.class));
        ReflectionTestUtils.setField(legacyClient, "callHardTimeoutSeconds", 0L);
        modelAnswers(prompt -> response("ok " + TRIGGER, "stop"));

        for (GigaChatClient each : List.of(legacyClient, client)) {
            each.chatCompletion(List.of(Map.of("role", "user", "content", "Привет " + TRIGGER)));
            each.chatCompletion(List.of(Map.of("role", "system", "content", "Ты — аналитик."),
                    Map.of("role", "user", "content", TRIGGER)), "GigaChat-2-Pro", 0.2);
            each.chatCompletionWithTools(List.of(Map.of("role", "user", "content", TRIGGER)), List.of(), null, 0.1);
            each.chatCompletionWithFile(TRIGGER, "скан.pdf", new byte[]{1}, "application/pdf", "GigaChat-2-Max", 0.01, 4000);
        }

        assertEquals(legacy.size(), prompts.size());
        for (int i = 0; i < legacy.size(); i++) {
            assertEquals(legacy.get(i).getInstructions().size(), prompts.get(i).getInstructions().size());
            assertEquals(legacy.get(i).getContents(), prompts.get(i).getContents());
            assertSameOptions(legacy.get(i), prompts.get(i));
        }
        assertNull(prompts.get(0).getOptions(), "запрос без модели и температуры — без опций, как раньше");
        assertTrue(filterRequests.isEmpty());
    }

    @Test
    void cleanInputAndOutputTurnCensorOff() {
        modelAnswers(prompt -> response(ANSWER, "stop"));

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", "Срок оказания услуг: 45 дней.")));

        assertEquals(ANSWER, text);
        assertEquals(Boolean.FALSE, options(prompts.get(0)).getProfanityCheck());
        assertEquals(2, filterRequests.size(), "вход и ответ");
        assertEquals(ANSWER, filterRequests.get(1).messages().get(0).content());
    }

    @Test
    void blockedInputDoesNotCallModel() {
        modelAnswers(prompt -> response(ANSWER, "stop"));
        List<Map<String, String>> prompt = List.of(Map.of("role", "user", "content", "Вопрос: " + TRIGGER));

        var e = assertThrows(GigaFilterBlockedException.class, () -> client.chatCompletion(
                prompt, "GigaChat-2-Max", 0.1));

        assertTrue(e.isInput());
        assertTrue(e.getMessage().startsWith("Текст отклонён фильтром GigaFilter на входе (сообщение запроса, знаки 1–28: «Вопрос: "),
                e.getMessage());
        verify(chatModel, never()).call(any(Prompt.class));
    }

    @Test
    void blockedOutputIsNotUsedAndUploadedFileIsDeleted() {
        GigaChatApi api = mock(GigaChatApi.class);
        GigaChatClient fileClient = client(guard, api);
        ChatResponse answer = new ChatResponse(List.of(new Generation(new AssistantMessage("Распознано: " + TRIGGER),
                ChatGenerationMetadata.builder().finishReason("stop").build())),
                ChatResponseMetadata.builder().keyValue(GigaChatModel.UPLOADED_MEDIA_IDS, List.of("file-7")).build());
        modelAnswers(prompt -> answer);
        List<Map<String, String>> chatPrompt = List.of(Map.of("role", "user", "content", "Расскажи о закупке"));

        var chat = assertThrows(GigaFilterBlockedException.class, () -> client.chatCompletion(chatPrompt));
        var ocr = assertThrows(GigaFilterBlockedException.class, () -> fileClient.chatCompletionWithFile("Выпиши содержимое",
                "скан.pdf", new byte[]{1}, "application/pdf", null, null, null));

        assertFalse(chat.isInput());
        assertEquals("Текст отклонён фильтром GigaFilter на выходе (ответ модели, знаки 1–32) — ответ модели не использован; "
                + "измените промпт или входные данные", chat.getMessage());
        assertFalse(ocr.isInput());
        verify(api).deleteFile("file-7");
        // файл во входе фильтром не проверяется — цензор остаётся включённым
        assertEquals(Boolean.TRUE, options(prompts.get(1)).getProfanityCheck());
    }

    @Test
    void outputCheckUnavailableAfterCensorOffRepeatsRequestWithCensorOn() {
        filter = request -> request.messages().get(0).content().startsWith("Ответ")
                ? GigaFilterCheck.Outcome.failed(503, "503 - Service Unavailable")
                : GigaFilterCheck.Outcome.verdict(false);
        modelAnswers(prompt -> response(Boolean.FALSE.equals(options(prompt).getProfanityCheck()) ? "Ответ 1" : "Ответ 2", "stop"));

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", "Вопрос")), "GigaChat-2-Max", 0.3);

        assertEquals("Ответ 2", text);
        assertEquals(2, prompts.size());
        assertEquals(Boolean.FALSE, options(prompts.get(0)).getProfanityCheck());
        assertEquals(Boolean.TRUE, options(prompts.get(1)).getProfanityCheck());
        assertEquals("GigaChat-2-Max", options(prompts.get(1)).getModel());
        assertEquals(0.3, options(prompts.get(1)).getTemperature());
    }

    @Test
    void unavailableFilterKeepsCensorOnWithoutRepeat() {
        filter = request -> GigaFilterCheck.Outcome.failed(404, "404 - {\"status\":404,\"message\":\"No such model\"}");
        modelAnswers(prompt -> response(ANSWER, "stop"));

        assertEquals(ANSWER, client.chatCompletion(List.of(Map.of("role", "user", "content", "Вопрос"))));
        assertEquals(ANSWER, client.chatCompletion(List.of(Map.of("role", "user", "content", "Ещё вопрос"))));

        assertEquals(2, prompts.size(), "без повторов");
        assertEquals(Boolean.TRUE, options(prompts.get(0)).getProfanityCheck());
        assertEquals(Boolean.TRUE, options(prompts.get(1)).getProfanityCheck());
        assertEquals(1, filterRequests.size(), "404 — автомат открыт, фильтр не вызывается");
    }

    @Test
    void blockedDocumentFragmentOfNodeIsDroppedAndMarked() {
        GigaChatClient.setRunCancelCheck(() -> false);
        modelAnswers(prompt -> response(ANSWER, "stop"));
        String context = "Документы:\n" + GigaFilterGuardTest.document("ТЗ часть 1.docx", 12)
                + "\n<<<Документ: ТЗ приложение 3.docx>>>\n" + (TRIGGER + " пункт 3.1.1.1\n").repeat(3)
                + "<<<КОНЕЦ ДОКУМЕНТА>>>\n\n" + GigaFilterGuardTest.document("Договор.docx", 12);

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content",
                GigaChatClient.splittableContent("Извлеки предмет закупки.", context, false))), null, null);

        String sent = prompts.get(0).getContents();
        assertFalse(sent.contains(TRIGGER), sent);
        assertTrue(sent.contains("[фрагмент документа «ТЗ приложение 3.docx» (знаки "), sent);
        assertEquals(Boolean.FALSE, options(prompts.get(0)).getProfanityCheck());
        assertTrue(text.startsWith("⚠ Фрагмент документа «ТЗ приложение 3.docx» (знаки "), text);
        assertTrue(text.endsWith("не передан модели: отклонён фильтром GigaFilter.\n\n" + ANSWER), text);
        assertEquals(1, notices.size());
        assertTrue(notices.get(0).startsWith("⚠ фрагмент документа «ТЗ приложение 3.docx»"), notices.get(0));
    }

    @Test
    void blockedToolResultIsReplacedByNoteAndAgentContinues() {
        ToolCallback tool = mock(ToolCallback.class);
        ToolDefinition definition = mock(ToolDefinition.class);
        when(definition.name()).thenReturn("read_document");
        when(tool.getToolDefinition()).thenReturn(definition);
        when(tool.call("{}")).thenReturn("{\"text\": \"" + TRIGGER + "\"}");
        var withCall = new ChatResponse(List.of(new Generation(AssistantMessage.builder().content("")
                .toolCalls(List.of(new AssistantMessage.ToolCall("id1", "function", "read_document", "{}"))).build())));
        modelAnswers(prompt -> prompts.size() == 1 ? withCall : response("Итог: пункт 3.1.1.1 не прочитан", "stop"));

        var result = client.chatCompletionWithTools(List.of(Map.of("role", "user", "content", "Проверь ТЗ")),
                List.of(tool), null, null);

        assertEquals("Итог: пункт 3.1.1.1 не прочитан", result.text());
        List<Message> history = prompts.get(1).getInstructions();
        ToolResponseMessage toolMessage = assertInstanceOf(ToolResponseMessage.class, history.get(history.size() - 1));
        assertEquals(GigaFilterGuard.TOOL_BLOCKED_NOTE, toolMessage.getResponses().get(0).responseData());
        assertEquals(Boolean.FALSE, options(prompts.get(1)).getProfanityCheck());
        assertEquals(List.of("⚠ результат инструмента «read_document» отклонён фильтром GigaFilter — агенту передана пометка"),
                notices);
    }

    @Test
    void blockedToolCallArgumentsFailBeforeToolRuns() {
        ToolCallback tool = mock(ToolCallback.class);
        ToolDefinition definition = mock(ToolDefinition.class);
        when(definition.name()).thenReturn("note_thought");
        when(tool.getToolDefinition()).thenReturn(definition);
        var withCall = new ChatResponse(List.of(new Generation(AssistantMessage.builder().content("")
                .toolCalls(List.of(new AssistantMessage.ToolCall("id1", "function", "note_thought",
                        "{\"thought\": \"" + TRIGGER + "\"}"))).build())));
        modelAnswers(prompt -> withCall);
        List<Map<String, String>> toolPrompt = List.of(Map.of("role", "user", "content", "Проверь ТЗ"));
        List<ToolCallback> tools = List.of(tool);

        var e = assertThrows(GigaFilterBlockedException.class, () -> client.chatCompletionWithTools(
                toolPrompt, tools, null, null));

        assertFalse(e.isInput());
        assertTrue(e.getMessage().contains("(аргументы инструмента «note_thought», знаки 1–35)"), e.getMessage());
        verify(tool, never()).call(anyString());
        assertEquals(1, prompts.size(), "следующий раунд с этими аргументами не отправлен");
        assertTrue(filterRequests.stream().anyMatch(r -> r.messages().get(0).content().contains(TRIGGER)));
    }

    @Test
    void blockedFragmentIsDroppedWhenDocumentIsSplitForContextLimit() {
        GigaChatClient.setRunCancelCheck(() -> false);
        modelAnswers(prompt -> {
            if (prompt.getContents().length() > 9000) {
                throw new RuntimeException("HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long\"}");
            }
            return response("[{\"ok\": 1}]", "stop");
        });

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", longNodeContent())), null, null);

        assertSplitWithoutBlockedFragment(text, "=== Ответ собран из 2 частей (запрос разделён из-за лимита контекста)");
    }

    @Test
    void blockedFragmentIsDroppedWhenDocumentIsSplitAfterCensorRefusal() {
        GigaChatClient.setRunCancelCheck(() -> false);
        modelAnswers(prompt -> prompt.getContents().length() > 9000
                ? response(GigaChatRefusalTest.INCIDENT_REFUSAL, "blacklist")
                : response("[{\"ok\": 1}]", "stop"));

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", longNodeContent())), null, null);

        assertSplitWithoutBlockedFragment(text, "=== Ответ собран из 2 частей (запрос разделён из-за ограничения темы GigaChat)");
    }

    @Test
    void filterPassTakesOnePermitWithoutQueueNotices() throws InterruptedException {
        GigaChatConcurrencyLimiter limiter = spy(new GigaChatConcurrencyLimiter(1, false, 50));
        client.setConcurrencyLimiter(limiter);
        GigaChatClient.setRunCancelCheck(() -> false);
        modelAnswers(prompt -> response(ANSWER, "stop"));
        CountDownLatch held = new CountDownLatch(1);
        Thread busy = new Thread(() -> limiter.call(() -> {
            held.countDown();
            pause(300);
            return null;
        }, null, null));
        busy.start();
        held.await();

        client.chatCompletion(List.of(Map.of("role", "user", "content", GigaFilterGuardTest.lines(120))), null, null);
        busy.join();

        assertTrue(filterRequests.size() >= 10, "фрагментов " + filterRequests.size());
        // проверка входа — одно разрешение на все фрагменты; запрос к модели и проверка ответа — по одному
        verify(limiter, times(2)).call(any(), notNull(), isNull());
        verify(limiter, times(1)).call(any(), notNull(), notNull());
        assertTrue(notices.isEmpty(), notices.toString());
    }

    @Test
    void rateLimitedOutputCheckIsRetriedWithoutRegeneration() {
        AtomicInteger outputChecks = new AtomicInteger();
        filter = request -> ANSWER.equals(request.messages().get(0).content()) && outputChecks.incrementAndGet() == 1
                ? GigaFilterCheck.Outcome.failed(429, "429 - {\"status\":429,\"message\":\"Too Many Requests\"}", 1L)
                : GigaFilterCheck.Outcome.verdict(false);
        modelAnswers(prompt -> response(ANSWER, "stop"));

        assertEquals(ANSWER, client.chatCompletion(List.of(Map.of("role", "user", "content", "Вопрос")), "GigaChat-2-Max", 0.1));

        verify(chatModel, times(1)).call(any(Prompt.class));
        assertEquals(2, outputChecks.get(), "проверка ответа повторена после 429");
        assertEquals(Boolean.FALSE, options(prompts.get(0)).getProfanityCheck());
    }

    @Test
    void globalDefaultCensorOffIsOverriddenWhenAgentKeepsCensor() {
        ReflectionTestUtils.setField(guard, "agent", true);
        when(chatModel.getDefaultOptions()).thenReturn(GigaChatOptions.builder().profanityCheck(false).build());
        modelAnswers(prompt -> response(ANSWER, "stop"));

        client.chatCompletion(List.of(Map.of("role", "user", "content", "Вопрос")));

        assertEquals(Boolean.TRUE, options(prompts.get(0)).getProfanityCheck());
    }

    @Test
    void profanityFlagCopyKeepsToolOptions() {
        GigaChatOptions tools = GigaChatOptions.builder().model("GigaChat-2-Max").temperature(0.2).build();
        tools.setToolCallbacks(List.of(mock(ToolCallback.class)));
        tools.setInternalToolExecutionEnabled(false);
        Prompt prompt = new Prompt(List.of(new AssistantMessage("история")), tools);

        Prompt flagged = GigaChatClient.withProfanityCheck(prompt, Boolean.FALSE);

        GigaChatOptions copy = options(flagged);
        assertEquals(Boolean.FALSE, copy.getProfanityCheck());
        assertEquals("GigaChat-2-Max", copy.getModel());
        assertEquals(0.2, copy.getTemperature());
        assertEquals(1, copy.getToolCallbacks().size());
        assertEquals(Boolean.FALSE, copy.getInternalToolExecutionEnabled());
        assertNull(tools.getProfanityCheck(), "исходные опции не меняются");
        assertSame(prompt, GigaChatClient.withProfanityCheck(prompt, null));
        assertEquals(Boolean.TRUE, options(GigaChatClient.withProfanityCheck(new Prompt("текст"), Boolean.TRUE)).getProfanityCheck());
    }

    // -------------------------------------------------------------------------
    // helpers
    // -------------------------------------------------------------------------

    private GigaChatClient client(GigaFilterGuard filterGuard, GigaChatApi api) {
        @SuppressWarnings("unchecked")
        ObjectProvider<GigaChatApi> provider = mock(ObjectProvider.class);
        when(provider.getIfAvailable()).thenReturn(api);
        GigaChatClient created = new GigaChatClient(chatModel, mock(EmbeddingModel.class), provider);
        ReflectionTestUtils.setField(created, "callHardTimeoutSeconds", 0L);
        ReflectionTestUtils.setField(created, "retryMaxAttempts", 1);
        created.setProfanityGuard(filterGuard);
        return created;
    }

    /** Промпт узла: ТЗ и договор по ~8,5 тыс. знаков, между ними приложение с фрагментом, отклоняемым фильтром. */
    private static String longNodeContent() {
        String context = "Документы:\n" + GigaFilterGuardTest.document("ТЗ часть 1.docx", 40)
                + "\n<<<Документ: ТЗ приложение 3.docx>>>\n" + (TRIGGER + " пункт 3.1.1.1\n").repeat(3)
                + "<<<КОНЕЦ ДОКУМЕНТА>>>\n\n" + GigaFilterGuardTest.document("Договор.docx", 40);
        return GigaChatClient.splittableContent("Извлеки предмет закупки.", context, true);
    }

    /** Ответ собран из частей очищенного контекста: пометка в начале, фрагмент не отправлен ни в одном запросе. */
    private void assertSplitWithoutBlockedFragment(String text, String header) {
        assertTrue(text.startsWith("⚠ Фрагмент документа «ТЗ приложение 3.docx» (знаки "), text);
        assertTrue(text.contains(header), text);
        assertEquals(3, prompts.size(), "полный запрос и две части");
        assertTrue(prompts.stream().noneMatch(p -> p.getContents().contains(TRIGGER)));
        assertTrue(prompts.get(2).getContents().contains("[фрагмент документа «ТЗ приложение 3.docx» (знаки "));
        assertEquals(Boolean.FALSE, options(prompts.get(2)).getProfanityCheck(), "часть прошла фильтр — цензор выключен");
        assertEquals(1, notices.stream().filter(n -> n.contains("отклонён фильтром GigaFilter")).count(), notices.toString());
    }

    private static void pause(long millis) {
        // NOSONAR java:S2925 — имитация сетевой задержки ответа фильтра (тест прерывания ожидания)
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void modelAnswers(Function<Prompt, ChatResponse> answer) {
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            Prompt prompt = inv.getArgument(0);
            prompts.add(prompt);
            return answer.apply(prompt);
        });
    }

    private static ChatResponse response(String text, String finishReason) {
        return GigaChatRefusalTest.response(text, finishReason);
    }

    private static GigaChatOptions options(Prompt prompt) {
        return assertInstanceOf(GigaChatOptions.class, prompt.getOptions());
    }

    private static void assertSameOptions(Prompt expected, Prompt actual) {
        if (expected.getOptions() == null) {
            assertNull(actual.getOptions());
            return;
        }
        GigaChatOptions left = options(expected);
        GigaChatOptions right = options(actual);
        assertNull(right.getProfanityCheck());
        assertEquals(left.getModel(), right.getModel());
        assertEquals(left.getTemperature(), right.getTemperature());
        assertEquals(left.getMaxTokens(), right.getMaxTokens());
        assertEquals(left.getInternalToolExecutionEnabled(), right.getInternalToolExecutionEnabled());
    }
}
