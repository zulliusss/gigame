package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Автомат доступности GigaFilter (серия сбоев открывает на паузу, 403/404 — сразу, пробный вызов после паузы,
 * 429 — пауза без счёта сбоев, предупреждения не чаще раза в минуту) и LRU-кэш вердиктов по хэшу фрагмента.
 */
class GigaFilterBreakerTest {

    private final AtomicLong clock = new AtomicLong(1_000_000L);

    @Test
    void seriesOfFailuresOpensBreakerForPauseThenProbeDecides() {
        GigaFilterBreaker breaker = new GigaFilterBreaker(3, 300_000L, clock::get);

        breaker.failure(null, "таймаут ответа фильтра 30000 мс");
        breaker.failure(503, "503 - Service Unavailable");
        assertTrue(breaker.allowsCall(), "два сбоя — автомат закрыт");
        breaker.failure(null, "таймаут ответа фильтра 30000 мс");
        assertFalse(breaker.allowsCall(), "три сбоя подряд — открыт");

        clock.addAndGet(299_999L);
        assertFalse(breaker.allowsCall());
        clock.addAndGet(1L);
        assertTrue(breaker.allowsCall(), "пауза истекла — пробный вызов");
        breaker.failure(500, "500 - Internal Server Error");
        assertFalse(breaker.allowsCall(), "пробный вызов не удался — снова открыт");

        clock.addAndGet(300_000L);
        breaker.success();
        assertTrue(breaker.allowsCall());
        breaker.failure(null, "сбой соединения");
        assertTrue(breaker.allowsCall(), "после успеха счёт сбоев с нуля");
    }

    @Test
    void notFoundOrForbiddenOpensAtOnce() {
        GigaFilterBreaker notFound = new GigaFilterBreaker(3, 60_000L, clock::get);
        notFound.failure(404, "404 - {\"status\":404,\"message\":\"No such model\"}");
        assertFalse(notFound.allowsCall());

        GigaFilterBreaker forbidden = new GigaFilterBreaker(3, 60_000L, clock::get);
        forbidden.failure(403, "403 - <html>403 Forbidden</html>");
        assertFalse(forbidden.allowsCall());

        GigaFilterBreaker unprocessable = new GigaFilterBreaker(3, 60_000L, clock::get);
        unprocessable.failure(422, "422 - invalid params");
        assertTrue(unprocessable.allowsCall(), "422 — обычный сбой, не сразу");
    }

    @Test
    void rateLimitPausesCallsWithoutCountingFailures() {
        GigaFilterBreaker breaker = new GigaFilterBreaker(1, 300_000L, clock::get);

        breaker.pause(2_000L, "429 - Too Many Requests");
        assertFalse(breaker.allowsCall(), "пауза по Retry-After");
        clock.addAndGet(2_000L);
        assertTrue(breaker.allowsCall(), "пауза истекла; 429 сбоем не считался (порог автомата — 1 сбой)");

        breaker.pause(0L, "429 без Retry-After");
        clock.addAndGet(GigaFilterBreaker.RATE_LIMIT_PAUSE_MILLIS - 1);
        assertFalse(breaker.allowsCall());
        clock.addAndGet(1L);
        assertTrue(breaker.allowsCall());
    }

    @Test
    void failureWarningsAreRateLimited() {
        GigaFilterBreaker breaker = new GigaFilterBreaker(100, 60_000L, clock::get);

        breaker.failure(null, "сбой 1");
        breaker.failure(null, "сбой 2");
        breaker.failure(null, "сбой 3");
        assertEquals(2, breaker.suppressedWarnings());

        clock.addAndGet(GigaFilterBreaker.WARN_INTERVAL_MILLIS);
        breaker.failure(null, "сбой 4");
        assertEquals(0, breaker.suppressedWarnings(), "интервал прошёл — предупреждение записано, счёт подавленных сброшен");
    }

    @Test
    void verdictCacheEvictsLeastRecentlyUsedAndSeparatesRoles() {
        GigaFilterCache cache = new GigaFilterCache(2);
        String first = GigaFilterCache.key("user", "фрагмент 1");
        String second = GigaFilterCache.key("user", "фрагмент 2");
        String third = GigaFilterCache.key("user", "фрагмент 3");

        cache.put(first, false);
        cache.put(second, true);
        assertEquals(Boolean.FALSE, cache.get(first));
        cache.put(third, false);

        assertNull(cache.get(second), "вытеснен давно не использованный");
        assertEquals(Boolean.FALSE, cache.get(first));
        assertEquals(Boolean.FALSE, cache.get(third));
        assertEquals(2, cache.size());
        assertEquals(64, first.length());
        assertEquals(first, GigaFilterCache.key("user", "фрагмент 1"));
        assertNotEquals(first, GigaFilterCache.key("assistant", "фрагмент 1"));
    }
}
