package ru.sber.cs.ai.gigame.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.content.Media;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.MimeTypeUtils;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.exception.GigaFilterBlockedException;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Проверка входа и выхода фильтром GigaFilter и решение о profanity_check: цензор выключается только после чистого
 * входа; фильтр недоступен или во входе файл — цензор включён; блокировка входа/выхода — понятная ошибка; фрагменты
 * контекста документов и результаты инструментов заменяются пометкой; кэш вердиктов, опции фильтра как у коллег,
 * ключи application.yaml; аргументы вызовов инструментов проверяются на входе и выходе; сбой фильтра на части
 * фрагментов не теряет известные блокировки; 422 не про safety опцию не отключает; 429/5xx повторяются; прерывание и
 * остановка прогона не открывают автомат.
 */
class GigaFilterGuardTest {

    /** Фрагмент, который фильтр в тестах блокирует. */
    static final String TRIGGER = "ЗАПРЕЩЁННЫЙ ФРАГМЕНТ";
    static final GigaFilterGuard.Limited DIRECT = Supplier::get;
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final List<GigaFilterCheck.Request> requests = new CopyOnWriteArrayList<>();
    private final List<String> notices = new CopyOnWriteArrayList<>();
    private Function<GigaFilterCheck.Request, GigaFilterCheck.Outcome> filter =
            request -> GigaFilterCheck.Outcome.verdict(request.messages().get(0).content().contains(TRIGGER));
    private GigaFilterGuard guard;

    @BeforeEach
    void setUp() {
        guard = guard(new GigaFilterTransport(() -> null) {
            @Override
            public GigaFilterCheck.Outcome check(GigaFilterCheck.Request request) {
                requests.add(request);
                return filter.apply(request);
            }
        });
    }

    @Test
    void cleanInputTurnsCensorOffAndVerdictsAreCached() {
        List<Message> messages = List.of(new SystemMessage("Ты — аналитик закупок."), new UserMessage(document("ТЗ.docx", 3)));

        assertEquals(Boolean.FALSE, guard.admit(messages, DIRECT));
        int calls = requests.size();
        assertEquals(Boolean.FALSE, guard.admit(messages, DIRECT));

        assertTrue(calls >= 3, "фрагментов " + calls);
        assertEquals(calls, requests.size(), "повторный вход — из кэша");
        assertTrue(requests.stream().allMatch(r -> "user".equals(r.messages().get(0).role()) && r.messages().size() == 1));
    }

    @Test
    void blockedInputThrowsWithFragmentAndDocument() {
        String text = "Проверь документы.\n\n<<<Документ: ТЗ приложение 3.docx>>>\n" + lines(6) + TRIGGER
                + " в пункте 3.1.1.1\n" + lines(30) + "<<<КОНЕЦ ДОКУМЕНТА>>>\n" + document("Проект договора.docx", 2);
        List<Message> input = List.of(new UserMessage(text));

        var e = assertThrows(GigaFilterBlockedException.class, () -> guard.admit(input, DIRECT));

        assertInstanceOf(GigaChatException.class, e);
        assertTrue(e.isInput());
        assertTrue(e.getMessage().startsWith("Текст отклонён фильтром GigaFilter на входе (сообщение запроса, фрагмент "),
                e.getMessage());
        assertTrue(e.getMessage().contains("документ «ТЗ приложение 3.docx»"), e.getMessage());
        assertTrue(e.getMessage().endsWith("— запрос к модели не отправлен; исключите или переформулируйте этот фрагмент"),
                e.getMessage());
    }

    @Test
    void unavailableFilterKeepsCensorOnAndBreakerStopsCalls() {
        filter = request -> GigaFilterCheck.Outcome.failed(404, "404 - {\"status\":404,\"message\":\"No such model\"}");
        List<Message> messages = List.of(new UserMessage("Срок оказания услуг: 45 дней."));

        assertEquals(Boolean.TRUE, guard.admit(messages, DIRECT));
        assertEquals(Boolean.TRUE, guard.admit(List.of(new UserMessage("Другой текст")), DIRECT));
        assertFalse(guard.checkOutput("Ответ модели", DIRECT));

        assertEquals(1, requests.size(), "404 — автомат открыт сразу, фильтр больше не вызывается");
    }

    @Test
    void filterUnavailableDuringContextScreeningIsNotCalledAgainByInputCheck() {
        filter = request -> GigaFilterCheck.Outcome.failed(null, "таймаут ответа фильтра 30000 мс");
        String content = GigaChatClient.splittableContent("Извлеки срок.", "Документы:\nСрок оказания услуг: 45 дней.", false);

        GigaFilterGuard.Screened screened = guard.screenContext(List.of(Map.of("role", "user", "content", content)),
                DIRECT, notices::add);
        Boolean flag = guard.admit(List.of(new UserMessage(GigaChatClient.stripSplitMarkers(content))), DIRECT);

        assertTrue(screened.notes().isEmpty());
        assertEquals(Boolean.TRUE, flag);
        assertEquals(1, requests.size(), "сбой при скрининге — проверка входа того же запроса фильтр не повторяет");
        assertEquals(Boolean.TRUE, guard.admit(List.of(new UserMessage("следующий запрос")), DIRECT));
        assertEquals(2, requests.size(), "следующий запрос проверяется заново (автомат ещё закрыт)");
    }

    @Test
    void blockedFragmentIsRemovedEvenWhenFilterFailsOnOtherFragments() {
        String appendix = "<<<Документ: ТЗ приложение 3.docx>>>\n" + (TRIGGER + " пункт 3.1.1.1\n").repeat(3)
                + "<<<КОНЕЦ ДОКУМЕНТА>>>\n";
        String failing = "<<<Документ: Договор.docx>>>\n" + lines(12) + "СБОЙ ФИЛЬТРА на строке договора\n" + lines(12)
                + "<<<КОНЕЦ ДОКУМЕНТА>>>\n";
        filter = request -> request.messages().get(0).content().contains("СБОЙ ФИЛЬТРА")
                ? GigaFilterCheck.Outcome.failed(null, "таймаут ответа фильтра 30000 мс")
                : GigaFilterCheck.Outcome.verdict(request.messages().get(0).content().contains(TRIGGER));
        // заблокированный документ до фрагмента со сбоем и после него (вердикт его фрагмента уже в кэше)
        String before = GigaChatClient.splittableContent("Извлеки предмет.", "Документы:\n" + appendix + "\n" + failing, false);
        String after = GigaChatClient.splittableContent("Извлеки срок.", "Документы:\n" + failing + "\n" + appendix, false);
        for (GigaFilterChunker.Chunk chunk : GigaFilterChunker.chunks(GigaChatClient.stripSplitMarkers(after), 400)) {
            if (chunk.text().contains(TRIGGER)) {
                List<Message> chunkMsg = List.of(new UserMessage(chunk.text()));
                assertThrows(GigaFilterBlockedException.class, () -> guard.admit(chunkMsg, DIRECT));
            }
        }

        for (String content : List.of(before, after)) {
            notices.clear();
            GigaFilterGuard.Screened screened = guard.screenContext(List.of(Map.of("role", "user", "content", content)),
                    DIRECT, notices::add);
            String sent = GigaChatClient.stripSplitMarkers(screened.messages().get(0).get("content"));
            int calls = requests.size();

            assertFalse(sent.contains(TRIGGER), sent);
            assertTrue(sent.contains("[фрагмент документа «ТЗ приложение 3.docx» (знаки "), sent);
            assertEquals(1, notices.size(), notices.toString());
            assertEquals(Boolean.TRUE, guard.admit(List.of(new UserMessage(sent)), DIRECT), "вердикт части фрагментов неизвестен");
            assertEquals(calls, requests.size(), "проверка входа того же запроса смотрит только кэш");
        }
    }

    @Test
    void knownBlockedVerdictBlocksInputWhenOtherFragmentsAreUnknown() {
        String appendix = "<<<Документ: Приложение 3.docx>>>\n" + (TRIGGER + " пункт 3.1.1.1\n").repeat(3) + "<<<КОНЕЦ ДОКУМЕНТА>>>\n";
        List<Message> appendixMsg = List.of(new UserMessage(appendix));
        assertThrows(GigaFilterBlockedException.class, () -> guard.admit(appendixMsg, DIRECT));
        filter = request -> GigaFilterCheck.Outcome.failed(null, "таймаут ответа фильтра 30000 мс");
        int calls = requests.size();
        List<Message> questionMsg = List.of(new UserMessage("Вопрос.\n" + lines(3) + appendix));
        List<Message> historyMsg = List.of(new SystemMessage("Ты — аналитик закупок."), new UserMessage(appendix));

        var message = assertThrows(GigaFilterBlockedException.class, () -> guard.admit(
                questionMsg, DIRECT));
        var history = assertThrows(GigaFilterBlockedException.class, () -> guard.admit(
                historyMsg, DIRECT));

        assertTrue(message.getMessage().contains("фрагмент 2 из 2"), message.getMessage());
        assertTrue(history.getMessage().contains("документ «Приложение 3.docx»"), history.getMessage());
        assertEquals(calls, requests.size(), "известная блокировка — без вызовов фильтра");
    }

    @Test
    void toolCallArgumentsAreCheckedInHistoryAndInAnswer() {
        AssistantMessage call = AssistantMessage.builder().content("").toolCalls(List.of(new AssistantMessage.ToolCall("id1",
                "function", "note_thought", "{\"thought\": \"" + TRIGGER + "\"}"))).build();
        List<Message> history = List.of(new UserMessage("Проверь ТЗ"), call, ToolResponseMessage.builder().responses(List.of(
                new ToolResponseMessage.ToolResponse("id1", "note_thought", "{\"ok\": true}"))).build());

        var input = assertThrows(GigaFilterBlockedException.class, () -> guard.admit(history, DIRECT));
        var output = assertThrows(GigaFilterBlockedException.class, () -> guard.checkAnswer(call, DIRECT));

        assertTrue(input.getMessage().contains("(аргументы инструмента «note_thought» в истории, знаки 1–35: «"), input.getMessage());
        assertEquals("Текст отклонён фильтром GigaFilter на выходе (аргументы инструмента «note_thought», знаки 1–35) — ответ "
                + "модели не использован; измените промпт или входные данные", output.getMessage());
        assertTrue(guard.checkAnswer(AssistantMessage.builder().content("").toolCalls(List.of(new AssistantMessage.ToolCall("id2",
                "function", "note_thought", "{\"thought\": \"сверить сроки\"}"))).build(), DIRECT));
        assertTrue(guard.checkAnswer(null, DIRECT));
    }

    @Test
    void unprocessableAnswerNotAboutSafetyKeepsOption() {
        filter = request -> request.messages().get(0).content().contains("ОГРОМНЫЙ")
                ? GigaFilterCheck.Outcome.failed(422, "NonTransientAiException: 422 - {\"status\":422,\"message\":\"Invalid params: "
                        + "messages too long\"}")
                : GigaFilterCheck.Outcome.verdict(false);

        assertEquals(Boolean.TRUE, guard.admit(List.of(new UserMessage("ОГРОМНЫЙ текст")), DIRECT));
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("обычный текст про закупку")), DIRECT));

        assertEquals(2, requests.size(), "без повтора без safety");
        assertEquals("safe", requests.get(1).settings().safety());
    }

    @Test
    void safetyIsDroppedOnlyAfterVerdictWithoutItAndCacheSeparatesOption() {
        filter = request -> GigaFilterCheck.Outcome.failed(422, "422 - {\"message\":\"unknown field safety\"}");
        assertEquals(Boolean.TRUE, guard.admit(List.of(new UserMessage("первый текст")), DIRECT));
        assertEquals(2, requests.size(), "повтор без safety тоже без вердикта");
        filter = request -> GigaFilterCheck.Outcome.verdict(false);
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("общий текст")), DIRECT));
        assertEquals("safe", requests.get(2).settings().safety(), "опция не отключена сбоем");

        filter = request -> request.settings().safety() != null
                ? GigaFilterCheck.Outcome.failed(422, "422 - {\"message\":\"unknown field safety\"}")
                : GigaFilterCheck.Outcome.verdict(false);
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("второй текст")), DIRECT));
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("общий текст")), DIRECT));

        assertEquals(6, requests.size());
        assertNull(requests.get(5).settings().safety(), "вердикт, полученный с safety, для запроса без неё не берётся из кэша");
    }

    @Test
    void rateLimitedAndServerErrorsAreRetriedThenFilterPausesWithoutBreakerFailures() {
        AtomicInteger calls = new AtomicInteger();
        filter = request -> calls.incrementAndGet() == 1
                ? GigaFilterCheck.Outcome.failed(503, "503 - Service Unavailable")
                : GigaFilterCheck.Outcome.verdict(false);
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("текст")), DIRECT));
        assertEquals(2, requests.size(), "5xx — повтор проверки фрагмента");

        filter = request -> GigaFilterCheck.Outcome.failed(429, "429 - Too Many Requests");
        assertEquals(Boolean.TRUE, guard.admit(List.of(new UserMessage("другой текст")), DIRECT));
        assertEquals(5, requests.size(), "вызов и два повтора");
        filter = request -> GigaFilterCheck.Outcome.verdict(false);
        assertEquals(Boolean.TRUE, guard.admit(List.of(new UserMessage("третий текст")), DIRECT));
        assertEquals(5, requests.size(), "после 429 фильтр на паузе — вызовов нет, цензор включён");
    }

    @Test
    void interruptionAndStopDoNotOpenBreakerAndStopBetweenFragments() {
        filter = request -> {
            throw new GigaChatException(GigaFilterTransport.INTERRUPTED, new InterruptedException());
        };
        for (String text : List.of("текст 1", "текст 2", "текст 3")) {
            List<Message> interruptMsg = List.of(new UserMessage(text));
            assertThrows(GigaChatException.class, () -> guard.admit(interruptMsg, DIRECT));
        }
        AtomicInteger calls = new AtomicInteger();
        AtomicBoolean stop = new AtomicBoolean();
        filter = request -> {
            stop.set(calls.incrementAndGet() == 2);
            return GigaFilterCheck.Outcome.verdict(false);
        };
        GigaFilterGuard.Limited stoppable = new GigaFilterGuard.Limited() {
            @Override
            public <T> T call(Supplier<T> call) {
                return call.get();
            }

            @Override
            public boolean cancelled() {
                return stop.get();
            }
        };

        List<Message> docMsg = List.of(new UserMessage(document("ТЗ.docx", 60)));
        var e = assertThrows(GigaChatException.class, () -> guard.admit(docMsg, stoppable));

        assertEquals(GigaChatClient.CANCELLED, e.getMessage());
        assertEquals(2, calls.get(), "остановка — между вызовами фильтра");
        stop.set(false);
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("чистый текст")), DIRECT), "автомат не открыт");
        assertEquals(3, calls.get());
    }

    @Test
    void fileAttachmentKeepsCensorOn() {
        Media scan = Media.builder().mimeType(MimeTypeUtils.parseMimeType("application/pdf")).data(new byte[]{1}).build();

        Boolean flag = guard.admit(List.of(UserMessage.builder().text("Выпиши содержимое").media(scan).build()), DIRECT);

        assertEquals(Boolean.TRUE, flag);
        assertEquals(1, requests.size(), "текст запроса проверен");
    }

    @Test
    void explicitSettingsWithoutInputCheckMakeNoCalls() {
        ReflectionTestUtils.setField(guard, "input", false);
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage(TRIGGER)), DIRECT));
        ReflectionTestUtils.setField(guard, "agent", true);
        assertNull(guard.admit(List.of(new UserMessage(TRIGGER)), DIRECT));
        ReflectionTestUtils.setField(guard, "input", true);
        assertNull(guard.admit(List.of(new UserMessage("чистый текст")), DIRECT), "agent=true — поле не ставится");

        assertEquals(1, requests.size());
    }

    @Test
    void rollbackSettingsAreInactive() {
        ReflectionTestUtils.setField(guard, "input", false);
        ReflectionTestUtils.setField(guard, "output", false);
        ReflectionTestUtils.setField(guard, "agent", true);

        assertFalse(guard.active());
        assertFalse(GigaFilterGuard.disabled().active());
        assertTrue(guard(null).active(), "умолчания: вход и выход проверяются, цензор выключается");
    }

    @Test
    void outputBlockedThrowsUnavailableReturnsFalse() {
        var e = assertThrows(GigaFilterBlockedException.class, () -> guard.checkOutput("Итог: " + TRIGGER, DIRECT));
        assertFalse(e.isInput());
        assertEquals("Текст отклонён фильтром GigaFilter на выходе (ответ модели, знаки 1–26) — ответ модели не "
                + "использован; измените промпт или входные данные", e.getMessage());
        assertTrue(guard.checkOutput("Итог: 100", DIRECT));
        assertTrue(guard.checkOutput("  ", DIRECT));
        assertTrue(guard.checkOutput(null, DIRECT));

        filter = request -> GigaFilterCheck.Outcome.failed(null, "таймаут ответа фильтра 30000 мс");
        assertFalse(guard.checkOutput("Другой ответ", DIRECT));
        ReflectionTestUtils.setField(guard, "output", false);
        int calls = requests.size();
        assertTrue(guard.checkOutput(TRIGGER, DIRECT));
        assertEquals(calls, requests.size());
    }

    @Test
    void outputRoleIsConfigurable() {
        ReflectionTestUtils.setField(guard, "outputRole", "assistant");

        guard.checkOutput("Итог: 100", DIRECT);

        assertEquals("assistant", requests.get(0).messages().get(0).role());
    }

    @Test
    void requestOptionsLikeColleaguesAndSafetyPlacement() throws IOException {
        assertEquals("{\"model\":\"GigaFilter\",\"messages\":[{\"role\":\"user\",\"content\":\"текст\"}],\"settings\":"
                + "{\"neuro\":true,\"blacklist\":true,\"whitelist\":true,\"unnormalized_history\":false,\"safety\":\"safe\"}}",
                MAPPER.writeValueAsString(guard.request("текст", "user", "settings")));
        assertEquals("{\"model\":\"GigaFilter\",\"messages\":[{\"role\":\"user\",\"content\":\"текст\"}],\"settings\":"
                + "{\"neuro\":true,\"blacklist\":true,\"whitelist\":true,\"unnormalized_history\":false},\"safety\":\"safe\"}",
                MAPPER.writeValueAsString(guard.request("текст", "user", " ROOT ")));
        assertNull(guard.request("текст", "user", "none").settings().safety());
        assertNull(guard.request("текст", "user", "none").safety());
    }

    @Test
    void unprocessableSafetyIsRetriedOnceWithoutItAndNotSentAgain() {
        filter = request -> request.settings().safety() != null
                ? GigaFilterCheck.Outcome.failed(422, "422 - {\"message\":\"unknown field safety\"}")
                : GigaFilterCheck.Outcome.verdict(false);

        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("первый текст")), DIRECT));
        assertEquals(Boolean.FALSE, guard.admit(List.of(new UserMessage("второй текст")), DIRECT));

        assertEquals(3, requests.size());
        assertEquals("safe", requests.get(0).settings().safety());
        assertNull(requests.get(1).settings().safety());
        assertNull(requests.get(2).settings().safety());
    }

    @Test
    void screenContextReplacesBlockedDocumentFragmentKeepingMarkers() {
        String context = "Документы:\n" + document("ТЗ часть 1.docx", 12) + "\n\n<<<Документ: ТЗ приложение 3.docx>>>\n"
                + (TRIGGER + " пункт чек-листа\n").repeat(3) + "<<<КОНЕЦ ДОКУМЕНТА>>>\n\n" + document("Договор.docx", 12);
        String content = GigaChatClient.splittableContent("Извлеки критерии.", context, true);

        GigaFilterGuard.Screened screened = guard.screenContext(List.of(Map.of("role", "user", "content", content)),
                DIRECT, notices::add);

        String sent = screened.messages().get(0).get("content");
        assertFalse(sent.contains(TRIGGER), sent);
        assertTrue(sent.startsWith("Извлеки критерии." + GigaChatClient.SPLIT_BOUNDARY), "граница сохранена");
        assertTrue(sent.endsWith(GigaChatClient.MERGE_ARRAYS_HINT), "подсказка слияния сохранена");
        assertTrue(sent.contains("[фрагмент документа «ТЗ приложение 3.docx» (знаки "), sent);
        assertTrue(sent.contains(" контекста) удалён: отклонён фильтром GigaFilter]"), sent);
        assertTrue(sent.contains("<<<Документ: Договор.docx>>>"), "остальные документы на месте");
        assertEquals(1, screened.notes().size());
        assertTrue(screened.notes().get(0).startsWith("⚠ Фрагмент документа «ТЗ приложение 3.docx» (знаки "));
        assertEquals(screened.notes().get(0) + "\n\n{}", screened.prefixed("{}"));
        assertTrue(screened.notes().get(0).endsWith("не передан модели: отклонён фильтром GigaFilter."), screened.notes().get(0));
        assertEquals(1, notices.size());
        assertTrue(notices.get(0).endsWith("отклонён фильтром GigaFilter — не передан модели"), notices.get(0));
    }

    @Test
    void screenContextFailsOnBlockedInstructionOrWholeContext() {
        String blockedInstruction = GigaChatClient.splittableContent("Инструкция: " + TRIGGER, document("ТЗ.docx", 12), false);
        String wholeContext = GigaChatClient.splittableContent("Извлеки критерии.", (TRIGGER + " строка\n").repeat(40), false);
        List<Map<String, String>> instructionMsg = List.of(Map.of("role", "user", "content", blockedInstruction));
        List<Map<String, String>> contextMsg = List.of(Map.of("role", "user", "content", wholeContext));

        var instruction = assertThrows(GigaFilterBlockedException.class, () -> guard.screenContext(
                instructionMsg, DIRECT, notices::add));
        var context = assertThrows(GigaFilterBlockedException.class, () -> guard.screenContext(
                contextMsg, DIRECT, notices::add));

        assertTrue(instruction.getMessage().contains("(инструкция узла, "), instruction.getMessage());
        assertTrue(context.getMessage().contains("(контекст документов целиком: отклонены все фрагменты"), context.getMessage());
    }

    @Test
    void strictModeLeavesContextAndBlocksWholeRequest() {
        ReflectionTestUtils.setField(guard, "skipBlockedFragments", false);
        String content = GigaChatClient.splittableContent("Извлеки критерии.", document("ТЗ.docx", 12) + "\n" + TRIGGER, false);
        List<Map<String, String>> messages = List.of(Map.of("role", "user", "content", content));

        GigaFilterGuard.Screened screened = guard.screenContext(messages, DIRECT, notices::add);

        assertSame(messages, screened.messages());
        assertTrue(requests.isEmpty());
        List<Message> strictMsg = List.of(new UserMessage(GigaChatClient.stripSplitMarkers(content)));
        assertThrows(GigaFilterBlockedException.class, () -> guard.admit(
                strictMsg, DIRECT));
    }

    @Test
    void screenToolResultsReplacesBlockedResult() {
        ToolResponseMessage results = ToolResponseMessage.builder().responses(List.of(
                new ToolResponseMessage.ToolResponse("1", "read_document", "{\"text\": \"" + TRIGGER + "\"}"),
                new ToolResponseMessage.ToolResponse("2", "kb_search", "{\"hits\": []}"))).build();

        ToolResponseMessage screened = guard.screenToolResults(results, DIRECT, notices::add);

        assertEquals(GigaFilterGuard.TOOL_BLOCKED_NOTE, screened.getResponses().get(0).responseData());
        assertEquals("{\"hits\": []}", screened.getResponses().get(1).responseData());
        assertEquals(List.of("⚠ результат инструмента «read_document» отклонён фильтром GigaFilter — агенту передана пометка"),
                notices);
        ToolResponseMessage clean = ToolResponseMessage.builder().responses(List.of(
                new ToolResponseMessage.ToolResponse("3", "kb_search", "{\"hits\": [1]}"))).build();
        assertSame(clean, guard.screenToolResults(clean, DIRECT, notices::add));
    }

    @Test
    void applicationYamlDeclaresProfanityKeysWithEnvAndDefaults() throws IOException {
        var environment = new StandardEnvironment();
        for (PropertySource<?> source : new YamlPropertySourceLoader().load("application",
                new ClassPathResource("application.yaml"))) {
            environment.getPropertySources().addLast(source);
        }
        Map<String, String> expected = Map.ofEntries(
                Map.entry("agent", "${GIGACHAT_PROFANITY_CHECK_AGENT:false}"),
                Map.entry("input", "${GIGACHAT_PROFANITY_CHECK_INPUT:true}"),
                Map.entry("output", "${GIGACHAT_PROFANITY_CHECK_OUTPUT:true}"),
                Map.entry("model", "${GIGACHAT_FILTER_MODEL:GigaFilter}"),
                Map.entry("path", "${GIGACHAT_FILTER_PATH:/filter/check}"),
                Map.entry("options.neuro", "${GIGACHAT_PROFANITY_CHECK_NEURO:true}"),
                Map.entry("options.blacklist", "${GIGACHAT_PROFANITY_CHECK_BLACKLIST:true}"),
                Map.entry("options.whitelist", "${GIGACHAT_PROFANITY_CHECK_WHITELIST:true}"),
                Map.entry("options.unnormalized-history", "${GIGACHAT_PROFANITY_CHECK_UNNORMALIZED_HISTORY:false}"),
                Map.entry("options.safety", "${GIGACHAT_PROFANITY_CHECK_SAFETY:safe}"),
                Map.entry("safety-placement", "${GIGACHAT_PROFANITY_CHECK_SAFETY_PLACEMENT:settings}"),
                Map.entry("output-role", "${GIGACHAT_PROFANITY_CHECK_OUTPUT_ROLE:user}"),
                Map.entry("chunk-chars", "${GIGACHAT_PROFANITY_CHECK_CHUNK_CHARS:4000}"),
                Map.entry("cache-size", "${GIGACHAT_PROFANITY_CHECK_CACHE_SIZE:20000}"),
                Map.entry("timeout-millis", "${GIGACHAT_PROFANITY_CHECK_TIMEOUT_MILLIS:30000}"),
                Map.entry("breaker-failures", "${GIGACHAT_PROFANITY_CHECK_BREAKER_FAILURES:3}"),
                Map.entry("breaker-open-seconds", "${GIGACHAT_PROFANITY_CHECK_BREAKER_OPEN_SECONDS:300}"),
                Map.entry("skip-blocked-fragments", "${GIGACHAT_PROFANITY_CHECK_SKIP_BLOCKED:true}"),
                Map.entry("retry-attempts", "${GIGACHAT_PROFANITY_CHECK_RETRY_ATTEMPTS:2}"),
                Map.entry("retry-max-delay-millis", "${GIGACHAT_PROFANITY_CHECK_RETRY_MAX_DELAY_MILLIS:3000}"));
        for (var entry : expected.entrySet()) {
            String key = "app.gigachat.profanity-check." + entry.getKey();
            assertEquals(entry.getValue(), String.valueOf(rawValue(environment, key)), key);
        }
        assertEquals("${GIGACHAT_REFUSAL_SPLIT_MAX_CALLS:16}", String.valueOf(rawValue(environment, "app.gigachat.refusal-split-max-calls")));
        assertEquals("false", environment.getProperty("app.gigachat.profanity-check.agent"));
    }

    @Test
    void verdictCacheDefaultCapacityCoversTypicalDocumentSet() {
        // corp23 cache-7: 280 договоров по ~200 тыс. знаков — ~14 000 фрагментов на узел; при 5000 LRU
        // вытеснял каждый ключ до повторного обращения, и следующие узлы прогона фильтр вызывали заново
        GigaFilterGuard fresh = new GigaFilterGuard(null);

        assertEquals(20000, ReflectionTestUtils.getField(fresh, "cacheSize"));
    }

    private static Object rawValue(StandardEnvironment environment, String key) {
        for (PropertySource<?> source : environment.getPropertySources()) {
            if (source.containsProperty(key)) {
                return source.getProperty(key);
            }
        }
        return null;
    }

    private static GigaFilterGuard guard(GigaFilterTransport transport) {
        GigaFilterGuard guard = new GigaFilterGuard(transport);
        ReflectionTestUtils.setField(guard, "chunkChars", 400);
        ReflectionTestUtils.setField(guard, "retryMaxDelayMillis", 1L);
        return guard;
    }

    /** Документ из пунктов ТЗ под маркером имени (строк × 3). */
    static String document(String name, int lines) {
        return "<<<Документ: " + name + ">>>\n" + lines(lines * 3) + "<<<КОНЕЦ ДОКУМЕНТА>>>\n";
    }

    /** Пункты ТЗ разной длины. */
    static String lines(int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= count; i++) {
            sb.append("п.").append(i).append(" Исполнитель обязан обеспечить выполнение работ по объекту № ").append(i * 7)
                    .append(".\n");
        }
        return sb.toString();
    }
}
