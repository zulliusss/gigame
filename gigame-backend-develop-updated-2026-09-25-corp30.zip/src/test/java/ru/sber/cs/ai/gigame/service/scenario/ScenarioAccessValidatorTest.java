package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Проверка доступа запускающего к базам знаний и под-сценариям графа до создания прогона.
 */
class ScenarioAccessValidatorTest {

    private static final String RUNNER = "RUNNER";
    private static final String OTHER = "OTHER";

    private static NodeDto kbNode(String id, String kbId) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Обработка").knowledgeBaseId(kbId).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static NodeDto subScenario(String id, String value) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Под-сценарий").value(value).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static GraphDataDto graph(NodeDto... nodes) {
        return new GraphDataDto(List.of(nodes), List.of());
    }

    private static Scenario scenario(UUID id, String name, String owner, boolean shared, NodeDto... nodes) {
        Scenario scenario = new Scenario();
        scenario.setId(id);
        scenario.setName(name);
        scenario.setUserId(owner);
        scenario.setShared(shared);
        scenario.setGraphData(GraphDataMapper.fromDto(graph(nodes)));
        return scenario;
    }

    private static KnowledgeBase kb(UUID id, String name, String owner, boolean shared) {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(id);
        kb.setName(name);
        kb.setUserId(owner);
        kb.setShared(shared);
        return kb;
    }

    /** Поиск сценария по id в памяти с журналом обращений. */
    private static Function<UUID, Optional<Scenario>> scenarios(List<UUID> calls, Scenario... scenarios) {
        Map<UUID, Scenario> byId = new HashMap<>();
        for (Scenario scenario : scenarios) {
            byId.put(scenario.getId(), scenario);
        }
        return id -> {
            calls.add(id);
            return Optional.ofNullable(byId.get(id));
        };
    }

    /** Поиск базы знаний по id в памяти с журналом обращений. */
    private static Function<UUID, Optional<KnowledgeBase>> bases(List<UUID> calls, KnowledgeBase... bases) {
        Map<UUID, KnowledgeBase> byId = new HashMap<>();
        for (KnowledgeBase kb : bases) {
            byId.put(kb.getId(), kb);
        }
        return id -> {
            calls.add(id);
            return Optional.ofNullable(byId.get(id));
        };
    }

    private static ScenarioException validateFails(GraphDataDto root, String runner,
                                                   Function<UUID, Optional<Scenario>> scenarios,
                                                   Function<UUID, Optional<KnowledgeBase>> bases) {
        UUID scenarioId = UUID.randomUUID();
        return assertThrows(ScenarioException.class,
                () -> ScenarioAccessValidator.validate(root, scenarioId, runner, scenarios, bases));
    }

    @Test
    void foreignPrivateKnowledgeBaseRejectsLaunch() {
        UUID kbId = UUID.randomUUID();
        GraphDataDto root = graph(kbNode("p1", kbId.toString()));

        ScenarioException ex = validateFails(root, RUNNER, scenarios(new ArrayList<>()),
                bases(new ArrayList<>(), kb(kbId, "Нормативка", OTHER, false)));

        assertEquals("База знаний «Нормативка» (" + kbId + ") недоступна пользователю", ex.getMessage());
    }

    @Test
    void ownAndSharedKnowledgeBasesPass() {
        UUID own = UUID.randomUUID();
        UUID shared = UUID.randomUUID();
        GraphDataDto root = graph(kbNode("p1", own.toString()), kbNode("p2", shared.toString()));
        Function<UUID, Optional<KnowledgeBase>> bases = bases(new ArrayList<>(),
                kb(own, "Своя", RUNNER, false), kb(shared, "Общая", OTHER, true));

        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(root, UUID.randomUUID(), RUNNER,
                scenarios(new ArrayList<>()), bases));
    }

    @Test
    void anonymousRunnerIsNormalizedLikeElsewhere() {
        UUID kbId = UUID.randomUUID();
        GraphDataDto root = graph(kbNode("p1", kbId.toString()));
        Function<UUID, Optional<Scenario>> scenarios = scenarios(new ArrayList<>());

        // пустой пользователь — «anonymous»: его собственная база доступна, чужая — нет
        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(root, null, null, scenarios,
                bases(new ArrayList<>(), kb(kbId, "Анонимная", "anonymous", false))));
        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(root, null, "", scenarios,
                bases(new ArrayList<>(), kb(kbId, "Анонимная", "anonymous", false))));
        ScenarioException ex = validateFails(root, null, scenarios,
                bases(new ArrayList<>(), kb(kbId, "Чужая", OTHER, false)));
        assertEquals("База знаний «Чужая» (" + kbId + ") недоступна пользователю", ex.getMessage());
    }

    @Test
    void missingOrInvalidKnowledgeBaseIsLeftToEngine() {
        UUID missing = UUID.randomUUID();
        List<UUID> calls = new ArrayList<>();
        GraphDataDto root = graph(
                kbNode("p1", missing.toString()),
                kbNode("p2", "не-uuid"),
                kbNode("p3", " "),
                kbNode("p4", null),
                NodeDto.builder().id("p5").type(ScenarioNodeType.PROCESSING_NODE.toString()).build());

        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(root, UUID.randomUUID(), RUNNER,
                scenarios(new ArrayList<>()), bases(calls)));
        assertEquals(List.of(missing), calls);
        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(null, null, RUNNER,
                scenarios(new ArrayList<>()), bases(calls)));
        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(new GraphDataDto(null, null), null, RUNNER,
                scenarios(new ArrayList<>()), bases(calls)));
    }

    @Test
    void eachKnowledgeBaseCheckedOnce() {
        UUID kbId = UUID.randomUUID();
        List<UUID> calls = new ArrayList<>();
        GraphDataDto root = graph(kbNode("p1", kbId.toString()), kbNode("p2", " " + kbId + " "));

        ScenarioException ex = validateFails(root, RUNNER, scenarios(new ArrayList<>()),
                bases(calls, kb(kbId, "", OTHER, false)));

        // база без имени называется по id; повторная ссылка не загружается и не дублирует проблему
        assertEquals("База знаний «" + kbId + "» (" + kbId + ") недоступна пользователю", ex.getMessage());
        assertEquals(List.of(kbId), calls);
    }

    @Test
    void foreignPrivateSubScenarioRejectedAndNotDescended() {
        UUID subId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        List<UUID> kbCalls = new ArrayList<>();
        GraphDataDto root = graph(subScenario("s1", subId.toString()));
        Function<UUID, Optional<Scenario>> scenarios = scenarios(new ArrayList<>(),
                scenario(subId, "Чужой", OTHER, false, kbNode("p1", kbId.toString())));

        ScenarioException ex = validateFails(root, RUNNER, scenarios, bases(kbCalls, kb(kbId, "Б", OTHER, false)));

        assertEquals("Под-сценарий «Чужой» недоступен пользователю", ex.getMessage());
        assertTrue(kbCalls.isEmpty());
    }

    @Test
    void ownAndSharedSubScenariosPass() {
        UUID own = UUID.randomUUID();
        UUID shared = UUID.randomUUID();
        GraphDataDto root = graph(subScenario("s1", own.toString()), subScenario("s2", shared.toString()));
        Function<UUID, Optional<Scenario>> scenarios = scenarios(new ArrayList<>(),
                scenario(own, "Свой", RUNNER, false), scenario(shared, "Общий", OTHER, true));

        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(root, UUID.randomUUID(), RUNNER, scenarios,
                bases(new ArrayList<>())));
    }

    @Test
    void knowledgeBasesOfAccessibleSubScenarioCheckedWithLocation() {
        UUID subId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        GraphDataDto root = graph(subScenario("s1", subId.toString()));
        Function<UUID, Optional<Scenario>> scenarios = scenarios(new ArrayList<>(),
                scenario(subId, "Первый", OTHER, true, kbNode("p1", kbId.toString())));

        ScenarioException ex = validateFails(root, RUNNER, scenarios,
                bases(new ArrayList<>(), kb(kbId, "Нормативка", OTHER, false)));

        assertEquals("База знаний «Нормативка» (" + kbId + ") недоступна пользователю (под-сценарий «Первый»)",
                ex.getMessage());
    }

    @Test
    void subScenariosAreCheckedToEngineDepth() {
        UUID level1 = UUID.randomUUID();
        UUID level2 = UUID.randomUUID();
        UUID level3 = UUID.randomUUID();
        List<UUID> calls = new ArrayList<>();
        Function<UUID, Optional<Scenario>> scenarios = scenarios(calls,
                scenario(level1, "Первый", OTHER, true, subScenario("s", level2.toString())),
                scenario(level2, "", OTHER, false, subScenario("s", level3.toString())),
                scenario(level3, "Третий", OTHER, false));
        GraphDataDto root = graph(subScenario("s1", level1.toString()));

        ScenarioException ex = validateFails(root, RUNNER, scenarios, bases(new ArrayList<>()));

        // второй уровень недоступен и называется по id; третий уровень движок не выполняет — он и не загружается
        assertEquals("Под-сценарий «" + level2 + "» недоступен пользователю (под-сценарий «Первый»)", ex.getMessage());
        assertEquals(List.of(level1, level2), calls);
        assertEquals(2, ScenarioEngine.MAX_SUB_DEPTH);
    }

    @Test
    void subScenarioCyclesRepeatsAndMissingAreHandled() {
        UUID rootId = UUID.randomUUID();
        UUID subId = UUID.randomUUID();
        UUID missing = UUID.randomUUID();
        List<UUID> calls = new ArrayList<>();
        Function<UUID, Optional<Scenario>> scenarios = scenarios(calls,
                scenario(subId, "Цикл", RUNNER, false, subScenario("self", subId.toString()),
                        subScenario("back", rootId.toString()), subScenario("gone", missing.toString())));
        GraphDataDto root = graph(subScenario("s1", subId.toString()), subScenario("s2", " " + subId + " "),
                subScenario("s3", "не-uuid"), subScenario("s4", null));

        assertDoesNotThrow(() -> ScenarioAccessValidator.validate(root, rootId, RUNNER, scenarios,
                bases(new ArrayList<>())));
        assertEquals(List.of(subId, missing), calls);
    }

    @Test
    void allProblemsReportedTogether() {
        UUID kbId = UUID.randomUUID();
        UUID subId = UUID.randomUUID();
        GraphDataDto root = graph(kbNode("p1", kbId.toString()), subScenario("s1", subId.toString()));

        ScenarioException ex = validateFails(root, RUNNER,
                scenarios(new ArrayList<>(), scenario(subId, "Чужой", OTHER, false)),
                bases(new ArrayList<>(), kb(kbId, "Чужая", OTHER, false)));

        assertEquals("База знаний «Чужая» (" + kbId + ") недоступна пользователю; "
                + "Под-сценарий «Чужой» недоступен пользователю", ex.getMessage());
    }

    @Test
    void canAccessRules() {
        assertTrue(ScenarioAccessValidator.canAccess(scenario(UUID.randomUUID(), "", RUNNER, false), RUNNER));
        assertTrue(ScenarioAccessValidator.canAccess(scenario(UUID.randomUUID(), "", OTHER, true), RUNNER));
        assertFalse(ScenarioAccessValidator.canAccess(scenario(UUID.randomUUID(), "", OTHER, false), RUNNER));
        assertFalse(ScenarioAccessValidator.canAccess(scenario(UUID.randomUUID(), "", null, false), RUNNER));
        assertTrue(ScenarioAccessValidator.canAccess(kb(UUID.randomUUID(), "", RUNNER, false), RUNNER));
        assertTrue(ScenarioAccessValidator.canAccess(kb(UUID.randomUUID(), "", OTHER, true), RUNNER));
        assertFalse(ScenarioAccessValidator.canAccess(kb(UUID.randomUUID(), "", OTHER, false), RUNNER));
    }
}
