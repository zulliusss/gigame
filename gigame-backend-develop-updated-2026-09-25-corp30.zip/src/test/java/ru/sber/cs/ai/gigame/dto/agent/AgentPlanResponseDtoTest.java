package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.config.JacksonConfig;
import ru.sber.cs.ai.gigame.model.AgentPlan;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты DTO плана агента: ключи snake_case строго по схеме AgentPlan
 * (additionalProperties: false), лимиты строк и формат дат.
 */
class AgentPlanResponseDtoTest {

    private final ObjectMapper mapper = new JacksonConfig().objectMapper();

    private static AgentPlan plan() {
        AgentPlan plan = new AgentPlan();
        plan.setId(UUID.randomUUID());
        plan.setScenarioId(UUID.randomUUID());
        plan.setTaskHash("0123456789abcdef".repeat(4));
        plan.setTaskPreview("Найди сумму акта");
        plan.setPlan("[\"пункт 1\",\"пункт 2\"]");
        plan.setUses(2);
        plan.setCreatedAt(OffsetDateTime.of(2026, 9, 15, 13, 5, 26, 884_512_243, ZoneOffset.ofHours(3)));
        plan.setUpdatedAt(OffsetDateTime.of(2026, 9, 15, 13, 6, 0, 1, ZoneOffset.ofHours(3)));
        return plan;
    }

    @Test
    void serialization_usesSnakeCaseSchemaKeys() throws Exception {
        AgentPlan entity = plan();

        JsonNode json = mapper.readTree(mapper.writeValueAsString(AgentPlanResponseDto.from(entity)));

        Set<String> keys = new HashSet<>();
        json.fieldNames().forEachRemaining(keys::add);
        assertEquals(Set.of("id", "scenario_id", "task_hash", "task_preview", "plan", "uses",
                "created_at", "updated_at"), keys);
        assertEquals(entity.getScenarioId().toString(), json.get("scenario_id").asText());
        assertEquals("0123456789abcdef".repeat(4), json.get("task_hash").asText());
        assertEquals("[\"пункт 1\",\"пункт 2\"]", json.get("plan").asText());
        assertEquals(2, json.get("uses").asInt());
    }

    @Test
    void serialization_datesAreUtcAndFitMaxLength() throws Exception {
        JsonNode json = mapper.readTree(mapper.writeValueAsString(AgentPlanResponseDto.from(plan())));

        assertEquals("2026-09-15T10:05:26.884512Z", json.get("created_at").asText());
        assertEquals("2026-09-15T10:06:00Z", json.get("updated_at").asText());
        assertTrue(json.get("created_at").asText().length() <= 32);
    }

    @Test
    void from_clipsTaskPreviewAndClampsUses() {
        AgentPlan entity = plan();
        entity.setTaskPreview("з".repeat(1500));
        entity.setUses(2_000_000);

        AgentPlanResponseDto dto = AgentPlanResponseDto.from(entity);

        assertEquals(AgentPlanResponseDto.TASK_PREVIEW_MAX_LENGTH, dto.taskPreview().length());
        assertEquals(AgentPlanResponseDto.USES_MAX, dto.uses());
    }

    @Test
    void from_oversizedJsonPlan_dropsTrailingItemsAndStaysValidJson() throws Exception {
        // план из 12 пунктов по ~400 символов: пункты отбрасываются с конца, последним — маркер
        List<String> items = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            items.add("пункт " + i + " " + "п".repeat(400));
        }
        AgentPlan entity = plan();
        entity.setPlan(mapper.writeValueAsString(items));

        String limited = AgentPlanResponseDto.from(entity).plan();

        assertTrue(limited.length() <= AgentPlanResponseDto.PLAN_MAX_LENGTH);
        JsonNode json = mapper.readTree(limited);
        assertTrue(json.isArray());
        int kept = json.size() - 1;
        assertTrue(kept > 0 && kept < 12, "kept=" + kept);
        for (int i = 0; i < kept; i++) {
            assertEquals(items.get(i), json.get(i).asText());
        }
        assertEquals("…ещё " + (12 - kept) + " пункт(ов) не показано — план в памяти хранится полностью",
                json.get(kept).asText());
    }

    @Test
    void from_oversizedJsonPlan_keepsAsManyItemsAsFitWithMarker() throws Exception {
        // ещё один пункт уже не помещается вместе с маркером
        List<String> items = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            items.add("пункт " + i + " " + "п".repeat(400));
        }
        AgentPlan entity = plan();
        entity.setPlan(mapper.writeValueAsString(items));

        JsonNode json = mapper.readTree(AgentPlanResponseDto.from(entity).plan());

        int kept = json.size() - 1;
        List<String> oneMore = new ArrayList<>(items.subList(0, kept + 1));
        oneMore.add("…ещё " + (11 - kept) + " пункт(ов) не показано — план в памяти хранится полностью");
        assertTrue(mapper.writeValueAsString(oneMore).length() > AgentPlanResponseDto.PLAN_MAX_LENGTH);
    }

    @Test
    void from_singleItemOverLimit_clippedToNonEmptyValidArray() throws Exception {
        AgentPlan entity = plan();
        entity.setPlan(mapper.writeValueAsString(List.of("п".repeat(4100))));

        String limited = AgentPlanResponseDto.from(entity).plan();

        assertTrue(limited.length() <= AgentPlanResponseDto.PLAN_MAX_LENGTH, "length=" + limited.length());
        JsonNode json = mapper.readTree(limited);
        assertTrue(json.isArray());
        assertEquals(1, json.size());
        assertTrue(json.get(0).asText().startsWith("ппп"));
        assertTrue(json.get(0).asText().endsWith("…"));
    }

    @Test
    void from_firstItemOverLimitWithEscapesAndMoreItems_clippedWithMarker() throws Exception {
        // кавычки и переводы строк удлиняют сериализацию — всё равно не больше лимита
        AgentPlan entity = plan();
        entity.setPlan(mapper.writeValueAsString(List.of("\"\n".repeat(3000), "второй пункт")));

        String limited = AgentPlanResponseDto.from(entity).plan();

        assertTrue(limited.length() <= AgentPlanResponseDto.PLAN_MAX_LENGTH, "length=" + limited.length());
        JsonNode json = mapper.readTree(limited);
        assertEquals(2, json.size());
        assertTrue(json.get(0).asText().endsWith("…"));
        assertEquals("…ещё 1 пункт(ов) не показано — план в памяти хранится полностью", json.get(1).asText());
    }

    @Test
    void from_oversizedNonJsonPlan_clippedWithEllipsis() {
        AgentPlan entity = plan();
        entity.setPlan("не JSON: " + "п".repeat(5000));

        String limited = AgentPlanResponseDto.from(entity).plan();

        assertEquals(AgentPlanResponseDto.PLAN_MAX_LENGTH, limited.length());
        assertTrue(limited.endsWith("…"));
    }

    @Test
    void from_planWithinLimitPassesUnchanged() {
        AgentPlan entity = plan();

        assertEquals("[\"пункт 1\",\"пункт 2\"]", AgentPlanResponseDto.from(entity).plan());
    }

    @Test
    void serialization_omitsNullScenarioAndDates() throws Exception {
        AgentPlan entity = plan();
        entity.setScenarioId(null);
        entity.setCreatedAt(null);
        entity.setUpdatedAt(null);

        JsonNode json = mapper.readTree(mapper.writeValueAsString(AgentPlanResponseDto.from(entity)));

        assertNull(json.get("scenario_id"));
        assertNull(json.get("created_at"));
        assertNull(json.get("updated_at"));
    }
}
