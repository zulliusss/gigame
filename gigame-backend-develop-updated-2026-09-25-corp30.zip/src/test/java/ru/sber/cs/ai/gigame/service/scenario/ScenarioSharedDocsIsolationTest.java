package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import ru.sber.cs.ai.gigame.dto.scenario.UploadStatusResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

/**
 * Изоляция документов общего сценария по пользователю: два пользователя загружают
 * в один сценарий разные документы (фоновая загрузка), и прогон каждого видит
 * только свои. Кэш документов, реестр загрузок и движок — настоящие; разбор
 * файлов, БД и исполнители узлов — заглушки.
 */
class ScenarioSharedDocsIsolationTest {

    private static final String USER_A = "USER1";

    private static final String USER_B = "USER2";

    private final UUID sharedScenarioId = UUID.randomUUID();

    private DocsTextCacheService cache;

    private ScenarioService scenarioServiceMock;

    private ScenarioUploadTaskService uploads;

    @BeforeEach
    void setUp() {
        cache = new DocsTextCacheService();
        scenarioServiceMock = Mockito.mock(ScenarioService.class);
        when(scenarioServiceMock.getMaxDocumentsPerRun()).thenReturn(100);
        // разбор: каждый файл — документ с тем же именем
        doAnswer(inv -> toDocuments(inv.getArgument(0)))
                .when(scenarioServiceMock).parseFiles(anyList(), any());
        uploads = new ScenarioUploadTaskService(scenarioServiceMock, cache);
    }

    @AfterEach
    void tearDown() {
        uploads.shutdown();
    }

    @Test
    void twoUsersOfSharedScenario_eachRunSeesOnlyOwnDocuments() throws InterruptedException {
        upload(USER_A, false, "форма-A.pdf");
        upload(USER_B, false, "форма-B.pdf", "критерии-B.pdf");

        assertEquals(List.of("форма-A.pdf"), docNamesSeenByRun(USER_A));
        assertEquals(List.of("критерии-B.pdf", "форма-B.pdf"), docNamesSeenByRun(USER_B));
        // запуск без X-UserId (аноним) документов этих пользователей не видит
        assertEquals(List.of(), docNamesSeenByRun(null));
    }

    @Test
    void anonymousUploadAndRun_shareOneUser() throws InterruptedException {
        // локальный стенд без шлюза: HTTP без заголовка (null) и WebSocket с пустым заголовком — один пользователь
        upload(null, false, "аноним.pdf");

        assertEquals(List.of("аноним.pdf"), docNamesSeenByRun(""));
        assertEquals(List.of(), docNamesSeenByRun(USER_A));
    }

    @Test
    void firstBatchOfOneUser_clearsOnlyOwnDocuments() throws InterruptedException {
        upload(USER_A, false, "a1.pdf");
        upload(USER_B, false, "b1.pdf");
        upload(USER_A, true, "a2.pdf");
        // новая первая партия USER_B (append=false) заменяет только его документы
        upload(USER_B, false, "b2.pdf");

        assertEquals(List.of("a1.pdf", "a2.pdf"), docNamesSeenByRun(USER_A));
        assertEquals(List.of("b2.pdf"), docNamesSeenByRun(USER_B));
    }

    @Test
    void uploadStatusAndBusyGuard_doNotDependOnOtherUser() throws InterruptedException {
        CountDownLatch releaseA = new CountDownLatch(1);
        doAnswer(inv -> {
            List<ScenarioService.RawFile> files = inv.getArgument(0);
            if (files.get(0).name().startsWith("a")) {
                // разбор USER_A держится до явного countDown; таймаут — только страховка от зависания
                releaseA.await(60, TimeUnit.SECONDS);
            }
            return toDocuments(files);
        }).when(scenarioServiceMock).parseFiles(anyList(), any());

        uploads.start(sharedScenarioId, USER_A, rawFiles("a.pdf"), false);
        assertTrue(uploads.isProcessing(sharedScenarioId, USER_A));
        // своя повторная загрузка USER_A отклоняется (422) — проверка сразу, до долгих шагов USER_B
        var filesA = rawFiles("a2.pdf");
        assertThrows(FileException.class, () -> uploads.start(sharedScenarioId, USER_A, filesA, false));
        assertEquals(ScenarioUploadTaskService.STATUS_PROCESSING, uploads.status(sharedScenarioId, USER_A).status());

        // пока разбирается загрузка USER_A, USER_B не видит её статус, не получает 422 и может запускать прогон
        assertEquals(ScenarioUploadTaskService.STATUS_NONE, uploads.status(sharedScenarioId, USER_B).status());
        assertFalse(uploads.isProcessing(sharedScenarioId, USER_B));
        var filesB = rawFiles("b.pdf");
        assertDoesNotThrow(() -> uploads.start(sharedScenarioId, USER_B, filesB, false));
        UploadStatusResponse statusB = awaitFinished(USER_B);
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, statusB.status());
        assertEquals(1, statusB.documents());
        assertEquals(List.of("b.pdf"), docNamesSeenByRun(USER_B));
        assertTrue(uploads.isProcessing(sharedScenarioId, USER_A));

        releaseA.countDown();
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(USER_A).status());
        assertEquals(List.of("a.pdf"), docNamesSeenByRun(USER_A));
        assertEquals(List.of("b.pdf"), docNamesSeenByRun(USER_B));
    }

    private static List<DocumentText> toDocuments(List<ScenarioService.RawFile> files) {
        return files.stream()
                .map(file -> new DocumentText(file.name(), "текст " + file.name()))
                .toList();
    }

    private static List<ScenarioService.RawFile> rawFiles(String... names) {
        return Arrays.stream(names)
                .map(name -> new ScenarioService.RawFile(name, name.getBytes(StandardCharsets.UTF_8)))
                .toList();
    }

    /**
     * Фоновая загрузка документов пользователем с ожиданием её завершения.
     */
    private void upload(String userId, boolean append, String... names) throws InterruptedException {
        uploads.start(sharedScenarioId, userId, rawFiles(names), append);
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(userId).status());
    }

    /**
     * Дожидается выхода задачи пользователя из processing (короткий поллинг вместо sleep).
     */
    @SuppressWarnings("java:S2925")
    private UploadStatusResponse awaitFinished(String userId) throws InterruptedException {
        for (int i = 0; i < 200; i++) {
            UploadStatusResponse status = uploads.status(sharedScenarioId, userId);
            if (!ScenarioUploadTaskService.STATUS_PROCESSING.equals(status.status())) {
                return status;
            }
            Thread.sleep(25);
        }
        return uploads.status(sharedScenarioId, userId);
    }

    /**
     * Запускает прогон общего сценария от имени пользователя и возвращает
     * отсортированные имена документов, которые получил граф прогона.
     * Первый узел прерывает прогон сразу после чтения документов.
     */
    private List<String> docNamesSeenByRun(String userId) {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(sharedScenarioId);
        run.setStatus("pending");
        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(new ScenarioRunStep());
        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(new ScenarioRunStep());
        Set<String> seen = new ConcurrentSkipListSet<>();
        when(executorFactory.createExecutor(any(ScenarioRunNode.class))).thenAnswer(inv -> {
            ScenarioRunNode node = inv.getArgument(0);
            node.getGraph().getDocMap().values().stream().map(ScenarioRunDoc::getFilename).forEach(seen::add);
            throw new ScenarioException("стоп: документы прогона прочитаны");
        });
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cache,
                Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        engine.executeScenario(run, graph(), userId).collectList().block(Duration.ofSeconds(30));
        Mockito.verify(runService, Mockito.timeout(5000)).setScenarioRunStatusFailed(any(ScenarioRun.class));
        return List.copyOf(new TreeSet<>(seen));
    }

    private static GraphDataDto graph() {
        NodeDto input = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto output = NodeDto.builder()
                .id("output-1")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(100, 100))
                .build();
        return new GraphDataDto(List.of(input, output),
                List.of(new EdgeDto("e1", "input-1", "output-1", new EdgeDataDto(null))));
    }
}
