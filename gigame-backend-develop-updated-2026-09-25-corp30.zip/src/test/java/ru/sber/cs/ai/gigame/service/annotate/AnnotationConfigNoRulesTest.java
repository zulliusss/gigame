package ru.sber.cs.ai.gigame.service.annotate;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Узел без правил отдаёт «[]» ({@code ScenarioRunNode.getRules()}), и разбор настройки разметки на каждом прогоне писал
 * в лог WARN «правила узла не разбираются». Разметка там просто не настроена — предупреждения быть не должно; настоящая
 * ошибка разбора (битый объект) по-прежнему предупреждает.
 */
class AnnotationConfigNoRulesTest {

    @Test
    void parse_rulesOfNodeWithoutRules_notConfiguredAndNoWarning() {
        List<ILoggingEvent> events = captured(() -> AnnotationConfig.parse("[]"));

        assertFalse(AnnotationConfig.configured("[]"));
        assertTrue(events.stream().noneMatch(e -> e.getLevel() == Level.WARN), events.toString());
    }

    @Test
    void parse_blankOrArrayWithSpaces_notConfigured() {
        assertNull(AnnotationConfig.parse(null));
        assertNull(AnnotationConfig.parse("   "));
        assertNull(AnnotationConfig.parse("  [ ]  "));
    }

    @Test
    void parse_objectWithAnnotationKey_configuredAsBefore() {
        AnnotationConfig cfg = AnnotationConfig.parse(" {\"разметка_документов\": {\"цитата\": \"з9\"}}");

        assertNotNull(cfg);
        assertEquals("з9", cfg.quoteField());
        assertNull(AnnotationConfig.parse("{\"колонки\": []}"));
    }

    @Test
    void parse_brokenObject_stillWarns() {
        List<ILoggingEvent> events = captured(() -> AnnotationConfig.parse("{\"разметка_документов\": "));

        assertEquals(1, events.stream().filter(e -> e.getLevel() == Level.WARN).count(), events.toString());
    }

    private static List<ILoggingEvent> captured(Supplier<AnnotationConfig> call) {
        Logger logger = (Logger) LoggerFactory.getLogger(AnnotationConfig.class);
        ListAppender<ILoggingEvent> journal = new ListAppender<>();
        journal.start();
        logger.addAppender(journal);
        try {
            assertNull(call.get());
        } finally {
            logger.detachAppender(journal);
        }
        return journal.list;
    }
}
