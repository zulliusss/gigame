package ru.sber.cs.ai.gigame.service.annotate;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Поиск цитаты в тексте документа: нормализация оформления и возврат позиций исходного текста.
 */
class TextLocatorTest {

    @Test
    void findsQuoteDespiteQuotesDashesYoAndSpacing() {
        String source = "Требование  №2: «отсутствие   действующих договоров» — с   другими банками, всё так.";
        String quote = "\"Отсутствие действующих договоров\" - с другими банками, все так";

        TextLocator.Span span = TextLocator.find(source, quote);

        assertNotNull(span);
        assertFalse(span.partial());
        assertEquals("отсутствие   действующих договоров» — с   другими банками, всё так", source.substring(span.start(), span.end()));
    }

    @Test
    void findsNumberWrittenWithDigitGroupingAndComma() {
        String source = "Итоговая сумма закупки составит: не более 289 523 339,14 руб., с учётом НДС.";

        TextLocator.Span span = TextLocator.find(source, "289523339.14");

        assertNotNull(span);
        assertEquals("289 523 339,14", source.substring(span.start(), span.end()));
    }

    @Test
    void longQuoteFallsBackToPrefixAndIsMarkedPartial() {
        String head = "Участник должен гарантировать отсутствие действующих договоров на разработку информационных материалов ";
        String source = head + "для другого банка.";
        String quote = head + "для другого банка, либо готовность расторгнуть их на период выполнения работ по этому договору";

        TextLocator.Span span = TextLocator.find(source, quote);

        assertNotNull(span);
        assertTrue(span.partial());
        assertTrue(source.substring(span.start(), span.end()).startsWith("Участник должен гарантировать"));
    }

    @Test
    void tableRowQuoteIsFoundByItsLongestCellPresentInText() {
        String cell = "Целесообразность настоящей закупочной процедуры направлена на согласование Первому заместителю";
        String row = "< Кем подтверждена целесообразность закупки | " + cell + " Председателя Правления (Приложение № 1) >";
        String numbers = "< 2 | Лот 2. | Комплект | 1 | 275448100,00 | 209331100,00* | 2324976360,00 >";

        TextLocator.Span inCell = TextLocator.find(cell + " Председателя Правления (Приложение № 1)", row);
        TextLocator.Span inNumberCell = TextLocator.find("275 448 100,00", numbers);

        assertNotNull(inCell);
        assertTrue(inCell.partial());
        assertEquals(0, inCell.start());
        assertNotNull(inNumberCell);
        assertEquals("275 448 100,00", "275 448 100,00".substring(inNumberCell.start(), inNumberCell.end()));
        assertNull(TextLocator.find("Кем подтверждена", "< а | б | в >"));
    }

    @Test
    void paraphrasedQuoteIsFoundByLongestWordWindow() {
        // модель пересказала начало цитаты («Корректура материала» вместо оборота документа), хвост дословный
        String source = "1.4. Подбор, выкуп и обработка стоковой иллюстрации к материалу.";
        String quote = "Корректура материала, подбор, выкуп и обработка стоковой иллюстрации";

        TextLocator.Span span = TextLocator.find(source, quote);

        assertNotNull(span);
        assertTrue(span.partial());
        assertEquals("Подбор, выкуп и обработка стоковой иллюстрации", source.substring(span.start(), span.end()));
    }

    @Test
    void tableHeaderGluedFromTwoCellsIsFoundByItsWords() {
        // цитата склеена из двух ячеек шапки таблицы — целиком её в тексте нет
        String source = "Среднемесячный расход";

        TextLocator.Span span = TextLocator.find(source, "Среднемесячный расход Новая закупка");

        assertNotNull(span);
        assertTrue(span.partial());
        assertEquals("Среднемесячный расход", source.substring(span.start(), span.end()));
    }

    @Test
    void randomWordsAreNotMatchedByWindow() {
        String source = "Участник обязан гарантировать отсутствие действующих договоров на разработку материалов.";

        assertNull(TextLocator.find(source, "совсем другие слова стоят подряд и ничего общего с текстом"));
    }

    @Test
    void quoteShortenedByEllipsisIsFoundByItsLongestPart() {
        String source = "Итоговая сумма закупки составит: не более 289 523 339,14 руб., с учётом НДС.";

        TextLocator.Span span = TextLocator.find(source, "НМЦ … 289523339.14");

        assertNotNull(span);
        assertTrue(span.partial());
        assertEquals("289 523 339,14", source.substring(span.start(), span.end()));
    }

    @Test
    void shortOrMissingQuoteIsNotFound() {
        assertNull(TextLocator.find("какой-то текст документа", "нет"));
        assertNull(TextLocator.find("какой-то текст документа", "совсем другая длинная фраза"));
        assertNull(TextLocator.find(null, "фраза для поиска"));
    }

    @Test
    void cleanQuoteStripsSurroundingQuotesAndEllipsis() {
        assertEquals("текст цитаты", TextLocator.cleanQuote(" «текст цитаты…» "));
        assertEquals("текст цитаты", TextLocator.cleanQuote("\"текст цитаты...\""));
    }

    @Test
    void normalizeKeepsSourceIndexForEveryChar() {
        TextLocator.Normalized normalized = TextLocator.normalize("Ёж,  1 234,5");

        assertEquals("еж, 1234.5", normalized.text());
        assertEquals(normalized.text().length(), normalized.sourceIndex().length);
        assertEquals(0, normalized.sourceIndex()[0]);
    }
}
