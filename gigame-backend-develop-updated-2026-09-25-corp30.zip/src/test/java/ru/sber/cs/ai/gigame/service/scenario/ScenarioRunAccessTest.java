package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.model.ScenarioRun;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Правило доступа к прогону: автор прогона; прогон без автора — владелец сценария.
 */
class ScenarioRunAccessTest {

    private static ScenarioRun run(String author) {
        ScenarioRun run = new ScenarioRun();
        run.setUserId(author);
        return run;
    }

    @Test
    void normalizeUser_emptyMeansAnonymous() {
        assertEquals("anonymous", ScenarioRunAccess.normalizeUser(null));
        assertEquals("anonymous", ScenarioRunAccess.normalizeUser(""));
        assertEquals("anonymous", ScenarioRunAccess.normalizeUser("anonymous"));
        assertEquals("ALICE", ScenarioRunAccess.normalizeUser("ALICE"));
    }

    @Test
    void canAccess_authoredRun_onlyAuthorEvenIfOtherOwnsScenario() {
        ScenarioRun aliceRun = run("ALICE");

        assertTrue(ScenarioRunAccess.canAccess(aliceRun, "OWNER", "ALICE"));
        assertFalse(ScenarioRunAccess.canAccess(aliceRun, "OWNER", "BOB"));
        assertFalse(ScenarioRunAccess.canAccess(aliceRun, "OWNER", "OWNER"));
        assertFalse(ScenarioRunAccess.canAccess(aliceRun, "ALICE", null));
    }

    @Test
    void canAccess_legacyRunWithoutAuthor_onlyScenarioOwner() {
        ScenarioRun legacy = run(null);

        assertTrue(ScenarioRunAccess.canAccess(legacy, "OWNER", "OWNER"));
        assertFalse(ScenarioRunAccess.canAccess(legacy, "OWNER", "ALICE"));
        assertFalse(ScenarioRunAccess.canAccess(legacy, null, "ALICE"));
    }

    @Test
    void canAccess_anonymousRun_normalizedAnonymousUser() {
        ScenarioRun anonymousRun = run("anonymous");

        assertTrue(ScenarioRunAccess.canAccess(anonymousRun, "OWNER", null));
        assertTrue(ScenarioRunAccess.canAccess(anonymousRun, "OWNER", ""));
        assertFalse(ScenarioRunAccess.canAccess(anonymousRun, "OWNER", "ALICE"));
        assertTrue(ScenarioRunAccess.canAccess(run(null), "anonymous", ""));
    }

    @Test
    void checkAccess_deniedThrowsAccessDenied() {
        ScenarioRun aliceRun = run("ALICE");

        assertDoesNotThrow(() -> ScenarioRunAccess.checkAccess(aliceRun, "OWNER", "ALICE"));
        assertThrows(AccessDeniedException.class,
                () -> ScenarioRunAccess.checkAccess(aliceRun, "OWNER", "BOB"));
    }
}
