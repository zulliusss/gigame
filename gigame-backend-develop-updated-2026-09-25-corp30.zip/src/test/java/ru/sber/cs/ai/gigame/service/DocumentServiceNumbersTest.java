package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Тесты нормализации чисел при извлечении текста: склейка разрядов,
 * разорванных пробелами-разделителями и переносами строк.
 */
class DocumentServiceNumbersTest {

    @Test
    void gluesGroupedThousands() {
        assertEquals("Сумма 9750986,34 руб.",
                DocumentService.normalizeNumberGroups("Сумма 9 750 986,34 руб."));
    }

    @Test
    void gluesTornDecimalNumber() {
        assertEquals("Итого 9750986,34",
                DocumentService.normalizeNumberGroups("Итого 975 09 86,34"));
    }

    @Test
    void gluesNumberWrappedByLineBreak() {
        assertEquals("НМЦ 3941343,56 руб.",
                DocumentService.normalizeNumberGroups("НМЦ 394134\n3,56 руб."));
    }

    @Test
    void gluesNumberWrappedAfterComma() {
        assertEquals("Акт на 384553,94",
                DocumentService.normalizeNumberGroups("Акт на 384553,\n94"));
    }

    @Test
    void keepsNeighbouringIndependentNumbers() {
        assertEquals("2025 100000,00",
                DocumentService.normalizeNumberGroups("2025 100 000,00"));
    }

    @Test
    void keepsQuantityAndPriceOfPdfTableRowApart() {
        // строка спецификации PDF «Лицензия | шт | 3 | 12,50 | 37,50» приходит через одиночные пробелы:
        // количество и цена — два числа, раньше склеивались в «312,50» (количество исчезало, цена искажалась молча)
        assertEquals("Лицензия шт 3 12,50 37,50",
                DocumentService.normalizeNumberGroups("Лицензия шт 3 12,50 37,50"));
        assertEquals("Позиция 7 22,10 154,70",
                DocumentService.normalizeNumberGroups("Позиция 7 22,10 154,70"));
        assertEquals("п. 2 5,5 %",
                DocumentService.normalizeNumberGroups("п. 2 5,5 %"));
        // номер этапа, номер строки и дата — не рваное число
        assertEquals("Этап 1 2 15.02.2025 1500000,00",
                DocumentService.normalizeNumberGroups("Этап 1 2 15.02.2025 1 500 000,00"));
    }

    @Test
    void gluesNumberTornInsideOneCellOrWrappedTotal() {
        // разрыв внутри одной ячейки (три куска и больше) и перенос строки внутри числа итога — склеиваются
        assertEquals("Итого 12345,67",
                DocumentService.normalizeNumberGroups("Итого 1 23 45,67"));
        assertEquals("Итого 3400940,77",
                DocumentService.normalizeNumberGroups("Итого 340094\n0,77"));
    }

    @Test
    void nullAndEmptyPassThrough() {
        assertEquals(null, DocumentService.normalizeNumberGroups(null));
        assertEquals("", DocumentService.normalizeNumberGroups(""));
    }
}
