package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class ScenarioRunRepositoryTest {

    Scenario scenario;
    @Autowired
    private ScenarioRunRepository scenarioRunRepository;
    @Autowired
    private ScenarioRepository scenarioRepository;

    @BeforeEach
    void setUp() {
        scenario = new Scenario();
        scenario.setName("Тестовый сценарий");
        scenario.setDescription("Тестовый сценарий");
        scenarioRepository.save(scenario);
    }

    @Test
    void testFindById_returnsScenarioRun() {
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("running");

        ScenarioRun saved = scenarioRunRepository.save(run);

        ScenarioRun found = scenarioRunRepository.findById(saved.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("running", found.getStatus());
    }

    @Test
    void testFindByScenarioIdOrderByStartedAtDesc_returnsSortedRuns() {
        // явные метки времени: два save подряд попадают в одну миллисекунду, и порядок по startedAt плавает
        ScenarioRun run1 = new ScenarioRun();
        run1.setScenarioId(scenario.getId());
        run1.setStatus("pending");
        run1.setStartedAt(OffsetDateTime.now().minusMinutes(2));
        scenarioRunRepository.save(run1);

        ScenarioRun run2 = new ScenarioRun();
        run2.setScenarioId(scenario.getId());
        run2.setStatus("completed");
        run2.setStartedAt(OffsetDateTime.now().minusMinutes(1));
        scenarioRunRepository.save(run2);

        List<ScenarioRun> result = scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenario.getId());

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("completed", result.get(0).getStatus());
        assertEquals("pending", result.get(1).getStatus());
    }

    private ScenarioRun savedRun(String userId, int minutesAgo) {
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("completed");
        run.setUserId(userId);
        run.setStartedAt(OffsetDateTime.now().minusMinutes(minutesAgo));
        return scenarioRunRepository.save(run);
    }

    @Test
    void testUserId_persistedAndLoaded() {
        ScenarioRun saved = savedRun("ALICE", 1);
        scenarioRunRepository.flush();

        ScenarioRun found = scenarioRunRepository.findById(saved.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("ALICE", found.getUserId());
    }

    @Test
    void testFindByScenarioIdAndUserId_returnsOnlyUsersRunsNewestFirst() {
        ScenarioRun aliceOld = savedRun("ALICE", 3);
        savedRun("BOB", 2);
        ScenarioRun aliceNew = savedRun("ALICE", 1);
        savedRun(null, 4);

        List<ScenarioRun> result = scenarioRunRepository
                .findByScenarioIdAndUserIdOrderByStartedAtDesc(scenario.getId(), "ALICE");

        assertEquals(List.of(aliceNew.getId(), aliceOld.getId()), result.stream().map(ScenarioRun::getId).toList());
    }

    @Test
    void testFindOwnerRuns_returnsOwnAndLegacyRunsWithoutForeign() {
        ScenarioRun legacy = savedRun(null, 3);
        savedRun("BOB", 2);
        ScenarioRun own = savedRun("OWNER", 1);

        List<ScenarioRun> result = scenarioRunRepository.findOwnerRuns(scenario.getId(), "OWNER");

        assertEquals(List.of(own.getId(), legacy.getId()), result.stream().map(ScenarioRun::getId).toList());
    }

    @Test
    void testFindByScenarioId_returnsEmptyList_whenNoRuns() {
        List<ScenarioRun> result = scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(UUID.randomUUID());
        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("running");

        ScenarioRun saved = scenarioRunRepository.save(run);
        assertNotNull(saved.getId());

        scenarioRunRepository.delete(saved);
        scenarioRunRepository.flush();

        assertFalse(scenarioRunRepository.findById(saved.getId()).isPresent());
    }

    /**
     * Завершённый прогон пользователя с явными метками старта и завершения.
     *
     * @param userId         автор прогона (null — прогон без автора)
     * @param startedMinutes сколько минут назад прогон стартовал
     * @param endedMinutes   сколько минут назад прогон завершился
     * @return сохранённый прогон
     */
    private ScenarioRun completedRun(String userId, int startedMinutes, int endedMinutes) {
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("completed");
        run.setUserId(userId);
        run.setStartedAt(OffsetDateTime.now().minusMinutes(startedMinutes));
        run.setCompletedAt(OffsetDateTime.now().minusMinutes(endedMinutes));
        return scenarioRunRepository.save(run);
    }

    @Test
    void testFindCompletedRunsByUser_ordersByCompletedAtAndSkipsUnfinished() {
        // пересекающиеся прогоны одного автора: run1 стартовал раньше, а завершился позже run2
        ScenarioRun run2 = completedRun("ALICE", 5, 4);
        ScenarioRun run1 = completedRun("ALICE", 6, 1);
        completedRun("BOB", 7, 2);
        ScenarioRun failed = completedRun("ALICE", 8, 3);
        failed.setStatus("failed");
        scenarioRunRepository.save(failed);
        ScenarioRun running = completedRun("ALICE", 1, 1);
        running.setStatus("running");
        running.setCompletedAt(null);
        scenarioRunRepository.save(running);

        List<ScenarioRun> result = scenarioRunRepository.findCompletedRunsByUser(scenario.getId(), "ALICE");

        assertEquals(List.of(run1.getId(), run2.getId()), result.stream().map(ScenarioRun::getId).toList());
    }

    @Test
    void testFindCompletedOwnerRuns_includesRunsWithoutAuthorAndSkipsForeign() {
        ScenarioRun legacy = completedRun(null, 6, 5);
        ScenarioRun own = completedRun("OWNER", 4, 1);
        completedRun("BOB", 3, 2);
        ScenarioRun ownFailed = completedRun("OWNER", 2, 1);
        ownFailed.setStatus("failed");
        scenarioRunRepository.save(ownFailed);

        List<ScenarioRun> result = scenarioRunRepository.findCompletedOwnerRuns(scenario.getId(), "OWNER");

        assertEquals(List.of(own.getId(), legacy.getId()), result.stream().map(ScenarioRun::getId).toList());
    }

    private ScenarioRun expiringRun(String userId, String status, int startedDaysAgo, int completedDaysAgo) {
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus(status);
        run.setUserId(userId);
        run.setStartedAt(OffsetDateTime.now().minusDays(startedDaysAgo));
        if (completedDaysAgo >= 0) {
            run.setCompletedAt(OffsetDateTime.now().minusDays(completedDaysAgo));
        }
        return scenarioRunRepository.save(run);
    }

    @Test
    void findExpiredRunIds_keepsRunningRunsAndLatestCompletedRunOfEachPair() {
        ScenarioRun aliceOld = expiringRun("ALICE", "completed", 40, 39);
        ScenarioRun aliceLatest = expiringRun("ALICE", "completed", 35, 34);
        ScenarioRun aliceFailed = expiringRun("ALICE", "failed", 45, 44);
        ScenarioRun aliceRunning = expiringRun("ALICE", "running", 50, -1);
        ScenarioRun bobOnly = expiringRun("BOB", "completed", 60, 59);
        ScenarioRun legacyOld = expiringRun(null, "completed", 70, 69);
        ScenarioRun legacyLatest = expiringRun(null, "completed", 65, 64);
        ScenarioRun recentFailed = expiringRun("ALICE", "failed", 5, 4);

        List<UUID> expired = scenarioRunRepository.findExpiredRunIds(OffsetDateTime.now().minusDays(30));

        assertEquals(Set.of(aliceOld.getId(), aliceFailed.getId(), legacyOld.getId()), Set.copyOf(expired));
        assertFalse(expired.contains(aliceLatest.getId()));
        assertFalse(expired.contains(aliceRunning.getId()));
        assertFalse(expired.contains(bobOnly.getId()));
        assertFalse(expired.contains(legacyLatest.getId()));
        assertFalse(expired.contains(recentFailed.getId()));
    }
}
