package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.dto.chat.MessageResponse;
import ru.sber.cs.ai.gigame.dto.chat.RagSource;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.ConversationRepository;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.repository.MessageRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.inOrder;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Генерация ответа чата (corp17): паузы GigaChat видны в потоке, по диалогу идёт одна
 * генерация, вопрос без ответа не сохраняется, вложения сверх бюджета не пропадают молча,
 * инструкция и контекст разделены границей деления, история ограничена по символам,
 * вложения регенерации читаются из хранилища, имя источника усекается до лимита схемы.
 */
@ExtendWith(MockitoExtension.class)
@SuppressWarnings("unchecked")
class ChatServiceStreamReplyTest {

    @Mock
    private ConversationRepository conversationRepository;
    @Mock
    private MessageRepository messageRepository;
    @Mock
    private GigaChatClient gigaChatClient;
    @Mock
    private EmbeddingService embeddingService;
    @Mock
    private MessageService messageService;
    @Mock
    private DocumentRepository documentRepository;
    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;
    @Mock
    private KbAggregateService kbAggregateService;
    @Mock
    private KBDocumentRepository kbDocumentRepository;

    @InjectMocks
    private ChatService chatService;

    private UUID conversationId;
    private Conversation conversation;

    @BeforeEach
    void setUp() {
        conversationId = UUID.randomUUID();
        conversation = new Conversation();
        conversation.setId(conversationId);
        conversation.setUserId("OWNER");
        ReflectionTestUtils.setField(chatService, "self", new AtomicReference<>(chatService));
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 12000);
        ReflectionTestUtils.setField(chatService, "maxHistoryMessages", 20);
        ReflectionTestUtils.setField(chatService, "maxAutoTitleLength", 100);
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        lenient().when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of());
        lenient().when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId)).thenReturn(List.of());
        lenient().when(messageRepository.save(any(Message.class))).thenAnswer(inv -> {
            Message m = inv.getArgument(0);
            if (m.getId() == null) {
                m.setId(UUID.randomUUID());
            }
            return m;
        });
        lenient().when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Ответ", null));
    }

    // -------------------------------------------------------------------------
    // Паузы GigaChat и ошибки генерации
    // -------------------------------------------------------------------------

    @Test
    void sendMessageStream_gigaChatWaitNotice_reachesUserAsContent() {
        ThreadLocal<Consumer<String>> notice = runWaitNotice();
        when(gigaChatClient.chatCompletionResult(any(), any(), any())).thenAnswer(inv -> {
            // GigaChatClient.withRetry зовёт получателя на потоке вызова — там, где чат его поставил
            notice.get().accept("превышен лимит запросов GigaChat (429) — пауза 30 с");
            return new GigaChatClient.ChatResult("Ответ", null);
        });

        List<String> contents = contents(send("Вопрос", null, null));

        assertEquals(2, contents.size());
        assertEquals(ChatService.WAIT_NOTICE_PREFIX + "превышен лимит запросов GigaChat (429) — пауза 30 с\n", contents.get(0));
        assertEquals("Ответ", contents.get(1));
        // пауза — служебное уведомление, в историю не попадает
        verify(messageService).saveAssistantMessage(eq(conversation), eq("Ответ"), any());
    }

    @Test
    void sendMessageStream_generationFails_userMessageNotSaved() {
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenThrow(new GigaChatException("Не удалось выполнить запрос к GigaChat: превышен лимит запросов (429) — паузы исчерпаны"));

        Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("OWNER",
                () -> chatService.sendMessageStream(conversationId, "Вопрос", null, null));

        GigaChatException e = assertThrows(GigaChatException.class, stream::blockLast);
        assertTrue(e.getMessage().contains("паузы исчерпаны"));
        verify(messageRepository, never()).save(any(Message.class));
        verify(messageService, never()).saveAssistantMessage(any(), any(), any());
        assertFalse(generating().contains(conversationId));
    }

    @Test
    void sendMessageStream_success_savesQuestionThenAnswer() {
        send("Вопрос", List.of("doc-1"), null);

        InOrder order = inOrder(messageRepository, messageService);
        order.verify(messageRepository).save(argThat(m -> "user".equals(m.getRole())
                && "Вопрос".equals(m.getContent()) && List.of("doc-1").equals(m.getDocumentIds())));
        order.verify(messageService).saveAssistantMessage(eq(conversation), eq("Ответ"), any());
    }

    // -------------------------------------------------------------------------
    // Одна генерация на диалог
    // -------------------------------------------------------------------------

    @Test
    void sendMessageStream_conversationBusy_rejectsSecondGeneration() {
        generating().add(conversationId);
        try {
            Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("OWNER",
                    () -> chatService.sendMessageStream(conversationId, "Вопрос", null, null));

            IllegalStateException e = assertThrows(IllegalStateException.class, stream::blockLast);
            assertEquals(ChatService.CONVERSATION_BUSY, e.getMessage());
            verify(gigaChatClient, never()).chatCompletionResult(any(), any(), any());
            // чужая генерация не снята
            assertTrue(generating().contains(conversationId));
        } finally {
            generating().remove(conversationId);
        }
    }

    @Test
    void sendMessageStream_releasesConversationAfterCompletionAndAfterRejection() {
        send("Вопрос", null, null);
        assertFalse(generating().contains(conversationId));

        Flux<ServerSentEvent<Map<String, Object>>> stranger = CurrentUserHolder.withUser("STRANGER",
                () -> chatService.sendMessageStream(conversationId, "Вопрос", null, null));
        assertThrows(AccessDeniedException.class, stranger::blockLast);
        assertFalse(generating().contains(conversationId));
    }

    // -------------------------------------------------------------------------
    // Вложения сверх бюджета контекста
    // -------------------------------------------------------------------------

    @Test
    void sendMessageStream_documentsOverBudget_warnsUserModelAndHistory() {
        // бюджет 400: части по 120 символов — помещаются три документа из семи
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 400);
        UUID fourth = UUID.randomUUID();
        Document doc = new Document();
        doc.setId(fourth);
        doc.setFilename("Договор_4.pdf");
        when(documentRepository.findById(fourth)).thenReturn(Optional.of(doc));
        List<String> texts = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            texts.add("Д".repeat(60));
            ids.add(i == 3 ? fourth.toString() : "doc-" + (i + 1));
        }
        String warning = "⚠ Документов: 7, из них 4 не поместились в контекст: Договор_4.pdf, документ 5, документ 6, документ 7";

        List<String> contents = contents(send("Вопрос", ids, texts));

        ArgumentCaptor<List<Map<String, String>>> captor = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient).chatCompletionResult(captor.capture(), any(), any());
        String system = captor.getValue().get(0).get("content");
        assertTrue(system.contains(warning));
        assertTrue(system.contains("--- ДОКУМЕНТ 3"));
        assertFalse(system.contains("--- ДОКУМЕНТ 4"));
        assertEquals(warning + "\n\n", contents.get(0));
        assertEquals("Ответ", contents.get(1));
        verify(messageService).saveAssistantMessage(eq(conversation), startsWith(warning + "\n\n"), any());
    }

    @Test
    void buildLargeDocumentPart_truncation_marksLimitAndMarker() {
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 8000);
        String text = "Т".repeat(9000);

        String part = ReflectionTestUtils.invokeMethod(chatService, "buildLargeDocumentPart",
                null, text, 1, "Вопрос", null);

        assertTrue(part.startsWith("--- ДОКУМЕНТ 1 (обрезан: 2000 из 9000 символов) ---"));
        assertTrue(part.contains(ChatService.DOC_TRUNCATED_MARKER));
        assertTrue(part.endsWith("--- КОНЕЦ ДОКУМЕНТА 1 ---"));
    }

    // -------------------------------------------------------------------------
    // Граница деления «инструкция | контекст»
    // -------------------------------------------------------------------------

    @Test
    void buildChatMessages_documents_instructionAndContextSeparatedByBoundary() {
        Object build = ReflectionTestUtils.invokeMethod(chatService, "buildChatMessages",
                conversation, message("user", "Вопрос"), null, List.of("Текст документа"));
        List<Map<String, String>> messages = ReflectionTestUtils.invokeMethod(build, "messages");

        String system = messages.get(0).get("content");
        int boundary = system.indexOf(GigaChatClient.SPLIT_BOUNDARY);
        assertTrue(boundary > 0);
        assertEquals(boundary, system.lastIndexOf(GigaChatClient.SPLIT_BOUNDARY));
        assertTrue(system.substring(0, boundary).startsWith("Пользователь загрузил 1 документ(ов)"));
        assertTrue(system.substring(boundary).contains("--- ДОКУМЕНТ 1 ---\nТекст документа"));
    }

    @Test
    void sendMessageStream_rag_instructionAndFragmentsSeparatedByBoundary() {
        UUID kbId = UUID.randomUUID();
        conversation.setKnowledgeBaseId(kbId);
        KnowledgeBase kb = new KnowledgeBase();
        kb.setShared(true);
        when(knowledgeBaseRepository.findById(kbId)).thenReturn(Optional.of(kb));
        UUID sourceDocId = UUID.randomUUID();
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString()))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("KB chunk", sourceDocId, 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(sourceDocId)).thenReturn(Optional.empty());

        send("Вопрос", null, null);

        ArgumentCaptor<List<Map<String, String>>> captor = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient).chatCompletionResult(captor.capture(), any(), any());
        String system = captor.getValue().get(0).get("content");
        int boundary = system.indexOf(GigaChatClient.SPLIT_BOUNDARY);
        assertTrue(boundary > 0);
        assertTrue(system.substring(0, boundary).startsWith("Ты — ассистент с доступом к базе знаний"));
        assertTrue(system.substring(boundary).contains("KB chunk"));
    }

    // -------------------------------------------------------------------------
    // Лимит символов истории
    // -------------------------------------------------------------------------

    @Test
    void addRecentHistory_charBudget_dropsOldestMessages() {
        ReflectionTestUtils.setField(chatService, "maxHistoryChars", 10);
        // от новых к старым, как возвращает репозиторий
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of(message("assistant", "Second"), message("user", "First!")));

        send("Third", null, null);

        verify(gigaChatClient).chatCompletionResult(argThat(messages -> messages.size() == 2
                && "Second".equals(messages.get(0).get("content"))
                && "Third".equals(messages.get(1).get("content"))), any(), any());
    }

    @Test
    void addRecentHistory_newestMessageOverBudget_isClippedWithMarker() {
        ReflectionTestUtils.setField(chatService, "maxHistoryChars", 60);
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of(message("assistant", "Ответ".repeat(40))));

        send("Вопрос", null, null);

        verify(gigaChatClient).chatCompletionResult(argThat(messages -> messages.size() == 2
                && messages.get(0).get("content").length() == 60
                && messages.get(0).get("content").endsWith(ChatService.HISTORY_CLIPPED_MARKER)), any(), any());
    }

    @Test
    void addRecentHistory_zeroBudget_noLimit() {
        ReflectionTestUtils.setField(chatService, "maxHistoryChars", 0);
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of(message("assistant", "Second"), message("user", "First!")));

        send("Third", null, null);

        verify(gigaChatClient).chatCompletionResult(argThat(messages -> messages.size() == 3), any(), any());
    }

    // -------------------------------------------------------------------------
    // Вложения регенерации/редактирования
    // -------------------------------------------------------------------------

    @Test
    void regenerateStream_cacheExpired_readsAttachmentsFromStorage() {
        UUID docId = UUID.randomUUID();
        Message question = message("user", "Что в договоре?");
        question.setDocumentIds(List.of(docId.toString()));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(List.of(question, message("assistant", "Старый ответ")));
        Document doc = new Document();
        doc.setId(docId);
        doc.setExtractedText("Текст договора из хранилища");
        when(documentRepository.findById(docId)).thenReturn(Optional.of(doc));

        CurrentUserHolder.withUser("OWNER", () -> chatService.regenerateStream(conversationId, null, null)).blockLast();

        verify(gigaChatClient).chatCompletionResult(argThat(messages -> "system".equals(messages.get(0).get("role"))
                && messages.get(0).get("content").contains("Текст договора из хранилища")), any(), any());
        verify(messageService).saveAssistantMessage(eq(conversation), eq("Ответ"), any());
    }

    @Test
    void regenerateStream_attachmentDeleted_reportsExpiredInsteadOfSilentRequest() {
        UUID docId = UUID.randomUUID();
        Message question = message("user", "Что в договоре?");
        question.setDocumentIds(List.of(docId.toString()));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId)).thenReturn(List.of(question));
        when(documentRepository.findById(docId)).thenReturn(Optional.empty());

        Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("OWNER",
                () -> chatService.regenerateStream(conversationId, null, null));

        NotFoundException e = assertThrows(NotFoundException.class, stream::blockLast);
        assertEquals(ChatService.ATTACHMENTS_EXPIRED, e.getMessage());
        verify(gigaChatClient, never()).chatCompletionResult(any(), any(), any());
        assertFalse(generating().contains(conversationId));
    }

    @Test
    void editMessageStream_cachedAttachments_takePriorityOverStorage() {
        Message question = message("user", "Старый вопрос");
        question.setDocumentIds(List.of(UUID.randomUUID().toString()));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId)).thenReturn(List.of(question));

        CurrentUserHolder.withUser("OWNER", () -> chatService.editMessageStream(conversationId, question.getId(),
                "Новый вопрос", List.of("cached-id"), List.of("Текст из кэша"))).blockLast();

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.get(0).get("content").contains("Текст из кэша")
                        && "Новый вопрос".equals(messages.get(messages.size() - 1).get("content"))), any(), any());
        verify(documentRepository, never()).findById(any(UUID.class));
    }

    // -------------------------------------------------------------------------
    // Имя источника — maxLength 255 (RagSource.document_name)
    // -------------------------------------------------------------------------

    @Test
    void convertSourcesToMap_clipsDocumentNameToSchemaLimit() {
        String longName = "д".repeat(300) + ".pdf";

        List<Map<String, String>> result = ReflectionTestUtils.invokeMethod(chatService, "convertSourcesToMap",
                List.of(new RagSource(UUID.randomUUID(), longName, "фрагмент")));

        assertEquals(ChatService.MAX_SOURCE_NAME_LENGTH, result.get(0).get("document_name").length());
        assertEquals("фрагмент", result.get(0).get("snippet"));
    }

    @Test
    void toMessageResponse_clipsStoredDocumentName() {
        Message msg = message("assistant", "Ответ");
        msg.setSources(List.of(Map.of("document_id", UUID.randomUUID().toString(),
                "document_name", "д".repeat(300), "snippet", "фрагмент")));

        MessageResponse response = ReflectionTestUtils.invokeMethod(chatService, "toMessageResponse", msg);

        assertEquals(ChatService.MAX_SOURCE_NAME_LENGTH, response.sources().get(0).documentName().length());
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы
    // -------------------------------------------------------------------------

    private List<ServerSentEvent<Map<String, Object>>> send(String content, List<String> docIds, List<String> texts) {
        return CurrentUserHolder.withUser("OWNER",
                () -> chatService.sendMessageStream(conversationId, content, docIds, texts)).collectList().block();
    }

    private static List<String> contents(List<ServerSentEvent<Map<String, Object>>> events) {
        return events.stream()
                .map(ServerSentEvent::data)
                .filter(data -> data != null && data.containsKey(ChatService.CONTENT))
                .map(data -> String.valueOf(data.get(ChatService.CONTENT)))
                .toList();
    }

    private Message message(String role, String content) {
        Message msg = new Message();
        msg.setId(UUID.randomUUID());
        msg.setRole(role);
        msg.setContent(content);
        msg.setConversation(conversation);
        return msg;
    }

    private Set<UUID> generating() {
        return (Set<UUID>) ReflectionTestUtils.getField(chatService, "generating");
    }

    /** Получатель уведомлений о паузах текущего потока — приватный ThreadLocal GigaChatClient. */
    private static ThreadLocal<Consumer<String>> runWaitNotice() {
        return (ThreadLocal<Consumer<String>>) ReflectionTestUtils.getField(GigaChatClient.class, "RUN_WAIT_NOTICE");
    }
}
