package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты блочной вёрстки листа (ключ "блоки" в rules): служебные строки
 * (паспорт закупки, выводы) выносятся из таблицы в блоки над и под ней.
 */
class ScenarioResultToXlsxBlocksTest {

    private static final String DATA_JSON = """
            [
              {"з1": "—", "з2": "Предмет закупки: услуги", "з4": "ПАСПОРТ"},
              {"з1": "—", "з2": "Способ закупки: у единственного поставщика", "з4": "ПАСПОРТ"},
              {"з1": "1", "з2": "Требование об опыте", "з4": "ВЫСОКИЙ"},
              {"з1": "2", "з2": "Срок оплаты 45 дней", "з4": "НИЗКИЙ"},
              {"з1": "—", "з2": "Количество рисков: 2", "з4": "ВЫВОД"}
            ]
            """;

    private static final String RULES = """
            {"лист": "Заключение",
             "колонки": [
              {"ключ": "з1", "заголовок": "№"},
              {"ключ": "з2", "заголовок": "Выявленный риск"},
              {"ключ": "з4", "заголовок": "Уровень риска"}
             ],
             "блоки": {"ключ": "з4", "верх": ["ПАСПОРТ"], "низ": ["ВЫВОД"],
                       "текст": "з2", "заголовок_верх": "ВВОДНАЯ ИНФОРМАЦИЯ О ЗАКУПКЕ",
                       "заголовок_низ": "ВЫВОДЫ"}}
            """;

    private static Sheet readSheet(byte[] xlsx) throws IOException {
        return new XSSFWorkbook(new ByteArrayInputStream(xlsx)).getSheetAt(0);
    }

    @Test
    void blocks_passportAboveTable_conclusionsBelow() throws IOException {
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, RULES));

        // верхний блок: заголовок и две паспортные строки текстом
        assertEquals("ВВОДНАЯ ИНФОРМАЦИЯ О ЗАКУПКЕ", sheet.getRow(0).getCell(0).getStringCellValue());
        assertEquals("Предмет закупки: услуги", sheet.getRow(1).getCell(0).getStringCellValue());
        assertEquals("Способ закупки: у единственного поставщика",
                sheet.getRow(2).getCell(0).getStringCellValue());
        // строка 3 — отступ, строка 4 — шапка таблицы
        assertEquals("Выявленный риск", sheet.getRow(4).getCell(1).getStringCellValue());
        // таблица: только строки рисков, без паспорта и выводов
        assertEquals("Требование об опыте", sheet.getRow(5).getCell(1).getStringCellValue());
        assertEquals("Срок оплаты 45 дней", sheet.getRow(6).getCell(1).getStringCellValue());
        // нижний блок после пустой строки-отступа
        assertEquals("ВЫВОДЫ", sheet.getRow(8).getCell(0).getStringCellValue());
        assertEquals("Количество рисков: 2", sheet.getRow(9).getCell(0).getStringCellValue());
        // блочные строки растянуты на ширину таблицы
        assertTrue(sheet.getNumMergedRegions() >= 4);
    }

    @Test
    void blocks_absentConfig_keepsPlainTableLayout() throws IOException {
        String rules = """
                {"колонки": [
                  {"ключ": "з1", "заголовок": "№"},
                  {"ключ": "з2", "заголовок": "Находка"},
                  {"ключ": "з4", "заголовок": "Уровень"}
                ]}
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, rules));

        // без конфига блоков — прежнее поведение: шапка в строке 0, все строки в таблице
        assertEquals("№", sheet.getRow(0).getCell(0).getStringCellValue());
        assertEquals("Предмет закупки: услуги", sheet.getRow(1).getCell(1).getStringCellValue());
        assertEquals("Количество рисков: 2", sheet.getRow(5).getCell(1).getStringCellValue());
        assertEquals(0, sheet.getNumMergedRegions());
    }

    @Test
    void blocks_levelSummaryCountedByCode() throws IOException {
        String rules = RULES.replace("\"заголовок_низ\": \"ВЫВОДЫ\"}}",
                "\"заголовок_низ\": \"ВЫВОДЫ\", \"сводка_уровней\": {\"колонка\": \"з4\", \"номер\": \"з1\"}}}");
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, rules));

        // первая строка нижнего блока — сводка, посчитанная по таблице; уровни без строк не упоминаются
        assertEquals("ВЫВОДЫ", sheet.getRow(8).getCell(0).getStringCellValue());
        String summary = sheet.getRow(9).getCell(0).getStringCellValue();
        assertTrue(summary.contains("ВЫСОКИЙ — №1 (итого 1)"));
        assertTrue(summary.contains("НИЗКИЙ — №2 (итого 1)"));
        assertFalse(summary.contains("СРЕДНИЙ"));
        // строка модели с выводом идёт следом
        assertEquals("Количество рисков: 2", sheet.getRow(10).getCell(0).getStringCellValue());
    }
}
