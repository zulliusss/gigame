package ru.sber.cs.ai.gigame.service;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DefaultDataBuffer;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.exception.UnsupportedFormatException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertNull;

@ExtendWith(MockitoExtension.class)
class DocumentServiceTest {

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private EmbeddingService embeddingService;

    @Mock
    private DocumentIndexService indexService;

    @InjectMocks
    private DocumentService documentService;

    private Document document;

    @BeforeEach
    void setUp() {
        document = new Document();
        document.setId(UUID.randomUUID());
        document.setUserId("user1");
        document.setExtractedText("Test content");
        ReflectionTestUtils.setField(documentService, "charLimit", 12000);
    }

    @Test
    void testParseText_PDF() throws Exception {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.pdf");
        assertNotNull(inputStream, "Файл test.pdf не найден в resources");
        String result = documentService.parseText(inputStream, "pdf");
        assertEquals("Это тестовый файл для проверки парсинга \n", result);
    }

    @Test
    void testParseText_DOCX() throws Exception {
        var expected = """
                Заголовок
                Это тестовый файл для проверки парсинга
                
                [ < 1 |  | 3 >
                < Нужна | Для проверки | Третий
                [ < Вложенная | Таблица >
                < Первый | Второй > ]
                столбец > ]
                
                Таблица с переменными
                [ < 1 | 15919275,00 | Рубль > ]
                
                Жирный текст после таблицы.
                Курсив тоже нужно проверить.""";
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.docx");
        assertNotNull(inputStream, "Файл test.docx не найден в resources");
        String result = documentService.parseText(inputStream, "docx");
        assertEquals(expected, result);
    }

    @Test
    void testParseText_XLSX() throws Exception {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.xlsx");
        assertNotNull(inputStream, "Файл test.xlsx не найден в resources");
        String result = documentService.parseText(inputStream, "xlsx");
        assertEquals("это | тестовый | документ | для | проверки | парсинга\n1 | 2 |  | 4 | 5 | 12\n", result);
    }

    @Test
    void testParseText_XLSX_multilineCellStaysOnOneRow() throws Exception {
        // перенос строки внутри ячейки рвал текстовую строку листа пополам —
        // построчные потребители получали половину строки и сдвиг колонок
        var out = new java.io.ByteArrayOutputStream();
        try (var wb = new org.apache.poi.xssf.usermodel.XSSFWorkbook()) {
            var sheet = wb.createSheet("Данные");
            var row = sheet.createRow(0);
            row.createCell(0).setCellValue("Договор №800000283541\nот 09.01.2025");
            row.createCell(1).setCellValue("АКТ сдачи-приемки\nпо Этапу 1");
            wb.write(out);
        }
        String result = documentService.parseText(new ByteArrayInputStream(out.toByteArray()), "xlsx");
        assertEquals("Договор №800000283541 от 09.01.2025 | АКТ сдачи-приемки по Этапу 1\n", result);
    }

    @Test
    void testParseText_TXT() throws Exception {
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream("test.txt");
        assertNotNull(inputStream, "Файл test.txt не найден в resources");
        String result = documentService.parseText(inputStream, "txt");
        assertEquals("Это тестовый документ для проверки парсинга", result);
    }

    @Test
    void testParseText_withUnsupportedType_throwsException() {
        InputStream inputStream = new ByteArrayInputStream("test".getBytes());

        assertThrows(IllegalArgumentException.class,
                () -> documentService.parseText(inputStream, "unsupported"));
    }

    @Test
    void testDeleteDocument() {
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        doNothing().when(embeddingService).deleteDocumentChunks(any());

        documentService.deleteDocument(document.getId());

        verify(embeddingService).deleteDocumentChunks(document.getId());
        verify(documentRepository).delete(document);
    }

    @Test
    void testDeleteDocument_withNonExistingDocument_throwsNotFoundException() {
        when(documentRepository.findById(any())).thenReturn(Optional.empty());
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> documentService.deleteDocument(uuid));
    }

    @Test
    void testUploadDocument() {
        String userId = "user1";
        String filename = "test.txt";
        String content = "Test document content";
        byte[] bytes = content.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);
        lenient().when(filePart.content()).thenReturn(flux);

        Document savedDoc = new Document();
        savedDoc.setId(UUID.randomUUID());
        savedDoc.setFilename(filename);
        savedDoc.setContentType("txt");
        savedDoc.setExtractedText(content);
        savedDoc.setSizeBytes(bytes.length);
        savedDoc.setUserId(userId);

        when(documentRepository.save(any())).thenReturn(savedDoc);
        doNothing().when(indexService).indexDocument(any(), any());

        ReflectionTestUtils.setField(documentService, "charLimit", 10);

        DocumentService.DocumentResponse result = CurrentUserHolder.withUser(userId,
                () -> documentService.uploadDocument(filePart));

        assertNotNull(result);
        assertEquals(filename, result.filename());
        assertEquals("txt", result.contentType());
        assertEquals(bytes.length, result.sizeBytes());
        assertEquals(content.length(), result.textLength());
        verify(documentRepository).save(any(Document.class));
        verify(indexService).indexDocument(savedDoc.getId(), content);
    }

    @Test
    void testUploadDocument_withLongDocument_triggersIndexing() {
        String userId = "user1";
        String filename = "long.txt";
        String longContent = "A".repeat(15000);
        byte[] bytes = longContent.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);
        lenient().when(filePart.content()).thenReturn(flux);

        Document savedDoc = new Document();
        savedDoc.setId(UUID.randomUUID());
        savedDoc.setFilename(filename);
        savedDoc.setContentType("txt");
        savedDoc.setExtractedText(longContent);
        savedDoc.setSizeBytes(bytes.length);
        savedDoc.setUserId(userId);

        when(documentRepository.save(any())).thenReturn(savedDoc);
        doNothing().when(indexService).indexDocument(any(), any());

        DocumentService.DocumentResponse result = CurrentUserHolder.withUser(userId,
                () -> documentService.uploadDocument(filePart));

        assertNotNull(result);
        assertEquals(15000, result.textLength());
        verify(indexService).indexDocument(savedDoc.getId(), longContent);
    }

    @Test
    void testUploadDocument_withShortDocument_skipsIndexing() {
        String userId = "user1";
        String filename = "short.txt";
        String shortContent = "Short";
        byte[] bytes = shortContent.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);
        lenient().when(filePart.content()).thenReturn(flux);

        Document savedDoc = new Document();
        savedDoc.setId(UUID.randomUUID());
        savedDoc.setFilename(filename);
        savedDoc.setContentType("txt");
        savedDoc.setExtractedText(shortContent);
        savedDoc.setSizeBytes(bytes.length);
        savedDoc.setUserId(userId);

        when(documentRepository.save(any())).thenReturn(savedDoc);

        DocumentService.DocumentResponse result = CurrentUserHolder.withUser(userId,
                () -> documentService.uploadDocument(filePart));

        assertNotNull(result);
        assertEquals(5, result.textLength());
        verify(indexService, never()).indexDocument(any(), any());
    }

    @Test
    void testUploadDocument_withNullFilename() {
        String userId = "user1";
        String content = "Test content";
        byte[] bytes = content.getBytes();

        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.wrap(bytes);
        Flux<DataBuffer> flux = Flux.just(dataBuffer);

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn("");
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn((long) bytes.length);
        lenient().when(filePart.content()).thenReturn(flux);

        assertThrows(FileException.class,
                () -> CurrentUserHolder.withUser(userId, () -> {
                    documentService.uploadDocument(filePart);
                    return null;
                }));
    }

    @Test
    void testUploadDocument_withParsingError_throwsFileException() {
        String userId = "user1";
        String filename = "test.xyz";

        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);

        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.name()).thenReturn("file");
        lenient().when(filePart.headers()).thenReturn(headersMock);
        lenient().when(headersMock.getContentLength()).thenReturn(100L);

        // Simulate content stream (optional - depends on whether parseText is called)
        DefaultDataBuffer dataBuffer = DefaultDataBufferFactory.sharedInstance.allocateBuffer(0);
        lenient().when(filePart.content()).thenReturn(Flux.just(dataBuffer));

        assertThrows(FileException.class,
                () -> CurrentUserHolder.withUser(userId, () -> {
                    documentService.uploadDocument(filePart);
                    return null;
                }));
    }

    @Test
    void testParseText_XLS_binary() throws Exception {
        // Бинарный XLS генерируется на лету — раньше .xls направлялся в XLSX-парсер и падал
        var out = new java.io.ByteArrayOutputStream();
        try (var wb = new HSSFWorkbook()) {
            var sheet = wb.createSheet("Данные");
            var row = sheet.createRow(0);
            row.createCell(0).setCellValue("Поставщик");
            row.createCell(1).setCellValue("Цена");
            var row2 = sheet.createRow(1);
            row2.createCell(0).setCellValue("Оптима");
            row2.createCell(1).setCellValue(1234.5);
            wb.write(out);
        }
        String result = documentService.parseText(new ByteArrayInputStream(out.toByteArray()), "xls");
        assertNotNull(result);
        assertEquals(true, result.contains("Поставщик | Цена"));
        assertEquals(true, result.contains("Оптима"));
    }

    @Test
    void testParseText_XLS_numbersDoNotDependOnJvmLocale() throws Exception {
        // кейс Хинт 23.09.2026: без фиксированной локали форматтера пром (en) давал «1,338,698.00 ₽», стенд ru-RU — «1 338 698,00 ₽»;
        // локаль зафиксирована русской (формат, на котором отлажены сценарии), разряды — неразрывный пробел U+00A0
        var out = new ByteArrayOutputStream();
        try (var wb = new HSSFWorkbook()) {
            var row = wb.createSheet("Рейтинг").createRow(0);
            var formats = wb.getCreationHelper().createDataFormat();
            var rubles = wb.createCellStyle();
            rubles.setDataFormat(formats.getFormat("#,##0.00 \"₽\""));
            var plain = wb.createCellStyle();
            plain.setDataFormat(formats.getFormat("#,##0.00"));
            var rublesCell = row.createCell(0);
            rublesCell.setCellValue(1338698.0);
            rublesCell.setCellStyle(rubles);
            var plainCell = row.createCell(1);
            plainCell.setCellValue(1338698.0);
            plainCell.setCellStyle(plain);
            wb.write(out);
        }
        Locale previous = Locale.getDefault();
        Locale.setDefault(Locale.US);
        try {
            String result = documentService.parseText(new ByteArrayInputStream(out.toByteArray()), "xls");
            // XLS идёт через formatRawCellContents по индексу формата: разряды POI здесь не ставит, десятичная — запятая
            assertEquals("1338698,00 ₽ | 1338698,00\n", result);
        } finally {
            Locale.setDefault(previous);
        }
    }

    @Test
    void testParseText_PPTX() throws Exception {
        var out = new java.io.ByteArrayOutputStream();
        try (var ppt = new XMLSlideShow()) {
            var slide = ppt.createSlide();
            var box = slide.createTextBox();
            box.setAnchor(new java.awt.Rectangle(50, 50, 400, 100));
            box.setText("Заголовок презентации");
            var slide2 = ppt.createSlide();
            var box2 = slide2.createTextBox();
            box2.setAnchor(new java.awt.Rectangle(50, 50, 400, 100));
            box2.setText("Второй слайд");
            var table = slide2.createTable();
            table.setAnchor(new java.awt.Rectangle(50, 200, 400, 100));
            var headerRow = table.addRow();
            headerRow.addCell().setText("Колонка 1");
            headerRow.addCell().setText("Колонка 2");
            var dataRow = table.addRow();
            dataRow.addCell().setText("Значение 1");
            dataRow.addCell().setText("Значение 2");
            ppt.write(out);
        }
        String result = documentService.parseText(new ByteArrayInputStream(out.toByteArray()), "pptx");
        assertNotNull(result);
        assertEquals(true, result.contains("=== Слайд 1 ==="));
        assertEquals(true, result.contains("Заголовок презентации"));
        assertEquals(true, result.contains("=== Слайд 2 ==="));
        assertEquals(true, result.contains("Второй слайд"));
    }

    // -------------------------------------------------------------------------
    // corp17: размер и хэш содержимого, чтение и разбор по частям, предел текстов чата
    // -------------------------------------------------------------------------

    private static FilePart filePartOf(String filename, byte[] bytes) {
        FilePart filePart = mock(FilePart.class);
        HttpHeaders headersMock = mock(HttpHeaders.class);
        lenient().when(filePart.filename()).thenReturn(filename);
        lenient().when(filePart.headers()).thenReturn(headersMock);
        // у multipart-части заголовка Content-Length обычно нет
        lenient().when(headersMock.getContentLength()).thenReturn(-1L);
        lenient().when(filePart.content()).thenReturn(Flux.just(DefaultDataBufferFactory.sharedInstance.wrap(bytes)));
        return filePart;
    }

    @Test
    void uploadDocument_storesActualSizeAndSha256_notContentLengthHeader() {
        byte[] bytes = "Текст документа".getBytes(StandardCharsets.UTF_8);
        when(documentRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        ArgumentCaptor<Document> captor = ArgumentCaptor.forClass(Document.class);

        DocumentService.DocumentResponse result = CurrentUserHolder.withUser("user1",
                () -> documentService.uploadDocument(filePartOf("a.txt", bytes)));

        verify(documentRepository).save(captor.capture());
        assertEquals(bytes.length, captor.getValue().getSizeBytes());
        assertEquals(bytes.length, result.sizeBytes());
        assertEquals(DocumentService.sha256Hex(bytes), captor.getValue().getContentSha256());
        assertEquals(64, captor.getValue().getContentSha256().length());
    }

    @Test
    void sha256Hex_knownVector() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
                DocumentService.sha256Hex("abc".getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    void readContent_returnsBytes_andRejectsOversizedFile() {
        byte[] bytes = "1234".getBytes(StandardCharsets.UTF_8);

        assertEquals(4, documentService.readContent(filePartOf("a.txt", bytes)).length);

        ReflectionTestUtils.setField(documentService, "maxFileSizeBytes", 3L);
        FilePart big = filePartOf("a.txt", bytes);
        assertThrows(FileException.class, () -> documentService.readContent(big));
    }

    @Test
    void readContent_stopsAtLimitWhileReadingChunks_withoutBufferingWholeFile() {
        // предел проверяется по ходу чтения частей: третья часть за пределом обрывает чтение, а не сравнивается после
        ReflectionTestUtils.setField(documentService, "maxFileSizeBytes", 5L);
        FilePart part = mock(FilePart.class);
        lenient().when(part.filename()).thenReturn("big.pdf");
        when(part.content()).thenReturn(Flux.just(
                DefaultDataBufferFactory.sharedInstance.wrap("1234".getBytes(StandardCharsets.UTF_8)),
                DefaultDataBufferFactory.sharedInstance.wrap("5678".getBytes(StandardCharsets.UTF_8)),
                DefaultDataBufferFactory.sharedInstance.wrap("90".getBytes(StandardCharsets.UTF_8))));

        FileException e = assertThrows(FileException.class, () -> documentService.readContent(part));

        assertTrue(e.getMessage().contains("превышает максимально допустимый размер"), e.getMessage());
    }

    @Test
    void unreadableDocument_savesMarkerWithHonestReason() {
        when(documentRepository.save(any())).thenAnswer(invocation -> {
            Document saved = invocation.getArgument(0);
            saved.setId(UUID.randomUUID());
            return saved;
        });

        DocumentService.DocumentResponse unsupported = CurrentUserHolder.withUser("user1", () -> documentService.unreadableDocument(
                "Договор.doc", new UnsupportedFormatException("doc", "Word 97-2003 — сохраните документ как DOCX или PDF")));
        DocumentService.DocumentResponse tooBig = documentService.unreadableDocument("том.pdf",
                new FileException("Файл том.pdf превышает максимально допустимый размер: 104857600 байт"));
        DocumentService.DocumentResponse broken = documentService.unreadableDocument("битый.pdf",
                new FileException("Failed to extract text from битый.pdf"));

        assertTrue(unsupported.extractedText().startsWith(DocumentService.MANUAL_CHECK_MARKER
                + " Документ «Договор.doc» не удалось обработать: формат .doc не поддерживается (Word 97-2003"), unsupported.extractedText());
        assertTrue(tooBig.extractedText().contains("превышает максимально допустимый размер"), tooBig.extractedText());
        assertTrue(broken.extractedText().contains("файл повреждён или содержит неподдерживаемое содержимое"), broken.extractedText());
        assertEquals("txt", broken.contentType());
        assertNotNull(broken.id());
    }

    @Test
    void extractText_parsesTxt_andWrapsParserFailure() {
        assertEquals("привет", documentService.extractText("a.txt", "txt", "привет".getBytes(StandardCharsets.UTF_8)));

        byte[] broken = "not a pdf".getBytes(StandardCharsets.UTF_8);
        assertThrows(FileException.class, () -> documentService.extractText("a.pdf", "pdf", broken));
    }

    @Test
    void checkChatTotalChars_rejectsOverLimit_allowsWithinAndDisabled() {
        ReflectionTestUtils.setField(documentService, "chatMaxTotalChars", 10L);
        List<String> over = List.of("12345", "123456");
        List<String> within = List.of("12345", "12345");

        assertThrows(FileException.class, () -> documentService.checkChatTotalChars(over));
        documentService.checkChatTotalChars(within);

        ReflectionTestUtils.setField(documentService, "chatMaxTotalChars", 0L);
        documentService.checkChatTotalChars(over);
    }

    @Test
    void uploadDocument_isNotTransactional_parsingOcrAndEmbeddingsRunOutsideDbTransaction() throws NoSuchMethodException {
        // разбор, OCR и эмбеддинги длятся минутами: соединение из пула Hikari на это время не удерживается
        assertNull(DocumentService.class.getMethod("uploadDocument", FilePart.class).getAnnotation(Transactional.class));
    }
}
