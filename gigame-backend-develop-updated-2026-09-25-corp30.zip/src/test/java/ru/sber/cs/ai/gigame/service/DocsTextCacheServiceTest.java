package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.test.util.ReflectionTestUtils;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тест для {@link DocsTextCacheService}.
 * <p>
 * Проверяет базовые операции кэширования текстов документов: сохранение,
 * получение, очистка кэша для отдельного диалога/сценария и всего кэша.
 */
@ExtendWith(MockitoExtension.class)
class DocsTextCacheServiceTest {

    private DocsTextCacheService cacheService;

    private UUID id;
    private List<String> documentTexts;
    private List<String> fileNames;
    private List<String> docIds;

    @BeforeEach
    void setUp() {
        cacheService = new DocsTextCacheService();
        id = UUID.randomUUID();
        documentTexts = List.of("текст документа 1", "текст документа 2");
        fileNames = List.of("file1.pdf", "file2.docx");
        docIds = List.of("doc-001", "doc-002");
    }

    @Test
    void testCacheDocumentTexts_shouldStoreAndReturnData() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        assertEquals(documentTexts, cacheService.getCachedDocumentTexts(id));
        assertEquals(fileNames, cacheService.getCachedFileNames(id));
        assertEquals(docIds, cacheService.getCachedDocIds(id));
    }

    @Test
    void testGetCachedDocumentTexts_withEmptyCache_shouldReturnEmptyList() {
        List<String> result = cacheService.getCachedDocumentTexts(id);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetCachedFileNames_withEmptyCache_shouldReturnEmptyString() {
        var result = cacheService.getCachedFileNames(id);
        assertNotNull(result);
        assertEquals(List.of(), result);
    }

    @Test
    void testGetCachedDocIds_withEmptyCache_shouldReturnEmptyList() {
        List<String> result = cacheService.getCachedDocIds(id);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testClearCache_shouldRemoveOnlySpecifiedEntry() {
        UUID otherId = UUID.randomUUID();
        List<String> otherTexts = List.of("другой текст");

        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.cacheDocumentTexts(otherId, otherTexts, List.of("other.pdf"), List.of("doc-003"));

        cacheService.clearCache(id);

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertEquals(List.of(), cacheService.getCachedFileNames(id));
        assertTrue(cacheService.getCachedDocIds(id).isEmpty());

        // otherId должен остаться в кэше
        assertEquals(otherTexts, cacheService.getCachedDocumentTexts(otherId));
    }

    @Test
    void testClearAllCache_shouldRemoveAllEntries() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        cacheService.clearAllCache();

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertEquals(List.of(), cacheService.getCachedFileNames(id));
        assertTrue(cacheService.getCachedDocIds(id).isEmpty());
    }

    @Test
    void testCacheDocumentTexts_shouldOverwriteExistingEntry() {
        List<String> updatedTexts = List.of("обновленный текст");
        List<String> updatedFileNames = List.of("new.pdf");
        List<String> updatedDocIds = List.of("doc-003");

        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.cacheDocumentTexts(id, updatedTexts, updatedFileNames, updatedDocIds);

        assertEquals(updatedTexts, cacheService.getCachedDocumentTexts(id));
        assertEquals(updatedFileNames, cacheService.getCachedFileNames(id));
        assertEquals(updatedDocIds, cacheService.getCachedDocIds(id));
    }

    // =====================================================================
    // appendDocumentTexts — ConcurrentHashMap.compute (не synchronized)
    // =====================================================================

    @Test
    void testAppendDocumentTexts_shouldAppendToExisting() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        List<String> newTexts = List.of("дополнительный текст");
        int total = cacheService.appendDocumentTexts(id, newTexts, List.of("extra.pdf"), List.of("doc-003"));

        assertEquals(3, total);
        assertEquals(3, cacheService.getCachedDocumentTexts(id).size());
        assertEquals("дополнительный текст", cacheService.getCachedDocumentTexts(id).get(2));
    }

    @Test
    void testAppendDocumentTexts_withEmptyCache_createsNew() {
        List<String> newTexts = List.of("первый текст");
        int total = cacheService.appendDocumentTexts(id, newTexts, List.of("first.pdf"), List.of("doc-001"));

        assertEquals(1, total);
        assertEquals(newTexts, cacheService.getCachedDocumentTexts(id));
    }

    @Test
    void testAppendDocumentTexts_notBlocked() {
        // Проверяем, что метод не использует synchronized (использует compute)
        // — при параллельном доступе не возникает deadlock
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        ExecutorService executor = Executors.newFixedThreadPool(4);
        CountDownLatch latch = new CountDownLatch(5);
        AtomicInteger errors = new AtomicInteger(0);

        for (int i = 0; i < 5; i++) {
            int idx = i;
            executor.submit(() ->
                    appendAndCountdown(id, idx, latch, errors));
        }

        try {
            assertTrue(latch.await(5, TimeUnit.SECONDS), "Все параллельные append должны завершиться");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        assertEquals(0, errors.get(), "Не должно быть ошибок при параллельном append");
        executor.shutdownNow();
    }

    /**
     * Выполняет {@link DocsTextCacheService#appendDocumentTexts} в параллельном потоке
     * и уменьшает {@link CountDownLatch}. Вынесен в отдельный метод, чтобы избежать
     * вложенных {@code try} в {@code try}, запрещённых checkstyle.
     */
    private void appendAndCountdown(UUID uuid, int idx, CountDownLatch latch, AtomicInteger errors) {
        try {
            cacheService.appendDocumentTexts(uuid,
                    List.of("параллельный текст " + idx),
                    List.of("file" + idx + ".pdf"),
                    List.of("doc-" + (100 + idx)));
        } catch (Exception e) {
            errors.incrementAndGet();
        } finally {
            latch.countDown();
        }
    }

    @Test
    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    void uploadingScenarioSurvivesTtlEviction() throws InterruptedException {
        // Комплект 4: вторая партия сканов разбиралась 18 минут, первая (форма, критерии) устарела по TTL 10 минут
        ReflectionTestUtils.setField(cacheService, "ttlMinutes", 0);
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.markUploading(id);
        Thread.sleep(5);

        cacheService.evictStaleEntries();
        assertEquals(fileNames, cacheService.getCachedFileNames(id));

        cacheService.unmarkUploading(id);
        Thread.sleep(5);
        cacheService.evictStaleEntries();
        assertTrue(cacheService.getCachedFileNames(id).isEmpty());
    }

    @Test
    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    void touchProlongsEntriesWithoutReading() throws InterruptedException {
        // TTL 0: запись устаревает при первом же обходе; помеченная загрузкой — нет, а touch чужого id ничего не ломает
        ReflectionTestUtils.setField(cacheService, "ttlMinutes", 0);
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.touch(UUID.randomUUID());
        cacheService.markUploading(id);
        Thread.sleep(5);

        cacheService.evictStaleEntries();
        assertEquals(documentTexts, cacheService.getCachedDocumentTexts(id));
        assertEquals(docIds, cacheService.getCachedDocIds(id));
    }

    // =====================================================================
    // scenarioKey — изоляция документов общего сценария по пользователю
    // =====================================================================

    @Test
    void scenarioKey_sameScenarioDifferentUsers_differ() {
        assertNotEquals(DocsTextCacheService.scenarioKey(id, "USER1"),
                DocsTextCacheService.scenarioKey(id, "USER2"));
    }

    @Test
    void scenarioKey_differentScenariosSameUser_differ() {
        assertNotEquals(DocsTextCacheService.scenarioKey(id, "USER1"),
                DocsTextCacheService.scenarioKey(UUID.randomUUID(), "USER1"));
    }

    @Test
    void scenarioKey_sameInput_isStable() {
        UUID scenarioId = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");
        assertEquals(DocsTextCacheService.scenarioKey(scenarioId, "USER1"),
                DocsTextCacheService.scenarioKey(UUID.fromString("123e4567-e89b-12d3-a456-426614174000"), "USER1"));
    }

    @Test
    void scenarioKey_nullEmptyAndAnonymous_areOneUser() {
        // HTTP без X-UserId даёт null/«anonymous», WebSocket с пустым заголовком — пустую строку
        UUID anonymousKey = DocsTextCacheService.scenarioKey(id, "anonymous");
        assertEquals(anonymousKey, DocsTextCacheService.scenarioKey(id, null));
        assertEquals(anonymousKey, DocsTextCacheService.scenarioKey(id, ""));
    }

    @Test
    void scenarioKey_differsFromScenarioId() {
        // ключ пользователя не совпадает с «голым» идентификатором сценария (старый общий ключ)
        assertNotEquals(id, DocsTextCacheService.scenarioKey(id, "USER1"));
        assertNotEquals(id, DocsTextCacheService.scenarioKey(id, null));
    }

    @Test
    void scenarioKey_isolatesDocumentsOfUsers() {
        // два пользователя одного общего сценария: догрузка, чтение и очистка не пересекаются
        UUID keyA = DocsTextCacheService.scenarioKey(id, "USER1");
        UUID keyB = DocsTextCacheService.scenarioKey(id, "USER2");
        cacheService.appendDocumentTexts(keyA, List.of("текст A"), List.of("a.pdf"), List.of());
        cacheService.appendDocumentTexts(keyB, List.of("текст B"), List.of("b.pdf"), List.of());

        assertEquals(List.of("текст A"), cacheService.getCachedDocumentTexts(keyA));
        assertEquals(List.of("a.pdf"), cacheService.getCachedFileNames(keyA));
        assertEquals(List.of("b.pdf"), cacheService.getCachedFileNames(keyB));
        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());

        cacheService.clearCache(keyB);
        assertTrue(cacheService.getCachedFileNames(keyB).isEmpty());
        assertEquals(List.of("a.pdf"), cacheService.getCachedFileNames(keyA));
    }

    @Test
    @SuppressWarnings("java:S2925")
    void scenarioKey_uploadingMarkProtectsOnlyOwnUser() throws InterruptedException {
        // пометка загрузки одного пользователя не удерживает от TTL документы другого
        ReflectionTestUtils.setField(cacheService, "ttlMinutes", 0);
        UUID keyA = DocsTextCacheService.scenarioKey(id, "USER1");
        UUID keyB = DocsTextCacheService.scenarioKey(id, "USER2");
        cacheService.appendDocumentTexts(keyA, List.of("текст A"), List.of("a.pdf"), List.of());
        cacheService.appendDocumentTexts(keyB, List.of("текст B"), List.of("b.pdf"), List.of());
        cacheService.markUploading(keyA);
        Thread.sleep(5);

        cacheService.evictStaleEntries();
        assertEquals(List.of("a.pdf"), cacheService.getCachedFileNames(keyA));
        assertTrue(cacheService.getCachedFileNames(keyB).isEmpty());
    }

    @Test
    @SuppressWarnings("java:S2925")
    void maxSizeEviction_skipsScenarioKeyUnderUpload() throws InterruptedException {
        // USER1 догружает документы сценария; загрузка в диалог другого пользователя вытесняет не их, а следующую по давности запись
        ReflectionTestUtils.setField(cacheService, "maxSize", 2);
        UUID uploadingKey = DocsTextCacheService.scenarioKey(id, "USER1");
        UUID oldConversation = UUID.randomUUID();
        UUID newConversation = UUID.randomUUID();
        cacheService.appendDocumentTexts(uploadingKey, List.of("текст A"), List.of("a.pdf"), List.of());
        cacheService.markUploading(uploadingKey);
        Thread.sleep(2);
        cacheService.cacheDocumentTexts(oldConversation, documentTexts, fileNames, docIds);
        Thread.sleep(2);

        cacheService.cacheDocumentTexts(newConversation, documentTexts, fileNames, docIds);

        assertEquals(List.of("текст A"), cacheService.getCachedDocumentTexts(uploadingKey));
        assertEquals(List.of("a.pdf"), cacheService.getCachedFileNames(uploadingKey));
        assertTrue(cacheService.getCachedDocumentTexts(oldConversation).isEmpty());
        assertEquals(fileNames, cacheService.getCachedFileNames(newConversation));
    }

    @Test
    @SuppressWarnings("java:S2925")
    void maxSizeEviction_removesSameKeyFromAllMaps() throws InterruptedException {
        // давность записей в картах разная (тексты A и имена B читались позже), но вытесняется один ключ целиком
        ReflectionTestUtils.setField(cacheService, "maxSize", 2);
        UUID first = UUID.randomUUID();
        UUID second = UUID.randomUUID();
        cacheService.cacheDocumentTexts(first, documentTexts, fileNames, docIds);
        Thread.sleep(2);
        cacheService.cacheDocumentTexts(second, List.of("текст B"), List.of("b.pdf"), List.of("doc-b"));
        Thread.sleep(2);
        cacheService.getCachedDocumentTexts(first);
        cacheService.getCachedFileNames(second);
        Thread.sleep(2);

        cacheService.cacheDocumentTexts(UUID.randomUUID(), documentTexts, fileNames, docIds);

        assertEquals(documentTexts, cacheService.getCachedDocumentTexts(first));
        assertEquals(fileNames, cacheService.getCachedFileNames(first));
        assertEquals(docIds, cacheService.getCachedDocIds(first));
        assertTrue(cacheService.getCachedDocumentTexts(second).isEmpty());
        assertTrue(cacheService.getCachedFileNames(second).isEmpty());
        assertTrue(cacheService.getCachedDocIds(second).isEmpty());
    }

    // =====================================================================
    // getCachedDocuments — снимок документов при приёме команды прогона
    // =====================================================================

    @Test
    void getCachedDocuments_returnsTextsAndNamesOfKey() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        var snapshot = cacheService.getCachedDocuments(id).orElseThrow();

        assertEquals(documentTexts, snapshot.texts());
        assertEquals(fileNames, snapshot.fileNames());
    }

    @Test
    void getCachedDocuments_withoutCache_returnsEmptyOptional() {
        assertTrue(cacheService.getCachedDocuments(id).isEmpty());
    }

    @Test
    void getCachedDocuments_laterUploadOrClear_doesNotChangeSnapshot() {
        // прогон принят со снимком: загрузка следующей партии и очистка кэша второй вкладкой его не меняют
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        var snapshot = cacheService.getCachedDocuments(id).orElseThrow();

        cacheService.appendDocumentTexts(id, List.of("текст партии 2"), List.of("партия2.pdf"), List.of());
        cacheService.clearCache(id);

        assertEquals(documentTexts, snapshot.texts());
        assertEquals(fileNames, snapshot.fileNames());
        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
    }

    @Test
    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    void getCachedDocuments_snapshotSurvivesTtlEviction() throws InterruptedException {
        // прогон ждал в очереди дольше TTL: снимок, снятый при приёме команды, не обнуляется
        ReflectionTestUtils.setField(cacheService, "ttlMinutes", 0);
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        var snapshot = cacheService.getCachedDocuments(id).orElseThrow();
        Thread.sleep(5);

        cacheService.evictStaleEntries();

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertEquals(documentTexts, snapshot.texts());
        assertEquals(fileNames, snapshot.fileNames());
    }

    @Test
    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    void unmarkUploading_ofOneTask_keepsPinOfAnother() throws InterruptedException {
        // синхронная и фоновая загрузки одного ключа: завершение первой не снимает защиту от TTL второй
        ReflectionTestUtils.setField(cacheService, "ttlMinutes", 0);
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.markUploading(id);
        cacheService.markUploading(id);

        cacheService.unmarkUploading(id);
        Thread.sleep(5);
        cacheService.evictStaleEntries();
        assertEquals(fileNames, cacheService.getCachedFileNames(id));

        cacheService.unmarkUploading(id);
        Thread.sleep(5);
        cacheService.evictStaleEntries();
        assertTrue(cacheService.getCachedFileNames(id).isEmpty());
    }

    @Test
    void unmarkUploading_withoutMark_doesNotThrow() {
        assertDoesNotThrow(() -> cacheService.unmarkUploading(id));
    }

    @Test
    @SuppressWarnings("java:S2925")
    void appendDocumentTexts_respectsMaxSize_evictingOldestEntry() throws InterruptedException {
        // догрузка обходила лимит maxSize и кэш рос без предела
        ReflectionTestUtils.setField(cacheService, "maxSize", 1);
        UUID first = UUID.randomUUID();
        UUID second = UUID.randomUUID();
        cacheService.cacheDocumentTexts(first, documentTexts, fileNames, docIds);
        Thread.sleep(2);

        cacheService.appendDocumentTexts(second, List.of("текст B"), List.of("b.pdf"), List.of());

        assertTrue(cacheService.getCachedDocumentTexts(first).isEmpty());
        assertTrue(cacheService.getCachedFileNames(first).isEmpty());
        assertEquals(List.of("текст B"), cacheService.getCachedDocumentTexts(second));
    }

    @Test
    void appendDocumentTexts_toExistingKey_doesNotEvictItself() {
        ReflectionTestUtils.setField(cacheService, "maxSize", 1);
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        int total = cacheService.appendDocumentTexts(id, List.of("текст C"), List.of("c.pdf"), List.of());

        assertEquals(3, total);
        assertEquals(List.of("текст документа 1", "текст документа 2", "текст C"), cacheService.getCachedDocumentTexts(id));
    }

    // =====================================================================
    // corp23 cache-1/concurrency-5: предел объёма кэша, память о вытесненных ключах
    // =====================================================================

    @Test
    @SuppressWarnings("java:S2925")
    void volumeLimit_evictsOldestOtherKey_andRemembersIt() throws InterruptedException {
        // предел 10 символов: третья запись не помещается — вытесняется самая давняя по обращению запись другого ключа
        ReflectionTestUtils.setField(cacheService, "maxTotalChars", 10L);
        UUID first = UUID.randomUUID();
        UUID second = UUID.randomUUID();
        UUID third = UUID.randomUUID();
        cacheService.cacheDocumentTexts(first, List.of("1234"), List.of("a.pdf"), List.of());
        Thread.sleep(2);
        cacheService.cacheDocumentTexts(second, List.of("1234"), List.of("b.pdf"), List.of());
        Thread.sleep(2);
        cacheService.getCachedDocumentTexts(first);
        Thread.sleep(2);

        cacheService.cacheDocumentTexts(third, List.of("12345"), List.of("c.pdf"), List.of());

        assertTrue(cacheService.getCachedDocumentTexts(second).isEmpty(), "давняя запись другого ключа не вытеснена");
        assertTrue(cacheService.getCachedFileNames(second).isEmpty());
        assertTrue(cacheService.isEvicted(second), "вытесненный ключ не запомнен");
        assertEquals(List.of("1234"), cacheService.getCachedDocumentTexts(first));
        assertEquals(List.of("12345"), cacheService.getCachedDocumentTexts(third));
        assertFalse(cacheService.isEvicted(first));
        assertFalse(cacheService.isEvicted(third));
    }

    @Test
    void volumeLimit_appendCountsExistingEntry_andSparesUploadingAndOwnKey() {
        // догрузка: собственная запись ключа и запись, занятую загрузкой, вытеснять нельзя — запись принимается сверх предела
        ReflectionTestUtils.setField(cacheService, "maxTotalChars", 6L);
        UUID uploadingKey = UUID.randomUUID();
        cacheService.cacheDocumentTexts(uploadingKey, List.of("1234"), List.of("u.pdf"), List.of());
        cacheService.markUploading(uploadingKey);
        cacheService.appendDocumentTexts(id, List.of("12"), List.of("a.pdf"), List.of());

        int total = cacheService.appendDocumentTexts(id, List.of("345"), List.of("b.pdf"), List.of());

        assertEquals(2, total);
        assertEquals(List.of("12", "345"), cacheService.getCachedDocumentTexts(id));
        assertEquals(List.of("1234"), cacheService.getCachedDocumentTexts(uploadingKey));
        assertFalse(cacheService.isEvicted(uploadingKey));
        assertFalse(cacheService.isEvicted(id));
    }

    @Test
    @SuppressWarnings("java:S2925")
    void volumeLimit_nextWriteEvictsIdleKeyOnceUploadFinished() throws InterruptedException {
        // после снятия пометки загрузки та же запись становится кандидатом на вытеснение по объёму
        ReflectionTestUtils.setField(cacheService, "maxTotalChars", 6L);
        UUID idle = UUID.randomUUID();
        cacheService.cacheDocumentTexts(idle, List.of("1234"), List.of("u.pdf"), List.of());
        cacheService.markUploading(idle);
        cacheService.unmarkUploading(idle);
        Thread.sleep(2);

        cacheService.cacheDocumentTexts(id, List.of("12345"), List.of("a.pdf"), List.of());

        assertTrue(cacheService.getCachedDocumentTexts(idle).isEmpty());
        assertTrue(cacheService.isEvicted(idle));
        assertEquals(List.of("12345"), cacheService.getCachedDocumentTexts(id));
    }

    @Test
    void volumeLimit_zero_meansNoLimit() {
        ReflectionTestUtils.setField(cacheService, "maxTotalChars", 0L);
        UUID other = UUID.randomUUID();
        cacheService.cacheDocumentTexts(other, List.of("ж".repeat(1000)), List.of("a.pdf"), List.of());

        cacheService.cacheDocumentTexts(id, List.of("ж".repeat(1000)), List.of("b.pdf"), List.of());

        assertEquals(1, cacheService.getCachedDocumentTexts(other).size());
        assertEquals(1, cacheService.getCachedDocumentTexts(id).size());
    }

    @Test
    @SuppressWarnings("java:S2925")
    void ttlEviction_marksKeyEvicted_untilNewUploadOrExplicitClear() throws InterruptedException {
        // документы были и устарели по TTL — ключ помечен (запуск прогона отклоняется); новая загрузка снимает пометку
        ReflectionTestUtils.setField(cacheService, "ttlMinutes", 0);
        assertFalse(cacheService.isEvicted(id), "ключ без загрузок не считается устаревшим");
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        Thread.sleep(5);

        cacheService.evictStaleEntries();

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertTrue(cacheService.isEvicted(id));
        cacheService.appendDocumentTexts(id, List.of("новая партия"), List.of("n.pdf"), List.of());
        assertFalse(cacheService.isEvicted(id));
        Thread.sleep(5);
        cacheService.evictStaleEntries();
        assertTrue(cacheService.isEvicted(id));
        cacheService.clearCache(id);
        assertFalse(cacheService.isEvicted(id), "явная очистка — не «документы устарели»");
    }

    @Test
    @SuppressWarnings("java:S2925")
    void maxSizeEviction_marksEvictedKey() throws InterruptedException {
        ReflectionTestUtils.setField(cacheService, "maxSize", 1);
        UUID first = UUID.randomUUID();
        cacheService.cacheDocumentTexts(first, documentTexts, fileNames, docIds);
        Thread.sleep(2);

        cacheService.cacheDocumentTexts(id, List.of("текст B"), List.of("b.pdf"), List.of());

        assertTrue(cacheService.isEvicted(first));
        assertFalse(cacheService.isEvicted(id));
    }

    @Test
    void settings_defaultsAndKeys_areWiredBySpring() {
        // имена ключей cache.* и умолчания: TTL 12 часов (запасной), 200 записей, 300 млн символов
        try (var context = new AnnotationConfigApplicationContext()) {
            context.registerBean(PropertySourcesPlaceholderConfigurer.class);
            context.registerBean(DocsTextCacheService.class);
            context.refresh();
            DocsTextCacheService springService = context.getBean(DocsTextCacheService.class);

            assertEquals(720, ReflectionTestUtils.getField(springService, "ttlMinutes"));
            assertEquals(200, ReflectionTestUtils.getField(springService, "maxSize"));
            assertEquals(300_000_000L, ReflectionTestUtils.getField(springService, "maxTotalChars"));
        }
        try (var context = new AnnotationConfigApplicationContext()) {
            context.getEnvironment().getPropertySources().addFirst(new MapPropertySource("тест", Map.of(
                    "cache.ttl-minutes", "5", "cache.max-size", "3", "cache.max-total-chars", "7")));
            context.registerBean(PropertySourcesPlaceholderConfigurer.class);
            context.registerBean(DocsTextCacheService.class);
            context.refresh();
            DocsTextCacheService springService = context.getBean(DocsTextCacheService.class);

            assertEquals(5, ReflectionTestUtils.getField(springService, "ttlMinutes"));
            assertEquals(3, ReflectionTestUtils.getField(springService, "maxSize"));
            assertEquals(7L, ReflectionTestUtils.getField(springService, "maxTotalChars"));
        }
    }

    @Test
    void applicationYaml_declaresCacheKeysWithEnvAndDefaults() throws IOException {
        var environment = new StandardEnvironment();
        for (PropertySource<?> source : new YamlPropertySourceLoader().load("application",
                new ClassPathResource("application.yaml"))) {
            environment.getPropertySources().addLast(source);
        }
        Map<String, String> expected = Map.of(
                "cache.max-size", "${DOCS_CACHE_MAX_SIZE:200}",
                "cache.max-total-chars", "${DOCS_CACHE_MAX_TOTAL_CHARS:300000000}",
                "cache.ttl-minutes", "${DOCS_CACHE_TTL_MINUTES:720}",
                "cache.eviction-rate-ms", "${DOCS_CACHE_EVICTION_RATE_MS:60000}");
        for (var entry : expected.entrySet()) {
            Object raw = null;
            for (PropertySource<?> source : environment.getPropertySources()) {
                Object value = source.getProperty(entry.getKey());
                if (value != null) {
                    raw = value;
                    break;
                }
            }
            assertEquals(entry.getValue(), String.valueOf(raw), entry.getKey());
        }
        assertEquals("720", environment.getProperty("cache.ttl-minutes"));
    }
}
