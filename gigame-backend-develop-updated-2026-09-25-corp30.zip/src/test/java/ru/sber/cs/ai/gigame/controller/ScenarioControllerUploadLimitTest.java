package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.web.reactive.ReactiveMultipartAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.exception.FileTooLargeException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.DocumentText;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Загрузка файла больше лимитов multipart WebFlux: 413 с {@link ErrorResponse} и понятным текстом вместо 500
 * «Внутренняя ошибка сервера» (архив комплекта 55,5 МБ при пределе части 50 МБ) — и в синхронном, и в асинхронном
 * режиме. Лимиты уменьшены: часть до 1 МБ, в памяти до 64 КБ, не больше 4 частей. Прочие пределы тела (буфер кодека
 * JSON, поле формы) — тоже 413, но с текстом про тело запроса, а не про файл и архив.
 */
@WebFluxTest(controllers = ScenarioController.class, properties = {
        "spring.webflux.multipart.max-in-memory-size=64KB",
        "spring.webflux.multipart.max-disk-usage-per-part=1MB",
        "spring.webflux.multipart.max-parts=4"})
@ImportAutoConfiguration(ReactiveMultipartAutoConfiguration.class)
@SuppressWarnings("unused")
class ScenarioControllerUploadLimitTest {

    private static final String USER = "USER123";

    private static final int MEBIBYTE = 1024 * 1024;

    private static final String TOO_LARGE_TEXT =
            "Файл больше допустимого размера 1 МБ — разделите архив на части или загрузите документы по отдельности";

    @MockitoBean
    private DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ScenarioService scenarioService;
    @MockitoBean
    private ScenarioEngine scenarioEngine;
    @MockitoBean
    private ScenarioUploadTaskService scenarioUploadTaskService;

    @Test
    void syncUpload_partAboveDiskLimit_returns413_andCacheIsUntouched() {
        ErrorResponse error = postExpecting413("/api/scenarios/{id}/upload", UUID.randomUUID(),
                body(file("архив.zip", MEBIBYTE + MEBIBYTE / 2)));

        assertEquals(TOO_LARGE_TEXT, error.getMessage());
        verify(scenarioService, never()).getScenario(any());
        verify(scenarioService, never()).getDocuments(any(), any());
        verify(docsTextCacheService, never()).clearCache(any());
    }

    @Test
    void asyncUpload_partAboveDiskLimit_returns413_withoutBackgroundTask() {
        ErrorResponse error = postExpecting413("/api/scenarios/{id}/upload?async=true", UUID.randomUUID(),
                body(file("архив.zip", MEBIBYTE + MEBIBYTE / 2)));

        assertEquals(TOO_LARGE_TEXT, error.getMessage());
        verify(scenarioService, never()).readFiles(any());
        verify(scenarioUploadTaskService, never()).start(any(), any(), any(), anyBoolean());
    }

    @Test
    void asyncUpload_fileAboveDocumentLimitInService_returns413WithName() {
        UUID scenarioId = UUID.randomUUID();
        stubScenario(scenarioId);
        when(scenarioService.readFiles(any())).thenThrow(new FileTooLargeException("акт.pdf", 512L * 1024));

        ErrorResponse error = postExpecting413("/api/scenarios/{id}/upload?async=true", scenarioId,
                body(file("акт.pdf", MEBIBYTE / 2 + 1)));

        assertEquals("Файл «акт.pdf» больше допустимого размера 0,5 МБ — разделите архив на части или загрузите "
                + "документы по отдельности", error.getMessage());
        verify(scenarioUploadTaskService, never()).start(any(), any(), any(), anyBoolean());
    }

    @Test
    void syncUpload_tooManyParts_returns413() {
        ErrorResponse error = postExpecting413("/api/scenarios/{id}/upload", UUID.randomUUID(),
                body(file("1.txt", 10), file("2.txt", 10), file("3.txt", 10), file("4.txt", 10), file("5.txt", 10)));

        assertEquals("Слишком много файлов в одном запросе загрузки (больше 4) — загрузите документы несколькими партиями",
                error.getMessage());
        verify(scenarioService, never()).getDocuments(any(), any());
    }

    @Test
    void syncUpload_partWithinDiskLimit_isAccepted() {
        UUID scenarioId = UUID.randomUUID();
        stubScenario(scenarioId);
        when(scenarioService.getDocuments(any(), any())).thenReturn(List.of(new DocumentText("акт.pdf", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(10);

        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", USER)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body(file("акт.pdf", MEBIBYTE - 1024))))
                .exchange()
                .expectStatus().isOk();

        verify(scenarioService).getDocuments(any(), any());
    }

    @Test
    void updateScenario_jsonAboveCodecLimit_returns413WithBodyText_notFileText() {
        // PUT сценария с JSON 400 КБ: предел кодека spring.codec.max-in-memory-size (по умолчанию 256 КБ)
        String json = "{\"name\":\"Сценарий\",\"description\":\"" + "x".repeat(400 * 1024) + "\"}";

        ErrorResponse error = expect413(webClient.put()
                .uri("/api/scenarios/{id}", UUID.randomUUID())
                .header("X-UserId", USER)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(json));

        assertEquals("Тело запроса больше допустимого размера 256 КБ", error.getMessage());
        verify(scenarioService, never()).updateScenario(any(), any(), any(), any(), any());
    }

    @Test
    void syncUpload_formFieldAboveMemoryLimit_returns413WithBodyText_notFileText() {
        MultiValueMap<String, HttpEntity<?>> body = body(file("акт.pdf", 10));
        body.add("comment", new HttpEntity<>("x".repeat(100 * 1024)));

        ErrorResponse error = postExpecting413("/api/scenarios/{id}/upload", UUID.randomUUID(), body);

        assertEquals("Тело запроса больше допустимого размера 64 КБ", error.getMessage());
        verify(scenarioService, never()).getDocuments(any(), any());
    }

    private ErrorResponse postExpecting413(String uri, UUID scenarioId, MultiValueMap<String, HttpEntity<?>> body) {
        return expect413(webClient.post()
                .uri(uri, scenarioId)
                .header("X-UserId", USER)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body)));
    }

    private static ErrorResponse expect413(WebTestClient.RequestHeadersSpec<?> request) {
        ErrorResponse error = request
                .exchange()
                .expectStatus().isEqualTo(413)
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ErrorResponse.class)
                .returnResult()
                .getResponseBody();
        assertNotNull(error);
        assertEquals(413, error.getStatusCode());
        assertEquals("Payload Too Large", error.getError());
        return error;
    }

    private void stubScenario(UUID scenarioId) {
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(scenarioId, "Сценарий", "Описание", null, null,
                        new GraphDataDto(List.of(), List.of())));
    }

    private static HttpEntity<?> file(String filename, int size) {
        ByteArrayResource resource = new ByteArrayResource(new byte[size]) {
            @Override
            public String getFilename() {
                return filename;
            }
        };
        LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Content-Type", "application/octet-stream");
        return new HttpEntity<>(resource, headers);
    }

    private static MultiValueMap<String, HttpEntity<?>> body(HttpEntity<?>... files) {
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (HttpEntity<?> part : files) {
            body.add("files", part);
        }
        return body;
    }
}
