package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Отсечка OOXML-бомб до POI на общем пути ({@link DocumentService#rejectOoxmlBomb}, {@link DocumentService#extractText}):
 * предел распакованной записи, коэффициент сжатия «толстого» docx, легитимные документы и не-OOXML файлы.
 */
class DocumentServiceOoxmlBombTest {

    private final DocumentService service = new DocumentService(null, null, null);

    private static byte[] zipOf(Map<String, byte[]> entries) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            for (var e : entries.entrySet()) {
                zos.putNextEntry(new ZipEntry(e.getKey()));
                zos.write(e.getValue());
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    @Test
    void entryAboveSizeLimitIsRejectedBeforePoiOnChatAndKbPath() throws IOException {
        ReflectionTestUtils.setField(service, "maxOoxmlEntryMb", 1);
        byte[] bomb = zipOf(Map.of("word/document.xml", new byte[2 * 1024 * 1024]));

        FileException e = assertThrows(FileException.class, () -> service.rejectOoxmlBomb("бомба.docx", "docx", bomb));

        assertTrue(e.getMessage().contains("распаковывается более чем в 1 МБ"), e.getMessage());
        // путь диалога и базы знаний (extractText) раньше отдавал такой файл в POI напрямую
        FileException chat = assertThrows(FileException.class, () -> service.extractText("бомба.docx", "docx", bomb));
        assertTrue(chat.getMessage().contains("распаковывается более чем в 1 МБ"), chat.getMessage());
    }

    @Test
    void fatDocxCompressedBeyondRatioIsRejected() throws IOException {
        // «толстый» docx: мегабайты нулей сжимаются в килобайты (сильнее x100) — предел записи не сработал бы
        ReflectionTestUtils.setField(service, "minOoxmlInflateRatio", 0.01);
        byte[] fat = zipOf(Map.of("word/document.xml", new byte[4 * 1024 * 1024]));

        FileException e = assertThrows(FileException.class, () -> service.rejectOoxmlBomb("толстый.docx", "docx", fat));

        assertTrue(e.getMessage().contains("похоже на ZIP-бомбу"), e.getMessage());
        assertTrue(e.getMessage().contains("word/document.xml"), e.getMessage());
    }

    @Test
    void legitimateDocumentPassesAndRatioZeroDisablesCheck() throws IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; sb.length() < 600_000; i++) {
            sb.append("Строка ").append(i).append(": соответствует требованиям спецификации\n");
        }
        byte[] legit = zipOf(Map.of("word/document.xml", sb.toString().getBytes(StandardCharsets.UTF_8)));

        assertDoesNotThrow(() -> service.rejectOoxmlBomb("договор.docx", "docx", legit));
        assertDoesNotThrow(() -> service.rejectOoxmlBomb("акт.pdf", "pdf", new byte[]{1, 2, 3}));

        ReflectionTestUtils.setField(service, "minOoxmlInflateRatio", 0.0);
        byte[] fat = zipOf(Map.of("word/document.xml", new byte[4 * 1024 * 1024]));
        assertDoesNotThrow(() -> service.rejectOoxmlBomb("толстый.docx", "docx", fat));
    }
}
