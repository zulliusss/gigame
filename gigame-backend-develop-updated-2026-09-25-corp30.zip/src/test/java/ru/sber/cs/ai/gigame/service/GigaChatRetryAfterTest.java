package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.springframework.ai.retry.NonTransientAiException;
import org.springframework.ai.retry.TransientAiException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RestClientResponseException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Подсказка Retry-After: из заголовков ответа в цепочке причин, из пометки в тексте ошибки, а также
 * обработчик ответов GigaChat, который эту пометку дописывает.
 */
class GigaChatRetryAfterTest {

    @Test
    void readsSecondsFromResponseHeadersInCauseChain() {
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.RETRY_AFTER, "30");
        RestClientResponseException response = new RestClientResponseException("429 Too Many Requests", 429,
                "Too Many Requests", headers, new byte[0], StandardCharsets.UTF_8);

        assertEquals(30_000, GigaChatRetryAfter.millis(new RuntimeException("обёртка", response)));
    }

    @Test
    void readsSecondsFromMarkerInMessage() {
        assertEquals(12_000, GigaChatRetryAfter.millis(new NonTransientAiException("429 - {}; " + GigaChatRetryAfter.MARKER + "12")));
    }

    @Test
    void ignoresDatesAndMissingHeader() {
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.RETRY_AFTER, "Wed, 21 Oct 2026 07:28:00 GMT");
        RestClientResponseException dated = new RestClientResponseException("429", 429, "Too Many Requests",
                headers, new byte[0], StandardCharsets.UTF_8);

        assertEquals(0, GigaChatRetryAfter.millis(dated));
        assertEquals(0, GigaChatRetryAfter.millis(new RuntimeException("429 - {}")));
        assertEquals(0, GigaChatRetryAfter.millis(null));
    }

    @Test
    void errorHandlerAppendsMarkerOnlyFor429WithNumericHeader() throws IOException {
        GigaChatResponseErrorHandler handler = new GigaChatResponseErrorHandler();
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.RETRY_AFTER, "30");
        URI uri = URI.create("https://gigachat");
        ClientHttpResponse limitedResp = response(HttpStatus.TOO_MANY_REQUESTS, "{\"status\":429}", headers);
        ClientHttpResponse plainResp = response(HttpStatus.NOT_FOUND, "{\"status\":404}", new HttpHeaders());
        ClientHttpResponse serverResp = response(HttpStatus.SERVICE_UNAVAILABLE, "down", headers);

        NonTransientAiException limited = assertThrows(NonTransientAiException.class,
                () -> handler.handleError(uri, HttpMethod.POST, limitedResp));
        NonTransientAiException plain = assertThrows(NonTransientAiException.class,
                () -> handler.handleError(uri, HttpMethod.POST, plainResp));
        TransientAiException server = assertThrows(TransientAiException.class,
                () -> handler.handleError(uri, HttpMethod.POST, serverResp));

        assertEquals("429 - {\"status\":429}; " + GigaChatRetryAfter.MARKER + "30", limited.getMessage());
        assertEquals("404 - {\"status\":404}", plain.getMessage());
        assertEquals("503 - down", server.getMessage());
        assertTrue(handler.hasError(response(HttpStatus.BAD_REQUEST, "", new HttpHeaders())));
        assertFalse(handler.hasError(response(HttpStatus.OK, "", new HttpHeaders())));
    }

    private static ClientHttpResponse response(HttpStatus status, String body, HttpHeaders headers) throws IOException {
        ClientHttpResponse response = mock(ClientHttpResponse.class);
        when(response.getStatusCode()).thenReturn(status);
        when(response.getBody()).thenReturn(new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
        when(response.getHeaders()).thenReturn(headers);
        return response;
    }
}
