package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Бюджет контекста агентного цикла: оценка истории, укладка в бюджет с пометками вместо ответов инструментов,
 * разбор 422 «context too long».
 */
class AgentContextBudgetTest {

    @Test
    void budgetInCharsAndTaskShareFollowSettings() {
        AgentContextBudget budget = new AgentContextBudget(100_000, 3.0);

        assertEquals(300_000, budget.maxChars());
        assertEquals(180_000, budget.taskChars());
        assertEquals(34, budget.tokens(100));
        // неверные настройки — умолчания
        assertEquals(AgentContextBudget.defaults().maxChars(), new AgentContextBudget(0, -1).maxChars());
    }

    @Test
    void historyCharsCountTextsToolCallArgumentsAndToolResponses() {
        List<Message> history = new ArrayList<>();
        history.add(new UserMessage("задание"));
        history.add(call("id1", "read_document", "{\"name\":\"a\"}"));
        history.add(toolResponse("id1", "read_document", "текст"));

        assertEquals(7 + 13 + 12 + 13 + 5, AgentContextBudget.historyChars(history));
        ToolCallback tool = mock(ToolCallback.class);
        when(tool.getToolDefinition()).thenReturn(ToolDefinition.builder().name("noop").description("ничего").inputSchema("{}").build());
        assertEquals(4 + 6 + 2, AgentContextBudget.toolChars(List.of(tool)));
        assertEquals(0, AgentContextBudget.toolChars(null));
    }

    @Test
    void fitReplacesOldToolResponsesUntilHistoryFitsAndKeepsLast() {
        List<Message> history = history(3, 5000);
        AgentContextBudget budget = new AgentContextBudget(2000, 3.0);

        int replaced = budget.fit(history, 0, 1);

        // 15 тыс. символов при бюджете 6 тыс.: первые два ответа — пометкой, последний полный
        assertEquals(2, replaced);
        assertEquals(AgentContextBudget.marker("read_document", 5000), responseData(history, 2));
        assertEquals(AgentContextBudget.marker("read_document", 5000), responseData(history, 4));
        assertEquals(5000, responseData(history, 6).length());
        assertTrue(AgentContextBudget.historyChars(history) <= budget.maxChars());
    }

    @Test
    void fitStopsAsSoonAsHistoryFitsAndDoesNothingWithinBudget() {
        List<Message> history = history(3, 5000);

        assertEquals(1, new AgentContextBudget(4000, 3.0).fit(history, 0, 0));
        assertEquals(5000, responseData(history, 4).length());
        assertEquals(0, new AgentContextBudget(100_000, 3.0).fit(history(3, 5000), 0, 0));
        // описания инструментов входят в оценку
        assertEquals(1, new AgentContextBudget(4000, 3.0).fit(history(2, 5000), 3000, 0));
    }

    @Test
    void compressAllReplacesEveryLongResponseAndReportsNothingToCompress() {
        List<Message> history = history(2, 5000);

        assertEquals(2, AgentContextBudget.compressAll(history));
        assertEquals(0, AgentContextBudget.compressAll(history));
        assertEquals(0, AgentContextBudget.compressAll(history(2, 20)));
        assertEquals("{\"note\":\"[результат инструмента усечён: read_document, 5000 симв. — бюджет контекста агента; "
                + "при необходимости вызови инструмент снова]\"}", responseData(history, 2));
    }

    @Test
    void overflowIsParsedFromCauseChain() {
        var error = new GigaChatException("Не удалось выполнить запрос к GigaChat: HTTP 422", new RuntimeException(
                "HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 142410, maximum allowed context is 130048\"}"));

        AgentContextBudget.Overflow overflow = AgentContextBudget.overflow(error);

        assertEquals(new AgentContextBudget.Overflow(142410, 130048), overflow);
        assertEquals(new AgentContextBudget.Overflow(190108, 0), AgentContextBudget.parseOverflow("Invalid params: context too long 190108"));
        assertEquals(new AgentContextBudget.Overflow(0, 0), AgentContextBudget.parseOverflow("Invalid params: context too long"));
        assertNull(AgentContextBudget.overflow(new RuntimeException("HTTP 413 - Tokens limit exceeded for index 0")));
        assertNull(AgentContextBudget.parseOverflow(null));
    }

    private static List<Message> history(int rounds, int responseChars) {
        List<Message> history = new ArrayList<>();
        history.add(new UserMessage("задание"));
        for (int i = 0; i < rounds; i++) {
            history.add(call("id" + i, "read_document", "{}"));
            history.add(toolResponse("id" + i, "read_document", "Ф".repeat(responseChars)));
        }
        return history;
    }

    private static AssistantMessage call(String id, String name, String arguments) {
        return AssistantMessage.builder().content("")
                .toolCalls(List.of(new AssistantMessage.ToolCall(id, "function", name, arguments))).build();
    }

    private static ToolResponseMessage toolResponse(String id, String name, String data) {
        return ToolResponseMessage.builder().responses(List.of(new ToolResponseMessage.ToolResponse(id, name, data))).build();
    }

    private static String responseData(List<Message> history, int index) {
        return ((ToolResponseMessage) history.get(index)).getResponses().get(0).responseData();
    }
}
