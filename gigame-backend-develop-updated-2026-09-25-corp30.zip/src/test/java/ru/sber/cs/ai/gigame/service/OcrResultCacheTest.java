package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Кэш результатов распознавания по SHA-256 байтов: попадание без модели с пометкой, вытеснение по объёму,
 * отказы и обрывы не кэшируются, кэш с нулевым пределом выключен.
 */
class OcrResultCacheTest {

    private static byte[] bytes(String text) {
        return text.getBytes(StandardCharsets.UTF_8);
    }

    @Test
    void secondRecognitionOfSameBytesComesFromCacheWithMarker() {
        OcrResultCache cache = new OcrResultCache(1000, 24);
        AtomicInteger calls = new AtomicInteger();

        String first = cache.recognize("скан.pdf", bytes("pdf-1"), () -> "текст " + calls.incrementAndGet());
        String second = cache.recognize("копия скана.pdf", bytes("pdf-1"), () -> "текст " + calls.incrementAndGet());
        String other = cache.recognize("другой.pdf", bytes("pdf-2"), () -> "текст " + calls.incrementAndGet());

        assertEquals("текст 1", first);
        assertEquals("текст 1\n" + OcrResultCache.CACHE_MARKER, second);
        assertEquals("текст 2", other);
        assertEquals(2, calls.get());
    }

    @Test
    void leastRecentlyUsedEntriesAreEvictedOverCharLimit() {
        OcrResultCache cache = new OcrResultCache(10, 24);
        cache.put("a", "12345");
        cache.put("b", "1234");
        assertEquals("12345", cache.get("a"));

        cache.put("c", "123");

        assertEquals("12345", cache.get("a"), "к «a» обращались позже — остаётся");
        assertNull(cache.get("b"), "самая давняя запись вытеснена");
        assertEquals("123", cache.get("c"));
        cache.put("d", "12345678901");
        assertNull(cache.get("d"), "текст больше предела не кэшируется");
        assertEquals(2, cache.size());
    }

    @Test
    void refusalsTruncationsAndDisabledCacheAreNotCached() {
        assertFalse(OcrResultCache.cacheable(ScanOcrService.DOC_REFUSED_PREFIX + "скан.pdf» не распознан: отказ"));
        assertFalse(OcrResultCache.cacheable("--- страница 1 ---\nтекст\n[страница 2 не распознана: отказ модели]"));
        assertFalse(OcrResultCache.cacheable("текст" + ScanOcrService.TRUNCATED_MARKER));
        assertFalse(OcrResultCache.cacheable(""));
        assertTrue(OcrResultCache.cacheable(ScanOcrService.OCR_PREFIX + " Документ «скан.pdf»:\n--- страница 1 ---\nтекст"));

        OcrResultCache disabled = new OcrResultCache(0, 24);
        AtomicInteger calls = new AtomicInteger();
        disabled.recognize("скан.pdf", bytes("pdf"), () -> "текст " + calls.incrementAndGet());
        disabled.recognize("скан.pdf", bytes("pdf"), () -> "текст " + calls.incrementAndGet());
        assertEquals(2, calls.get());

        OcrResultCache cache = new OcrResultCache(1000, 24);
        cache.recognize("скан.pdf", bytes("pdf"), () -> ScanOcrService.DOC_REFUSED_PREFIX + "скан.pdf» не распознан");
        assertEquals(0, cache.size());
    }
}
