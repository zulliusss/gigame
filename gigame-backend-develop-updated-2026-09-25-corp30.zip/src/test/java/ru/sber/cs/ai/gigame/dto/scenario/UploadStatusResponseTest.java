package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.config.JacksonConfig;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты DTO статуса фоновой загрузки: ключи строго по схеме
 * UploadStatusResponse (additionalProperties: false) и лимиты значений.
 */
class UploadStatusResponseTest {

    private final ObjectMapper mapper = new JacksonConfig().objectMapper();

    @Test
    void serialization_containsOnlySchemaKeys() throws Exception {
        UploadStatusResponse status = UploadStatusResponse.of("processing", 3, 1,
                List.of("скан.pdf: требуется ручная проверка"), null);

        JsonNode json = mapper.readTree(mapper.writeValueAsString(status));

        Set<String> keys = new HashSet<>();
        json.fieldNames().forEachRemaining(keys::add);
        assertEquals(Set.of("status", "files", "documents", "warnings", "error"), keys);
        assertEquals("processing", json.get("status").asText());
        assertEquals(3, json.get("files").asInt());
        assertEquals(1, json.get("documents").asInt());
        assertEquals("скан.pdf: требуется ручная проверка", json.get("warnings").get(0).asText());
        assertEquals("", json.get("error").asText());
    }

    @Test
    void of_clampsNumbersToSchemaRange() {
        UploadStatusResponse over = UploadStatusResponse.of("done", 150, 1500, List.of(), "");
        UploadStatusResponse negative = UploadStatusResponse.of("done", -1, -1, null, "");

        assertEquals(UploadStatusResponse.MAX_FILES, over.files());
        assertEquals(UploadStatusResponse.MAX_DOCUMENTS, over.documents());
        assertEquals(0, negative.files());
        assertEquals(0, negative.documents());
        assertEquals(List.of(), negative.warnings());
    }

    @Test
    void of_limitsWarningsCountAndLength_keepingFirst() {
        List<String> warnings = new ArrayList<>();
        warnings.add("длинное: " + "ы".repeat(2000));
        for (int i = 1; i < 1200; i++) {
            warnings.add("файл" + i + ".pdf: предупреждение");
        }

        UploadStatusResponse status = UploadStatusResponse.of("failed", 100, 0, warnings, "e".repeat(5000));

        assertEquals(UploadStatusResponse.MAX_WARNINGS, status.warnings().size());
        assertEquals(UploadStatusResponse.MAX_TEXT_LENGTH, status.warnings().get(0).length());
        assertTrue(status.warnings().get(0).startsWith("длинное: "));
        assertEquals("файл999.pdf: предупреждение", status.warnings().get(999));
        assertEquals(UploadStatusResponse.MAX_TEXT_LENGTH, status.error().length());
        assertTrue(status.error().endsWith("…"));
    }
}
