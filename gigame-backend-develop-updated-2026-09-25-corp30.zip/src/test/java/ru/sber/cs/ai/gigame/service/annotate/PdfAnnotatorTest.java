package ru.sber.cs.ai.gigame.service.annotate;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationHighlight;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationText;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.service.TestPdf;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Разметка PDF: подсветка найденной цитаты с заметкой, заметка на странице скана без текстового слоя.
 */
class PdfAnnotatorTest {

    private static final String LINE = "Requirement to have no active contracts with other banks restricts competition";

    private static Finding finding(int number, String quote) {
        return new Finding(number, "документ.pdf", quote, "ВЫСОКИЙ", "[ВЫСОКИЙ] Суть находки", List.of());
    }

    @Test
    void highlightsQuoteOnPageWithTextLayer() throws IOException {
        byte[] pdf = TestPdf.of("First page of the contract without findings", LINE);

        PdfAnnotator.Result result = PdfAnnotator.annotate(pdf,
                List.of(new PdfAnnotator.Target(finding(1, "contracts with other banks restricts"), null)));

        assertEquals(1, result.annotated());
        assertTrue(result.notes().isEmpty(), String.valueOf(result.notes()));
        try (PDDocument doc = Loader.loadPDF(result.content())) {
            assertTrue(doc.getPage(0).getAnnotations().isEmpty());
            List<PDAnnotation> annotations = doc.getPage(1).getAnnotations();
            PDAnnotationHighlight highlight = (PDAnnotationHighlight) annotations.stream()
                    .filter(PDAnnotationHighlight.class::isInstance).findFirst().orElseThrow();
            assertEquals(8, highlight.getQuadPoints().length);
            assertTrue(highlight.getRectangle().getWidth() > 0);
            assertEquals("[ВЫСОКИЙ] Суть находки", highlight.getContents());
            assertTrue(annotations.stream().anyMatch(PDAnnotationText.class::isInstance));
        }
    }

    @Test
    void scanPageGetsNoteFromOcrPageHint() throws IOException {
        byte[] pdf = TestPdf.of(TestPdf.IMAGE, TestPdf.IMAGE);

        PdfAnnotator.Result result = PdfAnnotator.annotate(pdf,
                List.of(new PdfAnnotator.Target(finding(2, "text recognised only by the OCR model"), 2)));

        assertEquals(1, result.annotated());
        assertTrue(result.notes().get(0).contains("без текстового слоя"));
        try (PDDocument doc = Loader.loadPDF(result.content())) {
            assertTrue(doc.getPage(0).getAnnotations().isEmpty());
            PDAnnotation note = doc.getPage(1).getAnnotations().get(0);
            assertTrue(note instanceof PDAnnotationText);
            assertTrue(note.getContents().contains("без текстового слоя"));
        }
    }

    @Test
    void missingQuoteWithoutPageHintIsReported() throws IOException {
        PdfAnnotator.Result result = PdfAnnotator.annotate(TestPdf.of(LINE),
                List.of(new PdfAnnotator.Target(finding(3, "this phrase is definitely not in the document"), null)));

        assertEquals(0, result.annotated());
        assertTrue(result.notes().get(0).contains("не найдена"));
    }
}
