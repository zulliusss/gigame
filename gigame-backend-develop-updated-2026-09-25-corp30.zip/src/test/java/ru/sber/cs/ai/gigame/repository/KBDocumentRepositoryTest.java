package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class KBDocumentRepositoryTest {

    @Autowired
    private KBDocumentRepository kbDocumentRepository;

    @Autowired
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Autowired
    private DocumentRepository documentRepository;

    @Test
    void testFindById_returnsKBDocument() {
        UUID docId = UUID.randomUUID();

        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("Test KB");
        knowledgeBaseRepository.save(kb);

        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        kbDocumentRepository.save(kbDoc);

        KBDocument found = kbDocumentRepository.findById(kbDoc.getId()).orElse(null);

        assertNotNull(found);
        assertEquals(kb.getId(), found.getKnowledgeBase().getId());
    }

    @Test
    void testFindByKnowledgeBaseId_returnsDocuments() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("Test KB");
        knowledgeBaseRepository.save(kb);

        var document1 = new Document();
        document1.setFilename("file2.txt");
        documentRepository.save(document1);

        var document2 = new Document();
        document2.setFilename("file1.txt");
        documentRepository.save(document2);

        KBDocument doc1 = new KBDocument();
        doc1.setKnowledgeBase(kb);
        doc1.setDocumentId(document1.getId());
        doc1.setDocument(document1);
        kbDocumentRepository.save(doc1);

        KBDocument doc2 = new KBDocument();
        doc2.setKnowledgeBase(kb);
        doc2.setDocumentId(document2.getId());
        doc2.setDocument(document2);
        kbDocumentRepository.save(doc2);

        List<KBDocument> result = kbDocumentRepository.findByKnowledgeBaseId(kb.getId());

        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    void testFindByKnowledgeBaseId_returnsEmptyList_whenNoDocuments() {
        List<KBDocument> result = kbDocumentRepository.findByKnowledgeBaseId(UUID.randomUUID());

        assertTrue(result.isEmpty());
    }

    @Test
    void testFindByKnowledgeBaseIdAndDocumentId_returnsOptional() {

        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("Test KB");
        knowledgeBaseRepository.save(kb);

        var document = new Document();
        document.setFilename("file2.txt");
        documentRepository.save(document);

        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(document.getId());
        kbDoc.setDocument(document);
        kbDocumentRepository.save(kbDoc);

        KBDocument found = kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(kb.getId(), document.getId()).orElse(null);

        assertNotNull(found);
        assertEquals(kb.getId(), found.getKnowledgeBase().getId());
        assertEquals(document.getId(), found.getDocumentId());
    }

    @Test
    void testFindByKnowledgeBaseIdAndDocumentId_returnsEmpty_whenNotFound() {
        var result = kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(UUID.randomUUID(), UUID.randomUUID());

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("Test KB");
        knowledgeBaseRepository.save(kb);

        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(UUID.randomUUID());

        KBDocument saved = kbDocumentRepository.save(kbDoc);
        assertNotNull(saved.getId());

        kbDocumentRepository.delete(saved);
        assertFalse(kbDocumentRepository.findById(saved.getId()).isPresent());
    }

    private KBDocument savedLink(KnowledgeBase kb, String filename, String sha256, String status) {
        Document document = new Document();
        document.setFilename(filename);
        document.setContentSha256(sha256);
        documentRepository.save(document);
        KBDocument link = new KBDocument();
        link.setKnowledgeBase(kb);
        link.setDocumentId(document.getId());
        link.setDocument(document);
        link.setStatus(status);
        return kbDocumentRepository.save(link);
    }

    @Test
    void testFindByStatus_returnsOnlyRequestedStatus() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("Test KB");
        knowledgeBaseRepository.save(kb);
        KBDocument processing = savedLink(kb, "a.txt", "1".repeat(64), "processing");
        savedLink(kb, "b.txt", "2".repeat(64), "ready");

        List<KBDocument> result = kbDocumentRepository.findByStatus("processing");

        assertEquals(1, result.size());
        assertEquals(processing.getId(), result.get(0).getId());
    }

    @Test
    void testFindByKbAndFileContent_matchesNameAndHashWithinKb() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("Test KB");
        knowledgeBaseRepository.save(kb);
        KnowledgeBase other = new KnowledgeBase();
        other.setName("Other KB");
        knowledgeBaseRepository.save(other);
        String sha = "a".repeat(64);
        KBDocument match = savedLink(kb, "act.pdf", sha, "ready");
        savedLink(kb, "act.pdf", "b".repeat(64), "ready");
        savedLink(kb, "other.pdf", sha, "ready");
        savedLink(other, "act.pdf", sha, "ready");

        List<KBDocument> result = kbDocumentRepository.findByKbAndFileContent(kb.getId(), "act.pdf", sha);

        assertEquals(1, result.size());
        assertEquals(match.getId(), result.get(0).getId());
        assertEquals("act.pdf", result.get(0).getDocument().getFilename());
        assertTrue(kbDocumentRepository.findByKbAndFileContent(kb.getId(), "act.pdf", "c".repeat(64)).isEmpty());
    }
}
