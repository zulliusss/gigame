package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Текст ошибки «файл больше допустимого размера»: с именем файла и без него, предел в мегабайтах.
 */
class FileTooLargeExceptionTest {

    private static final long HUNDRED_MB = 100L * 1024 * 1024;

    @Test
    void message_withFileName() {
        FileTooLargeException e = new FileTooLargeException("1.2 Опыт ЭЦС (договора и акты) - 1 ЛОТ.zip", HUNDRED_MB);

        assertEquals(413, e.getStatusCode());
        assertEquals("Файл «1.2 Опыт ЭЦС (договора и акты) - 1 ЛОТ.zip» больше допустимого размера 100 МБ — "
                + "разделите архив на части или загрузите документы по отдельности", e.getMessage());
    }

    @Test
    void message_withoutFileName() {
        String expected = "Файл больше допустимого размера 50 МБ — разделите архив на части или загрузите документы по отдельности";

        assertEquals(expected, FileTooLargeException.message(null, 50L * 1024 * 1024));
        assertEquals(expected, FileTooLargeException.message("  ", 50L * 1024 * 1024));
    }

    @Test
    void megabytes_wholeOrWithTwoDecimals() {
        assertEquals("100", FileTooLargeException.megabytes(HUNDRED_MB));
        assertEquals("1,5", FileTooLargeException.megabytes(3L * 512 * 1024));
        assertEquals("0,01", FileTooLargeException.megabytes(10_240));
        assertEquals("0", FileTooLargeException.megabytes(0));
    }

    @Test
    void kilobytes_wholeOrWithTwoDecimals() {
        assertEquals("256", FileTooLargeException.kilobytes(256L * 1024));
        assertEquals("64", FileTooLargeException.kilobytes(65_536));
        assertEquals("0,5", FileTooLargeException.kilobytes(512));
        assertEquals("1024", FileTooLargeException.kilobytes(1024L * 1024));
    }
}
