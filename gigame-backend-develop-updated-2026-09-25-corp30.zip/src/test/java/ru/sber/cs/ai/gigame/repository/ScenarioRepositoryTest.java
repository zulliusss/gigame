package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class ScenarioRepositoryTest {

    @Autowired
    private ScenarioRepository scenarioRepository;

    @Autowired
    private ScenarioRunRepository scenarioRunRepository;

    @Autowired
    private ScenarioRunStepRepository scenarioRunStepRepository;

    @Test
    void testFindById_returnsScenario() {
        Scenario scenario = new Scenario();
        scenario.setName("Test Scenario");
        scenario.setUserId("user1");
        scenario.setGraphData(Map.of());
        scenarioRepository.save(scenario);

        Scenario found = scenarioRepository.findById(scenario.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("Test Scenario", found.getName());
    }

    @Test
    void testFindAllByOrderByUpdatedAtDesc_returnsSortedScenarios() {
        Scenario s1 = new Scenario();
        s1.setName("First");
        s1.setUserId("user1");
        scenarioRepository.save(s1);

        Scenario s2 = new Scenario();
        s2.setName("Second");
        s2.setUserId("user1");
        scenarioRepository.save(s2);

        List<Scenario> result = scenarioRepository.findAllByUserIdOrderByUpdatedAtDesc("user1");

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Second", result.get(0).getName());
        assertEquals("First", result.get(1).getName());
    }

    @Test
    void testFindAll_returnsEmptyList_whenNoScenarios() {
        List<Scenario> result = scenarioRepository.findAllByUserIdOrderByUpdatedAtDesc("user1");

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        Scenario scenario = new Scenario();
        scenario.setName("To Delete");
        scenario.setUserId("user1");
        scenario.setGraphData(Map.of());

        Scenario saved = scenarioRepository.save(scenario);
        assertNotNull(saved.getId());

        scenarioRepository.delete(saved);
        assertFalse(scenarioRepository.findById(saved.getId()).isPresent());
    }

    @Test
    void testDeleteScenarioById_cascadesRunsAndStepsInDatabase() {
        // без JPA-каскада прогоны и шаги удаляет FK ON DELETE CASCADE в БД одним DELETE сценария
        Scenario scenario = new Scenario();
        scenario.setName("С прогонами");
        scenario.setUserId("user1");
        scenario.setGraphData(Map.of());
        scenarioRepository.save(scenario);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("completed");
        scenarioRunRepository.save(run);
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(run.getId());
        step.setNodeId("node1");
        scenarioRunStepRepository.save(step);

        int deleted = scenarioRepository.deleteScenarioById(scenario.getId());

        assertEquals(1, deleted);
        assertFalse(scenarioRepository.findById(scenario.getId()).isPresent());
        assertFalse(scenarioRunRepository.findById(run.getId()).isPresent());
        assertFalse(scenarioRunStepRepository.findById(step.getId()).isPresent());
    }
}
