package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatModel;
import chat.giga.springai.api.chat.GigaChatApi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.metadata.ChatResponseMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class GigaChatClientTest {

    @Mock
    private ChatModel chatModel;

    @Mock
    private EmbeddingModel embeddingModel;

    @Captor
    private ArgumentCaptor<Prompt> promptCaptor;

    private GigaChatClient gigaChatClient;

    @BeforeEach
    void setUp() {
        gigaChatClient = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(gigaChatClient, "textMaxLength", 800);
        ReflectionTestUtils.setField(gigaChatClient, "batchSize", 50);
    }

    @Test
    void testChatCompletion() {
        AssistantMessage assistantMsg = new AssistantMessage("");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);
        List<Map<String, String>> messages = List.of(
                Map.of("role", "user", "content", "Hello"),
                Map.of("role", "system", "content", "Ты помогаешь людям"),
                Map.of("role", "assistant", "content", "Привет")
        );
        assertDoesNotThrow(() -> gigaChatClient.chatCompletion(messages));
    }

    @Test
    void testChatCompletionStream() {
        AssistantMessage assistantMsg = new AssistantMessage("");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        List<Map<String, String>> messages = List.of(
                Map.of("role", "user", "content", "Hello")
        );

        var result = gigaChatClient.chatCompletionStream(messages);

        assertNotNull(result);
        assertDoesNotThrow(() -> result.collectList().block());
    }

    @Test
    void testGetEmbeddings() {
        EmbeddingResponse embeddingResponse = mock(EmbeddingResponse.class);
        when(embeddingResponse.getResults()).thenReturn(List.of());

        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        List<String> texts = List.of("Test text");

        assertDoesNotThrow(() -> {
            List<float[]> result = gigaChatClient.getEmbeddings(texts);
            assertNotNull(result);
            assertTrue(result.isEmpty());
        });
    }

    @Test
    void testGetEmbeddings_withMultipleBatches() {
        var f = new float[4];
        f[0] = 10.10f;
        f[1] = 30.3f;
        f[2] = 40.60f;
        f[3] = 77.50f;
        var embedding = new Embedding(f, 4);
        EmbeddingResponse embeddingResponse = new EmbeddingResponse(List.of(embedding));
        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        // Create 100 texts to test batching (50 texts per batch, 2 batches)
        List<String> texts = new ArrayList<>(Collections.nCopies(100, "Это тестовая строка"));
        assertDoesNotThrow(() -> {
            List<float[]> result = gigaChatClient.getEmbeddings(texts);
            assertNotNull(result);
            assertEquals(2, result.size());
        });
    }

    @Test
    void testGetEmbeddings_truncatesLongTexts() {
        var f = new float[4];
        f[0] = 10.10f;
        f[1] = 30.3f;
        f[2] = 40.60f;
        f[3] = 77.50f;
        var embedding = new Embedding(f, 4);
        EmbeddingResponse embeddingResponse = new EmbeddingResponse(List.of(embedding));

        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        String longText = "A".repeat(2000);
        List<String> texts = List.of(longText);

        assertDoesNotThrow(() -> {
            List<float[]> result = gigaChatClient.getEmbeddings(texts);
            assertNotNull(result);
            assertEquals(1, result.size());
        });
    }

    @Test
    void testGetEmbeddings_emptyList() {
        var f = new float[0];
        var embedding = new Embedding(f, 0);
        EmbeddingResponse embeddingResponse = new EmbeddingResponse(List.of(embedding));

        lenient().when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddingResponse);

        List<String> texts = List.of();

        List<float[]> result = gigaChatClient.getEmbeddings(texts);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // =====================================================================
    // 3-arg chatCompletion with model/temperature override
    // =====================================================================

    @Test
    void testChatCompletion_withModelOverride() {
        AssistantMessage assistantMsg = new AssistantMessage("Ответ от GigaChat-Pro");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        List<Map<String, String>> messages = List.of(
                Map.of("role", "user", "content", "Hello")
        );

        String result = gigaChatClient.chatCompletion(messages, "GigaChat-Pro", 0.7);

        assertEquals("Ответ от GigaChat-Pro", result);

        verify(chatModel).call(promptCaptor.capture());
        Prompt prompt = promptCaptor.getValue();
        assertNotNull(prompt.getOptions());
    }

    @Test
    void testChatCompletion_withNullModelAndTemp() {
        AssistantMessage assistantMsg = new AssistantMessage("Ответ");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")), null, null);

        assertEquals("Ответ", result);
        verify(chatModel).call(promptCaptor.capture());
        assertNull(promptCaptor.getValue().getOptions());
    }

    // =====================================================================
    // chatCompletionResult — returns ChatResult with text and usage
    // =====================================================================

    @Test
    void testChatCompletionResult_returnsUsage() {
        AssistantMessage assistantMsg = new AssistantMessage("Hi there");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        GigaChatClient.ChatResult result = gigaChatClient.chatCompletionResult(
                List.of(Map.of("role", "user", "content", "Hello")), null, 0.5);

        assertEquals("Hi there", result.text());
        assertNotNull(result.usage());
    }

    // =====================================================================
    // chatCompletionStreamResult — Flux with ChatResult
    // =====================================================================

    @Test
    void testChatCompletionStreamResult_withModelOverride() {
        AssistantMessage assistantMsg = new AssistantMessage("Stream result");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        var flux = gigaChatClient.chatCompletionStreamResult(
                List.of(Map.of("role", "user", "content", "Hi")), "GigaChat-Max", 0.3);

        GigaChatClient.ChatResult result = flux.blockFirst();
        assertNotNull(result);
        assertEquals("Stream result", result.text());
    }

    // =====================================================================
    // safeAttachmentName — static method for file name sanitisation
    // =====================================================================

    @ParameterizedTest
    @CsvSource({
            "отчёт.pdf,        attachment-*.pdf",
            "scan.PDF,         attachment-*.PDF",
            "my document.pdf,  attachment-*.pdf",
            "data/summary.PNG, attachment-*.PNG",
            "/tmp/file.JPEG,   attachment-*.JPEG",
            "noext,            attachment-*",
            "image,            attachment-*",
            ".hidden,          attachment-*.hidden",
            "a.b.c.d.png,      attachment-*.png",
    })
    void testSafeAttachmentName_commonCases(String filename, String expectedPattern) {
        String name = GigaChatClient.safeAttachmentName(filename);
        assertTrue(name.startsWith("attachment-"));
        if (filename.contains(".")) {
            String ext = filename.substring(filename.lastIndexOf('.'));
            assertTrue(name.endsWith(ext.toLowerCase()),
                    "Expected suffix '" + ext.toLowerCase() + "' but got '" + name + "'");
        }
    }

    @Test
    void testSafeAttachmentName_differentInputsSameHash() {
        String name1 = GigaChatClient.safeAttachmentName("report.pdf");
        String name2 = GigaChatClient.safeAttachmentName("REPORT.pdf");
        // different hash because hashCode differs for "report" vs "REPORT"
        assertTrue(name1.endsWith(".pdf"));
        assertTrue(name2.endsWith(".pdf"));
    }

    // =====================================================================
    // Retry logic: transient failures trigger retry
    // =====================================================================

    @Test
    void testChatCompletion_retriesOnTransientServerError() {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 3);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1); // minimal delay

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("503 Service Unavailable"))
                .thenThrow(new RuntimeException("502 Bad Gateway"))
                .thenReturn(createResponse("Success after retry"));

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hello")));

        assertEquals("Success after retry", result);
        verify(chatModel, times(3)).call(any(Prompt.class));
    }

    @Test
    void testChatCompletion_retriesOnRateLimit() {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelay429Millis", 1);

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("429 Too Many Requests"))
                .thenReturn(createResponse("OK after rate limit"));

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("OK after rate limit", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    @Test
    void testChatCompletion_retriesOnTimeout() {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("timed out"))
                .thenReturn(createResponse("OK after timeout"));

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("OK after timeout", result);
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    @Test
    void testChatCompletion_hardTimeout_abortsHangingCallAndRetries() {
        // повисший сетевой вызов (read-timeout не сработал) обязан
        // прерваться страховочным потолком и уйти в retry, а не держать
        // поток узла вечно
        ReflectionTestUtils.setField(gigaChatClient, "callHardTimeoutSeconds", 1L);
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);

        when(chatModel.call(any(Prompt.class)))
                .thenAnswer(inv -> {
                    Thread.sleep(60_000); // NOSONAR java:S2925 — имитация зависшего сетевого вызова; прерывается страховочным таймаутом
                    return createResponse("недостижимо");
                })
                .thenReturn(createResponse("OK after hang"));

        long start = System.currentTimeMillis();
        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("OK after hang", result);
        assertTrue(System.currentTimeMillis() - start < 30_000,
                "страховочный таймаут не сработал — ждали дольше 30 с");
    }

    @Test
    void testLlmCallPool_isBoundedByMaxConcurrent() {
        // пул страховочных вызовов ограничен max(2, 2 × max-concurrent) и создаётся один раз
        ReflectionTestUtils.setField(gigaChatClient, "maxConcurrent", 3);
        ReflectionTestUtils.setField(gigaChatClient, "llmCallPoolSize", 0);

        Object pool = ReflectionTestUtils.invokeMethod(gigaChatClient, "llmCallPool");

        assertInstanceOf(ThreadPoolExecutor.class, pool);
        assertEquals(6, ((ThreadPoolExecutor) pool).getMaximumPoolSize());
        assertSame(pool, ReflectionTestUtils.invokeMethod(gigaChatClient, "llmCallPool"));
        gigaChatClient.shutdownLlmCallPool();
        assertTrue(((ThreadPoolExecutor) pool).isShutdown());
    }

    @Test
    void testLlmCallPool_explicitSizeAndMinimumOfTwo() {
        ReflectionTestUtils.setField(gigaChatClient, "llmCallPoolSize", 4);
        ThreadPoolExecutor explicit = ReflectionTestUtils.invokeMethod(gigaChatClient, "llmCallPool");
        assertNotNull(explicit);
        assertEquals(4, explicit.getMaximumPoolSize());
        gigaChatClient.shutdownLlmCallPool();

        GigaChatClient tiny = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(tiny, "maxConcurrent", 0);
        ThreadPoolExecutor minimal = ReflectionTestUtils.invokeMethod(tiny, "llmCallPool");
        assertNotNull(minimal);
        assertEquals(2, minimal.getMaximumPoolSize());
        tiny.shutdownLlmCallPool();
    }

    @Test
    void testChatCompletion_throwsOnClientError_noRetry() {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 3);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("400 Bad Request"));

        List<Map<String, String>> message = List.of(Map.of("role", "user", "content", "Hi"));

        assertThrows(RuntimeException.class, () ->
                gigaChatClient.chatCompletion(message));

        // Only 1 attempt — 4xx is not retryable
        verify(chatModel, times(1)).call(any(Prompt.class));
    }

    @Test
    void testChatCompletionWithTools_ownLoopExecutesToolAndReturnsFinalText() {
        // раунд 1: модель просит инструмент; раунд 2: финальный текст
        var toolCall = new AssistantMessage.ToolCall("id1", "function",
                "search_documents", "{\"query\":\"НМЦ\"}");
        var withCall = new ChatResponse(List.of(new Generation(
                AssistantMessage.builder().content("").toolCalls(List.of(toolCall)).build())));
        var finalResp = new ChatResponse(List.of(new Generation(
                new AssistantMessage("Итог: 100"))));
        when(chatModel.call(any(Prompt.class))).thenReturn(withCall).thenReturn(finalResp);
        ToolCallback tool = mock(ToolCallback.class);
        var def = mock(org.springframework.ai.tool.definition.ToolDefinition.class);
        when(def.name()).thenReturn("search_documents");
        when(tool.getToolDefinition()).thenReturn(def);
        when(tool.call("{\"query\":\"НМЦ\"}")).thenReturn("{\"hits\":[]}");

        var result = gigaChatClient.chatCompletionWithTools(
                List.of(Map.of("role", "user", "content", "найди НМЦ")),
                List.of(tool), null, null);

        assertEquals("Итог: 100", result.text());
        verify(tool).call("{\"query\":\"НМЦ\"}");
        // второй вызов модели получил историю с ответом инструмента
        ArgumentCaptor<Prompt> prompts = ArgumentCaptor.forClass(Prompt.class);
        verify(chatModel, times(2)).call(prompts.capture());
        assertTrue(prompts.getAllValues().get(1).getInstructions().stream()
                .anyMatch(m -> m instanceof org.springframework.ai.chat.messages.ToolResponseMessage));
    }

    @Test
    void testCompactToolHistory_shrinksOldHeavyResponsesKeepsRecent() {
        java.util.List<org.springframework.ai.chat.messages.Message> history =
                new java.util.ArrayList<>();
        history.add(new UserMessage("задание"));
        for (int i = 0; i < 4; i++) {
            history.add(AssistantMessage.builder().content("").toolCalls(List.of(
                    new AssistantMessage.ToolCall("id" + i, "function", "read_document", "{}")))
                    .build());
            history.add(org.springframework.ai.chat.messages.ToolResponseMessage.builder()
                    .responses(List.of(
                            new org.springframework.ai.chat.messages.ToolResponseMessage.ToolResponse(
                                    "id" + i, "read_document", "Ф".repeat(5000))))
                    .build());
        }

        GigaChatClient.compactToolHistory(history);

        var toolMsgs = history.stream()
                .filter(org.springframework.ai.chat.messages.ToolResponseMessage.class::isInstance)
                .map(org.springframework.ai.chat.messages.ToolResponseMessage.class::cast)
                .toList();
        // старые (первые 2 из 4) сжаты до маркера, последние 2 — полные
        assertTrue(toolMsgs.get(0).getResponses().get(0).responseData().contains("[сжато]"));
        assertTrue(toolMsgs.get(1).getResponses().get(0).responseData().contains("[сжато]"));
        assertEquals(5000, toolMsgs.get(2).getResponses().get(0).responseData().length());
        assertEquals(5000, toolMsgs.get(3).getResponses().get(0).responseData().length());
    }

    @Test
    void testChatCompletion_cancelledRunStopsRetries() {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 5);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("timed out"));
        GigaChatClient.setRunCancelCheck(() -> true);
        List<Map<String, String>> cancelMsg = List.of(Map.of("role", "user", "content", "q"));
        try {
            assertThrows(RuntimeException.class, () -> gigaChatClient.chatCompletion(cancelMsg));
            // остановленный прогон не жжёт бюджет повторов — ровно одна попытка
            verify(chatModel, times(1)).call(any(Prompt.class));
        } finally {
            GigaChatClient.clearRunCancelCheck();
        }
    }

    @Test
    void testChatCompletion_throwsOnExhaustedRetries() {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("503 Service Unavailable"));

        List<Map<String, String>> exhaustedMsg = List.of(Map.of("role", "user", "content", "Hi"));

        assertThrows(RuntimeException.class, () ->
                gigaChatClient.chatCompletion(exhaustedMsg));

        verify(chatModel, times(3)).call(any(Prompt.class));
    }

    // =====================================================================
    // isRateLimited / isTransientFailure — tested via retry behavior
    // =====================================================================

    @ParameterizedTest
    @ValueSource(strings = {
            "429 Too Many Requests",
            "HTTP 429",
    })
    void testRetry_rateLimited(String errorMessage) {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelay429Millis", 1);

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException(errorMessage))
                .thenReturn(createResponse("OK"));

        assertDoesNotThrow(() -> gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi"))));
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "500 Internal Error",
            "502 Bad Gateway",
            "503 Service Unavailable",
            "504 Gateway Timeout",
            "Connection refused",
            "connection reset",
            "Read timed out",
            "timeout exceeded",
    })
    void testRetry_transientFailure(String errorMessage) {
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);

        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException(errorMessage))
                .thenReturn(createResponse("OK"));

        assertDoesNotThrow(() -> gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi"))));
    }

    // =====================================================================
    // Usage capture (begin/end/addCapturedUsage)
    // =====================================================================

    @Test
    void testUsageCapture_beginEndReturnsTokens() {
        GigaChatClient.beginUsageCapture();

        // Simulate adding usage via chatCompletion
        AssistantMessage assistantMsg = new AssistantMessage("response");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "Hi")));

        // With no real usage in the mock, no tokens are captured
        // The frame is still closed cleanly
        assertDoesNotThrow(GigaChatClient::endUsageCapture);
    }

    @Test
    void testUsageCapture_addCapturedUsageWithoutFrame_noError() {
        // Should not throw when there's no frame open
        assertDoesNotThrow(() ->
                GigaChatClient.addCapturedUsage(Map.of("total_tokens", 100)));
    }

    @Test
    void testUsageCapture_endWithoutFrame_returnsNull() {
        Integer result = GigaChatClient.endUsageCapture();
        assertNull(result);
    }

    @Test
    void testUsageCapture_accumulatesAcrossMultipleCalls() {
        GigaChatClient.beginUsageCapture();

        AssistantMessage assistantMsg = new AssistantMessage("response");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        // Two successive calls — no real usage captured from mock, but no exception
        gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "First")));
        gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "Second")));

        assertDoesNotThrow(GigaChatClient::endUsageCapture);
    }

    @Test
    void testUsageCapture_nestedFrames() {
        // Simulate scenario engine with nested sub-scenarios
        GigaChatClient.beginUsageCapture(); // outer frame

        AssistantMessage assistantMsg = new AssistantMessage("response");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        // Inner call
        gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "Inner")));

        // No usage captured from mock, but frame closes cleanly
        assertDoesNotThrow(GigaChatClient::endUsageCapture);
    }

    // =====================================================================
    // getEmbeddings — ошибка пакета отдаётся вызывающему (нулевых векторов нет)
    // =====================================================================

    @Test
    void testGetEmbeddings_throwsOnException() {
        // сетевой сбой повторяется по политике и в конце отдаётся ошибкой: раньше вместо векторов
        // возвращались нули, и документ помечался проиндексированным, оставаясь невидимым для поиска
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 1);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1L);
        when(embeddingModel.call(any(EmbeddingRequest.class)))
                .thenThrow(new RuntimeException("Embedding API error"));

        List<String> texts = List.of("Text1", "Text2");

        GigaChatException ex = assertThrows(GigaChatException.class, () -> gigaChatClient.getEmbeddings(texts));

        assertTrue(ex.getMessage().contains("GigaChat"), ex.getMessage());
    }

    @Test
    void testGetEmbeddings_partialBatchFailureThrows() {
        // First batch succeeds, second fails
        var f1 = new float[]{1.0f, 2.0f};
        Embedding embedding1 = new Embedding(f1, 2);
        EmbeddingResponse successResponse = new EmbeddingResponse(List.of(embedding1));

        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 1);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1L);
        when(embeddingModel.call(any(EmbeddingRequest.class)))
                .thenReturn(successResponse)
                .thenThrow(new RuntimeException("Second batch failed"));

        ReflectionTestUtils.setField(gigaChatClient, "batchSize", 1);

        List<String> texts = List.of("First", "Second");

        // упавший пакет не подменяется нулевыми векторами — ошибка доходит до вызывающего целиком
        assertThrows(GigaChatException.class, () -> gigaChatClient.getEmbeddings(texts));
    }

    // =====================================================================
    // 1-arg chatCompletion via 3-arg delegation
    // =====================================================================

    @Test
    void testChatCompletion_delegatesTo3Arg() {
        AssistantMessage assistantMsg = new AssistantMessage("Delegated");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        String result = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("Delegated", result);
    }

    // =====================================================================
    // chatCompletionStream — basic test with model/temperature
    // =====================================================================

    @Test
    void testChatCompletionStream_withModel() {
        AssistantMessage assistantMsg = new AssistantMessage("Stream model");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        // chatCompletionStream delegates to chatCompletionStreamResult with null model/temperature
        var flux = gigaChatClient.chatCompletionStream(
                List.of(Map.of("role", "user", "content", "Hi")));

        List<String> texts = flux.collectList().block();
        assertNotNull(texts);
        assertEquals(1, texts.size());
        assertEquals("Stream model", texts.get(0));
    }

    // =====================================================================
    // chatCompletionWithFile — file attachment flow
    // =====================================================================

    @Test
    void testChatCompletionWithFile_basicFlow() {
        // Mock GigaChatApi provider for deleteUploadedMedia
        ObjectProvider<GigaChatApi> apiProvider = mock(ObjectProvider.class);
        GigaChatApi mockApi = mock(GigaChatApi.class);
        when(apiProvider.getIfAvailable()).thenReturn(mockApi);

        // Create client with 3-arg constructor
        GigaChatClient client = new GigaChatClient(chatModel, embeddingModel, apiProvider);

        // Mock chat response with file metadata
        AssistantMessage assistantMsg = new AssistantMessage("File content recognized");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        // Set metadata with file upload IDs via ReflectionTestUtils
        ChatResponseMetadata metadata = new ChatResponseMetadata();
        Map<String, Object> metaMap = new HashMap<>();
        metaMap.put(GigaChatModel.UPLOADED_MEDIA_IDS, List.of("file-1", "file-2"));
        ReflectionTestUtils.setField(metadata, "map", metaMap);
        ReflectionTestUtils.setField(chatResponse, "chatResponseMetadata", metadata);

        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        byte[] pdfContent = "Test PDF content".getBytes();
        GigaChatClient.ChatResult result = client.chatCompletionWithFile(
                "Extract text from this PDF", "report.pdf", pdfContent,
                "application/pdf", null, null, null);

        assertNotNull(result);
        assertEquals("File content recognized", result.text());
        verify(mockApi, times(2)).deleteFile(anyString());
    }

    @Test
    void testChatCompletionWithFile_noApiProvider_skipsDelete() {
        // Use 2-arg constructor (no API provider) — deleteUploadedMedia is skipped
        GigaChatClient client = new GigaChatClient(chatModel, embeddingModel);

        AssistantMessage assistantMsg = new AssistantMessage("Response");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        byte[] content = "test".getBytes();
        GigaChatClient.ChatResult result = client.chatCompletionWithFile(
                "Process", "file.txt", content, "text/plain", null, null, null);

        assertNotNull(result);
        assertEquals("Response", result.text());
    }

    @Test
    void testChatCompletionWithFile_withModelAndTemp() {
        ObjectProvider<GigaChatApi> apiProvider = mock(ObjectProvider.class);
        when(apiProvider.getIfAvailable()).thenReturn(null);
        GigaChatClient client = new GigaChatClient(chatModel, embeddingModel, apiProvider);

        AssistantMessage assistantMsg = new AssistantMessage("Custom model response");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        when(chatModel.call(any(Prompt.class))).thenReturn(chatResponse);

        byte[] content = "Test".getBytes();
        GigaChatClient.ChatResult result = client.chatCompletionWithFile(
                "Process", "scan.pdf", content, "application/pdf",
                "GigaChat-Pro", 0.7, 1000);

        assertNotNull(result);
        assertEquals("Custom model response", result.text());
    }

    // =====================================================================
    // safeAttachmentName — edge cases
    // =====================================================================

    @ParameterizedTest
    @CsvSource({
            "report.pdf,                   attachment-*.pdf",
            "scan_with_spaces.pdf,         attachment-*.pdf",
            "кириллица.pdf,                attachment-*.pdf",
            "MY_FILE.PDF,                  attachment-*.PDF",
            "noextension,                   attachment-*",
    })
    void testSafeAttachmentName_generatesCorrectExtension(String filename, String expectedPrefix) {
        String name = GigaChatClient.safeAttachmentName(filename);
        if (filename != null && !filename.isBlank() && filename.contains(".")) {
            String ext = filename.substring(filename.lastIndexOf('.')).toLowerCase();
            assertTrue(name.endsWith(ext), "Expected suffix '" + ext + "' but got '" + name + "'");
        }
    }

    @Test
    void testSafeAttachmentName_convertsToAscii() {
        // Even with non-ASCII input, the output should be lowercase ASCII
        String name = GigaChatClient.safeAttachmentName("Приложение.pdf");
        assertTrue(name.endsWith(".pdf"));
        assertTrue(name.matches("attachment-[a-f0-9]+\\.pdf"),
                "Should match pattern attachment-[a-f0-9]+.pdf but got: " + name);
    }

    // =====================================================================
    // deleteUploadedMedia — tested via ReflectionTestUtils
    // =====================================================================

    @Test
    void testSanitizeToolText_replacesSuperquoteToken() {
        String raw = "{<|superquote|>нмцд_руб<|superquote|>: 161560083}";

        assertEquals("{\"нмцд_руб\": 161560083}", GigaChatClient.sanitizeToolText(raw));
        assertEquals("обычный текст", GigaChatClient.sanitizeToolText("обычный текст"));
        assertEquals(null, GigaChatClient.sanitizeToolText(null));
    }

    @Test
    void testDeleteUploadedMedia_noMetadata_skips() {
        ChatResponse response = new ChatResponse(List.of());
        // No metadata set — should skip without error
        assertDoesNotThrow(() ->
                ReflectionTestUtils.invokeMethod(gigaChatClient, "deleteUploadedMedia", response));
    }

    @Test
    void testDeleteUploadedMedia_withFileIds_deletes() {
        ObjectProvider<GigaChatApi> apiProvider = mock(ObjectProvider.class);
        GigaChatApi mockApi = mock(GigaChatApi.class);
        when(apiProvider.getIfAvailable()).thenReturn(mockApi);
        GigaChatClient client = new GigaChatClient(chatModel, embeddingModel, apiProvider);

        // Create response with metadata containing file IDs
        AssistantMessage assistantMsg = new AssistantMessage("text");
        Generation generation = new Generation(assistantMsg);
        ChatResponse chatResponse = new ChatResponse(List.of(generation));
        ChatResponseMetadata metadata = new ChatResponseMetadata();
        Map<String, Object> metaMap = new HashMap<>();
        metaMap.put(GigaChatModel.UPLOADED_MEDIA_IDS, List.of("file-1"));
        ReflectionTestUtils.setField(metadata, "map", metaMap);
        ReflectionTestUtils.setField(chatResponse, "chatResponseMetadata", metadata);

        assertDoesNotThrow(() ->
                ReflectionTestUtils.invokeMethod(client, "deleteUploadedMedia", chatResponse));
        verify(mockApi).deleteFile("file-1");
    }

    // =====================================================================
    // Helper — creates a ChatResponse with the given text
    // =====================================================================

    private static ChatResponse createResponse(String text) {
        AssistantMessage assistantMsg = new AssistantMessage(text);
        Generation generation = new Generation(assistantMsg);
        return new ChatResponse(List.of(generation));
    }

    @Test
    void continuesTruncatedAnswer() {
        // первый ответ оборван по лимиту длины (finish_reason=length) — клиент дочитывает и склеивает
        var cut = new ChatResponse(List.of(new Generation(new AssistantMessage("[{\"a\":1},"),
                org.springframework.ai.chat.metadata.ChatGenerationMetadata.builder().finishReason("length").build())));
        var rest = new ChatResponse(List.of(new Generation(new AssistantMessage("{\"a\":2}]"),
                org.springframework.ai.chat.metadata.ChatGenerationMetadata.builder().finishReason("stop").build())));
        when(chatModel.call(any(Prompt.class))).thenReturn(cut, rest);

        String text = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "верни JSON")));

        assertEquals("[{\"a\":1},{\"a\":2}]", text);
        org.mockito.Mockito.verify(chatModel, org.mockito.Mockito.times(2)).call(promptCaptor.capture());
        var second = promptCaptor.getAllValues().get(1).getInstructions();
        assertEquals(3, second.size());
        assertTrue(second.get(1).getText().startsWith("[{\"a\":1},"));
        assertTrue(second.get(2).getText().contains("Продолжи ТОЧНО с места обрыва"));
        assertFalse(GigaChatClient.isTruncated(rest));
    }

    @Test
    void rateLimitPausesAndResumesBeyondMaxAttempts() {
        // 429 не считается «попыткой»: шаг ждёт и продолжается, пока не исчерпан суммарный лимит ожидания
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelay429Millis", 1L);
        ReflectionTestUtils.setField(gigaChatClient, "rateLimitMaxDelayMillis", 4L);
        ReflectionTestUtils.setField(gigaChatClient, "rateLimitMaxWaitMillis", 60_000L);
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new RuntimeException("429 Too Many Requests"))
                .thenThrow(new RuntimeException("429 Too Many Requests"))
                .thenThrow(new RuntimeException("429 Too Many Requests"))
                .thenThrow(new RuntimeException("429 Too Many Requests"))
                .thenReturn(createResponse("OK after quota"));

        String result = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "Hi")));

        assertEquals("OK after quota", result);
        verify(chatModel, times(5)).call(any(Prompt.class));
    }

    @Test
    void rateLimitStopsStepWhenTotalWaitExceeded() {
        ReflectionTestUtils.setField(gigaChatClient, "retryDelay429Millis", 10L);
        ReflectionTestUtils.setField(gigaChatClient, "rateLimitMaxDelayMillis", 10L);
        ReflectionTestUtils.setField(gigaChatClient, "rateLimitMaxWaitMillis", 15L);
        when(chatModel.call(any(Prompt.class))).thenThrow(new RuntimeException("429 Too Many Requests"));

        var ex = org.junit.jupiter.api.Assertions.assertThrows(ru.sber.cs.ai.gigame.exception.GigaChatException.class,
                () -> gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "Hi"))));

        assertTrue(ex.getMessage().contains("не восстановился"));
        verify(chatModel, times(2)).call(any(Prompt.class));
    }
}
