package ru.sber.cs.ai.gigame.service.annotate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Склады исходных файлов и артефактов прогона: запись, чтение, очистка ключа, чистка по сроку жизни,
 * предел объёма, одноимённые документы с разным текстом, снимок оригиналов прогона.
 */
class FileStoresTest {

    @TempDir
    Path temp;

    private static byte[] bytes(int size, int fill) {
        byte[] content = new byte[size];
        Arrays.fill(content, (byte) fill);
        return content;
    }

    @Test
    void rawStoreSavesLoadsClearsAndEvictsStaleKeys() throws IOException {
        RawFileStore store = new RawFileStore(temp.resolve("raw").toString(), 1);
        UUID fresh = UUID.randomUUID();
        UUID stale = UUID.randomUUID();
        assertTrue(store.save(fresh, "архив.zip/папка/файл.pdf", "текст", new byte[] {1, 2, 3}));
        assertTrue(store.save(stale, "старый.docx", "текст", new byte[] {9}));
        assertTrue(store.save(fresh, "пустой.txt", "", new byte[0]));

        assertArrayEquals(new byte[] {1, 2, 3}, store.load(fresh, null, "архив.zip/папка/файл.pdf", "текст").orElseThrow());
        assertTrue(store.load(fresh, null, "пустой.txt", "").isEmpty());
        assertTrue(store.load(fresh, null, "нет такого.pdf", "текст").isEmpty());
        // тот же документ с другим текстом — другой ключ склада
        assertTrue(store.load(fresh, null, "архив.zip/папка/файл.pdf", "другой текст").isEmpty());

        Files.setLastModifiedTime(temp.resolve("raw").resolve(stale.toString()),
                FileTime.from(Instant.now().minus(2, ChronoUnit.HOURS)));
        store.evictStale();
        assertTrue(store.load(stale, null, "старый.docx", "текст").isEmpty());
        assertTrue(store.load(fresh, null, "архив.zip/папка/файл.pdf", "текст").isPresent());

        store.clear(fresh);
        assertTrue(store.load(fresh, null, "архив.zip/папка/файл.pdf", "текст").isEmpty());
        assertFalse(Files.exists(temp.resolve("raw").resolve(fresh.toString())));
    }

    @Test
    void rawStoreKeepsSameNameDocumentsWithDifferentText() {
        // cache-10: два «Договор.pdf» с разным содержимым (второй лот при догрузке) хранятся рядом
        RawFileStore store = new RawFileStore(temp.resolve("raw").toString(), 24);
        UUID key = UUID.randomUUID();
        assertTrue(store.save(key, "Договор.pdf", "лот 1", new byte[] {1}));
        assertTrue(store.save(key, "Договор.pdf", "лот 2", new byte[] {2}));

        assertArrayEquals(new byte[] {1}, store.load(key, null, "Договор.pdf", "лот 1").orElseThrow());
        assertArrayEquals(new byte[] {2}, store.load(key, null, "Договор.pdf", "лот 2").orElseThrow());
    }

    @Test
    void rawStoreEvictsOldestKeysOverVolumeLimitAndRejectsTooLargeFile() throws IOException {
        // storage-1: предел 1 МБ — третий файл вытесняет самый старый каталог; файл больше предела не сохраняется
        RawFileStore store = new RawFileStore(temp.resolve("raw").toString(), 24, 1);
        UUID oldKey = UUID.randomUUID();
        UUID newKey = UUID.randomUUID();
        assertTrue(store.save(oldKey, "старый.pdf", "т", bytes(400 * 1024, 1)));
        Files.setLastModifiedTime(temp.resolve("raw").resolve(oldKey.toString()),
                FileTime.from(Instant.now().minus(10, ChronoUnit.MINUTES)));
        assertTrue(store.save(newKey, "новый.pdf", "т", bytes(400 * 1024, 2)));

        assertTrue(store.save(newKey, "ещё.pdf", "т", bytes(400 * 1024, 3)));

        assertTrue(store.load(oldKey, null, "старый.pdf", "т").isEmpty(), "самый старый каталог вытеснен");
        assertTrue(store.load(newKey, null, "новый.pdf", "т").isPresent());
        assertTrue(store.load(newKey, null, "ещё.pdf", "т").isPresent());
        assertTrue(store.usedBytes() <= 1024 * 1024);
        assertFalse(store.save(newKey, "огромный.pdf", "т", bytes(2 * 1024 * 1024, 4)), "файл больше предела");
        assertTrue(store.load(newKey, null, "огромный.pdf", "т").isEmpty());
        // загрузка не падает: остальные файлы ключа на месте
        assertTrue(store.load(newKey, null, "ещё.pdf", "т").isPresent());
    }

    @Test
    void runSnapshotSurvivesClearAndNewUploadOfKey() throws IOException {
        // concurrency-7: оригиналы закреплены за прогоном — новая загрузка без догрузки их не удаляет
        RawFileStore store = new RawFileStore(temp.resolve("raw").toString(), 1);
        UUID key = UUID.randomUUID();
        UUID run = UUID.randomUUID();
        store.save(key, "Договор.pdf", "лот 1", new byte[] {1});
        store.snapshotForRun(key, run, null);
        store.snapshotForRun(key, run, null);

        store.clear(key);
        store.save(key, "Договор.pdf", "лот 2", new byte[] {2});

        assertArrayEquals(new byte[] {1}, store.load(key, run, "Договор.pdf", "лот 1").orElseThrow());
        assertTrue(store.load(key, null, "Договор.pdf", "лот 1").isEmpty());
        // без снимка — файл ключа
        assertArrayEquals(new byte[] {2}, store.load(key, run, "Договор.pdf", "лот 2").orElseThrow());

        // возобновление: склад ключа пуст — снимок берётся из снимка упавшего прогона
        store.clear(key);
        UUID resumed = UUID.randomUUID();
        store.snapshotForRun(key, resumed, run);
        assertArrayEquals(new byte[] {1}, store.load(key, resumed, "Договор.pdf", "лот 1").orElseThrow());

        Files.setLastModifiedTime(temp.resolve("raw").resolve(RawFileStore.RUNS_DIR).resolve(run.toString()),
                FileTime.from(Instant.now().minus(2, ChronoUnit.HOURS)));
        store.evictStale();
        assertTrue(store.load(key, run, "Договор.pdf", "лот 1").isEmpty(), "снимок старше срока жизни вычищен");
        assertTrue(store.load(key, resumed, "Договор.pdf", "лот 1").isPresent());
    }

    @Test
    void artifactStoreSavesLoadsAndEvictsOldFiles() throws IOException {
        RunArtifactStore store = new RunArtifactStore(temp.resolve("art").toString(), 1);
        UUID run = UUID.randomUUID();
        store.save(run, "node_7", new byte[] {4, 5});
        store.save(run, "узел/с/путём", new byte[] {6});

        assertArrayEquals(new byte[] {4, 5}, store.load(run, "node_7").orElseThrow());
        assertArrayEquals(new byte[] {6}, store.load(run, "узел/с/путём").orElseThrow());
        assertTrue(store.load(run, "другой").isEmpty());

        Files.setLastModifiedTime(temp.resolve("art").resolve(run.toString()).resolve("node_7.zip"),
                FileTime.from(Instant.now().minus(2, ChronoUnit.HOURS)));
        store.evictStale();
        assertTrue(store.load(run, "node_7").isEmpty());
        assertTrue(store.load(run, "узел/с/путём").isPresent());
    }
}
