package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Текст вопроса чата для эмбеддинга RAG: сообщение длиннее предела эмбеддинга векторизуется по хвосту
 * (вопрос обычно в конце, после вставленного фрагмента договора), а не по началу.
 */
class ChatServiceEmbeddingQueryTest {

    @Test
    void shortQueryIsUnchanged() {
        assertEquals("вопрос", ChatService.embeddingTail("вопрос", 800));
        assertNull(ChatService.embeddingTail(null, 800));
        assertEquals("abc", ChatService.embeddingTail("abc", 0));
        assertEquals("a".repeat(800), ChatService.embeddingTail("a".repeat(800), 800));
    }

    @Test
    void longQueryIsCutToTailNotLongerThanLimit() {
        String question = "Какой срок оплаты по этому пункту?";
        String pasted = "п".repeat(1500) + "\n" + question;

        String tail = ChatService.embeddingTail(pasted, 800);

        // вопрос короче половины предела: хвост ровно в предел, вопрос целиком в конце
        assertEquals(800, tail.length());
        assertTrue(tail.endsWith("\n" + question), tail);
    }

    @Test
    void longQueryTailStartsFromLineStartWhenLineIsLongEnough() {
        String question = "вопрос ".repeat(100);
        String pasted = "в".repeat(100) + "\n" + question;

        // строка вопроса не короче половины предела — хвост начинается с начала строки, без обрывка предыдущей
        assertEquals(question, ChatService.embeddingTail(pasted, 800));
    }
}
