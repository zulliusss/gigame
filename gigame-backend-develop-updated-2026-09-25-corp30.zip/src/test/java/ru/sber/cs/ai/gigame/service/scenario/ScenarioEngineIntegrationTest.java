package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Интеграционные тесты для {@link ScenarioEngine}.
 * <p>
 * Тестирует публичный API executeScenario, который запускает doExecute в отдельном потоке.
 * <p>
 * Также тестирует doExecute напрямую через рефлексию.
 */
class ScenarioEngineIntegrationTest {

    // -------------------------------------------------------------------------
    // executeScenario integration tests
    // -------------------------------------------------------------------------

    @Test
    void testExecuteScenario_withValidGraph_returnsFlux() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockExecutor = getMockExecutor(graphData, inputNode, 0, "input");

        when(executorFactory.createExecutor(
                any(ScenarioRunNode.class))).thenReturn(mockExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withMultipleNodes_returnsFlux() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");

        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, outputNode),
                List.of(edge)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Input result");

        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, outputNode, 1, "Final output");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2);

        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withException_returnsFailedStatus() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());

        AbstractScenarioExecutor mockExecutor = getMockExecutorWithException(graphData, inputNode, "Test exception");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor);

        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_stepModePausesExecution() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("node-1");
        NodeDto outputNode = createOutputNode("node-2");

        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, outputNode),
                List.of(edge)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Step 1 result");
        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, outputNode, 1, "Step 2 result");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withSkippedNode_emitsSkippedStatus() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "Condition check");
        NodeDto outputNode = createOutputNode("output-1");

        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Input result");
        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, processingNode, 1, "");
        AbstractScenarioExecutor mockExecutor3 = getMockExecutor(graphData, outputNode, 2, "Final");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2)
                .thenReturn(mockExecutor3);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    // -------------------------------------------------------------------------
    // doExecute direct tests (via reflection)
    // -------------------------------------------------------------------------

    /**
     * Тестирует прямой вызов doExecute с валидным графом.
     * doExecute вызывается напрямую через рефлексию.
     */
    @Test
    void testDoExecute_withValidGraph_executesSuccessfully() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto node1 = createInputNode("node-1");
        NodeDto node2 = createOutputNode("node-2");
        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(List.of(node1, node2), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        var step = createScenarioRunStep();
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(step);
        step.setInputData(Map.of(
                "documents_text", "",
                "previous_output", ""));
        step.setOutputData(Map.of("result", "result"));
        step.setPromptUsed("");
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(step);
        var mockExecutor = getMockExecutor(graphData, node1, 0, "Result");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class))).thenReturn(mockExecutor);

        // Создаем Flux и вызываем doExecute напрямую через рефлексию
        Flux<ServerSentEvent<Map<String, Object>>> flux = Flux.create(sink -> {
            try {
                var method = ScenarioEngine.class.getDeclaredMethod("doExecute",
                        FluxSink.class, ScenarioRun.class, GraphDataDto.class,
                        DocsTextCacheService.CachedDocuments.class);
                method.setAccessible(true);
                method.invoke(engine, sink, run, graphData, DocsTextCacheService.CachedDocuments.EMPTY);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        // Подписываемся на Flux и ждем завершения
        var events = flux.collectList().block();
        assertNotNull(events);
    }

    /**
     * Тестирует обработку исключений в doExecute.
     */
    @Test
    void testDoExecute_withException_handledCorrectly() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto node1 = createInputNode("node-1");
        NodeDto node2 = createOutputNode("node-2");
        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(List.of(node1, node2), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        AbstractScenarioExecutor mockExecutor = getMockExecutorWithException(graphData, node1, "Test exception in doExecute");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor);

        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(createScenarioRunStep());
        // Ошибка узла (on_error=stop по умолчанию) пробрасывается из doExecute;
        // прогон завершается со статусом FAILED на уровне executeScenario
        Flux<ServerSentEvent<Map<String, Object>>> flux = engine.executeScenario(run, graphData);

        // Подписываемся на Flux - должен завершиться корректно (исключение обработано)
        var events = flux.collectList().block();
        assertNotNull(events);
        Mockito.verify(runService, Mockito.timeout(5000)).setScenarioRunStatusFailed(any(ScenarioRun.class));
    }

    // -------------------------------------------------------------------------
    // документы прогона — только загруженные запускающим пользователем
    // -------------------------------------------------------------------------

    @Test
    void testExecuteScenario_readsDocumentsUploadedByRunningUser() {
        // общий сценарий запускают разные пользователи: прогон читает кэш по ключу «сценарий + запускающий»
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        ScenarioRun run = createScenarioRun();
        GraphDataDto graphData = twoNodeGraph();
        ScenarioEngine engine = engineWithFailingNode(cacheService, run, graphData);
        UUID userKey = DocsTextCacheService.scenarioKey(run.getScenarioId(), "USER1");

        var events = engine.executeScenario(run, graphData, "USER1").collectList().block(Duration.ofSeconds(30));

        assertNotNull(events);
        Mockito.verify(cacheService, Mockito.timeout(5000)).getCachedDocuments(userKey);
        Mockito.verify(cacheService, Mockito.never()).getCachedDocuments(run.getScenarioId());
        Mockito.verify(cacheService, Mockito.never())
                .getCachedDocuments(DocsTextCacheService.scenarioKey(run.getScenarioId(), "USER2"));
    }

    @Test
    void testExecuteScenario_withoutUser_readsAnonymousDocuments() {
        // без пользователя (аноним) — ключ «anonymous», как у загрузки без X-UserId
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        ScenarioRun run = createScenarioRun();
        GraphDataDto graphData = twoNodeGraph();
        ScenarioEngine engine = engineWithFailingNode(cacheService, run, graphData);
        UUID anonymousKey = DocsTextCacheService.scenarioKey(run.getScenarioId(), "anonymous");

        var events = engine.executeScenario(run, graphData).collectList().block(Duration.ofSeconds(30));

        assertNotNull(events);
        Mockito.verify(cacheService, Mockito.timeout(5000)).getCachedDocuments(anonymousKey);
        Mockito.verify(cacheService, Mockito.never()).getCachedDocuments(run.getScenarioId());
    }

    @Test
    @ExtendWith(OutputCaptureExtension.class)
    void testExecuteScenario_logsDocumentsKeyAndCount(CapturedOutput output) {
        // диагностика расхождения X-UserId в HTTP и WebSocket: в лог прогона пишутся ключ кэша и число документов
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        ScenarioRun run = createScenarioRun();
        GraphDataDto graphData = twoNodeGraph();
        ScenarioEngine engine = engineWithFailingNode(cacheService, run, graphData);
        UUID userKey = DocsTextCacheService.scenarioKey(run.getScenarioId(), "USER1");
        when(cacheService.getCachedDocuments(userKey)).thenReturn(Optional.of(
                new DocsTextCacheService.CachedDocuments(List.of("текст 1", "текст 2"), List.of("a.pdf", "b.pdf"))));

        engine.executeScenario(run, graphData, "USER1").collectList().block(Duration.ofSeconds(30));

        Pattern keyAndCount = Pattern.compile(Pattern.quote(run.getId() + ": ") + "\\S+ \\S+ "
                + Pattern.quote(userKey.toString()) + ", \\S+ 2");
        assertTrue(keyAndCount.matcher(output.getOut()).find(), "в логе нет ключа кэша и числа документов прогона");
    }

    private GraphDataDto twoNodeGraph() {
        NodeDto node1 = createInputNode("node-1");
        NodeDto node2 = createOutputNode("node-2");
        return new GraphDataDto(List.of(node1, node2), List.of(createEdge("e1", "node-1", "node-2")));
    }

    /**
     * Движок, у которого первый узел падает: прогон читает документы и завершается FAILED.
     */
    private ScenarioEngine engineWithFailingNode(DocsTextCacheService cacheService, ScenarioRun run, GraphDataDto graphData) {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(createScenarioRunStep());
        AbstractScenarioExecutor failing = getMockExecutorWithException(graphData, graphData.nodes().get(0),
                "стоп после чтения документов");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class))).thenReturn(failing);
        return new ScenarioEngine(runService, stepService, executorFactory, cacheService,
                Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));
    }

    // -------------------------------------------------------------------------
    // resumeScenario tests
    // -------------------------------------------------------------------------

    @Test
    void testResumeScenario_withValidGraph_restoresAndExecutes() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "промпт");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );

        var oldInputStep = createScenarioRunStep();
        oldInputStep.setNodeId("input-1");
        oldInputStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldInputStep.setStatus("completed");
        oldInputStep.setOutputData(Map.of(
                "result", "<<<DOC_1>>>\nТекст документа\n<<<END_DOC_1>>>",
                "doc_names", "файл.pdf"));

        var oldProcessingStep = createScenarioRunStep();
        oldProcessingStep.setNodeId("process-1");
        oldProcessingStep.setNodeType(ScenarioNodeType.PROCESSING_NODE.toString());
        oldProcessingStep.setStatus("completed");
        oldProcessingStep.setOutputData(Map.of("result", "результат обработки"));

        List<ScenarioRunStep> oldSteps = List.of(oldInputStep, oldProcessingStep);
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.resumeScenario(run, graphData, oldSteps);

        assertNotNull(result);
    }

    @Test
    void testResumeScenario_withEmptyOldSteps_throwsScenarioException() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.resumeScenario(run, graphData, List.of());

        assertNotNull(result);
    }

    @Test
    void testResumeScenario_withStepModeEnabled_pausesCorrectly() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        engine.enableStepMode(run.getId().toString());

        var oldStep = createScenarioRunStep();
        oldStep.setNodeId("input-1");
        oldStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldStep.setStatus("completed");
        oldStep.setOutputData(Map.of("result", "<<<DOC_1>>>\ntext\n<<<END_DOC_1>>>", "doc_names", "test.pdf"));

        List<ScenarioRunStep> oldSteps = List.of(oldStep);

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.resumeScenario(run, graphData, oldSteps);

        assertNotNull(result);
    }

    // -------------------------------------------------------------------------
    // scheduleReadyNodes tests
    // -------------------------------------------------------------------------

    @Test
    void testScheduleReadyNodes_startNode_returns1() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        // Создаём граф с узлами
        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        // Вызываем scheduleReadyNodes через рефлексию
        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // Стартовый узел (input-1) должен быть запланирован
        assertEquals(1, started);
        assertTrue(scheduled.stream().anyMatch(n -> "input-1".equals(n.getId())));
    }

    @Test
    void testScheduleReadyNodes_allScheduled_returns0() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        // Все узлы уже запланированы
        scheduled.addAll(nodes);

        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // Ни один узел не должен быть запланирован
        assertEquals(0, started);
    }

    @Test
    void testScheduleReadyNodes_skipNode_returns0ForSkipped() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        // Граф: вход → обработка → выход (обработка может быть пропущена)
        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "промпт");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        // Создаём граф с узлами
        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        // Отмечаем все узлы, кроме processing, как завершённые (чтобы
        // scheduleNodeIfReady дошёл до проверки skip для process-1)
        for (var n : nodes) {
            if (!"process-1".equals(n.getId())) {
                n.setCompleted(true);
                n.setSkip(false);
            }
        }

        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // process-1 имеет skip=true и все родители завершены — узел пропускается
        assertEquals(0, started);
        // process-1 должен быть в skippedNodes (родители завершены, но не активирован)
        assertTrue(skippedNodes.stream().anyMatch(n -> "process-1".equals(n.getId())));
    }

    @Test
    void testScheduleReadyNodes_completedNode_returns0() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        ScenarioRunNode inputNodeInstance = graph.getNodeMap().get("input-1");

        // Узел уже завершён (completed=true — восстановлен из предыдущего прогона)
        inputNodeInstance.setCompleted(true);
        inputNodeInstance.setSkip(false);

        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // Завершённый узел не планируется заново
        assertEquals(0, started);
        assertTrue(scheduled.stream().anyMatch(n -> "input-1".equals(n.getId())));
    }

    // -------------------------------------------------------------------------
    // resumeExecution tests
    // -------------------------------------------------------------------------

    /**
     * Вызов resumeExecution через рефлексию.
     */
    private void invokeResumeExecution(ScenarioEngine engine,
                                        FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                        ScenarioRun run,
                                        GraphDataDto graphData,
                                        List<ScenarioRunStep> oldSteps) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("resumeExecution",
                    FluxSink.class, ScenarioRun.class, GraphDataDto.class, List.class);
            method.setAccessible(true);
            method.invoke(engine, sink, run, graphData, oldSteps);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException) {
                throw (RuntimeException) cause;
            }
            throw new RuntimeException(cause);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testResumeExecution_withValidOldSteps_completesSuccessfully() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        var repository = Mockito.mock(ScenarioRepository.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "промпт");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, repository, Mockito.mock(ScenarioOutputSupportService.class));

        var oldInputStep = createScenarioRunStep();
        oldInputStep.setNodeId("input-1");
        oldInputStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldInputStep.setStatus("completed");
        oldInputStep.setOutputData(Map.of(
                "result", "<<<DOC_1>>>\nТекст документа\n<<<END_DOC_1>>>",
                "doc_names", "файл.pdf"));

        var oldProcessingStep = createScenarioRunStep();
        oldProcessingStep.setNodeId("process-1");
        oldProcessingStep.setNodeType(ScenarioNodeType.PROCESSING_NODE.toString());
        oldProcessingStep.setStatus("completed");
        oldProcessingStep.setOutputData(Map.of("result", "обработан"));

        List<ScenarioRunStep> oldSteps = List.of(oldInputStep, oldProcessingStep);

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());
        when(stepService.copyStepToRun(any(UUID.class), any(ScenarioRunStep.class)))
                .thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        assertDoesNotThrow(() -> invokeResumeExecution(engine, sink, run, graphData, oldSteps));
        // документы возобновлённого прогона — из шага входного узла, кэш загрузок (чьих-либо) не читается
        Mockito.verify(cacheService, Mockito.never()).getCachedDocumentTexts(any());
        Mockito.verify(cacheService, Mockito.never()).getCachedFileNames(any());
    }

    @Test
    void testResumeExecution_withoutOldSteps_throwsScenarioException() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        var repository = Mockito.mock(ScenarioRepository.class);

        GraphDataDto graphData = new GraphDataDto(List.of(), List.of());
        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, repository, Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        assertThrows(ScenarioException.class,
                () -> invokeResumeExecution(engine, sink, run, graphData, List.of()));
    }

    @Test
    void testRestoreAgentCheckpoints_failedStepBecomesWorkingDoc() {
        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode),
                List.of(createEdge("e1", "input-1", "output-1")));
        var graph = new ScenarioRunGraph(graphData);
        var failedStep = createScenarioRunStep();
        failedStep.setNodeId("agent-1");
        failedStep.setStatus("failed");
        failedStep.setOutputData(Map.of("error", "сеть",
                "checkpoint", "поиск 'НМЦ' -> 161560083"));
        var completedStep = createScenarioRunStep();
        completedStep.setNodeId("input-1");
        completedStep.setStatus("completed");

        ScenarioEngine.restoreAgentCheckpoints(graph, List.of(failedStep, completedStep));

        // чекпойнт упавшего узла стал рабочим файлом прогона, completed — нет
        var work = graph.getDocMap().values().stream()
                .filter(d -> d.isWorkNote()).toList();
        assertEquals(1, work.size());
        assertTrue(work.get(0).getFilename().contains("agent-1"));
        assertTrue(work.get(0).getText().contains("161560083"));
    }

    @Test
    void testResumeExecution_withoutInputResult_throwsScenarioException() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        var repository = Mockito.mock(ScenarioRepository.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, repository, Mockito.mock(ScenarioOutputSupportService.class));

        var oldStep = createScenarioRunStep();
        oldStep.setNodeId("input-1");
        oldStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldStep.setStatus("completed");
        // outputData без result — нечего восстанавливать

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        var oldSteps = List.of(oldStep);

        assertThrows(ScenarioException.class,
                () -> invokeResumeExecution(engine, sink, run, graphData, oldSteps));
    }

    // -------------------------------------------------------------------------
    // Сквозные тесты возобновления: реальные input/if, записывающие исполнители остальных узлов
    // -------------------------------------------------------------------------

    @Test
    void testResumeScenario_threeDocsInHashMapOrder_eachDocKeepsTextNameAndClass() {
        Map<String, List<String>> seenDocs = new ConcurrentHashMap<>();
        Map<String, String> seenUsers = new ConcurrentHashMap<>();
        Map<String, String> outputs = new ConcurrentHashMap<>();
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = resumeEngine(runService, stepService, recordingFactory(seenDocs, seenUsers),
                run, outputs);
        List<ScenarioRunStep> oldSteps = classifyIfOldSteps();

        engine.resumeScenario(run, classifyIfGraph(), oldSteps, "ALICE")
                .collectList().block(Duration.ofSeconds(30));

        Mockito.verify(runService).setScenarioRunStatusCompleted(any(ScenarioRun.class), any());
        // цикл-классификатор восстановлен из шага, а не перезапущен
        assertFalse(seenDocs.containsKey("loop-1"));
        Mockito.verify(stepService).copyStepToRun(run.getId(), oldSteps.get(1));
        // if по docClass отдал ветке «договор» ровно договор: его текст, его имя, его класс
        assertEquals(List.of("DOC_1|договор.pdf|договор|текст договора"), seenDocs.get("agent-1"));
        assertEquals(Set.of("DOC_2|тз.docx|ТЗ|текст ТЗ", "DOC_3|кп.pdf|КП|текст КП"),
                new HashSet<>(seenDocs.get("proc-2")));
        // чекпойнт упавшего агента виден ему рабочим файлом, но не стал входным документом
        assertEquals(List.of("чекпойнт-agent-1-прерванного-прогона.md"), seenDocs.get("agent-1#work"));
        String inputResult = outputs.get("input-1");
        assertTrue(inputResult.contains("<<<DOC_1>>>\nтекст договора\n<<<END_DOC_1>>>"));
        assertTrue(inputResult.contains("<<<DOC_2>>>\nтекст ТЗ\n<<<END_DOC_2>>>"));
        assertTrue(inputResult.contains("<<<DOC_3>>>\nтекст КП\n<<<END_DOC_3>>>"));
        assertFalse(inputResult.contains("WORK_"));
        // имена сохранены по номерам DOC_i — повторное возобновление их не потеряет
        Mockito.verify(stepService).setScenarioStepStatusCompleted(any(ScenarioRunStep.class), any(), any(), any(),
                any(), any(), Mockito.eq("договор.pdf\nтз.docx\nкп.pdf"));
        Mockito.verify(stepService, Mockito.never()).appendOutputData(any(), Mockito.eq("doc_names"), any());
        assertEquals("ALICE", seenUsers.get("agent-1"));
    }

    @Test
    void testResumeScenario_nodesRunAsResumingUser() {
        Map<String, List<String>> seenDocs = new ConcurrentHashMap<>();
        Map<String, String> seenUsers = new ConcurrentHashMap<>();
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = resumeEngine(runService, stepService, recordingFactory(seenDocs, seenUsers),
                run, new ConcurrentHashMap<>());
        GraphDataDto graphData = new GraphDataDto(
                List.of(createInputNode("input-1"), createProcessingNode("process-1", "промпт"),
                        createOutputNode("output-1")),
                List.of(createEdge("e1", "input-1", "process-1"), createEdge("e2", "process-1", "output-1")));
        var inputStep = oldStep("input-1", ScenarioNodeType.INPUT_NODE, "completed",
                Map.of("result", "<<<DOC_1>>>\nтекст\n<<<END_DOC_1>>>"));

        engine.resumeScenario(run, graphData, List.of(inputStep), "ALICE")
                .collectList().block(Duration.ofSeconds(30));

        Mockito.verify(runService).setScenarioRunStatusCompleted(any(ScenarioRun.class), any());
        // узлы (в пуле волн) выполняются от имени возобновившего, а не «anonymous»
        assertEquals("ALICE", seenUsers.get("process-1"));
        assertEquals("ALICE", seenUsers.get("output-1"));
    }

    @Test
    void testResumeExecution_stepBuiltOnParentError_rerunWithDescendants() {
        Map<String, List<String>> seenDocs = new ConcurrentHashMap<>();
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = resumeEngine(runService, stepService,
                recordingFactory(seenDocs, new ConcurrentHashMap<>()), run, new ConcurrentHashMap<>());
        List<ScenarioRunStep> oldSteps = parentErrorOldSteps();
        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        invokeResumeExecution(engine, sink, run, parentErrorGraph(), oldSteps);

        // X упал и перезапускается; A отработал на тексте ошибки X, B — на битом выходе A:
        // оба перезапускаются, независимая ветка C восстанавливается
        assertTrue(seenDocs.keySet().containsAll(List.of("x-1", "a-1", "b-1", "output-1")));
        assertFalse(seenDocs.containsKey("c-1"));
        Mockito.verify(stepService).copyStepToRun(run.getId(), oldSteps.get(4));
        Mockito.verify(stepService, Mockito.never()).copyStepToRun(any(UUID.class), Mockito.same(oldSteps.get(2)));
        Mockito.verify(stepService, Mockito.never()).copyStepToRun(any(UUID.class), Mockito.same(oldSteps.get(3)));
    }

    @Test
    void testResumeExecution_branchModeMergeWithoutMarker_rerunAfterFailedParent() {
        Map<String, List<String>> seenDocs = new ConcurrentHashMap<>();
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = resumeEngine(runService, stepService,
                recordingFactory(seenDocs, new ConcurrentHashMap<>()), run, new ConcurrentHashMap<>());
        var inputStep = oldStep("input-1", ScenarioNodeType.INPUT_NODE, "completed",
                Map.of("result", "<<<DOC_1>>>\nтекст\n<<<END_DOC_1>>>"));
        var failedStep = oldStep("x-1", ScenarioNodeType.PROCESSING_NODE, "failed",
                Map.of("error", "Не удалось выполнить запрос к GigaChat"));
        var clean = oldStep("c-1", ScenarioNodeType.PROCESSING_NODE, "completed",
                Map.of("result", "независимый результат"));
        clean.setInputData(Map.of("documents_text", "текст", "previous_output", ""));
        // on_error=branch: обычная ветка X → A пропущена, слияние R отработало на одном C — маркера нет
        var merge = oldStep("r-1", ScenarioNodeType.PROCESSING_NODE, "completed",
                Map.of("result", "итог без анализа"));
        merge.setInputData(Map.of("documents_text", "текст", "previous_output",
                "=== РЕЗУЛЬТАТ ОТ \"Processing\" ===\nнезависимый результат"));
        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        invokeResumeExecution(engine, sink, run, branchMergeGraph(), List.of(inputStep, failedStep, clean, merge));

        // X перезапускается, за ним A и слияние R (иначе выход A молча терялся бы); C восстанавливается
        assertTrue(seenDocs.keySet().containsAll(List.of("x-1", "a-1", "r-1", "output-1")));
        assertFalse(seenDocs.containsKey("c-1"));
        Mockito.verify(stepService).copyStepToRun(run.getId(), clean);
        Mockito.verify(stepService, Mockito.never()).copyStepToRun(any(UUID.class), Mockito.same(merge));
    }

    /**
     * Граф: вход → X (on_error=branch) → A → R → выход; вход → C → R.
     */
    private GraphDataDto branchMergeGraph() {
        NodeDto failing = NodeDto.builder()
                .id("x-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Анализ").prompt("анализ").onError("branch").build())
                .position(new PositionDto(100, 100))
                .build();
        return new GraphDataDto(
                List.of(createInputNode("input-1"), failing, createProcessingNode("a-1", "по анализу"),
                        createProcessingNode("c-1", "соседняя ветка"), createProcessingNode("r-1", "слияние"),
                        createOutputNode("output-1")),
                List.of(createEdge("e1", "input-1", "x-1"), createEdge("e2", "x-1", "a-1"),
                        createEdge("e3", "a-1", "r-1"), createEdge("e4", "input-1", "c-1"),
                        createEdge("e5", "c-1", "r-1"), createEdge("e6", "r-1", "output-1")));
    }

    /**
     * Граф: вход → цикл-классификатор → if (docClass = договор) → агент / прочие → выход.
     */
    private GraphDataDto classifyIfGraph() {
        NodeDto loopNode = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Классификатор").classifyStrict("true")
                        .classes("договор, ТЗ, КП").build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto ifNode = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder().label("Договор?").field("docClass").operator("equals")
                        .value("договор").build())
                .position(new PositionDto(100, 100))
                .build();
        return new GraphDataDto(
                List.of(createInputNode("input-1"), loopNode, ifNode, createProcessingNode("agent-1", "проверь договор"),
                        createProcessingNode("proc-2", "прочие документы"), createOutputNode("output-1")),
                List.of(createEdge("e1", "input-1", "loop-1"), createEdge("e2", "loop-1", "if-1"),
                        new EdgeDto("e3", "if-1", "agent-1", new EdgeDataDto("true")),
                        new EdgeDto("e4", "if-1", "proc-2", new EdgeDataDto("false")),
                        createEdge("e5", "agent-1", "output-1"), createEdge("e6", "proc-2", "output-1")));
    }

    /**
     * Шаги упавшего прогона: блоки документов во входе и в цикле — в порядке итерации HashMap
     * для трёх документов (DOC_2, DOC_1, DOC_3); агент упал с чекпойнтом.
     */
    private List<ScenarioRunStep> classifyIfOldSteps() {
        var inputStep = oldStep("input-1", ScenarioNodeType.INPUT_NODE, "completed", Map.of(
                "result", "<<<DOC_2>>>\nтекст ТЗ\n<<<END_DOC_2>>>\n\n"
                        + "<<<DOC_1>>>\nтекст договора\n<<<END_DOC_1>>>\n\n"
                        + "<<<DOC_3>>>\nтекст КП\n<<<END_DOC_3>>>",
                "doc_names", "договор.pdf\nтз.docx\nкп.pdf"));
        var loopStep = oldStep("loop-1", ScenarioNodeType.LOOP_NODE, "completed", Map.of(
                "result", "<<<DOC_2|CLASS:ТЗ>>>\nтекст ТЗ\n<<<END_DOC_2>>>\n\n"
                        + "<<<DOC_1|CLASS:договор>>>\nтекст договора\n<<<END_DOC_1>>>\n\n"
                        + "<<<DOC_3|CLASS:КП>>>\nтекст КП\n<<<END_DOC_3>>>"));
        loopStep.setInputData(Map.of("documents_text", "текст ТЗ", "previous_output", ""));
        var ifStep = oldStep("if-1", ScenarioNodeType.IF_NODE, "completed", Map.of("result", "старый результат"));
        var agentStep = oldStep("agent-1", ScenarioNodeType.PROCESSING_NODE, "failed",
                Map.of("error", "обрыв сети", "checkpoint", "НМЦ договора: 100 руб."));
        return List.of(inputStep, loopStep, ifStep, agentStep);
    }

    /**
     * Граф: вход → X (on_error=continue) → A → B → выход; вход → C → выход.
     */
    private GraphDataDto parentErrorGraph() {
        NodeDto failing = NodeDto.builder()
                .id("x-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Анализ").prompt("анализ").onError("continue").build())
                .position(new PositionDto(100, 100))
                .build();
        return new GraphDataDto(
                List.of(createInputNode("input-1"), failing, createProcessingNode("a-1", "по анализу"),
                        createProcessingNode("b-1", "итог"), createProcessingNode("c-1", "независимая ветка"),
                        createOutputNode("output-1")),
                List.of(createEdge("e1", "input-1", "x-1"), createEdge("e2", "x-1", "a-1"),
                        createEdge("e3", "a-1", "b-1"), createEdge("e4", "b-1", "output-1"),
                        createEdge("e5", "input-1", "c-1"), createEdge("e6", "c-1", "output-1")));
    }

    /**
     * Шаги прогона, где X упал при on_error=continue: A «успешно» отработал на тексте ошибки
     * (маркер из handleNodeError во входе), B — на выходе A (маркера уже нет), C — независим.
     */
    private List<ScenarioRunStep> parentErrorOldSteps() {
        var inputStep = oldStep("input-1", ScenarioNodeType.INPUT_NODE, "completed",
                Map.of("result", "<<<DOC_1>>>\nтекст\n<<<END_DOC_1>>>"));
        var failedStep = oldStep("x-1", ScenarioNodeType.PROCESSING_NODE, "failed",
                Map.of("error", "Не удалось выполнить запрос к GigaChat"));
        var builtOnError = oldStep("a-1", ScenarioNodeType.PROCESSING_NODE, "completed",
                Map.of("result", "данных нет"));
        builtOnError.setInputData(Map.of("documents_text", "текст", "previous_output",
                "=== РЕЗУЛЬТАТ ОТ \"Анализ\" (ОШИБКА) ===\n"
                        + "[ОШИБКА УЗЛА «Анализ»: Не удалось выполнить запрос к GigaChat]"));
        var derived = oldStep("b-1", ScenarioNodeType.PROCESSING_NODE, "completed",
                Map.of("result", "итог: данных нет"));
        derived.setInputData(Map.of("documents_text", "", "previous_output",
                "=== РЕЗУЛЬТАТ ОТ \"Processing\" ===\nданных нет"));
        var clean = oldStep("c-1", ScenarioNodeType.PROCESSING_NODE, "completed",
                Map.of("result", "независимый результат"));
        clean.setInputData(Map.of("documents_text", "текст", "previous_output", ""));
        return List.of(inputStep, failedStep, builtOnError, derived, clean);
    }

    private ScenarioRunStep oldStep(String nodeId, ScenarioNodeType type, String status,
                                    Map<String, String> outputData) {
        var step = createScenarioRunStep();
        step.setNodeId(nodeId);
        step.setNodeType(type.toString());
        step.setStatus(status);
        step.setOutputData(outputData);
        return step;
    }

    /**
     * Движок с моками сервисов прогона: шаги получают id узла, выходы узлов записываются.
     */
    private ScenarioEngine resumeEngine(ScenarioRunService runService, ScenarioRunStepService stepService,
                                        ScenarioExecutorFactory factory, ScenarioRun run,
                                        Map<String, String> outputs) {
        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenAnswer(inv -> {
                    var step = createScenarioRunStep();
                    step.setNodeId(inv.getArgument(1));
                    return step;
                });
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), any(), any(), any(), any(), any(), any()))
                .thenAnswer(inv -> {
                    ScenarioRunStep step = inv.getArgument(0);
                    outputs.put(step.getNodeId(), String.valueOf((Object) inv.getArgument(3)));
                    return step;
                });
        return new ScenarioEngine(runService, stepService, factory, Mockito.mock(DocsTextCacheService.class),
                Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));
    }

    /**
     * Фабрика исполнителей: input и if — настоящие, остальные узлы записывают свои документы
     * («метка|имя|класс|текст»), рабочие файлы прогона («id#work») и пользователя потока.
     */
    private ScenarioExecutorFactory recordingFactory(Map<String, List<String>> seenDocs,
                                                     Map<String, String> seenUsers) {
        var realFactory = new ScenarioExecutorFactory(null, null, null, null, null);
        var factory = Mockito.mock(ScenarioExecutorFactory.class);
        when(factory.createExecutor(any(ScenarioRunNode.class))).thenAnswer(inv -> {
            ScenarioRunNode node = inv.getArgument(0);
            if (node.getType() == ScenarioNodeType.INPUT_NODE || node.getType() == ScenarioNodeType.IF_NODE) {
                return realFactory.createExecutor(node);
            }
            return recordingExecutor(node, seenDocs, seenUsers);
        });
        return factory;
    }

    private AbstractScenarioExecutor recordingExecutor(ScenarioRunNode runNode,
                                                       Map<String, List<String>> seenDocs,
                                                       Map<String, String> seenUsers) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                seenUsers.put(runNode.getId(), String.valueOf(CurrentUserHolder.getCurrentUser()));
                var docMap = runNode.getGraph().getDocMap();
                List<String> docs = new ArrayList<>();
                for (String docId : runNode.getDocList()) {
                    var doc = docMap.get(docId);
                    docs.add(docId + "|" + doc.getFilename() + "|" + doc.getDocClass() + "|" + doc.getText());
                }
                seenDocs.put(runNode.getId(), docs);
                seenDocs.put(runNode.getId() + "#work", docMap.values().stream()
                        .filter(ScenarioRunDoc::isWorkNote).map(ScenarioRunDoc::getFilename).toList());
                // исполнители активируют детей (как processing/loop)
                runNode.getChildNodeList().forEach(child -> child.setSkip(false));
                return "результат " + runNode.getId();
            }

            @Override
            public String getPrompt() {
                return "";
            }
        };
    }

    // -------------------------------------------------------------------------
    // Factory methods for test data
    // -------------------------------------------------------------------------

    private ScenarioRun createScenarioRun() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(UUID.randomUUID());
        run.setStatus("pending");
        return run;
    }

    private ScenarioRunStep createScenarioRunStep() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setRunId(UUID.randomUUID());
        step.setNodeId("node-1");
        step.setNodeType("input");
        step.setStatus("pending");
        return step;
    }

    private NodeDto createInputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private NodeDto createOutputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private NodeDto createProcessingNode(String id, String prompt) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Processing").prompt(prompt).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private EdgeDto createEdge(String id, String source, String target) {
        return new EdgeDto(id, source, target, new EdgeDataDto(null));
    }

    private AbstractScenarioExecutor getMockExecutor(GraphDataDto graphData, NodeDto node, int index, String inputResult) {
        return new AbstractScenarioExecutor(ScenarioRunNode.fromDto(index, node, new ScenarioRunGraph(graphData))) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                return inputResult;
            }

            @Override
            public String getPrompt() {
                return "";
            }

        };
    }

    private AbstractScenarioExecutor getMockExecutorWithException(GraphDataDto graphData, NodeDto node1, String exceptionText) {
        return new AbstractScenarioExecutor(
                ScenarioRunNode.fromDto(0, node1, new ScenarioRunGraph(graphData))) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                throw new RuntimeException(exceptionText);
            }

            @Override
            public String getPrompt() {
                return "";
            }
        };
    }
}
