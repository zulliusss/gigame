package ru.sber.cs.ai.gigame.service;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Изображения (jpg/png) как одностраничный скан: обёртка в PDF по размеру картинки и распознавание
 * через {@link ScanOcrService} на пути диалога и базы знаний.
 */
@ExtendWith(MockitoExtension.class)
class DocumentServiceImageTest {

    @Mock
    private ScanOcrService ocr;
    @Mock
    private ObjectProvider<ScanOcrService> ocrProvider;

    private static byte[] image(String format) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(new BufferedImage(40, 30, BufferedImage.TYPE_INT_RGB), format, out);
        return out.toByteArray();
    }

    @Test
    void imageIsWrappedIntoSinglePagePdfOfItsSize() throws IOException {
        DocumentService service = new DocumentService(null, null, null);

        byte[] pdf = service.imageToPdf(image("png"), "фото.png");

        try (PDDocument doc = Loader.loadPDF(pdf)) {
            assertEquals(1, doc.getNumberOfPages());
            assertEquals(40f, doc.getPage(0).getMediaBox().getWidth());
            assertEquals(30f, doc.getPage(0).getMediaBox().getHeight());
        }
        // страница-картинка без текстового слоя — тот же скан для постраничной проверки
        assertEquals(List.of(1), service.textlessPages(pdf));
        assertTrue(service.isScanPdf(pdf, ""));
        assertEquals("", service.parseText(new ByteArrayInputStream(image("jpg")), "image"));
        assertThrows(Exception.class, () -> service.imageToPdf("not an image".getBytes(), "битое.jpg"));
    }

    @Test
    void imageIsRecognizedThroughOcrAsScan() throws IOException {
        when(ocrProvider.getIfAvailable()).thenReturn(ocr);
        when(ocr.isEnabled()).thenReturn(true);
        when(ocr.recognize(eq("IMG_0001.jpg"), any())).thenReturn("[РАСПОЗНАНО] Документ «IMG_0001.jpg»:\nАкт №7");
        DocumentService service = new DocumentService(null, null, null, ocrProvider);

        String text = service.extractText("IMG_0001.jpg", "image", image("jpg"));

        assertEquals("[РАСПОЗНАНО] Документ «IMG_0001.jpg»:\nАкт №7", text);
        ArgumentCaptor<byte[]> sent = ArgumentCaptor.forClass(byte[].class);
        verify(ocr).recognize(eq("IMG_0001.jpg"), sent.capture());
        assertTrue(new String(sent.getValue(), 0, 5).startsWith("%PDF-"), "в GigaChat уходит PDF, а не картинка");
    }

    @Test
    void imageWithoutOcrGivesEmptyTextInsteadOfFailure() throws IOException {
        DocumentService service = new DocumentService(null, null, null);

        assertEquals("", service.extractText("IMG_0001.jpg", "image", image("jpg")));
    }
}
