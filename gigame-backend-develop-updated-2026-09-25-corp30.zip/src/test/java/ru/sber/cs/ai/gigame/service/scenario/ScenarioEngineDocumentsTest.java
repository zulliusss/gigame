package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * corp23 concurrency-5 / cache-1: память прогона на документах. Входной узел не держит склейку
 * всех документов в результате узла (только сводка), полный текст уходит лишь в шаг БД; сводка
 * документов шага считается по документам без склейки и совпадает с прежним хэшем; число
 * документов пишется в журнал прогона.
 */
class ScenarioEngineDocumentsTest {

    private final ScenarioRunService runService = mock(ScenarioRunService.class);
    private final ScenarioRunStepService stepService = mock(ScenarioRunStepService.class);
    private final List<Map<String, Object>> events = new CopyOnWriteArrayList<>();
    private final Map<String, ScenarioRunNode> nodes = new ConcurrentHashMap<>();
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> eventSink = mock(FluxSink.class);

    @Test
    void inputNode_keepsOnlySummaryInResult_fullTextGoesToStepOnly() {
        String text1 = "договор ".repeat(50);
        String text2 = "акт ".repeat(50);
        var docs = new DocsTextCacheService.CachedDocuments(List.of(text1, text2), List.of("договор.pdf", "акт.pdf"));

        invokeDoExecute(engine(), graph(), docs);

        ScenarioRunNode input = nodes.get("input-1");
        assertNotNull(input);
        assertEquals("документов 2: DOC_1 (договор.pdf), DOC_2 (акт.pdf)", input.getResult());
        assertFalse(input.getResult().contains("<<<DOC_1>>>"), "склейка документов осталась в результате входного узла");
        // потомок читает документы из docMap, а не из результата входа
        ScenarioRunNode child = nodes.get("a-1");
        assertEquals(List.of("DOC_1", "DOC_2"), List.copyOf(child.getDocList()));
        assertEquals(List.of(text1, text2), child.getDocTexts());
        // полный текст комплекта — только в шаге входного узла (по нему возобновление восстанавливает документы)
        ArgumentCaptor<String> output = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<String> docNames = ArgumentCaptor.forClass(String.class);
        verify(stepService, Mockito.atLeastOnce()).setScenarioStepStatusCompleted(any(), any(), any(),
                output.capture(), any(), any(), docNames.capture());
        int inputStep = docNames.getAllValues().indexOf("договор.pdf\nакт.pdf");
        assertTrue(inputStep >= 0, "шаг входного узла без имён файлов: " + docNames.getAllValues());
        assertTrue(output.getAllValues().get(inputStep).contains("<<<DOC_1>>>\n" + text1 + "\n<<<END_DOC_1>>>"));
    }

    @Test
    void childStep_documentsSummaryIsHashedPerDocument_andEqualsJoinedHash() {
        String text1 = "текст первого";
        String text2 = "текст второго";
        var docs = new DocsTextCacheService.CachedDocuments(List.of(text1, text2), List.of("a.pdf", "b.pdf"));

        invokeDoExecute(engine(), graph(), docs);

        ArgumentCaptor<String> summaries = ArgumentCaptor.forClass(String.class);
        verify(stepService, Mockito.atLeastOnce()).setScenarioStepStatusCompleted(any(), any(), summaries.capture(),
                any(), any(), any(), any());
        String expected = ScenarioRunStepService.documentsSummary(List.of("DOC_1", "DOC_2"), text1 + "\n\n" + text2);
        assertTrue(summaries.getAllValues().contains(expected), "сводки шагов: " + summaries.getAllValues());
        assertTrue(summaries.getAllValues().stream().noneMatch(s -> s.contains(text1)));
    }

    @Test
    void run_writesDocumentCountToRunJournal() {
        var docs = new DocsTextCacheService.CachedDocuments(List.of("1", "2", "3"), List.of("a", "b", "c"));

        invokeDoExecute(engine(), graph(), docs);

        assertTrue(events.stream().anyMatch(e -> ScenarioEngine.DOCUMENTS_LABEL.equals(e.get("node_label"))
                && "документов 3".equals(e.get("detail"))), "в журнале прогона нет числа документов: " + events);
    }

    @Test
    void resultToKeep_nonInputNode_keepsOutput_inputWithoutDocs_keepsOutput() {
        var graph = new ScenarioRunGraph(graph());
        assertEquals("выход", ScenarioEngine.resultToKeep(graph.getNodeMap().get("a-1"), "выход"));
        assertEquals("", ScenarioEngine.resultToKeep(graph.getNodeMap().get("input-1"), ""));
        graph.addDocs(List.of("t"), List.of("f.pdf"));
        graph.addWorkingDoc("заметка.md", "рабочий файл не считается документом");
        assertEquals("документов 1: DOC_1 (f.pdf)", ScenarioEngine.resultToKeep(graph.getNodeMap().get("input-1"), "x"));
    }

    // -------------------------------------------------------------------------
    // helpers
    // -------------------------------------------------------------------------

    private ScenarioEngine engine() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(UUID.randomUUID());
        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenAnswer(inv -> {
                    var step = new ScenarioRunStep();
                    step.setId(UUID.randomUUID());
                    step.setNodeId(inv.getArgument(1));
                    return step;
                });
        when(stepService.setScenarioStepStatusCompleted(any(), any(), any(), any(), any(), any(), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.doAnswer(inv -> {
            ServerSentEvent<Map<String, Object>> event = inv.getArgument(0);
            events.add(event.data());
            return null;
        }).when(eventSink).next(any());
        var real = new ScenarioExecutorFactory(null, null, null, null, null);
        var factory = mock(ScenarioExecutorFactory.class);
        when(factory.createExecutor(any(ScenarioRunNode.class))).thenAnswer(inv -> {
            ScenarioRunNode node = inv.getArgument(0);
            nodes.put(node.getId(), node);
            // вход — настоящий исполнитель (склейка документов); обработка — вклад в выход без LLM
            return node.getType() == ScenarioNodeType.PROCESSING_NODE ? contributing(node) : real.createExecutor(node);
        });
        var support = mock(ScenarioOutputSupportService.class);
        when(support.accumulateIfConfigured(any(), any(), any())).thenAnswer(inv -> inv.getArgument(2));
        return new ScenarioEngine(runService, stepService, factory, mock(DocsTextCacheService.class),
                mock(ScenarioRepository.class), support);
    }

    private void invokeDoExecute(ScenarioEngine engine, GraphDataDto graphData, DocsTextCacheService.CachedDocuments docs) {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(UUID.randomUUID());
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("doExecute",
                    FluxSink.class, ScenarioRun.class, GraphDataDto.class, DocsTextCacheService.CachedDocuments.class);
            method.setAccessible(true);
            method.invoke(engine, eventSink, run, graphData, docs);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException(e);
        }
    }

    private static AbstractScenarioExecutor contributing(ScenarioRunNode runNode) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                String text = "[{\"документов\": " + runNode.getDocList().size() + "}]";
                runNode.getOutput().add(text);
                for (var child : runNode.getChildNodeList()) {
                    child.setSkip(false);
                    child.addInput(runNode.getId(), text);
                }
                return text;
            }
        };
    }

    private static GraphDataDto graph() {
        return new GraphDataDto(
                List.of(node("input-1", ScenarioNodeType.INPUT_NODE, "Вход"),
                        node("a-1", ScenarioNodeType.PROCESSING_NODE, "Обработка"),
                        node("out-1", ScenarioNodeType.OUTPUT_NODE, "Выход")),
                List.of(edge("input-1", "a-1"), edge("a-1", "out-1")));
    }

    private static NodeDto node(String id, ScenarioNodeType type, String label) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).prompt("p").build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static EdgeDto edge(String source, String target) {
        return new EdgeDto(source + "-" + target, source, target, new EdgeDataDto(null));
    }
}
