package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;
import org.springframework.core.codec.DecodingException;
import org.springframework.core.io.buffer.DataBufferLimitException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.web.server.PayloadTooLargeException;
import org.springframework.web.server.ResponseStatusException;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ApplicationErrorHandlerTest {

    private final ApplicationErrorHandler handler = new ApplicationErrorHandler();

    @Test
    void testHandleNotFoundException() {
        NotFoundException ex = new NotFoundException("Resource not found");

        ResponseEntity<ErrorResponse> response = handler.handleNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(404, response.getBody().getStatusCode());
        assertEquals("Not Found", response.getBody().getError());
        assertEquals("Resource not found", response.getBody().getMessage());
        assertNotNull(response.getBody().getTimestamp());
    }

    @Test
    void testHandleAccessDeniedException() {
        AccessDeniedException ex = new AccessDeniedException("Access denied");

        ResponseEntity<ErrorResponse> response = handler.handleAccessDeniedException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(403, response.getBody().getStatusCode());
        assertEquals("Forbidden", response.getBody().getError());
        assertEquals("Access denied", response.getBody().getMessage());
    }

    @Test
    void testHandleFileException() {
        FileException ex = new FileException("File error");

        ResponseEntity<ErrorResponse> response = handler.handleFileException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(422, response.getBody().getStatusCode());
        assertEquals("Unprocessable Entity", response.getBody().getError());
        assertEquals("File error", response.getBody().getMessage());
    }

    @Test
    void testHandleScenarioException() {
        ScenarioException ex = new ScenarioException("Scenario error");

        ResponseEntity<ErrorResponse> response = handler.handleScenarioException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(400, response.getBody().getStatusCode());
        assertEquals("Bad Request", response.getBody().getError());
        assertEquals("Scenario error", response.getBody().getMessage());
    }

    @Test
    void testHandleValidationException() {
        // corp17 (P1): превышение maxLength спецификации — 422 с телом ErrorResponse
        ValidationException ex = new ValidationException("Название промпта длиннее 255 символов: 300");

        ResponseEntity<ErrorResponse> response = handler.handleValidationException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(422, response.getBody().getStatusCode());
        assertEquals("Unprocessable Entity", response.getBody().getError());
        assertEquals("Название промпта длиннее 255 символов: 300", response.getBody().getMessage());
    }

    @Test
    void testHandleNotFoundException_withInnerException() {
        NotFoundException ex = new NotFoundException("Resource not found");

        ResponseEntity<ErrorResponse> response = handler.handleNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testHandleNotFoundException_withoutMessage() {
        NotFoundException ex = new NotFoundException();

        ResponseEntity<ErrorResponse> response = handler.handleNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Ресурс не найден", response.getBody().getMessage());
    }

    @Test
    void testHandleAccessDeniedException_withoutMessage() {
        AccessDeniedException ex = new AccessDeniedException();

        ResponseEntity<ErrorResponse> response = handler.handleAccessDeniedException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Доступ запрещен", response.getBody().getMessage());
    }

    @Test
    void testHandleFileException_withCause() {
        Exception cause = new Exception("Inner error");
        FileException ex = new FileException("File error", cause);

        ResponseEntity<ErrorResponse> response = handler.handleFileException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("File error", response.getBody().getMessage());
    }

    @Test
    void testHandleGigaChatException_returns503ErrorResponse() {
        GigaChatException ex = new GigaChatException("Не удалось выполнить запрос к GigaChat: HTTP 503");

        ResponseEntity<ErrorResponse> response = handler.handleApplicationException(ex);

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(503, response.getBody().getStatusCode());
        assertEquals("Service Unavailable", response.getBody().getError());
        assertEquals("Не удалось выполнить запрос к GigaChat: HTTP 503", response.getBody().getMessage());
        assertNotNull(response.getBody().getTimestamp());
    }

    @Test
    void testHandleIllegalArgument_returns400() {
        ResponseEntity<ErrorResponse> response = handler.handleIllegalArgument(new IllegalArgumentException("Название обязательно"));

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(400, response.getBody().getStatusCode());
        assertEquals("Bad Request", response.getBody().getError());
        assertEquals("Название обязательно", response.getBody().getMessage());
    }

    @Test
    void testHandleTaskRejected_returns503WithNeutralMessage() {
        ResponseEntity<ErrorResponse> response = handler.handleTaskRejected(
                new TaskRejectedException("Executor [pool] did not accept task"));

        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(ApplicationErrorHandler.OVERLOADED, response.getBody().getMessage());
    }

    @Test
    void testHandleResponseStatus_keepsStatusAndReason() {
        ResponseEntity<ErrorResponse> withReason = handler.handleResponseStatus(
                new ResponseStatusException(HttpStatus.NOT_FOUND, "Узел не является файловым выходом"));
        ResponseEntity<ErrorResponse> withoutReason = handler.handleResponseStatus(
                new ResponseStatusException(HttpStatus.UNSUPPORTED_MEDIA_TYPE));

        assertEquals(HttpStatus.NOT_FOUND, withReason.getStatusCode());
        assertNotNull(withReason.getBody());
        assertEquals("Not Found", withReason.getBody().getError());
        assertEquals("Узел не является файловым выходом", withReason.getBody().getMessage());
        assertEquals(HttpStatus.UNSUPPORTED_MEDIA_TYPE, withoutReason.getStatusCode());
        assertNotNull(withoutReason.getBody());
        assertEquals("Unsupported Media Type", withoutReason.getBody().getMessage());
    }

    @Test
    void testHandleUnexpected_returns500WithoutInternals() {
        ResponseEntity<ErrorResponse> response = handler.handleUnexpected(new IllegalStateException("SQL: select * from secret"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(500, response.getBody().getStatusCode());
        assertEquals("Internal Server Error", response.getBody().getError());
        assertEquals(ApplicationErrorHandler.INTERNAL_ERROR, response.getBody().getMessage());
    }

    /**
     * Архив 55,5 МБ при пределе части multipart 50 МБ: раньше 500 «Внутренняя ошибка сервера» (корп-шлюз отдавал
     * фронту 403 без тела), теперь 413 с понятным текстом и пределом из текста исключения.
     */
    @Test
    void testHandleSizeLimit_multipartPartLimit_returns413WithFileTextAndLimitFromMessage() {
        ResponseEntity<ErrorResponse> response = handler.handleSizeLimit(
                new DataBufferLimitException("Part exceeded the disk usage limit of 52428800 bytes"));

        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(413, response.getBody().getStatusCode());
        assertEquals("Payload Too Large", response.getBody().getError());
        assertEquals("Файл больше допустимого размера 50 МБ — разделите архив на части или загрузите документы по отдельности",
                response.getBody().getMessage());
    }

    @Test
    void testHandleSizeLimit_payloadTooLarge_usesPartLimitFromCause_orBodyTextWithoutLimit() {
        ResponseEntity<ErrorResponse> withCause = handler.handleSizeLimit(new PayloadTooLargeException(
                new DataBufferLimitException("Part exceeded the disk usage limit of 104857600 bytes")));
        ResponseEntity<ErrorResponse> withoutCause = handler.handleSizeLimit(new PayloadTooLargeException(null));

        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, withCause.getStatusCode());
        assertNotNull(withCause.getBody());
        assertTrue(withCause.getBody().getMessage().startsWith("Файл больше допустимого размера 100 МБ"),
                withCause.getBody().getMessage());
        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, withoutCause.getStatusCode());
        assertNotNull(withoutCause.getBody());
        assertEquals("Тело запроса больше допустимого размера", withoutCause.getBody().getMessage());
    }

    /**
     * Обработчик глобальный: предел буфера кодека JSON ({@code spring.codec.max-in-memory-size}, 256 КБ) — не файл
     * и не архив, текст про тело запроса с реальным пределом из сообщения.
     */
    @Test
    void testHandleSizeLimit_codecBufferLimit_returnsBodyTextInKilobytes() {
        ResponseEntity<ErrorResponse> buffered = handler.handleSizeLimit(new PayloadTooLargeException(
                new DataBufferLimitException("Exceeded limit on max bytes to buffer : 262144")));
        ResponseEntity<ErrorResponse> perObject = handler.handleSizeLimit(
                new DataBufferLimitException("Exceeded limit on max bytes per JSON object: 262144"));

        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, buffered.getStatusCode());
        assertNotNull(buffered.getBody());
        assertEquals("Payload Too Large", buffered.getBody().getError());
        assertEquals("Тело запроса больше допустимого размера 256 КБ", buffered.getBody().getMessage());
        assertNotNull(perObject.getBody());
        assertEquals("Тело запроса больше допустимого размера 256 КБ", perObject.getBody().getMessage());
    }

    @Test
    void testHandleSizeLimit_formFieldAndPartHeaders_returnBodyText_notFileText() {
        ResponseEntity<ErrorResponse> formField = handler.handleSizeLimit(
                new DataBufferLimitException("Form field value exceeded the memory usage limit of 65536 bytes"));
        ResponseEntity<ErrorResponse> headers = handler.handleSizeLimit(
                new DataBufferLimitException("Part headers exceeded the memory usage limit of 10240 bytes"));
        ResponseEntity<ErrorResponse> noLimit = handler.handleSizeLimit(new DataBufferLimitException("limit exceeded"));

        assertNotNull(formField.getBody());
        assertEquals("Тело запроса больше допустимого размера 64 КБ", formField.getBody().getMessage());
        assertNotNull(headers.getBody());
        assertEquals("Тело запроса больше допустимого размера 10 КБ", headers.getBody().getMessage());
        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, noLimit.getStatusCode());
        assertNotNull(noLimit.getBody());
        assertEquals(ApplicationErrorHandler.BODY_TOO_LARGE, noLimit.getBody().getMessage());
    }

    @Test
    void testHandleFileTooLarge_returns413WithFileName() {
        ResponseEntity<ErrorResponse> response = handler.handleFileTooLarge(
                new FileTooLargeException("1.2 Опыт ЭЦС.zip", 100L * 1024 * 1024));

        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Payload Too Large", response.getBody().getError());
        assertEquals("Файл «1.2 Опыт ЭЦС.zip» больше допустимого размера 100 МБ — разделите архив на части "
                + "или загрузите документы по отдельности", response.getBody().getMessage());
    }

    @Test
    void testHandleDecoding_tooManyParts_returns413_otherErrors_return500() {
        ResponseEntity<ErrorResponse> tooMany = handler.handleDecoding(new DecodingException("Too many parts (129/128 allowed)"));
        ResponseEntity<ErrorResponse> broken = handler.handleDecoding(new DecodingException("Could not find first boundary"));

        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, tooMany.getStatusCode());
        assertNotNull(tooMany.getBody());
        assertEquals("Слишком много файлов в одном запросе загрузки (больше 128) — загрузите документы несколькими партиями",
                tooMany.getBody().getMessage());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, broken.getStatusCode());
        assertNotNull(broken.getBody());
        assertEquals(ApplicationErrorHandler.INTERNAL_ERROR, broken.getBody().getMessage());
    }

    @Test
    void testLongMessageIsTruncatedToSchemaLimit() {
        ResponseEntity<ErrorResponse> truncated = handler.handleIllegalArgument(new IllegalArgumentException("x".repeat(600)));
        ResponseEntity<ErrorResponse> exact = handler.handleIllegalArgument(new IllegalArgumentException("y".repeat(255)));

        assertNotNull(truncated.getBody());
        assertEquals(ErrorResponse.MESSAGE_MAX_LENGTH, truncated.getBody().getMessage().length());
        assertTrue(truncated.getBody().getMessage().endsWith("…"));
        assertNotNull(exact.getBody());
        assertEquals("y".repeat(255), exact.getBody().getMessage());
    }
}
