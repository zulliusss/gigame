package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.PlatformTransactionManager;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.contains;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты фоновой обработки файла базы знаний: разбор, запись текста, индексация.
 */
@ExtendWith(MockitoExtension.class)
class KBUploadProcessorTest {

    @Mock
    private DocumentService documentService;
    @Mock
    private DocumentIndexService indexService;
    @Mock
    private DocumentRepository documentRepository;
    @Mock
    private PlatformTransactionManager transactionManager;

    private KBUploadProcessor processor;
    private KBUploadProcessor.PendingUpload upload;
    private Document document;

    @BeforeEach
    void setUp() {
        processor = new KBUploadProcessor(transactionManager, documentService, indexService, documentRepository);
        document = new Document();
        document.setId(UUID.randomUUID());
        document.setFilename("act.pdf");
        upload = new KBUploadProcessor.PendingUpload(UUID.randomUUID(), document.getId(), UUID.randomUUID(),
                "USER1", "act.pdf", "pdf", "%PDF".getBytes(StandardCharsets.UTF_8));
    }

    @Test
    void process_extractsText_savesIt_andIndexes() {
        when(documentService.extractText("act.pdf", "pdf", upload.content())).thenReturn("Акт приёмки");
        when(documentRepository.findById(document.getId())).thenReturn(Optional.of(document));
        when(documentRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        processor.process(upload);

        assertEquals("Акт приёмки", document.getExtractedText());
        verify(indexService).indexKBDocument(upload.kbId(), document.getId(), upload.kbDocId());
        verify(indexService, never()).markIndexingFailed(any(), any(), any(), any());
    }

    @Test
    void process_parseFailure_marksErrorWithReason_andSkipsIndexing() {
        when(documentService.extractText(any(), any(), any()))
                .thenThrow(new FileException("Failed to extract text from act.pdf"));

        processor.process(upload);

        verify(indexService).markIndexingFailed(eq(upload.kbId()), eq(document.getId()), eq(upload.kbDocId()),
                contains("Не удалось извлечь текст: Failed to extract text from act.pdf"));
        verify(indexService, never()).indexKBDocument(any(), any(), any());
        verify(documentRepository, never()).save(any());
    }

    @Test
    void process_documentGone_marksError() {
        when(documentService.extractText(any(), any(), any())).thenReturn("текст");
        when(documentRepository.findById(any())).thenReturn(Optional.empty());

        processor.process(upload);

        verify(indexService).markIndexingFailed(eq(upload.kbId()), eq(document.getId()), eq(upload.kbDocId()),
                contains("Документ не найден"));
        verify(indexService, never()).indexKBDocument(any(), any(), any());
    }

    @Test
    void processAsync_runsUnderUploadingUser() {
        List<String> users = new ArrayList<>();
        when(documentService.extractText(any(), any(), any())).thenAnswer(inv -> {
            users.add(CurrentUserHolder.getCurrentUser());
            return "текст";
        });
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        when(documentRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        processor.processAsync(upload);

        assertEquals(List.of("USER1"), users);
        assertTrue(document.getExtractedText().contains("текст"));
    }
}
