package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.metadata.ChatGenerationMetadata;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.env.MockEnvironment;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.exception.GigaChatRefusedException;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Распознавание отказа цензора GigaChat: finish_reason=blacklist (основной признак), три текста отказа пробы API,
 * типовые фразы, регистр и переносы, настраиваемые фразы {@code app.gigachat.refusal-phrases}, отсутствие ложных
 * срабатываний на JSON, таблицах и длинных ответах, маркер отклонённой части, текст ошибки узла с цитатой отказа.
 */
class GigaChatRefusalTest {

    /** Ответ GigaChat узлу «Обработка» на ТЗ аудита пожарной безопасности (корп-контур, 16.09.2026). */
    static final String INCIDENT_REFUSAL = "Как и любая языковая модель, GigaChat не обладает собственным мнением и не "
            + "транслирует мнение своих разработчиков. Ответ сгенерирован нейросетевой моделью, обученной на открытых "
            + "данных, в которых может содержаться неточная или ошибочная информация. Во избежание неправильного "
            + "толкования, разговоры на некоторые темы временно ограничены.";
    /** Второй текст отказа цензора (проба API ключом стенда, 16.09.2026). */
    static final String PROBE_REFUSAL_SENSITIVE = "Генеративные языковые модели не обладают собственным мнением — их "
            + "ответы являются обобщением информации, находящейся в открытом доступе. Чтобы избежать ошибок и "
            + "неправильного толкования, разговоры на чувствительные темы могут быть ограничены.";
    /** Третий текст отказа цензора (проба API ключом стенда, 16.09.2026). */
    static final String PROBE_REFUSAL_APOLOGY = "К сожалению, иногда генеративные языковые модели могут создавать "
            + "некорректные ответы, основанные на открытых источниках. Во избежание неправильного толкования, ответы на "
            + "вопросы, связанные с чувствительными темами, временно ограничены. Благодарим за понимание.";
    /** Строка извещения ЕИС 32616332046 (ОПС). */
    static final String NOTICE_LINE = "оказание услуг по техническому обслуживанию, планово-предупредительному и текущему "
            + "ремонту систем пожарной сигнализации, систем оповещения и управления эвакуацией людей при пожаре";

    private final GigaChatRefusal refusal = GigaChatRefusal.defaults();

    @Test
    void recognizesIncidentRefusalAndTypicalPhrases() {
        assertTrue(refusal.isRefusal(INCIDENT_REFUSAL));
        assertTrue(refusal.isRefusal("Не люблю менять тему разговора, но вот сейчас тот самый случай."));
        assertTrue(refusal.isRefusal("Что-то в вашем вопросе меня смущает. Может, поговорим на другую тему?"));
        assertTrue(refusal.isRefusal("К сожалению, я не могу обсуждать эту тему."));
        assertTrue(refusal.isRefusal("Предпочту не отвечать на этот вопрос."));
    }

    @Test
    void ignoresCaseYoAndLineBreaks() {
        assertTrue(refusal.isRefusal("  ЧТО-ТО В ВАШЕМ ВОПРОСЕ МЕНЯ СМУЩАЕТ."));
        assertTrue(refusal.isRefusal("GigaChat не обладает\nсобственным   мнением."));
        assertTrue(new GigaChatRefusal(List.of("Давайте сменим тему, всё")).isRefusal("давайте сменим тему, все ясно"));
    }

    @Test
    void jsonCodeBlockAndTableAnswersAreNotRefusals() {
        assertFalse(refusal.isRefusal("{\"предмет\": \"" + NOTICE_LINE + "\", "
                + "\"примечание\": \"разговоры на некоторые темы временно ограничены\"}"));
        assertFalse(refusal.isRefusal("[{\"критерий\": \"Технология 1\", \"значение\": \"предпочту не отвечать\"}]"));
        assertFalse(refusal.isRefusal("```json\n{\"ответ\": \"не могу обсуждать эту тему\"}\n```"));
        assertFalse(refusal.isRefusal("| № | Требование |\n|---|---|\n| 1 | Что-то в вашем вопросе меня смущает |"));
    }

    @Test
    void longAnswerWithPhraseNotAtStartIsNotRefusal() {
        String intro = "Предмет закупки: " + NOTICE_LINE + ". ";
        String phraseLater = intro + "Замечание заказчика: «предпочту не отвечать» — цитата из протокола. ";
        String longAnswer = phraseLater + (NOTICE_LINE + ". ").repeat(10);
        assertTrue(longAnswer.length() > GigaChatRefusal.LONG_ANSWER);
        assertFalse(refusal.isRefusal(longAnswer));
        // короткий ответ с той же фразой в окне — отказ; фраза за окном 600 знаков — нет
        assertTrue(refusal.isRefusal(phraseLater));
        assertFalse(refusal.isRefusal((NOTICE_LINE + ". ").repeat(4) + "Предпочту не отвечать."));
        // длинный текст, начинающийся с отказа, — отказ
        assertTrue(refusal.isRefusal(INCIDENT_REFUSAL + "\n" + (NOTICE_LINE + ". ").repeat(10)));
    }

    @Test
    void ordinaryAnswersAndOcrRefusalAreNotCensorRefusals() {
        assertFalse(refusal.isRefusal(null));
        assertFalse(refusal.isRefusal("   "));
        assertFalse(refusal.isRefusal("Заявка №219 к Договору № АБ-С-ИТ-2020"));
        // отказ OCR (ScanOcrService.isRefusal) — другой случай
        assertFalse(refusal.isRefusal("Извини, но в предоставленном контексте нет текста страницы отсканированного документа."));
    }

    @Test
    void extraPhrasesFromSettingsListOrCommaString() {
        var list = new GigaChatRefusal(new MockEnvironment()
                .withProperty(GigaChatRefusal.PHRASES_PROPERTY + "[0]", "Давайте Сменим Тему")
                .withProperty(GigaChatRefusal.PHRASES_PROPERTY + "[1]", "   "));
        assertTrue(list.isRefusal("Давайте сменим тему и поговорим о другом."));
        assertFalse(list.isRefusal("Предмет закупки: " + NOTICE_LINE));
        assertTrue(list.isRefusal(INCIDENT_REFUSAL));

        var comma = new GigaChatRefusal(new MockEnvironment()
                .withProperty(GigaChatRefusal.PHRASES_PROPERTY, "первая фраза отказа, вторая фраза отказа"));
        assertTrue(comma.isRefusal("Вторая фраза отказа."));
        assertTrue(comma.isRefusal("Первая фраза отказа."));
    }

    @Test
    void applicationYamlDeclaresEmptyPhraseList() throws IOException {
        var environment = new StandardEnvironment();
        for (PropertySource<?> source : new YamlPropertySourceLoader().load("application",
                new ClassPathResource("application.yaml"))) {
            environment.getPropertySources().addLast(source);
        }
        assertTrue(environment.containsProperty(GigaChatRefusal.PHRASES_PROPERTY));

        var fromYaml = new GigaChatRefusal(environment);

        assertTrue(fromYaml.isRefusal(INCIDENT_REFUSAL));
        assertFalse(fromYaml.isRefusal("Предмет закупки: " + NOTICE_LINE));
    }

    @Test
    void recognizesAllThreeCensorTextsFromApiProbe() {
        assertTrue(refusal.isRefusal(PROBE_REFUSAL_SENSITIVE));
        assertTrue(refusal.isRefusal(PROBE_REFUSAL_APOLOGY));
        assertTrue(refusal.isRefusal(INCIDENT_REFUSAL));
        // обычный анализ со словами «чувствительные данные» и «временно» — не отказ
        assertFalse(refusal.isRefusal("Требования к защите: персональные и чувствительные данные участников "
                + "хранятся временно, доступ ограничен."));
    }

    @Test
    void blacklistFinishReasonIsPrimarySign() {
        assertTrue(GigaChatRefusal.isBlacklisted(response("любой текст", "blacklist")));
        assertTrue(GigaChatRefusal.isBlacklisted(response("", "BLACKLIST")));
        assertTrue(GigaChatRefusal.isBlacklisted(response("", "response_blacklist")));
        assertFalse(GigaChatRefusal.isBlacklisted(response(INCIDENT_REFUSAL, "stop")));
        assertFalse(GigaChatRefusal.isBlacklisted(response("{}", "length")));
        assertFalse(GigaChatRefusal.isBlacklisted(new ChatResponse(List.of(new Generation(new AssistantMessage("без метаданных"))))));
        assertFalse(GigaChatRefusal.isBlacklisted(new ChatResponse(List.of())));
        assertFalse(GigaChatRefusal.isBlacklisted(null));
    }

    @Test
    void partMarkerNamesPartSpanAndFragmentStart() {
        assertEquals("[часть 2/3 (знаки 2001–4180 контекста) не обработана: модель отказалась — ограничение темы "
                + "GigaChat; начало фрагмента: «<<<Документ: ТЗ приложение 3.docx>>> Чек-лист: хранение ЛВЖ …»]",
                GigaChatRefusal.partMarker(2, 3, 2001, 4180, "<<<Документ: ТЗ приложение 3.docx>>>\nЧек-лист: хранение "
                        + "ЛВЖ и ГЖ, проведение огневых работ"));
        assertEquals("[часть 1/2 (знаки 1–5 контекста) не обработана: модель отказалась — ограничение темы GigaChat; "
                + "начало фрагмента: «коротко»]", GigaChatRefusal.partMarker(1, 2, 1, 5, " коротко\n"));
    }

    @Test
    void markerQuoteOfJsonFragmentDoesNotBecomeFirstJsonOfAnswer() {
        String marker = GigaChatRefusal.partMarker(2, 2, 2001, 4000, "{\"лот\": 1, \"цена\": 100}\n[{\"лот\": 2}]\nТЗ");
        String merged = "[{\"критерий\":\"Опыт\",\"вес\":10},{\"критерий\":\"Цена\",\"вес\":90}]";
        String answer = "=== Ответ собран из 2 частей (запрос разделён из-за ограничения темы GigaChat), JSON-массивы частей "
                + "объединены ===\n" + marker + "\n" + merged;

        assertTrue(marker.endsWith("начало фрагмента: «(\"лот\": 1, \"цена\": 100) ((\"лот\": 2)) ТЗ»]"), marker);
        // Excel-выход, выражения и Форма 3 берут первый JSON ответа — это объединённый массив, а не цитата маркера
        assertEquals(merged, LlmJson.first(answer, LlmJson.OBJECT.or(LlmJson.ARRAY_OF_OBJECTS_OR_EMPTY)).first().node().toString());
        assertEquals(merged, LlmJson.first(answer, LlmJson.ANY).first().node().toString());
    }

    @Test
    void refusedExceptionQuotesFirst160CharsOfRefusal() {
        var e = new GigaChatRefusedException(INCIDENT_REFUSAL);

        assertInstanceOf(GigaChatException.class, e);
        assertEquals(INCIDENT_REFUSAL, e.getRefusal());
        assertEquals("Модель отказалась обрабатывать запрос (ограничение темы GigaChat): «"
                + INCIDENT_REFUSAL.substring(0, GigaChatRefusedException.QUOTE_LIMIT)
                + "…» — измените формулировку или сократите документ", e.getMessage());
        assertEquals("Модель отказалась обрабатывать запрос (ограничение темы GigaChat): «Что-то в вашем вопросе "
                + "меня смущает.» — измените формулировку или сократите документ",
                GigaChatRefusedException.message("Что-то в вашем\nвопросе меня смущает."));
    }

    /** Ответ модели с заданной причиной завершения. */
    static ChatResponse response(String text, String finishReason) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(text),
                ChatGenerationMetadata.builder().finishReason(finishReason).build())));
    }
}
