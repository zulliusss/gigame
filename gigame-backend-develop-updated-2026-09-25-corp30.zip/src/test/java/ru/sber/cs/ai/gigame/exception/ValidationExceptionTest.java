package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Исключение проверки данных запроса: статус 422 и сообщение для {@code ErrorResponse}.
 */
class ValidationExceptionTest {

    @Test
    void testValidationException_status422WithMessage() {
        ValidationException ex = new ValidationException("Название промпта длиннее 255 символов: 300");

        assertEquals("Название промпта длиннее 255 символов: 300", ex.getMessage());
        assertEquals(422, ex.getStatusCode());
        assertNull(ex.getDetails());
    }
}
