package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.codec.ServerSentEvent;
import ru.sber.cs.ai.gigame.config.JacksonConfig;
import ru.sber.cs.ai.gigame.dto.scenario.UploadStatusResponse;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.MapPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты фоновой обработки загруженных документов (асинхронный режим загрузки).
 */
@ExtendWith(MockitoExtension.class)
class ScenarioUploadTaskServiceTest {

    /**
     * Ключи схемы UploadStatusResponse статической спецификации.
     */
    private static final Set<String> SCHEMA_KEYS = Set.of("status", "files", "documents", "warnings", "error");

    /**
     * Загружающий пользователь.
     */
    private static final String USER = "USER1";

    /**
     * Другой пользователь того же общего сценария.
     */
    private static final String OTHER_USER = "USER2";

    @Mock
    private ScenarioService scenarioService;
    @Mock
    private DocsTextCacheService docsTextCacheService;

    @InjectMocks
    private ScenarioUploadTaskService service;

    private static List<ScenarioService.RawFile> rawFiles() {
        return List.of(new ScenarioService.RawFile("файл.txt", "текст".getBytes()));
    }

    private static ServerSentEvent<Map<String, Object>> event(Map<String, Object> data) {
        return ServerSentEvent.<Map<String, Object>>builder().data(data).build();
    }

    private static Set<String> jsonKeys(UploadStatusResponse status) throws JsonProcessingException {
        ObjectMapper mapper = new JacksonConfig().objectMapper();
        JsonNode node = mapper.readTree(mapper.writeValueAsString(status));
        Set<String> keys = new HashSet<>();
        node.fieldNames().forEachRemaining(keys::add);
        return keys;
    }

    /**
     * Ключ кэша документов сценария загружающего пользователя.
     */
    private static UUID userKey(UUID scenarioId) {
        return DocsTextCacheService.scenarioKey(scenarioId, USER);
    }

    /**
     * Дожидается выхода задачи загружающего пользователя из processing.
     */
    private UploadStatusResponse awaitFinished(UUID scenarioId) throws InterruptedException {
        return awaitFinished(scenarioId, USER);
    }

    /**
     * Дожидается выхода задачи пользователя из processing (короткий поллинг вместо sleep).
     */
    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    private UploadStatusResponse awaitFinished(UUID scenarioId, String userId) throws InterruptedException {
        for (int i = 0; i < 200; i++) {
            UploadStatusResponse status = service.status(scenarioId, userId);
            if (!ScenarioUploadTaskService.STATUS_PROCESSING.equals(status.status())) {
                return status;
            }
            Thread.sleep(25);
        }
        return service.status(scenarioId, userId);
    }

    @Test
    void start_parsesFilesInBackground_andCachesDocuments() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), false);
        UploadStatusResponse status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.status());
        assertEquals(1, status.documents());
        assertEquals(1, status.files());
        assertEquals("", status.error());
        assertFalse(service.isProcessing(scenarioId, USER));
        verify(docsTextCacheService).clearCache(userKey(scenarioId));
        verify(docsTextCacheService).appendDocumentTexts(userKey(scenarioId),
                List.of("текст"), List.of("файл.txt"), List.of());
    }

    @Test
    void cancel_whileProcessing_marksTaskFailedAsCancelled_andCachesNothing() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch parsing = new CountDownLatch(1);
        when(scenarioService.parseFiles(anyList(), any())).thenAnswer(invocation -> {
            parsing.countDown();
            try {
                Thread.sleep(TimeUnit.SECONDS.toMillis(30)); // разбор «долгий» — отмена прерывает его interrupt-ом
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new FileException("Обработка файлов прервана", e);
            }
            return List.of(new DocumentText("файл.txt", "текст"));
        });

        service.start(scenarioId, USER, rawFiles(), false);
        assertTrue(parsing.await(5, TimeUnit.SECONDS));
        assertTrue(service.cancel(scenarioId, USER));
        UploadStatusResponse status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_FAILED, status.status());
        assertEquals(ScenarioUploadTaskService.CANCELLED_MESSAGE, status.error());
        assertFalse(service.isProcessing(scenarioId, USER));
        verify(docsTextCacheService, never()).appendDocumentTexts(any(), anyList(), anyList(), anyList());
        verify(docsTextCacheService).unmarkUploading(userKey(scenarioId));
        // отменять больше нечего — повторная отмена и отмена без задачи ничего не делают
        assertFalse(service.cancel(scenarioId, USER));
        assertFalse(service.cancel(UUID.randomUUID(), USER));
    }

    @Test
    void status_whileProcessing_showsOcrPageProgressInErrorField() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch reported = new CountDownLatch(1);
        CountDownLatch release = new CountDownLatch(1);
        when(scenarioService.parseFiles(anyList(), any())).thenAnswer(invocation -> {
            List<ServerSentEvent<Map<String, Object>>> events = invocation.getArgument(1);
            events.add(event(Map.of("type", "upload_ocr", "file", "скан.pdf")));
            events.add(event(Map.of("type", "upload_ocr_page", "file", "скан.pdf", "page", 3, "total", 40)));
            reported.countDown();
            release.await(5, TimeUnit.SECONDS);
            events.add(event(Map.of("type", "upload_parsed", "file", "скан.pdf", "chars", 10)));
            return List.of(new DocumentText("скан.pdf", "текст"));
        });
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), false);
        assertTrue(reported.await(5, TimeUnit.SECONDS));
        UploadStatusResponse processing = service.status(scenarioId, USER);

        assertEquals(ScenarioUploadTaskService.STATUS_PROCESSING, processing.status());
        assertEquals("распознаётся скан «скан.pdf»: страница 3 из 40", processing.error());
        release.countDown();
        UploadStatusResponse done = awaitFinished(scenarioId);
        // после завершения документа ход OCR не показывается, поле error — снова про ошибку задачи
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, done.status());
        assertEquals("", done.error());
    }

    @Test
    void cancel_otherUsersTask_isNotAffected() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch release = new CountDownLatch(1);
        when(scenarioService.parseFiles(anyList(), any())).thenAnswer(invocation -> {
            release.await(5, TimeUnit.SECONDS);
            return List.of(new DocumentText("файл.txt", "текст"));
        });
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), false);

        assertFalse(service.cancel(scenarioId, OTHER_USER));
        assertTrue(service.isProcessing(scenarioId, USER));
        release.countDown();
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId).status());
    }

    @Test
    void start_appendMode_doesNotClearCache() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId)))
                .thenReturn(List.of("уже загруженный"));

        service.start(scenarioId, USER, rawFiles(), true);
        UploadStatusResponse status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.status());
        assertEquals(2, status.documents());
        verify(docsTextCacheService, never()).clearCache(userKey(scenarioId));
    }

    @Test
    void start_parsingError_marksTaskFailedWithMessage() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenThrow(new FileException("Архив пуст или повреждён: битый.zip"));

        service.start(scenarioId, USER, rawFiles(), false);
        UploadStatusResponse status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_FAILED, status.status());
        assertTrue(status.error().contains("битый.zip"));
        assertFalse(service.isProcessing(scenarioId, USER));
    }

    @Test
    void start_whileProcessing_throwsFileException() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch releaseParsing = new CountDownLatch(1);
        lenient().when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            releaseParsing.await(5, TimeUnit.SECONDS);
            return List.of();
        });

        service.start(scenarioId, USER, rawFiles(), false);
        assertTrue(service.isProcessing(scenarioId, USER));
        var rawFiles = rawFiles();
        assertThrows(FileException.class, () -> service.start(scenarioId, USER, rawFiles, false));
        releaseParsing.countDown();
        awaitFinished(scenarioId);
    }

    @Test
    void start_otherUserWhileProcessing_doesNotThrow() throws InterruptedException {
        // общий сценарий: загрузка USER1 ещё разбирается — USER2 не получает 422, не ждёт и не видит чужую задачу
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch releaseParsing = new CountDownLatch(1);
        lenient().when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            releaseParsing.await(5, TimeUnit.SECONDS);
            return List.of();
        });

        service.start(scenarioId, USER, rawFiles(), false);
        assertTrue(service.isProcessing(scenarioId, USER));
        assertFalse(service.isProcessing(scenarioId, OTHER_USER));
        assertEquals(ScenarioUploadTaskService.STATUS_NONE, service.status(scenarioId, OTHER_USER).status());

        var rawFiles = rawFiles();
        assertDoesNotThrow(() -> service.start(scenarioId, OTHER_USER, rawFiles, false));
        assertTrue(service.isProcessing(scenarioId, OTHER_USER));
        // своя повторная загрузка по-прежнему блокируется и ничего не очищает
        assertThrows(FileException.class, () -> service.start(scenarioId, USER, rawFiles, false));
        verify(docsTextCacheService).clearCache(userKey(scenarioId));
        verify(docsTextCacheService).clearCache(DocsTextCacheService.scenarioKey(scenarioId, OTHER_USER));

        releaseParsing.countDown();
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId).status());
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId, OTHER_USER).status());
    }

    @Test
    void status_otherUsersTask_isNotVisible() throws InterruptedException {
        // чужая упавшая задача (ошибка с именем чужого файла) не попадает в статус другого пользователя
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenThrow(new FileException("Архив пуст или повреждён: чужой.zip"));

        service.start(scenarioId, USER, rawFiles(), false);
        assertEquals(ScenarioUploadTaskService.STATUS_FAILED, awaitFinished(scenarioId).status());

        UploadStatusResponse other = service.status(scenarioId, OTHER_USER);
        assertEquals(ScenarioUploadTaskService.STATUS_NONE, other.status());
        assertEquals(0, other.files());
        assertEquals(List.of(), other.warnings());
        assertEquals("", other.error());
    }

    @Test
    void start_notAppend_clearsOnlyOwnDocuments() throws InterruptedException {
        // первая партия USER2 очищает только его кэш: документы USER1 того же сценария не трогаются
        UUID scenarioId = UUID.randomUUID();
        UUID otherKey = DocsTextCacheService.scenarioKey(scenarioId, OTHER_USER);
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);

        service.start(scenarioId, OTHER_USER, rawFiles(), false);
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId, OTHER_USER).status());

        verify(docsTextCacheService).clearCache(otherKey);
        verify(docsTextCacheService).appendDocumentTexts(otherKey,
                List.of("текст"), List.of("файл.txt"), List.of());
        verify(docsTextCacheService, never()).clearCache(userKey(scenarioId));
        verify(docsTextCacheService, never()).clearCache(scenarioId);
    }

    @Test
    void start_withoutUser_usesAnonymousKey() throws InterruptedException {
        // без X-UserId (null в HTTP, пустая строка в WebSocket) — один пользователь «anonymous», как раньше
        UUID scenarioId = UUID.randomUUID();
        UUID anonymousKey = DocsTextCacheService.scenarioKey(scenarioId, "anonymous");
        when(scenarioService.parseFiles(anyList(), any())).thenReturn(List.of());

        service.start(scenarioId, null, rawFiles(), true);
        UploadStatusResponse status = awaitFinished(scenarioId, "anonymous");

        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.status());
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, service.status(scenarioId, "").status());
        verify(docsTextCacheService).markUploading(anonymousKey);
        verify(docsTextCacheService).unmarkUploading(anonymousKey);
    }

    @Test
    @SuppressWarnings("java:S2925")
    void status_whileProcessing_containsOnlySchemaKeysAndWarnings() throws Exception {
        // ход разбора (parsed/ocr/message) в схеме UploadStatusResponse не описан — шлюз отклонял каждый опрос
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch releaseParsing = new CountDownLatch(1);
        lenient().when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            List<ServerSentEvent<Map<String, Object>>> events = inv.getArgument(1);
            events.add(event(Map.of("type", "upload_ocr", "file", "скан.pdf")));
            events.add(event(Map.of("type", "upload_parsed", "file", "акт.pdf", "chars", 100)));
            events.add(event(Map.of("type", "upload_warning", "file", "скан.pdf",
                    "message", "PDF-скан распознан через GigaChat — проверьте суммы")));
            releaseParsing.await(5, TimeUnit.SECONDS);
            return List.of();
        });

        service.start(scenarioId, USER, rawFiles(), false);
        UploadStatusResponse status = service.status(scenarioId, USER);
        for (int i = 0; i < 100 && status.warnings().isEmpty(); i++) {
            Thread.sleep(20);
            status = service.status(scenarioId, USER);
        }

        assertEquals(ScenarioUploadTaskService.STATUS_PROCESSING, status.status());
        // ход разбора — через документированное поле documents: разобрано документов текущей партии
        assertEquals(1, status.documents());
        assertEquals(List.of("скан.pdf: PDF-скан распознан через GigaChat — проверьте суммы"), status.warnings());
        assertEquals(SCHEMA_KEYS, jsonKeys(status));
        releaseParsing.countDown();
        UploadStatusResponse finished = awaitFinished(scenarioId);
        assertEquals(SCHEMA_KEYS, jsonKeys(finished));
        // после завершения documents — документов в кэше (разбор вернул пустой список)
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, finished.status());
        assertEquals(0, finished.documents());
    }

    @Test
    void status_failedTask_limitsWarningsAndErrorBySchema() throws InterruptedException {
        // граничный случай [scenario-b #11]: больше 1000 предупреждений и длинные тексты
        UUID scenarioId = UUID.randomUUID();
        String longText = "ж".repeat(3000);
        when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            List<ServerSentEvent<Map<String, Object>>> events = inv.getArgument(1);
            List<ServerSentEvent<Map<String, Object>>> batch = new ArrayList<>();
            for (int i = 0; i < 1005; i++) {
                batch.add(event(Map.of("type", "upload_warning", "file", "скан" + i + ".pdf",
                        "message", i == 0 ? longText : "требуется ручная проверка")));
            }
            events.addAll(batch);
            throw new FileException("Слишком много документов: " + longText);
        });

        service.start(scenarioId, USER, rawFiles(), false);
        UploadStatusResponse status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_FAILED, status.status());
        assertEquals(UploadStatusResponse.MAX_WARNINGS, status.warnings().size());
        assertTrue(status.warnings().get(0).startsWith("скан0.pdf: "));
        assertEquals(UploadStatusResponse.MAX_TEXT_LENGTH, status.warnings().get(0).length());
        assertEquals("скан999.pdf: требуется ручная проверка", status.warnings().get(999));
        assertEquals(UploadStatusResponse.MAX_TEXT_LENGTH, status.error().length());
    }

    @Test
    void status_withoutTask_returnsNone() throws JsonProcessingException {
        UploadStatusResponse status = service.status(UUID.randomUUID(), USER);
        assertEquals(ScenarioUploadTaskService.STATUS_NONE, status.status());
        assertEquals(0, status.files());
        assertEquals(0, status.documents());
        assertEquals(List.of(), status.warnings());
        assertEquals("", status.error());
        assertEquals(SCHEMA_KEYS, jsonKeys(status));
    }

    @Test
    void start_marksScenarioUploading_untilTaskFinishes() throws InterruptedException {
        // пока идёт разбор партии, кэш сценария помечен занятым (не вычищается по TTL), опрос статуса продлевает записи
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch release = new CountDownLatch(1);
        when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            release.await(5, TimeUnit.SECONDS);
            return List.of(new DocumentText("файл.txt", "текст"));
        });
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), true);
        verify(docsTextCacheService).markUploading(userKey(scenarioId));
        verify(docsTextCacheService, never()).unmarkUploading(userKey(scenarioId));
        service.status(scenarioId, USER);
        verify(docsTextCacheService).touch(userKey(scenarioId));
        // опрос другого пользователя не продлевает записи загружающего (touch по его ключу — всё ещё один раз)
        service.status(scenarioId, OTHER_USER);
        verify(docsTextCacheService, times(1)).touch(userKey(scenarioId));
        verify(docsTextCacheService, never()).touch(DocsTextCacheService.scenarioKey(scenarioId, OTHER_USER));

        release.countDown();
        UploadStatusResponse status = awaitFinished(scenarioId);
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.status());
        verify(docsTextCacheService).unmarkUploading(userKey(scenarioId));
    }

    @Test
    void start_concurrentRequestsOfOneUser_registerSingleTask() throws InterruptedException {
        // две вкладки жмут «Загрузить» одновременно: проверка «разбор уже идёт» и регистрация задачи
        // атомарны, поэтому на ключ становится ровно одна задача (вторая получает 422)
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch release = new CountDownLatch(1);
        CountDownLatch parsingStarted = new CountDownLatch(1);
        lenient().when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            parsingStarted.countDown();
            release.await(30, TimeUnit.SECONDS);
            return List.of(new DocumentText("файл.txt", "текст"));
        });
        lenient().when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        lenient().when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());
        AtomicInteger accepted = new AtomicInteger();
        AtomicInteger rejected = new AtomicInteger();
        int attempts = 4;
        CountDownLatch ready = new CountDownLatch(attempts);
        CountDownLatch go = new CountDownLatch(1);
        CountDownLatch finished = new CountDownLatch(attempts);
        ExecutorService threads = Executors.newFixedThreadPool(attempts);

        for (int i = 0; i < attempts; i++) {
            threads.submit(() -> tryStart(scenarioId, ready, go, finished, accepted, rejected));
        }
        assertTrue(ready.await(30, TimeUnit.SECONDS));
        go.countDown();
        assertTrue(finished.await(30, TimeUnit.SECONDS));
        threads.shutdownNow();

        assertEquals(1, accepted.get());
        assertEquals(attempts - 1, rejected.get());
        assertTrue(parsingStarted.await(30, TimeUnit.SECONDS));
        verify(docsTextCacheService, times(1)).markUploading(userKey(scenarioId));
        verify(scenarioService, times(1)).parseFiles(anyList(), any());

        release.countDown();
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId).status());
    }

    @Test
    void parseThreads_fromSettings_sizesPoolAndShutdownStopsIt() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        ReflectionTestUtils.setField(service, "parseThreads", 3);
        lenient().when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        lenient().when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        lenient().when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), false);
        awaitFinished(scenarioId);

        ThreadPoolExecutor pool = (ThreadPoolExecutor) ReflectionTestUtils.getField(service, "executor");
        assertEquals(3, pool.getMaximumPoolSize());

        service.shutdown();
        assertTrue(pool.isShutdown(), "пул фонового разбора не остановлен");
    }

    @Test
    void parseThreads_belowOne_fallsBackToSingleThread() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        ReflectionTestUtils.setField(service, "parseThreads", 0);
        lenient().when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        lenient().when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        lenient().when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), false);
        awaitFinished(scenarioId);

        ThreadPoolExecutor pool = (ThreadPoolExecutor) ReflectionTestUtils.getField(service, "executor");
        assertEquals(1, pool.getMaximumPoolSize());
        service.shutdown();
    }

    @Test
    void parseThreads_property_isWiredBySpringAndPoolClosedOnShutdown() throws InterruptedException {
        // имя настройки app.upload.parse-threads и остановка пула при закрытии контекста
        UUID scenarioId = UUID.randomUUID();
        lenient().when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        lenient().when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        lenient().when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());
        ThreadPoolExecutor pool;
        ScenarioUploadTaskService springService;
        try (var context = new AnnotationConfigApplicationContext()) {
            context.getEnvironment().getPropertySources().addFirst(
                    new MapPropertySource("тест", Map.of("app.upload.parse-threads", "5")));
            context.registerBean(PropertySourcesPlaceholderConfigurer.class);
            context.registerBean(ScenarioService.class, () -> scenarioService);
            context.registerBean(DocsTextCacheService.class, () -> docsTextCacheService);
            context.registerBean(ScenarioUploadTaskService.class);
            context.refresh();
            springService = context.getBean(ScenarioUploadTaskService.class);
            springService.start(scenarioId, USER, rawFiles(), false);
            for (int i = 0; i < 200 && ScenarioUploadTaskService.STATUS_PROCESSING
                    .equals(springService.status(scenarioId, USER).status()); i++) {
                Thread.sleep(25); // NOSONAR java:S2925 — опрос статуса фонового разбора с паузой (с ограничением по числу итераций)
            }
            pool = (ThreadPoolExecutor) ReflectionTestUtils.getField(springService, "executor");
            assertEquals(5, pool.getMaximumPoolSize());
        }

        assertTrue(pool.isShutdown(), "пул фонового разбора не остановлен при закрытии контекста");
    }

    @Test
    void shutdown_withoutTasks_doesNotThrow() {
        assertDoesNotThrow(() -> service.shutdown());
    }

    /**
     * Одна одновременная попытка загрузки: все потоки стартуют по общей защёлке,
     * исход (принята/отклонена 422) складывается в счётчики.
     *
     * @param scenarioId идентификатор сценария
     * @param ready      готовность потока к старту
     * @param go         общая защёлка старта
     * @param finished   завершение попытки
     * @param accepted   счётчик принятых загрузок
     * @param rejected   счётчик отклонённых загрузок
     */
    private void tryStart(UUID scenarioId, CountDownLatch ready, CountDownLatch go, CountDownLatch finished,
                          AtomicInteger accepted, AtomicInteger rejected) {
        ready.countDown();
        boolean started = awaitGo(go);
        if (!started) {
            finished.countDown();
            return;
        }
        try {
            service.start(scenarioId, USER, rawFiles(), false);
            accepted.incrementAndGet();
        } catch (FileException e) {
            rejected.incrementAndGet();
        } finally {
            finished.countDown();
        }
    }

    private static boolean awaitGo(CountDownLatch go) {
        try {
            return go.await(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    // -------------------------------------------------------------------------
    // corp15: завершённые задачи вычищаются по TTL; итог синхронной загрузки — в upload-status
    // -------------------------------------------------------------------------

    // -------------------------------------------------------------------------
    // corp23 upload-4 / upload-6 / cache-2: Error в задаче, продление кэша после done, рестарт
    // -------------------------------------------------------------------------

    @Test
    void start_errorInTask_marksTaskFailed_andDoesNotStayProcessing() throws InterruptedException {
        // OutOfMemoryError в потоке задачи глотал FutureTask: задача навсегда processing, сценарий заблокирован
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenThrow(new OutOfMemoryError("Java heap space"))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        lenient().when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        lenient().when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), false);
        UploadStatusResponse status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_FAILED, status.status());
        assertEquals("внутренняя ошибка разбора: OutOfMemoryError: Java heap space", status.error());
        assertFalse(service.isProcessing(scenarioId, USER));
        verify(docsTextCacheService).unmarkUploading(userKey(scenarioId));
        // сценарий не заблокирован: следующая загрузка того же пользователя принимается и завершается
        var rawFiles = rawFiles();
        assertDoesNotThrow(() -> service.start(scenarioId, USER, rawFiles, false));
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId).status());
    }

    @Test
    void status_afterDone_keepsProlongingCacheEntry() throws InterruptedException {
        // опрос статуса после done продлевает жизнь документов в кэше: раньше только во время processing,
        // и комплект устаревал по TTL, пока пользователь читал предупреждения загрузки
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());
        service.start(scenarioId, USER, rawFiles(), false);
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId).status());
        Mockito.clearInvocations(docsTextCacheService);

        service.status(scenarioId, USER);
        service.status(scenarioId, USER);

        verify(docsTextCacheService, times(2)).touch(userKey(scenarioId));
        // чужой опрос и опрос без задачи ничего не продлевают
        service.status(scenarioId, OTHER_USER);
        verify(docsTextCacheService, never()).touch(DocsTextCacheService.scenarioKey(scenarioId, OTHER_USER));
    }

    @Test
    void status_afterFailed_alsoProlongsCacheEntry() throws InterruptedException {
        // догрузка упала, но первая партия в кэше жива — её тоже не надо терять по TTL
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenThrow(new FileException("Архив пуст или повреждён: битый.zip"));
        service.start(scenarioId, USER, rawFiles(), true);
        assertEquals(ScenarioUploadTaskService.STATUS_FAILED, awaitFinished(scenarioId).status());
        Mockito.clearInvocations(docsTextCacheService);

        service.status(scenarioId, USER);

        verify(docsTextCacheService).touch(userKey(scenarioId));
    }

    @Test
    void status_afterServiceRestart_isNone_soClientAsksToUploadAgain() {
        // cache-2: задачи и кэш живут в памяти экземпляра — новый экземпляр (рестарт пода) отдаёт none,
        // и клиент предлагает загрузить документы заново; никакого processing/done от прежней жизни нет
        ScenarioUploadTaskService restarted = new ScenarioUploadTaskService(scenarioService, docsTextCacheService);
        UUID scenarioId = UUID.randomUUID();

        UploadStatusResponse status = restarted.status(scenarioId, USER);

        assertEquals(ScenarioUploadTaskService.STATUS_NONE, status.status());
        assertEquals(0, status.documents());
        assertFalse(restarted.isProcessing(scenarioId, USER));
        verify(docsTextCacheService, never()).touch(any());
    }

    @Test
    void finishedTask_isEvictedAfterTtl() throws InterruptedException {
        ReflectionTestUtils.setField(service, "taskTtlMinutes", 0);
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of());

        service.start(scenarioId, USER, rawFiles(), false);
        UploadStatusResponse status = awaitFinished(scenarioId);

        // TTL = 0: первый же опрос после завершения вычищает запись задачи вместе с её событиями
        assertEquals(ScenarioUploadTaskService.STATUS_NONE, status.status());
        assertFalse(service.isProcessing(scenarioId, USER));
    }

    @Test
    void recordSyncUpload_exposesWarningsThroughStatus() throws JsonProcessingException {
        UUID scenarioId = UUID.randomUUID();
        List<ServerSentEvent<Map<String, Object>>> events = List.of(
                event(Map.of("type", "upload_warning", "file", "пустой.docx", "message", "документ пуст: пустой.docx")),
                event(Map.of("type", "upload_parsed", "file", "пустой.docx", "chars", 0)));

        service.recordSyncUpload(userKey(scenarioId), 1, 3, events);
        UploadStatusResponse status = service.status(scenarioId, USER);

        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.status());
        assertEquals(1, status.files());
        assertEquals(3, status.documents());
        assertEquals(List.of("пустой.docx: документ пуст: пустой.docx"), status.warnings());
        assertEquals("", status.error());
        assertEquals(SCHEMA_KEYS, jsonKeys(status));
        assertFalse(service.isProcessing(scenarioId, USER));
        assertEquals(ScenarioUploadTaskService.STATUS_NONE, service.status(scenarioId, OTHER_USER).status());
    }

    @Test
    void recordSyncUpload_doesNotReplaceRunningTask() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch release = new CountDownLatch(1);
        when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            release.await();
            return List.of();
        });
        service.start(scenarioId, USER, rawFiles(), false);

        service.recordSyncUpload(userKey(scenarioId), 1, 1, List.of());

        assertTrue(service.isProcessing(scenarioId, USER));
        release.countDown();
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, awaitFinished(scenarioId).status());
    }

    @Test
    void start_appendMode_skipsDocumentsAlreadyCachedWithSameNameAndText() throws InterruptedException {
        // повторная догрузка того же архива давала дубли документов — одинаковые по имени и тексту пропускаются с предупреждением
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("архив.zip/акт.pdf", "текст акта"),
                        new DocumentText("архив.zip/акт.pdf", "другой текст"),
                        new DocumentText("новый.pdf", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocuments(userKey(scenarioId)))
                .thenReturn(java.util.Optional.of(new DocsTextCacheService.CachedDocuments(
                        List.of("текст акта"), List.of("архив.zip/акт.pdf"))));
        when(docsTextCacheService.getCachedDocumentTexts(userKey(scenarioId))).thenReturn(List.of("текст акта"));

        service.start(scenarioId, USER, rawFiles(), true);
        UploadStatusResponse status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.status());
        assertEquals(3, status.documents());
        assertEquals(List.of("архив.zip/акт.pdf: документ уже загружен ранее (то же имя и содержимое) — дубль пропущен"),
                status.warnings());
        verify(docsTextCacheService).appendDocumentTexts(userKey(scenarioId),
                List.of("другой текст", "текст"), List.of("архив.zip/акт.pdf", "новый.pdf"), List.of());
    }
}
