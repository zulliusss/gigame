package ru.sber.cs.ai.gigame.service.annotate;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Разметка книги Excel: заливка ячейки цветом уровня и примечание с текстом находки.
 */
class XlsAnnotatorTest {

    private static final String QUOTE = "Объединение разнородных услуг в один лот";

    private static byte[] book(Workbook book) throws IOException {
        try (Workbook target = book; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Sheet sheet = target.createSheet("Лоты");
            Row first = sheet.createRow(0);
            first.createCell(0).setCellValue("Предмет");
            first.createCell(1).setCellValue(QUOTE);
            Row second = sheet.createRow(1);
            second.createCell(0).setCellValue("НМЦД");
            second.createCell(1).setCellValue(289523339.14);
            target.write(out);
            return out.toByteArray();
        }
    }

    private static Finding finding(String quote, String level, List<String> numbers) {
        return new Finding(1, "книга.xlsx", quote, level, "[" + level + "] Суть находки\nРекомендация: разделить",
                numbers);
    }

    private static Cell cell(Workbook target, int row, int column) {
        return target.getSheetAt(0).getRow(row).getCell(column);
    }

    @Test
    void highlightsCellWithQuoteAndAttachesComment() throws IOException {
        byte[] xlsx = book(new XSSFWorkbook());

        XlsAnnotator.Result result = XlsAnnotator.annotate(xlsx, List.of(finding(QUOTE, "ВЫСОКИЙ", List.of())));

        assertEquals(1, result.annotated());
        assertTrue(result.notes().isEmpty(), String.valueOf(result.notes()));
        try (Workbook marked = WorkbookFactory.create(new ByteArrayInputStream(result.content()))) {
            Cell quoted = cell(marked, 0, 1);
            assertEquals(QUOTE, quoted.getStringCellValue());
            assertEquals(FillPatternType.SOLID_FOREGROUND, quoted.getCellStyle().getFillPattern());
            assertNotNull(quoted.getCellComment());
            assertEquals(XlsAnnotator.AUTHOR, quoted.getCellComment().getAuthor());
            assertTrue(quoted.getCellComment().getString().getString().contains("Суть находки"));
            assertNull(cell(marked, 0, 0).getCellComment());
            assertEquals(FillPatternType.NO_FILL, cell(marked, 0, 0).getCellStyle().getFillPattern());
        }
    }

    @Test
    void findingWithoutQuoteIsAnchoredByNumberInNumericCell() throws IOException {
        byte[] xlsx = book(new XSSFWorkbook());
        Finding byNumber = finding("", "СРЕДНИЙ", Finding.numbersOf("Расхождение сумм НМЦ: 289 523 339,14 руб."));

        XlsAnnotator.Result result = XlsAnnotator.annotate(xlsx, List.of(byNumber));

        assertEquals(1, result.annotated());
        try (Workbook marked = WorkbookFactory.create(new ByteArrayInputStream(result.content()))) {
            assertNotNull(cell(marked, 1, 1).getCellComment());
            assertNull(cell(marked, 0, 1).getCellComment());
        }
    }

    @Test
    void oldBinaryBookIsAnnotatedToo() throws IOException {
        byte[] xls = book(new HSSFWorkbook());

        XlsAnnotator.Result result = XlsAnnotator.annotate(xls, List.of(finding(QUOTE, "НИЗКИЙ", List.of())));

        assertEquals(1, result.annotated());
        try (Workbook marked = WorkbookFactory.create(new ByteArrayInputStream(result.content()))) {
            assertTrue(marked instanceof HSSFWorkbook);
            assertNotNull(cell(marked, 0, 1).getCellComment());
            assertEquals(FillPatternType.SOLID_FOREGROUND, cell(marked, 0, 1).getCellStyle().getFillPattern());
        }
    }

    @Test
    void missingQuoteIsReportedAndBookIsNotMarked() throws IOException {
        byte[] xlsx = book(new XSSFWorkbook());

        XlsAnnotator.Result result = XlsAnnotator.annotate(xlsx, List.of(finding("Такой строки в книге нет", "НИЗКИЙ",
                List.of())));

        assertEquals(0, result.annotated());
        assertEquals(1, result.notes().size());
        assertTrue(result.notes().get(0).contains("не найдена"));
        try (Workbook marked = WorkbookFactory.create(new ByteArrayInputStream(result.content()))) {
            assertNull(cell(marked, 0, 1).getCellComment());
        }
    }
}
