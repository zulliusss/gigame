package ru.sber.cs.ai.gigame.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.controller.AgentMemoryController;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Фильтр X-UserId в цепочке WebFlux с включённым флагом: запрос к API без заголовка
 * отклоняется до контроллера ответом 401 в формате ErrorResponse, с заголовком — проходит.
 */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {AgentMemoryController.class, UserIdRequiredWebFilter.class, TestConfiguration.class})
@WebFluxTest(controllers = AgentMemoryController.class)
@TestPropertySource(properties = "app.security.require-user-id=true")
@AutoConfigureWebTestClient(timeout = "30000")
class UserIdRequiredWebFilterEnabledWebTest {

    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private AgentMemoryService memoryService;
    @MockitoBean
    private ScenarioRunRepository runRepository;
    @MockitoBean
    private ScenarioRunStepRepository stepRepository;
    @MockitoBean
    private ScenarioService scenarioService;

    @Test
    void apiWithoutHeader_returns401ErrorResponse() {
        webClient.get()
                .uri("/api/agent/lessons")
                .exchange()
                .expectStatus().isUnauthorized()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.statusCode").isEqualTo(401)
                .jsonPath("$.error").isEqualTo("Unauthorized")
                .jsonPath("$.message").isEqualTo("Отсутствует обязательный заголовок X-UserId")
                .jsonPath("$.timestamp").exists()
                .jsonPath("$.details").doesNotExist();

        verify(memoryService, never()).getLessons(any());
    }

    @Test
    void apiWithAnonymousLiteral_returns401() {
        webClient.get()
                .uri("/api/agent/lessons")
                .header("X-UserId", "anonymous")
                .exchange()
                .expectStatus().isUnauthorized()
                .expectBody()
                .jsonPath("$.message").isEqualTo("Недопустимое значение заголовка X-UserId");

        verify(memoryService, never()).getLessons(any());
    }

    @Test
    void apiWithValidHeader_passesToController() {
        when(memoryService.getLessons(any())).thenReturn(List.of());

        webClient.get()
                .uri("/api/agent/lessons")
                .header("X-UserId", "test-user")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getLessons(any());
    }
}
