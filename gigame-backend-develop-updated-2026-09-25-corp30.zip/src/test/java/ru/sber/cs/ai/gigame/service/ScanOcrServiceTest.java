package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.exception.GigaChatRefusedException;
import ru.sber.cs.ai.gigame.exception.GigaFilterBlockedException;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.Future;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.ArrayList;
import java.io.IOException;
import java.util.Map;

import java.util.List;
import java.util.concurrent.TimeUnit;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты постраничного OCR: страницы-картинки распознаются по одной, страница
 * со штампом ЭДО берётся из текстового слоя (в том числе за лимитом), пустые
 * страницы не распознаются, лимит помечается только для страниц-картинок.
 */
@ExtendWith(MockitoExtension.class)
class ScanOcrServiceTest {

    private static final String STAMP = "Document signed and transferred via EDO operator, registration number 12345";

    /** Ответ модели вместо текста декларации о стране происхождения (AZK-V3A-UB0145, 16.09.2026), дословно. */
    private static final String AZK_DECLARATION_COMMENT = "Из предоставленного фрагмента текста невозможно выписать запрашиваемую "
            + "информацию о финансовом документе, так как он содержит только общие сведения о компании и декларацию соответствия "
            + "требованиям законодательства. В тексте нет информации о реквизитах документа, сторонах договора, основаниях, "
            + "таблице работ, суммах и других данных, необходимых для выполнения запроса.";

    /** Ответ модели вместо стр. 28 договора — форма таблицы без данных (KOM-V4-K2-STOLY, 16.09.2026), дословно. */
    private static final String K2_TABLE_COMMENT = "Из предоставленного фрагмента таблицы невозможно однозначно определить "
            + "содержание финансового документа. Здесь представлена только структура таблицы без конкретных данных. "
            + "Для выполнения задачи необходимо предоставить полный текст или изображение документа.";

    private static final String DECLARATION = "Декларация об исполнении требований ст.14 44-ФЗ (о стране происхождения)\n"
            + "Участник закупки декларирует, что страной происхождения поставляемого товара является Российская Федерация.";

    @Mock
    private GigaChatClient gigaChatClient;

    private static byte[] pdf(String... pages) throws IOException {
        return TestPdf.of(pages);
    }

    private ScanOcrService service() {
        ScanOcrService service = new ScanOcrService(gigaChatClient);
        ReflectionTestUtils.setField(service, "enabled", true);
        return service;
    }

    @Test
    void multiPageScanIsRecognizedPageByPageKeepingTextLayerPages() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Акт №1 текст страницы", Map.of()));

        String text = service().recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE, STAMP));

        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.startsWith(ScanOcrService.OCR_PREFIX + " Документ «скан.pdf»:"));
        assertTrue(text.contains("--- страница 1 ---\nАкт №1 текст страницы"));
        assertTrue(text.contains("--- страница 3 (текстовый слой) ---\n" + STAMP));
    }

    @Test
    void pageProgressIsReportedForEveryPageOfMultiPageScan() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("текст страницы", Map.of()));
        List<String> progress = new ArrayList<>();

        service().recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE, STAMP),
                (file, page, total) -> progress.add(file + ":" + page + "/" + total));

        // страницы из текстового слоя тоже считаются пройденными — ход виден до конца документа
        assertEquals(List.of("скан.pdf:1/3", "скан.pdf:2/3", "скан.pdf:3/3"), progress);
    }

    @Test
    void refusedPageIsRetriedWithFallbackPrompt() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Из предоставленного контекста невозможно сформировать полный текст", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("Заявка №219 к Договору", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("страница 2", Map.of()));

        String text = service().recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE));

        verify(gigaChatClient, times(3)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.contains("--- страница 1 ---\nЗаявка №219 к Договору"));
        assertTrue(ScanOcrService.isRefusal("Из предоставленного контекста невозможно сформировать полный и дословный текст"));
        assertFalse(ScanOcrService.isRefusal("Заявка №219 к Договору № АБ-С-ИТ-2020"));
        // отказы постраничного распознавания договора МЕТРО (16.09.2026): страницы 2–7 пришли просьбами приложить документ
        assertTrue(ScanOcrService.isRefusal("Извини, но в предоставленном контексте нет текста страницы отсканированного документа."));
        assertTrue(ScanOcrService.isRefusal("Извини, но в твоем сообщении нет прикрепленного файла или текста страницы."));
        assertTrue(ScanOcrService.isRefusal("У меня нет доступа к содержимому изображений или сканированных документов."));
        assertTrue(ScanOcrService.isRefusal("В контексте нет самой страницы. Пожалуйста, приложи саму страницу или её текст."));
    }

    @Test
    void emptyPageRefusalAskingToAttachTextOrFileIsRecognized() {
        // отказ модели на пустой странице: обращение к пользователю с просьбой приложить текст или файл
        assertTrue(ScanOcrService.isRefusal("Извини, но я не могу помочь с данным запросом по предоставленному контексту. "
                + "Пожалуйста, приложите текст или файл, который нужно обработать."));
        assertTrue(ScanOcrService.isRefusal("Извини, но я не могу помочь с данным запросом."));
        assertTrue(ScanOcrService.isRefusal("Пожалуйста, приложите текст страницы."));
        assertTrue(ScanOcrService.isRefusal("Приложи, пожалуйста, файл."));
        assertTrue(ScanOcrService.isRefusal("Приложите файл, который нужно распознать."));
    }

    @Test
    void documentTextAskingToAttachCopiesIsNotRefusal() {
        // указания документа участнику в начале распознанного текста — не отказ модели
        assertFalse(ScanOcrService.isRefusal("Приложите к заявке копию лицензии"));
        assertFalse(ScanOcrService.isRefusal("ДОГОВОР № 5028839\nг. Москва 07.08.2024\n1. Предмет договора\n"
                + "1.1. Исполнитель оказывает услуги по разработке. Приложите к заявке копию лицензии и текст договора "
                + "субподряда, файл выписки ЕГРЮЛ — в формате PDF, который необходимо подписать ЭП."));
        assertFalse(ScanOcrService.isRefusal("АКТ № 15 сдачи-приемки оказанных услуг от 29.05.2025\n"
                + "Исполнитель: ООО «Ромашка» | Заказчик: ПАО Сбербанк\nК акту приложите текст отчёта о выполненных работах."));
    }

    @Test
    void nonFinancialPageCommentIsRefusalOnlyInShortAnswer() {
        // AZK-V3A-UB0145 и KOM-V4-K2-STOLY (16.09.2026): комментарий модели вместо текста нефинансовой страницы
        assertTrue(ScanOcrService.isRefusal(AZK_DECLARATION_COMMENT));
        assertTrue(ScanOcrService.isRefusal(K2_TABLE_COMMENT));
        // те же комментарии в постраничном OCR Комплекта 5 (заявки Хинт — Альфа-Банк), дословно
        assertTrue(ScanOcrService.isRefusal("4Из предоставленного тобой текста невозможно извлечь запрашиваемую информацию о финансовом "
                + "документе. Текст содержит список выполненных задач без указания реквизитов документов, сторон сделки, оснований "
                + "и сумм."));
        assertTrue(ScanOcrService.isRefusal("4Из предоставленного отрывка текста невозможно полностью воспроизвести всю страницу "
                + "сканированного финансового документа так, как это было бы необходимо согласно вашему запросу. Отсутствует "
                + "информация о полном содержании страницы, включая заголовки, реквизиты, таблицы и суммы. Пожалуйста, уточните "
                + "запрос или предоставьте более полный контекст."));
        // распознанный акт (Комплект 5, Заявка №104) с оговоркой модели в начале — длинный ответ, это текст, а не отказ
        String act = "АКТ сдачи-приемки работ\n\nг. Москва\n\n27 апреля 2024 г.\n\n"
                + "ООО «Хинт», именуемое в дальнейшем «Исполнитель», в лице Генерального директора, действующего на основании "
                + "Устава, с одной стороны, и АО «АЛЬФА-БАНК», именуемое в дальнейшем «Заказчик», в лице , действующего на "
                + "основании доверенности , с другой стороны, вместе и по отдельности именуемые «Стороны(а)», составили настоящий "
                + "Акт сдачи-приемки работ (далее - «Акт») К Договору от 03.02.2020г. №АБ-С-ИТ-2020 (далее - «Договор») о "
                + "нижеследующем:\n\n1. Исполнитель выполнил в соответствии с Заявкой №104 от 15.04.2024г. следующие работы:\n"
                + ". доработка программного обеспечения «Развитие платформы 2.0»;\n"
                + ". доработка программного обеспечения «Расширенная версия 2.0».\n\n"
                + "2. Исполнитель передал, а Заказчик принял следующие результаты работ по Заявке №104 от 15.04.2024г.:\n"
                + "Программное обеспечение «Развитие платформы 2.0». Отчеты, документация, описание. Исходный текст и объектный код;\n"
                + "Программное обеспечение «Расширенная версия 2.0». Отчеты, документация, описание. Исходный текст и объектный код.\n\n"
                + "3. Трудозатраты со стороны Исполнителя по Заявке №104 от 15.04.2024г. на выполнение работ составили:\n\n"
                + "| Категория специалиста | Уровень квалификации | Дата начала | Дата окончания | Стоимость затраченных дней, руб., без НДС |\n"
                + "|-|-|-|-|-|\n| Аналитик | 4 | 09.01.2024 | 27.04.2024 | 528 000 |\n| Аналитик | 4 | 09.01.2024 | 27.04.2024 | 404 800,00 |";
        assertFalse(ScanOcrService.isRefusal(act));
        String withRemark = "Из предоставленного фрагмента невозможно однозначно определить наименования двух программ "
                + "(в кавычках пусто), остальной текст:\n" + act;
        assertTrue(withRemark.length() > 900);
        assertFalse(ScanOcrService.isRefusal(withRemark));
    }

    @Test
    void singlePageDeclarationCommentIsRetriedWithNeutralPrompt() throws IOException {
        // AZK: декларация о стране происхождения — вместо текста комментарий «невозможно выписать … о финансовом документе»
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("скан.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(AZK_DECLARATION_COMMENT, Map.of()))
                .thenReturn(new GigaChatClient.ChatResult(DECLARATION, Map.of()));

        String text = service().recognize("скан.pdf", pdf(""));

        ArgumentCaptor<String> prompts = ArgumentCaptor.forClass(String.class);
        verify(gigaChatClient, times(2)).chatCompletionWithFile(prompts.capture(), eq("скан.pdf"), any(), eq("application/pdf"),
                any(), any(), any());
        // первый промпт для актов/УПД прежний, запасной — без слова «финансовый»
        assertTrue(prompts.getAllValues().get(0).contains("отсканированный финансовый документ"), prompts.getAllValues().get(0));
        assertFalse(prompts.getAllValues().get(1).contains("финансов"), prompts.getAllValues().get(1));
        assertTrue(prompts.getAllValues().get(1).contains("Выпиши дословно весь текст страницы"), prompts.getAllValues().get(1));
        assertEquals(ScanOcrService.OCR_PREFIX + " Документ «скан.pdf»:\n" + DECLARATION, text);
    }

    @Test
    void pageTableCommentTwiceGetsRefusedMarker() throws IOException {
        // К2, стр. 28 договора: форма таблицы без данных — комментарий на оба промпта, страница помечается, текст отказа не попадает
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(K2_TABLE_COMMENT, Map.of()))
                .thenReturn(new GigaChatClient.ChatResult(K2_TABLE_COMMENT, Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("Приложение № 5 к Договору № 50005802429", Map.of()));

        String text = service().recognize("договор.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE));

        ArgumentCaptor<String> prompts = ArgumentCaptor.forClass(String.class);
        verify(gigaChatClient, times(3)).chatCompletionWithFile(prompts.capture(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(prompts.getAllValues().get(0).contains("страница отсканированного финансового документа"));
        assertFalse(prompts.getAllValues().get(1).contains("финансов"), prompts.getAllValues().get(1));
        assertTrue(text.contains("--- страница 1 ---\n[страница 1 " + ScanOcrService.PAGE_REFUSED_MARKER), text);
        assertFalse(text.contains("невозможно однозначно определить"), text);
        assertTrue(text.contains("--- страница 2 ---\nПриложение № 5 к Договору № 50005802429"), text);
        assertTrue(ScanOcrService.uploadWarning(text, false).contains("страницы 1 не распознаны: отказ модели"));
    }

    @Test
    void censorRefusalOrFilterBlockOnPageIsMarkedWithoutFallbackRetry() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenThrow(new GigaChatRefusedException("Как и любая языковая модель, GigaChat не обладает собственным мнением"))
                .thenThrow(new GigaFilterBlockedException(false, "ответ модели, знаки 1–120"));

        String text = service().recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE));

        // отказ по содержимому повтором запасного промпта не снимается — два вызова на две страницы
        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.contains("--- страница 1 ---\n[страница 1 " + ScanOcrService.PAGE_REFUSED_MARKER), text);
        assertTrue(text.contains("--- страница 2 ---\n[страница 2 " + ScanOcrService.PAGE_REFUSED_MARKER), text);
        assertTrue(ScanOcrService.uploadWarning(text, false).contains("страницы 1, 2 не распознаны: отказ модели"),
                ScanOcrService.uploadWarning(text, false));
        assertTrue(ScanOcrService.isRefusal(ScanOcrService.BLOCKED_REFUSAL));
    }

    @Test
    void garbledTextLayerPageIsRecognizedByModel() throws IOException {
        // штамп ЭДО в актах МЕТРО: слой есть, но это мусор шрифта без ToUnicode — страница уходит в OCR
        String garbled = "X c X \" +\" - 469 - . + , + ; y b X X c o y E X a X + , + ; b X - \" X X y a - f X 1120 1,+ 3 0 1 2+";
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Документ подписан и передан через оператора ЭДО", Map.of()));

        String text = service().recognize("акт.pdf", pdf("Act text with the full description of works and services rendered by the contractor", garbled));

        verify(gigaChatClient, times(1)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.contains("--- страница 1 (текстовый слой) ---"), text);
        assertTrue(text.contains("--- страница 2 ---\nДокумент подписан и передан через оператора ЭДО"), text);
        assertTrue(ScanOcrService.looksGarbled(garbled));
        assertFalse(ScanOcrService.looksGarbled("Акт сдачи-приёмки работ по Спецификации № 5270341 от 17.03.2025, сумма 3 400 940,77"));
    }

    @Test
    void singlePageScanIsRecognizedAsWholeDocument() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("скан.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("одна страница", Map.of()));

        String text = service().recognize("скан.pdf", pdf(""));

        assertEquals(ScanOcrService.OCR_PREFIX + " Документ «скан.pdf»:\nодна страница", text);
        assertFalse(text.contains("--- страница"));
    }

    @Test
    void pagesAreRecognizedInBatchesWhenConfigured() throws IOException {
        // corp21: три страницы-изображения — один запрос с маркерами страниц, текстовый слой — как раньше
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("pages-1-3.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(
                        "=== СТРАНИЦА 1 ===\nтекст 1\n=== СТРАНИЦА 2 ===\nтекст 2\n=== СТРАНИЦА 3 ===\nтекст 3", Map.of()));
        ScanOcrService service = service();
        ReflectionTestUtils.setField(service, "ocrPagesPerRequest", 3);
        List<String> progress = new ArrayList<>();

        String text = service.recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE, TestPdf.IMAGE, STAMP),
                (file, page, total) -> progress.add(page + "/" + total));

        verify(gigaChatClient, times(1)).chatCompletionWithFile(anyString(), anyString(), any(), anyString(), any(), any(), any());
        assertTrue(text.contains("--- страница 1 ---\nтекст 1\n\n--- страница 2 ---\nтекст 2\n\n--- страница 3 ---\nтекст 3"), text);
        assertTrue(text.contains("--- страница 4 (текстовый слой) ---\n" + STAMP), text);
        assertEquals(List.of("1/4", "2/4", "3/4", "4/4"), progress);
    }

    @Test
    void batchAnswerWithoutPageMarkersIsRecognizedPageByPage() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("pages-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("сплошной текст без маркеров страниц", Map.of()));
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("стр", Map.of()));
        ScanOcrService service = service();
        ReflectionTestUtils.setField(service, "ocrPagesPerRequest", 2);

        String text = service.recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE));

        verify(gigaChatClient, times(1)).chatCompletionWithFile(anyString(), eq("pages-1-2.pdf"), any(), anyString(), any(), any(), any());
        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), anyString(), any(), any(), any());
        assertTrue(text.contains("--- страница 1 ---\nстр\n\n--- страница 2 ---\nстр"), text);
    }

    @Test
    void splitBatchRequiresOrderedMarkersAndCompleteAnswer() {
        assertEquals(Map.of(1, "а", 2, "б"), ScanOcrService.splitBatch("=== СТРАНИЦА 1 ===\nа\n\n=== СТРАНИЦА 2 ===\nб\n", 2));
        assertEquals(Map.of(), ScanOcrService.splitBatch("=== СТРАНИЦА 1 ===\nа\n=== СТРАНИЦА 3 ===\nб", 2));
        assertEquals(Map.of(), ScanOcrService.splitBatch("=== СТРАНИЦА 1 ===\nа", 2));
        assertEquals(Map.of(), ScanOcrService.splitBatch("=== СТРАНИЦА 1 ===\nа\n=== СТРАНИЦА 2 ===\nб " + ScanOcrService.TRUNCATED_MARKER, 2));
        assertEquals(Map.of(), ScanOcrService.splitBatch("Пожалуйста, приложите файл, который нужно обработать", 2));
    }

    @Test
    void pagesBeyondLimitAreMarkedNotRecognized() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("стр", Map.of()));
        ScanOcrService service = service();
        ReflectionTestUtils.setField(service, "ocrMaxPages", 2);

        String text = service.recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE, TestPdf.IMAGE));

        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), anyString(), any(), anyString(), any(), any(), any());
        assertTrue(text.contains("[страницы 3 не распознаны: превышен лимит страниц OCR 2 (обработано 2 из 3 страниц)]"), text);
        // раньше предупреждение говорило лишь «распознан — проверьте суммы», и страницы сверх лимита выпадали без сигнала
        assertEquals("PDF-скан распознан через GigaChat — проверьте суммы; обработано 2 из 3 страниц: страницы 3 не распознаны — "
                + "превышен лимит 2 страниц OCR, догрузите документ частями", ScanOcrService.uploadWarning(text, false));
    }

    @Test
    void numericTablePageWithExactTextLayerIsNotSentToOcr() throws IOException {
        // график платежей с точным слоем: букв мало, цифр много — раньше страница считалась мусором и уходила в модель
        String schedule = "1 15.01.2025 1500000,00 stage 1 2 15.02.2025 1500000,00 stage 2 3 15.03.2025 2000000,00 stage 3";
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("стр", Map.of()));

        String text = service().recognize("договор.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE, schedule));

        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.contains("--- страница 3 (текстовый слой) ---\n1 15.01.2025 1500000,00 stage 1"), text);
        assertFalse(ScanOcrService.looksGarbled("1 | 15.01.2025 | 1 500 000,00 | 2 | 15.02.2025 | 1 500 000,00"));
        assertFalse(ScanOcrService.looksGarbled("1. Общие положения ........................ 3\n2. Предмет договора ........... 4"));
        // штамп без ToUnicode: букв и цифр мало, служебных знаков вперемешку много — по-прежнему мусор
        assertTrue(ScanOcrService.looksGarbled("X c X \" +\" - 469 - . + , + ; y b X X c o y E X a X + , + ; b X - \" X X y a - f X 1120 1,+ 3 0 1 2+"));
        assertTrue(ScanOcrService.looksGarbled("\" + \" - + ; , + ; \" - + \" ; , - + \" ; + , \" - ; + \" , + -"));
    }

    @Test
    void textLayerNumbersAreNormalizedLikeParsedPdf() throws IOException {
        // смешанный PDF: слой страниц шёл в документ сырым, рваная сумма «975 09 86,34» не находилась регэкспами
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("стр", Map.of()));

        String text = service().recognize("договор.pdf", pdf("Total amount of the contract is 975 09 86,34 rub, stages 3 12,50 37,50",
                TestPdf.IMAGE));

        assertTrue(text.contains("--- страница 1 (текстовый слой) ---\nTotal amount of the contract is 9750986,34 rub, stages 3 12,50 37,50"), text);
    }

    @Test
    void imageWrappedInPdfIsSentUnderPdfName() throws IOException {
        // фото акта: одностраничный PDF из картинки уходит в хранилище с расширением .pdf, имя документа остаётся
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("IMG_0001.jpg.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Акт №7", Map.of()));

        String text = service().recognize("IMG_0001.jpg", pdf(TestPdf.IMAGE));

        assertEquals(ScanOcrService.OCR_PREFIX + " Документ «IMG_0001.jpg»:\nАкт №7", text);
    }

    @Test
    void textLayerPagesBeyondLimitAreKeptAndOnlyImagePagesAreMarked() throws IOException {
        // договор p8 (16.09.2026): лимит 40 заменял маркером текстовый слой страниц 41–71
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("стр", Map.of()));
        ScanOcrService service = service();
        ReflectionTestUtils.setField(service, "ocrMaxPages", 1);

        String text = service.recognize("смешанный.pdf",
                pdf(TestPdf.IMAGE, STAMP, TestPdf.BLANK, TestPdf.IMAGE, TestPdf.FORM_IMAGE, STAMP + " 6", TestPdf.IMAGE));

        verify(gigaChatClient, times(1)).chatCompletionWithFile(anyString(), anyString(), any(), anyString(), any(), any(), any());
        assertTrue(text.contains("--- страница 1 ---\nстр"), text);
        assertTrue(text.contains("--- страница 2 (текстовый слой) ---\n" + STAMP), text);
        assertTrue(text.contains("--- страница 6 (текстовый слой) ---\n" + STAMP + " 6"), text);
        assertFalse(text.contains("страница 3"), text);
        assertTrue(text.endsWith("[страницы 4–5, 7 не распознаны: превышен лимит страниц OCR 1 (обработано 4 из 7 страниц)]"), text);
    }

    @Test
    void blankPagesAreNotSentToGigaChat() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Акт №1", Map.of()));

        String text = service().recognize("скан.pdf", pdf(TestPdf.BLANK, TestPdf.INLINE_IMAGE, TestPdf.BLANK, STAMP));

        verify(gigaChatClient, times(1)).chatCompletionWithFile(anyString(), eq("page-2.pdf"), any(), eq("application/pdf"),
                any(), any(), any());
        assertEquals(ScanOcrService.OCR_PREFIX + " Документ «скан.pdf»:\n--- страница 2 ---\nАкт №1\n\n"
                + "--- страница 4 (текстовый слой) ---\n" + STAMP, text);
    }

    @Test
    void mixedDocumentWarningListsRecognizedPages() {
        String text = ScanOcrService.OCR_PREFIX + " Документ «договор.pdf»:\n--- страница 1 (текстовый слой) ---\n" + STAMP
                + "\n\n--- страница 2 ---\nАкт\n\n--- страница 4 ---\nСчёт\n\n--- страница 5 ---\nСпецификация"
                + "\n\n--- страница 7 ---\n[страница 7 не распознана: отказ модели]";

        assertEquals("распознаны через GigaChat страницы 2, 4–5 — проверьте суммы; страницы 7 не распознаны: отказ модели",
                ScanOcrService.uploadWarning(text, true));
        // скан целиком — прежний текст
        assertEquals("PDF-скан распознан через GigaChat — проверьте суммы; страницы 7 не распознаны: отказ модели",
                ScanOcrService.uploadWarning(text, false));
        assertEquals("41–43, 50", ScanOcrService.pageRanges(List.of(41, 42, 43, 50)));
        assertEquals("3", ScanOcrService.pageRanges(List.of(3)));
    }

    @Test
    void ocrRequestsAreLimitedByParallelism() throws Exception {
        // 4 потока разбора × OCR давали 429 GigaChat: по умолчанию распознавание идёт по одному запросу за раз
        AtomicInteger active = new AtomicInteger();
        AtomicInteger maxActive = new AtomicInteger();
        when(gigaChatClient.chatCompletionWithFile(anyString(), anyString(), any(), eq("application/pdf"), any(), any(), any()))
                .thenAnswer(inv -> {
                    maxActive.accumulateAndGet(active.incrementAndGet(), Math::max);
                    Thread.sleep(60); // NOSONAR java:S2925 — имитация задержки OCR-запроса для проверки параллелизма
                    active.decrementAndGet();
                    return new GigaChatClient.ChatResult("текст", Map.of());
                });
        ScanOcrService service = service();
        byte[] scan = pdf("");
        ExecutorService pool = Executors.newFixedThreadPool(3);
        try {
            List<Future<String>> results = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                results.add(pool.submit(() -> service.recognize("скан.pdf", scan)));
            }
            for (Future<String> f : results) {
                assertTrue(f.get(5, TimeUnit.SECONDS).contains("текст"));
            }
        } finally {
            pool.shutdownNow();
        }
        assertEquals(1, maxActive.get());
    }

    @Test
    void singlePageRefusalIsRetriedWithPagePrompt() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("скан.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Из предоставленного контекста невозможно сформировать текст", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("Акт № 5", Map.of()));

        String text = service().recognize("скан.pdf", pdf(""));

        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), eq("скан.pdf"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.endsWith("Акт № 5"));
        assertFalse(text.contains("невозможно сформировать"));
    }

    @Test
    void pageRefusedAfterFallbackGetsMarkerInsteadOfRefusalText() throws IOException {
        // обе попытки — отказ: раньше текст отказа становился «текстом страницы»
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Из предоставленного контекста невозможно сформировать текст", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("Пожалуйста, предоставьте полный документ", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("страница 2 текст", Map.of()));

        String text = service().recognize("скан.pdf", pdf(TestPdf.IMAGE, TestPdf.IMAGE));

        assertTrue(text.contains("--- страница 1 ---\n[страница 1 не распознана: отказ модели]"));
        assertFalse(text.contains("невозможно сформировать"));
        assertTrue(text.contains("--- страница 2 ---\nстраница 2 текст"));
        assertTrue(ScanOcrService.uploadWarning(text, false).contains("страницы 1 не распознаны: отказ модели"));
    }

    @Test
    void wholeDocumentRefusalGivesManualCheckMarker() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("скан.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Не могу выполнить: предоставьте полный текст", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("Из предоставленного контекста невозможно сформировать", Map.of()));

        String text = service().recognize("скан.pdf", pdf(""));

        assertTrue(text.startsWith(ScanOcrService.DOC_REFUSED_PREFIX + "скан.pdf» не распознан: модель отказалась"));
        assertFalse(text.startsWith(ScanOcrService.OCR_PREFIX));
        assertTrue(ScanOcrService.uploadWarning(text, false).contains("отказалась"));
    }

    @Test
    void multiPageRecognizedWholeGetsSeparatePrefixAndWarning() throws IOException {
        // постраничный режим выключен — многостраничный скан распознаётся целиком (пересказ), это видно по префиксу
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("скан.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("пересказ трёх страниц", Map.of()));
        ScanOcrService service = service();
        ReflectionTestUtils.setField(service, "ocrPerPage", false);

        String text = service.recognize("скан.pdf", pdf("", "", ""));

        assertTrue(text.startsWith(ScanOcrService.OCR_WHOLE_PREFIX + " Документ «скан.pdf»:\nпересказ трёх страниц"));
        assertTrue(ScanOcrService.uploadWarning(text, true).contains("распознан целиком (пересказ)"));
        assertEquals("PDF-скан распознан через GigaChat — проверьте суммы",
                ScanOcrService.uploadWarning(ScanOcrService.OCR_PREFIX + " Документ «a.pdf»:\nтекст", false));
        assertTrue(ScanOcrService.uploadWarning("текст\n" + GigaChatClient.TRUNCATED_MARKER, false).contains("оборван по лимиту длины"));
    }

    @Test
    void sameScanIsTakenFromCacheWithoutModelCall() throws IOException {
        // cache-5: повторная загрузка того же скана (по SHA-256 байтов) — без запросов к модели, с пометкой в предупреждении
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Акт №1 текст страницы", Map.of()));
        ScanOcrService service = service();
        service.setOcrResultCache(new OcrResultCache(1_000_000, 24));
        byte[] scan = pdf(TestPdf.IMAGE, TestPdf.IMAGE, STAMP);

        String first = service.recognize("скан.pdf", scan);
        String second = service.recognize("тот же скан.pdf", scan);

        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertFalse(first.contains(OcrResultCache.CACHE_MARKER));
        assertEquals(first + "\n" + OcrResultCache.CACHE_MARKER, second);
        assertTrue(ScanOcrService.uploadWarning(second, false).contains("распознавание взято из кэша"), ScanOcrService.uploadWarning(second, false));
        assertFalse(ScanOcrService.uploadWarning(first, false).contains("кэша"));
    }
}
