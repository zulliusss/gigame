package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.MeasuredDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты для {@link ScenarioEngine}.
 * <p>
 * Тестирует валидацию графов, топологическую сортировку,
 * управление пошаговым режимом отладки и очистку состояния.
 */
@ExtendWith(MockitoExtension.class)
class ScenarioEngineTest {

    @Mock
    private ScenarioRunService runService;

    @Mock
    private ScenarioRunStepService stepService;

    @Mock
    private ScenarioExecutorFactory executorFactory;

    @Mock
    private DocsTextCacheService cacheService;

    @Mock
    private ScenarioRepository scenarioRepository;

    @Mock
    private ScenarioOutputSupportService outputSupportService;

    private ScenarioEngine engine;

    @BeforeEach
    void setUp() {
        engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService,
                scenarioRepository, outputSupportService);
    }

    // -------------------------------------------------------------------------
    // Constructor and basic initialization
    // -------------------------------------------------------------------------

    @Test
    void testConstructor_initializedSuccessfully() {
        assertNotNull(engine);
    }

    // -------------------------------------------------------------------------
    // Step mode tests
    // -------------------------------------------------------------------------

    @Test
    void testEnableStepMode_addsRunIdToEnabledSet() {
        String runId = "run-123";
        engine.enableStepMode(runId);
        engine.disableStepMode(runId);
        assertNotNull(engine);
    }

    @Test
    void testDisableStepMode_addsRunIdToDisabledSet() {
        String runId = UUID.randomUUID().toString();
        engine.disableStepMode(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    @Test
    void testContinueStep_completesExistingFuture() {
        String runId = UUID.randomUUID().toString();
        engine.enableStepMode(runId);
        engine.continueStep(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    @Test
    void testContinueStep_withNonExistentFuture_doesNotThrow() {
        String runId = UUID.randomUUID().toString();
        assertDoesNotThrow(() -> engine.continueStep(runId));
    }

    @Test
    void testCleanupRun_clearsAllState() {
        String runId = UUID.randomUUID().toString();
        engine.enableStepMode(runId);
        engine.continueStep(runId);
        engine.cleanupRun(runId);
        engine.enableStepMode(runId);
        engine.disableStepMode(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    // -------------------------------------------------------------------------
    // Graph validation tests (via reflection on private methods)
    // -------------------------------------------------------------------------

    @Test
    void testValidateGraph_withEmptyNodes_throwsScenarioException() {
        GraphDataDto graphData = new GraphDataDto(List.of(), List.of());

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует или пуст массив nodes"));
    }

    @Test
    void testValidateGraph_withEmptyEdges_throwsScenarioException() {
        NodeDto node = createInputNode("node-1");
        GraphDataDto graphData = new GraphDataDto(List.of(node), List.of());

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует или пуст массив edges"));
    }

    @Test
    void testValidateGraph_withCyclicGraph_throwsScenarioException() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");

        EdgeDto edgeAB = createEdge("e1", "A", "B");
        EdgeDto edgeBC = createEdge("e2", "B", "C");
        EdgeDto edgeCA = createEdge("e3", "C", "A");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC),
                List.of(edgeAB, edgeBC, edgeCA)
        );

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("обнаружен цикл"));
    }

    @Test
    void testValidateGraph_withNotExistentOutputNode_throwsScenarioException() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        EdgeDto edge = createEdge("e1", "A", "B");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует узел с типом 'Выход'"));
    }

    @Test
    void testValidateGraph_withNotExistentInputNode_throwsScenarioException() {
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");
        EdgeDto edge = createEdge("e1", "B", "C");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeB, nodeC), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("отсутствует узел с типом 'Вход'"));
    }

    @ParameterizedTest
    @MethodSource("invalidEdgeGraphProvider")
    void testValidateGraph_withInvalidEdge_throwsScenarioException(String testName, GraphDataDto graphData, String expectedMessage) {
        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains(expectedMessage),
                () -> "For case '" + testName + "': expected message containing '" + expectedMessage
                        + "' but got '" + exception.getMessage() + "'");
    }

    static Stream<Arguments> invalidEdgeGraphProvider() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");

        return Stream.of(
                Arguments.of(
                        "invalid edge source",
                        new GraphDataDto(List.of(nodeA, nodeB, nodeC), List.of(createEdge("e1", "nonexistent", "B"))),
                        "источник ребра 'nonexistent' ссылается на несуществующий узел"
                ),
                Arguments.of(
                        "invalid edge target",
                        new GraphDataDto(List.of(nodeA, nodeB, nodeC), List.of(createEdge("e1", "A", "nonexistent"))),
                        "цель ребра 'nonexistent' ссылается на несуществующий узел"
                ),
                Arguments.of(
                        "disconnected node",
                        new GraphDataDto(List.of(nodeA, nodeB, nodeC), List.of(createEdge("e1", "A", "C"))),
                        "обнаружены узлы, не связанные рёбрами"
                )
        );
    }

    @Test
    void testValidateGraph_withNodeWithoutId_throwsScenarioException() {
        NodeDto nodeWithoutIdInput = new NodeDto(null, "input", NodeDataDto.builder().build(),
                new PositionDto(0, 0), new MeasuredDto(0, 0));
        NodeDto nodeWithoutIdOutnput = new NodeDto(null, "output", NodeDataDto.builder().build(),
                new PositionDto(0, 0), new MeasuredDto(0, 0));
        EdgeDto edge = createEdge("e1", "some-node", "another-node");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeWithoutIdInput, nodeWithoutIdOutnput), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        String message = exception.getMessage();
        assertTrue(message.contains("отсутствует идентификатор"),
                "Expected exception message to contain 'отсутствует идентификатор', but got: " + message);
    }

    @Test
    void testValidateGraph_withValidGraph_doesNotThrow() {
        NodeDto nodeA = createInputNode("node-a");
        NodeDto nodeB = createProcessingNode("node-b", "Prompt");
        NodeDto nodeC = createOutputNode("node-c");

        EdgeDto edge1 = createEdge("e1", "node-a", "node-b");
        EdgeDto edge2 = createEdge("e2", "node-b", "node-c");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC),
                List.of(edge1, edge2)
        );

        assertDoesNotThrow(() -> validateGraph(engine, graphData));
    }

    @Test
    void testValidateGraph_withExtraRoot_throwsScenarioException() {
        // второй узел без родителей: в последовательном режиме он не выполнился бы вовсе
        NodeDto input = createInputNode("node-a");
        NodeDto extraRoot = createProcessingNode("node-x", "Prompt");
        NodeDto output = createOutputNode("node-c");
        GraphDataDto graphData = new GraphDataDto(
                List.of(input, extraRoot, output),
                List.of(createEdge("e1", "node-a", "node-c"), createEdge("e2", "node-x", "node-c")));

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                validateGraph(engine, graphData));

        assertTrue(exception.getMessage().contains("несколько узлов без входящих рёбер"), exception.getMessage());
        assertTrue(exception.getMessage().contains("node-a"), exception.getMessage());
        assertTrue(exception.getMessage().contains("node-x"), exception.getMessage());
    }

    // -------------------------------------------------------------------------
    // Topological sort tests (via reflection)
    // -------------------------------------------------------------------------

    @Test
    void testTopologicalSort_linearGraph() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "output");

        EdgeDto edgeAB = createEdge("e1", "A", "B");
        EdgeDto edgeBC = createEdge("e2", "B", "C");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC),
                List.of(edgeAB, edgeBC)
        );

        List<String> sorted = topologicalSort(engine, graphData);

        assertTrue(sorted.indexOf("A") < sorted.indexOf("B"));
        assertTrue(sorted.indexOf("B") < sorted.indexOf("C"));
    }

    @Test
    void testTopologicalSort_withMultiplePaths() {
        NodeDto nodeA = createNode("A", "input");
        NodeDto nodeB = createNode("B", "processing");
        NodeDto nodeC = createNode("C", "processing");
        NodeDto nodeD = createNode("D", "output");

        EdgeDto edgeAB = createEdge("e1", "A", "B");
        EdgeDto edgeAC = createEdge("e2", "A", "C");
        EdgeDto edgeBD = createEdge("e3", "B", "D");
        EdgeDto edgeCD = createEdge("e4", "C", "D");

        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, nodeC, nodeD),
                List.of(edgeAB, edgeAC, edgeBD, edgeCD)
        );

        List<String> sorted = topologicalSort(engine, graphData);

        assertEquals("A", sorted.get(0));
        assertEquals("D", sorted.get(sorted.size() - 1));
    }

    @Test
    void testTopologicalSort_singleNode() {
        NodeDto nodeA = createNode("A", "input");

        GraphDataDto graphData = new GraphDataDto(List.of(nodeA), List.of());

        List<String> sorted = topologicalSort(engine, graphData);

        assertEquals(1, sorted.size());
        assertEquals("A", sorted.get(0));
    }

    @Test
    void testTopologicalSort_emptyGraph() {
        GraphDataDto graphData = new GraphDataDto(List.of(), List.of());

        List<String> sorted = topologicalSort(engine, graphData);

        assertEquals(0, sorted.size());
    }

    // -------------------------------------------------------------------------
    // stripNoteNodes tests (package-private static)
    // -------------------------------------------------------------------------

    @Test
    void testStripNoteNodes_withoutNotes_returnsSameGraph() {
        NodeDto nodeA = createInputNode("A");
        NodeDto nodeB = createOutputNode("B");
        EdgeDto edge = createEdge("e1", "A", "B");
        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB), List.of(edge));

        GraphDataDto stripped = stripNoteNodes(graphData);

        assertEquals(2, stripped.nodes().size());
        assertEquals(1, stripped.edges().size());
    }

    @Test
    void testStripNoteNodes_removesNoteNodesAndTheirEdges() {
        NodeDto nodeA = createInputNode("A");
        NodeDto nodeB = createOutputNode("B");
        NodeDto note1 = createNode("note-1", "note");
        NodeDto note2 = createNode("note-2", "note");
        EdgeDto edgeAB = createEdge("e1", "A", "B");
        EdgeDto edgeNote1 = createEdge("en1", "note-1", "A");
        EdgeDto edgeNote2 = createEdge("en2", "B", "note-2");
        GraphDataDto graphData = new GraphDataDto(
                List.of(nodeA, nodeB, note1, note2),
                List.of(edgeAB, edgeNote1, edgeNote2)
        );

        GraphDataDto stripped = stripNoteNodes(graphData);

        assertEquals(2, stripped.nodes().size());
        assertEquals(1, stripped.edges().size());
        assertTrue(stripped.nodes().stream().noneMatch(n -> "note".equals(n.type())));
        assertTrue(stripped.edges().stream().allMatch(e -> "e1".equals(e.id())));
    }

    // -------------------------------------------------------------------------
    // getNodeIds tests (private static)
    // -------------------------------------------------------------------------

    @Test
    void testGetNodeIds_returnsAllNodeIds() {
        NodeDto nodeA = createInputNode("A");
        NodeDto nodeB = createOutputNode("B");
        EdgeDto edge = createEdge("e1", "A", "B");
        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB), List.of(edge));

        Set<String> ids = getNodeIds(graphData);

        assertEquals(Set.of("A", "B"), ids);
    }

    @Test
    void testGetNodeIds_withNodeWithoutId_throwsScenarioException() {
        NodeDto nodeWithoutId = new NodeDto(null, "input", NodeDataDto.builder().build(),
                new PositionDto(0, 0), new MeasuredDto(0, 0));
        NodeDto nodeB = createOutputNode("B");
        GraphDataDto graphData = new GraphDataDto(List.of(nodeWithoutId, nodeB), List.of());

        ScenarioException exception = assertThrows(ScenarioException.class,
                () -> getNodeIds(graphData));

        assertTrue(exception.getMessage().contains("отсутствует идентификатор"));
    }

    @Test
    void testGetNodeIds_withInvalidEdgeSource_throwsScenarioException() {
        NodeDto nodeA = createInputNode("A");
        NodeDto nodeB = createOutputNode("B");
        EdgeDto edge = createEdge("e1", "nonexistent", "B");
        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class,
                () -> getNodeIds(graphData));

        assertTrue(exception.getMessage().contains("источник ребра 'nonexistent' ссылается на несуществующий узел"));
    }

    @Test
    void testGetNodeIds_withInvalidEdgeTarget_throwsScenarioException() {
        NodeDto nodeA = createInputNode("A");
        NodeDto nodeB = createOutputNode("B");
        EdgeDto edge = createEdge("e1", "A", "nonexistent");
        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB), List.of(edge));

        ScenarioException exception = assertThrows(ScenarioException.class,
                () -> getNodeIds(graphData));

        assertTrue(exception.getMessage().contains("цель ребра 'nonexistent' ссылается на несуществующий узел"));
    }

    // -------------------------------------------------------------------------
    // getDisconnectedNodes tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testGetDisconnectedNodes_fullyConnected_returnsEmpty() {
        NodeDto nodeA = createInputNode("A");
        NodeDto nodeB = createOutputNode("B");
        EdgeDto edge = createEdge("e1", "A", "B");
        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB), List.of(edge));

        List<String> disconnected = getDisconnectedNodes(engine, graphData, Set.of("A", "B"));

        assertTrue(disconnected.isEmpty());
    }

    @Test
    void testGetDisconnectedNodes_withOrphanNode_returnsOrphanId() {
        NodeDto nodeA = createInputNode("A");
        NodeDto nodeB = createOutputNode("B");
        NodeDto orphan = createNode("orphan", "processing");
        EdgeDto edge = createEdge("e1", "A", "B");
        GraphDataDto graphData = new GraphDataDto(List.of(nodeA, nodeB, orphan), List.of(edge));

        List<String> disconnected = getDisconnectedNodes(engine, graphData, Set.of("A", "B", "orphan"));

        assertEquals(List.of("orphan"), disconnected);
    }

    // -------------------------------------------------------------------------
    // pauseFutureGet tests (private static)
    // -------------------------------------------------------------------------

    @Test
    void testPauseFutureGet_completedFuture_returnsImmediately() {
        CompletableFuture<Void> completed = CompletableFuture.completedFuture(null);

        long start = System.currentTimeMillis();
        pauseFutureGet(completed, "run-1");
        long elapsed = System.currentTimeMillis() - start;

        assertTrue(elapsed < 500, "Should return immediately for completed future");
    }

    @Test
    void testPauseFutureGet_uncompletedFuture_blocksUntilComplete() throws Exception {
        CompletableFuture<Void> future = new CompletableFuture<>();
        AtomicReference<Throwable> errorRef = new AtomicReference<>();
        CountDownLatch started = new CountDownLatch(1);
        Thread waiter = new Thread(() -> {
            started.countDown();
            try {
                pauseFutureGet(future, "run-1");
            } catch (Throwable t) {
                errorRef.set(t);
            }
        });
        waiter.start();

        // Дожидаемся, пока поток-ожидатель дойдёт до блокирующего get (вместо sleep),
        // затем завершаем future и проверяем, что поток разблокировался без ошибок.
        assertTrue(started.await(5, TimeUnit.SECONDS), "Waiter thread should start blocking");
        future.complete(null);
        waiter.join(2000);
        assertFalse(waiter.isAlive(), "Waiter thread should have finished");
        assertNull(errorRef.get());
    }

    // -------------------------------------------------------------------------
    // evictStepEvents tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testEvictStepEvents_withExistingFuture_completesAndRemoves() throws Exception {
        String runId = UUID.randomUUID().toString();
        CompletableFuture<Void> future = new CompletableFuture<>();
        // Доступ к private stepEvents через рефлексию
        var field = ScenarioEngine.class.getDeclaredField("stepEvents");
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        var stepEvents = (java.util.concurrent.ConcurrentHashMap<String, CompletableFuture<Void>>) field.get(engine);
        stepEvents.put(runId, future);

        assertFalse(future.isDone());
        evictStepEvents(engine, runId);
        assertTrue(future.isDone());
        assertNull(stepEvents.get(runId));
    }

    @Test
    void testEvictStepEvents_withoutFuture_doesNotThrow() {
        String runId = UUID.randomUUID().toString();
        assertDoesNotThrow(() -> evictStepEvents(engine, runId));
    }

    // -------------------------------------------------------------------------
    // evictExpiredStepEvents tests (private @Scheduled)
    // -------------------------------------------------------------------------

    @Test
    void testEvictExpiredStepEvents_withExpiredFuture_completesAndRemoves() throws Exception {
        String runId = UUID.randomUUID().toString();
        CompletableFuture<Void> future = new CompletableFuture<>();
        var field = ScenarioEngine.class.getDeclaredField("stepEvents");
        field.setAccessible(true);
        @SuppressWarnings("unchecked")
        var stepEvents = (java.util.concurrent.ConcurrentHashMap<String, CompletableFuture<Void>>) field.get(engine);
        stepEvents.put(runId, future);

        // runTimestamps не содержит runId → orphan → удаляется
        evictExpiredStepEvents(engine);

        assertTrue(future.isDone());
        assertNull(stepEvents.get(runId));
    }

    @Test
    void testEvictExpiredStepEvents_withFreshTimestamp_keepsFuture() throws Exception {
        String runId = UUID.randomUUID().toString();
        CompletableFuture<Void> future = new CompletableFuture<>();
        var stepEventsField = ScenarioEngine.class.getDeclaredField("stepEvents");
        stepEventsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        var stepEvents = (java.util.concurrent.ConcurrentHashMap<String, CompletableFuture<Void>>) stepEventsField.get(engine);
        stepEvents.put(runId, future);

        // Свежий timestamp (сейчас) → НЕ удаляется
        var tsField = ScenarioEngine.class.getDeclaredField("runTimestamps");
        tsField.setAccessible(true);
        @SuppressWarnings("unchecked")
        var runTimestamps = (java.util.concurrent.ConcurrentHashMap<String, Long>) tsField.get(engine);
        runTimestamps.put(runId, System.currentTimeMillis());

        evictExpiredStepEvents(engine);

        assertFalse(future.isDone());
        assertNotNull(stepEvents.get(runId));
    }

    // -------------------------------------------------------------------------
    // shutdown test
    // -------------------------------------------------------------------------

    @Test
    void testShutdown_doesNotThrow() {
        assertDoesNotThrow(() -> engine.shutdown());
    }

    // -------------------------------------------------------------------------
    // evictStaleRuns test
    // -------------------------------------------------------------------------

    @Test
    void testEvictStaleRuns_doesNotThrow() {
        String runId = UUID.randomUUID().toString();
        engine.cleanupRun(runId);

        assertDoesNotThrow(() -> engine.evictStaleRuns());

        engine.cleanupRun(runId);
    }

    @Test
    @SuppressWarnings("unchecked")
    void testScheduledEvictions_keepStepModeAndPauseOfActiveRunOlderThanTenMinutes() throws Exception {
        // corp23 concurrency-1: отметка времени ставится при старте и не обновляется; прогон на комплекте идёт
        // дольше 10 минут — чистки снимали пошаговый режим и завершали паузу живого прогона
        String runId = UUID.randomUUID().toString();
        var runTimestamps = (ConcurrentHashMap<String, Long>) field("runTimestamps");
        var activeGraphs = (ConcurrentHashMap<String, ScenarioRunGraph>) field("activeGraphs");
        var stepModeEnabled = (Set<String>) field("stepModeEnabled");
        var stepEvents = (ConcurrentHashMap<String, CompletableFuture<Void>>) field("stepEvents");
        engine.enableStepMode(runId);
        runTimestamps.put(runId, System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(25));
        activeGraphs.put(runId, new ScenarioRunGraph(new GraphDataDto(
                List.of(createNode("A", "input"), createNode("B", "output")), List.of(createEdge("e1", "A", "B")))));
        CompletableFuture<Void> pause = new CompletableFuture<>();
        stepEvents.put(runId, pause);

        engine.evictStaleRuns();
        engine.evictExpiredStepEvents();

        assertTrue(stepModeEnabled.contains(runId), "пошаговый режим живого прогона снят чисткой");
        assertFalse(pause.isDone(), "пауза живого прогона завершена чисткой");
        assertSame(pause, stepEvents.get(runId));
        assertTrue(runTimestamps.containsKey(runId));

        // прогон завершился (граф снят с учёта) — то же состояние теперь чистится как устаревшее
        activeGraphs.remove(runId);
        engine.evictStaleRuns();
        engine.evictExpiredStepEvents();

        assertFalse(stepModeEnabled.contains(runId));
        assertTrue(pause.isDone());
        assertNull(stepEvents.get(runId));
        assertFalse(runTimestamps.containsKey(runId));
    }

    private Object field(String name) throws ReflectiveOperationException {
        var declared = ScenarioEngine.class.getDeclaredField(name);
        declared.setAccessible(true);
        return declared.get(engine);
    }

    // -------------------------------------------------------------------------
    // executeSubScenarioInline tests
    // -------------------------------------------------------------------------

    @Test
    void testExecuteSubScenarioInline_withInputFallback_returnsExecutorResult() {
        String expectedResult = "SUB_RESULT";
        UUID subId = UUID.randomUUID();

        Scenario subScenario = createValidSubScenario("input-1", "output-1");
        when(scenarioRepository.findById(subId)).thenReturn(Optional.of(subScenario));

        // исполнители активируют детей: результат под-сценария — выход его output-узла
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenAnswer(inv -> activatingExecutor(inv.getArgument(0), expectedResult));

        ScenarioRunNode parentNode = createParentNodeWithInput("текст на входе узла");

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

        String result = engine.executeSubScenarioInline(subId.toString(), parentNode, sink);

        assertEquals(expectedResult, result);
        verify(scenarioRepository).findById(subId);
        // вход и выход под-сценария
        verify(executorFactory, org.mockito.Mockito.times(2)).createExecutor(any(ScenarioRunNode.class));
    }

    @Test
    void testExecuteSubScenarioInline_withParentDocs_passesDocsToSubGraph() {
        UUID subId = UUID.randomUUID();

        Scenario subScenario = createValidSubScenario("input-1", "output-1");
        when(scenarioRepository.findById(subId)).thenReturn(Optional.of(subScenario));

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenAnswer(inv -> activatingExecutor(inv.getArgument(0), "ok"));

        ScenarioRunNode parentNode = createParentNodeWithDocs("DOC_1", "doc text", "file.txt");

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

        engine.executeSubScenarioInline(subId.toString(), parentNode, sink);

        assertEquals(1, parentNode.getGraph().getDocMap().size());
        assertTrue(parentNode.getGraph().getDocMap().containsKey("DOC_1"));
        ScenarioRunDoc doc = parentNode.getGraph().getDocMap().get("DOC_1");
        assertEquals("doc text", doc.getText());
        assertEquals("file.txt", doc.getFilename());
    }

    @Test
    void testExecuteSubScenarioInline_invalidUuid_throwsScenarioException() {
        ScenarioRunNode parentNode = createParentNodeWithInput("text");

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                engine.executeSubScenarioInline("not-a-uuid", parentNode, sink));

        assertTrue(exception.getMessage().contains("некорректный идентификатор сценария"));
    }

    @Test
    void testExecuteSubScenarioInline_subScenarioNotFound_throwsScenarioException() {
        UUID subId = UUID.randomUUID();
        when(scenarioRepository.findById(subId)).thenReturn(Optional.empty());

        ScenarioRunNode parentNode = createParentNodeWithInput("text");

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);
        var subIdStr = subId.toString();
        ScenarioException exception = assertThrows(ScenarioException.class, () ->
                engine.executeSubScenarioInline(subIdStr, parentNode, sink));

        assertTrue(exception.getMessage().contains("сценарий не найден"));
    }

    // -------------------------------------------------------------------------
    // isErrorEdge tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testIsErrorEdge_withErrorLabel_returnsTrue() {
        ScenarioRunNode from = createSimpleNodeInGraph("from");
        ScenarioRunNode to = createSimpleNodeInGraph("to");
        from.getGraph().getEdgeMap().put(
                org.apache.commons.lang3.tuple.Pair.of("from", "to"),
                new EdgeDataDto("ошибка"));

        boolean result = isErrorEdge(engine, from, to);

        assertTrue(result);
    }

    @Test
    void testIsErrorEdge_withEnglishErrorLabel_returnsTrue() {
        ScenarioRunNode from = createSimpleNodeInGraph("from");
        ScenarioRunNode to = createSimpleNodeInGraph("to");
        from.getGraph().getEdgeMap().put(
                org.apache.commons.lang3.tuple.Pair.of("from", "to"),
                new EdgeDataDto("Error"));

        boolean result = isErrorEdge(engine, from, to);

        assertTrue(result);
    }

    @Test
    void testIsErrorEdge_withNormalLabel_returnsFalse() {
        ScenarioRunNode from = createSimpleNodeInGraph("from");
        ScenarioRunNode to = createSimpleNodeInGraph("to");
        from.getGraph().getEdgeMap().put(
                org.apache.commons.lang3.tuple.Pair.of("from", "to"),
                new EdgeDataDto("обычная ветка"));

        boolean result = isErrorEdge(engine, from, to);

        assertFalse(result);
    }

    @Test
    void testIsErrorEdge_withoutEdge_returnsFalse() {
        ScenarioRunNode from = createSimpleNodeInGraph("from");
        ScenarioRunNode to = createSimpleNodeInGraph("to");

        boolean result = isErrorEdge(engine, from, to);

        assertFalse(result);
    }

    // -------------------------------------------------------------------------
    // isAllParentCompleted tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testIsAllParentCompleted_noParents_returnsTrue() {
        ScenarioRunNode node = createSimpleNodeInGraph("alone");

        boolean result = isAllParentCompleted(engine, node);

        assertTrue(result);
    }

    @Test
    void testIsAllParentCompleted_allCompleted_returnsTrue() {
        ScenarioRunNode parent1 = createSimpleNodeInGraph("p1");
        ScenarioRunNode parent2 = createSimpleNodeInGraph("p2");
        ScenarioRunNode child = createSimpleNodeInGraph("child");
        child.getParentNodeList().add(parent1);
        child.getParentNodeList().add(parent2);
        parent1.setCompleted(true);
        parent2.setCompleted(true);

        boolean result = isAllParentCompleted(engine, child);

        assertTrue(result);
    }

    @Test
    void testIsAllParentCompleted_someNotCompleted_returnsFalse() {
        ScenarioRunNode parent1 = createSimpleNodeInGraph("p1");
        ScenarioRunNode parent2 = createSimpleNodeInGraph("p2");
        ScenarioRunNode child = createSimpleNodeInGraph("child");
        child.getParentNodeList().add(parent1);
        child.getParentNodeList().add(parent2);
        parent1.setCompleted(true);
        parent2.setCompleted(false);
        parent2.setSkip(false);

        boolean result = isAllParentCompleted(engine, child);

        assertFalse(result);
    }

    @Test
    void testIsAllParentCompleted_someSkipped_returnsTrue() {
        ScenarioRunNode parent1 = createSimpleNodeInGraph("p1");
        ScenarioRunNode child = createSimpleNodeInGraph("child");
        child.getParentNodeList().add(parent1);
        parent1.setSkip(true);
        parent1.setCompleted(false);

        boolean result = isAllParentCompleted(engine, child);

        assertTrue(result);
    }

    // -------------------------------------------------------------------------
    // isNotReadyForTraversal tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testIsNotReadyForTraversal_alreadyCompleted_returnsTrue() {
        ScenarioRunNode node = createSimpleNodeInGraph("n");
        node.setCompleted(true);

        boolean result = isNotReadyForTraversal(engine, node, "run-1");

        assertTrue(result);
    }

    @Test
    void testIsNotReadyForTraversal_parentNotComplete_returnsTrue() {
        ScenarioRunNode parent = createSimpleNodeInGraph("p");
        ScenarioRunNode child = createSimpleNodeInGraph("c");
        child.getParentNodeList().add(parent);
        parent.setCompleted(false);
        parent.setSkip(false);

        boolean result = isNotReadyForTraversal(engine, child, "run-1");

        assertTrue(result);
    }

    @Test
    void testIsNotReadyForTraversal_parentsSkipped_returnsFalse() {
        ScenarioRunNode parent = createSimpleNodeInGraph("p");
        ScenarioRunNode child = createSimpleNodeInGraph("c");
        child.getParentNodeList().add(parent);
        parent.setSkip(true);

        boolean result = isNotReadyForTraversal(engine, child, "run-1");

        assertFalse(result);
    }

    @Test
    void testIsNotReadyForTraversal_ready_returnsFalse() {
        ScenarioRunNode parent = createSimpleNodeInGraph("p");
        ScenarioRunNode child = createSimpleNodeInGraph("c");
        child.getParentNodeList().add(parent);
        parent.setCompleted(true);

        boolean result = isNotReadyForTraversal(engine, child, "run-1");

        assertFalse(result);
    }

    // -------------------------------------------------------------------------
    // stepByType tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testStepByType_findsMatchingStep() {
        // Use input type node for INPUT_NODE type search
        ScenarioRunGraph graph = createRunGraphWithTypes(java.util.Map.of("A", "input"), "A", "B");
        ScenarioRunStep inputStep = new ScenarioRunStep();
        inputStep.setNodeId("A");
        inputStep.setOutputData(Map.of("result", "data"));
        inputStep.setStatus("completed");

        ScenarioRunStep found = stepByType(engine,
                List.of(inputStep), graph, ScenarioNodeType.INPUT_NODE);

        assertSame(inputStep, found);
    }

    @Test
    void testStepByType_noMatchingType_returnsNull() {
        ScenarioRunGraph graph = createRunGraphWithTypes(java.util.Map.of("A", "processing"), "A");
        ScenarioRunStep processingStep = new ScenarioRunStep();
        processingStep.setNodeId("A");
        processingStep.setOutputData(Map.of("result", "data"));

        ScenarioRunStep found = stepByType(engine,
                List.of(processingStep), graph, ScenarioNodeType.OUTPUT_NODE);

        assertNull(found);
    }

    @Test
    void testStepByType_stepWithoutOutputData_returnsNull() {
        ScenarioRunGraph graph = createRunGraphWithTypes(java.util.Map.of("A", "input"), "A");
        ScenarioRunStep inputStep = new ScenarioRunStep();
        inputStep.setNodeId("A");
        inputStep.setOutputData(null);

        ScenarioRunStep found = stepByType(engine,
                List.of(inputStep), graph, ScenarioNodeType.INPUT_NODE);

        assertNull(found);
    }

    @Test
    void testStepByType_emptySteps_returnsNull() {
        ScenarioRunGraph graph = createRunGraphWithTypes(java.util.Map.of("A", "input"), "A");

        ScenarioRunStep found = stepByType(engine,
                List.of(), graph, ScenarioNodeType.INPUT_NODE);

        assertNull(found);
    }

    // -------------------------------------------------------------------------
    // stepResult tests (private @SuppressWarnings unused)
    // -------------------------------------------------------------------------

    @Test
    void testStepResult_returnsResultValue() {
        // Use input type node for INPUT_NODE type search
        ScenarioRunGraph graph = createRunGraphWithTypes(java.util.Map.of("A", "input"), "A");
        ScenarioRunStep inputStep = new ScenarioRunStep();
        inputStep.setNodeId("A");
        inputStep.setOutputData(Map.of("result", "RESULT_VALUE"));

        String result = stepResult(engine,
                List.of(inputStep), graph, ScenarioNodeType.INPUT_NODE);

        assertEquals("RESULT_VALUE", result);
    }

    @Test
    void testStepResult_noMatching_returnsNull() {
        ScenarioRunGraph graph = createRunGraphWithTypes(java.util.Map.of("A", "input"), "A");

        String result = stepResult(engine,
                List.of(), graph, ScenarioNodeType.INPUT_NODE);

        assertNull(result);
    }

    @Test
    void testStepResult_nullResult_returnsNull() {
        // Use input type node for INPUT_NODE type search
        ScenarioRunGraph graph = createRunGraphWithTypes(java.util.Map.of("A", "input"), "A");
        ScenarioRunStep inputStep = new ScenarioRunStep();
        inputStep.setNodeId("A");
        inputStep.setOutputData(Map.of("other_key", "value"));

        String result = stepResult(engine,
                List.of(inputStep), graph, ScenarioNodeType.INPUT_NODE);

        assertNull(result);
    }

    // -------------------------------------------------------------------------
    // restoreDocClasses tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testRestoreDocClasses_setsClassFromLoopOutput() {
        ScenarioRunGraph graph = createRunGraphWithNodes("loop");
        graph.addDocs(List.of("text1", "text2"), List.of("file1.txt", "file2.txt"));
        String loopOutput = "Классификация:\n<<<DOC_1|CLASS:ТЗ>>>\n<<<DOC_2|CLASS:КП>>>";

        restoreDocClasses(engine, graph, loopOutput);

        assertEquals("ТЗ", graph.getDocMap().get("DOC_1").getDocClass());
        assertEquals("КП", graph.getDocMap().get("DOC_2").getDocClass());
    }

    @Test
    void testRestoreDocClasses_noMarkers_doesNothing() {
        ScenarioRunGraph graph = createRunGraphWithNodes("loop");
        graph.addDocs(List.of("text1"), List.of("file1.txt"));

        restoreDocClasses(engine, graph, "Без меток классификации");

        assertNull(graph.getDocMap().get("DOC_1").getDocClass());
    }

    // -------------------------------------------------------------------------
    // restoreRealDocNames tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testRestoreRealDocNames_replacesAllNames() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setOutputData(Map.of("doc_names", "real1.pdf\nreal2.pdf"));
        List<String> names = new ArrayList<>(List.of("DOC_1", "DOC_2"));

        restoreRealDocNames(engine, step, names);

        assertEquals(List.of("real1.pdf", "real2.pdf"), names);
    }

    @Test
    void testRestoreRealDocNames_shuffledBlocks_pairedByDocIndex() {
        // блоки в result идут в порядке итерации HashMap — имена обязаны
        // сопоставляться по номеру DOC_i, а не по позиции (иначе документы
        // получают чужие имена и группировка agent_group рушится)
        ScenarioRunStep step = new ScenarioRunStep();
        step.setOutputData(Map.of("doc_names", "real1.pdf\nreal2.pdf\nreal3.pdf"));
        List<String> names = new ArrayList<>(List.of("DOC_3", "DOC_1", "DOC_2"));

        restoreRealDocNames(engine, step, names);

        assertEquals(List.of("real3.pdf", "real1.pdf", "real2.pdf"), names);
    }

    @Test
    void testRestoreRealDocNames_indexBeyondSaved_keepsTechnicalName() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setOutputData(Map.of("doc_names", "real1.pdf"));
        List<String> names = new ArrayList<>(List.of("DOC_1", "DOC_2"));

        restoreRealDocNames(engine, step, names);

        assertEquals(List.of("real1.pdf", "DOC_2"), names);
    }

    @Test
    void testRestoreRealDocNames_nullDocNames_keepsOriginal() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setOutputData(Map.of("other_key", "value"));
        List<String> names = new ArrayList<>(List.of("DOC_1"));

        restoreRealDocNames(engine, step, names);

        assertEquals(List.of("DOC_1"), names);
    }

    // -------------------------------------------------------------------------
    // saveInputDocNames tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testSaveInputDocNames_inputNode_savesNamesToStep() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        graph.addDocs(List.of("doc1", "doc2"), List.of("file1.pdf", "file2.pdf"));
        ScenarioRunNode inputNode = graph.getNodeMap().get("input-1");

        // имена пишутся тем же UPDATE, что и результат шага (аргумент docNames), а не отдельным appendOutputData
        assertEquals("file1.pdf\nfile2.pdf", inputDocNames(engine, inputNode));
        verify(stepService, never()).appendOutputData(any(), any(), any());
    }

    @Test
    void testSaveInputDocNames_notInputNode_doesNotCallService() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("proc-1", "processing"), "proc-1");
        graph.addDocs(List.of("doc1"), List.of("file1.pdf"));
        ScenarioRunNode procNode = graph.getNodeMap().get("proc-1");

        assertNull(inputDocNames(engine, procNode));
    }

    @Test
    void testSaveInputDocNames_emptyDocs_doesNotCallService() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        ScenarioRunNode inputNode = graph.getNodeMap().get("input-1");

        assertNull(inputDocNames(engine, inputNode));
    }

    @Test
    void testSaveInputDocNames_workNoteAndLabelGap_savedByLabelIndex() {
        // возобновлённый прогон: документы под исходными метками (с пропуском DOC_2)
        // и чекпойнт агента рабочим файлом — имена всё равно сохраняются по номеру DOC_i
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        graph.putDoc("DOC_3", "c.pdf", "текст 3");
        graph.putDoc("DOC_1", "a.pdf", "текст 1");
        graph.addWorkingDoc("чекпойнт-agent-1-прерванного-прогона.md", "наблюдения");

        assertEquals("a.pdf\n\nc.pdf", inputDocNames(engine, graph.getNodeMap().get("input-1")));
    }

    @Test
    void testSaveInputDocNames_onlyWorkNotes_doesNotCallService() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        graph.addWorkingDoc("заметка.md", "текст");

        assertNull(inputDocNames(engine, graph.getNodeMap().get("input-1")));
    }

    @Test
    void testSaveInputDocNames_hugeLabelIndex_skippedWithoutGrowingList() {
        // метка DOC_2000000000 из текста документа не раздувает список имён до OutOfMemoryError
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        graph.putDoc("DOC_1", "a.pdf", "текст 1");
        graph.putDoc("DOC_2000000000", "чужая метка", "текст из документа");

        assertEquals("a.pdf", inputDocNames(engine, graph.getNodeMap().get("input-1")));
    }

    // -------------------------------------------------------------------------
    // restoreDocsFromSteps tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testRestoreDocsFromSteps_hugeLabelInsideDocText_blockSkipped() {
        // текст DOC_1 дословно содержит «<<<END_DOC_1>>>» и блок с огромным номером:
        // такой блок не становится документом, нормальные метки восстанавливаются
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        ScenarioRunStep inputStep = new ScenarioRunStep();
        inputStep.setNodeId("input-1");
        inputStep.setOutputData(Map.of(
                "result", "<<<DOC_1>>>\nx\n<<<END_DOC_1>>>\n\n<<<DOC_2000000000>>>\ny\n"
                        + "<<<END_DOC_2000000000>>>\n<<<END_DOC_1>>>",
                "doc_names", "a.pdf"));

        restoreDocsFromSteps(engine, graph, List.of(inputStep));

        assertEquals(1, graph.getDocMap().size());
        assertEquals("x", graph.getDocMap().get("DOC_1").getText());
        assertEquals("a.pdf", graph.getDocMap().get("DOC_1").getFilename());
        assertNull(graph.getDocMap().get("DOC_2000000000"));
    }

    @Test
    void testRestoreDocsFromSteps_hashMapOrderAndGap_docsKeepOriginalLabels() {
        // блоки в порядке итерации HashMap (DOC_3 раньше DOC_1), DOC_2 отсутствует:
        // документ обязан вернуться под своей меткой — со своим текстом и своим именем
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        ScenarioRunStep inputStep = new ScenarioRunStep();
        inputStep.setNodeId("input-1");
        inputStep.setOutputData(Map.of(
                "result", "<<<DOC_3>>>\nтекст 3\n<<<END_DOC_3>>>\n\n<<<DOC_1>>>\nтекст 1\n<<<END_DOC_1>>>",
                "doc_names", "a.pdf\nb.pdf\nc.pdf"));

        restoreDocsFromSteps(engine, graph, List.of(inputStep));

        assertEquals(2, graph.getDocMap().size());
        assertEquals("текст 1", graph.getDocMap().get("DOC_1").getText());
        assertEquals("a.pdf", graph.getDocMap().get("DOC_1").getFilename());
        assertEquals("текст 3", graph.getDocMap().get("DOC_3").getText());
        assertEquals("c.pdf", graph.getDocMap().get("DOC_3").getFilename());
        assertNull(graph.getDocMap().get("DOC_2"));
    }

    @Test
    void testRestoreDocsFromSteps_shuffledBlocks_restoredInNumericOrder() {
        // блоки шага «Вход» старого прогона в хеш-порядке (DOC_12, DOC_3, DOC_1, DOC_10, DOC_2):
        // docMap восстанавливается в числовом порядке DOC_1..DOC_12 — его наследуют docList детей входа
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("input-1", "input"), "input-1");
        ScenarioRunStep inputStep = new ScenarioRunStep();
        inputStep.setNodeId("input-1");
        inputStep.setOutputData(Map.of("result",
                "<<<DOC_12>>>\nт12\n<<<END_DOC_12>>>\n\n<<<DOC_3>>>\nт3\n<<<END_DOC_3>>>\n\n"
                        + "<<<DOC_1>>>\nт1\n<<<END_DOC_1>>>\n\n<<<DOC_10>>>\nт10\n<<<END_DOC_10>>>\n\n"
                        + "<<<DOC_2>>>\nт2\n<<<END_DOC_2>>>"));

        restoreDocsFromSteps(engine, graph, List.of(inputStep));

        assertEquals(List.of("DOC_1", "DOC_2", "DOC_3", "DOC_10", "DOC_12"),
                new ArrayList<>(graph.getDocMap().keySet()));
        assertEquals("т10", graph.getDocMap().get("DOC_10").getText());
        assertEquals("т2", graph.getDocMap().get("DOC_2").getText());
    }

    // -------------------------------------------------------------------------
    // isBuiltOnNodeError tests
    // -------------------------------------------------------------------------

    @Test
    void testIsBuiltOnNodeError_previousOutputWithErrorContribution_returnsTrue() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setInputData(Map.of("documents_text", "",
                "previous_output", "=== РЕЗУЛЬТАТ ОТ \"Анализ\" (ОШИБКА) ===\n"
                        + "[ОШИБКА УЗЛА «Анализ»: Не удалось выполнить запрос к GigaChat]"));

        assertTrue(ScenarioEngine.isBuiltOnNodeError(step, 0));
    }

    @Test
    void testIsBuiltOnNodeError_promptWithErrorOutputExpression_returnsTrue() {
        // {{output:Анализ}} подставил результат упавшего узла прямо в промпт
        ScenarioRunStep step = new ScenarioRunStep();
        step.setInputData(Map.of("documents_text", "", "previous_output", ""));
        step.setPromptUsed("Сверь: [ОШИБКА УЗЛА «Анализ»: таймаут]");

        assertTrue(ScenarioEngine.isBuiltOnNodeError(step, 0));
    }

    @Test
    void testIsBuiltOnNodeError_cleanOrMissingInput_returnsFalse() {
        ScenarioRunStep clean = new ScenarioRunStep();
        clean.setInputData(Map.of("documents_text", "",
                "previous_output", "=== РЕЗУЛЬТАТ ОТ \"Анализ\" ===\nНМЦ 100 руб."));
        clean.setPromptUsed("Промпт без ошибок");
        ScenarioRunStep empty = new ScenarioRunStep();

        assertFalse(ScenarioEngine.isBuiltOnNodeError(clean, 0));
        assertFalse(ScenarioEngine.isBuiltOnNodeError(empty, 0));
    }

    @Test
    void testIsBuiltOnNodeError_prefixOnlyFromDocument_returnsFalse() {
        // документ — выгрузка итога прогона с чужой ошибкой; он целиком попал в промпт
        String docText = "Итог: [ОШИБКА УЗЛА «Поиск»: таймаут]";
        ScenarioRunStep step = new ScenarioRunStep();
        step.setInputData(Map.of("documents_text", docText, "previous_output", ""));
        step.setPromptUsed("Проверь документ\n\n" + docText);

        assertFalse(ScenarioEngine.isBuiltOnNodeError(step, 0));
    }

    @Test
    void testIsBuiltOnNodeError_errorExpressionOverDocumentWithPrefix_returnsTrue() {
        // тот же документ, но {{output:Анализ}} подставил в промпт ещё и результат упавшего узла
        String docText = "Итог: [ОШИБКА УЗЛА «Поиск»: таймаут]";
        ScenarioRunStep step = new ScenarioRunStep();
        step.setInputData(Map.of("documents_text", docText, "previous_output", ""));
        step.setPromptUsed("Сверь: [ОШИБКА УЗЛА «Анализ»: таймаут]\n\n" + docText);

        assertTrue(ScenarioEngine.isBuiltOnNodeError(step, 0));
    }

    // -------------------------------------------------------------------------
    // isRestorableLlmStep tests (private)
    // -------------------------------------------------------------------------

    @Test
    void testIsRestorableLlmStep_processingCompleted_returnsTrue() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("proc-1", "processing"), "proc-1");
        ScenarioRunNode node = graph.getNodeMap().get("proc-1");
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("completed");
        step.setOutputData(Map.of("result", "data"));

        boolean result = isRestorableLlmStep(engine, step, node);

        assertTrue(result);
    }

    @Test
    void testIsRestorableLlmStep_loopCompleted_returnsTrue() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("loop-1", "loop"), "loop-1");
        ScenarioRunNode node = graph.getNodeMap().get("loop-1");
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("completed");
        step.setOutputData(Map.of("result", "data"));

        boolean result = isRestorableLlmStep(engine, step, node);

        assertTrue(result);
    }

    @Test
    void testIsRestorableLlmStep_nullNode_returnsFalse() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("completed");
        step.setOutputData(Map.of("result", "data"));

        boolean result = isRestorableLlmStep(engine, step, null);

        assertFalse(result);
    }

    @Test
    void testIsRestorableLlmStep_notCompleted_returnsFalse() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("proc-1", "processing"), "proc-1");
        ScenarioRunNode node = graph.getNodeMap().get("proc-1");
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("failed");
        step.setOutputData(Map.of("result", "data"));

        boolean result = isRestorableLlmStep(engine, step, node);

        assertFalse(result);
    }

    @Test
    void testIsRestorableLlmStep_nonLlmNode_returnsFalse() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("sw-1", "switch"), "sw-1");
        ScenarioRunNode node = graph.getNodeMap().get("sw-1");
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("completed");
        step.setOutputData(Map.of("result", "data"));

        boolean result = isRestorableLlmStep(engine, step, node);

        assertFalse(result);
    }

    @Test
    void testIsRestorableLlmStep_nullOutputData_returnsFalse() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("proc-1", "processing"), "proc-1");
        ScenarioRunNode node = graph.getNodeMap().get("proc-1");
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("completed");
        step.setOutputData(null);

        boolean result = isRestorableLlmStep(engine, step, node);

        assertFalse(result);
    }

    @Test
    void testIsRestorableLlmStep_nullResultKey_returnsFalse() {
        ScenarioRunGraph graph = createRunGraphWithTypes(Map.of("proc-1", "processing"), "proc-1");
        ScenarioRunNode node = graph.getNodeMap().get("proc-1");
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("completed");
        step.setOutputData(Map.of("other", "value"));

        boolean result = isRestorableLlmStep(engine, step, node);

        assertFalse(result);
    }

    // -------------------------------------------------------------------------
    // Helper methods for testing private/package-private methods
    // -------------------------------------------------------------------------

    private void validateGraph(ScenarioEngine scenarioEngine, GraphDataDto graphData) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("validateGraph", GraphDataDto.class);
            method.setAccessible(true);
            method.invoke(scenarioEngine, graphData);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private List<String> topologicalSort(ScenarioEngine scenarioEngine, GraphDataDto graphData) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("topologicalSort", GraphDataDto.class);
            method.setAccessible(true);
            return (List<String>) method.invoke(scenarioEngine, graphData);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private GraphDataDto stripNoteNodes(GraphDataDto graphData) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("stripNoteNodes", GraphDataDto.class);
            method.setAccessible(true);
            return (GraphDataDto) method.invoke(null, graphData);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    @SuppressWarnings("unchecked")
    private Set<String> getNodeIds(GraphDataDto graphData) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("getNodeIds", GraphDataDto.class);
            method.setAccessible(true);
            return (Set<String>) method.invoke(null, graphData);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private List<String> getDisconnectedNodes(ScenarioEngine scenarioEngine, GraphDataDto graphData,
                                              Set<String> nodeIds) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("getDisconnectedNodes",
                    GraphDataDto.class, Set.class);
            method.setAccessible(true);
            return (List<String>) method.invoke(scenarioEngine, graphData, nodeIds);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private void pauseFutureGet(CompletableFuture<Void> future, String runId) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("pauseFutureGet",
                    CompletableFuture.class, String.class);
            method.setAccessible(true);
            method.invoke(null, future, runId);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private void evictStepEvents(ScenarioEngine scenarioEngine, String runId) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("evictStepEvents", String.class);
            method.setAccessible(true);
            method.invoke(scenarioEngine, runId);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private void evictExpiredStepEvents(ScenarioEngine scenarioEngine) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("evictExpiredStepEvents");
            method.setAccessible(true);
            method.invoke(scenarioEngine);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private boolean isErrorEdge(ScenarioEngine scenarioEngine,
                                ScenarioRunNode from, ScenarioRunNode to) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("isErrorEdge",
                    ScenarioRunNode.class, ScenarioRunNode.class);
            method.setAccessible(true);
            return (boolean) method.invoke(scenarioEngine, from, to);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private boolean isAllParentCompleted(ScenarioEngine scenarioEngine, ScenarioRunNode node) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("isAllParentCompleted",
                    ScenarioRunNode.class);
            method.setAccessible(true);
            return (boolean) method.invoke(scenarioEngine, node);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private boolean isNotReadyForTraversal(ScenarioEngine scenarioEngine,
                                           ScenarioRunNode node, String runId) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("isNotReadyForTraversal",
                    ScenarioRunNode.class, String.class);
            method.setAccessible(true);
            return (boolean) method.invoke(scenarioEngine, node, runId);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private ScenarioRunStep stepByType(ScenarioEngine scenarioEngine,
                                       List<ScenarioRunStep> steps,
                                       ScenarioRunGraph graph,
                                       ScenarioNodeType type) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("stepByType",
                    List.class, ScenarioRunGraph.class, ScenarioNodeType.class);
            method.setAccessible(true);
            return (ScenarioRunStep) method.invoke(scenarioEngine, steps, graph, type);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private String stepResult(ScenarioEngine scenarioEngine,
                              List<ScenarioRunStep> steps,
                              ScenarioRunGraph graph,
                              ScenarioNodeType type) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("stepResult",
                    List.class, ScenarioRunGraph.class, ScenarioNodeType.class);
            method.setAccessible(true);
            return (String) method.invoke(scenarioEngine, steps, graph, type);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private void restoreDocClasses(ScenarioEngine scenarioEngine,
                                   ScenarioRunGraph graph, String output) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("restoreDocClasses",
                    ScenarioRunGraph.class, String.class);
            method.setAccessible(true);
            method.invoke(scenarioEngine, graph, output);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private void restoreRealDocNames(ScenarioEngine scenarioEngine,
                                     ScenarioRunStep step, List<String> names) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("restoreRealDocNames",
                    ScenarioRunStep.class, List.class);
            method.setAccessible(true);
            method.invoke(scenarioEngine, step, names);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private String inputDocNames(ScenarioEngine scenarioEngine, ScenarioRunNode node) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("inputDocNames", ScenarioRunNode.class);
            method.setAccessible(true);
            return (String) method.invoke(scenarioEngine, node);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private void restoreDocsFromSteps(ScenarioEngine scenarioEngine,
                                      ScenarioRunGraph graph, List<ScenarioRunStep> steps) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("restoreDocsFromSteps",
                    ScenarioRunGraph.class, List.class);
            method.setAccessible(true);
            method.invoke(scenarioEngine, graph, steps);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private boolean isRestorableLlmStep(ScenarioEngine scenarioEngine,
                                        ScenarioRunStep step, ScenarioRunNode node) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("isRestorableLlmStep",
                    ScenarioRunStep.class, ScenarioRunNode.class);
            method.setAccessible(true);
            return (boolean) method.invoke(scenarioEngine, step, node);
        } catch (Exception e) {
            throw unwrapException(e);
        }
    }

    private RuntimeException unwrapException(Exception e) {
        if (e instanceof java.lang.reflect.InvocationTargetException) {
            Throwable cause = e.getCause();
            if (cause != null) {
                if (cause instanceof RuntimeException) {
                    return (RuntimeException) cause;
                }
                if (cause instanceof Exception) {
                    return unwrapException((Exception) cause);
                }
                return new RuntimeException(cause);
            }
        }
        if (e instanceof RuntimeException) {
            Throwable cause = e.getCause();
            if (cause != null) {
                return unwrapException((Exception) cause);
            }
        }
        return new RuntimeException(e);
    }

    private void assertDoesNotThrow(Runnable runnable) {
        try {
            runnable.run();
        } catch (Exception e) {
            throw new AssertionError("Should not have thrown exception", e);
        }
    }

    // -------------------------------------------------------------------------
    // Helpers for executeSubScenarioInline
    // -------------------------------------------------------------------------

    /**
     * Исполнитель под-сценария: возвращает результат и активирует детей
     * (как настоящие узлы), чтобы output-узел под-графа выполнился.
     */
    private static AbstractScenarioExecutor activatingExecutor(ScenarioRunNode runNode, String result) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                runNode.getChildNodeList().forEach(child -> child.setSkip(false));
                return result;
            }
        };
    }

    private static Scenario createValidSubScenario(String inputId, String outputId) {
        NodeDto inputNode = createInputNode(inputId);
        NodeDto outputNode = createOutputNode(outputId);
        EdgeDto edge = createEdge("e1", inputId, outputId);
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));
        Scenario sub = new Scenario();
        sub.setId(UUID.randomUUID());
        sub.setName("sub");
        sub.setGraphData(GraphDataMapper.fromDto(graphData));
        return sub;
    }

    private static ScenarioRunNode createParentNodeWithInput(String inputText) {
        NodeDto parentDto = NodeDto.builder()
                .id("parent-node")
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Parent").value(UUID.randomUUID().toString()).build())
                .position(new PositionDto(0, 0))
                .build();
        NodeDto siblingDto = createInputNode("sibling-input");
        EdgeDto edge = createEdge("e-parent", "sibling-input", "parent-node");
        GraphDataDto parentGraphData = new GraphDataDto(List.of(siblingDto, parentDto), List.of(edge));
        ScenarioRunGraph parentGraph = new ScenarioRunGraph(parentGraphData);
        ScenarioRunNode parentNode = parentGraph.getNodeMap().get("parent-node");
        parentNode.getInput().add(inputText);
        return parentNode;
    }

    private static ScenarioRunNode createParentNodeWithDocs(String docId, String docText, String filename) {
        NodeDto parentDto = NodeDto.builder()
                .id("parent-node")
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Parent").value(UUID.randomUUID().toString()).build())
                .position(new PositionDto(0, 0))
                .build();
        NodeDto siblingDto = createInputNode("sibling-input");
        EdgeDto edge = createEdge("e-parent", "sibling-input", "parent-node");
        GraphDataDto parentGraphData = new GraphDataDto(List.of(siblingDto, parentDto), List.of(edge));
        ScenarioRunGraph parentGraph = new ScenarioRunGraph(parentGraphData);
        parentGraph.addDocs(List.of(docText), List.of(filename));
        ScenarioRunNode parentNode = parentGraph.getNodeMap().get("parent-node");
        parentNode.getDocList().add(docId);
        return parentNode;
    }

    /**
     * Создаёт один узел в изолированном графе для тестов приватных хелперов.
     */
    private static ScenarioRunNode createSimpleNodeInGraph(String id) {
        return createRunGraphWithNodes(id).getNodeMap().get(id);
    }

    /**
     * Создаёт граф с произвольным набором изолированных узлов
     * (для тестов приватных хелперов, которым не нужен реальный обход).
     */
    private static ScenarioRunGraph createRunGraphWithNodes(String... nodeIds) {
        return createRunGraphWithTypes(java.util.Map.of(), nodeIds);
    }

    /**
     * Создаёт граф с произвольным набором узлов; для узлов, перечисленных в {@code typeOverrides},
     * тип берётся из мапы, остальные получают тип "processing".
     */
    private static ScenarioRunGraph createRunGraphWithTypes(java.util.Map<String, String> typeOverrides,
                                                           String... nodeIds) {
        var dtos = new ArrayList<NodeDto>();
        for (String id : nodeIds) {
            String type = typeOverrides.getOrDefault(id, "processing");
            dtos.add(NodeDto.builder()
                    .id(id)
                    .type(type)
                    .data(NodeDataDto.builder().label("N " + id).build())
                    .position(new PositionDto(0, 0))
                    .build());
        }
        return new ScenarioRunGraph(new GraphDataDto(dtos, List.of()));
    }

    // -------------------------------------------------------------------------
    // Factory methods for test data
    // -------------------------------------------------------------------------

    private static NodeDto createNode(String id, String type) {
        return NodeDto.builder()
                .id(id)
                .type(type)
                .data(NodeDataDto.builder().label("Node " + id).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static NodeDto createInputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static NodeDto createProcessingNode(String id, String prompt) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Processing").prompt(prompt).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static NodeDto createOutputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static EdgeDto createEdge(String id, String source, String target) {
        return new EdgeDto(id, source, target, new EdgeDataDto(null));
    }

    // -------------------------------------------------------------------------
    // Edge case tests
    // -------------------------------------------------------------------------

    @Test
    void testEnableStepMode_withMultipleRunIds() {
        String runId1 = UUID.randomUUID().toString();
        String runId2 = UUID.randomUUID().toString();
        String runId3 = UUID.randomUUID().toString();

        engine.enableStepMode(runId1);
        engine.enableStepMode(runId2);
        engine.enableStepMode(runId3);

        engine.cleanupRun(runId1);
        engine.cleanupRun(runId2);
        engine.cleanupRun(runId3);
        assertNotNull(engine);
    }

    @Test
    void testDisableStepMode_withActivePause() {
        String runId = UUID.randomUUID().toString();
        engine.enableStepMode(runId);
        engine.continueStep(runId);
        engine.disableStepMode(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    @Test
    void testCleanupRun_idempotent() {
        String runId = UUID.randomUUID().toString();
        engine.cleanupRun(runId);
        engine.cleanupRun(runId);
        engine.cleanupRun(runId);
        assertNotNull(engine);
    }

    // -------------------------------------------------------------------------
    // corp15: маркеры ошибки в документах — по шагу входного узла; кэш документов не по id прогона
    // -------------------------------------------------------------------------

    @Test
    void testIsBuiltOnNodeError_docMarkersFromInputStep_coverPromptMarkers() {
        // documents_text хранит сводку (метки + sha256); маркеры в документах считаются по шагу входного узла
        ScenarioRunStep step = new ScenarioRunStep();
        step.setInputData(Map.of("documents_text", "DOC_1\nsha256:abc", "previous_output", ""));
        step.setPromptUsed("Проверь документ\n\nИтог: [ОШИБКА УЗЛА «Поиск»: таймаут]");

        assertTrue(ScenarioEngine.isBuiltOnNodeError(step, 0));
        assertFalse(ScenarioEngine.isBuiltOnNodeError(step, 1));
    }

    @Test
    void testCleanupRun_doesNotClearDocumentsCache() {
        // кэш документов живёт по ключу «сценарий + пользователь» и чистится по TTL, а не по id прогона
        engine.cleanupRun(UUID.randomUUID().toString());

        verify(cacheService, never()).clearCache(any());
    }
}
