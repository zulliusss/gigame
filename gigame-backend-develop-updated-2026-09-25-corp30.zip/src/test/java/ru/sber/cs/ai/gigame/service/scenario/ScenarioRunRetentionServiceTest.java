package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.PlatformTransactionManager;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты чистки прогонов по сроку хранения и лёгкой ретенции тяжёлых полей шагов.
 */
@ExtendWith(MockitoExtension.class)
class ScenarioRunRetentionServiceTest {

    @Mock
    private ScenarioRunRepository runRepository;
    @Mock
    private AgentQuestionRepository questionRepository;
    @Mock
    private ScenarioRunStepRepository stepRepository;
    @Mock
    private PlatformTransactionManager transactionManager;

    private ScenarioRunRetentionService service;

    @BeforeEach
    void setUp() {
        service = new ScenarioRunRetentionService(transactionManager, runRepository, questionRepository, stepRepository);
    }

    @Test
    void purge_disabledByDefault_deletesNothing() {
        assertEquals(0, service.purgeExpiredRuns(OffsetDateTime.now()));

        verify(runRepository, never()).findExpiredRunIds(any());
        verify(runRepository, never()).deleteAllByIdInBatch(any());
        verify(questionRepository, never()).deleteByRunIds(any());
        // предупреждение о выключенной чистке при старте не падает
        assertDoesNotThrow(() -> service.warnIfRetentionDisabled());
    }

    @Test
    void purge_deletesExpiredRunsWithQuestionsInBatches() {
        service.setRetentionDays(30);
        List<UUID> ids = Stream.generate(UUID::randomUUID)
                .limit(ScenarioRunRetentionService.BATCH_SIZE + 1)
                .toList();
        OffsetDateTime now = OffsetDateTime.of(2026, 9, 15, 12, 0, 0, 0, ZoneOffset.UTC);
        when(runRepository.findExpiredRunIds(now.minusDays(30))).thenReturn(ids);

        assertEquals(ids.size(), service.purgeExpiredRuns(now));

        List<UUID> firstBatch = ids.subList(0, ScenarioRunRetentionService.BATCH_SIZE);
        List<UUID> secondBatch = ids.subList(ScenarioRunRetentionService.BATCH_SIZE, ids.size());
        verify(questionRepository).deleteByRunIds(firstBatch);
        verify(questionRepository).deleteByRunIds(secondBatch);
        verify(runRepository).deleteAllByIdInBatch(firstBatch);
        verify(runRepository).deleteAllByIdInBatch(secondBatch);
        verify(runRepository, times(2)).deleteAllByIdInBatch(any());
    }

    @Test
    void purge_nothingExpired_deletesNothing() {
        service.setRetentionDays(7);
        when(runRepository.findExpiredRunIds(any())).thenReturn(List.of());

        assertEquals(0, service.purgeExpiredRuns(OffsetDateTime.now()));

        verify(runRepository, never()).deleteAllByIdInBatch(any());
        verify(questionRepository, never()).deleteByRunIds(any());
    }

    @Test
    void scheduledPurge_swallowsDatabaseErrors() {
        service.setRetentionDays(1);
        when(runRepository.findExpiredRunIds(any())).thenThrow(new IllegalStateException("БД недоступна"));

        assertDoesNotThrow(() -> service.purgeExpiredRuns());
    }

    @Test
    void purgeOrphanQuestions_deletesQuestionsOfMissingRuns() {
        // corp17 (M9): вопросы прогонов, удалённых каскадом вместе со сценарием, чистятся отдельно
        when(questionRepository.deleteOrphans()).thenReturn(3);

        assertEquals(3, service.purgeOrphanQuestions());

        verify(questionRepository).deleteOrphans();
    }

    @Test
    void scheduledPurge_alsoPurgesOrphanQuestions_evenWhenRetentionDisabled() {
        when(questionRepository.deleteOrphans()).thenReturn(0);

        service.purgeExpiredRuns();

        verify(runRepository, never()).findExpiredRunIds(any());
        verify(questionRepository).deleteOrphans();
    }

    @Test
    void stepPayloads_clearedAfterConfiguredDays_evenWhenRunRetentionDisabled() {
        // storage-5: чистка прогонов выключена (0), но тяжёлые поля шагов старше 30 дней очищаются
        OffsetDateTime now = OffsetDateTime.of(2026, 9, 23, 12, 0, 0, 0, ZoneOffset.UTC);
        when(stepRepository.clearPayloadsBefore(now.minusDays(30))).thenReturn(7);

        assertEquals(7, service.purgeStepPayloads(now));

        verify(stepRepository).clearPayloadsBefore(now.minusDays(30));
        verify(runRepository, never()).findExpiredRunIds(any());
    }

    @Test
    void stepPayloads_notClearedWhenDisabled_andScheduledPurgeCallsIt() {
        service.setStepPayloadRetentionDays(0);
        assertEquals(0, service.purgeStepPayloads(OffsetDateTime.now()));
        verify(stepRepository, never()).clearPayloadsBefore(any());

        service.setStepPayloadRetentionDays(10);
        when(stepRepository.clearPayloadsBefore(any())).thenReturn(0);
        when(questionRepository.deleteOrphans()).thenReturn(0);
        service.purgeExpiredRuns();
        verify(stepRepository).clearPayloadsBefore(any());
    }
}
