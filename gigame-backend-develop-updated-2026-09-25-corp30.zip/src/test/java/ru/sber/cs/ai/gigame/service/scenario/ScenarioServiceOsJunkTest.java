package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.ScanOcrService;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Служебные файлы Windows и Office среди файлов, загруженных россыпью (папкой): письма 25.09.2026 — Егорова «Ошибка
 * 403» (файл блокировки Word «~$говор РК-02-1442-25.docx» давал предупреждение «файл не обработан (повреждён…)»),
 * Борисов «Иновью» (35 копий desktop.ini). В разбор не идут, о них одно предупреждение загрузки.
 */
@ExtendWith(MockitoExtension.class)
@SuppressWarnings("unused")
class ScenarioServiceOsJunkTest {

    private static final String CONTRACT_TEXT = "Текст договора достаточной длины для порога скан-детекции";

    @Mock
    private ScenarioRepository scenarioRepository;
    @Mock
    private ScenarioRunRepository scenarioRunRepository;
    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;
    @Mock
    private ScenarioVersionRepository scenarioVersionRepository;
    @Mock
    private ScenarioEngine scenarioEngine;
    @Mock
    private DocumentService documentService;
    @Mock
    private ScanOcrService scanOcrService;

    @InjectMocks
    private ScenarioService scenarioService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(scenarioService, "minParsedChars", 40);
    }

    private FilePart filePart(String filename, byte[] content) {
        FilePart file = mock(FilePart.class);
        when(file.filename()).thenReturn(filename);
        lenient().when(file.headers()).thenReturn(null);
        when(file.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap(content)));
        return file;
    }

    private static List<String> warnings(List<ServerSentEvent<Map<String, Object>>> events) {
        return events.stream()
                .filter(e -> e.data() != null && "upload_warning".equals(e.data().get("type")))
                .map(e -> String.valueOf(e.data().get("message")))
                .toList();
    }

    @Test
    void looseOfficeLockAndDesktopIniAreSkippedWithOneWarning() throws IOException {
        List<FilePart> files = new ArrayList<>();
        files.add(filePart("~$говор РК-02-1442-25.docx", new byte[162]));
        files.add(filePart("Договор РК-02-1442-25.docx", "docx".getBytes()));
        for (int i = 0; i < 7; i++) {
            files.add(filePart(i == 0 ? "desktop.ini" : "desktop (" + i + ").ini", "[.ShellClassInfo]".getBytes()));
        }
        when(documentService.parseText(any(InputStream.class), eq("docx"))).thenReturn(CONTRACT_TEXT);

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(files, events);

        assertEquals(1, docs.size());
        assertEquals("Договор РК-02-1442-25.docx", docs.get(0).filename());
        verify(documentService, times(1)).parseText(any(InputStream.class), any());
        List<String> warnings = warnings(events);
        assertEquals(1, warnings.size(), warnings.toString());
        assertEquals("пропущено служебных файлов Windows/macOS/Office: 8 (~$говор РК-02-1442-25.docx, desktop.ini,"
                + " desktop (1).ini, desktop (2).ini, desktop (3).ini, …) — это не документы, в прогон не идут", warnings.get(0));
    }

    @Test
    void batchWithoutServiceFilesHasNoWarning() throws IOException {
        when(documentService.parseText(any(InputStream.class), eq("docx"))).thenReturn(CONTRACT_TEXT);

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(filePart("Договор.docx", "docx".getBytes())), events);

        assertEquals(1, docs.size());
        assertTrue(warnings(events).isEmpty(), warnings(events).toString());
    }
}
