package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.dto.agent.AgentPlanResponseDto;
import ru.sber.cs.ai.gigame.dto.agent.AgentQuestionResponseDto;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputViews;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты типизированных DTO-запросов памяти агента: тела запросов
 * десериализуются из snake_case JSON без Map (требование СОВЫ).
 */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {AgentMemoryController.class, TestConfiguration.class})
@WebFluxTest(controllers = AgentMemoryController.class)
// холодный старт контекста на нагруженной машине превышает дефолтные 5с
@AutoConfigureWebTestClient(timeout = "30000")
class AgentMemoryControllerTest {

    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private AgentMemoryService memoryService;
    @MockitoBean
    private ScenarioRunRepository runRepository;
    @MockitoBean
    private ScenarioRunStepRepository stepRepository;
    @MockitoBean
    private ScenarioService scenarioService;

    private String userId;
    private AgentLesson lessonEntity;

    @BeforeEach
    void setUp() {
        userId = "test-user";
        lessonEntity = new AgentLesson();
        lessonEntity.setId(UUID.randomUUID());
        lessonEntity.setLesson("Суммы брать из УПД");
    }

    @Test
    void addLesson_ShouldParseSnakeCaseBody() {
        UUID scenarioId = UUID.randomUUID();
        when(memoryService.addLesson(scenarioId,
                "Суммы брать из УПД", AgentLesson.SOURCE_USER))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"" + scenarioId + "\", \"lesson\": \"Суммы брать из УПД\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).addLesson(scenarioId,
                "Суммы брать из УПД", AgentLesson.SOURCE_USER);
    }

    @Test
    void addLesson_ShouldTreatBlankScenarioIdAsGlobal() {
        when(memoryService.addLesson(isNull(),
                eq("Общий урок"), eq(AgentLesson.SOURCE_USER)))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"\", \"lesson\": \"Общий урок\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).addLesson(isNull(),
                eq("Общий урок"), eq(AgentLesson.SOURCE_USER));
    }

    @Test
    void updateLesson_ShouldParseLessonBody() {
        UUID id = UUID.randomUUID();
        when(memoryService.updateLesson(id, "Новый текст"))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.put()
                .uri("/api/agent/lessons/{id}", id)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"lesson\": \"Новый текст\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).updateLesson(id, "Новый текст");
    }

    @Test
    void answerQuestion_ShouldParseAnswerBody() {
        UUID id = UUID.randomUUID();
        AgentQuestion question = question(id);
        when(memoryService.getQuestionRunId(id)).thenReturn(question.getRunId());
        question.setAnswer("Дата — из штампа ЭП");
        question.setAnsweredAt(OffsetDateTime.of(2026, 9, 15, 13, 4, 37, 669_778_312, ZoneOffset.ofHours(3)));
        when(memoryService.answerQuestion(id, "Дата — из штампа ЭП"))
                .thenReturn(AgentQuestionResponseDto.from(question));

        webClient.post()
                .uri("/api/agent/questions/{id}/answer", id)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"answer\": \"Дата — из штампа ЭП\"}")
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.run_id").isEqualTo(question.getRunId().toString())
                .jsonPath("$.node_label").isEqualTo("Агент")
                .jsonPath("$.answer").isEqualTo("Дата — из штампа ЭП")
                .jsonPath("$.answered_at").isEqualTo("2026-09-15T10:04:37.669778Z")
                .jsonPath("$.runId").doesNotExist()
                .jsonPath("$.answeredAt").doesNotExist()
                .jsonPath("$.createdAt").doesNotExist();

        // вопрос цитирует документы прогона — доступ к прогону проверяется до ответа
        verify(scenarioService).checkRunAccess(question.getRunId());
        verify(memoryService).answerQuestion(id, "Дата — из штампа ЭП");
    }

    @Test
    void getLessons_ShouldReturnListByScenario() {
        UUID scenarioId = UUID.randomUUID();
        when(memoryService.getLessons(scenarioId))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/lessons")
                        .queryParam("scenario_id", scenarioId).build())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getLessons(scenarioId);
    }

    @Test
    void getLessons_ShouldReturnGlobalWhenNoScenario() {
        when(memoryService.getLessons(isNull()))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.get()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getLessons(isNull());
    }

    @Test
    void getLessons_ShouldPassUserIdToService() {
        // уроки фильтруются по пользователю из заголовка: сервис видит его в CurrentUserHolder
        AtomicReference<String> seenUser = new AtomicReference<>();
        when(memoryService.getLessons(isNull())).thenAnswer(inv -> {
            seenUser.set(CurrentUserHolder.getCurrentUser());
            return List.of();
        });

        webClient.get()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        assertEquals(userId, seenUser.get());
    }

    @Test
    void getLessons_WithoutHeader_ServiceSeesAnonymous() {
        AtomicReference<String> seenUser = new AtomicReference<>();
        when(memoryService.getLessons(isNull())).thenAnswer(inv -> {
            seenUser.set(CurrentUserHolder.getCurrentUser());
            return List.of();
        });

        webClient.get()
                .uri("/api/agent/lessons")
                .exchange()
                .expectStatus().isOk();

        assertEquals("anonymous", seenUser.get());
    }

    @Test
    void getPlans_ShouldPassUserIdToService() {
        UUID scenarioId = UUID.randomUUID();
        AtomicReference<String> seenUser = new AtomicReference<>();
        when(memoryService.getPlans(scenarioId)).thenAnswer(inv -> {
            seenUser.set(CurrentUserHolder.getCurrentUser());
            return List.of();
        });

        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/plans")
                        .queryParam("scenario_id", scenarioId).build())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        assertEquals(userId, seenUser.get());
    }

    @Test
    void deleteLesson_ShouldCallService() {
        UUID id = UUID.randomUUID();

        webClient.delete()
                .uri("/api/agent/lessons/{id}", id)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isNoContent();

        verify(memoryService).deleteLesson(id);
    }

    @Test
    void approveLesson_ShouldCallService() {
        UUID id = UUID.randomUUID();
        when(memoryService.approveLesson(id))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons/{id}/approve", id)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).approveLesson(id);
    }

    @Test
    void compressLessons_ShouldCallService() {
        UUID scenarioId = UUID.randomUUID();
        when(memoryService.compressLessons(scenarioId))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.post()
                .uri("/api/agent/lessons/compress")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"" + scenarioId + "\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).compressLessons(scenarioId);
    }

    @Test
    void getPlans_ShouldCallService() {
        UUID scenarioId = UUID.randomUUID();
        AgentPlan plan = new AgentPlan();
        plan.setId(UUID.randomUUID());
        plan.setScenarioId(scenarioId);
        plan.setTaskHash("a".repeat(64));
        plan.setTaskPreview("Найди сумму акта");
        plan.setPlan("[\"пункт 1\",\"пункт 2\"]");
        plan.setUses(2);
        plan.setUpdatedAt(OffsetDateTime.of(2026, 9, 15, 13, 5, 26, 884_512_200, ZoneOffset.ofHours(3)));
        when(memoryService.getPlans(scenarioId)).thenReturn(List.of(AgentPlanResponseDto.from(plan)));

        // ключи в snake_case по схеме AgentPlan (additionalProperties: false)
        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/plans")
                        .queryParam("scenario_id", scenarioId).build())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$[0].scenario_id").isEqualTo(scenarioId.toString())
                .jsonPath("$[0].task_hash").isEqualTo("a".repeat(64))
                .jsonPath("$[0].task_preview").isEqualTo("Найди сумму акта")
                .jsonPath("$[0].uses").isEqualTo(2)
                .jsonPath("$[0].updated_at").isEqualTo("2026-09-15T10:05:26.884512Z")
                .jsonPath("$[0].scenarioId").doesNotExist()
                .jsonPath("$[0].taskHash").doesNotExist()
                .jsonPath("$[0].taskPreview").doesNotExist()
                .jsonPath("$[0].updatedAt").doesNotExist();

        verify(memoryService).getPlans(scenarioId);
    }

    @Test
    void deletePlan_ShouldCallService() {
        UUID id = UUID.randomUUID();

        webClient.delete()
                .uri("/api/agent/plans/{id}", id)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isNoContent();

        verify(memoryService).deletePlan(id);
    }

    @Test
    void extractLessons_ShouldCollectStepOutputs() {
        UUID runId = UUID.randomUUID();
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId("critic");
        step.setNodeType("processing");
        step.setOutputData(Map.of("result", "РАСХОЖДЕНИЕ: сумма акта"));

        when(runRepository.findById(runId)).thenReturn(Optional.of(run));
        when(stepRepository.findViewByRunIdOrderByStartedAtAsc(runId)).thenReturn(List.of(StepOutputViews.of(step)));
        List<AgentMemoryService.StepOutput> expected = List.of(
                new AgentMemoryService.StepOutput("critic (processing)", "РАСХОЖДЕНИЕ: сумма акта", false));
        when(memoryService.extractLessonsFromRun(scenarioId, expected))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.post()
                .uri("/api/agent/lessons/extract")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"run_id\": \"" + runId + "\"}")
                .exchange()
                .expectStatus().isOk();

        verify(scenarioService).checkRunAccess(runId);
        verify(memoryService).extractLessonsFromRun(scenarioId, expected);
    }

    @Test
    void extractLessons_failedStep_passesErrorTextMarkedFailed() {
        // corp17 (M2): у ошибочного шага результата нет — в извлечение идёт текст ошибки с признаком failed
        UUID runId = UUID.randomUUID();
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        when(runRepository.findById(runId)).thenReturn(Optional.of(run));
        when(stepRepository.findViewByRunIdOrderByStartedAtAsc(runId)).thenReturn(List.of(
                StepOutputViews.of("ok", "processing", Map.of("result", "результат"), "completed"),
                StepOutputViews.of("bad", "processing", Map.of("error", "узел упал"), "failed"),
                StepOutputViews.of("empty", "processing", Map.of(), "failed")));
        List<AgentMemoryService.StepOutput> expected = List.of(
                new AgentMemoryService.StepOutput("ok (processing)", "результат", false),
                new AgentMemoryService.StepOutput("bad (processing)", "узел упал", true));
        when(memoryService.extractLessonsFromRun(scenarioId, expected)).thenReturn(List.of());

        webClient.post()
                .uri("/api/agent/lessons/extract")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"run_id\": \"" + runId + "\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).extractLessonsFromRun(scenarioId, expected);
    }

    @Test
    void extractLessons_ShouldSkipBlankStepResults() {
        UUID runId = UUID.randomUUID();
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        ScenarioRunStep blankStep = new ScenarioRunStep();
        blankStep.setNodeId("input");
        blankStep.setNodeType("input");
        blankStep.setOutputData(Map.of("result", " "));
        ScenarioRunStep nullOut = new ScenarioRunStep();
        nullOut.setNodeId("note");
        nullOut.setNodeType("note");

        when(runRepository.findById(runId)).thenReturn(Optional.of(run));
        when(stepRepository.findViewByRunIdOrderByStartedAtAsc(runId))
                .thenReturn(List.of(StepOutputViews.of(blankStep), StepOutputViews.of(nullOut)));
        when(memoryService.extractLessonsFromRun(scenarioId, List.of()))
                .thenReturn(List.of());

        webClient.post()
                .uri("/api/agent/lessons/extract")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"run_id\": \"" + runId + "\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).extractLessonsFromRun(scenarioId, List.of());
    }

    @Test
    void getQuestions_ShouldCallService() {
        UUID runId = UUID.randomUUID();
        AgentQuestion q = question(UUID.randomUUID());
        q.setRunId(runId);
        when(memoryService.getQuestionsByRun(runId)).thenReturn(List.of(AgentQuestionResponseDto.from(q)));

        // ключи в snake_case по схеме AgentQuestion (additionalProperties: false)
        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/questions")
                        .queryParam("run_id", runId).build())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$[0].run_id").isEqualTo(runId.toString())
                .jsonPath("$[0].scenario_id").isEqualTo(q.getScenarioId().toString())
                .jsonPath("$[0].node_label").isEqualTo("Агент")
                .jsonPath("$[0].question").isEqualTo("По пункту «НМЦ» значение не подтверждено")
                .jsonPath("$[0].created_at").isEqualTo("2026-09-15T07:00:00Z")
                .jsonPath("$[0].answer").doesNotExist()
                .jsonPath("$[0].runId").doesNotExist()
                .jsonPath("$[0].scenarioId").doesNotExist()
                .jsonPath("$[0].nodeLabel").doesNotExist();

        // вопросы цитируют документы прогона — доступ проверяется до выдачи
        verify(scenarioService).checkRunAccess(runId);
        verify(memoryService).getQuestionsByRun(runId);
    }

    private static AgentQuestion question(UUID id) {
        AgentQuestion q = new AgentQuestion();
        q.setId(id);
        q.setRunId(UUID.randomUUID());
        q.setScenarioId(UUID.randomUUID());
        q.setNodeLabel("Агент");
        q.setQuestion("По пункту «НМЦ» значение не подтверждено");
        q.setCreatedAt(OffsetDateTime.of(2026, 9, 15, 10, 0, 0, 0, ZoneOffset.ofHours(3)));
        return q;
    }
}
