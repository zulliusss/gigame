package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Hooks;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.ConversationRepository;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.repository.MessageRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Пользователь потоковых методов регенерации и редактирования читается на вызывающем
 * потоке, а не внутри {@code Flux.defer} на boundedElastic: там поток-локальное хранилище
 * вызывающего потока не видно, и проверка владельца диалога сравнивала бы «anonymous»
 * с владельцем. Автоматический проброс ThreadLocal Reactor здесь намеренно выключен —
 * иначе тест не отличал бы исправленный код от прежнего.
 */
@ExtendWith(MockitoExtension.class)
class ChatServiceStreamUserTest {

    @Mock
    private ConversationRepository conversationRepository;
    @Mock
    private MessageRepository messageRepository;
    @Mock
    private GigaChatClient gigaChatClient;
    @Mock
    private EmbeddingService embeddingService;
    @Mock
    private MessageService messageService;
    @Mock
    private DocumentRepository documentRepository;
    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;
    @Mock
    private KbAggregateService kbAggregateService;

    @Mock
    private KBDocumentRepository kbDocumentRepository;

    @InjectMocks
    private ChatService chatService;

    private UUID conversationId;
    private Conversation conversation;
    private Message userMessage;

    @BeforeAll
    static void disableCurrentUserReactorPropagation() {
        Hooks.disableAutomaticContextPropagation();
    }

    @BeforeEach
    void setUp() {
        conversationId = UUID.randomUUID();
        conversation = new Conversation();
        conversation.setId(conversationId);
        conversation.setUserId("OWNER");
        userMessage = new Message();
        userMessage.setId(UUID.randomUUID());
        userMessage.setRole("user");
        userMessage.setContent("Вопрос");
        userMessage.setConversation(conversation);
        ReflectionTestUtils.setField(chatService, "self", new AtomicReference<>(chatService));
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 12000);
        ReflectionTestUtils.setField(chatService, "maxHistoryMessages", 20);
        ReflectionTestUtils.setField(chatService, "maxAutoTitleLength", 100);
        when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        lenient().when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(List.of(userMessage));
        lenient().when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of());
        lenient().when(messageRepository.save(any(Message.class))).thenAnswer(inv -> inv.getArgument(0));
        lenient().when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Ответ", null));
    }

    @Test
    void regenerateStream_ownerFromCallingThread_generatesReply() {
        Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("OWNER",
                () -> chatService.regenerateStream(conversationId, null, null));
        // на вызывающем потоке пользователь уже очищен — внутри defer его читать поздно
        assertNull(CurrentUserHolder.getCurrentUser());

        stream.blockLast();

        verify(gigaChatClient).chatCompletionResult(any(), any(), any());
    }

    @Test
    void regenerateStream_stranger_accessDenied() {
        Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("STRANGER",
                () -> chatService.regenerateStream(conversationId, null, null));

        assertThrows(AccessDeniedException.class, stream::blockLast);
        verify(gigaChatClient, never()).chatCompletionResult(any(), any(), any());
    }

    @Test
    void editMessageStream_ownerFromCallingThread_generatesReply() {
        UUID messageId = userMessage.getId();
        Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("OWNER",
                () -> chatService.editMessageStream(conversationId, messageId, "Новый вопрос", null, null));
        assertNull(CurrentUserHolder.getCurrentUser());

        stream.blockLast();

        verify(gigaChatClient).chatCompletionResult(any(), any(), any());
    }

    @Test
    void editMessageStream_stranger_accessDenied() {
        UUID messageId = userMessage.getId();
        Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("STRANGER",
                () -> chatService.editMessageStream(conversationId, messageId, "Новый вопрос", null, null));

        assertThrows(AccessDeniedException.class, stream::blockLast);
        verify(messageRepository, never()).save(any(Message.class));
        verify(gigaChatClient, never()).chatCompletionResult(any(), any(), any());
    }

    @Test
    void sendMessageStream_ownerFromCallingThread_generatesReply() {
        Flux<ServerSentEvent<Map<String, Object>>> stream = CurrentUserHolder.withUser("OWNER",
                () -> chatService.sendMessageStream(conversationId, "Привет", null, null));
        assertNull(CurrentUserHolder.getCurrentUser());

        stream.blockLast();

        verify(gigaChatClient).chatCompletionResult(any(), any(), any());
    }
}
