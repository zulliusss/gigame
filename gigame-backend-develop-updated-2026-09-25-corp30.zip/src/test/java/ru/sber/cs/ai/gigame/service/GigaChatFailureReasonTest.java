package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.springframework.ai.retry.NonTransientAiException;
import org.springframework.ai.retry.TransientAiException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

/**
 * Тесты краткой причины сбоя вызова GigaChat: по типу сбоя — понятная человеку строка без стека.
 */
class GigaChatFailureReasonTest {

    @Test
    void missingModelIsNamedWhenKnown() {
        RuntimeException error = new NonTransientAiException("HTTP 404 - {\"status\":404,\"message\":\"No such model\"}");

        assertEquals("модель «GigaChat-2-Max» недоступна (HTTP 404)", GigaChatFailureReason.describe(error, "GigaChat-2-Max"));
        assertEquals("модель недоступна (HTTP 404)", GigaChatFailureReason.describe(error, null));
    }

    @Test
    void tokensLimitSuggestsShorterInput() {
        RuntimeException error = new GigaChatException("Сбой LLM-вызова", new NonTransientAiException(
                "HTTP 413 - {\"status\":413,\"message\":\"Tokens limit exceeded for index 0\"}"));

        assertEquals("превышен лимит токенов модели (HTTP 413) — сократите документы или промпт",
                GigaChatFailureReason.describe(error, "GigaChat"));
    }

    @Test
    void otherHttpErrorShowsCodeAndMessageFromBody() {
        RuntimeException badRequest = new NonTransientAiException("HTTP 400 - {\"status\":400,\"message\":\"Invalid params: temperature\"}");
        RuntimeException notFoundPath = new NonTransientAiException("HTTP 404 - {\"status\":404,\"message\":\"Not found\"}");
        RuntimeException defaultHandler = new NonTransientAiException("401 - {\"status\":401,\"message\":\"Unauthorized\"}");
        RuntimeException htmlBody = new TransientAiException("HTTP 502 - <html><body><h1>502 Bad Gateway</h1>\n</body></html>");

        assertEquals("HTTP 400: Invalid params: temperature", GigaChatFailureReason.describe(badRequest, "GigaChat"));
        assertEquals("HTTP 404: Not found", GigaChatFailureReason.describe(notFoundPath, "GigaChat"));
        assertEquals("HTTP 401: Unauthorized", GigaChatFailureReason.describe(defaultHandler, null));
        assertEquals("HTTP 502: 502 Bad Gateway", GigaChatFailureReason.describe(htmlBody, null));
    }

    @Test
    void longBodyIsCutToLimit() {
        String longMessage = "x".repeat(GigaChatFailureReason.DETAIL_LIMIT + 100);
        RuntimeException error = new NonTransientAiException("HTTP 400 - {\"status\":400,\"message\":\"" + longMessage + "\"}");

        String reason = GigaChatFailureReason.describe(error, null);

        assertEquals("HTTP 400: " + "x".repeat(GigaChatFailureReason.DETAIL_LIMIT) + "…", reason);
    }

    @Test
    void clientResponseExceptionsAreReadFromCauseChain() {
        byte[] body = "{\"status\":400,\"message\":\"Invalid params: \\\"model\\\"\"}".getBytes(StandardCharsets.UTF_8);
        RuntimeException rest = new RestClientResponseException("400 Bad Request", HttpStatusCode.valueOf(400), "Bad Request",
                HttpHeaders.EMPTY, body, StandardCharsets.UTF_8);
        RuntimeException web = new RuntimeException("обёртка", WebClientResponseException.create(HttpStatusCode.valueOf(413),
                "Payload Too Large", HttpHeaders.EMPTY, "Tokens limit exceeded".getBytes(StandardCharsets.UTF_8),
                StandardCharsets.UTF_8, null));

        assertEquals("HTTP 400: Invalid params: \"model\"", GigaChatFailureReason.describe(rest, null));
        assertEquals(GigaChatFailureReason.TOKENS_LIMIT, GigaChatFailureReason.describe(web, null));
    }

    @Test
    void interruptedCallIsReportedAsInterruption() {
        RuntimeException error = new GigaChatException("LLM-вызов прерван", new InterruptedException());

        assertEquals("запрос прерван: поток выполнения узла остановлен", GigaChatFailureReason.describe(error, "GigaChat"));
    }

    @Test
    void plainErrorShowsMessageAndRootCauseWithoutStack() {
        RuntimeException withRoot = new RuntimeException("I/O error on POST request",
                new IllegalStateException("обёртка", new UnknownHostException("gigachat.devices.sberbank.ru")));
        RuntimeException sameText = new RuntimeException("Connection reset", new IllegalStateException("Connection reset"));
        RuntimeException multiline = new IllegalArgumentException("строка 1\n\tстрока 2   ");

        assertEquals("I/O error on POST request (gigachat.devices.sberbank.ru)", GigaChatFailureReason.describe(withRoot, null));
        assertEquals("Connection reset", GigaChatFailureReason.describe(sameText, null));
        assertEquals("строка 1 строка 2", GigaChatFailureReason.describe(multiline, null));
        assertEquals("IllegalStateException", GigaChatFailureReason.describe(new IllegalStateException(), null));
        assertEquals("неизвестная ошибка", GigaChatFailureReason.describe(null, null));
    }

    @Test
    void reasonNeverContainsStackTrace() {
        RuntimeException error = new RuntimeException("Сбой", new RuntimeException("корень"));

        String reason = GigaChatFailureReason.describe(error, null);

        assertEquals("Сбой (корень)", reason);
        assertFalse(reason.contains("\tat ") || reason.contains("Exception:"), reason);
    }
}
