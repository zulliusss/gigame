package ru.sber.cs.ai.gigame.service;

import org.apache.poi.ss.usermodel.FormulaError;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Потоковый разбор XLSX даёт тот же текст, что DOM-парсер: листы с заголовками,
 * ячейки через " | ", пропуски как пустые ячейки, формулы — значением.
 */
class XlsxStreamingParserTest {

    private static byte[] workbook(boolean twoSheets) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            var sheet = wb.createSheet("1300");
            var row = sheet.createRow(0);
            row.createCell(0).setCellValue("ПАО Сбербанк_10000203");
            row.createCell(2).setCellValue("ВСП_10039053");
            row.createCell(3).setCellValue(10039053);
            row.createCell(4).setCellValue("ВСП\nотделения");
            var formula = sheet.createRow(2);
            formula.createCell(0).setCellValue(5);
            formula.createCell(1).setCellValue(7);
            formula.createCell(2).setCellFormula("A3+B3");
            var dateCell = formula.createCell(3);
            dateCell.setCellValue(java.time.LocalDate.of(2020, 7, 1));
            var dateStyle = wb.createCellStyle();
            dateStyle.setDataFormat(wb.getCreationHelper().createDataFormat().getFormat("m/d/yy"));
            dateCell.setCellStyle(dateStyle);
            wb.getCreationHelper().createFormulaEvaluator().evaluateAll();
            if (twoSheets) {
                wb.createSheet("1600").createRow(0).createCell(0).setCellValue("ВИП ВСП_10312080");
            }
            wb.write(out);
        }
        return out.toByteArray();
    }

    @Test
    void singleSheetRowsKeepEmptyCellsFormulasAndFlattenedText() throws Exception {
        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(workbook(false)), 100, 100_000);

        assertEquals("ПАО Сбербанк_10000203 |  | ВСП_10039053 | 10039053 | ВСП отделения\n5 | 7 | 12 | 01.07.2020\n", text);
    }

    @Test
    void severalSheetsGetHeadersAndBlankLineBetween() throws Exception {
        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(workbook(true)), 100, 100_000);

        assertTrue(text.startsWith("=== Лист: 1300 ===\nПАО Сбербанк_10000203 |  | ВСП_10039053"));
        assertTrue(text.contains("5 | 7 | 12 | 01.07.2020\n\n=== Лист: 1600 ===\nВИП ВСП_10312080\n"));
    }

    @Test
    void rowsBeyondLimitAreDroppedWithMarker() throws Exception {
        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(workbook(true)), 100, 1);

        // маркер обрезки — на каждом затронутом листе, а не только на первом
        assertEquals("=== Лист: 1300 ===\nПАО Сбербанк_10000203 |  | ВСП_10039053 | 10039053 | ВСП отделения\n"
                + "[...обрезано: больше 1 строк]\n\n=== Лист: 1600 ===\n[...обрезано: больше 1 строк]\n", text);
    }

    @Test
    void formulaWithoutCachedValueIsShownAsFormula() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            var row = wb.createSheet("Расчёт").createRow(0);
            row.createCell(0).setCellValue(2);
            // формула без пересчёта (книга из библиотеки без вычисления): сохранённого значения нет
            row.createCell(1).setCellFormula("A1*21");
            wb.write(out);
        }

        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(out.toByteArray()), 100, 100_000);

        assertEquals("2 | =A1*21\n", text);
    }

    @Test
    void formulaErrorIsShownLikeExcelWithoutPoiPrefix() throws Exception {
        // обработчик POI отдаёт ошибку ячейки как «ERROR:#DIV/0!» — в тексте документа она даётся как в Excel и в .xls
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            var row = wb.createSheet("Расчёт").createRow(0);
            row.createCell(0).setCellValue(2);
            var formula = row.createCell(1);
            formula.setCellFormula("A1/0");
            formula.setCellErrorValue(FormulaError.DIV0.getCode());
            wb.write(out);
        }

        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(out.toByteArray()), 100, 100_000);

        assertEquals("2 | #DIV/0!\n", text);
    }

    @Test
    void sheetsBeyondLimitAreListedInMarker() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            wb.createSheet("Первый").createRow(0).createCell(0).setCellValue("a");
            wb.createSheet("Второй").createRow(0).createCell(0).setCellValue("b");
            wb.createSheet("Третий").createRow(0).createCell(0).setCellValue("c");
            wb.write(out);
        }

        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(out.toByteArray()), 1, 100_000);

        assertEquals("=== Лист: Первый ===\na\n\n[... листы сверх лимита 1 не разобраны (2): Второй, Третий ...]\n", text);
    }

    /**
     * Числа рендерятся одинаково при любой локали JVM (кейс Хинт 23.09.2026: на проме с локалью en
     * «1,338,698.00 ₽», на стенде ru-RU — «1 338 698,00 ₽»): локаль форматтера зафиксирована русской,
     * как на стенде, где отлажены сценарии; разряды — неразрывный пробел (U+00A0).
     */
    @Test
    void numbersAreFormattedIndependentlyOfJvmLocale() throws Exception {
        byte[] xlsx = workbookWithMoneyCells();
        Locale previous = Locale.getDefault();
        Locale.setDefault(Locale.US);
        try {
            String text = XlsxStreamingParser.parse(new ByteArrayInputStream(xlsx), 100, 100_000);

            assertEquals("1 338 698,00 ₽ | 1 338 698,00\n", text);
        } finally {
            Locale.setDefault(previous);
        }
    }

    /** Книга с числом 1338698 в форматах «#,##0.00 "₽"» и «#,##0.00». */
    private static byte[] workbookWithMoneyCells() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            var row = wb.createSheet("Рейтинг").createRow(0);
            var formats = wb.getCreationHelper().createDataFormat();
            var rubles = wb.createCellStyle();
            rubles.setDataFormat(formats.getFormat("#,##0.00 \"₽\""));
            var plain = wb.createCellStyle();
            plain.setDataFormat(formats.getFormat("#,##0.00"));
            var rublesCell = row.createCell(0);
            rublesCell.setCellValue(1338698.0);
            rublesCell.setCellStyle(rubles);
            var plainCell = row.createCell(1);
            plainCell.setCellValue(1338698.0);
            plainCell.setCellStyle(plain);
            wb.write(out);
        }
        return out.toByteArray();
    }

    /**
     * XML листа с <!DOCTYPE> и внешней сущностью должен разбираться без раскрытия
     * этой сущности: либо документ отвергается (disallow-doctype-decl), либо
     * содержимое внешнего файла не попадает в результат.
     */
    @Test
    void externalEntityInSheetXmlIsNotResolved() throws Exception {
        Path secretFile = Files.createTempFile("gigame-xxe-secret", ".txt");
        String secret = "XXE_SECRET_" + System.nanoTime();
        try {
            Files.writeString(secretFile, secret);
            byte[] malicious = maliciousWorkbookWithExternalEntity(secretFile.toUri().toASCIIString());
                // убеждаемся, что зловредный DOCTYPE действительно внедрён в лист
            // (проверяем распакованный XML — в сжатых байтах архива строка не встречается)
            assertTrue(sheet1Xml(malicious).contains("<!DOCTYPE"));
            assertTrue(sheet1Xml(malicious).contains("&xxe;"));

            // disallow-doctype-decl заставляет парсер отвергнуть документ с DOCTYPE
            assertThrows(IOException.class,
                    () -> XlsxStreamingParser.parse(new ByteArrayInputStream(malicious), 100, 100_000),
                    "документ с DOCTYPE/внешней сущностью не должен быть разобран");
        } finally {
            Files.deleteIfExists(secretFile);
        }
    }

    /** Книга с числовой ячейкой, у которой в XML листа внедрены DOCTYPE и ссылка на внешнюю сущность. */
    private static byte[] maliciousWorkbookWithExternalEntity(String entityUrl) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            wb.createSheet("Лист").createRow(0).createCell(0).setCellValue(424242);
            wb.write(out);
        }
        return injectDoctype(out.toByteArray(), entityUrl);
    }

    /** Пересобирает XLSX-архив, добавляя в лист DOCTYPE и заменяя значение ячейки на ссылку на сущность. */
    private static byte[] injectDoctype(byte[] xlsx, String entityUrl) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(xlsx));
             ZipOutputStream zos = new ZipOutputStream(out)) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                zos.putNextEntry(new ZipEntry(entry.getName()));
                if ("xl/worksheets/sheet1.xml".equals(entry.getName())) {
                    String xml = new String(zin.readAllBytes(), StandardCharsets.UTF_8);
                    String doctype = "<!DOCTYPE worksheet [<!ENTITY xxe SYSTEM \"" + entityUrl + "\">]>";
                    int tag = xml.indexOf("<worksheet");
                    String body = xml.substring(tag).replace("424242", "&xxe;");
                    zos.write((xml.substring(0, tag) + doctype + body).getBytes(StandardCharsets.UTF_8));
                } else {
                    transfer(zin, zos);
                }
                zos.closeEntry();
            }
        }
        return out.toByteArray();
    }

    private static void transfer(InputStream in, ZipOutputStream out) throws IOException {
        in.transferTo(out);
    }

    /** Содержимое xl/worksheets/sheet1.xml внутри архива (внедрённый DOCTYPE проверяется на распакованном XML). */
    private static String sheet1Xml(byte[] xlsx) throws IOException {
        try (ZipInputStream zin = new ZipInputStream(new ByteArrayInputStream(xlsx))) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                if ("xl/worksheets/sheet1.xml".equals(entry.getName())) {
                    return new String(zin.readAllBytes(), StandardCharsets.UTF_8);
                }
            }
        }
        return "";
    }
}
