package ru.sber.cs.ai.gigame.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.controller.AgentMemoryController;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Фильтр X-UserId с выключенным флагом (умолчание): запрос без заголовка доходит
 * до контроллера как прежде — «anonymous».
 */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {AgentMemoryController.class, UserIdRequiredWebFilter.class, TestConfiguration.class})
@WebFluxTest(controllers = AgentMemoryController.class)
@AutoConfigureWebTestClient(timeout = "30000")
class UserIdRequiredWebFilterDisabledWebTest {

    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private AgentMemoryService memoryService;
    @MockitoBean
    private ScenarioRunRepository runRepository;
    @MockitoBean
    private ScenarioRunStepRepository stepRepository;
    @MockitoBean
    private ScenarioService scenarioService;

    @Test
    void apiWithoutHeader_passesToController() {
        when(memoryService.getLessons(any())).thenReturn(List.of());

        webClient.get()
                .uri("/api/agent/lessons")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getLessons(any());
    }
}
