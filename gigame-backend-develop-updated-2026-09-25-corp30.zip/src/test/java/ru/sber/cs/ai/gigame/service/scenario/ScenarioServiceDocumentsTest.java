package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.apache.commons.compress.utils.SeekableInMemoryByteChannel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.FileTooLargeException;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.ScanOcrService;
import ru.sber.cs.ai.gigame.service.TestPdf;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты getDocuments: распаковка ZIP, маркер скана, лимит документов.
 */
@ExtendWith(MockitoExtension.class)
@SuppressWarnings("unused")
class ScenarioServiceDocumentsTest {

    @Mock
    private ScenarioRepository scenarioRepository;
    @Mock
    private ScenarioRunRepository scenarioRunRepository;
    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;
    @Mock
    private ScenarioVersionRepository scenarioVersionRepository;
    @Mock
    private ScenarioEngine scenarioEngine;
    @Mock
    private DocumentService documentService;
    @Mock
    private ScanOcrService scanOcrService;

    @InjectMocks
    private ScenarioService scenarioService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(scenarioService, "minParsedChars", 40);
    }

    private FilePart mockFilePart(String filename, byte[] content) {
        FilePart mockFile = mock(FilePart.class);
        when(mockFile.filename()).thenReturn(filename);
        lenient().when(mockFile.headers()).thenReturn(null);
        when(mockFile.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap(content)));
        return mockFile;
    }

    private static byte[] zipOf(Map<String, byte[]> entries) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            for (var e : entries.entrySet()) {
                zos.putNextEntry(new ZipEntry(e.getKey()));
                zos.write(e.getValue());
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    private static byte[] sevenZOf(Map<String, byte[]> entries) throws IOException {
        SeekableInMemoryByteChannel channel = new SeekableInMemoryByteChannel();
        try (SevenZOutputFile szf = new SevenZOutputFile(channel)) {
            for (var e : entries.entrySet()) {
                SevenZArchiveEntry entry = new SevenZArchiveEntry();
                entry.setName(e.getKey());
                entry.setDirectory(false);
                szf.putArchiveEntry(entry);
                szf.write(e.getValue());
                szf.closeArchiveEntry();
            }
        }
        return Arrays.copyOf(channel.array(), (int) channel.size());
    }

    @Test
    void getDocuments_zipIsUnpackedIntoSeveralDocuments() throws IOException {
        byte[] zip = zipOf(Map.of(
                "Договор 123/договор.pdf", "pdf".getBytes(),
                "Договор 123/Signature.sig", "junk".getBytes(),
                "Договор 123/акт.docx", "docx".getBytes()));
        FilePart file = mockFilePart("документы.zip", zip);
        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("Текст договора достаточной длины для порога скан-детекции");
        when(documentService.parseText(any(InputStream.class), eq("docx")))
                .thenReturn("Текст акта достаточной длины для порога скан-детекции!");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals(2, docs.size());
        assertTrue(docs.stream().anyMatch(d -> d.filename().equals("документы.zip/Договор 123/договор.pdf")));
        assertTrue(docs.stream().anyMatch(d -> d.filename().equals("документы.zip/Договор 123/акт.docx")));
    }

    @Test
    void getDocuments_zipWithoutSupportedDocuments_givesMarkerDocumentAndWarning() throws IOException {
        // проблемный архив больше не роняет партию: документ-маркер + предупреждение, остальные файлы разбираются
        byte[] zip = zipOf(Map.of("Signature.sig", "junk".getBytes()));
        FilePart file = mockFilePart("пустой.zip", zip);
        FilePart good = mockFilePart("хороший.txt", "текст".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("нормальный текст документа");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file, good), events);

        assertEquals(2, docs.size());
        assertEquals("пустой.zip", docs.get(0).filename());
        assertTrue(docs.get(0).text().startsWith("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Архив «пустой.zip» не распакован: архив не содержит"));
        assertEquals("нормальный текст документа", docs.get(1).text());
        assertTrue(events.stream().anyMatch(e -> e.data() != null && "upload_warning".equals(e.data().get("type"))
                && String.valueOf(e.data().get("message")).startsWith("архив не распакован: архив не содержит")));
    }

    @Test
    void getDocuments_corruptedArchive_givesMarkerDocumentAndBatchContinues() throws IOException {
        FilePart broken = mockFilePart("битый.zip", "это не архив".getBytes());
        FilePart good = mockFilePart("хороший.txt", "текст".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("нормальный текст документа");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(broken, good), events);

        assertEquals(2, docs.size());
        assertTrue(docs.get(0).text().contains("Архив «битый.zip» не распакован: Архив пуст или повреждён"));
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).startsWith("архив не распакован: Архив пуст или повреждён")));
    }

    @Test
    void getDocuments_zipWithUnsupportedFiles_warnsAboutSkippedNames() throws IOException {
        byte[] zip = zipOf(Map.of("договор.pdf", "pdf".getBytes(), "смета.exe", "x".getBytes(), "Signature.sig", "s".getBytes()));
        FilePart file = mockFilePart("документы.zip", zip);
        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("Текст договора достаточной длины для порога скан-детекции");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(1, docs.size());
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && "архив документы.zip: пропущено 1 файлов (смета.exe)".equals(e.data().get("message"))));
    }

    @Test
    void getDocuments_mixedPdfWithoutOcr_marksTextlessPagesAndWarns() throws IOException {
        String text = "Текст первой страницы достаточной длины для порога скан-детекции";
        FilePart file = mockFilePart("смешанный.pdf", "байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn(text);
        when(documentService.isScanPdf(any(), eq(text))).thenReturn(false);
        when(documentService.textlessPages(any())).thenReturn(List.of(2, 4));
        when(scanOcrService.isEnabled()).thenReturn(false);

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(text + "\n\n[страница 2 без текстового слоя — не распознана]\n\n[страница 4 без текстового слоя — не распознана]",
                docs.get(0).text());
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && "страницы 2, 4 без текстового слоя — не распознаны".equals(e.data().get("message"))));
    }

    @Test
    void getDocuments_mixedPdfWithOcr_recognizedPageByPage() throws IOException {
        String text = "Текст первой страницы достаточной длины для порога скан-детекции";
        FilePart file = mockFilePart("смешанный.pdf", "байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn(text);
        when(documentService.isScanPdf(any(), eq(text))).thenReturn(false);
        when(documentService.textlessPages(any())).thenReturn(List.of(2));
        when(scanOcrService.isEnabled()).thenReturn(true);
        String recognized = "[РАСПОЗНАНО] --- страница 1 (текстовый слой) ---\n" + text + "\n\n--- страница 2 ---\nстр2";
        when(scanOcrService.recognize(eq("смешанный.pdf"), any(), any())).thenReturn(recognized);

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(recognized, docs.get(0).text());
        // смешанный PDF: перечисляются распознанные страницы, а не «PDF-скан распознан»
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && "распознаны через GigaChat страницы 2 — проверьте суммы".equals(e.data().get("message"))));
    }

    @Test
    void getDocuments_scanRecognizedPageByPage_keepsScanWarning() throws IOException {
        FilePart file = mockFilePart("скан.pdf", "байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn(" ");
        when(scanOcrService.isEnabled()).thenReturn(true);
        when(scanOcrService.recognize(eq("скан.pdf"), any(), any())).thenReturn("[РАСПОЗНАНО] --- страница 1 ---\nАкт\n\n--- страница 2 ---\nСчёт");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        scenarioService.getDocuments(List.of(file), events);

        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && "PDF-скан распознан через GigaChat — проверьте суммы".equals(e.data().get("message"))));
    }

    @Test
    void parseFiles_textPdfWithBlankPage_notSentToOcrAndTextKept() throws IOException {
        // договор p8 (16.09.2026): пустая страница машиночитаемого договора запускала OCR и теряла текст за лимитом
        String page = "Contract text of the page long enough for the scan detection threshold";
        ScenarioService service = new ScenarioService(scenarioRepository, scenarioRunRepository, scenarioRunStepRepository,
                scenarioVersionRepository, scenarioEngine, new DocumentService(null, null, null), scanOcrService, null, null);
        ReflectionTestUtils.setField(service, "minParsedChars", 40);
        lenient().when(scanOcrService.isEnabled()).thenReturn(true);
        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();

        List<DocumentText> docs = service.parseFiles(
                List.of(new ScenarioService.RawFile("договор.pdf", TestPdf.of(page, page, TestPdf.BLANK, page))), events);

        verify(scanOcrService, never()).recognize(any(), any(), any());
        assertEquals(3, docs.get(0).text().split(page, -1).length - 1, docs.get(0).text());
        assertTrue(events.stream().noneMatch(e -> "upload_warning".equals(e.data().get("type"))));
    }

    @Test
    void getDocuments_ocrRefusal_givesManualCheckMarkerAndSeparateWarning() throws IOException {
        FilePart file = mockFilePart("скан.pdf", "байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn("  ");
        when(scanOcrService.isEnabled()).thenReturn(true);
        when(scanOcrService.recognize(eq("скан.pdf"), any(), any())).thenReturn(
                "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «скан.pdf» не распознан: модель отказалась распознавать скан.");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertTrue(docs.get(0).text().startsWith("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).contains("модель отказалась распознавать документ")));
    }

    @Test
    void getDocuments_unrecognizedEncoding_warns() throws IOException {
        FilePart file = mockFilePart("мусор.txt", "x".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenReturn(DocumentService.ENCODING_MARKER + "\n▒▓░▒▓");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        scenarioService.getDocuments(List.of(file), events);

        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && "кодировка текстового файла не распознана — текст может быть искажён".equals(e.data().get("message"))));
    }

    @Test
    void getDocuments_scannedPdf_replacedWithManualReviewMarker() throws IOException {
        FilePart file = mockFilePart("скан.pdf", "оригинальные байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn("  \n ");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(1, docs.size());
        assertTrue(docs.get(0).text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(docs.get(0).text().contains("скан.pdf"));
        assertTrue(events.stream().anyMatch(e ->
                "upload_warning".equals(e.data() != null ? e.data().get("type") : null)));
    }

    @Test
    void getDocuments_scanWithEdoStampPage_recognizedAndStampKept() throws IOException {
        // текстовый слой штампа ЭДО длиннее порога, но постраничный детектор видит скан — идёт OCR, штамп сохраняется
        String stamp = "Документ подписан и передан через оператора ЭДО АО «ПФ «СКБ Контур»";
        FilePart file = mockFilePart("скан.pdf", "байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn(stamp);
        when(documentService.isScanPdf(any(), eq(stamp))).thenReturn(true);
        when(scanOcrService.isEnabled()).thenReturn(true);
        when(scanOcrService.recognize(eq("скан.pdf"), any(), any())).thenReturn("[РАСПОЗНАНО] Акт №1");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals("[РАСПОЗНАНО] Акт №1\n\n" + stamp, docs.get(0).text());
    }

    @Test
    void getDocuments_brokenFile_getsManualReviewMarkerInsteadOfFailingWholeBatch() throws IOException {
        // битый файл (XML-бомба в docx, повреждение) не должен ронять загрузку комплекта
        FilePart good = mockFilePart("хороший.txt", "нормальный текст документа".getBytes());
        FilePart broken = mockFilePart("битый.docx", "мусор".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenReturn("нормальный текст документа");
        when(documentService.parseText(any(InputStream.class), eq("docx")))
                .thenThrow(new IOException("Zip bomb detected"));

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(good, broken), events);

        assertEquals(2, docs.size());
        var brokenDoc = docs.stream().filter(d -> d.filename().equals("битый.docx")).findFirst().orElseThrow();
        assertTrue(brokenDoc.text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(brokenDoc.text().contains("не удалось обработать"));
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).contains("не обработан")));
    }

    @Test
    void getDocuments_ooxmlBomb_rejectedFastWithMarker_withoutReachingPoi() throws IOException {
        // docx с document.xml, раздувающимся сверх лимита, отсекается общей проверкой DocumentService.rejectOoxmlBomb
        // ДО передачи в POI: parseText для docx не должен вызываться вовсе, партия не падает
        byte[] bomb = zipOf(Map.of("word/document.xml", new byte[2 * 1024 * 1024]));
        FilePart file = mockFilePart("бомба.docx", bomb);
        doThrow(new FileException("Внутренняя часть «word/document.xml» файла «бомба.docx» распаковывается более чем в 1 МБ"))
                .when(documentService).rejectOoxmlBomb(eq("бомба.docx"), eq("docx"), any());

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(1, docs.size());
        assertTrue(docs.get(0).text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        verify(documentService, never()).parseText(any(InputStream.class), eq("docx"));
    }

    @Test
    void getDocuments_sevenZipArchive_unpackedLikeZip() throws IOException {
        // .7z маршрутизируется в экстрактор так же, как .zip (архив собран в ZipExtractorTest-стиле)
        byte[] sevenZ = sevenZOf(Map.of(
                "Договор 123/договор.pdf", "pdf-bytes".getBytes(),
                "Договор 123/Signature(01).sig", "junk".getBytes()));
        FilePart file = mockFilePart("документы.7z", sevenZ);
        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("Текст договора достаточной длины для порога скан-детекции");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals(1, docs.size());
        assertEquals("документы.7z/Договор 123/договор.pdf", docs.get(0).filename());
    }

    @Test
    void getDocuments_shortButNonEmptyTxt_isNotMarked() throws IOException {
        // маркер применяется только к PDF: короткий txt остаётся как есть
        FilePart file = mockFilePart("короткий.txt", "ok".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("ok");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals("ok", docs.get(0).text());
    }

    @Test
    void getDocumentsText_returnsTextsInOrder() throws IOException {
        FilePart file1 = mockFilePart("a.txt", "1".getBytes());
        FilePart file2 = mockFilePart("b.txt", "2".getBytes());
        // парсинг параллельный — стаб привязан к содержимому, а не к порядку вызовов
        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenAnswer(inv -> "1".equals(new String(((InputStream) inv.getArgument(0)).readAllBytes()))
                        ? "первый текст" : "второй текст");

        List<String> texts = scenarioService.getDocumentsText(List.of(file1, file2), null);

        assertEquals(List.of("первый текст", "второй текст"), texts);
    }

    @Test
    void getDocuments_fileAboveSizeLimit_rejectedBeforeParsing() throws IOException {
        // WebFlux не применяет spring.servlet.multipart.*: размер файла проверяется кодом ещё при чтении
        // запроса (быстрая фаза) — 413 с именем файла, как у лимита части multipart
        ReflectionTestUtils.setField(scenarioService, "maxFileSizeBytes", 1024L * 1024);
        FilePart big = mockFilePart("большой.txt", new byte[1024 * 1024 + 1]);
        var files = List.of(big);

        FileTooLargeException e = assertThrows(FileTooLargeException.class, () -> scenarioService.getDocuments(files, null));

        assertEquals(413, e.getStatusCode());
        assertEquals("Файл «большой.txt» больше допустимого размера 1 МБ — разделите архив на части или загрузите "
                + "документы по отдельности", e.getMessage());
        verify(documentService, never()).parseText(any(InputStream.class), any());
    }

    @Test
    void readFiles_archiveAboveFileSizeLimit_isAccepted() {
        // архив комплекта 55,5 МБ при пределе документа 50 МБ (DOCUMENT_MAX_FILE_SIZE на поде) принимается:
        // предел документа к архиву не применяется, архив держат сумма запроса и пределы распакованных документов
        ReflectionTestUtils.setField(scenarioService, "maxFileSizeBytes", 10L);
        FilePart zip = mockFilePart("1.2 Опыт ЭЦС.ZIP", "12345678901".getBytes());
        FilePart sevenZ = mockFilePart("акты.7z", "123456789012".getBytes());

        List<ScenarioService.RawFile> raw = scenarioService.readFiles(List.of(zip, sevenZ));

        assertEquals(List.of("1.2 Опыт ЭЦС.ZIP", "акты.7z"), raw.stream().map(ScenarioService.RawFile::name).toList());
    }

    @Test
    void readFiles_documentAboveFileSizeLimit_rejectedWith413_evenIfTotalFits() {
        ReflectionTestUtils.setField(scenarioService, "maxFileSizeBytes", 10L);
        FilePart archive = mockFilePart("акты.zip", "12345678901".getBytes());
        FilePart document = mockFilePart("акт.zip.pdf", "12345678901".getBytes());
        var files = List.of(archive, document);

        FileTooLargeException e = assertThrows(FileTooLargeException.class, () -> scenarioService.readFiles(files));

        assertEquals(413, e.getStatusCode());
        assertTrue(e.getMessage().startsWith("Файл «акт.zip.pdf» больше допустимого размера"), e.getMessage());
    }

    @Test
    void readFiles_archiveAboveUploadLimit_rejectedWith422() {
        // архив ограничен суммой запроса, как и раньше
        ReflectionTestUtils.setField(scenarioService, "maxFileSizeBytes", 10L);
        ReflectionTestUtils.setField(scenarioService, "maxUploadBytes", 20L);
        FilePart archive = mockFilePart("акты.zip", new byte[21]);
        var files = List.of(archive);

        FileException e = assertThrows(FileException.class, () -> scenarioService.readFiles(files));

        assertEquals(422, e.getStatusCode());
        assertTrue(e.getMessage().contains("Суммарный размер"), e.getMessage());
    }

    @Test
    void getDocuments_archiveAboveFileSizeLimit_withEntriesWithinLimit_isParsed() throws IOException {
        ReflectionTestUtils.setField(scenarioService, "maxFileSizeBytes", 150L);
        byte[] zip = zipOf(Map.of(
                "акты/акт1.txt", "1".repeat(100).getBytes(),
                "акты/акт2.txt", "2".repeat(100).getBytes(),
                "акты/акт3.txt", "3".repeat(100).getBytes()));
        assertTrue(zip.length > 150, "архив должен быть больше предела документа: " + zip.length);
        FilePart file = mockFilePart("акты.zip", zip);
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("текст акта");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals(3, docs.size());
        assertTrue(docs.stream().allMatch(d -> "текст акта".equals(d.text())));
    }

    @Test
    void getDocuments_archiveEntryAboveSizeLimit_becomesMarkerAndBatchContinues() throws IOException {
        // распакованный документ больше предела: раньше 422 на всю партию уже после разбора (и OCR) остальных документов
        ReflectionTestUtils.setField(scenarioService, "maxFileSizeBytes", 1024L * 1024);
        byte[] zip = zipOf(Map.of("акты/том.txt", new byte[1024 * 1024 + 1], "акты/акт.txt", "текст".getBytes()));
        FilePart file = mockFilePart("акты.zip", zip);
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("текст акта");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(2, docs.size());
        var big = docs.stream().filter(d -> d.filename().endsWith("том.txt")).findFirst().orElseThrow();
        assertTrue(big.text().startsWith("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «акты.zip/акты/том.txt» не удалось обработать: "
                + "файл больше предела 1 МБ (1 МБ) и не разобран"), big.text());
        assertTrue(docs.stream().anyMatch(d -> "текст акта".equals(d.text())));
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && "файл больше 1 МБ — не разобран, требуется ручная проверка".equals(e.data().get("message"))));
        verify(documentService, times(1)).parseText(any(InputStream.class), any());
    }

    @Test
    void getDocuments_unsupportedFormatInArchive_getsHonestMarkerInsteadOfSilentSkip() throws IOException {
        // .doc в архиве раньше выбрасывался из прогона молча (только имя в предупреждении), напрямую — маркер «повреждён»
        byte[] ole2 = {(byte) 0xD0, (byte) 0xCF, 0x11, (byte) 0xE0, (byte) 0xA1, (byte) 0xB1, 0x1A, (byte) 0xE1};
        byte[] zip = zipOf(Map.of("договор.pdf", "pdf".getBytes(), "старый.doc", ole2));
        FilePart archive = mockFilePart("документы.zip", zip);
        FilePart direct = mockFilePart("письмо.rtf", "{\\rtf1}".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("Текст договора достаточной длины для порога скан-детекции");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(archive, direct), events);

        assertEquals(3, docs.size());
        var doc = docs.stream().filter(d -> d.filename().endsWith("старый.doc")).findFirst().orElseThrow();
        assertTrue(doc.text().startsWith("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «документы.zip/старый.doc» не удалось обработать: "
                + "формат .doc не поддерживается (Word 97-2003 — сохраните документ как DOCX или PDF)"), doc.text());
        var rtf = docs.stream().filter(d -> d.filename().equals("письмо.rtf")).findFirst().orElseThrow();
        assertTrue(rtf.text().contains("формат .rtf не поддерживается"), rtf.text());
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).startsWith("формат .doc не поддерживается")));
    }

    @Test
    void getDocuments_imageIsRecognizedAsSinglePageScan() throws IOException {
        // фото акта телефоном: изображение оборачивается в PDF и распознаётся как скан; при выключенном OCR — маркер
        byte[] pdf = "%PDF-wrapped".getBytes();
        FilePart photo = mockFilePart("IMG_0001.jpg", new byte[]{(byte) 0xFF, (byte) 0xD8, (byte) 0xFF});
        when(documentService.parseText(any(InputStream.class), eq("image"))).thenReturn("");
        when(documentService.imageToPdf(any(), eq("IMG_0001.jpg"))).thenReturn(pdf);
        when(scanOcrService.isEnabled()).thenReturn(true);
        when(scanOcrService.recognize(eq("IMG_0001.jpg"), eq(pdf), any())).thenReturn("[РАСПОЗНАНО] Документ «IMG_0001.jpg»:\nАкт №7");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(photo), events);

        assertEquals("[РАСПОЗНАНО] Документ «IMG_0001.jpg»:\nАкт №7", docs.get(0).text());
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && "PDF-скан распознан через GigaChat — проверьте суммы".equals(e.data().get("message"))));

        when(scanOcrService.isEnabled()).thenReturn(false);
        List<DocumentText> withoutOcr = scenarioService.getDocuments(List.of(mockFilePart("IMG_0002.png", new byte[]{1})), null);
        assertTrue(withoutOcr.get(0).text().startsWith("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «IMG_0002.png» не распознан: изображение"),
                withoutOcr.get(0).text());
    }

    @Test
    void getDocuments_scanRecognizedPageByPage_keepsStampOnce() throws IOException {
        // постраничный OCR уже включил страницу-штамп как текстовый слой — штамп не дописывается второй раз
        String stamp = "Документ подписан и передан через оператора ЭДО АО «ПФ «СКБ Контур»";
        String recognized = "[РАСПОЗНАНО] Документ «скан.pdf»:\n--- страница 1 ---\nАкт №1\n\n--- страница 2 (текстовый слой) ---\n" + stamp;
        FilePart file = mockFilePart("скан.pdf", "байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn(stamp);
        when(documentService.isScanPdf(any(), eq(stamp))).thenReturn(true);
        when(scanOcrService.isEnabled()).thenReturn(true);
        when(scanOcrService.recognize(eq("скан.pdf"), any(), any())).thenReturn(recognized);

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals(recognized, docs.get(0).text());
        assertEquals(1, docs.get(0).text().split(stamp, -1).length - 1);
    }

    @Test
    void readFiles_sizeLimitIsCheckedWhileReadingParts() {
        // предел проверяется по ходу чтения частей multipart, а не после чтения файла в heap целиком
        ReflectionTestUtils.setField(scenarioService, "maxFileSizeBytes", 5L);
        ReflectionTestUtils.setField(scenarioService, "maxUploadBytes", 8L);
        FilePart document = mock(FilePart.class);
        when(document.filename()).thenReturn("акт.pdf");
        lenient().when(document.headers()).thenReturn(null);
        when(document.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap("1234".getBytes()),
                new DefaultDataBufferFactory().wrap("5678".getBytes())));
        FilePart archive = mock(FilePart.class);
        when(archive.filename()).thenReturn("акты.zip");
        lenient().when(archive.headers()).thenReturn(null);
        when(archive.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap("12345".getBytes()),
                new DefaultDataBufferFactory().wrap("6789".getBytes())));

        FileTooLargeException tooLarge = assertThrows(FileTooLargeException.class, () -> scenarioService.readFiles(List.of(document)));
        FileException total = assertThrows(FileException.class, () -> scenarioService.readFiles(List.of(archive)));

        assertEquals(413, tooLarge.getStatusCode());
        assertTrue(tooLarge.getMessage().startsWith("Файл «акт.pdf» больше допустимого размера"), tooLarge.getMessage());
        assertEquals(422, total.getStatusCode());
        assertTrue(total.getMessage().contains("Суммарный размер"), total.getMessage());
    }

    @Test
    void readFiles_totalAboveUploadLimit_rejectedWith422() {
        ReflectionTestUtils.setField(scenarioService, "maxUploadBytes", 10L);
        FilePart first = mockFilePart("a.txt", "123456".getBytes());
        FilePart second = mockFilePart("b.txt", "123456".getBytes());
        var files = List.of(first, second);

        FileException e = assertThrows(FileException.class, () -> scenarioService.readFiles(files));

        assertEquals(422, e.getStatusCode());
        assertTrue(e.getMessage().contains("Суммарный размер"), e.getMessage());
        assertTrue(e.getMessage().contains("b.txt"), e.getMessage());
    }

    @Test
    void readFiles_withinUploadLimit_returnsAllFiles() {
        ReflectionTestUtils.setField(scenarioService, "maxUploadBytes", 12L);
        FilePart first = mockFilePart("a.txt", "123456".getBytes());
        FilePart second = mockFilePart("b.txt", "123456".getBytes());

        List<ScenarioService.RawFile> raw = scenarioService.readFiles(List.of(first, second));

        assertEquals(List.of("a.txt", "b.txt"), raw.stream().map(ScenarioService.RawFile::name).toList());
    }

    @Test
    void getDocuments_emptyTextAfterParsing_getsUploadWarningForAnyFileType() throws IOException {
        // пустой текст после разбора (docx/xlsx/txt) раньше молча уходил в прогон
        FilePart file = mockFilePart("пустой.txt", "   ".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("   ");
        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals("   ", docs.get(0).text());
        assertTrue(events.stream().anyMatch(e -> "upload_warning".equals(e.data().get("type"))
                && "документ пуст: пустой.txt".equals(e.data().get("message"))));
        assertTrue(events.stream().anyMatch(e -> "upload_parsed".equals(e.data().get("type"))));
    }

    @Test
    void getDocuments_nonEmptyText_getsNoEmptyWarning() throws IOException {
        FilePart file = mockFilePart("текст.txt", "ok".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("ok");
        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();

        scenarioService.getDocuments(List.of(file), events);

        assertTrue(events.stream().noneMatch(e -> "upload_warning".equals(e.data().get("type"))));
    }
}
