package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.UploadStatusResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.DocumentText;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.mockito.ArgumentCaptor;
import org.springframework.http.codec.ServerSentEvent;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;

@WebFluxTest(controllers = ScenarioController.class)
@SuppressWarnings("unused")
class ScenarioControllerUploadFilesTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ScenarioService scenarioService;
    @MockitoBean
    private ScenarioEngine scenarioEngine;
    @MockitoBean
    private ScenarioUploadTaskService scenarioUploadTaskService;

    @Test
    void uploadFiles_ShouldProcessFilesAndCacheTexts() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "test.txt";
        String fileText = "Текст из файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем обработку документов
        when(scenarioService.getDocumentsText(any(), eq(null)))
                .thenReturn(List.of(fileText));

        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
            @Override
            public String getFilename() {
                return filename;
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // Мокируем кэширование
        doNothing().when(docsTextCacheService).cacheDocumentTexts(any(), any(), any(), any());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void uploadFiles_ShouldProcessMultipleFilesAndCacheTexts() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename1 = "document1.txt";
        String fileText1 = "Текст из первого файла.";
        String filename2 = "document2.txt";
        String fileText2 = "Текст из второго файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем обработку документов
        String combinedText = fileText1 + "\n---\n" + fileText2;
        when(scenarioService.getDocumentsText(any(), eq(null)))
                .thenReturn(List.of(combinedText));

        // Подготовка multipart тела с двумя файлами
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        ByteArrayResource resource1 = new ByteArrayResource(fileText1.getBytes()) {
            @Override
            public String getFilename() {
                return filename1;
            }
        };
        LinkedMultiValueMap<String, String> headers1 = new LinkedMultiValueMap<>();
        headers1.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource1, headers1));

        ByteArrayResource resource2 = new ByteArrayResource(fileText2.getBytes()) {
            @Override
            public String getFilename() {
                return filename2;
            }
        };
        LinkedMultiValueMap<String, String> headers2 = new LinkedMultiValueMap<>();
        headers2.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource2, headers2));

        // Мокируем кэширование
        doNothing().when(docsTextCacheService).cacheDocumentTexts(any(), any(), any(), any());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void uploadFiles_AsyncMode_ShouldReadBytesAndSubmitBackgroundTask() {
        // Given: async=true — запрос лишь принимает байты и ставит фоновую задачу
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String fileText = "Текст из файла.";

        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId, "Test Scenario", "Description", null, null,
                        new GraphDataDto(List.of(), List.of())));
        List<ScenarioService.RawFile> rawFiles =
                List.of(new ScenarioService.RawFile("test.txt", fileText.getBytes(StandardCharsets.UTF_8)));
        when(scenarioService.readFiles(any())).thenReturn(rawFiles);

        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
            @Override
            public String getFilename() {
                return "test.txt";
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload?async=true", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();

        verify(scenarioUploadTaskService).start(scenarioId, userId, rawFiles, false);
    }

    @Test
    void uploadStatus_ShouldReturnBackgroundTaskState() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId, "Test Scenario", "Description", null, null,
                        new GraphDataDto(List.of(), List.of())));
        when(scenarioUploadTaskService.status(scenarioId, userId)).thenReturn(
                UploadStatusResponse.of("done", 2, 5, List.of("скан.pdf: требуется ручная проверка"), ""));

        // When & Then: только ключи схемы UploadStatusResponse (additionalProperties: false)
        webClient.get()
                .uri("/api/scenarios/{id}/upload-status", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo("done")
                .jsonPath("$.files").isEqualTo(2)
                .jsonPath("$.documents").isEqualTo(5)
                .jsonPath("$.warnings[0]").isEqualTo("скан.pdf: требуется ручная проверка")
                .jsonPath("$.error").isEqualTo("")
                .jsonPath("$.parsed").doesNotExist()
                .jsonPath("$.ocr").doesNotExist()
                .jsonPath("$.message").doesNotExist();
    }

    @Test
    void uploadFiles_WithUnsupportedContentType_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "test.xyz";
        String fileText = "Текст из файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем вызов getDocuments для выброса исключения
        when(scenarioService.getDocuments(any(), any()))
                .thenThrow(new FileException("Не удалось обработать файл: " + filename));
        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
            @Override
            public String getFilename() {
                return filename;
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "application/xyz");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadFiles_WithoutFiles_ShouldReturnNoContent() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Мокируем обработку пустого списка файлов
        when(scenarioService.getDocumentsText(any(), eq(null)))
                .thenReturn(List.of());

        // Подготовка multipart тела без файлов
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();

        // Мокируем кэширование
        doNothing().when(docsTextCacheService).cacheDocumentTexts(any(), any(), any(), any());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void uploadFiles_WithJsonInsteadOfMultipart_ShouldReturnUnsupportedMediaType() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        Map<String, String> jsonBody = Map.of("key", "value");

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                // Отправляем JSON вместо multipart
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(jsonBody)
                .exchange()
                // Expect 415 Unsupported Media Type
                .expectStatus().isEqualTo(415);
    }

    @Test
    void uploadFiles_WithTooManyFiles_ShouldFailWithUnprocessableEntity() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "test.txt";
        String fileText = "Текст из файла.";

        // Мокируем, что сценарий существует
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId,
                        "Test Scenario",
                        "Description",
                        null,
                        null,
                        new GraphDataDto(List.of(), List.of())
                ));

        // Подготовка multipart тела с количеством файлов, превышающим лимит
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < ScenarioController.MAX_FILES_PER_REQUEST + 1; i++) {
            int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadFiles_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();

        // Мокируем, что сценарий не найден
        when(scenarioService.getScenario(scenarioId))
                .thenThrow(new IllegalArgumentException("Сценарий не найден: " + scenarioId));

        // Подготовка multipart тела
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource("test content".getBytes()) {
            @Override
            public String getFilename() {
                return "test.txt";
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource, fileHeaders));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isBadRequest();
    }

    @Test
    void uploadFiles_ShouldFailWhenDocumentLimitExceeded() {
        // Given: лимит = 10, в кэше 7, загружаем 4 → 7+4=11 > 10
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "file.txt";
        String fileText = "Текст из файла.";
        int limit = 10;
        int cachedCount = 7;
        int newDocuments = 4;

        // Мокируем сценарий
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId, "Test Scenario", "Description", null, null,
                        new GraphDataDto(List.of(), List.of())));

        // Мокируем getDocuments — возвращаем newDocuments документов
        List<ru.sber.cs.ai.gigame.service.scenario.DocumentText> docTexts = List.of(
                new ru.sber.cs.ai.gigame.service.scenario.DocumentText("file_0.txt", fileText),
                new ru.sber.cs.ai.gigame.service.scenario.DocumentText("file_1.txt", fileText),
                new ru.sber.cs.ai.gigame.service.scenario.DocumentText("file_2.txt", fileText),
                new ru.sber.cs.ai.gigame.service.scenario.DocumentText("file_3.txt", fileText)
        );
        when(scenarioService.getDocuments(any(), any())).thenReturn(docTexts);

        // Мокируем кэш — уже есть cachedCount документов
        when(docsTextCacheService.getCachedDocumentTexts(any()))
                .thenReturn(Collections.nCopies(cachedCount, "cached_text"));

        // Мокируем лимит
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(limit);

        // Подготовка тела с newDocuments файлами
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < newDocuments; i++) {
            final int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then: ожидаем 422 — FileException с сообщением о превышении лимита
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadFiles_ShouldSucceedWhenDocumentLimitNotExceeded() {
        // Given: лимит = 10, в кэше 3, загружаем 2 → 3+2=5 <= 10
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String fileText = "Текст из файла.";
        int limit = 10;

        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId, "Test Scenario", "Description", null, null,
                        new GraphDataDto(List.of(), List.of())));

        when(scenarioService.getDocumentsText(any(), eq(null)))
                .thenReturn(List.of(fileText, fileText));

        when(docsTextCacheService.getCachedDocumentTexts(any()))
                .thenReturn(Collections.nCopies(3, "cached_text"));

        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(limit);

        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes()) {
                @Override
                public String getFilename() {
                    return idx + "_" + "file.txt";
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then: успех, т.к. 3+2=5 <= 10
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void uploadFiles_WithExactlyMaxFiles_ShouldSucceed() {
        // Given: ровно MAX_FILES_PER_REQUEST = 100 — должно пройти
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "file.txt";
        String fileText = "Текст из файла.";

        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId, "Test Scenario", "Description", null, null,
                        new GraphDataDto(List.of(), List.of())));
        when(scenarioService.readFiles(any()))
                .thenReturn(List.of(new ScenarioService.RawFile(filename, fileText.getBytes())));

        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < ScenarioController.MAX_FILES_PER_REQUEST; i++) {
            final int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then: ровно 100 файлов — проходит, 101 — нет
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void uploadFiles_WithExactlyOneMoreThanMax_ShouldFail() {
        // Given: MAX_FILES_PER_REQUEST + 1 = 101 — должно упасть с 422
        String userId = "USER123";
        UUID scenarioId = UUID.randomUUID();
        String filename = "file.txt";
        String fileText = "Текст из файла.";

        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId, "Test Scenario", "Description", null, null,
                        new GraphDataDto(List.of(), List.of())));

        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        for (int i = 0; i < ScenarioController.MAX_FILES_PER_REQUEST + 1; i++) {
            final int idx = i;
            ByteArrayResource resource = new ByteArrayResource(fileText.getBytes(StandardCharsets.UTF_8)) {
                @Override
                public String getFilename() {
                    return idx + "_" + filename;
                }
            };
            LinkedMultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            headers.add("Content-Type", "text/plain");
            body.add("files", new HttpEntity<>(resource, headers));
        }

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isEqualTo(422);
    }

    @Test
    void uploadFiles_Sync_ShouldCacheUnderUserScopedKey() {
        // Given: общий сценарий, синхронная первая партия пользователя USER456
        String userId = "USER456";
        UUID scenarioId = UUID.randomUUID();
        UUID userKey = DocsTextCacheService.scenarioKey(scenarioId, userId);
        stubScenario(scenarioId);
        when(scenarioService.getDocuments(any(), any())).thenReturn(List.of(new DocumentText("a.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(10);

        // When
        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(singleFileBody("a.txt", "текст")))
                .exchange()
                .expectStatus().isOk();

        // Then: очистка, пометка загрузки и догрузка — только по ключу «сценарий + пользователь»
        verify(docsTextCacheService).clearCache(userKey);
        verify(docsTextCacheService).markUploading(userKey);
        verify(docsTextCacheService).appendDocumentTexts(userKey, List.of("текст"), List.of("a.txt"), List.of());
        verify(docsTextCacheService).unmarkUploading(userKey);
        verify(docsTextCacheService, never()).clearCache(scenarioId);
        verify(docsTextCacheService, never()).clearCache(DocsTextCacheService.scenarioKey(scenarioId, "USER123"));
    }

    @Test
    void uploadFiles_SyncLimit_ShouldNotCountOtherUsersDocuments() {
        // Given: у USER123 (и под старым общим ключом сценария) в кэше по 9 документов при лимите 10;
        // USER456 загружает 4 своих — это не превышение
        UUID scenarioId = UUID.randomUUID();
        UUID ownKey = DocsTextCacheService.scenarioKey(scenarioId, "USER456");
        stubScenario(scenarioId);
        when(docsTextCacheService.getCachedDocumentTexts(DocsTextCacheService.scenarioKey(scenarioId, "USER123")))
                .thenReturn(Collections.nCopies(9, "чужой документ"));
        when(docsTextCacheService.getCachedDocumentTexts(scenarioId))
                .thenReturn(Collections.nCopies(9, "документ общего ключа"));
        when(scenarioService.getDocuments(any(), any())).thenReturn(Collections.nCopies(4, new DocumentText("b.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(10);

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload?append=true", scenarioId)
                .header("X-UserId", "USER456")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(singleFileBody("b.txt", "текст")))
                .exchange()
                .expectStatus().isOk();

        // лимит считается и документы дописываются именно по ключу загружающего
        verify(docsTextCacheService).getCachedDocumentTexts(ownKey);
        verify(docsTextCacheService).appendDocumentTexts(eq(ownKey), any(), any(), any());
        verify(docsTextCacheService, never()).clearCache(any());
    }

    @Test
    void uploadFiles_SyncLimit_ShouldCountOwnDocuments() {
        // Given: у самого USER456 в кэше 9 документов при лимите 10 — ещё 4 своих дают превышение
        UUID scenarioId = UUID.randomUUID();
        UUID ownKey = DocsTextCacheService.scenarioKey(scenarioId, "USER456");
        stubScenario(scenarioId);
        when(docsTextCacheService.getCachedDocumentTexts(ownKey))
                .thenReturn(Collections.nCopies(9, "свой документ"));
        when(scenarioService.getDocuments(any(), any())).thenReturn(Collections.nCopies(4, new DocumentText("b.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(10);

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/upload?append=true", scenarioId)
                .header("X-UserId", "USER456")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(singleFileBody("b.txt", "текст")))
                .exchange()
                .expectStatus().isEqualTo(422);

        verify(docsTextCacheService, never()).appendDocumentTexts(any(), any(), any(), any());
        verify(docsTextCacheService).unmarkUploading(ownKey);
    }

    @Test
    void uploadStatus_WithoutUserHeader_ShouldPassNullUser() {
        // Given: без X-UserId контроллер передаёт пользователя как есть — ключ «anonymous» считает сервис
        UUID scenarioId = UUID.randomUUID();
        stubScenario(scenarioId);
        when(scenarioUploadTaskService.status(eq(scenarioId), isNull()))
                .thenReturn(UploadStatusResponse.of("none", 0, 0, List.of(), ""));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/upload-status", scenarioId)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.status").isEqualTo("none");

        verify(scenarioUploadTaskService).status(eq(scenarioId), isNull());
    }

    private void stubScenario(UUID scenarioId) {
        when(scenarioService.getScenario(scenarioId))
                .thenReturn(new ScenarioDetailResponse(
                        scenarioId, "Shared Scenario", "Description", null, null,
                        new GraphDataDto(List.of(), List.of())));
    }

    private static MultiValueMap<String, HttpEntity<?>> singleFileBody(String filename, String text) {
        MultiValueMap<String, HttpEntity<?>> body = new LinkedMultiValueMap<>();
        ByteArrayResource resource = new ByteArrayResource(text.getBytes(StandardCharsets.UTF_8)) {
            @Override
            public String getFilename() {
                return filename;
            }
        };
        LinkedMultiValueMap<String, String> fileHeaders = new LinkedMultiValueMap<>();
        fileHeaders.add("Content-Type", "text/plain");
        body.add("files", new HttpEntity<>(resource, fileHeaders));
        return body;
    }

    @Test
    @SuppressWarnings("unchecked")
    void uploadFiles_Sync_ShouldRecordParseWarningsForUploadStatus() {
        // предупреждения разбора при синхронной загрузке доходят до GET upload-status
        String userId = "USER456";
        UUID scenarioId = UUID.randomUUID();
        UUID userKey = DocsTextCacheService.scenarioKey(scenarioId, userId);
        stubScenario(scenarioId);
        when(scenarioService.getDocuments(any(), any())).thenAnswer(inv -> {
            List<ServerSentEvent<Map<String, Object>>> events = inv.getArgument(1);
            events.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_warning", "file", "a.txt", "message", "документ пуст: a.txt"))
                    .build());
            return List.of(new DocumentText("a.txt", ""));
        });
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(10);
        when(docsTextCacheService.appendDocumentTexts(eq(userKey), any(), any(), any())).thenReturn(1);

        webClient.post()
                .uri("/api/scenarios/{id}/upload", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(singleFileBody("a.txt", "")))
                .exchange()
                .expectStatus().isOk();

        ArgumentCaptor<List<ServerSentEvent<Map<String, Object>>>> captor = ArgumentCaptor.forClass(List.class);
        verify(scenarioUploadTaskService).recordSyncUpload(eq(userKey), eq(1), eq(1), captor.capture());
        assertEquals("документ пуст: a.txt", captor.getValue().get(0).data().get("message"));
    }
}
