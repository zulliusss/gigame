package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.annotate.DocumentAnnotationService;
import ru.sber.cs.ai.gigame.service.annotate.RunArtifactStore;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputView;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputViews;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.KBService;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.InMemoryFilePart;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты доп. возможностей output-узла: нарастающий итог («накапливать»)
 * и реестр в базе знаний («в_базу_знаний»).
 */
@ExtendWith(MockitoExtension.class)
class ScenarioOutputSupportServiceTest {

    @Mock
    private ScenarioRunRepository scenarioRunRepository;
    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;
    @Mock
    private KBService kbService;
    @Mock
    private ScenarioRepository scenarioRepository;
    @Mock
    private DocumentAnnotationService documentAnnotationService;
    @Mock
    private RunArtifactStore runArtifactStore;

    @InjectMocks
    private ScenarioOutputSupportService service;

    private static ScenarioRun run(UUID id, UUID scenarioId) {
        ScenarioRun run = new ScenarioRun();
        run.setId(id);
        run.setScenarioId(scenarioId);
        return run;
    }

    private static Scenario scenario(UUID id, String ownerId) {
        Scenario scenario = new Scenario();
        scenario.setId(id);
        scenario.setUserId(ownerId);
        return scenario;
    }

    private static StepOutputView outputStep(String result) {
        return StepOutputViews.of("b9", "output", Map.of("result", result));
    }

    private static ScenarioRunNode outputNode(String rules) {
        ScenarioRunNode node = mock(ScenarioRunNode.class);
        when(node.getRules()).thenReturn(rules);
        lenient().when(node.getId()).thenReturn("b9");
        return node;
    }

    @Test
    void accumulate_appendsCurrentRowsBelowPreviousRunRows() {
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        ScenarioRun previous = run(UUID.randomUUID(), scenarioId);
        ScenarioRunStep prevStep = new ScenarioRunStep();
        prevStep.setNodeId("b9");
        prevStep.setOutputData(Map.of("result", "[{\"договор\": \"партия-1\", \"сумма\": 100.50}]"));

        when(scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenarioId))
                .thenReturn(List.of(current, previous));
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(previous.getId(), "b9"))
                .thenReturn(List.of(StepOutputViews.of(prevStep)));

        String merged = service.accumulateIfConfigured(current, outputNode("{\"накапливать\": true}"),
                "[{\"договор\": \"партия-2\", \"сумма\": 200.00}]");

        // строки прошлого прогона ПЕРЕД новыми (новый результат — ниже первых)
        assertTrue(merged.indexOf("партия-1") < merged.indexOf("партия-2"));
        assertTrue(merged.trim().startsWith("["));
    }

    @Test
    void accumulate_authoredRun_takesOnlySameUsersPreviousRun() {
        // общий сценарий: строки чужих прогонов в нарастающий итог не попадают
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        current.setUserId("ALICE");
        ScenarioRun alicePrevious = run(UUID.randomUUID(), scenarioId);
        alicePrevious.setUserId("ALICE");
        ScenarioRunStep prevStep = new ScenarioRunStep();
        prevStep.setNodeId("b9");
        prevStep.setOutputData(Map.of("result", "[{\"договор\": \"партия Алисы\"}]"));

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario(scenarioId, "OWNER")));
        when(scenarioRunRepository.findCompletedRunsByUser(scenarioId, "ALICE"))
                .thenReturn(List.of(current, alicePrevious));
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(alicePrevious.getId(), "b9"))
                .thenReturn(List.of(StepOutputViews.of(prevStep)));

        String merged = service.accumulateIfConfigured(current, outputNode("{\"накапливать\": true}"),
                "[{\"договор\": \"новая партия\"}]");

        assertTrue(merged.indexOf("партия Алисы") < merged.indexOf("новая партия"));
        verify(scenarioRunRepository, never()).findByScenarioIdOrderByStartedAtDesc(any());
        verify(scenarioRunRepository, never()).findCompletedOwnerRuns(any(), any());
    }

    @Test
    void accumulate_scenarioOwnerRun_includesLegacyRunWithoutAuthor() {
        // первый прогон владельца после обновления: строки старого прогона без автора
        // остаются в нарастающем итоге — цепочка партий не обрывается
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        current.setUserId("OWNER");
        ScenarioRun legacy = run(UUID.randomUUID(), scenarioId);

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario(scenarioId, "OWNER")));
        when(scenarioRunRepository.findCompletedOwnerRuns(scenarioId, "OWNER"))
                .thenReturn(List.of(current, legacy));
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(legacy.getId(), "b9"))
                .thenReturn(List.of(outputStep("[{\"договор\": \"партия до обновления\"}]")));

        String merged = service.accumulateIfConfigured(current, outputNode("{\"накапливать\": true}"),
                "[{\"договор\": \"партия после обновления\"}]");

        assertTrue(merged.contains("партия до обновления"));
        assertTrue(merged.indexOf("партия до обновления") < merged.indexOf("партия после обновления"));
        verify(scenarioRunRepository, never()).findCompletedRunsByUser(any(), any());
        verify(scenarioRunRepository, never()).findByScenarioIdOrderByStartedAtDesc(any());
    }

    @Test
    void accumulate_nonOwnerRun_ignoresLegacyRunsWithoutAuthor() {
        // старые прогоны без автора принадлежат владельцу — не-владельцу они не достаются
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        current.setUserId("BOB");

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario(scenarioId, "OWNER")));
        when(scenarioRunRepository.findCompletedRunsByUser(scenarioId, "BOB"))
                .thenReturn(List.of(current));

        String result = "[{\"договор\": \"партия Боба\"}]";
        assertEquals(result, service.accumulateIfConfigured(current,
                outputNode("{\"накапливать\": true}"), result));
        verify(scenarioRunRepository, never()).findCompletedOwnerRuns(any(), any());
        verify(scenarioRunRepository, never()).findByScenarioIdOrderByStartedAtDesc(any());
        verify(scenarioRunStepRepository, never()).findViewByRunIdAndNodeIdOrderByStartedAtAsc(any(), any());
    }

    @Test
    void accumulate_authoredRunWithoutOwnPreviousRuns_returnsResultUnchanged() {
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        current.setUserId("BOB");
        when(scenarioRunRepository.findCompletedRunsByUser(scenarioId, "BOB"))
                .thenReturn(List.of(current));

        String result = "[{\"договор\": \"первая партия Боба\"}]";
        assertEquals(result, service.accumulateIfConfigured(current,
                outputNode("{\"накапливать\": true}"), result));
        verify(scenarioRunStepRepository, never()).findViewByRunIdAndNodeIdOrderByStartedAtAsc(any(), any());
    }

    @Test
    void accumulate_withoutFlag_returnsResultUnchanged() {
        ScenarioRun current = run(UUID.randomUUID(), UUID.randomUUID());
        String result = "[{\"договор\": \"единственная партия\"}]";

        assertEquals(result, service.accumulateIfConfigured(current,
                outputNode("{\"колонки\": []}"), result));
        verify(scenarioRunRepository, never()).findByScenarioIdOrderByStartedAtDesc(any());
    }

    @Test
    void accumulate_withoutPreviousRuns_returnsResultUnchanged() {
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        when(scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenarioId))
                .thenReturn(List.of(current));

        String result = "[{\"договор\": \"первая партия\"}]";
        assertEquals(result, service.accumulateIfConfigured(current,
                outputNode("{\"накапливать\": true}"), result));
    }

    @Test
    void accumulate_overlappingRunsOfOneUser_takesRunFinishedLast() {
        // run1 стартовал раньше run2, но завершился позже: основа берётся по времени ЗАВЕРШЕНИЯ,
        // иначе партия P1 выпадала из нарастающего итога (выбор по времени старта)
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        current.setUserId("ALICE");
        ScenarioRun run1 = run(UUID.randomUUID(), scenarioId);
        run1.setUserId("ALICE");
        ScenarioRun run2 = run(UUID.randomUUID(), scenarioId);
        run2.setUserId("ALICE");

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario(scenarioId, "OWNER")));
        // порядок запроса — по completed_at по убыванию: run1 завершился последним
        when(scenarioRunRepository.findCompletedRunsByUser(scenarioId, "ALICE"))
                .thenReturn(List.of(run1, run2));
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(run1.getId(), "b9"))
                .thenReturn(List.of(outputStep("[{\"партия\": \"P0\"},{\"партия\": \"P2\"},{\"партия\": \"P1\"}]")));

        String merged = service.accumulateIfConfigured(current, outputNode("{\"накапливать\": true}"),
                "[{\"партия\": \"P3\"}]");

        assertEquals("[{\"партия\":\"P0\"},{\"партия\":\"P2\"},{\"партия\":\"P1\"},{\"партия\":\"P3\"}]", merged);
        verify(scenarioRunStepRepository, never()).findViewByRunIdAndNodeIdOrderByStartedAtAsc(eq(run2.getId()), any());
    }

    @Test
    void saveToKnowledgeBase_uploadsResultAsTextDocument() {
        UUID scenarioId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);

        service.saveToKnowledgeBaseIfConfigured(current,
                outputNode("{\"в_базу_знаний\": \"" + kbId + "\"}"), "строки реестра");

        ArgumentCaptor<InMemoryFilePart> captor = ArgumentCaptor.forClass(InMemoryFilePart.class);
        verify(kbService).addDocumentToKB(eq(kbId), captor.capture());
        assertTrue(captor.getValue().filename().endsWith(".txt"));
        assertTrue(new String(captor.getValue().bytes(), StandardCharsets.UTF_8)
                .contains("строки реестра"));
    }

    @Test
    void saveToKnowledgeBase_errorDoesNotPropagate() {
        UUID scenarioId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        doThrow(new RuntimeException("БЗ недоступна"))
                .when(kbService).addDocumentToKB(eq(kbId), any());

        // ошибка сохранения реестра не роняет прогон
        assertDoesNotThrow((() -> service.saveToKnowledgeBaseIfConfigured(current,
                outputNode("{\"в_базу_знаний\": \"" + kbId + "\"}"), "строки")));
    }

    @Test
    void saveToKnowledgeBase_replacesPreviousRegistryUnderStableName() {
        // storage-4: реестр — один документ на пару «сценарий + автор», прежний удаляется, а не копится прогонами
        UUID scenarioId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        ScenarioRun first = run(UUID.randomUUID(), scenarioId);
        first.setUserId("ALICE");
        ScenarioRun second = run(UUID.randomUUID(), scenarioId);
        second.setUserId("ALICE");
        when(kbService.removeDocumentsByFilename(eq(kbId), any(), any())).thenReturn(1);

        service.saveToKnowledgeBaseIfConfigured(first, outputNode("{\"в_базу_знаний\": \"" + kbId + "\"}"), "строки реестра");
        service.saveToKnowledgeBaseIfConfigured(second, outputNode("{\"в_базу_знаний\": \"" + kbId + "\"}"), "строки реестра");

        String expected = "registry-" + scenarioId + "-ALICE.txt";
        ArgumentCaptor<InMemoryFilePart> parts = ArgumentCaptor.forClass(InMemoryFilePart.class);
        ArgumentCaptor<String> hashes = ArgumentCaptor.forClass(String.class);
        verify(kbService, times(2)).removeDocumentsByFilename(eq(kbId), eq(expected), hashes.capture());
        verify(kbService, times(2)).addDocumentToKB(eq(kbId), parts.capture());
        assertEquals(expected, parts.getAllValues().get(0).filename());
        assertEquals(expected, parts.getAllValues().get(1).filename());
        // одинаковый результат — одинаковое содержимое и хэш: повтор не переиндексируется
        assertArrayEquals(parts.getAllValues().get(0).bytes(), parts.getAllValues().get(1).bytes());
        assertEquals(hashes.getAllValues().get(0), hashes.getAllValues().get(1));
        assertEquals(DocumentService.sha256Hex(parts.getAllValues().get(0).bytes()), hashes.getAllValues().get(0));
        ScenarioRun anonymous = run(UUID.randomUUID(), scenarioId);
        assertEquals("registry-" + scenarioId + "-shared.txt", ScenarioOutputSupportService.registryName(anonymous));
    }

    @Test
    void annotate_failureStoresReportOnlyZipInsteadOfNothing() throws Exception {
        // storage-2: разметка не удалась — в артефактах ZIP с отчётом о причине, а не молчаливый Excel без разметки
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        ScenarioRunNode node = outputNode("{\"разметка_документов\": {}}");
        ScenarioRunGraph graph = mock(ScenarioRunGraph.class);
        when(graph.getRunnerUserId()).thenReturn("ALICE");
        when(graph.getDocMap()).thenReturn(Map.of("DOC_1", new ScenarioRunDoc("Договор.pdf", "текст")));
        when(node.getGraph()).thenReturn(graph);
        when(documentAnnotationService.annotate(any(), eq(current.getId()), any(), any(), any()))
                .thenThrow(new IllegalStateException("PDF повреждён"));

        service.annotateIfConfigured(current, node, "[{\"з2\": \"риск\"}]");

        ArgumentCaptor<byte[]> zip = ArgumentCaptor.forClass(byte[].class);
        verify(runArtifactStore).save(eq(current.getId()), eq("b9"), zip.capture());
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(zip.getValue()))) {
            ZipEntry entry = in.getNextEntry();
            assertEquals(DocumentAnnotationService.REPORT_ENTRY, entry.getName());
            assertEquals("разметка документов не выполнена: PDF повреждён", new String(in.readAllBytes(), StandardCharsets.UTF_8));
        }
    }

    @Test
    void annotate_keysSameNameDocumentsUniquelyAndPassesRunId() {
        // cache-10 / concurrency-7: одноимённые документы не схлопываются, оригиналы берутся из снимка прогона
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        ScenarioRunNode node = outputNode("{\"разметка_документов\": {}}");
        ScenarioRunGraph graph = mock(ScenarioRunGraph.class);
        when(graph.getRunnerUserId()).thenReturn("ALICE");
        Map<String, ScenarioRunDoc> docs = new LinkedHashMap<>();
        docs.put("DOC_1", new ScenarioRunDoc("Договор.pdf", "лот 1"));
        docs.put("DOC_2", new ScenarioRunDoc("Договор.pdf", "лот 2"));
        when(graph.getDocMap()).thenReturn(docs);
        when(node.getGraph()).thenReturn(graph);
        when(documentAnnotationService.annotate(any(), any(), any(), any(), any())).thenReturn(new byte[] {1});

        service.annotateIfConfigured(current, node, "[]");

        ArgumentCaptor<Map<String, String>> texts = ArgumentCaptor.forClass(Map.class);
        verify(documentAnnotationService).annotate(eq(DocsTextCacheService.scenarioKey(scenarioId, "ALICE")),
                eq(current.getId()), any(), any(), texts.capture());
        assertEquals(Map.of("Договор.pdf", "лот 1", "Договор (2).pdf", "лот 2"), texts.getValue());
        verify(runArtifactStore).save(current.getId(), "b9", new byte[] {1});
    }
}
