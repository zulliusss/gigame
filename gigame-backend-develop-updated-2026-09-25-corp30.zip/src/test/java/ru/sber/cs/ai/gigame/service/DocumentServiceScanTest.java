package ru.sber.cs.ai.gigame.service;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты постраничного детектора скана: страница-штамп ЭДО с текстом подписей
 * не должна скрывать скан, а текстовый документ не должен уходить в OCR —
 * в том числе из-за пустых страниц без изображений.
 */
class DocumentServiceScanTest {

    private static final String LONG_TEXT = "Document signed and transferred via EDO operator, registration number 12345";
    private final DocumentService service = new DocumentService(null, null, null);

    private static byte[] pdf(String... pages) throws IOException {
        return TestPdf.of(pages);
    }

    @Test
    void textDocumentIsNotScan() throws IOException {
        assertFalse(service.isScanPdf(pdf(LONG_TEXT, LONG_TEXT), LONG_TEXT + "\n" + LONG_TEXT));
    }

    @Test
    void scanWithEdoStampPageIsScan() throws IOException {
        // две страницы-картинки акта и страница-штамп с текстом подписей: текст выше порога, но это скан
        assertTrue(service.isScanPdf(pdf(TestPdf.IMAGE, TestPdf.IMAGE, LONG_TEXT), LONG_TEXT));
    }

    @Test
    void blankPagesWithoutImagesAreNotScan() throws IOException {
        // договор p8 (16.09.2026): пустая страница машиночитаемого документа отправляла его в OCR
        byte[] withBlankPages = pdf(LONG_TEXT, TestPdf.BLANK, TestPdf.BLANK);

        assertFalse(service.isScanPdf(withBlankPages, LONG_TEXT));
        assertEquals(List.of(), service.textlessPages(withBlankPages));
    }

    @Test
    void imagePagesAreFoundInResourcesFormsAndInlineImages() throws IOException {
        byte[] content = pdf(LONG_TEXT, TestPdf.IMAGE, TestPdf.BLANK, TestPdf.FORM_IMAGE, TestPdf.INLINE_IMAGE, TestPdf.SELF_FORM);

        assertEquals(List.of(2, 4, 5), service.textlessPages(content));
        assertTrue(service.isScanPdf(content, LONG_TEXT));
        assertTrue(service.textlessPages("not a pdf".getBytes()).isEmpty());
    }

    @Test
    void shortTextIsScanWithoutPageCheck() {
        assertTrue(service.isScanPdf(new byte[0], "  \n "));
    }

    @Test
    void unreadablePdfWithLongTextIsNotScan() {
        assertFalse(service.isScanPdf("not a pdf".getBytes(), LONG_TEXT));
    }

    @Test
    void recognizedTextKeepsParsedStamp() {
        assertEquals("[РАСПОЗНАНО] акт\n\nштамп ЭДО", DocumentService.withParsed("[РАСПОЗНАНО] акт", " штамп ЭДО \n"));
        assertEquals("[РАСПОЗНАНО] акт", DocumentService.withParsed("[РАСПОЗНАНО] акт", "  "));
    }

    @Test
    void pagedRecognitionDoesNotAppendTextLayerSecondTime() {
        // постраничный OCR уже включил страницу-штамп как «(текстовый слой)»: раньше штамп дописывался ещё раз хвостом
        String paged = "[РАСПОЗНАНО] Документ «акт.pdf»:\n--- страница 1 ---\nАкт\n\n--- страница 2 (текстовый слой) ---\nштамп ЭДО";

        assertEquals(paged, DocumentService.withParsed(paged, "штамп ЭДО"));
        assertEquals(1, paged.split("штамп ЭДО", -1).length - 1);
    }

    @Test
    void pdfIsParsedOnceAndPageCheckIsTakenFromCache() throws IOException {
        // текст, признак скана и страницы без слоя — из одного прохода PDFBox: раньше файл открывался до трёх раз
        byte[] content = pdf(LONG_TEXT, TestPdf.IMAGE, LONG_TEXT);

        String text = service.parseText(new ByteArrayInputStream(content), "pdf");

        try (PDDocument doc = Loader.loadPDF(content)) {
            assertEquals(new PDFTextStripper().getText(doc), text);
        }
        var cache = (Map<?, ?>) ReflectionTestUtils.getField(service, "pdfPagesCache");
        assertTrue(cache.containsKey(DocumentService.sha256Hex(content)));
        assertEquals(List.of(2), service.textlessPages(content));
        assertFalse(service.isScanPdf(content, text));
    }
}
