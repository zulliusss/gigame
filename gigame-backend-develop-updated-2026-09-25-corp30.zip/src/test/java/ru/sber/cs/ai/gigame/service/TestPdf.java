package ru.sber.cs.ai.gigame.service;

import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDFormContentStream;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.graphics.image.PDInlineImage;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Синтетические PDF для тестов постраничной проверки: страница с текстом,
 * пустая страница, страница-картинка (image XObject), картинка внутри
 * form XObject, inline image и форма, ссылающаяся сама на себя (без картинок).
 */
public final class TestPdf {

    /** Пустая страница: ни текста, ни изображений. */
    public static final String BLANK = "";

    /** Страница-картинка: image XObject в ресурсах страницы. */
    public static final String IMAGE = "<image>";

    /** Картинка внутри form XObject: в ресурсах страницы только форма. */
    public static final String FORM_IMAGE = "<form-image>";

    /** Inline image (BI … ID … EI) в потоке содержимого страницы. */
    public static final String INLINE_IMAGE = "<inline-image>";

    /** Form XObject без картинок, в ресурсах которого есть он сам (цикл). */
    public static final String SELF_FORM = "<self-form>";

    private TestPdf() {
    }

    /**
     * PDF из страниц: константа класса задаёт вид страницы, любая другая строка — текст страницы.
     *
     * @param pages виды страниц либо тексты
     * @return содержимое PDF
     * @throws IOException ошибка сборки PDF
     */
    public static byte[] of(String... pages) throws IOException {
        try (PDDocument doc = new PDDocument()) {
            for (String page : pages) {
                addPage(doc, page);
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private static void addPage(PDDocument doc, String kind) throws IOException {
        PDPage page = new PDPage();
        doc.addPage(page);
        if (BLANK.equals(kind)) {
            return;
        }
        try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
            draw(doc, cs, kind);
        }
    }

    private static void draw(PDDocument doc, PDPageContentStream cs, String kind) throws IOException {
        if (IMAGE.equals(kind)) {
            cs.drawImage(image(doc), 50, 50, 200, 200);
        } else if (FORM_IMAGE.equals(kind)) {
            cs.drawForm(formWithImage(doc));
        } else if (INLINE_IMAGE.equals(kind)) {
            COSDictionary params = new COSDictionary();
            params.setInt(COSName.W, 1);
            params.setInt(COSName.H, 1);
            params.setInt(COSName.BPC, 8);
            params.setItem(COSName.CS, COSName.G);
            cs.drawImage(new PDInlineImage(params, new byte[]{0}, new PDResources()), 50, 50, 10, 10);
        } else if (SELF_FORM.equals(kind)) {
            cs.drawForm(selfForm(doc));
        } else {
            cs.beginText();
            cs.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
            cs.newLineAtOffset(50, 700);
            cs.showText(kind);
            cs.endText();
        }
    }

    private static PDImageXObject image(PDDocument doc) throws IOException {
        return LosslessFactory.createFromImage(doc, new BufferedImage(4, 4, BufferedImage.TYPE_INT_RGB));
    }

    private static PDFormXObject formWithImage(PDDocument doc) throws IOException {
        PDFormXObject form = new PDFormXObject(doc);
        form.setBBox(new PDRectangle(200, 200));
        form.setResources(new PDResources());
        try (PDFormContentStream fcs = new PDFormContentStream(form)) {
            fcs.drawImage(image(doc), 0, 0, 200, 200);
        }
        return form;
    }

    private static PDFormXObject selfForm(PDDocument doc) throws IOException {
        PDFormXObject form = new PDFormXObject(doc);
        form.setBBox(new PDRectangle(10, 10));
        PDResources resources = new PDResources();
        form.setResources(resources);
        try (PDFormContentStream fcs = new PDFormContentStream(form)) {
            fcs.addRect(0, 0, 5, 5);
            fcs.fill();
        }
        resources.put(COSName.getPDFName("Self"), form);
        return form;
    }
}
