package ru.sber.cs.ai.gigame.service.annotate;

import org.apache.poi.xwpf.usermodel.XWPFComment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Разметка DOCX: подсветка цитаты внутри абзаца с делением ранов и комментарий Word к ней.
 */
class DocxAnnotatorTest {

    private static final String BEFORE = "Квалификационное требование №2: ";
    private static final String QUOTE = "гарантия отсутствия действующих договоров с другими банками";
    private static final String AFTER = " на период выполнения работ.";

    private static byte[] document() throws IOException {
        try (XWPFDocument doc = new XWPFDocument()) {
            doc.createParagraph().createRun().setText("Пояснительная записка. Предмет закупки — контент.");
            XWPFRun run = doc.createParagraph().createRun();
            run.setText(BEFORE + QUOTE + AFTER);
            XWPFTable table = doc.createTable(1, 2);
            table.getRow(0).getCell(0).setText("НМЦД");
            table.getRow(0).getCell(1).setText("Итоговая сумма закупки составит: не более 289 523 339,14 руб.");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.write(out);
            return out.toByteArray();
        }
    }

    private static Finding finding(int number, String quote, String level, List<String> numbers) {
        return new Finding(number, "документ.docx", quote, level, "[" + level + "] Суть находки\nРекомендация: исправить", numbers);
    }

    @Test
    void highlightsQuoteInsideParagraphAndAttachesComment() throws IOException {
        DocxAnnotator.Result result = DocxAnnotator.annotate(document(),
                List.of(finding(1, "«Гарантия отсутствия действующих договоров с другими банками»", "ВЫСОКИЙ", List.of())));

        assertEquals(1, result.annotated());
        assertTrue(result.notes().isEmpty(), String.valueOf(result.notes()));
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(result.content()))) {
            XWPFParagraph paragraph = doc.getParagraphs().get(1);
            assertEquals(BEFORE + QUOTE + AFTER, paragraph.getText());
            List<XWPFRun> highlighted = paragraph.getRuns().stream().filter(XWPFRun::isHighlighted).toList();
            assertEquals(1, highlighted.size());
            assertEquals(QUOTE, highlighted.get(0).text());
            assertEquals("red", highlighted.get(0).getTextHighlightColor().toString());
            List<XWPFComment> comments = doc.getDocComments().getComments();
            assertEquals(1, comments.size());
            assertEquals("GigaMe", comments.get(0).getAuthor());
            assertTrue(comments.get(0).getText().contains("Суть находки"));
            assertTrue(paragraph.getCTP().xmlText().contains("commentRangeStart"));
            assertTrue(paragraph.getCTP().xmlText().contains("commentReference"));
        }
    }

    @Test
    void findingWithoutQuoteIsAnchoredByNumberInTableCell() throws IOException {
        DocxAnnotator.Result result = DocxAnnotator.annotate(document(),
                List.of(finding(2, "", "СРЕДНИЙ", Finding.numbersOf("Расхождение сумм НМЦ: 289523339.14 руб. в ПЗ против 288543415.67 руб."))));

        assertEquals(1, result.annotated());
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(result.content()))) {
            XWPFParagraph cell = doc.getTables().get(0).getRow(0).getCell(1).getParagraphs().get(0);
            List<XWPFRun> highlighted = cell.getRuns().stream().filter(XWPFRun::isHighlighted).toList();
            assertEquals(1, highlighted.size());
            assertEquals("289 523 339,14", highlighted.get(0).text());
            assertEquals("yellow", highlighted.get(0).getTextHighlightColor().toString());
        }
    }

    @Test
    void quoteInsideRunWithTabIsHighlightedWholeWithoutBreakingText() throws IOException {
        byte[] docx = documentWithTabRun();
        Finding found = finding(1, "Экспертная статья для профильного раздела", "ВЫСОКИЙ", List.of());

        DocxAnnotator.Result result = DocxAnnotator.annotate(docx, List.of(found));

        assertEquals(1, result.annotated());
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(result.content()))) {
            XWPFParagraph paragraph = doc.getParagraphs().get(0);
            assertEquals("Категория A1\tЭкспертная статья для профильного раздела сайта.",
                    paragraph.getRuns().stream().map(XWPFRun::text).reduce("", String::concat));
            List<XWPFRun> highlighted = paragraph.getRuns().stream().filter(XWPFRun::isHighlighted).toList();
            assertEquals(1, highlighted.size());
            assertTrue(highlighted.get(0).text().contains("Экспертная статья для профильного раздела"));
            assertEquals(1, doc.getDocComments().getComments().size());
        }
    }

    /** Абзац из одного рана с табуляцией внутри: текст рана шире его {@code <w:t>}. */
    private static byte[] documentWithTabRun() throws IOException {
        try (XWPFDocument doc = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            XWPFRun run = doc.createParagraph().createRun();
            run.setText("Категория A1");
            run.addTab();
            run.setText("Экспертная статья для профильного раздела сайта.");
            doc.write(out);
            return out.toByteArray();
        }
    }

    @Test
    void codeFindingWithCurrencyInQuoteIsAnchoredByItsNumber() throws IOException {
        // кодовая находка пишет суммы со знаком рубля, а в ячейке таблицы документа знака нет
        Finding sums = new Finding(1, "документ.docx", "НМЦ 289523339,14 ₽ … 1 000 000,00 ₽", "СРЕДНИЙ",
                "[СРЕДНИЙ] Расхождение сумм", Finding.numbersOf("НМЦ 289523339,14 ₽ … 1 000 000,00 ₽"));

        DocxAnnotator.Result result = DocxAnnotator.annotate(document(), List.of(sums));

        assertEquals(1, result.annotated());
        assertEquals(1, result.notes().size());
        assertTrue(result.notes().get(0).contains("«289 523 339,14»"), String.valueOf(result.notes()));
    }

    @Test
    void missingQuoteIsReportedWithoutChangingDocument() throws IOException {
        byte[] source = document();

        DocxAnnotator.Result result = DocxAnnotator.annotate(source,
                List.of(finding(3, "этой фразы в документе точно нет нигде", "НИЗКИЙ", List.of())));

        assertEquals(0, result.annotated());
        assertEquals(1, result.notes().size());
        assertTrue(result.notes().get(0).contains("не найдена"));
    }
}
