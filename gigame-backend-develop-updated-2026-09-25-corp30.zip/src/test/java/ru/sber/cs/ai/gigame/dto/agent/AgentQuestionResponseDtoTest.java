package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.config.JacksonConfig;
import ru.sber.cs.ai.gigame.model.AgentQuestion;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты DTO вопроса агента: ключи snake_case строго по схеме AgentQuestion
 * (additionalProperties: false), лимиты строк и формат дат.
 */
class AgentQuestionResponseDtoTest {

    private final ObjectMapper mapper = new JacksonConfig().objectMapper();

    private static AgentQuestion answeredQuestion() {
        AgentQuestion q = new AgentQuestion();
        q.setId(UUID.randomUUID());
        q.setRunId(UUID.randomUUID());
        q.setScenarioId(UUID.randomUUID());
        q.setNodeLabel("Агент");
        q.setQuestion("По пункту «НМЦ» значение не подтверждено");
        q.setAnswer("в разделе 5");
        // время из памяти JVM: пояс +03:00 и наносекунды (Linux) — 35 символов без нормализации
        q.setAnsweredAt(OffsetDateTime.of(2026, 9, 15, 13, 4, 37, 669_778_312, ZoneOffset.ofHours(3)));
        q.setCreatedAt(OffsetDateTime.of(2026, 9, 15, 7, 0, 0, 123_456_000, ZoneOffset.UTC));
        return q;
    }

    @Test
    void serialization_usesSnakeCaseSchemaKeys() throws Exception {
        AgentQuestion entity = answeredQuestion();

        JsonNode json = mapper.readTree(mapper.writeValueAsString(AgentQuestionResponseDto.from(entity)));

        Set<String> keys = new HashSet<>();
        json.fieldNames().forEachRemaining(keys::add);
        assertEquals(Set.of("id", "run_id", "scenario_id", "node_label", "question", "answer",
                "answered_at", "created_at"), keys);
        assertEquals(entity.getRunId().toString(), json.get("run_id").asText());
        assertEquals("Агент", json.get("node_label").asText());
        assertEquals("в разделе 5", json.get("answer").asText());
    }

    @Test
    void serialization_answeredAtIsUtcMicrosWithinMaxLength() throws Exception {
        JsonNode json = mapper.readTree(mapper.writeValueAsString(AgentQuestionResponseDto.from(answeredQuestion())));

        assertEquals("2026-09-15T10:04:37.669778Z", json.get("answered_at").asText());
        assertEquals("2026-09-15T07:00:00.123456Z", json.get("created_at").asText());
        assertTrue(json.get("answered_at").asText().length() <= 32);
    }

    @Test
    void serialization_unansweredQuestionOmitsNullKeys() throws Exception {
        AgentQuestion entity = answeredQuestion();
        entity.setAnswer(null);
        entity.setAnsweredAt(null);
        entity.setScenarioId(null);

        JsonNode json = mapper.readTree(mapper.writeValueAsString(AgentQuestionResponseDto.from(entity)));

        assertNull(json.get("answer"));
        assertNull(json.get("answered_at"));
        assertNull(json.get("scenario_id"));
    }

    @Test
    void from_clipsTextsBySchemaLimits() {
        AgentQuestion entity = answeredQuestion();
        entity.setNodeLabel("м".repeat(400));
        entity.setQuestion("в".repeat(4500));
        entity.setAnswer("о".repeat(4001));

        AgentQuestionResponseDto dto = AgentQuestionResponseDto.from(entity);

        assertEquals(AgentQuestionResponseDto.NODE_LABEL_MAX_LENGTH, dto.nodeLabel().length());
        assertEquals(AgentQuestionResponseDto.TEXT_MAX_LENGTH, dto.question().length());
        assertEquals(AgentQuestionResponseDto.TEXT_MAX_LENGTH, dto.answer().length());
        assertTrue(dto.question().endsWith("…"));
    }
}
