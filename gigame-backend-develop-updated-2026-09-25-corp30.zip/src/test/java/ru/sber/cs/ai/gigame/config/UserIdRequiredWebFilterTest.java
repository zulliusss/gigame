package ru.sber.cs.ai.gigame.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Фильтр обязательного заголовка X-UserId: с включённым флагом запросы на /api/** и /ws/**
 * без допустимого заголовка получают 401 с ErrorResponse, остальные пути и выключенный
 * флаг — пропускаются.
 */
class UserIdRequiredWebFilterTest {

    private static final ObjectMapper MAPPER = new JacksonConfig().objectMapper();

    /** Обмен с запросом GET на путь с необязательным заголовком X-UserId. */
    private static MockServerWebExchange exchange(String path, String userId) {
        MockServerHttpRequest.BaseBuilder<?> request = MockServerHttpRequest.get(path);
        if (userId != null) {
            request.header(UserIdRequiredWebFilter.HEADER, userId);
        }
        return MockServerWebExchange.from(request.build());
    }

    /** Пропустил ли фильтр запрос дальше по цепочке. */
    private static boolean passed(UserIdRequiredWebFilter filter, MockServerWebExchange exchange) {
        AtomicBoolean passed = new AtomicBoolean();
        WebFilterChain chain = ex -> {
            passed.set(true);
            return Mono.empty();
        };
        filter.filter(exchange, chain).block();
        return passed.get();
    }

    private static JsonNode body(MockServerWebExchange exchange) throws Exception {
        return MAPPER.readTree(exchange.getResponse().getBodyAsString().block());
    }

    @Test
    void disabledFlag_passesRequestsWithoutHeader() {
        UserIdRequiredWebFilter filter = new UserIdRequiredWebFilter(false, MAPPER);

        MockServerWebExchange api = exchange("/api/scenarios", null);
        assertTrue(passed(filter, api));
        assertNotEquals(HttpStatus.UNAUTHORIZED, api.getResponse().getStatusCode());
        assertTrue(passed(filter, exchange("/ws/scenario", null)));
        assertTrue(passed(filter, exchange("/api/scenarios", "anonymous")));
    }

    @Test
    void enabledFlag_missingHeader_returns401WithErrorResponse() throws Exception {
        UserIdRequiredWebFilter filter = new UserIdRequiredWebFilter(true, MAPPER);
        MockServerWebExchange exchange = exchange("/api/scenarios", null);

        assertFalse(passed(filter, exchange));

        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
        assertEquals(MediaType.APPLICATION_JSON, exchange.getResponse().getHeaders().getContentType());
        JsonNode body = body(exchange);
        assertEquals(401, body.path("statusCode").asInt());
        assertEquals("Unauthorized", body.path("error").asText());
        assertEquals("Отсутствует обязательный заголовок X-UserId", body.path("message").asText());
        assertTrue(body.hasNonNull("timestamp"));
        assertFalse(body.has("details"));
    }

    @Test
    void enabledFlag_webSocketHandshakeWithoutHeader_returns401() {
        UserIdRequiredWebFilter filter = new UserIdRequiredWebFilter(true, MAPPER);
        MockServerWebExchange exchange = exchange("/ws/chat", null);

        assertFalse(passed(filter, exchange));
        assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode());
    }

    @Test
    void enabledFlag_validHeader_passes() {
        UserIdRequiredWebFilter filter = new UserIdRequiredWebFilter(true, MAPPER);

        assertTrue(passed(filter, exchange("/api/scenarios", "ABC123")));
        assertTrue(passed(filter, exchange("/ws/scenario", "user_1-x")));
        assertTrue(passed(filter, exchange("/api/agent/lessons", "a".repeat(64))));
    }

    @Test
    void enabledFlag_invalidHeader_returns401() throws Exception {
        UserIdRequiredWebFilter filter = new UserIdRequiredWebFilter(true, MAPPER);

        for (String bad : new String[] {"anonymous", "ANONYMOUS", "", " ", "a b", "юзер", "a".repeat(65), "x;y"}) {
            MockServerWebExchange exchange = exchange("/api/scenarios", bad);
            assertFalse(passed(filter, exchange), "значение «" + bad + "»");
            assertEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode(), "значение «" + bad + "»");
            assertEquals("Недопустимое значение заголовка X-UserId", body(exchange).path("message").asText());
        }
    }

    @Test
    void enabledFlag_otherPathsUntouched() {
        UserIdRequiredWebFilter filter = new UserIdRequiredWebFilter(true, MAPPER);

        for (String path : new String[] {"/actuator/health", "/actuator/info", "/swagger-ui.html", "/sample-api-docs", "/", "/api", "/ws"}) {
            MockServerWebExchange exchange = exchange(path, null);
            assertTrue(passed(filter, exchange), path);
            assertNotEquals(HttpStatus.UNAUTHORIZED, exchange.getResponse().getStatusCode(), path);
        }
    }

    @Test
    void enabledFlag_pathIsTakenRelativeToBasePath() {
        UserIdRequiredWebFilter filter = new UserIdRequiredWebFilter(true, MAPPER);

        // spring.webflux.base-path: фильтр видит путь внутри приложения, без /gigame
        MockServerWebExchange api = MockServerWebExchange.from(
                MockServerHttpRequest.get("/gigame/api/scenarios").contextPath("/gigame").build());
        assertFalse(passed(filter, api));
        assertEquals(HttpStatus.UNAUTHORIZED, api.getResponse().getStatusCode());

        MockServerWebExchange health = MockServerWebExchange.from(
                MockServerHttpRequest.get("/gigame/actuator/health").contextPath("/gigame").build());
        assertTrue(passed(filter, health));
    }

    @Test
    void isValid_acceptsPatternAndRejectsAnonymousLiteral() {
        assertTrue(UserIdRequiredWebFilter.isValid("U1"));
        assertTrue(UserIdRequiredWebFilter.isValid("user-name_01"));
        assertFalse(UserIdRequiredWebFilter.isValid(null));
        assertFalse(UserIdRequiredWebFilter.isValid(""));
        assertFalse(UserIdRequiredWebFilter.isValid("anonymous"));
        assertFalse(UserIdRequiredWebFilter.isValid("Anonymous"));
        assertFalse(UserIdRequiredWebFilter.isValid("a.b"));
        assertFalse(UserIdRequiredWebFilter.isValid("a".repeat(65)));
    }
}
