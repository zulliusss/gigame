package ru.sber.cs.ai.gigame.service.annotate;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import ru.sber.cs.ai.gigame.service.TestPdf;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Сборка ZIP размеченных документов по строкам заключения: выбор документа, склад исходников, отчёт.
 */
class DocumentAnnotationServiceTest {

    private static final String QUOTE = "гарантия отсутствия действующих договоров с другими банками";
    private static final String RULES = "{\"колонки\": [{\"ключ\": \"з2\", \"заголовок\": \"Выявленный риск\"},"
            + " {\"ключ\": \"з6\", \"заголовок\": \"Рекомендации\"}], \"разметка_документов\": {}}";

    @TempDir
    Path temp;

    private static byte[] docx(String text) throws IOException {
        try (XWPFDocument doc = new XWPFDocument()) {
            doc.createParagraph().createRun().setText(text);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.write(out);
            return out.toByteArray();
        }
    }

    private static byte[] xlsx(String text) throws IOException {
        try (XSSFWorkbook book = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            book.createSheet("КП").createRow(0).createCell(0).setCellValue(text);
            book.write(out);
            return out.toByteArray();
        }
    }

    private static Map<String, Object> row(String level, String risk, String document, String quote) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("з1", "1");
        row.put("з2", risk);
        row.put("з3", document);
        row.put("з4", level);
        row.put("з6", "Исключить требование");
        row.put("з8", quote);
        return row;
    }

    private static Map<String, byte[]> unzip(byte[] zip) throws IOException {
        Map<String, byte[]> entries = new LinkedHashMap<>();
        try (ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(zip))) {
            for (ZipEntry entry = in.getNextEntry(); entry != null; entry = in.getNextEntry()) {
                entries.put(entry.getName(), in.readAllBytes());
            }
        }
        return entries;
    }

    @Test
    void buildsZipWithAnnotatedDocumentsAndReport() throws IOException {
        RawFileStore store = new RawFileStore(temp.toString(), 24);
        UUID key = UUID.randomUUID();
        String docxName = "комплект.zip/документация/Документация фин дат 1.docx";
        String docxText = "Требование №2: " + QUOTE + " на период работ.";
        String pdfText = "Total purchase amount: no more than 289 523 339,14 RUB.";
        store.save(key, docxName, docxText, docx(docxText));
        store.save(key, "ПЗ.pdf", pdfText, TestPdf.of(pdfText));
        String bookText = "Цена указана одной строкой без разбивки по позициям";
        store.save(key, "КП участника.xlsx", bookText, xlsx(bookText));
        store.save(key, "Смета.rtf", "смета", "смета".getBytes(StandardCharsets.UTF_8));
        Map<String, String> texts = Map.of(docxName, docxText,
                "ПЗ.pdf", pdfText,
                "КП участника.xlsx", bookText,
                "Смета.rtf", "смета");
        List<Map<String, Object>> rows = List.of(
                row("ПАСПОРТ", "Предмет закупки: контент", "—", "—"),
                row("ВЫСОКИЙ", "Требование о расторжении договоров с другими банками", "Документация фин дат 1.docx, раздел 2", QUOTE),
                row("СРЕДНИЙ", "Расхождение сумм НМЦ: 289523339.14 руб. в ПЗ против 288543415.67 руб. в извещении", "ПЗ.pdf", "без цитаты"),
                row("НИЗКИЙ", "Цена без разбивки", "КП участника.xlsx", bookText),
                row("НИЗКИЙ", "Смета не в том формате", "Смета.rtf", "смета одной строкой без расшифровки"),
                row("НИЗКИЙ", "Находка без документа", "неизвестный файл.docx", "этой фразы нет ни в одном документе"));

        byte[] zip = new DocumentAnnotationService(store).annotate(key, null, AnnotationConfig.parse(RULES), rows, texts);

        Map<String, byte[]> entries = unzip(zip);
        assertTrue(entries.containsKey("документация/Документация фин дат 1 — разметка GigaMe.docx"), String.valueOf(entries.keySet()));
        assertTrue(entries.containsKey("ПЗ — разметка GigaMe.pdf"));
        String report = new String(entries.get(DocumentAnnotationService.REPORT_ENTRY), StandardCharsets.UTF_8);
        assertTrue(report.contains("Документация фин дат 1.docx: отмечено находок 1 из 1"), report);
        assertTrue(report.contains("ПЗ.pdf: отмечено находок 1 из 1"), report);
        assertTrue(report.contains("КП участника.xlsx: отмечено находок 1 из 1"), report);
        assertTrue(entries.containsKey("КП участника — разметка GigaMe.xlsx"), String.valueOf(entries.keySet()));
        assertTrue(report.contains("Смета.rtf: формат не размечается"), report);
        assertTrue(report.contains("находка № 5: документ не определён — в «неизвестный файл.docx» нет имени"), report);
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(entries.get("документация/Документация фин дат 1 — разметка GigaMe.docx")))) {
            assertEquals(1, doc.getDocComments().getComments().size());
            assertTrue(doc.getDocComments().getComments().get(0).getText().contains("Рекомендации: Исключить требование"));
        }
    }

    @Test
    void missingOriginalIsReportedAndExcelIsMergedIntoDownloadZip() throws IOException {
        RawFileStore store = new RawFileStore(temp.toString(), 24);
        Map<String, String> texts = Map.of("ПЗ.docx", "Требование №2: " + QUOTE);

        byte[] zip = new DocumentAnnotationService(store).annotate(UUID.randomUUID(), UUID.randomUUID(),
                AnnotationConfig.parse(RULES), List.of(row("ВЫСОКИЙ", "Риск", "ПЗ.docx", QUOTE)), texts);
        byte[] download = DocumentAnnotationService.withExcel(zip, "xlsx-bytes".getBytes(StandardCharsets.UTF_8));

        Map<String, byte[]> entries = unzip(download);
        assertEquals("xlsx-bytes", new String(entries.get(DocumentAnnotationService.EXCEL_ENTRY), StandardCharsets.UTF_8));
        String report = new String(entries.get(DocumentAnnotationService.REPORT_ENTRY), StandardCharsets.UTF_8);
        assertTrue(report.contains("ПЗ.docx: исходный файл недоступен"), report);
    }

    @Test
    void sameNameDocumentsWithDifferentTextAreAnnotatedEach() throws IOException {
        // cache-10: два «Договор.docx» разных лотов — находки каждого попадают в свой оригинал
        RawFileStore store = new RawFileStore(temp.toString(), 24);
        UUID key = UUID.randomUUID();
        UUID run = UUID.randomUUID();
        String first = "Договор лота 1: " + QUOTE + " на период работ.";
        String second = "Договор лота 2: поставщик обязан застраховать груз на весь срок перевозки.";
        // догрузка второго лота: то же имя файла, другой текст — оба на складе, снимок прогона переживает очистку ключа
        store.save(key, "папка/Договор.docx", first, docx(first));
        store.save(key, "папка/Договор.docx", second, docx(second));
        store.snapshotForRun(key, run, null);
        store.clear(key);
        Map<String, String> texts = new LinkedHashMap<>();
        texts.put(DocumentAnnotationService.uniqueName(texts, "папка/Договор.docx"), first);
        texts.put(DocumentAnnotationService.uniqueName(texts, "папка/Договор.docx"), second);
        assertEquals(List.of("папка/Договор.docx", "папка/Договор (2).docx"), List.copyOf(texts.keySet()));
        List<Map<String, Object>> rows = List.of(
                row("ВЫСОКИЙ", "Расторжение договоров с другими банками", "Договор.docx", QUOTE),
                row("СРЕДНИЙ", "Страхование груза", "Договор.docx", "застраховать груз на весь срок перевозки"));

        byte[] zip = new DocumentAnnotationService(store).annotate(key, run, AnnotationConfig.parse(RULES), rows, texts);

        Map<String, byte[]> entries = unzip(zip);
        String report = new String(entries.get(DocumentAnnotationService.REPORT_ENTRY), StandardCharsets.UTF_8);
        assertTrue(entries.containsKey("папка/Договор — разметка GigaMe.docx"), report);
        assertTrue(entries.containsKey("папка/Договор (2) — разметка GigaMe.docx"), report);
        assertTrue(report.contains("папка/Договор.docx: отмечено находок 1 из 1"), report);
        assertTrue(report.contains("папка/Договор (2).docx: отмечено находок 1 из 1"), report);
        assertEquals("Договор.docx", DocumentAnnotationService.plainName("Договор (2).docx"));
        assertEquals("папка/Договор", DocumentAnnotationService.plainName("папка/Договор (3)"));
        assertEquals("Отчёт 2024.docx", DocumentAnnotationService.plainName("Отчёт 2024.docx"));
    }

    @Test
    void reportOnlyZipCarriesTheReason() throws IOException {
        Map<String, byte[]> entries = unzip(DocumentAnnotationService.reportOnly("разметка документов не выполнена: сбой"));

        assertEquals(List.of(DocumentAnnotationService.REPORT_ENTRY), List.copyOf(entries.keySet()));
        assertEquals("разметка документов не выполнена: сбой",
                new String(entries.get(DocumentAnnotationService.REPORT_ENTRY), StandardCharsets.UTF_8));
    }

    @Test
    void documentIsResolvedByFileNameOrByQuoteInText() {
        Map<String, String> texts = Map.of("папка/Документация.docx", "текст с цитатой про договоры с другими банками и прочее",
                "ПЗ.docx", "другой текст");
        Finding byName = new Finding(1, "Документация.docx, раздел 2", "нет такой цитаты нигде", "ВЫСОКИЙ", "к", List.of());
        Finding byText = new Finding(2, "—", "цитатой про договоры с другими банками", "ВЫСОКИЙ", "к", List.of());
        Finding nowhere = new Finding(3, "—", "фраза, которой нет", "ВЫСОКИЙ", "к", List.of());

        assertEquals("папка/Документация.docx", DocumentAnnotationService.resolveDocument(byName, texts));
        assertEquals("папка/Документация.docx", DocumentAnnotationService.resolveDocument(byText, texts));
        assertNull(DocumentAnnotationService.resolveDocument(nowhere, texts));
    }

    @Test
    void ocrPageHintComesFromPageMarkerBeforeQuote() {
        String text = "--- страница 1 ---\nшапка акта\n\n--- страница 2 ---\nВсего к оплате 1 234 567,89 руб.\n\n--- страница 3 ---\nподписи";
        Finding finding = new Finding(1, "акт.pdf", "Всего к оплате 1234567.89 руб", "СРЕДНИЙ", "к", List.of());

        assertEquals(2, DocumentAnnotationService.ocrPage(text, finding));
        assertNull(DocumentAnnotationService.ocrPage("текст без маркеров и цитаты", finding));
        assertNotNull(AnnotationConfig.parse(RULES));
        assertNull(AnnotationConfig.parse("{\"лист\": \"Заключение\"}"));
        assertEquals("папка/файл — разметка GigaMe.pdf", DocumentAnnotationService.entryName("архив.zip/папка/файл.pdf"));
    }
}
