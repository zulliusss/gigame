package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.config.JacksonConfig;
import ru.sber.cs.ai.gigame.model.AgentLesson;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты DTO урока агента: текст урока не длиннее maxLength 4000 схемы,
 * даты в UTC с микросекундами.
 */
class AgentLessonResponseDtoTest {

    private static AgentLesson lesson(String text) {
        AgentLesson lesson = new AgentLesson();
        lesson.setId(UUID.randomUUID());
        lesson.setScenarioId(UUID.randomUUID());
        lesson.setUserId("USER1");
        lesson.setLesson(text);
        lesson.setSource(AgentLesson.SOURCE_USER);
        lesson.setApproved(true);
        lesson.setCreatedAt(OffsetDateTime.of(2026, 9, 15, 13, 0, 0, 987_654_321, ZoneOffset.ofHours(3)));
        return lesson;
    }

    @Test
    void from_longLessonIsClippedToSchemaLimit() {
        AgentLessonResponseDto dto = AgentLessonResponseDto.from(lesson("у".repeat(4135)));

        assertEquals(AgentLessonResponseDto.LESSON_MAX_LENGTH, dto.lesson().length());
        assertTrue(dto.lesson().endsWith("…"));
    }

    @Test
    void from_shortLessonPassesUnchanged() {
        AgentLessonResponseDto dto = AgentLessonResponseDto.from(lesson("Суммы брать из УПД"));

        assertEquals("Суммы брать из УПД", dto.lesson());
    }

    @Test
    void serialization_createdAtIsUtcMicros() throws Exception {
        ObjectMapper mapper = new JacksonConfig().objectMapper();

        JsonNode json = mapper.readTree(mapper.writeValueAsString(AgentLessonResponseDto.from(lesson("урок"))));

        assertEquals("2026-09-15T10:00:00.987654Z", json.get("created_at").asText());
        assertEquals("USER1", json.get("user_id").asText());
    }

    @Test
    void serialization_userIdOutsideSchemaPatternIsOmitted() throws Exception {
        // запрос без X-UserId сохраняет урок с user_id «anonymous» — pattern ^[A-Z0-9]{0,16}$ его не пропускает
        ObjectMapper mapper = new JacksonConfig().objectMapper();
        AgentLesson anonymous = lesson("урок");
        anonymous.setUserId("anonymous");

        AgentLessonResponseDto dto = AgentLessonResponseDto.from(anonymous);

        assertNull(dto.userId());
        assertNull(mapper.readTree(mapper.writeValueAsString(dto)).get("user_id"));
        AgentLesson corporate = lesson("урок");
        corporate.setUserId("USER123");
        assertEquals("USER123", AgentLessonResponseDto.from(corporate).userId());
    }
}
