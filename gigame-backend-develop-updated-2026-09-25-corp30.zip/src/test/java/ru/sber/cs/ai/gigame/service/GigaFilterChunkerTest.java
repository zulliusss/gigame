package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Деление текста на фрагменты для GigaFilter: склейка фрагментов даёт исходный текст, размер не превышается,
 * границы задаёт содержимое — один и тот же документ после разных инструкций делится одинаково (кэш вердиктов
 * попадает), строка длиннее фрагмента режется по пробелу.
 */
class GigaFilterChunkerTest {

    private static final int SIZE = 4000;

    @Test
    void shortTextIsOneChunkAndEmptyTextHasNone() {
        assertEquals(List.of(new GigaFilterChunker.Chunk(0, "Срок оказания услуг: 45 дней.")),
                GigaFilterChunker.chunks("Срок оказания услуг: 45 дней.", SIZE));
        assertTrue(GigaFilterChunker.chunks("", SIZE).isEmpty());
        assertTrue(GigaFilterChunker.chunks(null, SIZE).isEmpty());
    }

    @Test
    void chunksCoverTextInOrderAndRespectSize() {
        String text = document(900);

        List<GigaFilterChunker.Chunk> chunks = GigaFilterChunker.chunks(text, SIZE);

        StringBuilder joined = new StringBuilder();
        for (GigaFilterChunker.Chunk chunk : chunks) {
            assertEquals(joined.length(), chunk.start());
            assertTrue(chunk.text().length() <= SIZE, "фрагмент " + chunk.text().length());
            joined.append(chunk.text());
        }
        assertEquals(text, joined.toString());
        assertTrue(chunks.size() >= text.length() / SIZE, "фрагментов " + chunks.size());
        // фрагменты не мельчат: в среднем не меньше половины размера
        assertTrue(text.length() / chunks.size() >= SIZE / 2, "средний фрагмент " + text.length() / chunks.size());
    }

    @Test
    void sameDocumentAfterDifferentInstructionsGivesSameChunks() {
        String document = document(900);
        String first = "Ты — аналитик закупок. Извлеки критерии оценки и верни JSON-массив.\n\nДокументы:\n" + document;
        String second = ("Проверь документацию на соответствие 223-ФЗ: сроки, обеспечение, критерии, квалификационные "
                + "требования, порядок оценки заявок; по каждому нарушению укажи пункт документа.\n").repeat(7)
                + "\nДокументы:\n" + document;

        Set<String> firstTexts = new HashSet<>();
        GigaFilterChunker.chunks(first, SIZE).forEach(chunk -> firstTexts.add(chunk.text()));
        List<GigaFilterChunker.Chunk> secondChunks = GigaFilterChunker.chunks(second, SIZE);
        int inDocument = 0;
        int shared = 0;
        for (GigaFilterChunker.Chunk chunk : secondChunks) {
            if (chunk.start() >= second.length() - document.length()) {
                inDocument++;
                shared += firstTexts.contains(chunk.text()) ? 1 : 0;
            }
        }

        assertTrue(inDocument >= 20, "фрагментов документа " + inDocument);
        // расходятся только фрагменты до первой общей границы
        assertTrue(shared >= inDocument - 3, "совпало " + shared + " из " + inDocument);
    }

    @Test
    void documentAndPageStartsBeginNewChunk() {
        String first = "<<<Документ: ТЗ.docx>>>\n" + "Пункт технического задания.\n".repeat(30) + "<<<КОНЕЦ ДОКУМЕНТА>>>\n\n";
        String second = "<<<Документ: Договор.docx>>>\n--- страница 1 ---\n" + "Статья договора.\n".repeat(40)
                + "--- страница 2 ---\n" + "Статья договора.\n".repeat(10);

        List<GigaFilterChunker.Chunk> chunks = GigaFilterChunker.chunks(first + second, SIZE);

        assertEquals(first.length(), chunks.get(1).start(), "новый документ — новый фрагмент");
        assertTrue(chunks.stream().anyMatch(chunk -> chunk.text().startsWith("--- страница 2 ---")));
        // короткий заголовок перед документом (меньше 1/8 фрагмента) не отделяется
        assertEquals(1, GigaFilterChunker.chunks("Документы:\n<<<Документ: ТЗ.docx>>>\nтекст\n", SIZE).size());
    }

    @Test
    void lineLongerThanChunkIsCutAtSpace() {
        String line = "слово ".repeat(2000);

        List<GigaFilterChunker.Chunk> chunks = GigaFilterChunker.chunks(line, SIZE);

        assertTrue(chunks.size() >= 3);
        for (int i = 0; i < chunks.size() - 1; i++) {
            assertTrue(chunks.get(i).text().length() <= SIZE);
            assertTrue(chunks.get(i).text().endsWith(" "), "разрез не по пробелу: " + i);
        }
        assertEquals(GigaFilterChunker.MIN_SIZE, GigaFilterChunker.chunks("x".repeat(500), 10).get(0).text().length());
    }

    /** Документ из строк разной длины: пункты ТЗ с номерами и абзацы. */
    private static String document(int lines) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= lines; i++) {
            sb.append("п.").append(i / 10 + 1).append('.').append(i % 10).append(' ')
                    .append("Исполнитель обязан обеспечить ".repeat(1 + i % 4))
                    .append("выполнение работ по объекту № ").append(i * 37 % 1000).append(".\n");
            if (i % 17 == 0) {
                sb.append('\n');
            }
        }
        return sb.toString();
    }
}
