package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Prompt;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Тесты базы промптов: атомарный инкремент счётчика использований.
 */
@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class PromptRepositoryTest {

    @Autowired
    private PromptRepository promptRepository;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    void incrementUsageCount_addsOneInDatabase() {
        // corp17 (P5): инкремент одним UPDATE, без чтения-изменения-записи сущности
        Prompt prompt = new Prompt();
        prompt.setTitle("Промпт");
        prompt.setText("текст");
        prompt.setUserId("U");
        UUID id = promptRepository.saveAndFlush(prompt).getId();

        assertEquals(1, promptRepository.incrementUsageCount(id));
        assertEquals(1, promptRepository.incrementUsageCount(id));
        assertEquals(0, promptRepository.incrementUsageCount(UUID.randomUUID()));

        // сущность в контексте персистентности устарела — читаем из БД заново
        entityManager.clear();
        assertEquals(2, promptRepository.findById(id).orElseThrow().getUsageCount());
    }
}
