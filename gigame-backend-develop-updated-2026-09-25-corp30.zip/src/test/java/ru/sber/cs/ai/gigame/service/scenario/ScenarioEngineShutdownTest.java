package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioEventType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

/**
 * Graceful-остановка сервиса: закрытие контекста останавливает активные и ожидающие прогоны с причиной
 * «прерван перезапуском», прогоны получают FAILED, а {@code shutdown()} дожидается их завершения.
 */
class ScenarioEngineShutdownTest {

    private static final String USER = "USER1";

    private final ScenarioRunService runService = Mockito.mock(ScenarioRunService.class);

    private final ScenarioRunStepService stepService = Mockito.mock(ScenarioRunStepService.class);

    private final ScenarioExecutorFactory executorFactory = Mockito.mock(ScenarioExecutorFactory.class);

    private final Map<UUID, Consumer<ScenarioRunNode>> nodeBodies = new ConcurrentHashMap<>();

    private final List<ScenarioEngine> engines = new ArrayList<>();

    @AfterEach
    void tearDown() {
        engines.forEach(ScenarioEngine::shutdown);
    }

    @Test
    void contextClosed_cancelsActiveRunWithRestartReason_andShutdownWaitsForIt() {
        ScenarioEngine engine = engine();
        ScenarioRun run = run();
        CountDownLatch started = new CountDownLatch(1);
        nodeBodies.put(run.getId(), node -> {
            started.countDown();
            spinUntilCancelled(node.getGraph());
        });
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();

        CountDownLatch done = subscribe(engine.executeScenario(run, twoNodeGraph(), USER), events);
        assertTrue(awaitLatch(started, 30), "узел не начал выполнение");
        engine.onContextClosed();

        assertTrue(awaitLatch(done, 20), "прогон не завершился после остановки сервиса");
        Map<String, Object> last = events.get(events.size() - 1).data();
        assertEquals(ScenarioEventType.STATUS, last.get("type"));
        assertEquals(ScenarioStatus.FAILED, last.get("status"));
        assertTrue(events.stream().anyMatch(event -> ScenarioEventType.NODE_STATUS.equals(event.data().get("type"))
                        && String.valueOf(event.data().get("error")).contains(ScenarioEngine.RESTART_REASON)),
                "ошибка узла должна быть «прерван перезапуском», события: " + events);
        Mockito.verify(runService).setScenarioRunStatusFailed(run);
        long start = System.nanoTime();
        engine.shutdown();
        assertTrue((System.nanoTime() - start) / 1_000_000 < 5_000, "пул завершённых прогонов останавливается сразу");
    }

    @Test
    void shutdown_cancelsQueuedRunWithRestartReason_withoutExecutingItsNodes() {
        ScenarioEngine engine = engine();
        ScenarioRun active = run();
        CountDownLatch started = new CountDownLatch(1);
        nodeBodies.put(active.getId(), node -> {
            started.countDown();
            spinUntilCancelled(node.getGraph());
        });
        ScenarioRun queued = run();
        nodeBodies.put(queued.getId(), node -> {
            throw new IllegalStateException("узел прогона, остановленного в очереди, выполняться не должен");
        });
        List<ServerSentEvent<Map<String, Object>>> activeEvents = new CopyOnWriteArrayList<>();
        List<ServerSentEvent<Map<String, Object>>> queuedEvents = new CopyOnWriteArrayList<>();

        CountDownLatch activeDone = subscribe(engine.executeScenario(active, twoNodeGraph(), USER), activeEvents);
        assertTrue(awaitLatch(started, 30), "активный прогон не стартовал");
        CountDownLatch queuedDone = subscribe(engine.executeScenario(queued, twoNodeGraph(), USER), queuedEvents);
        assertTrue(awaitUntil(() -> !queuedEvents.isEmpty()), "событие приёма прогона в очередь не пришло");

        engine.shutdown();

        assertTrue(awaitLatch(activeDone, 20), "активный прогон не завершился");
        assertTrue(awaitLatch(queuedDone, 20), "прогон из очереди не завершился");
        assertEquals(ScenarioStatus.FAILED, queuedEvents.get(queuedEvents.size() - 1).data().get("status"));
        assertFalse(queuedEvents.stream().anyMatch(event -> ScenarioEventType.NODE_STATUS.equals(event.data().get("type"))),
                "узлы прогона, остановленного в очереди, не выполняются");
        Mockito.verify(runService).setScenarioRunStatusFailed(queued);
        Mockito.verify(runService, Mockito.never()).setScenarioRunStatusRunning(queued);
        Mockito.verify(runService).setScenarioRunStatusFailed(active);
    }

    @Test
    void firstCancelReasonWins() {
        ScenarioRunGraph graph = new ScenarioRunGraph(twoNodeGraph());

        graph.requestCancel(ScenarioEngine.RESTART_REASON);
        graph.requestCancel();

        assertTrue(graph.isCancelRequested());
        assertEquals(ScenarioEngine.RESTART_REASON, graph.getCancelReason());
        assertEquals(ScenarioRunGraph.CANCELLED_BY_USER, new ScenarioRunGraph(twoNodeGraph()).getCancelReason());
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Долгий узел: ждёт остановки и проверяет её флаг, как это делают циклы по документам и группам —
     * прогон падает ошибкой узла с причиной остановки.
     */
    private static void spinUntilCancelled(ScenarioRunGraph graph) {
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(30);
        while (!graph.isCancelRequested() && System.nanoTime() < deadline) {
            Thread.onSpinWait();
        }
        graph.checkNotCancelled();
    }

    private ScenarioEngine engine() {
        Mockito.lenient().when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class)))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class)))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any()))
                .thenAnswer(inv -> step());
        Mockito.lenient().when(stepService.setScenarioStepStatusCompleted(any(), any(), any(), any(), any(), any(), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(stepService.setScenarioStepStatusFailed(any(), anyString()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenAnswer(inv -> nodeExecutor(inv.getArgument(0)));
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                Mockito.mock(DocsTextCacheService.class), Mockito.mock(ScenarioRepository.class),
                Mockito.mock(ScenarioOutputSupportService.class), 1);
        ReflectionTestUtils.setField(engine, "parallelEnabled", false);
        ReflectionTestUtils.setField(engine, "shutdownWaitSeconds", 15L);
        engines.add(engine);
        return engine;
    }

    private AbstractScenarioExecutor nodeExecutor(ScenarioRunNode node) {
        return new AbstractScenarioExecutor(node) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                Consumer<ScenarioRunNode> body = nodeBodies.get(node.getGraph().getRunId());
                if (body != null && node.getType() == ScenarioNodeType.INPUT_NODE) {
                    body.accept(node);
                }
                for (var next : node.getChildNodeList()) {
                    next.setSkip(false);
                }
                return "результат " + node.getId();
            }

            @Override
            public String getPrompt() {
                return "";
            }
        };
    }

    private static CountDownLatch subscribe(Flux<ServerSentEvent<Map<String, Object>>> flux,
                                            List<ServerSentEvent<Map<String, Object>>> events) {
        CountDownLatch done = new CountDownLatch(1);
        flux.subscribe(events::add, error -> done.countDown(), done::countDown);
        return done;
    }

    private static ScenarioRun run() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(UUID.randomUUID());
        run.setStatus("running");
        return run;
    }

    private static ScenarioRunStep step() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setNodeId("node-1");
        step.setStatus("running");
        return step;
    }

    private static NodeDto node(String id, ScenarioNodeType type) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(id).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static GraphDataDto twoNodeGraph() {
        return new GraphDataDto(List.of(node("node-1", ScenarioNodeType.INPUT_NODE), node("node-2", ScenarioNodeType.OUTPUT_NODE)),
                List.of(new EdgeDto("e1", "node-1", "node-2", new EdgeDataDto(null))));
    }

    private static boolean awaitLatch(CountDownLatch latch, int seconds) {
        try {
            return latch.await(seconds, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    private static boolean awaitUntil(java.util.function.BooleanSupplier condition) {
        long deadline = System.currentTimeMillis() + 10_000;
        while (System.currentTimeMillis() < deadline) {
            if (condition.getAsBoolean()) {
                return true;
            }
            Thread.onSpinWait();
        }
        return condition.getAsBoolean();
    }
}
