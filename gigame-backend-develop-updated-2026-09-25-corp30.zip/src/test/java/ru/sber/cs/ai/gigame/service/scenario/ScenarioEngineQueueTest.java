package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.MapPropertySource;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioEventType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

/**
 * Очередь пула прогонов: снимок документов при приёме команды, видимость
 * прогона в очереди (run_id и запись журнала), остановка до старта,
 * сохранение пошагового режима и размер пула из настройки.
 */
class ScenarioEngineQueueTest {

    private static final String USER = "USER1";

    private final ScenarioRunService runService = Mockito.mock(ScenarioRunService.class);

    private final ScenarioRunStepService stepService = Mockito.mock(ScenarioRunStepService.class);

    private final ScenarioExecutorFactory executorFactory = Mockito.mock(ScenarioExecutorFactory.class);

    /**
     * Тела узлов по прогонам: у каждого прогона своё поведение исполнителя.
     */
    private final Map<UUID, Consumer<ScenarioRunNode>> nodeBodies = new ConcurrentHashMap<>();

    private final List<ScenarioEngine> engines = new ArrayList<>();

    @AfterEach
    void tearDown() {
        engines.forEach(ScenarioEngine::shutdown);
    }

    // -------------------------------------------------------------------------
    // A. Снимок документов в момент приёма команды
    // -------------------------------------------------------------------------

    @Test
    void queuedRun_keepsDocumentsUploadedBeforeCommand_whenNewUploadReplacesCache() {
        DocsTextCacheService cache = new DocsTextCacheService();
        UUID scenarioId = UUID.randomUUID();
        UUID docsKey = DocsTextCacheService.scenarioKey(scenarioId, USER);
        cache.cacheDocumentTexts(docsKey, List.of("текст партии 1"), List.of("партия-1.pdf"), List.of());
        ScenarioEngine engine = engine(cache, 1);
        CountDownLatch release = new CountDownLatch(1);
        startBlockingRun(engine, release);
        ScenarioRun queued = run(scenarioId);
        List<String> seen = new CopyOnWriteArrayList<>();
        nodeBodies.put(queued.getId(), node -> node.getGraph().getDocMap().values()
                .forEach(doc -> seen.add(doc.getFilename())));

        CountDownLatch done = subscribe(engine.executeScenario(queued, twoNodeGraph(), USER), new CopyOnWriteArrayList<>());
        // вторая вкладка того же пользователя грузит другой комплект, пока прогон ждёт в очереди
        cache.clearCache(docsKey);
        cache.cacheDocumentTexts(docsKey, List.of("текст партии 2"), List.of("партия-2.pdf"), List.of());
        release.countDown();

        assertTrue(awaitLatch(done), "прогон из очереди не завершился");
        assertEquals(List.of("партия-1.pdf"), List.copyOf(seen));
    }

    @Test
    void queuedRun_keepsDocuments_whenCacheEntryExpiresByTtl() {
        DocsTextCacheService cache = new DocsTextCacheService();
        ReflectionTestUtils.setField(cache, "ttlMinutes", 0);
        UUID scenarioId = UUID.randomUUID();
        UUID docsKey = DocsTextCacheService.scenarioKey(scenarioId, USER);
        cache.cacheDocumentTexts(docsKey, List.of("текст комплекта"), List.of("комплект.pdf"), List.of());
        ScenarioEngine engine = engine(cache, 1);
        CountDownLatch release = new CountDownLatch(1);
        startBlockingRun(engine, release);
        ScenarioRun queued = run(scenarioId);
        List<String> seen = new CopyOnWriteArrayList<>();
        nodeBodies.put(queued.getId(), node -> node.getGraph().getDocMap().values()
                .forEach(doc -> seen.add(doc.getFilename())));

        CountDownLatch done = subscribe(engine.executeScenario(queued, twoNodeGraph(), USER), new CopyOnWriteArrayList<>());
        // ожидание в очереди дольше TTL: запись кэша вычищается фоновой задачей
        cache.evictStaleEntries();
        release.countDown();

        assertTrue(awaitLatch(done), "прогон из очереди не завершился");
        assertTrue(cache.getCachedDocumentTexts(docsKey).isEmpty());
        assertEquals(List.of("комплект.pdf"), List.copyOf(seen));
    }

    // -------------------------------------------------------------------------
    // B. Видимость прогона в очереди и остановка до старта
    // -------------------------------------------------------------------------

    @Test
    void acceptedRun_emitsRunIdAndQueuePositionBeforeStart() {
        ScenarioEngine engine = engine(Mockito.mock(DocsTextCacheService.class), 1);
        CountDownLatch release = new CountDownLatch(1);
        startBlockingRun(engine, release);
        ScenarioRun queued = run(UUID.randomUUID());
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();

        CountDownLatch done = subscribe(engine.executeScenario(queued, twoNodeGraph(), USER), events);

        assertTrue(awaitUntil(() -> events.size() >= 2), "события приёма прогона не пришли до старта");
        Map<String, Object> status = events.get(0).data();
        assertEquals(ScenarioEventType.STATUS, status.get("type"));
        assertEquals(queued.getId().toString(), status.get("run_id"));
        assertEquals(ScenarioStatus.RUNNING, status.get("status"));
        assertEquals(0, status.get("queue_ahead"));
        Map<String, Object> notice = events.get(1).data();
        assertEquals(ScenarioEventType.PROCESSING_PROGRESS, notice.get("type"));
        assertEquals(queued.getId().toString(), notice.get("run_id"));
        assertEquals("В очереди", notice.get("node_label"));
        assertTrue(String.valueOf(notice.get("detail")).contains("перед вами 0 прогон(ов), выполняется 1 из 1"));
        release.countDown();
        assertTrue(awaitLatch(done), "прогон из очереди не завершился");
    }

    @Test
    void runWithFreePool_emitsRunIdWithoutQueueNotice() {
        ScenarioEngine engine = engine(Mockito.mock(DocsTextCacheService.class), 2);
        ScenarioRun run = run(UUID.randomUUID());
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();

        CountDownLatch done = subscribe(engine.executeScenario(run, twoNodeGraph(), USER), events);

        assertTrue(awaitLatch(done), "прогон не завершился");
        assertEquals(ScenarioEventType.STATUS, events.get(0).data().get("type"));
        assertEquals(run.getId().toString(), events.get(0).data().get("run_id"));
        assertFalse(events.stream().anyMatch(event -> "В очереди".equals(event.data().get("node_label"))),
                "при свободном пуле записи об очереди быть не должно");
    }

    @Test
    void cancelOfQueuedRun_finishesRunAsFailedWithoutExecutingNodes() {
        ScenarioEngine engine = engine(Mockito.mock(DocsTextCacheService.class), 1);
        CountDownLatch release = new CountDownLatch(1);
        startBlockingRun(engine, release);
        ScenarioRun queued = run(UUID.randomUUID());
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();
        nodeBodies.put(queued.getId(), node -> {
            throw new IllegalStateException("узел остановленного прогона выполняться не должен");
        });

        CountDownLatch done = subscribe(engine.executeScenario(queued, twoNodeGraph(), USER), events);
        assertTrue(awaitUntil(() -> !events.isEmpty()), "событие приёма прогона не пришло");
        assertTrue(engine.requestCancel(queued.getId().toString()), "остановка прогона из очереди не принята");
        release.countDown();

        assertTrue(awaitLatch(done), "остановленный прогон не завершился");
        Map<String, Object> last = events.get(events.size() - 1).data();
        assertEquals(ScenarioEventType.STATUS, last.get("type"));
        assertEquals(ScenarioStatus.FAILED, last.get("status"));
        assertFalse(events.stream().anyMatch(event -> ScenarioEventType.NODE_STATUS.equals(event.data().get("type"))),
                "узлы остановленного в очереди прогона не выполняются");
        Mockito.verify(runService).setScenarioRunStatusFailed(queued);
        Mockito.verify(runService, Mockito.never()).setScenarioRunStatusRunning(queued);
    }

    // -------------------------------------------------------------------------
    // C. Пошаговый режим прогона, ждущего в очереди
    // -------------------------------------------------------------------------

    @Test
    @SuppressWarnings("unchecked")
    void stepModeOfQueuedRun_survivesEvictionOfStaleRuns() {
        ScenarioEngine engine = engine(Mockito.mock(DocsTextCacheService.class), 1);
        CountDownLatch release = new CountDownLatch(1);
        startBlockingRun(engine, release);
        ScenarioRun queued = run(UUID.randomUUID());
        String runId = queued.getId().toString();
        engine.enableStepMode(runId);
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();

        CountDownLatch done = subscribe(engine.executeScenario(queued, twoNodeGraph(), USER), events);
        assertTrue(awaitUntil(() -> !events.isEmpty()), "событие приёма прогона не пришло");
        // прогон ждёт в очереди дольше порога вычистки состояния
        var timestamps = (Map<String, Long>) ReflectionTestUtils.getField(engine, "runTimestamps");
        timestamps.put(runId, System.currentTimeMillis() - TimeUnit.MINUTES.toMillis(20));
        engine.evictStaleRuns();

        var stepModeEnabled = (Set<String>) ReflectionTestUtils.getField(engine, "stepModeEnabled");
        assertTrue(stepModeEnabled.contains(runId), "пошаговый режим прогона из очереди снят");
        assertTrue(timestamps.containsKey(runId), "отметка времени прогона из очереди вычищена");
        release.countDown();
        assertTrue(awaitUntil(() -> events.stream()
                        .anyMatch(event -> ScenarioEventType.STEP_PAUSED.equals(event.data().get("type")))),
                "прогон из очереди не встал на паузу пошагового режима");
        engine.disableStepMode(runId);
        assertTrue(awaitLatch(done), "прогон не завершился после отключения пошагового режима");
    }

    @Test
    @SuppressWarnings("unchecked")
    void cleanupRun_completesPauseFuture() {
        ScenarioEngine engine = engine(Mockito.mock(DocsTextCacheService.class), 1);
        String runId = UUID.randomUUID().toString();
        var stepEvents = (Map<String, CompletableFuture<Void>>) ReflectionTestUtils.getField(engine, "stepEvents");
        CompletableFuture<Void> pause = new CompletableFuture<>();
        stepEvents.put(runId, pause);

        engine.cleanupRun(runId);

        assertTrue(pause.isDone(), "пауза пошагового режима осталась незавершённой");
        assertFalse(stepEvents.containsKey(runId));
    }

    // -------------------------------------------------------------------------
    // D. Размер пула прогонов из настройки
    // -------------------------------------------------------------------------

    @Test
    void runThreads_fromSettings_sizePoolAndShutdownStopsIt() {
        ScenarioEngine engine = engine(Mockito.mock(DocsTextCacheService.class), 3);

        assertEquals(3, pool(engine).getMaximumPoolSize());

        engine.shutdown();
        assertTrue(pool(engine).isShutdown(), "пул прогонов не остановлен");
    }

    @Test
    void runThreads_belowOne_fallsBackToSingleThread() {
        assertEquals(1, pool(engine(Mockito.mock(DocsTextCacheService.class), 0)).getMaximumPoolSize());
    }

    @Test
    void runThreads_property_isWiredBySpringAndPoolClosedOnShutdown() {
        // имя настройки и закрытие пула проверяются через контекст Spring:
        // @Value на конструкторе читает app.scenario.run-threads, @PreDestroy останавливает пул
        ThreadPoolExecutor pool;
        try (var context = new AnnotationConfigApplicationContext()) {
            context.getEnvironment().getPropertySources().addFirst(
                    new MapPropertySource("тест", Map.of("app.scenario.run-threads", "4")));
            context.registerBean(PropertySourcesPlaceholderConfigurer.class);
            context.registerBean(ScenarioRunService.class, () -> runService);
            context.registerBean(ScenarioRunStepService.class, () -> stepService);
            context.registerBean(ScenarioExecutorFactory.class, () -> executorFactory);
            context.registerBean(DocsTextCacheService.class, () -> Mockito.mock(DocsTextCacheService.class));
            context.registerBean(ScenarioRepository.class, () -> Mockito.mock(ScenarioRepository.class));
            context.registerBean(ScenarioOutputSupportService.class,
                    () -> Mockito.mock(ScenarioOutputSupportService.class));
            context.registerBean(ScenarioEngine.class);
            context.refresh();
            pool = pool(context.getBean(ScenarioEngine.class));
            assertEquals(4, pool.getMaximumPoolSize());
        }

        assertTrue(pool.isShutdown(), "пул прогонов не остановлен при закрытии контекста");
    }

    @Test
    void engineWithoutSettings_usesDefaultPool() {
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                Mockito.mock(DocsTextCacheService.class), Mockito.mock(ScenarioRepository.class),
                Mockito.mock(ScenarioOutputSupportService.class));
        engines.add(engine);

        assertEquals(2, pool(engine).getMaximumPoolSize());
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Движок с заглушками БД: узлы выполняют тело из {@link #nodeBodies} по прогону.
     *
     * @param cache   кэш документов
     * @param threads число потоков пула прогонов
     * @return движок (останавливается после теста)
     */
    private ScenarioEngine engine(DocsTextCacheService cache, int threads) {
        Mockito.lenient().when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class)))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class)))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any()))
                .thenAnswer(inv -> step());
        Mockito.lenient().when(stepService.setScenarioStepStatusCompleted(any(), any(), any(), any(), any(), any(), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(stepService.setScenarioStepStatusFailed(any(), anyString()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenAnswer(inv -> nodeExecutor(inv.getArgument(0)));
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cache,
                Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class), threads);
        engines.add(engine);
        return engine;
    }

    /**
     * Прогон, занимающий поток пула до открытия защёлки.
     *
     * @param engine  движок
     * @param release защёлка освобождения потока
     * @return занявший поток прогон
     */
    private ScenarioRun startBlockingRun(ScenarioEngine engine, CountDownLatch release) {
        ScenarioRun busy = run(UUID.randomUUID());
        busy.setStatus("busy");
        CountDownLatch started = new CountDownLatch(1);
        nodeBodies.put(busy.getId(), node -> {
            started.countDown();
            awaitLatch(release);
        });
        subscribe(engine.executeScenario(busy, twoNodeGraph(), USER), new CopyOnWriteArrayList<>());
        assertTrue(awaitLatch(started), "прогон не занял поток пула");
        return busy;
    }

    /**
     * Исполнитель узла: выполняет тело своего прогона и возвращает результат.
     *
     * @param node узел прогона
     * @return исполнитель узла
     */
    private AbstractScenarioExecutor nodeExecutor(ScenarioRunNode node) {
        return new AbstractScenarioExecutor(node) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                Consumer<ScenarioRunNode> body = nodeBodies.get(node.getGraph().getRunId());
                if (body != null) {
                    body.accept(node);
                }
                return "результат " + node.getId();
            }

            @Override
            public String getPrompt() {
                return "";
            }
        };
    }

    /**
     * Подписка на поток событий прогона.
     *
     * @param flux   поток событий
     * @param events список, куда складываются события
     * @return защёлка завершения прогона
     */
    private static CountDownLatch subscribe(Flux<ServerSentEvent<Map<String, Object>>> flux,
                                            List<ServerSentEvent<Map<String, Object>>> events) {
        CountDownLatch done = new CountDownLatch(1);
        flux.subscribe(events::add, error -> done.countDown(), done::countDown);
        return done;
    }

    private static ThreadPoolExecutor pool(ScenarioEngine engine) {
        return (ThreadPoolExecutor) ReflectionTestUtils.getField(engine, "executor");
    }

    private static ScenarioRun run(UUID scenarioId) {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("running");
        return run;
    }

    private static ScenarioRunStep step() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setNodeId("node-1");
        step.setStatus("running");
        return step;
    }

    private static GraphDataDto twoNodeGraph() {
        NodeDto input = NodeDto.builder()
                .id("node-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Вход").build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto output = NodeDto.builder()
                .id("node-2")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Выход").build())
                .position(new PositionDto(200, 100))
                .build();
        return new GraphDataDto(List.of(input, output),
                List.of(new EdgeDto("e1", "node-1", "node-2", new EdgeDataDto(null))));
    }

    private static boolean awaitLatch(CountDownLatch latch) {
        try {
            return latch.await(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    /**
     * Ждёт выполнения условия коротким поллингом (события приходят из потоков пула).
     *
     * @param condition проверяемое условие
     * @return {@code true}, если условие выполнилось за отведённое время
     */
    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    private static boolean awaitUntil(BooleanSupplier condition) {
        for (int i = 0; i < 600; i++) {
            if (condition.getAsBoolean()) {
                return true;
            }
            if (!sleepShort()) {
                return false;
            }
        }
        return condition.getAsBoolean();
    }

    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    private static boolean sleepShort() {
        try {
            Thread.sleep(50);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }
}
