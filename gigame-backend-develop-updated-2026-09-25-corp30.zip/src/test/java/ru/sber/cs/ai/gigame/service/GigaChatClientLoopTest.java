package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.metadata.ChatGenerationMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Зацикливание модели при дочитывании усечённого ответа (Д1, регресс 16.09.2026): Субботин, узел s4 — поле «объем»
 * «10 шт.; 10 шт.; …» до лимита длины, 4 дочитывания, 14,5 мин. Хвост усечённого ответа проверяется перед каждым
 * дочитыванием; законные повторы (таблицы «| Да | Нет |», перечни находок, технологии лотов) детектор не трогает.
 */
@ExtendWith(MockitoExtension.class)
class GigaChatClientLoopTest {

    /** Начало реального первого ответа s4 Субботина: шапка JSON и зациклившееся поле «объем». */
    private static final String S4_HEAD = "regress/kom-v4-subbotin-lot3-s4-head.txt";

    @Mock
    private ChatModel chatModel;
    @Mock
    private EmbeddingModel embeddingModel;

    private GigaChatClient client;
    private final List<String> notices = new ArrayList<>();

    @BeforeEach
    void setUp() {
        client = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 1);
        ReflectionTestUtils.setField(client, "retryDelayMillis", 1L);
        ReflectionTestUtils.setField(client, "callHardTimeoutSeconds", 0L);
        GigaChatClient.setRunWaitNotice(notices::add);
    }

    @AfterEach
    void tearDown() {
        GigaChatClient.clearRunWaitNotice();
    }

    @Test
    void loopedAnswerOfSubbotinS4IsNotContinuedAndRepeatIsCut() throws IOException {
        String head = resource(S4_HEAD);
        when(chatModel.call(any(Prompt.class))).thenReturn(response(head, "length"));

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", "извлеки условия договора")), null, null);

        verify(chatModel, times(1)).call(any(Prompt.class));
        assertTrue(text.endsWith("\n" + GigaChatClient.LOOP_MARKER), text);
        assertFalse(text.contains(GigaChatClient.TRUNCATED_MARKER), text);
        String kept = text.substring(0, text.length() - GigaChatClient.LOOP_MARKER.length() - 1);
        // шапка JSON до зацикливания сохранена, повтор — не больше нескольких вхождений
        assertTrue(kept.contains("\"срок_поставки_до\": \"не указано\",\n\"объем\": \"100 шт.; 100 шт.; 100 м.;"), kept);
        assertTrue(kept.endsWith("300 шт.; 10 шт.; 20 шт.; 20 шт.; 10 шт.; 10 шт.; 10 шт.; "), kept);
        assertTrue(kept.length() < head.length() - 2000, "обрезано " + (head.length() - kept.length()));
        assertEquals(1, notices.size());
        assertTrue(notices.get(0).startsWith("⚠ ответ модели зациклился: «10 шт.;» повторено"), notices.get(0));
    }

    @Test
    void loopAppearingInContinuationStopsFurtherContinuations() throws IOException {
        String head = resource(S4_HEAD);
        int loopStart = head.indexOf("10 шт.; 10 шт.; 10 шт.;");
        when(chatModel.call(any(Prompt.class)))
                .thenReturn(response(head.substring(0, loopStart + 40), "length"))
                .thenReturn(response(head.substring(loopStart + 40), "length"));

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", "извлеки условия договора")), null, null);

        // первый кусок ещё не зациклился (5 повторов) — дочитан; после склейки хвост зациклился — стоп
        verify(chatModel, times(2)).call(any(Prompt.class));
        assertTrue(text.endsWith("\n" + GigaChatClient.LOOP_MARKER), text);
        assertEquals(1, notices.size());
    }

    @Test
    void loopAfterLastContinuationIsCutInsteadOfTruncationMarker() {
        when(chatModel.call(any(Prompt.class)))
                .thenReturn(response("Итог: " + "да; ".repeat(6), "length"))
                .thenReturn(response("да; ".repeat(6), "length"));

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", "вопрос")), null, null);

        // 5 ответов по 6 повторов: перед последним дочитыванием повторов 24, после него — 30
        verify(chatModel, times(GigaChatClient.MAX_CONTINUATIONS + 1)).call(any(Prompt.class));
        assertEquals("Итог: да; да; да; \n" + GigaChatClient.LOOP_MARKER, text);
        assertEquals(1, notices.size());
        assertTrue(notices.get(0).contains("зациклился"), notices.get(0));
    }

    @Test
    void legitimateLongOutputsOfRegressionRunsAreNotLoops() throws IOException {
        // срезы реальных длинных выходов в любом месте (так их видит дочитывание): находки ревизора D05 a2,
        // технологии лотов D05 j1, тетрадь агента F3-K1 a1 с таблицами и повторами «ПОДТВЕРЖДАЮ»
        for (String name : List.of("regress/s1-d05-ctrl-a2-head.txt", "regress/s1-d05-ctrl-j1-head.txt",
                "regress/f3-k1-a1-head.txt", "regress/kom-v4-subbotin-lot3-s5.txt")) {
            String text = resource(name);
            for (int cut = 1; cut <= text.length(); cut += 7) {
                assertNull(GigaChatClient.repeatLoop(text.substring(0, cut)), name + " срез " + cut);
            }
        }
    }

    @Test
    void tablesFillersAndShortRepeatsAreNotLoops() {
        StringBuilder table = new StringBuilder("| № | Java | Python | Go | DevOps |\n|---|---|---|---|---|\n");
        for (int row = 1; row <= 40; row++) {
            table.append("| ").append(row).append(" | Да | Нет | Нет | Нет |\n");
        }
        assertNull(GigaChatClient.repeatLoop(table));
        assertNull(GigaChatClient.repeatLoop("| да ".repeat(24) + "|"));
        assertNull(GigaChatClient.repeatLoop("Подпись: " + "_".repeat(200)));
        assertNull(GigaChatClient.repeatLoop("Оглавление " + ". ".repeat(300) + "5"));
        assertNull(GigaChatClient.repeatLoop("|" + "-".repeat(500) + "|" + " ".repeat(300)));
        assertNull(GigaChatClient.repeatLoop("да ".repeat(24)));
        assertNull(GigaChatClient.repeatLoop(""));
    }

    @Test
    void repeatLoopFindsShortestUnitAndFirstOccurrence() {
        String text = "Перечень:\n" + "10 шт.; ".repeat(1000) + "10 ш";

        GigaChatClient.RepeatLoop loop = GigaChatClient.repeatLoop(text);

        assertNotNull(loop);
        assertEquals(8, loop.unit());
        assertEquals("Перечень:\n".length(), loop.start());
        assertEquals(1000, loop.repeats());
        // строка-повтор тоже цикл: кусок с переводом строки
        GigaChatClient.RepeatLoop lines = GigaChatClient.repeatLoop("Строки:\n" + "- нет данных\n".repeat(30));
        assertNotNull(lines);
        assertEquals("- нет данных\n".length(), lines.unit());
    }

    private static ChatResponse response(String text, String finishReason) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(text),
                ChatGenerationMetadata.builder().finishReason(finishReason).build())));
    }

    static String resource(String name) throws IOException {
        try (InputStream in = GigaChatClientLoopTest.class.getClassLoader().getResourceAsStream(name)) {
            assertNotNull(in, name);
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
