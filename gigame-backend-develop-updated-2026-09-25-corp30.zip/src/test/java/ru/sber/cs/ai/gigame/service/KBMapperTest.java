package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.kb.KBDetailResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты приведения ответов баз знаний к ограничениям спецификации (SOWA).
 */
class KBMapperTest {

    private static KBDocument link(Document doc) {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(UUID.randomUUID());
        KBDocument link = new KBDocument();
        link.setId(UUID.randomUUID());
        link.setKnowledgeBase(kb);
        link.setDocument(doc);
        link.setDocumentId(doc.getId());
        return link;
    }

    private static Document document() {
        Document doc = new Document();
        doc.setId(UUID.randomUUID());
        doc.setFilename("акт.pdf");
        doc.setContentType("pdf");
        doc.setSizeBytes(10);
        return doc;
    }

    @Test
    void toKBDocumentResponse_clipsErrorMessageToSchemaMaxLength() {
        KBDocument link = link(document());
        link.setStatus("error");
        link.setErrorMessage("Не удалось выполнить запрос к GigaChat: " + "х".repeat(400));

        KBDocumentResponse response = KBMapper.toKBDocumentResponse(link);

        assertEquals(KBMapper.ERROR_MESSAGE_MAX_LENGTH, response.errorMessage().length());
        assertTrue(response.errorMessage().endsWith("…"));
        assertEquals("error", response.status());
    }

    @Test
    void toKBDocumentResponse_clipsContentTypeAndStatus_clampsNumbers_utcDates() {
        Document doc = document();
        doc.setContentType("c".repeat(100));
        doc.setSizeBytes(-5);
        KBDocument link = link(doc);
        link.setStatus("s".repeat(50));
        link.setChunkCount(-1);
        link.setCreatedAt(OffsetDateTime.of(2026, 9, 16, 12, 0, 0, 123_456_789, ZoneOffset.ofHours(3)));

        KBDocumentResponse response = KBMapper.toKBDocumentResponse(link);

        assertEquals(KBMapper.CONTENT_TYPE_MAX_LENGTH, response.contentType().length());
        assertEquals(KBMapper.STATUS_MAX_LENGTH, response.status().length());
        assertEquals(-1, response.sizeBytes());
        assertEquals(0, response.chunkCount());
        assertEquals(ZoneOffset.UTC, response.createdAt().getOffset());
        assertEquals(123_456_000, response.createdAt().getNano());
        assertEquals(9, response.createdAt().getHour());
    }

    @Test
    void toKBDocumentResponse_shortValuesUnchanged_nullsKept() {
        KBDocument link = link(document());
        link.setStatus("ready");
        link.setChunkCount(null);

        KBDocumentResponse response = KBMapper.toKBDocumentResponse(link);

        assertEquals("ready", response.status());
        assertNull(response.errorMessage());
        assertEquals(0, response.chunkCount());
        assertEquals(10, response.sizeBytes());
        assertEquals("pdf", response.contentType());
        assertEquals("акт.pdf", response.filename());
    }

    @Test
    void toKBDocumentResponse_withMessage_overridesErrorMessageOnlyInResponse() {
        KBDocument link = link(document());
        link.setStatus("ready");

        KBDocumentResponse response = KBMapper.toKBDocumentResponse(link, "повторная загрузка пропущена");

        assertEquals("повторная загрузка пропущена", response.errorMessage());
        assertNull(link.getErrorMessage());
    }

    @Test
    void toKBResponse_clipsNameAndDescription() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(UUID.randomUUID());
        kb.setUserId("U1");
        kb.setName("н".repeat(300));
        kb.setDescription("о".repeat(300));

        KBResponse response = KBMapper.toKBResponse(kb, "U1");

        assertEquals(KBMapper.NAME_MAX_LENGTH, response.name().length());
        assertEquals(KBMapper.NAME_MAX_LENGTH, response.description().length());
        assertTrue(response.isOwner());
    }

    @Test
    void toKBDetailResponse_limitsDocumentsToMaxItems_keepsFirst() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(UUID.randomUUID());
        kb.setUserId("U1");
        kb.setName("База");
        List<KBDocumentResponse> docs = IntStream.range(0, KBMapper.MAX_ITEMS + 5)
                .mapToObj(i -> KBMapper.toKBDocumentResponse(link(document())))
                .toList();

        KBDetailResponse response = KBMapper.toKBDetailResponse(kb, "U2", docs);

        assertEquals(KBMapper.MAX_ITEMS, response.documents().size());
        assertEquals(docs.get(0).id(), response.documents().get(0).id());
        assertFalse(response.isOwner());
        assertEquals("База", response.name());
    }
}
