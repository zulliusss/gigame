package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты усечения строковых полей шага в подробном отчёте прогона: корп. прокси
 * валидирует ответ по схеме с потолком 500 000 символов на поле, и больший
 * ответ блокируется целиком — поля режутся при отдаче с явной пометкой.
 */
class ScenarioMapperClipTest {

    private static final int LIMIT = 200_000;

    private static ScenarioRunStep step(String result, String documentsText) {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setNodeId("h1");
        step.setNodeType("input");
        step.setStatus("completed");
        step.setOutputData(Map.of("result", result));
        step.setInputData(Map.of("documents_text", documentsText));
        return step;
    }

    @Test
    void longFieldsAreClippedWithMarker() {
        String huge = "х".repeat(LIMIT + 100);

        ScenarioRunStepResponse response = ScenarioMapper.toStepResponse(step(huge, huge));

        String result = String.valueOf(response.outputData().result());
        assertTrue(result.length() < huge.length());
        assertTrue(result.contains("показаны первые " + LIMIT));
        String documents = String.valueOf(response.inputData().documentsText());
        assertTrue(documents.contains("показаны первые " + LIMIT));
    }

    @Test
    void stepErrorIsClippedToSchemaLimit255() {
        // [scenario-b #2]: в схеме output_data.error maxLength 255, а сообщения исполнителей длиннее
        ScenarioRunStep failed = step("", "");
        failed.setStatus("failed");
        failed.setOutputData(Map.of("error", "Узел «Трансформация»: не удалось разобрать конфигурацию: " + "ю".repeat(400)));

        ScenarioRunStepResponse response = ScenarioMapper.toStepResponse(failed);

        String error = response.outputData().error();
        assertEquals(ScenarioMapper.STEP_ERROR_LIMIT, error.length());
        assertTrue(error.startsWith("Узел «Трансформация»"));
        assertTrue(error.endsWith("…"));
    }

    @Test
    void exportStepKeepsErrorLongerThanSchemaLimit() {
        // DOCX-экспорт шлюз по JSON-схеме не проверяет — ошибка шага в нём полная, как до правки
        String longError = "Узел «Расчёт»: " + "ю".repeat(1000);
        ScenarioRunStep failed = step("", "");
        failed.setOutputData(Map.of("error", longError));

        assertEquals(longError, ScenarioMapper.toExportStepResponse(failed).outputData().error());
    }

    @Test
    void shortStepErrorPassesUnchanged() {
        ScenarioRunStep failed = step("", "");
        failed.setOutputData(Map.of("error", "Unknown node type"));

        assertEquals("Unknown node type", ScenarioMapper.toStepResponse(failed).outputData().error());
    }

    @Test
    void runResultIsClippedToSchemaLimitWithMarker() {
        // [scenario-b #1]: итог прогона в схеме maxLength 500000 — вместе с пометкой усечения
        String huge = "р".repeat(ScenarioMapper.RUN_RESULT_LIMIT + 1000);

        String clipped = ScenarioMapper.clipRunResult(huge);

        assertEquals(ScenarioMapper.RUN_RESULT_LIMIT, clipped.length());
        assertTrue(clipped.contains("итог усечён до " + ScenarioMapper.RUN_RESULT_LIMIT + " из " + huge.length()));
        assertTrue(clipped.endsWith("полный итог в DOCX-экспорте]"));
    }

    @Test
    void runResultWithinLimitPassesUnchanged() {
        String exact = "р".repeat(ScenarioMapper.RUN_RESULT_LIMIT);

        assertEquals(exact, ScenarioMapper.clipRunResult(exact));
        assertNull(ScenarioMapper.clipRunResult(null));
    }

    @Test
    void shortFieldsPassUnchanged() {
        ScenarioRunStepResponse response =
                ScenarioMapper.toStepResponse(step("короткий результат", "короткий вход"));

        assertEquals("короткий результат", response.outputData().result());
        assertEquals("короткий вход", response.inputData().documentsText());
    }
}
