package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioRunTest {

    @Test
    void testScenarioRunDefaultValues() {
        ScenarioRun run = new ScenarioRun();
        assertNull(run.getId());
        assertNull(run.getScenarioId());
        assertEquals("pending", run.getStatus());
        assertNull(run.getInputDocumentIds());
        assertNull(run.getResult());
        assertNull(run.getStartedAt());
        assertNull(run.getCompletedAt());
        assertNull(run.getUserId());
    }

    @Test
    void testScenarioRunWithAllFields() {
        UUID id = UUID.randomUUID();
        UUID scenarioId = UUID.randomUUID();
        OffsetDateTime startedAt = OffsetDateTime.now();

        ScenarioRun run = new ScenarioRun();
        run.setId(id);
        run.setScenarioId(scenarioId);
        run.setStatus("running");
        run.setInputDocumentIds(List.of(UUID.randomUUID().toString()));
        run.setResult("Test result");
        run.setStartedAt(startedAt);

        assertEquals(id, run.getId());
        assertEquals(scenarioId, run.getScenarioId());
        assertEquals("running", run.getStatus());
        assertNotNull(run.getInputDocumentIds());
        assertEquals("Test result", run.getResult());
        assertEquals(startedAt, run.getStartedAt());
    }

    @Test
    void testScenarioRunUserId() {
        ScenarioRun run = new ScenarioRun();
        assertNull(run.getUserId());

        run.setUserId("ALICE");

        assertEquals("ALICE", run.getUserId());
    }

    @Test
    void testScenarioRunWithNullResult() {
        ScenarioRun run = new ScenarioRun();
        run.setResult(null);

        assertNull(run.getResult());
    }

    @Test
    void testScenarioRunWithCompletedStatus() {
        ScenarioRun run = new ScenarioRun();
        run.setStatus("completed");
        run.setCompletedAt(OffsetDateTime.now());

        assertEquals("completed", run.getStatus());
        assertNotNull(run.getCompletedAt());
    }

    @Test
    void testScenarioRunWithEmptyInputDocumentIds() {
        ScenarioRun run = new ScenarioRun();
        run.setInputDocumentIds(List.of());

        assertTrue(run.getInputDocumentIds().isEmpty());
    }

    @Test
    void testToString() {
        ScenarioRun run = new ScenarioRun();
        String str = run.toString();
        assertNotNull(str);
        assertTrue(str.contains("ScenarioRun"));
    }
}
