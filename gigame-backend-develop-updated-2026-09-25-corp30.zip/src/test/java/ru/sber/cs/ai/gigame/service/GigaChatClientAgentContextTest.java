package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.retry.NonTransientAiException;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.ResourceAccessException;
import ru.sber.cs.ai.gigame.exception.AgentContextOverflowException;

import java.io.EOFException;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Защита агентного цикла от переполнения контекста модели: укладка истории в бюджет, повтор раунда со сжатием после
 * 422 «context too long», {@link AgentContextOverflowException}; повторы при сетевом обрыве и отказ повторять 4xx.
 */
@ExtendWith(MockitoExtension.class)
class GigaChatClientAgentContextTest {

    private static final String TOO_LONG = "HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 142410, "
            + "maximum allowed context is 130048\"}";
    private static final List<Map<String, String>> TASK = List.of(Map.of("role", "user", "content", "задание"));

    @Mock
    private ChatModel chatModel;

    @Mock
    private EmbeddingModel embeddingModel;

    private GigaChatClient client;
    private final List<List<Message>> sent = new CopyOnWriteArrayList<>();
    private final List<String> notices = new CopyOnWriteArrayList<>();

    @BeforeEach
    void setUp() {
        client = new GigaChatClient(chatModel, embeddingModel);
        // повторы разрешены: 4xx не должен повторяться из-за разрешающей политики
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 3);
        ReflectionTestUtils.setField(client, "retryDelayMillis", 1L);
        ReflectionTestUtils.setField(client, "retryDelay429Millis", 1L);
        ReflectionTestUtils.setField(client, "unavailableMaxWaitMillis", 1000L);
        ReflectionTestUtils.setField(client, "unavailableMaxDelayMillis", 1L);
        GigaChatClient.setRunWaitNotice(notices::add);
    }

    @AfterEach
    void tearDown() {
        GigaChatClient.clearRunWaitNotice();
    }

    @Test
    void largeToolResponsesAreFittedIntoBudgetBeforeRound() {
        ReflectionTestUtils.setField(client, "agentMaxContextTokens", 2000);
        answers(withCall("id1"), withCall("id2"), text("Итог"));

        var result = client.chatCompletionWithTools(TASK, List.of(tool("Ф".repeat(5000))), null, null);

        assertEquals("Итог", result.text());
        // третий раунд: 10 тыс. символов ответов при бюджете 6 тыс. — первый ответ пометкой, последний полный
        List<ToolResponseMessage> third = toolMessages(sent.get(2));
        assertEquals(AgentContextBudget.marker("read_document", 5000), third.get(0).getResponses().get(0).responseData());
        assertEquals(5000, third.get(1).getResponses().get(0).responseData().length());
        // второй раунд в бюджете — без изменений
        assertEquals(5000, toolMessages(sent.get(1)).get(0).getResponses().get(0).responseData().length());
    }

    @Test
    void contextTooLongOnSecondRoundIsRetriedOnceWithCompressedToolResponses() {
        answers(withCall("id1"), tooLong(), text("Итог"));

        var result = client.chatCompletionWithTools(TASK, List.of(tool("Ф".repeat(5000))), null, null);

        assertEquals("Итог", result.text());
        verify(chatModel, times(3)).call(any(Prompt.class));
        assertEquals(5000, toolMessages(sent.get(1)).get(0).getResponses().get(0).responseData().length());
        assertEquals(AgentContextBudget.marker("read_document", 5000),
                toolMessages(sent.get(2)).get(0).getResponses().get(0).responseData());
        assertEquals(List.of("⚠ контекст агента больше окна модели (запрос 142410 токенов при максимуме 130048) — "
                + "ответы инструментов сжаты (1), раунд повторяется"), notices);
    }

    @Test
    void contextTooLongTwiceThrowsOverflow() {
        answers(withCall("id1"), tooLong(), tooLong());
        ToolCallback largeTool = tool("Ф".repeat(5000));

        var e = assertThrows(AgentContextOverflowException.class,
                () -> client.chatCompletionWithTools(TASK, List.of(largeTool), null, null));

        verify(chatModel, times(3)).call(any(Prompt.class));
        assertEquals(142410, e.getRequested());
        assertEquals(130048, e.getMaximum());
        assertEquals("запрос 142410 токенов при максимуме 130048", e.limits());
    }

    @Test
    void contextTooLongOnFirstRoundWithoutToolResponsesThrowsAtOnce() {
        answers(tooLong());
        ToolCallback emptyTool = tool("{}");

        var e = assertThrows(AgentContextOverflowException.class,
                () -> client.chatCompletionWithTools(TASK, List.of(emptyTool), null, null));

        // сжимать нечего — ни повтора раунда, ни повторов политики
        verify(chatModel, times(1)).call(any(Prompt.class));
        assertEquals(130048, e.getMaximum());
        assertTrue(notices.isEmpty(), notices.toString());
    }

    @Test
    void contextTooLongWith502InsideTokenCountIsNotRetried() {
        // «135021» содержит «502»: прежде 422 считался 5xx и повторялся до 30 мин
        when(chatModel.call(any(Prompt.class))).thenThrow(new NonTransientAiException(
                "HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 135021, maximum allowed context is 130048\"}"));
        List<ToolCallback> tools = List.of();

        var e = assertThrows(AgentContextOverflowException.class, () -> client.chatCompletionWithTools(TASK, tools, null, null));

        verify(chatModel, times(1)).call(any(Prompt.class));
        assertEquals(135021, e.getRequested());
        RuntimeException tooLong = new NonTransientAiException("HTTP 422 - {\"message\":\"context too long 135021 of 142910\"}");
        String text = "NonTransientAiException: " + tooLong.getMessage();
        assertFalse(GigaChatClient.isTransientFailure(text, tooLong));
        assertFalse(GigaChatClient.isRateLimited(text, tooLong));
        // без кода ответа — число отдельным словом, а не часть числа токенов
        RuntimeException plain = new RuntimeException("context too long 135021, 142910");
        assertFalse(GigaChatClient.isTransientFailure(plain.getMessage(), plain));
        assertFalse(GigaChatClient.isRateLimited(plain.getMessage(), plain));
        RuntimeException badGateway = new RuntimeException("502 Bad Gateway");
        assertTrue(GigaChatClient.isTransientFailure(badGateway.getMessage(), badGateway));
        RuntimeException rateLimited = new NonTransientAiException("HTTP 429 - {\"message\":\"Too many requests\"}");
        assertTrue(GigaChatClient.isRateLimited(rateLimited.getMessage(), rateLimited));
    }

    @Test
    void eofWhileReadingResponseHeadersIsRetried() {
        IOException eof = new IOException("HTTP/1.1 header parser received no bytes", new EOFException("EOF reached while reading"));
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(new ResourceAccessException("I/O error on POST request for \"https://gigachat/api/v1/chat/completions\": "
                        + "HTTP/1.1 header parser received no bytes", eof))
                .thenReturn(new ChatResponse(List.of(new Generation(new AssistantMessage("ответ")))));

        assertEquals("ответ", client.chatCompletion(TASK));

        verify(chatModel, times(2)).call(any(Prompt.class));
        assertTrue(GigaChatClient.isNetworkFailure(new RuntimeException("обёртка", eof)));
        assertFalse(GigaChatClient.isNetworkFailure(new RuntimeException("HTTP 400")));
    }

    private void answers(Object... responses) {
        var stub = when(chatModel.call(any(Prompt.class)));
        for (Object response : responses) {
            stub = stub.thenAnswer(inv -> {
                sent.add(List.copyOf(inv.getArgument(0, Prompt.class).getInstructions()));
                if (response instanceof RuntimeException e) {
                    throw e;
                }
                return response;
            });
        }
    }

    private static RuntimeException tooLong() {
        return new NonTransientAiException(TOO_LONG);
    }

    private static ChatResponse withCall(String id) {
        return new ChatResponse(List.of(new Generation(AssistantMessage.builder().content("")
                .toolCalls(List.of(new AssistantMessage.ToolCall(id, "function", "read_document", "{\"offset\":" + id.length() + "}")))
                .build())));
    }

    private static ChatResponse text(String answer) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(answer))));
    }

    private static ToolCallback tool(String result) {
        return new ToolCallback() {
            @Override
            public ToolDefinition getToolDefinition() {
                return ToolDefinition.builder().name("read_document").description("чтение").inputSchema("{}").build();
            }

            @Override
            public String call(String toolInput) {
                return result;
            }
        };
    }

    private static List<ToolResponseMessage> toolMessages(List<Message> history) {
        return history.stream().filter(ToolResponseMessage.class::isInstance).map(ToolResponseMessage.class::cast).toList();
    }
}
