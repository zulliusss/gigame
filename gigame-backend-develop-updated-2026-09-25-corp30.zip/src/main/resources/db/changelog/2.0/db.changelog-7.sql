--liquibase formatted sql

--changeset gigame:10-run-retention-indexes
-- =====================================================
-- Правка 10: Срок хранения прогонов и объём шагов
-- =====================================================
-- 2026-09-15: Шаги прогона перестали дублировать тексты документов; появилась
--             плановая чистка прогонов по сроку хранения
--             (app.scenario.run-retention-days). Индекс по started_at — для
--             выборки устаревших прогонов; idx_scenario_run_steps_run_id
--             дублировал составной idx_scenario_run_steps_run (run_id, started_at).
--             Idempotent (IF NOT EXISTS / IF EXISTS).
CREATE INDEX IF NOT EXISTS idx_scenario_runs_started_at ON scenario_runs(started_at);
DROP INDEX IF EXISTS idx_scenario_run_steps_run_id;

--changeset gigame:11-run-steps-compression dbms:postgresql splitStatements:false
-- =====================================================
-- Правка 11: Сжатие полей шагов прогона
-- =====================================================
-- 2026-09-15: Сжатие JSONB/TEXT-полей шагов (PostgreSQL 14+, сборка с lz4). На старших
--             версиях и сборках без lz4 блок ничего не меняет (проверка версии +
--             перехват feature_not_supported); на уже сжатых колонках повтор безвреден.
DO $$
BEGIN
    IF current_setting('server_version_num')::int >= 140000 THEN
        BEGIN
            ALTER TABLE scenario_run_steps ALTER COLUMN input_data SET COMPRESSION lz4;
            ALTER TABLE scenario_run_steps ALTER COLUMN output_data SET COMPRESSION lz4;
            ALTER TABLE scenario_run_steps ALTER COLUMN prompt_used SET COMPRESSION lz4;
        EXCEPTION WHEN feature_not_supported THEN
            RAISE NOTICE 'lz4 недоступен в этой сборке PostgreSQL — сжатие шагов не включено';
        END;
    END IF;
END $$;

--changeset gigame:12-scenario-versions-fk dbms:postgresql splitStatements:false
-- =====================================================
-- Правка 12: Версии сценария удаляются вместе со сценарием
-- =====================================================
-- 2026-09-15: scenario_versions хранит снимок graph_data при каждом сохранении и
--             не имел внешнего ключа — после удаления сценария версии оставались
--             сиротами. Сироты удаляются, далее ON DELETE CASCADE. Число хранимых
--             версий ограничивает приложение (app.scenario.versions-keep).
--             Idempotent: ключ создаётся, только если его ещё нет.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'fk_scenario_versions_scenario'
                     AND conrelid = 'scenario_versions'::regclass) THEN
        DELETE FROM scenario_versions v
         WHERE NOT EXISTS (SELECT 1 FROM scenarios s WHERE s.id = v.scenario_id);
        ALTER TABLE scenario_versions
            ADD CONSTRAINT fk_scenario_versions_scenario
            FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE;
    END IF;
END $$;
