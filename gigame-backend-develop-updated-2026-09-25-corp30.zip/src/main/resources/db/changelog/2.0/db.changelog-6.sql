-- =====================================================
-- ChangeSet 9: Автор прогона сценария
-- =====================================================
-- 2026-09-15: Общий сценарий запускают разные пользователи: автор прогона
--             (user_id) ограничивает доступ к истории, деталям, файлам,
--             возобновлению и нарастающему итогу прогонов. Старые прогоны
--             без автора (NULL) остаются доступны владельцу сценария.
--             Idempotent (IF EXISTS / IF NOT EXISTS).

ALTER TABLE IF EXISTS scenario_runs
    ADD COLUMN IF NOT EXISTS user_id VARCHAR(255);

-- История прогонов пользователя и поиск его предыдущего прогона сценария
CREATE INDEX IF NOT EXISTS idx_scenario_runs_scenario_user
    ON scenario_runs(scenario_id, user_id, started_at);
