--liquibase formatted sql

--changeset gigame:corp17-documents-content-sha256
-- =====================================================
-- corp17 (база знаний): хэш содержимого документа и индексы чистки
-- =====================================================
-- 2026-09-16: content_sha256 — SHA-256 файла: повторная загрузка того же файла
--             (имя + хэш) в базу знаний пропускается либо заменяет неудачную попытку.
--             Индекс по created_at — для плановой чистки документов чата, не
--             попавших ни в одно сообщение (app.document.orphan-retention-hours).
--             Idempotent (IF NOT EXISTS).
ALTER TABLE documents ADD COLUMN IF NOT EXISTS content_sha256 VARCHAR(64);
CREATE INDEX IF NOT EXISTS idx_documents_content_sha256 ON documents(content_sha256);
CREATE INDEX IF NOT EXISTS idx_documents_created_at ON documents(created_at);

--changeset gigame:corp17-embeddings-source-document-fk dbms:postgresql splitStatements:false
-- =====================================================
-- corp17 (база знаний): эмбеддинги удаляются вместе с документом
-- =====================================================
-- 2026-09-16: embeddings.source_document_id (документ-источник фрагмента в коллекциях
--             «doc» и «kb») не имел внешнего ключа — удаление документа мимо кода
--             оставляло фрагменты сиротами. Сироты удаляются, далее ON DELETE CASCADE;
--             индекс по source_document_id — для каскадного удаления.
--             Idempotent: ключ создаётся, только если его ещё нет.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'fk_embeddings_source_document'
                     AND conrelid = 'embeddings'::regclass) THEN
        DELETE FROM embeddings e
         WHERE e.source_document_id IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM documents d WHERE d.id = e.source_document_id);
        CREATE INDEX IF NOT EXISTS idx_embeddings_source_document ON embeddings(source_document_id);
        ALTER TABLE embeddings
            ADD CONSTRAINT fk_embeddings_source_document
            FOREIGN KEY (source_document_id) REFERENCES documents(id) ON DELETE CASCADE;
    END IF;
END $$;
