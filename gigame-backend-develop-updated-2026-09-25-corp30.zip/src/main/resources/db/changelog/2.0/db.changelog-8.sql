--liquibase formatted sql

--changeset gigame:13-prompt-ratings-fk dbms:postgresql splitStatements:false
-- =====================================================
-- Правка 13: Оценки промпта удаляются вместе с промптом
-- =====================================================
-- 2026-09-16 (corp17): prompt_ratings не имела внешнего ключа на prompts — после
--             удаления промпта оценки оставались сиротами и копились бессрочно.
--             Сироты удаляются, далее ON DELETE CASCADE.
--             Idempotent: ключ создаётся, только если его ещё нет.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'fk_prompt_ratings_prompt'
                     AND conrelid = 'prompt_ratings'::regclass) THEN
        DELETE FROM prompt_ratings r
         WHERE NOT EXISTS (SELECT 1 FROM prompts p WHERE p.id = r.prompt_id);
        ALTER TABLE prompt_ratings
            ADD CONSTRAINT fk_prompt_ratings_prompt
            FOREIGN KEY (prompt_id) REFERENCES prompts(id) ON DELETE CASCADE;
    END IF;
END $$;

--changeset gigame:14-agent-memory-fk dbms:postgresql splitStatements:false
-- =====================================================
-- Правка 14: Память агента удаляется вместе со сценарием и прогоном
-- =====================================================
-- 2026-09-16 (corp17): agent_lessons и agent_plans (scenario_id) не имели внешнего
--             ключа на scenarios, agent_questions (run_id) — на scenario_runs: после
--             удаления сценария (один DELETE, прогоны — каскадом) уроки, планы и
--             вопросы оставались сиротами, и чистка по сроку хранения их не находила.
--             Сироты удаляются, далее ON DELETE CASCADE. Уроки без сценария
--             (scenario_id NULL — общие и системные) ключом не затрагиваются.
--             Idempotent: каждый ключ создаётся, только если его ещё нет.
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'fk_agent_lessons_scenario'
                     AND conrelid = 'agent_lessons'::regclass) THEN
        DELETE FROM agent_lessons l
         WHERE l.scenario_id IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM scenarios s WHERE s.id = l.scenario_id);
        ALTER TABLE agent_lessons
            ADD CONSTRAINT fk_agent_lessons_scenario
            FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'fk_agent_plans_scenario'
                     AND conrelid = 'agent_plans'::regclass) THEN
        DELETE FROM agent_plans p
         WHERE p.scenario_id IS NOT NULL
           AND NOT EXISTS (SELECT 1 FROM scenarios s WHERE s.id = p.scenario_id);
        ALTER TABLE agent_plans
            ADD CONSTRAINT fk_agent_plans_scenario
            FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE CASCADE;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_constraint
                   WHERE conname = 'fk_agent_questions_run'
                     AND conrelid = 'agent_questions'::regclass) THEN
        DELETE FROM agent_questions q
         WHERE NOT EXISTS (SELECT 1 FROM scenario_runs r WHERE r.id = q.run_id);
        ALTER TABLE agent_questions
            ADD CONSTRAINT fk_agent_questions_run
            FOREIGN KEY (run_id) REFERENCES scenario_runs(id) ON DELETE CASCADE;
    END IF;
END $$;
