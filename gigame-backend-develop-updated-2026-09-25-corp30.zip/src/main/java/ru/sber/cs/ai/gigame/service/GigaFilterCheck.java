package ru.sber.cs.ai.gigame.service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * DTO запроса и ответа проверки текста фильтром GigaFilter: {@code POST {base-url}/filter/check}.
 * <p>
 * Контракт (документация developers.sber.ru «Проверить содержимое сообщений», gigachat-java {@code FilterCheckRequest}):
 * тело {@code {"model":"GigaFilter","messages":[{"role","content"}],"settings":{"neuro","blacklist","whitelist",
 * "unnormalized_history"}}}, ответ {@code {"is_profane":bool,"usage":{"filter_tokens":n}}}. Место опции
 * {@code safety} в контракте не описано — настраивается ({@code app.gigachat.profanity-check.safety-placement}).
 */
public final class GigaFilterCheck {

    private GigaFilterCheck() {
    }

    /**
     * Тело запроса к фильтру.
     *
     * @param model    модель фильтра (GigaFilter)
     * @param messages проверяемые сообщения (один фрагмент — одно сообщение)
     * @param settings опции фильтра ({@code null} — не отправляются)
     * @param safety   опция safety в корне тела ({@code null} — не отправляется)
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Request(String model, List<Message> messages, Settings settings, String safety) {
    }

    /**
     * Сообщение на проверку.
     *
     * @param role    роль (user, assistant)
     * @param content текст фрагмента
     */
    public record Message(String role, String content) {
    }

    /**
     * Опции фильтра — как у агента коллег (profanity_check.options).
     *
     * @param neuro               нейросетевой классификатор
     * @param blacklist           словарь запрещённых выражений
     * @param whitelist           словарь разрешённых выражений
     * @param unnormalizedHistory проверка ненормализованной истории
     * @param safety              уровень строгости ({@code null} — не отправляется)
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record Settings(Boolean neuro, Boolean blacklist, Boolean whitelist,
                           @JsonProperty("unnormalized_history") Boolean unnormalizedHistory, String safety) {
    }

    /**
     * Ответ фильтра.
     *
     * @param profane признак блокировки ({@code null} — ответ не распознан)
     */
    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Response(@JsonProperty("is_profane") Boolean profane) {
    }

    /**
     * Исход одного вызова фильтра: вердикт либо сбой.
     *
     * @param profane          вердикт ({@code null} — вердикта нет, вызов не удался)
     * @param status           HTTP-код сбоя ({@code null} — сбой без ответа сервера либо вердикт)
     * @param failure          краткая причина сбоя ({@code null} при вердикте)
     * @param retryAfterMillis подсказка {@code Retry-After} ответа 429, мс (0 — нет)
     */
    public record Outcome(Boolean profane, Integer status, String failure, long retryAfterMillis) {

        /** Превышение лимита запросов ключа. */
        public static final int TOO_MANY_REQUESTS = 429;
        private static final int SERVER_ERROR_MIN = 500;
        private static final int SERVER_ERROR_MAX = 599;

        /**
         * Вердикт фильтра.
         *
         * @param profane текст заблокирован
         * @return исход с вердиктом
         */
        public static Outcome verdict(boolean profane) {
            return new Outcome(profane, null, null, 0L);
        }

        /**
         * Сбой вызова фильтра.
         *
         * @param status  HTTP-код ({@code null}, если ответа сервера нет)
         * @param failure краткая причина
         * @return исход без вердикта
         */
        public static Outcome failed(Integer status, String failure) {
            return new Outcome(null, status, failure, 0L);
        }

        /**
         * Сбой вызова фильтра с подсказкой паузы сервера.
         *
         * @param status           HTTP-код ({@code null}, если ответа сервера нет)
         * @param failure          краткая причина
         * @param retryAfterMillis подсказка {@code Retry-After}, мс (0 — нет)
         * @return исход без вердикта
         */
        public static Outcome failed(Integer status, String failure, long retryAfterMillis) {
            return new Outcome(null, status, failure, Math.max(0L, retryAfterMillis));
        }

        /**
         * Есть ли вердикт.
         *
         * @return {@code true}, если фильтр ответил 200 с признаком is_profane
         */
        public boolean definitive() {
            return profane != null;
        }

        /**
         * Превышен лимит запросов ключа (429) — временный сбой, повторяется после паузы.
         *
         * @return {@code true} для ответа 429
         */
        public boolean rateLimited() {
            return status != null && status == TOO_MANY_REQUESTS;
        }

        /**
         * Временный сбой, который стоит повторить: 429 или 5xx.
         *
         * @return {@code true} для 429 и кодов 500–599
         */
        public boolean retryable() {
            return rateLimited() || status != null && status >= SERVER_ERROR_MIN && status <= SERVER_ERROR_MAX;
        }
    }
}
