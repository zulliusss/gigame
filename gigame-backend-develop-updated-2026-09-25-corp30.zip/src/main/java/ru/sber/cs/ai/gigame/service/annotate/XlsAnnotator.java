package ru.sber.cs.ai.gigame.service.annotate;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.Comment;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Разметка книги Excel (XLSX и XLS) по находкам заключения: ячейка с цитатой (или с числом находки без цитаты)
 * заливается цветом уровня риска, к ней прикрепляется примечание Excel с текстом находки.
 * <p>
 * Ячейка ищется по её отображаемому тексту ({@link DataFormatter} с русской локалью — так же, как книга
 * попадает в проверку), сравнение — через {@link TextLocator}, поэтому оформление чисел и кавычек не мешает.
 * Подсветка ячейки целиком: разметить часть текста внутри ячейки Excel нельзя.
 */
public final class XlsAnnotator {

    /** Автор примечаний в книге. */
    static final String AUTHOR = "GigaMe";
    /** Ширина окна примечания в колонках. */
    private static final int COMMENT_COLUMNS = 4;
    /** Высота окна примечания в строках. */
    private static final int COMMENT_ROWS = 6;
    private static final Locale RU = new Locale("ru", "RU");

    private XlsAnnotator() {
    }

    /**
     * Итог разметки книги.
     *
     * @param content   размеченная книга (того же формата, что исходная)
     * @param annotated сколько находок отмечено
     * @param notes     пометки по находкам, которые не отмечены
     */
    public record Result(byte[] content, int annotated, List<String> notes) {
    }

    /** Лист, строка и колонка найденной ячейки. */
    private record Hit(Sheet sheet, Cell cell, boolean partial) {
    }

    /**
     * Размечает находки в книге.
     *
     * @param xls      исходная книга
     * @param findings находки этой книги
     * @return размеченная книга и пометки
     * @throws IOException книга не открывается или не записывается
     */
    public static Result annotate(byte[] xls, List<Finding> findings) throws IOException {
        try (Workbook book = WorkbookFactory.create(new ByteArrayInputStream(xls))) {
            DataFormatter formatter = new DataFormatter(RU);
            Map<String, CellStyle> styles = new HashMap<>();
            List<String> notes = new ArrayList<>();
            int annotated = 0;
            for (Finding finding : findings) {
                Hit hit = locate(book, formatter, finding);
                if (hit == null) {
                    notes.add("находка № " + finding.number() + ": цитата в книге не найдена — не отмечена");
                    continue;
                }
                mark(book, styles, hit, finding);
                annotated++;
                if (hit.partial()) {
                    notes.add("находка № " + finding.number() + ": цитата найдена не целиком — отмечена ячейка "
                            + hit.sheet().getSheetName() + "!" + hit.cell().getAddress());
                }
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            book.write(out);
            return new Result(out.toByteArray(), annotated, notes);
        }
    }

    /** Ячейка с цитатой: сначала полное совпадение, затем — частичное. */
    private static Hit locate(Workbook book, DataFormatter formatter, Finding finding) {
        Hit partial = null;
        for (int i = 0; i < book.getNumberOfSheets(); i++) {
            Hit hit = locateInSheet(book.getSheetAt(i), formatter, finding);
            if (hit != null && !hit.partial()) {
                return hit;
            }
            partial = partial != null ? partial : hit;
        }
        return partial;
    }

    /** Ячейка листа с цитатой: первое полное совпадение, иначе первое частичное, иначе {@code null}. */
    private static Hit locateInSheet(Sheet sheet, DataFormatter formatter, Finding finding) {
        Hit partial = null;
        for (Row row : sheet) {
            for (Cell cell : row) {
                TextLocator.Span span = findInCell(cell, formatter, finding);
                if (span != null && !span.partial()) {
                    return new Hit(sheet, cell, false);
                }
                if (span != null && partial == null) {
                    partial = new Hit(sheet, cell, true);
                }
            }
        }
        return partial;
    }

    /**
     * Поиск в ячейке: по отображаемому тексту, а для числа — ещё и по значению без формата. Общий формат Excel
     * показывает длинное число округлённым («289523339,1»), и сумма находки в нём не нашлась бы.
     *
     * @param cell      ячейка
     * @param formatter форматировщик значений
     * @param finding   находка
     * @return диапазон в тексте ячейки либо {@code null}
     */
    private static TextLocator.Span findInCell(Cell cell, DataFormatter formatter, Finding finding) {
        TextLocator.Span span = finding.locateIn(formatter.formatCellValue(cell));
        if (span != null || cell.getCellType() != CellType.NUMERIC || DateUtil.isCellDateFormatted(cell)) {
            return span;
        }
        return finding.locateIn(BigDecimal.valueOf(cell.getNumericCellValue()).toPlainString());
    }

    /** Заливка ячейки цветом уровня и примечание с текстом находки. */
    private static void mark(Workbook book, Map<String, CellStyle> styles, Hit hit, Finding finding) {
        Cell cell = hit.cell();
        short color = color(finding);
        cell.setCellStyle(styles.computeIfAbsent(cell.getCellStyle().getIndex() + "/" + color,
                key -> filled(book, cell.getCellStyle(), color)));
        CreationHelper helper = book.getCreationHelper();
        Drawing<?> drawing = hit.sheet().createDrawingPatriarch();
        ClientAnchor anchor = helper.createClientAnchor();
        anchor.setCol1(cell.getColumnIndex());
        anchor.setRow1(cell.getRowIndex());
        anchor.setCol2(cell.getColumnIndex() + COMMENT_COLUMNS);
        anchor.setRow2(cell.getRowIndex() + COMMENT_ROWS);
        Comment comment = drawing.createCellComment(anchor);
        comment.setAuthor(AUTHOR);
        comment.setString(helper.createRichTextString(finding.comment()));
        cell.setCellComment(comment);
    }

    /** Копия стиля ячейки со сплошной заливкой цвета уровня. */
    private static CellStyle filled(Workbook book, CellStyle source, short color) {
        CellStyle style = book.createCellStyle();
        style.cloneStyleFrom(source);
        style.setFillForegroundColor(color);
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return style;
    }

    /** Цвет заливки по уровню риска — те же цвета, что подсветка в DOCX. */
    private static short color(Finding finding) {
        return switch (finding.color()) {
            case "red" -> IndexedColors.ROSE.getIndex();
            case "yellow" -> IndexedColors.LIGHT_YELLOW.getIndex();
            case "green" -> IndexedColors.LIGHT_GREEN.getIndex();
            default -> IndexedColors.LIGHT_TURQUOISE.getIndex();
        };
    }
}
