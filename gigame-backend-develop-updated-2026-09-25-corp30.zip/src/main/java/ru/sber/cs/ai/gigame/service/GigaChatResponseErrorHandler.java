package ru.sber.cs.ai.gigame.service;

import org.springframework.ai.retry.NonTransientAiException;
import org.springframework.ai.retry.TransientAiException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;

/**
 * Обработчик ответов GigaChat с кодом ошибки для {@code RestClient} библиотеки spring-ai-gigachat
 * (автоконфигурация берёт бин {@link ResponseErrorHandler}, если он есть).
 * <p>
 * Повторяет {@code RetryUtils.DEFAULT_RESPONSE_ERROR_HANDLER} spring-ai — тот же текст «код - тело»,
 * те же исключения ({@link NonTransientAiException} для 4xx, {@link TransientAiException} для 5xx) —
 * и лишь дописывает к сообщению 429 пометку {@link GigaChatRetryAfter#MARKER} с числом секунд
 * заголовка {@code Retry-After}: исключения spring-ai заголовков не несут, а политика повторов
 * ждёт не меньше подсказки сервиса.
 */
@Component
public class GigaChatResponseErrorHandler implements ResponseErrorHandler {

    private static final int TOO_MANY_REQUESTS = 429;

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {
        return response.getStatusCode().isError();
    }

    @Override
    public void handleError(URI url, HttpMethod method, ClientHttpResponse response) throws IOException {
        if (!response.getStatusCode().isError()) {
            return;
        }
        int status = response.getStatusCode().value();
        String body = StreamUtils.copyToString(response.getBody(), StandardCharsets.UTF_8);
        String message = status + " - " + body + retryAfterMark(status, response.getHeaders());
        if (response.getStatusCode().is4xxClientError()) {
            throw new NonTransientAiException(message);
        }
        throw new TransientAiException(message);
    }

    /**
     * Пометка «; Retry-After=N» для 429 с числовым заголовком; иначе пусто.
     *
     * @param status  код ответа
     * @param headers заголовки ответа
     * @return пометка или пустая строка
     */
    static String retryAfterMark(int status, HttpHeaders headers) {
        if (status != TOO_MANY_REQUESTS || headers == null) {
            return "";
        }
        long millis = GigaChatRetryAfter.seconds(headers.getFirst(HttpHeaders.RETRY_AFTER));
        return millis > 0 ? "; " + GigaChatRetryAfter.MARKER + millis / 1000 : "";
    }
}
