package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Кэш результатов распознавания сканов по SHA-256 байтов файла (corp23). Повторная загрузка того же скана
 * (после истечения кэша документов, перезапуска клиента, в другой сценарий) отдаёт текст без обращения
 * к модели — распознавание 70-страничного скана стоит десятки минут и квоту GigaChat.
 * <p>
 * В памяти, ограничен суммарным объёмом текста {@code app.document.ocr-cache-max-chars} (вытеснение
 * самых давно использованных) и сроком {@code app.document.ocr-cache-ttl-hours}. Не кэшируются тексты
 * с отказами модели, нераспознанными страницами и обрывом ответа — их стоит распознать заново.
 * На попадании к тексту дописывается строка {@link #CACHE_MARKER}: по ней предупреждение загрузки сообщает,
 * что распознавание взято из кэша.
 */
@Slf4j
@Service
public class OcrResultCache {

    /** Пометка в конце текста, взятого из кэша. */
    public static final String CACHE_MARKER = "[распознавание взято из кэша]";
    private static final long NANOS_PER_HOUR = 3_600_000_000_000L;

    /** Предел суммарного объёма кэшированных текстов, знаков; 0 и меньше — кэш выключен. */
    @Value("${app.document.ocr-cache-max-chars:50000000}")
    private long maxChars = 50_000_000L;

    /** Срок жизни записи, часов. */
    @Value("${app.document.ocr-cache-ttl-hours:24}")
    private int ttlHours = 24;

    /** Записи в порядке обращения (самая давняя — первая). */
    private final LinkedHashMap<String, Entry> entries = new LinkedHashMap<>(64, 0.75f, true);
    private long totalChars;

    /** Запись кэша: текст и момент истечения. */
    private record Entry(String text, long expiresAtNanos) {
    }

    /** Конструктор для Spring (настройки внедряются в поля). */
    public OcrResultCache() {
    }

    /**
     * Кэш с заданными пределами (тесты).
     *
     * @param maxChars предел объёма, знаков
     * @param ttlHours срок жизни, часов
     */
    public OcrResultCache(long maxChars, int ttlHours) {
        this.maxChars = maxChars;
        this.ttlHours = ttlHours;
    }

    /**
     * Текст распознавания из кэша либо результат распознавания, положенный в кэш.
     *
     * @param filename   имя файла (для журнала)
     * @param content    байты файла
     * @param recognizer распознавание через модель
     * @return текст из кэша с пометкой {@link #CACHE_MARKER} либо результат распознавания
     */
    public String recognize(String filename, byte[] content, Supplier<String> recognizer) {
        if (maxChars <= 0) {
            return recognizer.get();
        }
        String key = DocumentService.sha256Hex(content);
        String hit = get(key);
        if (hit != null) {
            log.info("OCR «{}»: распознавание взято из кэша ({} знаков)", filename, hit.length());
            return hit + "\n" + CACHE_MARKER;
        }
        String text = recognizer.get();
        if (cacheable(text)) {
            put(key, text);
        }
        return text;
    }

    /**
     * Годится ли текст для кэша: без отказов, нераспознанных страниц и обрыва ответа.
     *
     * @param text результат распознавания
     * @return {@code true}, если текст полный
     */
    static boolean cacheable(String text) {
        return text != null && !text.isBlank()
                && !text.contains("не распознан")
                && !text.contains(ScanOcrService.TRUNCATED_MARKER)
                && !text.contains(ScanOcrService.BLOCKED_REFUSAL);
    }

    /**
     * Текст по ключу, если запись есть и не истекла.
     *
     * @param key SHA-256 байтов файла
     * @return текст либо {@code null}
     */
    synchronized String get(String key) {
        Entry entry = entries.get(key);
        if (entry == null) {
            return null;
        }
        if (System.nanoTime() - entry.expiresAtNanos() >= 0) {
            entries.remove(key);
            totalChars -= entry.text().length();
            return null;
        }
        return entry.text();
    }

    /**
     * Кладёт текст в кэш, вытесняя самые давно использованные записи сверх предела объёма.
     *
     * @param key  SHA-256 байтов файла
     * @param text текст распознавания
     */
    synchronized void put(String key, String text) {
        if (text.length() > maxChars) {
            return;
        }
        Entry previous = entries.remove(key);
        if (previous != null) {
            totalChars -= previous.text().length();
        }
        Iterator<Map.Entry<String, Entry>> oldest = entries.entrySet().iterator();
        while (totalChars + text.length() > maxChars && oldest.hasNext()) {
            totalChars -= oldest.next().getValue().text().length();
            oldest.remove();
        }
        entries.put(key, new Entry(text, System.nanoTime() + Math.max(1, ttlHours) * NANOS_PER_HOUR));
        totalChars += text.length();
    }

    /**
     * Число записей в кэше.
     *
     * @return число записей
     */
    synchronized int size() {
        return entries.size();
    }
}
