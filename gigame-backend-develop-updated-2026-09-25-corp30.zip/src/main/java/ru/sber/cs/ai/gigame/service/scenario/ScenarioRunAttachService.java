package ru.sber.cs.ai.gigame.service.scenario;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputView;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Повторная подписка на идущий прогон по run_id (corp23, WS-команда {@code attach}): после обрыва WebSocket
 * посреди долгого прогона панель показывала «соединение потеряно», а итоговый STATUS и FILE_OUTPUT
 * («файл готов») терялись — прогон при этом продолжался и завершался в БД.
 * <p>
 * Живого буфера событий у прогона нет (поток событий привязан к сессии, в которой он запущен), поэтому
 * состояние берётся из БД опросом раз в {@code app.ws.attach-poll-seconds} секунд: STATUS при подключении
 * и при каждой смене статуса; по завершении — FILE_OUTPUT для файловых выходных узлов, у которых есть
 * завершённый шаг с результатом, затем итоговый STATUS (COMPLETED/FAILED) с превью итога — как в живом
 * потоке. Промежуточные события шагов не повторяются: шаги клиент перечитывает ручкой GET /runs/{runId}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScenarioRunAttachService {

    private final ScenarioRunRepository scenarioRunRepository;
    private final ScenarioRepository scenarioRepository;
    private final ScenarioRunStepRepository scenarioRunStepRepository;

    /** Период опроса состояния прогона, секунд. */
    @Value("${app.ws.attach-poll-seconds:5}")
    private int pollSeconds = 5;

    /**
     * Состояние прогона на момент опроса.
     *
     * @param status    статус прогона
     * @param result    итог (у завершённого)
     * @param fileNodes файловые выходные узлы с готовым результатом (только у завершённого прогона)
     */
    record RunState(String status, String result, List<NodeDto> fileNodes) {

        boolean terminal() {
            return !ScenarioStatus.RUNNING.toString().equals(status) && !"pending".equals(status);
        }
    }

    /**
     * Поток событий состояния прогона до его завершения. Доступ — как к карточке прогона: автору,
     * прогон без автора — владельцу сценария.
     *
     * @param runId идентификатор прогона
     * @return события STATUS (при подключении и смене статуса) и FILE_OUTPUT + STATUS по завершении
     * @throws ScenarioException прогон не найден
     */
    public Flux<ServerSentEvent<Map<String, Object>>> attach(UUID runId) {
        String userId = CurrentUserHolder.getCurrentUser();
        ScenarioRun run = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new ScenarioException("Прогон не найден: " + runId));
        Scenario model = scenarioRepository.findById(run.getScenarioId())
                .orElseThrow(() -> new ScenarioException("Сценарий прогона не найден: " + run.getScenarioId()));
        ScenarioRunAccess.checkAccess(run, model.getUserId(), userId);
        GraphDataDto graph = GraphDataMapper.toDto(model.getGraphData());
        log.info("[{}] attach к прогону {} (статус {}), опрос раз в {} с", userId, runId, run.getStatus(), pollSeconds);
        AtomicReference<String> lastStatus = new AtomicReference<>();
        return Flux.interval(Duration.ZERO, Duration.ofSeconds(Math.max(1, pollSeconds)))
                .onBackpressureDrop()
                // состояние читается из БД (JPA) вне event loop; пользователь — для журнала
                .concatMap(tick -> Mono.fromCallable(() -> CurrentUserHolder.withUser(userId, () -> state(runId, graph)))
                        .subscribeOn(Schedulers.boundedElastic()), 1)
                .flatMapIterable(state -> events(runId, state, lastStatus))
                .takeUntil(ScenarioRunAttachService::isTerminalStatus);
    }

    /**
     * Состояние прогона из БД; удалённый прогон — как FAILED с текстом ошибки.
     *
     * @param runId идентификатор прогона
     * @param graph граф сценария (файловые выходные узлы)
     * @return состояние
     */
    private RunState state(UUID runId, GraphDataDto graph) {
        ScenarioRun run = scenarioRunRepository.findById(runId).orElse(null);
        if (run == null) {
            return new RunState(ScenarioStatus.FAILED.toString(), "Прогон удалён: " + runId, List.of());
        }
        RunState state = new RunState(run.getStatus(), run.getResult(), List.of());
        return state.terminal() ? new RunState(state.status(), state.result(), readyFileNodes(runId, graph)) : state;
    }

    /** Файловые выходные узлы, у которых в прогоне есть завершённый шаг с результатом (ручка скачивания отдаст файл). */
    private List<NodeDto> readyFileNodes(UUID runId, GraphDataDto graph) {
        List<NodeDto> ready = new ArrayList<>();
        for (NodeDto node : graph.nodes()) {
            if (!ScenarioNodeType.OUTPUT_NODE.toString().equalsIgnoreCase(node.type()) || node.data() == null
                    || ScenarioEventEmission.fileOutputEvent(node.id(), label(node), node.data().mode(), node.data().rules()) == null) {
                continue;
            }
            boolean hasResult = scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(runId, node.id()).stream()
                    .anyMatch(ScenarioRunAttachService::completedWithResult);
            if (hasResult) {
                ready.add(node);
            }
        }
        return ready;
    }

    /**
     * События по состоянию: STATUS при первом опросе и при смене статуса; у завершённого прогона —
     * FILE_OUTPUT готовых файловых узлов, затем итоговый STATUS с превью итога.
     */
    private static List<ServerSentEvent<Map<String, Object>>> events(UUID runId, RunState state, AtomicReference<String> lastStatus) {
        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        boolean changed = !state.status().equals(lastStatus.getAndSet(state.status()));
        if (!state.terminal()) {
            if (changed) {
                events.add(ScenarioEventEmission.statusEvent(runId, statusOf(state.status()), null));
            }
            return events;
        }
        for (NodeDto node : state.fileNodes()) {
            events.add(ScenarioEventEmission.fileOutputEvent(node.id(), label(node), node.data().mode(), node.data().rules()));
        }
        events.add(ScenarioEventEmission.statusEvent(runId, statusOf(state.status()), state.result()));
        return events;
    }

    /** Событие STATUS с итоговым статусом (не RUNNING) — конец подписки. */
    private static boolean isTerminalStatus(ServerSentEvent<Map<String, Object>> event) {
        Map<String, Object> data = event.data();
        return data != null && data.get("status") instanceof ScenarioStatus status && status != ScenarioStatus.RUNNING;
    }

    private static ScenarioStatus statusOf(String status) {
        try {
            return ScenarioStatus.valueOf(status.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return ScenarioStatus.UNKNOWN;
        }
    }

    private static String label(NodeDto node) {
        return node.data() == null || node.data().label() == null ? node.id() : node.data().label();
    }

    /**
     * Завершён ли шаг с сохранённым результатом (ручка скачивания отдаст файл узла).
     *
     * @param step проекция шага
     * @return {@code true}, если шаг завершён и результат сохранён
     */
    private static boolean completedWithResult(StepOutputView step) {
        return ScenarioStatus.COMPLETED.toString().equals(step.getStatus()) && step.result() != null;
    }
}
