package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;

import java.util.function.LongSupplier;

/**
 * Автомат доступности фильтра GigaFilter: после {@code failures} сбоев подряд (ответ 403/404 — сразу: модели нет или
 * маршрут закрыт) фильтр считается недоступным на {@code openMillis} — вызовы не делаются, запросы к модели идут с
 * включённым цензором. По истечении паузы пропускается пробный вызов: успех закрывает автомат, сбой открывает снова.
 * Предупреждения о сбоях — не чаще раза в {@link #WARN_INTERVAL_MILLIS} (с числом подавленных), открытие автомата
 * пишется всегда. Превышение лимита запросов ключа (429 после повторов) — не сбой фильтра: счётчик не растёт, фильтр
 * не вызывается только на паузу {@link #pause} (подсказка Retry-After, иначе {@link #RATE_LIMIT_PAUSE_MILLIS}), чтобы
 * каждый следующий запрос не тратил повторы и не удваивал генерацию.
 */
@Slf4j
final class GigaFilterBreaker {

    /** Интервал предупреждений о сбоях фильтра в лог, мс. */
    static final long WARN_INTERVAL_MILLIS = 60_000L;
    /** Пауза вызовов фильтра после 429 без подсказки Retry-After, мс. */
    static final long RATE_LIMIT_PAUSE_MILLIS = 30_000L;
    private static final int FORBIDDEN = 403;
    private static final int NOT_FOUND = 404;

    private final int failures;
    private final long openMillis;
    private final LongSupplier clock;
    private int consecutive;
    private long openUntil;
    private long pausedUntil;
    private long lastWarn = Long.MIN_VALUE;
    private int suppressed;

    /**
     * Автомат с заданным порогом и паузой.
     *
     * @param failures   сбоев подряд до открытия (меньше 1 — 1)
     * @param openMillis пауза открытого автомата, мс (меньше 0 — 0)
     * @param clock      источник времени, мс
     */
    GigaFilterBreaker(int failures, long openMillis, LongSupplier clock) {
        this.failures = Math.max(1, failures);
        this.openMillis = Math.max(0, openMillis);
        this.clock = clock;
    }

    /**
     * Можно ли вызывать фильтр: автомат закрыт либо пауза истекла (пробный вызов).
     *
     * @return {@code true}, если вызов разрешён
     */
    synchronized boolean allowsCall() {
        long now = clock.getAsLong();
        return now >= pausedUntil && (consecutive < failures || now >= openUntil);
    }

    /** Фильтр ответил вердиктом: счётчик сбоев сбрасывается, открытый автомат закрывается. */
    synchronized void success() {
        if (consecutive >= failures) {
            log.info("GigaFilter снова доступен — проверка текстов фильтром возобновлена");
        }
        consecutive = 0;
    }

    /**
     * Сбой вызова фильтра: счёт подряд, открытие автомата на пороге (403/404 — сразу).
     *
     * @param status HTTP-код ({@code null} — без ответа сервера)
     * @param reason краткая причина для лога
     */
    synchronized void failure(Integer status, String reason) {
        boolean permanent = Integer.valueOf(FORBIDDEN).equals(status) || Integer.valueOf(NOT_FOUND).equals(status);
        consecutive = permanent ? Math.max(failures, consecutive + 1) : consecutive + 1;
        long now = clock.getAsLong();
        if (consecutive >= failures) {
            openUntil = now + openMillis;
            log.warn("GigaFilter недоступен ({}) — {} с проверка фильтром не выполняется, запросы к модели идут "
                    + "с включённым цензором (profanity_check=true)", reason, openMillis / 1000);
            return;
        }
        warnRateLimited(now, reason);
    }

    /**
     * Превышен лимит запросов ключа (429 после повторов): фильтр не вызывается на паузу, счётчик сбоев не меняется.
     *
     * @param retryAfterMillis подсказка Retry-After, мс (0 — пауза {@link #RATE_LIMIT_PAUSE_MILLIS}); не дольше паузы
     *                         открытого автомата
     * @param reason           краткая причина для лога
     */
    synchronized void pause(long retryAfterMillis, String reason) {
        long millis = Math.min(retryAfterMillis > 0 ? retryAfterMillis : RATE_LIMIT_PAUSE_MILLIS, openMillis);
        long now = clock.getAsLong();
        pausedUntil = Math.max(pausedUntil, now + millis);
        if (warnDue(now)) {
            log.warn("GigaFilter: превышен лимит запросов ({}) — {} с проверка фильтром не выполняется, запросы к модели "
                    + "идут с включённым цензором{}", reason, millis / 1000, suppressedNote());
            suppressed = 0;
        }
    }

    /**
     * Число предупреждений о сбоях, подавленных с последнего записанного.
     *
     * @return счётчик подавленных предупреждений
     */
    synchronized int suppressedWarnings() {
        return suppressed;
    }

    /** Предупреждение о сбое не чаще раза в интервал; подавленные считаются. */
    private void warnRateLimited(long now, String reason) {
        if (warnDue(now)) {
            log.warn("GigaFilter: сбой проверки ({}){} — для этого запроса цензор модели остаётся включённым", reason,
                    suppressedNote());
            suppressed = 0;
        }
    }

    /** Пора ли писать предупреждение: интервал прошёл — отмечается время, иначе предупреждение считается подавленным. */
    private boolean warnDue(long now) {
        if (lastWarn != Long.MIN_VALUE && now - lastWarn < WARN_INTERVAL_MILLIS) {
            suppressed++;
            return false;
        }
        lastWarn = now;
        return true;
    }

    /** Хвост предупреждения с числом подавленных похожих предупреждений (пусто, если их нет). */
    private String suppressedNote() {
        return suppressed > 0 ? "; подавлено похожих предупреждений: " + suppressed : "";
    }
}
