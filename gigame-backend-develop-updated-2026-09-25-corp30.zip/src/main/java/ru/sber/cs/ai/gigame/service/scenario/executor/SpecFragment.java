package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Block;

import java.util.Comparator;
import java.util.List;

/**
 * Участок договора для строки характеристики, не найденной дословно: место, где слов строки больше всего.
 * <p>
 * Модель проверяет такую строку по тексту позиции в договоре. Раньше показывалось начало позиции (500 символов), и в
 * таблице «параметр — значение» на 25 характеристик нужная строка оставалась за обрезкой: «Особенности: … фарами ближнего
 * света …» стояла в конце позиции ричтрака, модель её не видела и ставила «НЕТ В ДОГОВОРЕ». Участок ищется вокруг
 * вхождений самых длинных слов строки (они реже встречаются), сужается до первого и последнего найденного слова и
 * расширяется на {@link #PAD} символов по краям в пределах участка позиции.
 */
final class SpecFragment {

    /** Запас по краям участка (нормализованных символов). */
    static final int PAD = 40;
    /** Слова короче не считаются при выборе участка: предлоги и единицы («с», «мм») есть везде. */
    private static final int MIN_WORD = 3;
    /** Сколько самых длинных слов строки служат опорами поиска. */
    private static final int ANCHORS = 3;

    private SpecFragment() {
    }

    /** Найденный участок: границы слов строки и сколько разных слов в нём есть. */
    private record Hit(Block span, int score) {
    }

    /**
     * Участок договора, где слов строки больше всего.
     *
     * @param line     строка характеристики
     * @param contract нормализованный текст договора
     * @param blocks   участки договора, относящиеся к позиции
     * @return участок с запасом по краям либо {@code null}, если слов строки в участках нет
     */
    static Block of(String line, NormalizedText contract, List<Block> blocks) {
        List<String> words = words(line);
        int reach = NormalizedText.normalize(line).length() + SpecLineCheck.MAX_GAP;
        Hit best = null;
        for (String anchor : words.stream().sorted(Comparator.comparingInt(String::length).reversed()).limit(ANCHORS).toList()) {
            for (Block block : blocks) {
                best = better(best, bestAround(anchor, words, contract.norm(), block, reach));
            }
        }
        return best == null ? null : best.span();
    }

    /**
     * Слова строки для выбора участка: без модальных «должен быть», без повторов, не короче {@link #MIN_WORD};
     * если таких нет — все слова.
     *
     * @param line строка характеристики
     * @return нормализованные слова
     */
    private static List<String> words(String line) {
        List<String> all = SpecLineCheck.withoutModal(NormalizedText.tokens(line)).stream().distinct().toList();
        List<String> long3 = all.stream().filter(w -> w.length() >= MIN_WORD).toList();
        return long3.isEmpty() ? all : long3;
    }

    private static Hit bestAround(String anchor, List<String> words, String norm, Block block, int reach) {
        Hit best = null;
        for (int at = norm.indexOf(anchor, block.from()); at >= 0 && at < block.to(); at = norm.indexOf(anchor, at + 1)) {
            Block window = new Block(Math.max(block.from(), at - reach), Math.min(block.to(), at + reach));
            best = better(best, hit(words, norm, window, block));
        }
        return best;
    }

    /**
     * Слова строки в окне: сколько разных найдено и границы от первого до последнего (с запасом в пределах участка).
     *
     * @param words  слова строки
     * @param norm   нормализованный текст договора
     * @param window окно поиска
     * @param block  участок позиции (предел запаса)
     * @return найденный участок либо {@code null}
     */
    private static Hit hit(List<String> words, String norm, Block window, Block block) {
        String text = norm.substring(window.from(), window.to());
        int score = 0;
        int from = text.length();
        int to = 0;
        for (String word : words) {
            int at = text.indexOf(word);
            if (at >= 0) {
                score++;
                from = Math.min(from, at);
                to = Math.max(to, at + word.length());
            }
        }
        if (score == 0) {
            return null;
        }
        Block span = new Block(Math.max(block.from(), window.from() + from - PAD), Math.min(block.to(), window.from() + to + PAD));
        return new Hit(span, score);
    }

    /** Больше слов — лучше; при равенстве остаётся найденный раньше. */
    private static Hit better(Hit current, Hit candidate) {
        return candidate != null && (current == null || candidate.score() > current.score()) ? candidate : current;
    }
}
