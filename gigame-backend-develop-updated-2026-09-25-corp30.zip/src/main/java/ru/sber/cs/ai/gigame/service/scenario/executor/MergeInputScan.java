package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * JSON-массивы объектов во входе операции «слить_json_массивы» — с устойчивостью к сбою разметки JSON в выходе
 * одного из родителей.
 * <p>
 * Вход узла — склейка вкладов родителей, каждый под заголовком «=== РЕЗУЛЬТАТ ОТ "…" ===» (либо
 * «=== РЕЗУЛЬТАТ ОТ "…" (ОШИБКА) ===»), см. {@link AbstractScenarioExecutor#prepareNextInput}. Раньше кавычки
 * считались по всему входу сразу: лишняя кавычка модели («""цитата":») в выходе одного родителя переносила все скобки
 * дальше «внутрь строки», и массивы всех следующих родителей молча терялись (ПЗД Z007, «Свод находок (сырой)»:
 * пропали находки кодовых узлов). Теперь вход делится на блоки по заголовкам, массивы ищутся в каждом блоке отдельно
 * по скобкам вне строковых литералов ({@link LlmJson#allOutsideLiterals}) и идут в прежнем порядке.
 * <p>
 * Повреждение блока чинится двумя способами. Лишняя кавычка перед ключом объекта («""ключ":» после «{», «,» или
 * перевода строки) убирается — в корректном JSON такого сочетания не бывает. Если после этого строковый литерал всё
 * равно не закрыт до конца блока, сканирование пересинхронизируется: со строки, которая начинается с «{» или «[»,
 * после первого литерала с переводом строки (в корректном JSON перевода строки внутри строк нет — такой литерал и есть
 * место сбоя или идёт после него), и так до {@value #MAX_RESYNC} раз на блок. Если по блокам не найдено ни одного
 * массива — прежний разбор всего входа ({@link LlmJson.Policy#ALL_ARRAYS} с запасным перебором скобок внутри
 * литералов). На корректных входах найденные массивы те же, что при разборе всего входа.
 */
final class MergeInputScan {

    /** Заголовок вклада родителя: группа 1 — метка узла, группа 2 — пометка ошибки. */
    private static final Pattern HEADER = Pattern.compile("^=== РЕЗУЛЬТАТ ОТ \"(.*)\"( \\(ОШИБКА\\))? ===$", Pattern.MULTILINE);

    /** Сколько раз пересинхронизировать сканирование одного блока. */
    private static final int MAX_RESYNC = 50;

    /** Результат {@link #damageFrom}: все литералы от позиции закрыты. */
    private static final int IN_SYNC = -2;

    /** Предельная длина ключа в «""ключ":». */
    private static final int MAX_KEY = 60;

    private static final String DOUBLED_QUOTE = "\"\"";

    private MergeInputScan() {
    }

    /**
     * Найденные массивы и предупреждения о повреждённых блоках.
     *
     * @param arrays   массивы по порядку появления во входе
     * @param warnings предупреждения «в выходе «X» JSON повреждён …» (пусто — повреждений нет)
     */
    record Result(List<JsonNode> arrays, List<String> warnings) {
    }

    /**
     * Блок входа.
     *
     * @param label метка узла-родителя либо {@code null} (текст без заголовка)
     * @param error вклад упавшего узла («(ОШИБКА)»)
     * @param text  текст блока без заголовка
     */
    private record Block(String label, boolean error, String text) {
    }

    /**
     * Массивы объектов (и пустые) входа по блокам вкладов родителей.
     *
     * @param text вход операции
     * @return массивы по порядку и предупреждения о повреждённой разметке
     */
    static Result scan(String text) {
        String input = text == null ? "" : text;
        List<JsonNode> arrays = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        for (Block block : blocks(input)) {
            boolean damaged = scanBlock(block.text(), arrays);
            // блок без «[» массивов не содержал — терять нечего; текст ошибки узла — не JSON
            if (damaged && !block.error() && block.text().indexOf('[') >= 0) {
                warnings.add(warning(block.label()));
            }
        }
        if (arrays.isEmpty()) {
            for (LlmJson.Parsed parsed : LlmJson.select(input, LlmJson.Policy.ALL_ARRAYS).blocks()) {
                arrays.add(parsed.node());
            }
        }
        return new Result(arrays, warnings);
    }

    private static String warning(String label) {
        return (label == null ? "во входе" : "в выходе «" + label + "»")
                + " JSON повреждён — часть объектов могла быть пропущена";
    }

    /** Блоки по заголовкам «=== РЕЗУЛЬТАТ ОТ … ===»; текст до первого заголовка — блок без метки (если не пуст). */
    private static List<Block> blocks(String text) {
        List<Block> blocks = new ArrayList<>();
        Matcher header = HEADER.matcher(text);
        String label = null;
        boolean error = false;
        int start = 0;
        while (header.find()) {
            addBlock(blocks, new Block(label, error, text.substring(start, header.start())));
            label = header.group(1);
            error = header.group(2) != null;
            start = header.end();
        }
        addBlock(blocks, new Block(label, error, text.substring(start)));
        return blocks;
    }

    private static void addBlock(List<Block> blocks, Block block) {
        if (block.label() != null || !block.text().isBlank()) {
            blocks.add(block);
        }
    }

    /**
     * Массивы одного блока — в общий список: лишние кавычки «""ключ":» убираются, при незакрытом литерале
     * сканирование пересинхронизируется.
     *
     * @param text   текст блока
     * @param arrays найденные массивы
     * @return {@code true}, если разметка блока повреждена
     */
    private static boolean scanBlock(String text, List<JsonNode> arrays) {
        String repaired = withoutDoubledKeyQuotes(text);
        String work = repaired == null ? text : repaired;
        boolean damaged = repaired != null;
        int from = 0;
        boolean inSync = false;
        for (int resync = 0; resync < MAX_RESYNC && !inSync; resync++) {
            int multiline = damageFrom(work, from);
            if (multiline == IN_SYNC) {
                inSync = true;
            } else {
                damaged = true;
                int next = multiline < 0 ? -1 : nextJsonLine(work, multiline);
                if (next < 0) {
                    inSync = true;
                } else {
                    addArrays(work.substring(from, next), arrays);
                    from = next;
                }
            }
        }
        addArrays(work.substring(from), arrays);
        return damaged;
    }

    private static void addArrays(String part, List<JsonNode> arrays) {
        for (LlmJson.Parsed parsed : LlmJson.allOutsideLiterals(part, LlmJson.ARRAY_WITH_OBJECTS_OR_EMPTY).blocks()) {
            arrays.add(parsed.node());
        }
    }

    /**
     * Текст без лишней кавычки перед ключом объекта: «""ключ":» → «"ключ":», если перед «""» (через пробелы и
     * табуляции) стоит «{», «,», перевод строки или начало текста.
     *
     * @param text текст блока
     * @return исправленный текст либо {@code null}, если исправлять нечего
     */
    private static String withoutDoubledKeyQuotes(String text) {
        StringBuilder sb = null;
        int copied = 0;
        int at = text.indexOf(DOUBLED_QUOTE);
        while (at >= 0) {
            if (!keyPositionBefore(text, at) || !keyFollows(text, at + 2)) {
                at = text.indexOf(DOUBLED_QUOTE, at + 1);
                continue;
            }
            sb = sb == null ? new StringBuilder(text.length()) : sb;
            sb.append(text, copied, at + 1);
            copied = at + 2;
            at = text.indexOf(DOUBLED_QUOTE, copied);
        }
        return sb == null ? null : sb.append(text, copied, text.length()).toString();
    }

    /** Перед позицией (через пробелы и табуляции) — начало текста, «{», «,» или перевод строки. */
    private static boolean keyPositionBefore(String text, int at) {
        int i = at - 1;
        while (i >= 0 && (text.charAt(i) == ' ' || text.charAt(i) == '\t')) {
            i--;
        }
        return i < 0 || "{,\n\r".indexOf(text.charAt(i)) >= 0;
    }

    /** С позиции — ключ (буква, цифра или «_» в начале, без кавычек и переводов строки) и «"» с «:» после пробелов. */
    private static boolean keyFollows(String text, int from) {
        if (from >= text.length() || !Character.isLetterOrDigit(text.charAt(from)) && text.charAt(from) != '_') {
            return false;
        }
        int limit = Math.min(text.length(), from + MAX_KEY);
        int close = from;
        while (close < limit && text.charAt(close) != '"' && text.charAt(close) != '\n') {
            close++;
        }
        if (close >= limit || text.charAt(close) != '"') {
            return false;
        }
        int colon = close + 1;
        while (colon < text.length() && (text.charAt(colon) == ' ' || text.charAt(colon) == '\t')) {
            colon++;
        }
        return colon < text.length() && text.charAt(colon) == ':';
    }

    /**
     * Литералы от позиции (вне литерала) до конца текста — по тем же правилам, что индекс скобок: «"» открывает и
     * закрывает литерал, внутри литерала «\» экранирует следующий символ.
     *
     * @param text текст блока
     * @param from позиция вне литерала
     * @return {@link #IN_SYNC}, если все литералы закрыты; иначе начало первого литерала с переводом строки
     *         (-1 — такого литерала нет)
     */
    private static int damageFrom(String text, int from) {
        int multiline = -1;
        int newline = text.indexOf('\n', from);
        int open = text.indexOf('"', from);
        while (open >= 0) {
            int close = literalEnd(text, open);
            if (newline >= 0 && newline < open) {
                newline = text.indexOf('\n', open);
            }
            if (multiline < 0 && newline >= 0 && newline < close) {
                multiline = open;
            }
            if (close >= text.length()) {
                return multiline;
            }
            open = text.indexOf('"', close + 1);
        }
        return IN_SYNC;
    }

    /** Закрывающая кавычка литерала, открытого в {@code open}, либо длина текста, если литерал не закрыт. */
    private static int literalEnd(String text, int open) {
        int i = open + 1;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (c == '\\') {
                i += 2;
            } else if (c == '"') {
                return i;
            } else {
                i++;
            }
        }
        return text.length();
    }

    /**
     * Начало первой строки после позиции, которая после пробелов и табуляций начинается с «{» или «[».
     *
     * @param text  текст блока
     * @param after позиция, после которой искать
     * @return начало строки либо -1
     */
    private static int nextJsonLine(String text, int after) {
        int newline = text.indexOf('\n', after);
        while (newline >= 0) {
            int at = newline + 1;
            while (at < text.length() && (text.charAt(at) == ' ' || text.charAt(at) == '\t')) {
                at++;
            }
            if (at < text.length() && (text.charAt(at) == '{' || text.charAt(at) == '[')) {
                return newline + 1;
            }
            newline = text.indexOf('\n', at);
        }
        return -1;
    }
}
