package ru.sber.cs.ai.gigame.utils;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Приведение значений ответов API к ограничениям статической спецификации
 * {@code openapi/gigame.yaml}.
 * <p>
 * Корпоративный шлюз SOWA проверяет ответы по этой спецификации (maxLength
 * строк, maxItems массивов, диапазоны чисел, длина дат) и блокирует
 * несоответствующий ответ целиком. Полные данные остаются в БД — усекается
 * только отдаваемое представление.
 */
public final class SchemaLimitUtils {

    /**
     * Пометка усечения строки по умолчанию.
     */
    public static final String ELLIPSIS = "…";

    /**
     * maxLength полей filename (KBDocumentResponse, DocumentViewResponse) в спецификации.
     */
    public static final int FILENAME_MAX_LENGTH = 255;

    /**
     * Символы, запрещённые pattern полей filename в спецификации: обратная и прямая
     * косая черта, двоеточие, звёздочка, вопросительный знак, кавычка, угловые скобки, вертикальная черта.
     */
    private static final Pattern FORBIDDEN_FILENAME_CHARS = Pattern.compile("[\\\\/:*?\"<>|]");

    /**
     * Максимальная длина хвоста после последней точки, который считается
     * расширением файла и сохраняется при усечении имени.
     */
    private static final int MAX_EXTENSION_LENGTH = 16;

    private SchemaLimitUtils() {
    }

    /**
     * Усекает строку до лимита схемы с многоточием на конце.
     *
     * @param value     исходная строка (может быть {@code null})
     * @param maxLength maxLength поля по спецификации
     * @return строка не длиннее лимита; {@code null} и короткие значения — как есть
     */
    public static String clip(String value, int maxLength) {
        return clip(value, maxLength, ELLIPSIS);
    }

    /**
     * Усекает строку до лимита схемы с заданной пометкой усечения.
     * Результат вместе с пометкой не длиннее {@code maxLength}; суррогатная
     * пара на границе усечения не разрывается.
     *
     * @param value     исходная строка (может быть {@code null})
     * @param maxLength maxLength поля по спецификации
     * @param marker    пометка, дописываемая к усечённой строке
     * @return строка не длиннее лимита; {@code null} и короткие значения — как есть
     */
    public static String clip(String value, int maxLength, String marker) {
        if (value == null || value.length() <= maxLength) {
            return value;
        }
        String suffix = marker != null && marker.length() < maxLength ? marker : "";
        int end = maxLength - suffix.length();
        if (end > 0 && Character.isHighSurrogate(value.charAt(end - 1))) {
            end--;
        }
        return value.substring(0, end) + suffix;
    }

    /**
     * Первые {@code maxItems} элементов списка (maxItems массива по спецификации).
     * Берутся именно первые: клиенты дочитывают такие списки по возрастающему
     * индексу, и срез «последних» сдвинул бы индексы.
     *
     * @param items    исходный список (может быть {@code null})
     * @param maxItems maxItems массива по спецификации
     * @param <T>      тип элементов
     * @return список не длиннее лимита; {@code null} и короткие списки — как есть
     */
    public static <T> List<T> firstItems(List<T> items, int maxItems) {
        if (items == null || items.size() <= maxItems) {
            return items;
        }
        return new ArrayList<>(items.subList(0, maxItems));
    }

    /**
     * Первые {@code maxItems - 1} элементов списка и последний элемент
     * (maxItems массива по спецификации). Нужен там, где последний элемент
     * важнее середины: упавший шаг прогона обычно последний, и по нему как раз
     * открывают подробный отчёт.
     *
     * @param items    исходный список (может быть {@code null})
     * @param maxItems maxItems массива по спецификации (не меньше 1)
     * @param <T>      тип элементов
     * @return список не длиннее лимита; {@code null} и короткие списки — как есть
     */
    public static <T> List<T> firstItemsAndLast(List<T> items, int maxItems) {
        if (items == null || items.size() <= maxItems) {
            return items;
        }
        List<T> limited = new ArrayList<>(items.subList(0, maxItems - 1));
        limited.add(items.get(items.size() - 1));
        return limited;
    }

    /**
     * Имя файла для ответа по pattern схемы: символы {@code \ / : * ? " < > |}
     * заменяются на «_», имя длиннее 255 символов усекается с многоточием
     * с сохранением расширения. Хранимое имя не меняется.
     *
     * @param filename исходное имя файла (может быть {@code null})
     * @return имя, соответствующее схеме; {@code null} — как есть
     */
    public static String safeFilename(String filename) {
        if (filename == null) {
            return null;
        }
        String safe = FORBIDDEN_FILENAME_CHARS.matcher(filename).replaceAll("_");
        if (safe.length() <= FILENAME_MAX_LENGTH) {
            return safe;
        }
        int dot = safe.lastIndexOf('.');
        String extension = dot > 0 && safe.length() - dot <= MAX_EXTENSION_LENGTH ? safe.substring(dot) : "";
        String base = safe.substring(0, safe.length() - extension.length());
        return clip(base, FILENAME_MAX_LENGTH - extension.length()) + extension;
    }

    /**
     * Ограничивает целое число диапазоном схемы.
     *
     * @param value значение
     * @param min   minimum по спецификации
     * @param max   maximum по спецификации
     * @return значение в диапазоне {@code [min, max]}
     */
    public static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    /**
     * Дата для ответа: UTC с точностью до микросекунд. Строка вида
     * {@code 2026-09-15T07:11:12.123456Z} не длиннее 27 символов при maxLength 32
     * независимо от часового пояса JVM и точности системных часов.
     *
     * @param value дата (может быть {@code null})
     * @return та же точка времени в UTC, усечённая до микросекунд
     */
    public static OffsetDateTime utcMicros(OffsetDateTime value) {
        return value == null ? null
                : value.withOffsetSameInstant(ZoneOffset.UTC).truncatedTo(ChronoUnit.MICROS);
    }
}
