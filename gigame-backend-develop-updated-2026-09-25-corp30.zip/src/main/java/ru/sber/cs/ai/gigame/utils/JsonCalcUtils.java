package ru.sber.cs.ai.gigame.utils;

import ru.sber.cs.ai.gigame.exception.ScenarioException;

import java.lang.ref.SoftReference;
import java.math.BigDecimal;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Deque;
import java.util.List;

/**
 * Общие хелперы для детерминированных узлов (calc, aggregate):
 * терпимый разбор чисел и JSON-фрагментов из текстовых ответов LLM.
 */
public final class JsonCalcUtils {

    /** Сколько фаз (сканов с разных стартовых позиций) держит индекс скобок одного текста. */
    static final int MAX_PHASES = 3;

    /** Индекс скобок последнего текста потока: циклы вызывающих по каждой скобке остаются линейными. */
    // NOSONAR java:S5164 — умышленный микро-кэш потока: SoftReference снимает риск утечки, вызов remove() ломал бы кэш
    private static final ThreadLocal<SoftReference<BracketIndex>> LAST_INDEX = new ThreadLocal<>();

    private JsonCalcUtils() {
    }

    /**
     * Чинит десятичные запятые в числах JSON («: 18196721,31» → «: 18196721.31»):
     * модели на русском регулярно пишут запятую как разделитель дробной части.
     * Замена выполняется только вне строковых значений и только для запятой, за
     * которой идут ровно одна-две цифры и не цифра (или конец): массив чисел
     * {@code [1,2,3]} остаётся списком, а не превращается в {@code 1.2.3}.
     *
     * @param json фрагмент JSON
     * @return фрагмент с точками в числах
     */
    public static String sanitizeDecimalCommas(String json) {
        StringBuilder sb = new StringBuilder(json.length());
        int i = 0;
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == '"') {
                i = appendStringLiteral(json, i, sb) + 1;
            } else if (isDecimalComma(json, i)) {
                sb.append('.');
                i++;
            } else {
                sb.append(c);
                i++;
            }
        }
        return sb.toString();
    }

    /**
     * Запятая между цифрой и одной-двумя цифрами, за которыми не цифра, — десятичный
     * разделитель (копейки). Запятая, за которой цифры продолжаются, за которой следует
     * ещё одна запятая с цифрой («1,2,3») или перед числом которой уже стоит такая запятая
     * («…,2,3]»), — разделитель элементов списка.
     */
    private static boolean isDecimalComma(String json, int i) {
        if (json.charAt(i) != ',' || i == 0 || !Character.isDigit(json.charAt(i - 1))) {
            return false;
        }
        int digits = 0;
        int j = i + 1;
        while (j < json.length() && Character.isDigit(json.charAt(j))) {
            digits++;
            j++;
        }
        if (digits < 1 || digits > 2) {
            return false;
        }
        if (j + 1 < json.length() && json.charAt(j) == ',' && Character.isDigit(json.charAt(j + 1))) {
            return false;
        }
        int k = i - 1;
        while (k >= 0 && Character.isDigit(json.charAt(k))) {
            k--;
        }
        return k < 1 || json.charAt(k) != ',' || !Character.isDigit(json.charAt(k - 1));
    }

    /**
     * Копирует строковый литерал (начиная с открывающей кавычки в позиции {@code start})
     * как есть, с учётом экранирования.
     *
     * @return индекс закрывающей кавычки (или конец текста, если литерал не закрыт)
     */
    private static int appendStringLiteral(String json, int start, StringBuilder sb) {
        sb.append('"');
        int i = start + 1;
        while (i < json.length()) {
            char c = json.charAt(i);
            sb.append(c);
            if (c == '\\' && i + 1 < json.length()) {
                sb.append(json.charAt(i + 1));
                i += 2;
            } else if (c == '"') {
                return i;
            } else {
                i++;
            }
        }
        return json.length();
    }

    /**
     * Индекс закрывающей скобки, парной открывающей в позиции {@code start}
     * ('{' или '['), с учётом строковых литералов.
     * <p>
     * Ответ берётся из индекса скобок текста ({@link BracketIndex}), который строится
     * одним проходом и кэшируется для последнего текста потока: перебор всех скобок
     * оборванного ответа вызывающим кодом остаётся линейным, а не квадратичным.
     *
     * @return индекс закрывающей скобки или -1, если блок не сбалансирован
     */
    public static int balancedEnd(String text, int start) {
        return indexOf(text).matchOf(start);
    }

    /**
     * Индекс скобок текста: для последнего текста потока — из кэша.
     *
     * @param text текст
     * @return индекс скобок
     */
    public static BracketIndex indexOf(String text) {
        SoftReference<BracketIndex> ref = LAST_INDEX.get();
        BracketIndex index = ref == null ? null : ref.get();
        if (index == null || text == null || !index.text.equals(text)) {
            index = new BracketIndex(text);
            LAST_INDEX.set(new SoftReference<>(index));
        }
        return index;
    }

    /**
     * Прямой скан от позиции {@code start}: старый алгоритм, один проход до парной скобки.
     *
     * @return индекс закрывающей скобки или -1
     */
    static int scanBalancedEnd(String text, int start) {
        char open = text.charAt(start);
        char close = open == '{' ? '}' : ']';
        int depth = 0;
        int i = start;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (c == '"') {
                i = skipStringLiteral(text, i) + 1;
            } else if (c == open) {
                depth++;
                i++;
            } else if (c == close) {
                depth--;
                if (depth == 0) {
                    return i;
                }
                i++;
            } else {
                i++;
            }
        }
        return -1;
    }

    /**
     * Пропускает строковый литерал (начиная с открывающей кавычки в позиции {@code start})
     * с учётом экранирования.
     *
     * @return индекс закрывающей кавычки (или конец текста, если литерал не закрыт)
     */
    private static int skipStringLiteral(String text, int start) {
        int i = start + 1;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (c == '\\') {
                i += 2;
            } else if (c == '"') {
                return i;
            } else {
                i++;
            }
        }
        return text.length();
    }

    /**
     * Терпимое преобразование в BigDecimal: убирает пробелы (в т.ч. неразрывные),
     * запятую считает десятичной точкой.
     *
     * @param raw  значение (число или строка)
     * @param what описание значения для сообщения об ошибке
     * @throws ScenarioException если значение не является числом
     */
    public static BigDecimal toDecimal(Object raw, String what) {
        try {
            if (raw == null) {
                return BigDecimal.ZERO;
            }
            // убираем любые пробельные разделители разрядов (включая NBSP/узкий NBSP)
            String s = String.valueOf(raw).replaceAll("[\\s\\u00A0\\u202F\\u2009]+", "").replace(",", ".");
            return new BigDecimal(s);
        } catch (Exception e) {
            throw new ScenarioException("Не удалось прочитать число («" + raw + "») для: " + what);
        }
    }

    /**
     * Число без экспоненты и без хвостовых нулей: 1080360.000 → 1080360; 0.850 → 0.85.
     */
    public static String fmtPlain(BigDecimal v) {
        BigDecimal s = v.stripTrailingZeros();
        if (s.scale() < 0) {
            s = s.setScale(0);
        }
        return s.toPlainString();
    }

    /**
     * Индекс парных скобок текста, построенный одним проходом.
     * <p>
     * Результат прямого скана от позиции зависит от «фазы» строковых литералов: скан,
     * начатый вне литерала, видит те же границы литералов, что и скан от начала текста;
     * скан от скобки внутри литерала — другие. Первая фаза — скан от начала; для скобки,
     * которую первая фаза считает внутри литерала, строится следующая фаза сканом от неё
     * (не более {@value #MAX_PHASES}), дальше — прямой скан. Результат совпадает со старым
     * посимвольным алгоритмом, а суммарная стоимость перебора всех скобок линейна.
     */
    public static final class BracketIndex {

        private final String text;
        private final List<Phase> phases = new ArrayList<>();

        BracketIndex(String text) {
            this.text = text;
        }

        /**
         * Индекс парной закрывающей скобки.
         *
         * @param start позиция открывающей скобки ('{' или '[')
         * @return индекс закрывающей скобки или -1, если блок не сбалансирован
         */
        public int matchOf(int start) {
            char c = text.charAt(start);
            if (c != '{' && c != '[') {
                return scanBalancedEnd(text, start);
            }
            for (Phase phase : phases) {
                if (phase.covers(start)) {
                    return phase.match[start];
                }
            }
            if (phases.size() >= MAX_PHASES) {
                return scanBalancedEnd(text, start);
            }
            Phase phase = new Phase(text, phases.isEmpty() ? 0 : start);
            phases.add(phase);
            return phase.covers(start) ? phase.match[start] : scanBalancedEnd(text, start);
        }

        /**
         * Позиции открывающих скобок, которые первая фаза видит вне строковых литералов.
         *
         * @return позиции по возрастанию
         */
        public List<Integer> opensOutsideLiterals() {
            return opens(true);
        }

        /**
         * Позиции открывающих скобок внутри строковых литералов (по первой фазе) — запасные
         * кандидаты: прежний посимвольный перебор рассматривал и их.
         *
         * @return позиции по возрастанию
         */
        public List<Integer> opensInsideLiterals() {
            return opens(false);
        }

        private List<Integer> opens(boolean outside) {
            if (phases.isEmpty()) {
                phases.add(new Phase(text, 0));
            }
            Phase first = phases.get(0);
            List<Integer> opens = new ArrayList<>();
            for (int i = 0; i < text.length(); i++) {
                char c = text.charAt(i);
                if ((c == '{' || c == '[') && first.outside.get(i) == outside) {
                    opens.add(i);
                }
            }
            return opens;
        }

        /** Одна фаза: скан от позиции {@code from} вне литерала. */
        private static final class Phase {

            private final int from;
            private final int[] match;
            private final BitSet outside = new BitSet();

            Phase(String text, int from) {
                this.from = from;
                this.match = new int[text.length()];
                scan(text);
            }

            boolean covers(int position) {
                return position >= from && outside.get(position);
            }

            private void scan(String text) {
                Deque<Integer> curly = new ArrayDeque<>();
                Deque<Integer> square = new ArrayDeque<>();
                int i = from;
                while (i < text.length()) {
                    char c = text.charAt(i);
                    if (c == '"') {
                        i = skipStringLiteral(text, i) + 1;
                        continue;
                    }
                    if (c == '{' || c == '[' || c == '}' || c == ']') {
                        outside.set(i);
                        match[i] = -1;
                        track(c == '{' || c == '}' ? curly : square, c == '{' || c == '[', i);
                    }
                    i++;
                }
            }

            private void track(Deque<Integer> stack, boolean opening, int i) {
                if (opening) {
                    stack.push(i);
                } else if (!stack.isEmpty()) {
                    match[stack.pop()] = i;
                }
            }
        }
    }
}
