package ru.sber.cs.ai.gigame.service.scenario;

import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.CannotCreateTransactionException;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
public class ScenarioRunStepService {

    static final String KEY_DOCUMENTS_TEXT = "documents_text";
    static final String KEY_PREVIOUS_OUTPUT = "previous_output";
    static final String KEY_RESULT = "result";
    static final String KEY_ERROR = "error";
    /** Имена файлов документов прогона (шаг входного узла) — для возобновления. */
    static final String KEY_DOC_NAMES = "doc_names";

    /** Число повторов сохранения шага при временном сбое БД (исчерпан пул соединений и т.п.). */
    static final int SAVE_RETRIES = 2;

    private static final String MSG_UNKNOWN_ERROR = "Неизвестная ошибка";
    /** Разделитель документов в хэшируемой склейке (см. {@link #documentsSummaryOfTexts}). */
    private static final byte[] DOC_SEPARATOR_BYTES = "\n\n".getBytes(StandardCharsets.UTF_8);

    private final ScenarioRunStepRepository stepRepository;

    /** Пауза перед повтором сохранения, мс (умножается на номер попытки); в тестах уменьшается. */
    private long retryPauseMs = 500;

    public ScenarioRunStepService(ScenarioRunStepRepository stepRepository) {
        this.stepRepository = stepRepository;
    }

    /**
     * Краткая сводка документов узла вместо полного текста: перечень меток DOC_i и SHA-256
     * склейки текстов. Полный текст комплекта хранится один раз — в результате шага
     * входного узла; повторять его в каждом шаге (4–9 копий за прогон) нельзя по объёму.
     *
     * @param docLabels     метки документов узла (DOC_i)
     * @param documentsText склейка текстов документов узла
     * @return «DOC_1, DOC_2\nsha256:…» либо пустая строка, если документов нет
     */
    public static String documentsSummary(List<String> docLabels, String documentsText) {
        if (docLabels == null || docLabels.isEmpty()) {
            return "";
        }
        return String.join(", ", docLabels) + "\nsha256:" + sha256(documentsText == null ? "" : documentsText);
    }

    /**
     * Та же сводка, что {@link #documentsSummary(List, String)}, но по отдельным текстам документов:
     * SHA-256 считается инкрементально (документы через «\n\n», как в склейке), без сборки комплекта
     * в одну строку и без байтов всего комплекта в памяти — на каждом узле склейка давала ещё две
     * копии всех документов прогона. Хэш совпадает с хэшем склейки тех же текстов.
     *
     * @param docLabels метки документов узла (DOC_i)
     * @param texts     тексты документов узла в том же порядке
     * @return «DOC_1, DOC_2\nsha256:…» либо пустая строка, если документов нет
     */
    public static String documentsSummaryOfTexts(List<String> docLabels, List<String> texts) {
        if (docLabels == null || docLabels.isEmpty()) {
            return "";
        }
        MessageDigest digest = sha256Digest();
        boolean first = true;
        for (String text : texts == null ? List.<String>of() : texts) {
            if (!first) {
                digest.update(DOC_SEPARATOR_BYTES);
            }
            first = false;
            digest.update(text.getBytes(StandardCharsets.UTF_8));
        }
        return String.join(", ", docLabels) + "\nsha256:" + HexFormat.of().formatHex(digest.digest());
    }

    private static String sha256(String text) {
        return HexFormat.of().formatHex(sha256Digest().digest(text.getBytes(StandardCharsets.UTF_8)));
    }

    private static MessageDigest sha256Digest() {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    public ScenarioRunStep setScenarioStepStatusRunning(UUID runId, String nodeId, ScenarioNodeType nodeType) {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId(nodeId);
        step.setNodeType(nodeType.toString());
        step.setStatus(ScenarioStatus.RUNNING.getValue());
        step.setStartedAt(OffsetDateTime.now());
        return saveWithRetry(step);
    }

    public ScenarioRunStep setScenarioStepStatusCompleted(ScenarioRunStep step,
                                                          String previousOutput,
                                                          String documentsText,
                                                          String output,
                                                          String prompt) {
        return setScenarioStepStatusCompleted(step, previousOutput, documentsText, output, prompt, null);
    }

    public ScenarioRunStep setScenarioStepStatusCompleted(ScenarioRunStep step,
                                                          String previousOutput,
                                                          String documentsText,
                                                          String output,
                                                          String prompt,
                                                          Integer tokensUsed) {
        return setScenarioStepStatusCompleted(step, previousOutput, documentsText, output, prompt, tokensUsed, null);
    }

    /**
     * Завершает шаг одним UPDATE: входные данные (сводка документов, вклады родителей),
     * результат, промпт, токены и — для шага входного узла — имена файлов документов
     * (ключ «doc_names», раньше писался отдельным UPDATE).
     *
     * @param step           шаг прогона
     * @param previousOutput вклады родителей
     * @param documentsText  сводка документов узла ({@link #documentsSummary})
     * @param output         результат узла
     * @param prompt         использованный промпт
     * @param tokensUsed     потрачено токенов (может быть {@code null})
     * @param docNames       имена файлов документов через перевод строки (только входной узел, иначе {@code null})
     * @return сохранённый шаг
     */
    public ScenarioRunStep setScenarioStepStatusCompleted(ScenarioRunStep step,
                                                          String previousOutput,
                                                          String documentsText,
                                                          String output,
                                                          String prompt,
                                                          Integer tokensUsed,
                                                          String docNames) {
        step.setStatus(ScenarioStatus.COMPLETED.getValue());
        step.setInputData(Map.of(
                KEY_DOCUMENTS_TEXT, documentsText,
                KEY_PREVIOUS_OUTPUT, previousOutput));
        Map<String, String> outputData = new HashMap<>();
        outputData.put(KEY_RESULT, output);
        if (docNames != null && !docNames.isEmpty()) {
            outputData.put(KEY_DOC_NAMES, docNames);
        }
        step.setOutputData(outputData);
        step.setPromptUsed(prompt);
        step.setTokensUsed(tokensUsed);
        step.setCompletedAt(OffsetDateTime.now());
        return saveWithRetry(step);
    }

    /**
     * Копирует завершённый шаг старого прогона в новый (возобновлённый) прогон,
     * чтобы цепочка повторных возобновлений видела восстановленные LLM-узлы.
     */
    public ScenarioRunStep copyStepToRun(UUID newRunId, ScenarioRunStep oldStep) {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(newRunId);
        step.setNodeId(oldStep.getNodeId());
        step.setNodeType(oldStep.getNodeType());
        step.setStatus(ScenarioStatus.COMPLETED.getValue());
        step.setInputData(oldStep.getInputData());
        step.setOutputData(oldStep.getOutputData());
        step.setPromptUsed(oldStep.getPromptUsed());
        step.setTokensUsed(oldStep.getTokensUsed());
        step.setStartedAt(OffsetDateTime.now());
        step.setCompletedAt(OffsetDateTime.now());
        return saveWithRetry(step);
    }

    /**
     * Дописывает ключ в выходные данные сохранённого шага (Map.of неизменяем).
     *
     * @param step  шаг прогона
     * @param key   ключ выходных данных
     * @param value значение
     * @return обновлённый шаг
     */
    public ScenarioRunStep appendOutputData(ScenarioRunStep step, String key, String value) {
        var data = new HashMap<>(
                step.getOutputData() != null ? step.getOutputData() : Map.of());
        data.put(key, value);
        step.setOutputData(data);
        return saveWithRetry(step);
    }

    public ScenarioRunStep setScenarioStepStatusFailed(ScenarioRunStep step,
                                                       String messageText) {
        step.setStatus(ScenarioStatus.FAILED.getValue());
        step.setOutputData(Map.of(KEY_ERROR, messageText != null ? messageText : MSG_UNKNOWN_ERROR));
        step.setCompletedAt(OffsetDateTime.now());
        return saveWithRetry(step);
    }

    /**
     * Сохраняет шаг, повторяя попытку при временном сбое БД: пул соединений исчерпан
     * (OCR и эмбеддинги держали соединения), обрыв соединения, тупик. Без повтора
     * такой сбой ронял весь прогон через handleNodeError.
     *
     * @param step шаг
     * @return сохранённый шаг
     */
    ScenarioRunStep saveWithRetry(ScenarioRunStep step) {
        int attempt = 1;
        while (true) {
            try {
                return stepRepository.save(step);
            } catch (RuntimeException e) {
                if (attempt > SAVE_RETRIES || !isRetryable(e)) {
                    throw e;
                }
                log.warn("Сохранение шага {} не удалось (попытка {} из {}): {} — повтор",
                        step.getNodeId(), attempt, SAVE_RETRIES + 1, e.getMessage());
                pause(retryPauseMs * attempt);
                attempt++;
            }
        }
    }

    /**
     * Сбой, который имеет смысл повторить: временный сбой доступа к данным, недоступность
     * ресурса (в том числе таймаут получения соединения Hikari) или невозможность открыть
     * транзакцию из-за отсутствия соединения.
     */
    static boolean isRetryable(RuntimeException e) {
        return e instanceof TransientDataAccessException
                || e instanceof DataAccessResourceFailureException
                || e instanceof CannotCreateTransactionException;
    }

    private static void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
    }

    void setRetryPauseMs(long retryPauseMs) {
        this.retryPauseMs = retryPauseMs;
    }
}
