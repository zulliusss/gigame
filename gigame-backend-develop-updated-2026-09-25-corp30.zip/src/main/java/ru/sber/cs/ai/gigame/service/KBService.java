package ru.sber.cs.ai.gigame.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.dto.document.DocumentViewResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBDetailResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.FileUtils;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;
import ru.sber.cs.ai.gigame.utils.UserUtils;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Сервис баз знаний.
 * <p>
 * Управляет базами знаний, их документами и векторной индексацией.
 * <p>
 * Основные функции:
 * <ul>
 *   <li>Создание и управление базами знаний (CRUD)</li>
 *   <li>Добавление и удаление документов в базах знаний</li>
 *   <li>Асинхронная индексация документов через векторное хранилище</li>
 *   <li>Поддержка ручного и автоматического переиндексирования</li>
 * </ul>
 *
 * @see KnowledgeBase
 * @see KBDocument
 * @see Document
 * @see EmbeddingService
 * @see GigaChatClient
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class KBService {

    /**
     * Сообщение об ошибке при отсутствии базы знаний.
     */
    public static final String KNOWLEDGE_BASE_NOT_FOUND = "Knowledge base not found: ";

    /**
     * maxLength поля extracted_text (DocumentViewResponse) в статической
     * спецификации: больший ответ корп. шлюз SOWA блокирует целиком. Полный
     * текст остаётся в БД.
     */
    static final int EXTRACTED_TEXT_MAX_LENGTH = 500_000;

    /** Предупреждение в ответе при повторной загрузке того же файла (в БД не пишется). */
    static final String DUPLICATE_SKIPPED = "файл уже есть в этой базе знаний — повторная загрузка пропущена";

    /** Причина в error_message, когда очередь фоновой обработки переполнена. */
    static final String QUEUE_FULL = "очередь индексации переполнена — удалите документ из базы "
            + "и загрузите файл заново позже";

    private static final String STATUS_PROCESSING = "processing";
    private static final String STATUS_ERROR = "error";

    private final KnowledgeBaseRepository knowledgeBaseRepository;
    private final KBDocumentRepository kbDocumentRepository;
    private final DocumentRepository documentRepository;
    private final DocumentService documentService;
    private final EmbeddingService embeddingService;
    private final DocumentIndexService indexService;
    private final KBUploadProcessor uploadProcessor;

    /**
     * Возвращает список всех баз знаний с возможной фильтрацией по имени.
     *
     * @param search поисковый запрос в имени базы знаний (опционально)
     * @return список баз знаний пользователя
     */
    public List<KBResponse> getKnowledgeBases(String search) {
        String requester = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getKnowledgeBases, search='{}'", requester, search);
        List<KnowledgeBase> kbs;
        if (search != null && !search.isBlank()) {
            kbs = knowledgeBaseRepository.searchAccessible(requester, search);
        } else {
            kbs = knowledgeBaseRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(requester);
        }
        return SchemaLimitUtils.firstItems(
                kbs.stream().map(kb -> KBMapper.toKBResponse(kb, requester)).toList(), KBMapper.MAX_ITEMS);
    }

    /**
     * Проверяет право чтения базы: доступна владельцу и всем, если база общая.
     *
     * @param userId идентификатор пользователя из заголовка
     * @param kb     база знаний
     */
    private void checkReadAccess(String userId, KnowledgeBase kb) {
        log.info("[{}] checkReadAccess, kbId={}, shared={}",
                userId, kb.getId(), kb.isShared());
        if (!kb.isShared()) {
            UserUtils.checkUserId(userId, kb.getUserId());
        }
    }

    /**
     * Проверяет, что пользователь — владелец базы (для изменяющих операций).
     * Общая база доступна остальным только для чтения.
     *
     * @param kbId UUID базы знаний
     */
    public void checkOwner(UUID kbId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] checkOwner, kbId={}", userId, kbId);
        KnowledgeBase kb = knowledgeBaseRepository.findById(kbId)
                .orElseThrow(() -> new NotFoundException(KNOWLEDGE_BASE_NOT_FOUND + kbId));
        UserUtils.checkUserId(userId, kb.getUserId());
    }

    /**
     * Возвращает одну базу знаний со списком документов. Выбрасывает исключение,
     * если база не найдена.
     *
     * @param id UUID базы знаний
     * @return подробная информация о базе знаний
     */
    @Transactional(readOnly = true)
    public KBDetailResponse getKnowledgeBase(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getKnowledgeBase, id={}", userId, id);
        KnowledgeBase kb = knowledgeBaseRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(KNOWLEDGE_BASE_NOT_FOUND + id));
        checkReadAccess(userId, kb);
        // Используем JOIN FETCH запрос для избежания N+1 и LazyInitializationException
        List<KBDocumentResponse> docs = kbDocumentRepository.findByKnowledgeBaseIdWithDocument(id).stream()
                .map(KBMapper::toKBDocumentResponse)
                .toList();
        return KBMapper.toKBDetailResponse(kb, userId, docs);
    }

    /**
     * Создаёт новую базу знаний.
     *
     * @param name        имя базы знаний
     * @param description описание базы знаний (опционально)
     * @return созданная база знаний
     */
    @Transactional
    public KBResponse createKnowledgeBase(String name, String description, Boolean shared) {
        String requester = CurrentUserHolder.getCurrentUser();
        log.info("[{}] createKnowledgeBase, name='{}', shared={}", requester, name, shared);
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName(name);
        kb.setDescription(description);
        kb.setUserId(requester);
        kb.setShared(Boolean.TRUE.equals(shared));
        kb = knowledgeBaseRepository.save(kb);
        return KBMapper.toKBResponse(kb, requester);
    }

    /**
     * Обновляет имя и/или описание базы знаний. Выбрасывает исключение,
     * если база не найдена.
     *
     * @param id          UUID базы знаний
     * @param name        новое имя (опционально)
     * @param description новое описание (опционально)
     * @return обновлённая база знаний
     */
    @Transactional
    public KBResponse updateKnowledgeBase(UUID id, String name, String description, Boolean shared) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] updateKnowledgeBase, id={}, name='{}', shared={}",
                userId, id, name, shared);
        KnowledgeBase kb = knowledgeBaseRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(KNOWLEDGE_BASE_NOT_FOUND + id));
        UserUtils.checkUserId(userId, kb.getUserId());
        if (name != null) {
            kb.setName(name);
        }
        if (description != null) {
            kb.setDescription(description);
        }
        if (shared != null) {
            kb.setShared(shared);
        }
        kb = knowledgeBaseRepository.save(kb);
        return KBMapper.toKBResponse(kb, CurrentUserHolder.getCurrentUser());
    }

    /**
     * Удаляет базу знаний и все её векторные эмбеддинги.
     *
     * @param id UUID базы знаний
     */
    @Transactional
    public void deleteKnowledgeBase(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] deleteKnowledgeBase, id={}", userId, id);
        KnowledgeBase kb = knowledgeBaseRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(KNOWLEDGE_BASE_NOT_FOUND + id));
        UserUtils.checkUserId(userId, kb.getUserId());
        // документы, которые есть только в этой базе: без неё они никому не нужны
        List<UUID> orphans = kbDocumentRepository.findByKnowledgeBaseId(id).stream()
                .map(KBDocument::getDocumentId)
                .filter(documentId -> !referencedByOtherKb(documentId, id))
                .toList();
        embeddingService.deleteKBCollection(id);
        knowledgeBaseRepository.delete(kb);
        deleteDocuments(orphans);
    }

    /**
     * Входит ли документ в другую базу знаний, кроме указанной.
     *
     * @param documentId идентификатор документа
     * @param kbId       база, связь с которой не считается
     * @return {@code true}, если документ есть ещё где-то
     */
    private boolean referencedByOtherKb(UUID documentId, UUID kbId) {
        return kbDocumentRepository.findByDocumentIdWithKnowledgeBase(documentId).stream()
                .anyMatch(link -> !kbId.equals(link.getKnowledgeBase().getId()));
    }

    /**
     * Удаляет документы (текст + эмбеддинги коллекции «doc»), оставшиеся без базы знаний.
     *
     * @param documentIds идентификаторы документов
     */
    private void deleteDocuments(List<UUID> documentIds) {
        for (UUID documentId : documentIds) {
            embeddingService.deleteDocumentChunks(documentId);
            documentRepository.deleteById(documentId);
        }
        if (!documentIds.isEmpty()) {
            log.info("[{}] Удалены документы без базы знаний: {}", CurrentUserHolder.getCurrentUser(), documentIds.size());
        }
    }

    /**
     * Возвращает документ с извлечённым текстом для просмотра источника.
     * <p>
     * Доступ разрешён владельцу документа, а также любому пользователю,
     * если документ входит хотя бы в одну доступную ему базу знаний
     * (собственную или общую).
     *
     * @param id UUID документа
     * @return документ с текстом
     */
    @Transactional(readOnly = true)
    public DocumentViewResponse getDocumentView(UUID id) {
        String requester = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getDocumentView, id={}", requester, id);
        Document doc = documentRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Document not found: " + id));
        boolean allowed = requester.equals(doc.getUserId())
                || kbDocumentRepository.findByDocumentIdWithKnowledgeBase(id).stream()
                        .map(KBDocument::getKnowledgeBase)
                        .anyMatch(kb -> kb.isShared() || requester.equals(kb.getUserId()));
        if (!allowed) {
            throw new AccessDeniedException("Нет доступа к документу " + id);
        }
        return new DocumentViewResponse(
                doc.getId(),
                SchemaLimitUtils.safeFilename(doc.getFilename()),
                SchemaLimitUtils.clip(doc.getContentType(), KBMapper.CONTENT_TYPE_MAX_LENGTH),
                doc.getSizeBytes(),
                clipExtractedText(doc.getExtractedText()),
                SchemaLimitUtils.utcMicros(doc.getCreatedAt())
        );
    }

    /**
     * Усекает извлечённый текст до {@link #EXTRACTED_TEXT_MAX_LENGTH} с пометкой
     * об усечении в конце текста (отдельное поле-признак отклонил бы шлюз:
     * в схеме additionalProperties: false).
     *
     * @param text извлечённый текст (может быть {@code null})
     * @return текст не длиннее лимита спецификации; {@code null} и короткие значения — как есть
     */
    static String clipExtractedText(String text) {
        if (text == null || text.length() <= EXTRACTED_TEXT_MAX_LENGTH) {
            return text;
        }
        return SchemaLimitUtils.clip(text, EXTRACTED_TEXT_MAX_LENGTH,
                "\n\n…[текст документа усечён до " + EXTRACTED_TEXT_MAX_LENGTH + " из "
                        + text.length() + " символов]");
    }

    // -------------------------------------------------------------------------
    // KB document management
    // -------------------------------------------------------------------------

    /**
     * Принимает файл в базу знаний и отвечает сразу документом в статусе
     * {@code processing}; разбор, распознавание скана и индексация идут в фоне
     * ({@link KBUploadProcessor}), статус меняется по завершении.
     * <p>
     * Алгоритм работы:
     * <ol>
     *   <li>Проверяет существование базы знаний и владельца</li>
     *   <li>Проверяет имя, расширение и размер файла; читает содержимое (часть
     *       multipart живёт только до конца запроса)</li>
     *   <li>Повторная загрузка того же файла (имя + SHA-256) в эту базу: если прежняя
     *       попытка завершилась ошибкой — заменяется (переиндексация из нового файла),
     *       иначе пропускается с предупреждением в error_message ответа</li>
     *   <li>Создаёт Document (без текста) и KBDocument со статусом "processing"</li>
     *   <li>Ставит обработку в очередь; при переполнении очереди — статус error с причиной</li>
     * </ol>
     *
     * @param kbId UUID базы знаний
     * @param file загруженный файл
     * @return KBDocumentResponse с начальным статусом
     */
    public KBDocumentResponse addDocumentToKB(UUID kbId, FilePart file) {
        String userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] addDocumentToKB, kbId={}", userId, kbId);
        KnowledgeBase kb = knowledgeBaseRepository.findById(kbId)
                .orElseThrow(() -> new NotFoundException(KNOWLEDGE_BASE_NOT_FOUND + kbId));
        UserUtils.checkUserId(userId, kb.getUserId());
        String filename = file.filename();
        if (filename == null || filename.isBlank()) { // NOSONAR java:S2589 — filename() контрактно nullable (FilePart)
            throw new FileException("Пустое имя файла");
        }
        FileUtils.detectContentType(filename);
        byte[] content = documentService.readContent(file);
        String contentType = FileUtils.detectContentType(filename, content);
        String sha256 = DocumentService.sha256Hex(content);
        Optional<KBDocument> duplicate = kbDocumentRepository.findByKbAndFileContent(kbId, filename, sha256).stream().findFirst();
        if (duplicate.isPresent() && !STATUS_ERROR.equals(duplicate.get().getStatus())) {
            log.warn("[{}] Повторная загрузка «{}» в KB {} пропущена: документ {} в статусе {}", userId, filename,
                    kbId, duplicate.get().getDocumentId(), duplicate.get().getStatus());
            return KBMapper.toKBDocumentResponse(duplicate.get(), DUPLICATE_SKIPPED);
        }
        KBDocument kbDoc = duplicate.map(this::resetForRetry)
                .orElseGet(() -> createPending(kb, filename, contentType, content.length, sha256, userId));
        KBDocument queued = enqueue(kbDoc, filename, contentType, content, userId);
        return KBMapper.toKBDocumentResponse(queued);
    }

    /**
     * Документ и связь с базой для нового файла: текст появится после фонового разбора.
     *
     * @return сохранённая связь KBDocument в статусе processing
     */
    private KBDocument createPending(KnowledgeBase kb, String filename, String contentType, int size,
                                     String sha256, String userId) {
        Document doc = new Document();
        doc.setFilename(filename);
        doc.setContentType(contentType);
        doc.setSizeBytes(size);
        doc.setContentSha256(sha256);
        doc.setUserId(userId);
        doc = documentRepository.save(doc);
        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(doc.getId());
        kbDoc.setDocument(doc);
        kbDoc.setStatus(STATUS_PROCESSING);
        return kbDocumentRepository.save(kbDoc);
    }

    /**
     * Прежняя неудачная попытка того же файла: старые фрагменты удалены, статус
     * снова processing — файл обработается заново.
     *
     * @param failed связь в статусе error
     * @return та же связь в статусе processing
     */
    private KBDocument resetForRetry(KBDocument failed) {
        log.info("[{}] Повторная загрузка «{}» в KB {}: прежняя попытка в error — заменяется",
                CurrentUserHolder.getCurrentUser(), failed.getFilename(), failed.getKnowledgeBase().getId());
        embeddingService.deleteKBDocumentChunks(failed.getKnowledgeBase().getId(), failed.getDocumentId());
        failed.setStatus(STATUS_PROCESSING);
        failed.setErrorMessage(null);
        failed.setChunkCount(0);
        return kbDocumentRepository.save(failed);
    }

    /**
     * Ставит фоновую обработку в очередь. Переполнение очереди пула
     * ({@code spring.task.execution.pool.queue-capacity}) — это статус error
     * с понятной причиной, а не «processing» навсегда и не 500 клиенту.
     *
     * @return связь KBDocument: processing либо error при переполнении
     */
    private KBDocument enqueue(KBDocument kbDoc, String filename, String contentType, byte[] content, String userId) {
        UUID kbId = kbDoc.getKnowledgeBase().getId();
        try {
            uploadProcessor.processAsync(new KBUploadProcessor.PendingUpload(
                    kbId, kbDoc.getDocumentId(), kbDoc.getId(), userId, filename, contentType, content));
            return kbDoc;
        } catch (TaskRejectedException e) {
            log.error("[{}] Очередь индексации переполнена: файл «{}» для KB {} не принят", userId, filename, kbId);
            KBDocument failed = indexService.markIndexingFailed(kbId, kbDoc.getDocumentId(), kbDoc.getId(), QUEUE_FULL);
            return failed != null ? failed : kbDoc;
        }
    }

    /**
     * Удаляет документ из базы знаний: удаляет векторные фрагменты и запись KBDocument.
     * Выбрасывает исключение, если запись KBDocument не найдена.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     */
    @Transactional
    public void removeDocumentFromKB(UUID kbId, UUID documentId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] removeDocumentFromKB, kbId={}, documentId={}",
                userId, kbId, documentId);
        var kb = knowledgeBaseRepository.findById(kbId)
                .orElseThrow(() -> new NotFoundException(KNOWLEDGE_BASE_NOT_FOUND + kbId));
        UserUtils.checkUserId(userId, kb.getUserId());
        KBDocument kbDoc = kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(kbId, documentId)
                .orElseThrow(() -> new NotFoundException(
                        "Документ базы знаний не найден: kbId=" + kbId + " docId=" + documentId));
        removeLink(kbId, kbDoc);
    }

    /**
     * corp23: удаляет из базы знаний документы с указанным именем файла вместе с их фрагментами — замена
     * документа-реестра сценария («в_базу_знаний») при повторном прогоне вместо накопления копий. Документ
     * с тем же содержимым ({@code keepSha256}) не в статусе error остаётся: {@link #addDocumentToKB}
     * распознает его как повтор и не переиндексирует.
     *
     * @param kbId       UUID базы знаний
     * @param filename   имя файла
     * @param keepSha256 SHA-256 нового содержимого — документ с таким хэшем сохраняется ({@code null} — удалять все)
     * @return число удалённых документов
     */
    @Transactional
    public int removeDocumentsByFilename(UUID kbId, String filename, String keepSha256) {
        var userId = CurrentUserHolder.getCurrentUser();
        var kb = knowledgeBaseRepository.findById(kbId)
                .orElseThrow(() -> new NotFoundException(KNOWLEDGE_BASE_NOT_FOUND + kbId));
        UserUtils.checkUserId(userId, kb.getUserId());
        int removed = 0;
        for (KBDocument kbDoc : kbDocumentRepository.findByKbAndFilename(kbId, filename)) {
            boolean same = keepSha256 != null && kbDoc.getDocument() != null
                    && keepSha256.equals(kbDoc.getDocument().getContentSha256());
            if (same && !STATUS_ERROR.equals(kbDoc.getStatus())) {
                continue;
            }
            removeLink(kbId, kbDoc);
            removed++;
        }
        if (removed > 0) {
            log.info("[{}] removeDocumentsByFilename, kbId={}, «{}»: удалено {} прежних документов", userId, kbId, filename, removed);
        }
        return removed;
    }

    /**
     * Удаляет связь документа с базой и его фрагменты; документ, не входящий в другие базы, удаляется целиком.
     *
     * @param kbId  UUID базы знаний
     * @param kbDoc связь документа с базой
     */
    private void removeLink(UUID kbId, KBDocument kbDoc) {
        UUID documentId = kbDoc.getDocumentId();
        boolean keepDocument = referencedByOtherKb(documentId, kbId);
        embeddingService.deleteKBDocumentChunks(kbId, documentId);
        kbDocumentRepository.delete(kbDoc);
        if (!keepDocument) {
            // документ создавался для этой базы (addDocumentToKB) — без неё он сирота
            deleteDocuments(List.of(documentId));
        }
    }
}
