package ru.sber.cs.ai.gigame.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.exception.GigaChatRefusedException;
import ru.sber.cs.ai.gigame.exception.GigaFilterBlockedException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Semaphore;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Распознавание PDF-сканов через файловое хранилище GigaChat.
 * <p>
 * PDF без текстового слоя загружается в хранилище GigaChat вложением к запросу
 * «выпиши содержимое» — модель распознаёт скан и возвращает текст, который
 * дальше идёт по обычному конвейеру сценария (группировка, проверки, суммы).
 * Файл после распознавания удаляется из хранилища.
 * <p>
 * Многостраничный скан распознаётся постранично ({@code app.document.ocr-per-page},
 * по умолчанию включено): на весь документ модель отвечает пересказом
 * (шестистраничная заявка — 2,5 тыс. знаков, состав работ потерян), а на
 * одну страницу — переписывает её полностью (8,4 тыс. знаков на тот же
 * документ). Страницы с текстовым слоем (штамп ЭДО) не распознаются, а
 * берутся как есть, пустые страницы пропускаются; в GigaChat уходит не больше
 * {@code app.document.ocr-max-pages} страниц-изображений, остальные изображения
 * помечаются нераспознанными. Многостраничный документ, распознанный целиком
 * (постраничный режим выключен или PDF не разбирается PDFBox), помечается
 * отдельным префиксом {@link #OCR_WHOLE_PREFIX} — это пересказ.
 * <p>
 * Отказ модели («предоставьте документ», короткий комментарий «из предоставленного фрагмента
 * невозможно выписать…») не принимается за текст: запрос повторяется нейтральным запасным
 * промптом, после второго отказа страница получает маркер {@link #PAGE_REFUSED_MARKER},
 * документ целиком — маркер ручной проверки {@link #DOC_REFUSED_PREFIX}.
 * <p>
 * Выключено по умолчанию: {@code app.document.ocr-via-gigachat=true}
 * (env {@code OCR_VIA_GIGACHAT}) включает. Результат помечается префиксом
 * {@link #OCR_PREFIX} — суммы из скана в итоговой форме стоит перепроверять.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ScanOcrService {

    /** Префикс распознанного текста — виден конвейеру и в итоговой форме. */
    public static final String OCR_PREFIX = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены "
            + "автоматическим распознаванием, суммы рекомендуется перепроверить]";

    /** Префикс многостраничного скана, распознанного целиком: модель пересказывает, строки таблиц могут быть потеряны. */
    public static final String OCR_WHOLE_PREFIX = "[РАСПОЗНАНО ИЗ СКАНА ЦЕЛИКОМ — пересказ модели, "
            + "строки таблиц и суммы могли быть потеряны, документ рекомендуется проверить вручную]";

    /** Начало маркера документа, который модель отказалась распознавать. */
    public static final String DOC_REFUSED_PREFIX = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «";

    /** Маркер страницы, распознать которую модель отказалась (номер страницы — в тексте). */
    static final String PAGE_REFUSED_MARKER = "не распознана: отказ модели]";

    /** Маркер обрыва ответа модели по лимиту токенов (ставит {@link GigaChatClient#chatCompletionWithFile}). */
    static final String TRUNCATED_MARKER = GigaChatClient.TRUNCATED_MARKER;

    /**
     * Ответ вместо текста, когда запрос распознавания отклонён цензором GigaChat (finish_reason=blacklist) либо
     * фильтром GigaFilter: распознаётся как отказ ({@link #isRefusal}), но без повтора запасным промптом — отказ
     * по содержимому повтором другой формулировки не снимается, повтор только тратил бы вызов.
     */
    static final String BLOCKED_REFUSAL = "не могу выполнить: распознавание отклонено (ограничение темы GigaChat "
            + "либо фильтр GigaFilter)";

    /**
     * Формулировка «выпиши содержимое» вместо «перепиши дословно текст вложения»:
     * на просьбу дословной переписки вложения GigaChat отвечает шаблонным отказом,
     * хотя файл обработан и находится в контексте (проверено экспериментально).
     */
    private static final String OCR_PROMPT = """
            Это отсканированный финансовый документ. Выпиши максимально полно его \
            содержимое в текстовом виде: тип и реквизиты документа (номера, даты), \
            стороны (исполнитель, заказчик, ИНН), основание (договор, спецификация), \
            таблицу работ построчно (колонки через « | »), все суммы, включая ИТОГО \
            с НДС. Нечитаемые фрагменты помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя.""";

    /** Запрос на пачку страниц (corp21): каждая страница переписывается под своим маркером, по порядку вложения. */
    private static final String BATCH_PROMPT = """
            Это %d страниц отсканированного финансового документа, по порядку. Для КАЖДОЙ страницы сначала \
            напиши отдельной строкой маркер «=== СТРАНИЦА k ===» (k — номер страницы во вложении, начиная с 1), \
            затем выпиши максимально полно и дословно весь её текст: заголовки, реквизиты (номера, даты), стороны, \
            таблицы построчно (колонки через « | »), все суммы. Нечитаемые фрагменты помечай [НЕЧИТАЕМО]. \
            Ничего не добавляй от себя, не сокращай и не пропускай страницы.""";

    /** Маркер страницы в ответе на пачку: «=== СТРАНИЦА 3 ===». */
    private static final Pattern BATCH_PAGE = Pattern.compile("(?m)^[ \\t]*===\\s*СТРАНИЦА\\s*(\\d+)\\s*===[ \\t]*$");

    /** Постраничный запрос: одна страница переписывается полностью, без пересказа. */
    private static final String PAGE_PROMPT = """
            Это страница отсканированного финансового документа. Выпиши максимально полно \
            и дословно весь текст страницы: заголовки, реквизиты (номера, даты), стороны, \
            таблицы построчно (колонки через « | »), все суммы. Нечитаемые фрагменты \
            помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя и не сокращай.""";

    /**
     * Запасной запрос после отказа модели — без слова «финансовый»: на нефинансовой странице (декларация о стране
     * происхождения АЗК, пустая форма таблицы в приложении договора) первые промпты давали комментарий «невозможно
     * выписать информацию о финансовом документе» вместо текста. Глагол «выпиши», а не «перепиши»: на просьбу
     * переписать вложение дословно GigaChat отвечает шаблонным отказом.
     */
    private static final String FALLBACK_PROMPT = """
            Это отсканированная страница документа. Выпиши дословно весь текст страницы: \
            заголовки, реквизиты, таблицы построчно (колонки через « | »), подписи. Нечитаемые \
            фрагменты помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя, не сокращай и не комментируй.""";

    /**
     * Отказ модели переписать страницу — повтор с нейтральным запасным промптом {@link #FALLBACK_PROMPT}.
     * Просьба приложить текст или файл считается отказом только как обращение к пользователю
     * («Пожалуйста, приложите текст или файл», «приложи файл, который нужно обработать»): указание
     * документа «Приложите к заявке копию лицензии» в начале распознанного текста отказом не является.
     */
    private static final Pattern REFUSAL = Pattern.compile(
            "невозможно сформировать|Из предоставленного контекста|предоставьте полн|не могу выполнить|не содержит текст"
                    + "|не является отсканированным|нет (?:текста|самой) страницы|нет прикрепл[её]нного|нет доступа к содержимому"
                    + "|приложи(?:те)? (?:саму|сам|страницу|документ)|предоставь(?:те)? (?:страницу|текстовую версию)"
                    + "|не могу помочь"
                    + "|(?:пожалуйста,?\\s+приложи(?:те)?|приложи(?:те)?,?\\s+пожалуйста,?)\\s+(?:[^\\s.,]+\\s+)?(?:текст|файл)"
                    + "|приложи(?:те)?\\s+(?:текст|файл)[^.\\n]{0,60}?(?:нужно|необходимо|надо)\\s+(?:обработать|распознать|переписать)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Комментарий модели вместо текста нефинансовой страницы («Из предоставленного фрагмента текста невозможно выписать
     * запрашиваемую информацию о финансовом документе…», «Из предоставленного фрагмента таблицы невозможно однозначно
     * определить содержание финансового документа…»; в сканах Комплекта 5 — «Из предоставленного тобой текста невозможно
     * извлечь…», «Из предоставленного отрывка текста невозможно полностью воспроизвести всю страницу…»). Считается
     * отказом только в коротком ответе ({@link #SHORT_REFUSAL_MAX_CHARS}): распознанный документ с такой оговоркой длиннее.
     */
    private static final Pattern SHORT_REFUSAL = Pattern.compile(
            "из\\s+предоставленного\\s+(?:тобой\\s+)?(?:фрагмента|текста|отрывка|описания)"
                    + "|невозможно\\s+(?:выписать|извлечь|однозначно\\s+определить|полностью\\s+(?:восстановить|воспроизвести))",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Длина ответа, начиная с которой фразы {@link #SHORT_REFUSAL} отказом не считаются: комментарии модели — 250–400 знаков. */
    private static final int SHORT_REFUSAL_MAX_CHARS = 900;
    /**
     * Доля букв и цифр среди непробельных знаков текстового слоя, ниже которой страница считается нечитаемой
     * (штамп ЭДО без ToUnicode). Считаются и цифры: страница-таблица с точным слоем («1 | 15.01.2025 | 1 500 000,00»)
     * букв почти не содержит, и по одной доле букв уходила в OCR — модель подменяла точные суммы, а за лимитом
     * страниц слой терялся вовсе.
     */
    private static final double ALNUM_SHARE_MIN = 0.5;
    /**
     * Доля «служебных» знаков (не буквы, не цифры, не пробелы; повтор одного знака подряд — точечные линии, «-----» —
     * считается один раз), с которой слой считается мусором: у штампа без ToUnicode это кавычки, плюсы и точки
     * вперемешку с одиночными буквами и цифрами, у числовой таблицы — только разделители.
     */
    private static final double JUNK_SHARE_MAX = 0.3;
    /** Нечитаемый слой короткий: страница штампа — сотни знаков, страница текста — тысячи. */
    private static final int GARBLED_MAX_CHARS = 3000;
    /** Маркер нераспознанной страницы: «[страница N не распознана: отказ модели]». */
    private static final Pattern PAGE_REFUSED = Pattern.compile("\\[страница (\\d+) " + Pattern.quote(PAGE_REFUSED_MARKER));
    /** Маркер страниц сверх лимита: «[страницы 41–70 не распознаны: превышен лимит страниц OCR 40 (обработано 40 из 70 страниц)]». */
    private static final Pattern PAGES_OVER_LIMIT = Pattern.compile(
            "\\[страницы ([^\\]]+?) не распознаны: превышен лимит страниц OCR (\\d+)(?: \\(обработано (\\d+) из (\\d+) страниц\\))?]");
    /** Страница, распознанная моделью: «--- страница N ---» без маркера «[страница N не распознана…]» следом. */
    private static final Pattern PAGE_RECOGNIZED = Pattern.compile("--- страница (\\d+) ---\\n(?!\\[страница \\1 не распознана)");
    private static final int REFUSAL_WINDOW = 400;
    private static final double OCR_TEMPERATURE = 0.01;
    private static final String PDF = "application/pdf";

    private final GigaChatClient gigaChatClient;

    @Value("${app.document.ocr-via-gigachat:true}")
    private boolean enabled;

    /** Модель для распознавания (пусто — глобальная модель по умолчанию). */
    @Value("${app.document.ocr-model:}")
    private String ocrModel;

    /** Лимит токенов ответа — страница либо документ целиком. */
    @Value("${app.document.ocr-max-tokens:8000}")
    private int ocrMaxTokens = 8000;

    /** Постраничное распознавание многостраничных сканов. */
    @Value("${app.document.ocr-per-page:true}")
    private boolean ocrPerPage = true;

    /** Максимум распознаваемых страниц одного документа. */
    @Value("${app.document.ocr-max-pages:40}")
    private int ocrMaxPages = 40;

    /**
     * Страниц скана в одном запросе распознавания (corp21): 1 — по одной, как раньше; больше — пачка страниц
     * уходит одним PDF, ответ размечен «=== СТРАНИЦА k ===», неполная или обрезанная пачка перераспознаётся постранично.
     * Ускоряет длинные сканы кратно размеру пачки (85 страниц: ~20 запросов вместо 85).
     */
    @Value("${app.document.ocr-pages-per-request:1}")
    private int ocrPagesPerRequest = 1;

    /** Порог текстового слоя страницы: короче — страница-картинка, распознаётся. */
    @Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars = 40;

    /**
     * Одновременных запросов распознавания к GigaChat. Пул разбора документов —
     * 4 потока, и четыре параллельных OCR упирались в лимит запросов корп-ключа
     * (429 с паузами 30–300 с: 16 сканов Комплекта 4 шли 31 минуту вместо ~10).
     */
    @Value("${app.document.ocr-parallelism:1}")
    private int ocrParallelism = 1;

    private Semaphore ocrSlots;

    /** Кэш результатов распознавания по SHA-256 байтов файла (corp23); {@code null} — без кэша. */
    private OcrResultCache ocrResultCache;

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Распознаёт PDF-скан через GigaChat: постранично для многостраничного
     * документа, целиком для одностраничного.
     *
     * @param filename имя файла (для хранилища и префикса)
     * @param content  содержимое PDF
     * @return распознанный текст с префиксом {@link #OCR_PREFIX} (либо
     *         {@link #OCR_WHOLE_PREFIX} для многостраничного документа, распознанного целиком;
     *         маркер {@link #DOC_REFUSED_PREFIX} при отказе модели)
     */
    public String recognize(String filename, byte[] content) {
        return recognize(filename, content, (file, page, total) -> { });
    }

    /**
     * Ход постраничного распознавания: вызывается после каждой обработанной страницы многостраничного
     * скана (распознанной моделью или взятой из текстового слоя). Счётчик документов загрузки растёт
     * только по завершении документа, и на скане в десятки страниц он «застывал» на десятки минут —
     * слушатель даёт статусу загрузки страницу и их общее число.
     */
    @FunctionalInterface
    public interface OcrProgress {

        /**
         * @param filename имя файла скана
         * @param page     номер обработанной страницы (с 1)
         * @param total    страниц в документе
         */
        void page(String filename, int page, int total);
    }

    /**
     * То же, что {@link #recognize(String, byte[])}, с уведомлением о каждой обработанной странице.
     *
     * @param filename имя файла (для хранилища и префикса)
     * @param content  содержимое PDF
     * @param progress слушатель хода постраничного распознавания
     * @return распознанный текст, как в {@link #recognize(String, byte[])}
     */
    public String recognize(String filename, byte[] content, OcrProgress progress) {
        // corp23: тот же файл (SHA-256 байтов) уже распознавался — текст из кэша без обращения к модели
        return ocrResultCache == null ? doRecognize(filename, content, progress)
                : ocrResultCache.recognize(filename, content, () -> doRecognize(filename, content, progress));
    }

    /**
     * Кэш результатов распознавания (необязателен: без него каждый разбор идёт в модель).
     *
     * @param cache кэш по SHA-256 байтов файла
     */
    @Autowired(required = false)
    public void setOcrResultCache(OcrResultCache cache) {
        this.ocrResultCache = cache;
    }

    private String doRecognize(String filename, byte[] content, OcrProgress progress) {
        log.info("OCR скана через GigaChat: {} ({} КБ)", filename, content.length / 1024);
        int total = pageCount(content);
        List<String> pages = ocrPerPage && total > 1 ? recognizePages(filename, content, progress) : List.of();
        if (!pages.isEmpty()) {
            return OCR_PREFIX + " Документ «" + filename + "»:\n" + String.join("\n\n", pages);
        }
        String text = ask(OCR_PROMPT, pdfName(filename), content);
        if (isRefusal(text) && !BLOCKED_REFUSAL.equals(text)) {
            // одностраничный документ: отказ модели повторяется запасным промптом, как и страница
            log.info("OCR «{}»: отказ модели на документе целиком, повтор с запасным промптом", filename);
            text = ask(FALLBACK_PROMPT, pdfName(filename), content);
        }
        if (isRefusal(text)) {
            log.warn("OCR «{}»: модель отказалась распознавать документ и после запасного промпта", filename);
            return DOC_REFUSED_PREFIX + filename + "» не распознан: модель отказалась распознавать скан. "
                    + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
        }
        String head = (total == 1 ? OCR_PREFIX : OCR_WHOLE_PREFIX) + " Документ «" + filename + "»:\n";
        return head + text;
    }

    /**
     * Имя вложения для хранилища GigaChat всегда с расширением .pdf: изображение (jpg/png) распознаётся как
     * одностраничный PDF ({@link DocumentService#imageToPdf}), а имя файла остаётся исходным для префикса и журнала.
     */
    private static String pdfName(String filename) {
        return filename != null && filename.toLowerCase().endsWith(".pdf") ? filename : filename + ".pdf";
    }

    /** Число страниц PDF; -1, если PDFBox не разбирает файл. */
    private static int pageCount(byte[] content) {
        try (PDDocument doc = Loader.loadPDF(content)) {
            return doc.getNumberOfPages();
        } catch (IOException e) {
            return -1;
        }
    }

    /**
     * Постраничное распознавание: страницы с текстовым слоем берутся как есть
     * всегда, в том числе за лимитом {@code app.document.ocr-max-pages}; по одной
     * распознаются только страницы-изображения ({@link DocumentService#isImagePage})
     * и страницы с нечитаемым слоем, пустые страницы в GigaChat не отправляются.
     * Лимит ограничивает число страниц, отправленных в GigaChat: не распознанные
     * из-за него страницы-изображения перечисляются в маркере. Сбой одной страницы
     * не роняет документ.
     *
     * @return тексты страниц с маркерами «--- страница N ---»; пусто, если документ
     *         не разбирается PDFBox либо в нём нет ни текста, ни изображений
     *         (тогда — распознавание целиком)
     */
    private List<String> recognizePages(String filename, byte[] content, OcrProgress progress) {
        try (PDDocument doc = Loader.loadPDF(content)) {
            int total = doc.getNumberOfPages();
            String[] texts = new String[total + 1];
            List<Integer> toOcr = new ArrayList<>();
            List<Integer> overLimit = new ArrayList<>();
            classifyPages(doc, texts, toOcr, overLimit);
            List<List<Integer>> batches = batches(toOcr);
            int next = 0;
            for (int page = 1; page <= total; page++) {
                if (next < batches.size() && batches.get(next).get(0) == page) {
                    recognizeBatch(filename, doc, batches.get(next++), texts);
                }
                progress.page(filename, page, total);
            }
            List<String> parts = new ArrayList<>();
            for (int page = 1; page <= total; page++) {
                if (texts[page] != null) {
                    parts.add(texts[page]);
                }
            }
            if (!overLimit.isEmpty()) {
                parts.add("[страницы " + pageRanges(overLimit) + " не распознаны: превышен лимит страниц OCR "
                        + ocrMaxPages + " (обработано " + (total - overLimit.size()) + " из " + total + " страниц)]");
            }
            log.info("OCR «{}»: страниц {}, распознано постранично {} (запросов пачками: {})", filename, total, toOcr.size(),
                    batches.size());
            return parts;
        } catch (IOException e) {
            log.warn("OCR «{}»: PDF не разбирается постранично ({}) — распознаётся целиком", filename, e.getMessage());
            return List.of();
        }
    }

    /**
     * Разбор страниц: страницы с текстовым слоем сразу получают текст, страницы-изображения и нечитаемые — в очередь
     * распознавания в пределах лимита, остальные — в перечень нераспознанных.
     */
    private void classifyPages(PDDocument doc, String[] texts, List<Integer> toOcr, List<Integer> overLimit) throws IOException {
        PDFTextStripper stripper = new PDFTextStripper();
        for (int page = 1; page < texts.length; page++) {
            stripper.setStartPage(page);
            stripper.setEndPage(page);
            // текстовый слой — с той же склейкой разрядов чисел, что у обычного разбора PDF (DocumentService.parseText):
            // в смешанном PDF слой страниц шёл в документ сырым, и рваные суммы («975 09 86,34») не находились
            String layer = DocumentService.normalizeNumberGroups(stripper.getText(doc).strip());
            if (!needsOcr(doc.getPage(page - 1), layer)) {
                texts[page] = layer.isEmpty() ? null : "--- страница " + page + " (текстовый слой) ---\n" + layer;
            } else if (toOcr.size() < ocrMaxPages) {
                toOcr.add(page);
            } else {
                overLimit.add(page);
            }
        }
    }

    /** Очередь распознавания пачками по {@code ocrPagesPerRequest} страниц (по одной при 1). */
    private List<List<Integer>> batches(List<Integer> toOcr) {
        int size = Math.max(1, ocrPagesPerRequest);
        List<List<Integer>> batches = new ArrayList<>();
        for (int i = 0; i < toOcr.size(); i += size) {
            batches.add(toOcr.subList(i, Math.min(toOcr.size(), i + size)));
        }
        return batches;
    }

    /**
     * Распознавание пачки: одна страница — постраничный запрос; несколько — один запрос с маркерами страниц, а если
     * ответ обрезан, отказ или маркеров не по числу страниц — пачка перераспознаётся постранично.
     */
    private void recognizeBatch(String filename, PDDocument doc, List<Integer> pages, String[] texts) {
        Map<Integer, String> recognized = pages.size() == 1 ? Map.of() : askBatch(filename, doc, pages);
        for (int i = 0; i < pages.size(); i++) {
            int page = pages.get(i);
            String text = recognized.get(i + 1);
            texts[page] = "--- страница " + page + " ---\n" + (text != null ? text : recognizePage(filename, doc, page));
        }
    }

    /** Ответ на пачку по номерам страниц во вложении (с 1); пусто — пачку распознавать постранично. */
    private Map<Integer, String> askBatch(String filename, PDDocument doc, List<Integer> pages) {
        String name = "pages-" + pages.get(0) + "-" + pages.get(pages.size() - 1) + ".pdf";
        try (PDDocument batch = new PDDocument()) {
            for (int page : pages) {
                batch.importPage(doc.getPage(page - 1));
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            batch.save(out);
            String text = ask(String.format(BATCH_PROMPT, pages.size()), name, out.toByteArray());
            Map<Integer, String> byPage = splitBatch(text, pages.size());
            if (byPage.isEmpty()) {
                log.info("OCR «{}»: пачка {} — ответ без полной разметки страниц, перераспознаю постранично", filename, name);
            }
            return byPage;
        } catch (IOException e) {
            log.warn("OCR «{}»: пачка {} не собрана ({}) — постранично", filename, name, e.getMessage());
            return Map.of();
        }
    }

    /**
     * Текст ответа на пачку по страницам: маркеры «=== СТРАНИЦА k ===» должны идти по порядку 1..n без пропусков,
     * ответ — не отказ и не обрезан по лимиту токенов; иначе пусто.
     *
     * @param text ответ модели
     * @param n    страниц в пачке
     * @return текст по номеру страницы во вложении либо пустая карта
     */
    static Map<Integer, String> splitBatch(String text, int n) {
        if (text == null || isRefusal(text) || text.contains(TRUNCATED_MARKER)) {
            return Map.of();
        }
        Matcher m = BATCH_PAGE.matcher(text);
        List<int[]> marks = new ArrayList<>();
        while (m.find()) {
            marks.add(new int[]{Integer.parseInt(m.group(1)), m.start(), m.end()});
        }
        if (marks.size() != n) {
            return Map.of();
        }
        Map<Integer, String> byPage = new LinkedHashMap<>();
        for (int i = 0; i < n; i++) {
            if (marks.get(i)[0] != i + 1) {
                return Map.of();
            }
            int end = i + 1 < n ? marks.get(i + 1)[1] : text.length();
            byPage.put(i + 1, text.substring(marks.get(i)[2], end).strip());
        }
        return byPage;
    }

    /**
     * Страница уходит в GigaChat: изображение без текстового слоя либо нечитаемый
     * слой (штамп ЭДО без ToUnicode). Пустая страница не распознаётся.
     *
     * @param page  страница PDF
     * @param layer текстовый слой страницы без краевых пробелов
     * @return {@code true}, если страницу нужно распознавать
     */
    private boolean needsOcr(PDPage page, String layer) {
        return layer.length() >= minParsedChars
                ? looksGarbled(layer)
                : DocumentService.isImagePage(page, layer, minParsedChars);
    }

    /** Страница с текстовым слоем как есть; пустая страница пропускается. */
    private static void addTextLayer(List<String> parts, int page, String layer) {
        if (!layer.isEmpty()) {
            parts.add("--- страница " + page + " (текстовый слой) ---\n" + layer);
        }
    }

    /**
     * Номера страниц диапазонами: [41, 42, 43, 50] → «41–43, 50».
     *
     * @param pages номера страниц по возрастанию
     * @return перечень номеров и диапазонов через запятую
     */
    static String pageRanges(List<Integer> pages) {
        List<String> ranges = new ArrayList<>();
        int start = 0;
        for (int i = 1; i <= pages.size(); i++) {
            if (i == pages.size() || pages.get(i) != pages.get(i - 1) + 1) {
                ranges.add(start == i - 1 ? String.valueOf(pages.get(start)) : pages.get(start) + "–" + pages.get(i - 1));
                start = i;
            }
        }
        return String.join(", ", ranges);
    }

    private String recognizePage(String filename, PDDocument doc, int page) {
        try (PDDocument single = new PDDocument()) {
            single.importPage(doc.getPage(page - 1));
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            single.save(out);
            String text = ask(PAGE_PROMPT, "page-" + page + ".pdf", out.toByteArray());
            if (isRefusal(text) && !BLOCKED_REFUSAL.equals(text)) {
                log.info("OCR «{}»: страница {} — отказ модели, повтор с запасным промптом", filename, page);
                text = ask(FALLBACK_PROMPT, "page-" + page + ".pdf", out.toByteArray());
            }
            if (isRefusal(text)) {
                log.warn("OCR «{}»: страница {} — отказ модели и после запасного промпта", filename, page);
                return "[страница " + page + " " + PAGE_REFUSED_MARKER;
            }
            return text;
        } catch (IOException e) {
            log.warn("OCR «{}»: страница {} не выделена ({})", filename, page, e.getMessage());
            return "[страница " + page + " не распознана: " + e.getMessage() + "]";
        }
    }

    /**
     * Текстовый слой страницы нечитаем: штамп оператора ЭДО в актах МЕТРО свёрстан шрифтом без таблицы
     * ToUnicode и извлекается как «X c X " +" - 469 -» — букв и цифр мало, «служебных» знаков много. Такая
     * страница распознаётся моделью, как страница без слоя, иначе дата и подпись заказчика из штампа теряются.
     * Числовая таблица с точным слоем (график платежей, спецификация) мусором не считается.
     *
     * @param layer текстовый слой страницы
     * @return {@code true}, если слой короткий и в нём меньше половины букв и цифр либо не меньше трети служебных знаков
     */
    static boolean looksGarbled(String layer) {
        if (layer.length() > GARBLED_MAX_CHARS) {
            return false;
        }
        int total = 0;
        int alnum = 0;
        int junk = 0;
        char previous = 0;
        for (int i = 0; i < layer.length(); i++) {
            char c = layer.charAt(i);
            if (Character.isWhitespace(c)) {
                continue;
            }
            boolean alphanumeric = Character.isLetterOrDigit(c);
            boolean repeated = !alphanumeric && c == previous;
            previous = c;
            if (repeated) {
                // точечные линии оглавления и «-----» — один служебный знак, а не десятки
                continue;
            }
            total++;
            if (alphanumeric) {
                alnum++;
            } else {
                junk++;
            }
        }
        return total > 0 && (alnum < total * ALNUM_SHARE_MIN || junk >= total * JUNK_SHARE_MAX);
    }

    /**
     * Отказ модели в начале ответа: вместо текста — просьба предоставить документ либо, в коротком ответе,
     * комментарий «из предоставленного фрагмента невозможно выписать…» ({@link #SHORT_REFUSAL}).
     *
     * @param text ответ модели
     * @return {@code true}, если ответ — отказ, а не распознанный текст
     */
    static boolean isRefusal(String text) {
        String head = text == null ? "" : text.substring(0, Math.min(text.length(), REFUSAL_WINDOW));
        return REFUSAL.matcher(head).find()
                || text != null && text.strip().length() < SHORT_REFUSAL_MAX_CHARS && SHORT_REFUSAL.matcher(head).find();
    }

    /**
     * Текст предупреждения загрузки по результату распознавания: отказ модели,
     * распознавание целиком (пересказ), нераспознанные страницы, обрыв ответа
     * либо обычное «распознан — проверьте суммы». У смешанного PDF, где моделью
     * распознаны отдельные страницы, вместо «PDF-скан распознан» перечисляются
     * эти страницы: документ машиночитаемый, перепроверять нужно только их.
     *
     * @param recognized результат {@link #recognize(String, byte[])}
     * @param mixed      документ — смешанный PDF (текстовый слой есть, часть страниц — изображения)
     * @return текст для upload_warning
     */
    public static String uploadWarning(String recognized, boolean mixed) {
        if (recognized.startsWith(DOC_REFUSED_PREFIX)) {
            return "PDF-скан не распознан: модель отказалась распознавать документ — требуется ручная проверка";
        }
        List<String> notes = new ArrayList<>();
        if (recognized.startsWith(OCR_WHOLE_PREFIX)) {
            notes.add("многостраничный скан распознан целиком (пересказ) — строки таблиц могли быть потеряны");
        }
        List<String> refused = new ArrayList<>();
        Matcher m = PAGE_REFUSED.matcher(recognized);
        while (m.find()) {
            refused.add(m.group(1));
        }
        if (!refused.isEmpty()) {
            notes.add("страницы " + String.join(", ", refused) + " не распознаны: отказ модели");
        }
        if (recognized.contains(TRUNCATED_MARKER)) {
            notes.add("ответ модели оборван по лимиту длины — часть текста не распознана");
        }
        Matcher limit = PAGES_OVER_LIMIT.matcher(recognized);
        if (limit.find()) {
            // раньше страницы сверх лимита оставались только маркером в тексте, а предупреждение говорило
            // «распознан — проверьте суммы»: приложения на страницах 41–70 выпадали без сигнала пользователю
            String processed = limit.group(3) == null ? "" : "обработано " + limit.group(3) + " из " + limit.group(4) + " страниц: ";
            notes.add(processed + "страницы " + limit.group(1) + " не распознаны — превышен лимит " + limit.group(2)
                    + " страниц OCR, догрузите документ частями");
        }
        if (recognized.contains(OcrResultCache.CACHE_MARKER)) {
            notes.add("распознавание взято из кэша (тот же файл уже распознавался)");
        }
        List<Integer> pages = mixed ? recognizedPages(recognized) : List.of();
        String base = pages.isEmpty()
                ? "PDF-скан распознан через GigaChat — проверьте суммы"
                : "распознаны через GigaChat страницы " + pageRanges(pages) + " — проверьте суммы";
        return notes.isEmpty() ? base : base + "; " + String.join("; ", notes);
    }

    /**
     * Номера страниц, распознанных моделью постранично: заголовок «--- страница N ---»
     * без пометки текстового слоя и без маркера нераспознанной страницы.
     *
     * @param recognized результат {@link #recognize(String, byte[])}
     * @return номера страниц по возрастанию
     */
    private static List<Integer> recognizedPages(String recognized) {
        List<Integer> pages = new ArrayList<>();
        Matcher m = PAGE_RECOGNIZED.matcher(recognized);
        while (m.find()) {
            pages.add(Integer.parseInt(m.group(1)));
        }
        return pages;
    }

    /**
     * Запрос к GigaChat под ограничителем одновременных распознаваний; отказ цензора и блокировка фильтром GigaFilter —
     * {@link #BLOCKED_REFUSAL} (отказ без повтора запасным промптом).
     */
    private String ask(String prompt, String filename, byte[] content) {
        Semaphore slots = slots();
        slots.acquireUninterruptibly();
        try {
            var result = gigaChatClient.chatCompletionWithFile(prompt, filename, content, PDF,
                    ocrModel == null || ocrModel.isBlank() ? null : ocrModel, OCR_TEMPERATURE, ocrMaxTokens);
            return result.text();
        } catch (GigaChatRefusedException | GigaFilterBlockedException e) {
            log.warn("OCR «{}»: {}", filename, e.getMessage());
            return BLOCKED_REFUSAL;
        } finally {
            slots.release();
        }
    }

    /** Ограничитель создаётся лениво: поле {@code ocrParallelism} заполняется после конструктора. */
    private synchronized Semaphore slots() {
        if (ocrSlots == null) {
            ocrSlots = new Semaphore(Math.max(1, ocrParallelism));
        }
        return ocrSlots;
    }
}
