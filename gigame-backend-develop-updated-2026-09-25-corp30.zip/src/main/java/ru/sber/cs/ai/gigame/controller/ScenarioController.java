package ru.sber.cs.ai.gigame.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioCreate;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRateRequest;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioUpdate;
import ru.sber.cs.ai.gigame.dto.scenario.UploadStatusResponse;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.DocumentText;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Контроллер для управления сценариями (AI-workflow).
 * <p>
 * Сценарии представляют собой графы узлов (input, output, loop, switch, if_node),
 * которые выполняются последовательно для обработки документов с использованием AI.
 */
@Slf4j
@RestController
@RequestMapping("/api/scenarios")
@RequiredArgsConstructor
@Tag(name = "scenarios", description = "Управление AI-сценариями (workflow)")
@SuppressWarnings("unused")
public class ScenarioController {

    static final int MAX_FILES_PER_REQUEST = 100;

    private final ScenarioService scenarioService;
    private final ScenarioEngine scenarioEngine;
    private final DocsTextCacheService docsTextCacheService;
    private final ScenarioUploadTaskService scenarioUploadTaskService;

    /**
     * Список всех сценариев.
     * <p>
     * Возвращает список всех доступных сценариев с краткой информацией.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @return Список сценариев
     */
    @GetMapping
    @Operation(
            summary = "Получить список сценариев",
            description = "Возвращает список всех доступных сценариев с их базовыми метаданными.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Список сценариев получен успешно",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    array = @ArraySchema(maxItems = 1000, schema = @Schema(implementation = ScenarioResponse.class)))),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<List<ScenarioResponse>> listScenarios(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId) {
        log.info("[{}] listScenarios", userId);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        scenarioService::getScenarios))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Создание нового сценария.
     * <p>
     * Создаёт новый сценарий с заданным названием, описанием и графом выполнения.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param body   Данные для создания сценария
     * @return Созданный сценарий
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
            summary = "Создать новый сценарий",
            description = """
                    Создаёт новый AI-сценарий с заданным графом выполнения.
                    
                    ## Структура graph_data:
                    
                    ```json
                    {
                      "nodes": [
                        {
                          "id": "node-id",
                          "type": "input|output|loop|switch|if_node",
                          "data": { ... }
                        }
                      ],
                      "edges": [
                        {
                          "source": "node-id-1",
                          "target": "node-id-2",
                          "data": { ... }
                        }
                      ]
                    }
                    ```
                    
                    ## Типы узлов:
                    - `input` — входной узел для документа
                    - `output` — выходной узел для результата
                    - `loop` — цикл по документам
                    - `switch` — условное ветвление
                    - `if_node` — условная проверка
                    """,
            responses = {
                    @ApiResponse(responseCode = "201",
                            description = "Сценарий успешно создан",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioResponse> createScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Данные для создания сценария",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ScenarioCreate.class)))
            @RequestBody ScenarioCreate body) {
        log.info("[{}] createScenario, name='{}'", userId, body.name());
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.createScenario(body.name(), body.description(), body.graphData())))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Получение сценария с деталями.
     * <p>
     * Возвращает полную информацию о сценарии, включая граф выполнения.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     * @return Детальная информация о сценарии
     */
    @GetMapping("/{id}")
    @Operation(
            summary = "Получить сценарий с деталями",
            description = "Возвращает сценарий с полным графом выполнения и всеми метаданными.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Сценарий найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioDetailResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioDetailResponse> getScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.info("[{}] getScenario, id={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.getScenario(id)))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Обновление сценария.
     * <p>
     * Обновляет название, описание и граф выполнения существующего сценария.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     * @param body   Новые данные сценария
     * @return Обновлённый сценарий
     */
    @PutMapping("/{id}")
    @Operation(
            summary = "Обновить сценарий",
            description = "Обновляет название, описание и граф выполнения существующего сценария.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Сценарий успешно обновлён",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioResponse> updateScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Новые данные сценария",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = ScenarioUpdate.class)))
            @RequestBody ScenarioUpdate body) {
        log.info("[{}] updateScenario, id={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.updateScenario(
                                id, body.name(), body.description(), body.graphData(), body.shared())))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Удаление сценария.
     * <p>
     * Удаляет сценарий и все связанные с ним результаты выполнения.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     */
    @DeleteMapping("/{id}")
    @Operation(
            summary = "Удалить сценарий",
            description = "Удаляет сценарий и все связанные с ним результаты выполнения. Операция необратима.",
            responses = {
                    @ApiResponse(responseCode = "204",
                            description = "Сценарий успешно удален"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ResponseEntity<Void>> deleteScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.info("[{}] deleteScenario, id={}", userId, id);
        return Mono.fromRunnable(() -> CurrentUserHolder.withUser(userId,
                        () -> {
                            scenarioService.deleteScenario(id);
                            return null;
                        }))
                .subscribeOn(Schedulers.boundedElastic())
                .then(Mono.just(ResponseEntity.noContent().build()));
    }

    /**
     * Ставит оценку сценарию (1..5) от текущего пользователя.
     * Повторная оценка заменяет предыдущую.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор сценария
     * @param body   тело с полем rating (1..5)
     */
    @PostMapping("/{id}/rating")
    @Operation(
            summary = "Оценить сценарий",
            description = "Ставит оценку сценарию от 1 до 5. Повторная оценка того же "
                    + "пользователя заменяет предыдущую. Оценивать можно общие сценарии "
                    + "и собственные.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Оценка сохранена"),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> rateScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @RequestBody ScenarioRateRequest body) {
        log.info("[{}] rateScenario, id={}", userId, id);
        return Mono.<Void>fromRunnable(() -> CurrentUserHolder.withUser(userId, () -> {
                    Integer rating = body.rating();
                    if (rating == null) {
                        throw new IllegalArgumentException("Не указано поле rating");
                    }
                    scenarioService.rateScenario(id, rating);
                    return null;
                })).subscribeOn(Schedulers.boundedElastic());
    }

    @PostMapping("/{id}/duplicate")
    @Operation(
            summary = "Дублировать сценарий",
            description = "Создаёт копию сценария с названием с добавлением ' (копия)'.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Сценарий успешно скопирован",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioResponse> duplicateScenario(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.info("[{}] duplicateScenario, id={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.duplicateScenario(id)))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Список выполнений сценария.
     * <p>
     * Возвращает историю всех выполнений заданного сценария.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор сценария
     * @return Список выполнений
     */
    @GetMapping("/{id}/runs")
    @Operation(
            summary = "Получить список выполнений сценария",
            description = "Возвращает историю всех выполнений сценария с их статусами и датами.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Список выполнений получен успешно",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    array = @ArraySchema(maxItems = 1000, schema = @Schema(implementation = ScenarioRunResponse.class)))),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<List<ScenarioRunResponse>> listRuns(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.info("[{}] listRuns, scenarioId={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.getScenarioRuns(id)))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Детальная информация о выполнении.
     * <p>
     * Возвращает полную информацию о конкретном выполнении сценария,
     * включая все шаги и их результаты.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     * @return Детальная информация о выполнении
     */
    @GetMapping("/runs/{runId}")
    @Operation(
            summary = "Получить детальную информацию о выполнении",
            description = "Возвращает полную информацию о выполнении сценария, включая все шаги, " +
                    "их входные/выходные данные и статусы.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Информация о выполнении получена",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ScenarioRunDetailResponse.class))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<ScenarioRunDetailResponse> getRunDetail(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        log.info("[{}] getRunDetail, runId={}", userId, runId);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.getScenarioRun(runId)))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Продолжение выполнения из паузы.
     * <p>
     * Продолжает выполнение после паузы в пошаговом режиме.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     */
    @PostMapping("/runs/{runId}/continue")
    @Operation(
            summary = "Продолжить выполнение из паузы",
            description = "Продолжает выполнение сценария после паузы в пошаговом режиме. " +
                    "Вызовите этот endpoint, когда получили событие `step_paused`.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Выполнение продолжено"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> continueRun(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        log.info("[{}] continueRun, runId={}", userId, runId);
        return Mono.fromRunnable(() -> CurrentUserHolder.withUser(userId, () -> {
                    scenarioService.checkRunAccess(runId);
                    scenarioEngine.continueStep(runId.toString());
                    return null;
                }))
                .subscribeOn(Schedulers.boundedElastic()).then();
    }

    /**
     * Отключение пошагового режима.
     * <p>
     * Отключает пошаговый режим и продолжает выполнение до конца.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     */
    @PostMapping("/runs/{runId}/disable-step-mode")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(
            summary = "Отключить пошаговый режим",
            description = "Отключает пошаговый режим и продолжает выполнение до завершения. " +
                    "Все оставшиеся шаги будут выполнены без пауз.",
            responses = {
                    @ApiResponse(responseCode = "204",
                            description = "Пошаговый режим отключён"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> disableStepMode(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        log.info("[{}] disableStepMode, runId={}", userId, runId);
        return Mono.fromRunnable(() -> CurrentUserHolder.withUser(userId, () -> {
                    scenarioService.checkRunAccess(runId);
                    scenarioEngine.disableStepMode(runId.toString());
                    return null;
                }))
                .subscribeOn(Schedulers.boundedElastic()).then();
    }

    /**
     * Остановка выполняющегося прогона.
     * <p>
     * Взводит флаг остановки: выполнение прерывается на границе текущего узла
     * (агентские инструменты сворачиваются на ближайшем вызове), прогон
     * завершается со статусом FAILED. Обрыв соединения прогон не останавливает —
     * только этот вызов.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     */
    @PostMapping("/runs/{runId}/cancel")
    @Operation(
            summary = "Остановить выполняющийся прогон",
            description = "Взводит флаг остановки: выполнение прерывается на границе текущего "
                    + "узла, прогон завершается со статусом FAILED. Если прогон уже не активен, "
                    + "вызов ничего не делает.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Остановка запрошена"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> cancelRun(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId) {
        log.info("[{}] cancelRun, runId={}", userId, runId);
        return Mono.fromRunnable(() -> CurrentUserHolder.withUser(userId, () -> {
                    scenarioService.checkRunAccess(runId);
                    return scenarioEngine.requestCancel(runId.toString());
                }))
                .subscribeOn(Schedulers.boundedElastic()).then();
    }

    /**
     * Загрузка файлов в кэш сценария.
     * <p>
     * Загружает файлы и сохраняет их в кэше по идентификатору сценария.
     * Файлы используются при последующем запуске сценария WS-командой run
     * (WebSocket /ws/scenario).
     *
     * @param userId   Идентификатор пользователя (из заголовка X-UserId)
     * @param id       Идентификатор сценария
     * @param fileFlux Поток файлов для загрузки
     */
    @PostMapping(value = "/{id}/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(
            summary = "Загрузить файлы в кэш сценария",
            description = """
                    Загружает файлы и сохраняет их в кэше по идентификатору сценария.
                    Файлы не обрабатываются, а только сохраняются для последующего использования.
                    Endpoint не возвращает ответ.
                    """,
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Файлы успешно загружены в кэш"
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> uploadFiles(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Файлы для загрузки",
                    array = @ArraySchema(
                            maxItems = 100,
                            schema = @Schema(
                                    type = "string",
                                    format = "binary",
                                    pattern = "^(1(01*0)*1|0)+$",
                                    description = "Файлы в формате binary")))
            @RequestPart(value = "files")
            Flux<FilePart> fileFlux,
            @Parameter(description = "Догрузить файлы к уже загруженным (для наборов, "
                    + "не помещающихся в один запрос: партии по ~100 файлов). "
                    + "По умолчанию false — кэш заменяется.")
            @RequestParam(value = "append", required = false, defaultValue = "false")
            boolean append,
            @Parameter(description = "Асинхронный режим: запрос только принимает байты "
                    + "файлов и ставит фоновую задачу разбора (обход шлюзовых таймаутов "
                    + "на больших комплектах); прогресс — GET /{id}/upload-status. "
                    + "По умолчанию false — прежняя синхронная обработка.")
            @RequestParam(value = "async", required = false, defaultValue = "false")
            boolean async) {
        log.info("[{}] uploadFiles, scenarioId={}, append={}, async={}",
                userId, id, append, async);
        // Реактивно собираем файлы, затем всю блокирующую работу (JPA, чтение байтов)
        // выполняем в Mono.fromCallable на boundedElastic. Никаких .block() внутри
        // MonoCallable — это приводит к дедлоку с Netty event loop и InterruptedException.
        Mono<List<FilePart>> collectedFiles = fileFlux == null
                ? Mono.just(List.of())
                : fileFlux.collectList().defaultIfEmpty(List.of());

        if (async) {
            return collectedFiles
                    .flatMap(files -> Mono.fromCallable(() -> submitUploadTask(userId, id, files, append))
                            .subscribeOn(Schedulers.boundedElastic()))
                    .then();
        }
        return collectedFiles
                .flatMap(files -> Mono.<Void>fromRunnable(() -> processUploadedFiles(userId, id, files, append))
                        .subscribeOn(Schedulers.boundedElastic()))
                .then();
    }

    /**
     * Статус фоновой задачи разбора документов (асинхронный режим загрузки).
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор сценария
     * @return status (processing/done/failed/none), files, documents, warnings, error
     */
    @GetMapping("/{id}/upload-status")
    @Operation(
            summary = "Статус фоновой обработки загруженных файлов",
            description = """
                    Возвращает состояние задачи разбора документов, поставленной
                    загрузкой с параметром async=true: processing — разбор идёт,
                    done — документы в кэше сценария (поле documents), failed —
                    ошибка (поле error), none — задач по сценарию не было.
                    """,
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Статус задачи разбора",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = UploadStatusResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<UploadStatusResponse> uploadStatus(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.info("[{}] uploadStatus, scenarioId={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> {
                            scenarioService.getScenario(id);
                            return scenarioUploadTaskService.status(id, userId);
                        }))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Отмена фоновой обработки загруженных файлов — крестик панели прогона во время загрузки.
     * До этой ручки крестик прерывал только запросы браузера, а бэкенд дорабатывал разбор
     * принятой партии (минуты OCR), и новая загрузка в сценарий упиралась в «обрабатывается».
     * Идемпотентна: без активной задачи ничего не делает.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор сценария
     */
    @PostMapping("/{id}/upload-cancel")
    @Operation(
            summary = "Отменить фоновую обработку загруженных файлов",
            description = """
                    Прерывает разбор документов, поставленный загрузкой с параметром async=true,
                    для текущего пользователя: разобранное в кэш сценария не попадает, задача
                    получает статус failed с текстом «Загрузка отменена пользователем»
                    (GET upload-status). Если разбор не идёт, вызов ничего не делает.
                    """,
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Отмена принята (или отменять нечего)"
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Сценарий не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<Void> cancelUpload(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.info("[{}] cancelUpload, scenarioId={}", userId, id);
        return Mono.fromRunnable(() -> CurrentUserHolder.withUser(userId, () -> {
                    scenarioService.getScenario(id);
                    return scenarioUploadTaskService.cancel(id, userId);
                }))
                .subscribeOn(Schedulers.boundedElastic()).then();
    }

    /**
     * Асинхронный приём файлов: проверка сценария и лимита, быстрое чтение
     * байтов, постановка фоновой задачи разбора. Долгий парсинг (POI, PDF,
     * OCR) в HTTP-запросе не выполняется.
     *
     * @param userId идентификатор пользователя
     * @param id     идентификатор сценария
     * @param files  собранные реактивно файлы
     * @param append признак догрузки к существующему кэшу
     * @return маркер постановки задачи (для завершения Mono)
     */
    private boolean submitUploadTask(String userId, UUID id, List<FilePart> files, boolean append) {
        return CurrentUserHolder.withUser(userId, () -> {
            scenarioService.getScenario(id);
            log.info("[{}] Асинхронная загрузка {} файла(ов) (append={})", userId, files.size(), append);
            if (files.size() > MAX_FILES_PER_REQUEST) {
                throw new FileException("Превышено максимальное количество файлов: " + files.size()
                        + ". Максимум: " + MAX_FILES_PER_REQUEST);
            }
            scenarioUploadTaskService.start(id, userId, scenarioService.readFiles(files), append);
            return true;
        });
    }

    /**
     * Синхронная обработка загруженных файлов: проверка сценария, валидация
     * количества, догрузка в кэш. Вызывается на {@link Schedulers#boundedElastic()}.
     * Документы кэшируются по ключу «сценарий + пользователь»
     * ({@link DocsTextCacheService#scenarioKey(UUID, String)}): загрузка одного
     * пользователя общего сценария не стирает и не дополняет документы другого.
     *
     * @param userId идентификатор пользователя
     * @param id     идентификатор сценария
     * @param files  собранные реактивно файлы
     * @param append признак догрузки к существующему кэшу
     */
    private void processUploadedFiles(String userId, UUID id, List<FilePart> files, boolean append) {
        CurrentUserHolder.withUser(userId, () -> {
            // Сначала проверяем, что сценарий существует
            scenarioService.getScenario(id);
            UUID key = DocsTextCacheService.scenarioKey(id, userId);
            log.info("[{}] Обработка {} файла(ов) для загрузки (append={}), ключ кэша {}",
                    CurrentUserHolder.getCurrentUser(), files.size(), append, key);
            if (files.size() > MAX_FILES_PER_REQUEST) {
                var errorText = "Превышено максимальное количество файлов: " + files.size()
                        + ". Максимум: " + MAX_FILES_PER_REQUEST;
                log.error(errorText);
                throw new FileException(errorText);
            }
            if (!append) {
                docsTextCacheService.clearCache(key);
                scenarioService.clearOriginals(key);
            }
            docsTextCacheService.markUploading(key);
            try {
                cacheDocuments(key, files);
            } finally {
                docsTextCacheService.unmarkUploading(key);
            }
            return null;
        });
    }

    /**
     * Разбирает файлы (с распаковкой ZIP) и догружает документы в кэш сценария.
     * Тексты и имена берутся из одного списка — при распаковке архива
     * один файл может дать несколько документов. Суммарное число документов
     * в кэше ограничено лимитом прогона.
     *
     * @param key   ключ кэша документов сценария пользователя
     *              ({@link DocsTextCacheService#scenarioKey(UUID, String)})
     * @param files собранные реактивно файлы
     */
    private void cacheDocuments(UUID key, List<FilePart> files) {
        // предупреждения разбора (скан, пустой или нечитаемый файл) при синхронной загрузке
        // раньше терялись — теперь они отдаются через GET upload-status (warnings) как и в async
        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        var documents = scenarioService.getDocuments(files, events);
        int cached = docsTextCacheService.getCachedDocumentTexts(key).size();
        int limit = scenarioService.getMaxDocumentsPerRun();
        if (cached + documents.size() > limit) {
            throw new FileException("Слишком много документов с учётом уже загруженных: "
                    + (cached + documents.size()) + ". Максимум на прогон: " + limit);
        }
        int total = docsTextCacheService.appendDocumentTexts(key,
                documents.stream().map(DocumentText::text).toList(),
                documents.stream().map(DocumentText::filename).toList(),
                List.of());
        // исходные файлы — на склад для разметки находок в самих документах (не сохранённый — upload_warning)
        scenarioService.storeOriginals(key, documents, events);
        scenarioUploadTaskService.recordSyncUpload(key, files.size(), total, events);
    }

    /**
     * Скачивание файла, сгенерированного output-узлом прогона.
     * <p>
     * WS-событие FILE_OUTPUT несёт только file_ready — байты отдаёт эта ручка.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param runId  Идентификатор выполнения
     * @param nodeId Идентификатор output-узла
     * @return файл узла (XLSX или текст)
     */
    @GetMapping("/runs/{runId}/files/{nodeId}")
    @Operation(
            summary = "Скачать файл output-узла прогона",
            description = "Отдаёт файл (XLSX/текст), сгенерированный output-узлом завершённого "
                    + "прогона. WS-событие FILE_OUTPUT сообщает только о готовности файла — "
                    + "байты забираются этой ручкой.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Файл",
                            content = @Content(mediaType = "application/octet-stream",
                                    schema = @Schema(implementation = String.class,
                                            pattern = "^[\\w\\W]{0,4096}$"))),
                    @ApiResponse(responseCode = "404",
                            description = "Прогон, узел или результат не найдены",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public ResponseEntity<Resource> downloadRunFile(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId,
            @Parameter(description = "Идентификатор output-узла сценария",
                    schema = @Schema(type = "string", pattern = "^[\\w-]{1,64}$"))
            @PathVariable String nodeId) {
        log.info("[{}] downloadRunFile, runId={}, nodeId={}", userId, runId, nodeId);
        return CurrentUserHolder.withUser(userId,
                () -> scenarioService.downloadRunFile(runId, nodeId));
    }

    /**
     * Экспорт результата выполнения в DOCX.
     * <p>
     * Генерирует Word-документ с результатами выполнения сценария.
     *
     * @param userId       Идентификатор пользователя (из заголовка X-UserId)
     * @param runId        Идентификатор выполнения
     * @param includeSteps включить в файл все шаги выполнения
     * @return DOCX файл с результатами
     */
    @GetMapping("/runs/{runId}/export")
    @Operation(
            summary = "Экспортировать результат в DOCX",
            description = "Генерирует Word-документ (.docx) с полной информацией о выполнении: " +
                    "статус, все шаги, их результаты и итоговый результат.",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "DOCX файл сгенерирован",
                            content = @Content(mediaType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                    schema = @Schema(implementation = String.class,
                                            pattern = "^[\\w\\W]{0,4096}$"))
                    ),
                    @ApiResponse(responseCode = "400",
                            description = "Неверные данные запроса",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Выполнение не найдено",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public ResponseEntity<Resource> exportRun(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор выполнения (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID runId,
            @Parameter(description = "Включить в файл все шаги выполнения (полные тексты "
                    + "документов и промежуточные результаты — получаются сотни страниц). "
                    + "По умолчанию выгружается только итоговый результат.")
            @RequestParam(value = "include_steps", required = false, defaultValue = "false")
            boolean includeSteps) {
        log.info("[{}] exportRun, runId={}, includeSteps={}",
                userId, runId, includeSteps);
        return CurrentUserHolder.withUser(userId,
                () -> scenarioService.extractToDocx(runId, includeSteps));
    }

    /**
     * Список версий сценария.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор сценария
     * @return версии от новых к старым (номер, имя, дата)
     */
    @GetMapping("/{id}/versions")
    @Operation(summary = "Версии сценария",
            description = "История сохранений: снапшот создаётся перед каждым изменением сценария.")
    public Mono<List<Map<String, Object>>> listVersions(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.info("[{}] listVersions, scenarioId={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.getVersions(id)))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Восстановление сценария из версии.
     *
     * @param userId    идентификатор пользователя (из заголовка X-UserId)
     * @param id        идентификатор сценария
     * @param versionNo номер версии
     * @return обновлённый сценарий
     */
    @PostMapping("/{id}/versions/{versionNo}/restore")
    @Operation(summary = "Восстановить версию сценария",
            description = "Текущее состояние предварительно сохраняется как новая версия.")
    public Mono<ScenarioResponse> restoreVersion(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор сценария (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id,
            @Parameter(description = "Номер версии", schema = @Schema(type = "integer"))
            @PathVariable int versionNo) {
        log.info("[{}] restoreVersion, scenarioId={}, versionNo={}",
                userId, id, versionNo);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> scenarioService.restoreVersion(id, versionNo)))
                .subscribeOn(Schedulers.boundedElastic());
    }
}
