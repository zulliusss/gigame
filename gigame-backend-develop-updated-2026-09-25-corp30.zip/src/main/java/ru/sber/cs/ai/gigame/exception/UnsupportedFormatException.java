package ru.sber.cs.ai.gigame.exception;

/**
 * Файл известного, но не поддерживаемого парсером формата (Word 97-2003 .doc, RTF, OpenDocument,
 * PowerPoint 97-2003): в отличие от повреждённого файла причина честная — «формат не поддерживается»
 * с подсказкой, в каком формате сохранить документ. HTTP-код тот же, что у {@link FileException} (422).
 */
public class UnsupportedFormatException extends FileException {

    /**
     * @param extension расширение без точки, в нижнем регистре
     * @param hint      подсказка пользователю: что за формат и как его сохранить
     */
    public UnsupportedFormatException(String extension, String hint) {
        super("формат ." + extension + " не поддерживается (" + hint + ")");
    }
}
