package ru.sber.cs.ai.gigame.repository.projection;

import java.util.Map;

/**
 * Проекция шага прогона для читателей результата узла: только идентификатор узла,
 * его тип и выходные данные — без input_data и prompt_used, которые несут промпты
 * с текстами документов и не нужны ни файлу output-узла, ни узлу-донору,
 * ни нарастающему итогу, ни извлечению уроков.
 */
public interface StepOutputView {

    /**
     * @return идентификатор узла графа
     */
    String getNodeId();

    /**
     * @return тип узла
     */
    String getNodeType();

    /**
     * @return статус шага (pending, running, completed, failed)
     */
    String getStatus();

    /**
     * @return выходные данные шага (ключ «result» — результат узла, «error» — ошибка шага)
     */
    Map<String, String> getOutputData();

    /**
     * Результат узла из выходных данных.
     *
     * @return результат либо {@code null}, если выходных данных нет
     */
    default String result() {
        Map<String, String> data = getOutputData();
        return data == null ? null : data.get("result");
    }

    /**
     * Текст ошибки шага из выходных данных (заполняется у шагов со статусом failed).
     *
     * @return ошибка либо {@code null}, если выходных данных или ошибки нет
     */
    default String error() {
        Map<String, String> data = getOutputData();
        return data == null ? null : data.get("error");
    }
}
