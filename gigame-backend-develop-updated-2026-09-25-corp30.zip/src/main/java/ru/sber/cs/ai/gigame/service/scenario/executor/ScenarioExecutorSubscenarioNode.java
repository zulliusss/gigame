package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.Map;

/**
 * Узел «Под-сценарий»: выполняет другой сценарий внутри текущего.
 * <p>
 * Идентификатор вызываемого сценария хранится в поле value узла (выбирается в UI).
 * Документами под-сценария становятся документы этого узла (маршрутизированные
 * Switch'ем), а при их отсутствии — вход узла единым документом. Результат
 * под-сценария (выход его output-узла) становится выходом этого узла.
 * Глубина вложенности ограничена движком.
 */
@Slf4j
public class ScenarioExecutorSubscenarioNode extends AbstractScenarioExecutor {

    private final ScenarioEngine engine;

    protected ScenarioExecutorSubscenarioNode(ScenarioRunNode node, ScenarioEngine engine) {
        super(node);
        this.engine = engine;
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] SubscenarioNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        String subScenarioId = node.getValue();
        if (subScenarioId == null || subScenarioId.isBlank()) {
            throw new ScenarioException("Узел «Под-сценарий»: не выбран сценарий для выполнения "
                    + "(настройте узел в панели)");
        }
        prompt = "[под-сценарий " + subScenarioId + "]";
        String result = engine.executeSubScenarioInline(subScenarioId, node, sink);
        node.getOutput().add(result);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.addInputs(node.getId(), input);
        }
        return result;
    }
}
