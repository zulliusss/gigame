package ru.sber.cs.ai.gigame.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.codec.DecodingException;
import org.springframework.core.io.buffer.DataBufferLimitException;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.server.PayloadTooLargeException;
import org.springframework.web.server.ResponseStatusException;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Единый маппинг исключений REST-контроллеров в {@link ErrorResponse} спецификации.
 * <p>
 * Прикладные исключения ({@link ApplicationRuntimeException}) — со своим кодом (в том числе
 * {@link GigaChatException} → 503); {@link IllegalArgumentException} (проверки входных данных
 * в сервисах) → 400; {@link TaskRejectedException} (очередь {@code @Async}-задач заполнена) → 503;
 * {@link ResponseStatusException} WebFlux (неверный UUID в пути, некорректное тело) — с её кодом;
 * превышения пределов размера тела ({@link DataBufferLimitException}, {@link PayloadTooLargeException}: часть
 * multipart, буфер кодека, поле формы), «Too many parts» и {@link FileTooLargeException} → 413 с понятным текстом;
 * всё прочее → 500 с нейтральным текстом. Раньше необработанные исключения уходили телом WebFlux
 * не по схеме — корп-шлюз мог отклонить такой ответ целиком.
 */
@ControllerAdvice
@Slf4j
public class ApplicationErrorHandler {

    /** Текст 500: детали внутренней ошибки в ответ не попадают, только в лог. */
    static final String INTERNAL_ERROR = "Внутренняя ошибка сервера";
    /** Текст 503 при переполнении очереди фоновых задач. */
    static final String OVERLOADED = "Сервер перегружен: очередь фоновых задач заполнена, повторите запрос позже";
    /** Начало текста {@link DecodingException} Spring при превышении {@code spring.webflux.multipart.max-parts}. */
    static final String TOO_MANY_PARTS = "Too many parts";
    /**
     * Признак превышения предела части multipart (файла) в тексте исключения Spring: «Part exceeded the disk usage
     * limit of N bytes» ({@code max-disk-usage-per-part}), «Part exceeded the limit of N bytes». Заголовки части
     * («Part headers exceeded …») и поле формы («Form field value exceeded …») — не файл.
     */
    static final String PART_EXCEEDED = "Part exceeded";
    /** Текст 413 для прочих пределов размера: буфер кодека (JSON), поле формы, заголовки части multipart. */
    static final String BODY_TOO_LARGE = "Тело запроса больше допустимого размера";
    /**
     * Предел в тексте исключений Spring: «Part exceeded the disk usage limit of 52428800 bytes»,
     * «Exceeded limit on max bytes to buffer : 262144», «Exceeded limit on max bytes per JSON object: 262144».
     */
    private static final Pattern LIMIT_BYTES =
            Pattern.compile("(?:limit of|max bytes to buffer :|max bytes per JSON object:) ?(\\d{1,18})");
    /** Предел числа частей в тексте исключения Spring: «Too many parts (129/128 allowed)». */
    private static final Pattern PARTS_ALLOWED = Pattern.compile("/(\\d+) allowed");
    /** Глубина поиска предела по цепочке причин исключения. */
    private static final int CAUSE_DEPTH = 5;

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFoundException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    @ExceptionHandler(FileException.class)
    public ResponseEntity<ErrorResponse> handleFileException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    @ExceptionHandler(ScenarioException.class)
    public ResponseEntity<ErrorResponse> handleScenarioException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<ErrorResponse> handleValidationException(ApplicationRuntimeException e) {
        return handleException(e);
    }

    /**
     * Прочие прикладные исключения со своим кодом: {@link GigaChatException} (503) и будущие наследники.
     *
     * @param e прикладное исключение
     * @return ответ с кодом исключения
     */
    @ExceptionHandler(ApplicationRuntimeException.class)
    public ResponseEntity<ErrorResponse> handleApplicationException(ApplicationRuntimeException e) {
        if (e instanceof GigaChatException) {
            log.warn("GigaChat недоступен: {}", e.getMessage());
        }
        return handleException(e);
    }

    /**
     * Файл загрузки больше предела, обнаруженный кодом (имя файла известно) — 413; в лог WARN без стека.
     *
     * @param e исключение превышения размера
     * @return ответ 413
     */
    @ExceptionHandler(FileTooLargeException.class)
    public ResponseEntity<ErrorResponse> handleFileTooLarge(FileTooLargeException e) {
        log.warn("Загрузка отклонена по размеру файла: {}", e.getMessage());
        return handleException(e);
    }

    /**
     * Тело запроса больше предела WebFlux — 413 (раньше 500 «Внутренняя ошибка сервера» со стеком в логе). Обработчик
     * глобальный, текст — по сообщению исключения ({@link #sizeLimitText}): «Файл больше допустимого размера N МБ …»
     * только при превышении предела части multipart ({@code spring.webflux.multipart.max-disk-usage-per-part}, имя
     * файла парсер не сообщает); буфер кодека ({@code spring.codec.max-in-memory-size}, например JSON сценария в PUT),
     * поле формы больше {@code max-in-memory-size}, заголовки части — «Тело запроса больше допустимого размера N КБ».
     * В лог — WARN без стека.
     *
     * @param e {@link DataBufferLimitException} либо {@link PayloadTooLargeException}
     * @return ответ 413
     */
    @ExceptionHandler({DataBufferLimitException.class, PayloadTooLargeException.class})
    public ResponseEntity<ErrorResponse> handleSizeLimit(Exception e) {
        log.warn("Запрос отклонён по пределу размера тела: {}", rootMessage(e));
        return respond(FileTooLargeException.STATUS, sizeLimitText(e));
    }

    /**
     * Ошибка декодирования тела: превышение числа частей multipart ({@code spring.webflux.multipart.max-parts})
     * — 413 с понятным текстом; прочие ошибки декодирования — как необработанное исключение (500).
     *
     * @param e исключение декодирования
     * @return ответ 413 либо 500
     */
    @ExceptionHandler(DecodingException.class)
    public ResponseEntity<ErrorResponse> handleDecoding(DecodingException e) {
        String text = e.getMessage();
        if (text == null || !text.startsWith(TOO_MANY_PARTS)) {
            return handleUnexpected(e);
        }
        log.warn("Запрос отклонён по лимиту числа частей multipart: {}", text);
        Matcher allowed = PARTS_ALLOWED.matcher(text);
        String limit = allowed.find() ? " (больше " + allowed.group(1) + ")" : "";
        return respond(FileTooLargeException.STATUS, "Слишком много файлов в одном запросе загрузки" + limit
                + " — загрузите документы несколькими партиями");
    }

    /**
     * Ошибка входных данных, обнаруженная сервисом ({@code IllegalArgumentException}) — 400.
     *
     * @param e исключение проверки
     * @return ответ 400
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgument(IllegalArgumentException e) {
        return respond(HttpStatus.BAD_REQUEST.value(), e.getMessage());
    }

    /**
     * Очередь фоновых задач ({@code spring.task.execution}) заполнена — 503, клиент повторит позже.
     *
     * @param e отказ пула задач
     * @return ответ 503
     */
    @ExceptionHandler(TaskRejectedException.class)
    public ResponseEntity<ErrorResponse> handleTaskRejected(TaskRejectedException e) {
        log.warn("Очередь фоновых задач заполнена: {}", e.getMessage());
        return respond(HttpStatus.SERVICE_UNAVAILABLE.value(), OVERLOADED);
    }

    /**
     * Исключения WebFlux со статусом (неверный UUID в пути, нечитаемое тело, неподдерживаемый тип) — их код,
     * тело по схеме {@link ErrorResponse}.
     *
     * @param e исключение со статусом
     * @return ответ с кодом исключения
     */
    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ErrorResponse> handleResponseStatus(ResponseStatusException e) {
        int status = e.getStatusCode().value();
        String reason = e.getReason();
        HttpStatus resolved = HttpStatus.resolve(status);
        String fallback = resolved == null ? "HTTP " + status : resolved.getReasonPhrase();
        String message = reason != null && !reason.isBlank() ? reason : fallback;
        return respond(status, message);
    }

    /**
     * Необработанное исключение — 500 с нейтральным текстом; подробности только в лог.
     *
     * @param e исключение
     * @return ответ 500
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleUnexpected(Exception e) {
        log.error("Необработанное исключение в REST-обработчике", e);
        return respond(HttpStatus.INTERNAL_SERVER_ERROR.value(), INTERNAL_ERROR);
    }

    private ResponseEntity<ErrorResponse> handleException(ApplicationRuntimeException e) {
        var response = ErrorResponse.of(e);
        return ResponseEntity.status(response.getStatusCode()).body(response);
    }

    /**
     * Текст 413 по первому сообщению в цепочке причин, где указан предел: предел части multipart
     * ({@link #PART_EXCEEDED}) — текст про файл в мегабайтах, прочие пределы — про тело запроса в килобайтах.
     * Предела в сообщениях нет — текст про тело запроса без числа.
     *
     * @param e исключение предела размера
     * @return текст для пользователя
     */
    static String sizeLimitText(Throwable e) {
        Throwable current = e;
        for (int depth = 0; current != null && depth < CAUSE_DEPTH; depth++) {
            String text = current.getMessage() == null ? "" : current.getMessage();
            Matcher limit = LIMIT_BYTES.matcher(text);
            if (limit.find()) {
                long bytes = Long.parseLong(limit.group(1));
                return text.contains(PART_EXCEEDED)
                        ? FileTooLargeException.message(null, bytes)
                        : BODY_TOO_LARGE + " " + FileTooLargeException.kilobytes(bytes) + " КБ";
            }
            current = current.getCause();
        }
        return BODY_TOO_LARGE;
    }

    /**
     * Текст самой глубокой причины — для лога без стека.
     *
     * @param e исключение
     * @return текст причины
     */
    private static String rootMessage(Throwable e) {
        Throwable root = e;
        for (int depth = 0; root.getCause() != null && depth < CAUSE_DEPTH; depth++) {
            root = root.getCause();
        }
        return root.getMessage();
    }

    private static ResponseEntity<ErrorResponse> respond(int status, String message) {
        var response = ErrorResponse.of(status, message);
        return ResponseEntity.status(status).body(response);
    }
}
