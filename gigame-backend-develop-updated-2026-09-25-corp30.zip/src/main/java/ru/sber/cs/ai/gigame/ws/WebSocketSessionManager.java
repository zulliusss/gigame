package ru.sber.cs.ai.gigame.ws;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.CloseStatus;
import org.springframework.web.reactive.socket.WebSocketSession;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Менеджер WebSocket сессий.
 * <p>
 * Отвечает за хранение и удаление WebSocket сессий для WebFlux.
 * Каждую минуту фоново проверяет сессии на закрытие и чистит зависшие.
 * Закрытие сессий выполняется реактивно (subscribe), без .block() —
 * чтобы не блокировать потоки boundedElastic при исчерпании пула.
 * <p>
 * Число открытых сессий одного пользователя (чат и сценарии вместе) ограничено
 * {@code app.ws.max-sessions-per-user} (env {@code WS_MAX_SESSIONS_PER_USER}, по умолчанию 10; 0 — без предела):
 * при превышении закрывается самая старая сессия пользователя с кодом 1008 (POLICY_VIOLATION). Выбрано закрытие
 * старой, а не отказ новой: залипший фронт с повторными подключениями и полуоткрытые соединения за NAT
 * (см. {@code app.ws.idle-timeout-minutes}) иначе заняли бы лимит навсегда, а живое новое подключение получало бы отказ.
 *
 * @see WebSocketSession
 */
@Component
@Slf4j
public class WebSocketSessionManager {

    /** Предел сессий на пользователя по умолчанию. */
    static final int DEFAULT_MAX_SESSIONS_PER_USER = 10;
    /** Причина закрытия самой старой сессии при превышении предела. */
    static final String TOO_MANY_SESSIONS = "превышен предел открытых WebSocket-сессий пользователя";
    /** Сколько знаков кадра попадает в журнал ({@link #framePreview}). */
    static final int FRAME_PREVIEW_CHARS = 300;

    private final Map<String, WebSocketSession> sessions = new ConcurrentHashMap<>();
    private final Map<String, String> sessionIdToUserId = new ConcurrentHashMap<>();
    /** Сессии пользователя в порядке открытия (доступ под {@code synchronized}). */
    private final Map<String, Deque<String>> userSessions = new HashMap<>();
    /** Предел открытых сессий на пользователя; 0 и меньше — без предела. */
    @Value("${app.ws.max-sessions-per-user:10}")
    private int maxSessionsPerUser = DEFAULT_MAX_SESSIONS_PER_USER;

    /**
     * Усечённый текст WebSocket-кадра для журнала (corp23): полный текст сообщений чата и событий прогона
     * (реквизиты и суммы договоров) в журнал не пишется — первые {@value #FRAME_PREVIEW_CHARS} знаков и длина.
     *
     * @param payload текст кадра
     * @return усечённый текст с длиной либо кадр целиком, если короче предела
     */
    public static String framePreview(String payload) {
        if (payload == null) {
            return "null";
        }
        return payload.length() <= FRAME_PREVIEW_CHARS ? payload
                : payload.substring(0, FRAME_PREVIEW_CHARS) + "… (всего " + payload.length() + " знаков)";
    }

    /**
     * Добавляет новую сессию; при превышении предела сессий пользователя закрывает его самые старые.
     *
     * @param session экземпляр WebSocketSession
     */
    public void addSession(WebSocketSession session) {
        var userId = extractUserIdFromWebSocketSession(session);
        sessions.put(session.getId(), session);
        sessionIdToUserId.put(session.getId(), userId);
        log.info("[{}] New WS connection: sessionId={}", userId, session.getId());
        for (String excess : registerForUser(userId, session.getId())) {
            closeExcess(excess, userId);
        }
    }

    /**
     * Удаляет сессию.
     *
     * @param session экземпляр WebSocketSession
     */
    public void removeSession(WebSocketSession session) {
        String sessionId = session.getId();
        WebSocketSession webSocketSession = sessions.remove(sessionId);
        // Always clean up userId mapping, even if sessions.remove returned null (idempotent call)
        String removedUserId = sessionIdToUserId.remove(sessionId);
        unregisterForUser(removedUserId, sessionId);
        if (webSocketSession != null) {
            try {
                if (webSocketSession.isOpen()) {
                    webSocketSession.close().subscribe(null, t ->
                            log.warn("[{}] Error closing session: sessionId={}", removedUserId, sessionId, t));
                }
            } catch (Exception e) {
                log.warn("[{}] Error closing session: sessionId={}", removedUserId, sessionId, e);
            }
        }

        log.info("[{}] Session closed: sessionId={}, hadUserId={}", removedUserId, sessionId, removedUserId != null);
    }

    /**
     * Возвращает сессию по ID.
     *
     * @param sessionId ID сессии
     * @return WebSocketSession или null если не найдена
     */
    public WebSocketSession getSession(String sessionId) {
        return sessions.get(sessionId);
    }

    /**
     * Возвращает ID пользователя по ID сессии.
     *
     * @param sessionId ID сессии
     * @return userId или null если не найден
     */
    public String getUserId(String sessionId) {
        return sessionIdToUserId.get(sessionId);
    }

    /**
     * Возвращает все активные сессии.
     *
     * @return коллекция всех WebSocket сессий
     */
    public Collection<WebSocketSession> getAllSessions() {
        return sessions.values();
    }

    /**
     * Проверяет наличие сессии по ID.
     *
     * @param sessionId ID сессии
     * @return true если сессия существует
     */
    public boolean hasSession(String sessionId) {
        return sessions.containsKey(sessionId);
    }

    /**
     * Число открытых сессий пользователя.
     *
     * @param userId пользователь
     * @return число сессий
     */
    public synchronized int sessionCount(String userId) {
        Deque<String> deque = userSessions.get(userId);
        return deque == null ? 0 : deque.size();
    }

    /**
     * Фоновая задача: раз в минуту проверяет все сессии и удаляет закрытые.
     * Защита от утечки сессий при аварийном разрыве соединения (краш браузера, обрыв сети).
     */
    @Scheduled(fixedRateString = "${websocket.stale-session-eviction-ms:60000}")
    void evictStaleSessions() {
        int removed = 0;
        for (var it = sessions.entrySet().iterator(); it.hasNext(); ) {
            var entry = it.next();
            WebSocketSession session = entry.getValue();
            if (!session.isOpen()) {
                it.remove();
                unregisterForUser(sessionIdToUserId.remove(entry.getKey()), entry.getKey());
                removed++;
                log.info("Evicted stale WebSocket session: sessionId={}", entry.getKey());
            }
        }
        if (removed > 0) {
            log.info("Evicted {} stale WebSocket session(s)", removed);
        }
    }

    public static String extractUserIdFromWebSocketSession(WebSocketSession session) {
        var userId = session.getHandshakeInfo()
                .getHeaders()
                .getFirst("X-UserId");
        userId = userId == null ? "anonymous" : userId;
        log.info("[{}] Extracted userId from WebSocket session", userId);
        return userId;
    }

    /**
     * Регистрирует сессию пользователя и возвращает самые старые сессии сверх предела (их надо закрыть).
     *
     * @param userId    пользователь
     * @param sessionId новая сессия
     * @return идентификаторы сессий сверх предела, от самой старой
     */
    private synchronized List<String> registerForUser(String userId, String sessionId) {
        Deque<String> deque = userSessions.computeIfAbsent(userId, k -> new ArrayDeque<>());
        deque.addLast(sessionId);
        List<String> excess = new ArrayList<>();
        while (maxSessionsPerUser > 0 && deque.size() > maxSessionsPerUser) {
            excess.add(deque.pollFirst());
        }
        return excess;
    }

    private synchronized void unregisterForUser(String userId, String sessionId) {
        if (userId == null) {
            return;
        }
        Deque<String> deque = userSessions.get(userId);
        if (deque != null) {
            deque.remove(sessionId);
            if (deque.isEmpty()) {
                userSessions.remove(userId);
            }
        }
    }

    /** Закрывает самую старую сессию пользователя сверх предела с кодом 1008 и убирает её из учёта. */
    private void closeExcess(String sessionId, String userId) {
        WebSocketSession old = sessions.remove(sessionId);
        sessionIdToUserId.remove(sessionId);
        log.warn("[{}] Превышен предел сессий ({}): закрывается самая старая, sessionId={}", userId, maxSessionsPerUser, sessionId);
        if (old == null || !old.isOpen()) {
            return;
        }
        try {
            old.close(CloseStatus.POLICY_VIOLATION.withReason(TOO_MANY_SESSIONS)).subscribe(null, t ->
                    log.warn("[{}] Error closing excess session: sessionId={}", userId, sessionId, t));
        } catch (Exception e) {
            log.warn("[{}] Error closing excess session: sessionId={}", userId, sessionId, e);
        }
    }
}
