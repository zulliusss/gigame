package ru.sber.cs.ai.gigame.service;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.binder.MeterBinder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Общий ограничитель одновременных HTTP-запросов к GigaChat на экземпляр приложения.
 * <p>
 * Корп-ключ разрешает ограниченное число одновременных потоков; прогоны сценариев, OCR сканов,
 * индексация БЗ, чат и агентные узлы бьют в один ключ и без общего ограничения получают 429
 * с паузами до минут. Ограничитель — честный FIFO-семафор: запросы получают разрешение строго
 * в порядке входа в очередь, общий для всех потребителей.
 * <p>
 * Разрешение берётся на одну попытку HTTP-вызова и освобождается до паузы повтора (429, 5xx):
 * повторы ведёт вызывающий {@code withRetry}, а сюда передаётся только сама попытка.
 * Ожидание очереди прерываемо: флагом остановки прогона (проверка каждые {@link #POLL_MILLIS} мс)
 * и прерыванием потока. Ожидание дольше {@link #NOTICE_AFTER_MILLIS} мс пишется в лог (INFO, один раз
 * на запрос) и в журнал прогона. Занятость и очередь видны метриками {@code gigachat.requests.active}
 * и {@code gigachat.requests.waiting}.
 * <p>
 * Настройки: {@code app.gigachat.max-concurrent} (env {@code GIGACHAT_MAX_CONCURRENT}, по умолчанию 5,
 * 0 и меньше — без ограничения), {@code app.gigachat.limit-embeddings} (env {@code GIGACHAT_LIMIT_EMBEDDINGS},
 * по умолчанию true — эмбеддинги под тем же лимитом) и {@code app.gigachat.queue-max-wait-millis}
 * (env {@code GIGACHAT_QUEUE_MAX_WAIT_MILLIS}, по умолчанию 600000 = 10 мин, 0 — без предела) — предел ожидания
 * очереди для вызовов без проверки остановки прогона (REST, чат, индексация БЗ, память агента): HTTP-клиент за
 * шлюзом давно ушёл по 504, а работа выполнялась бы впустую. Узел прогона ждёт очередь до остановки прогона.
 */
@Component
@Slf4j
public class GigaChatConcurrencyLimiter implements MeterBinder {

    /** Порог ожидания очереди, после которого пишутся INFO-лог и уведомление в журнал прогона, мс. */
    static final long NOTICE_AFTER_MILLIS = 2000L;
    /** Шаг проверки остановки прогона при ожидании очереди, мс. */
    static final long POLL_MILLIS = 250L;
    /** Ошибка прерванного ожидания: без «timeout/Connection/5xx/429», чтобы повтор не счёл её временной. */
    static final String INTERRUPTED = "Ожидание очереди к GigaChat прервано";
    /** Предел ожидания очереди по умолчанию, мс (10 мин). */
    static final long DEFAULT_QUEUE_MAX_WAIT_MILLIS = 600_000L;
    /** Начало ошибки исчерпанного ожидания очереди (текст без «timeout», чтобы повтор не счёл её временной). */
    static final String QUEUE_WAIT_EXHAUSTED = "очередь запросов к GigaChat: ожидание ";
    /** Признак, что текущий поток уже держит разрешение: вложенный вызов не ждёт сам себя. */
    private static final ThreadLocal<Boolean> HOLDING = new ThreadLocal<>();

    /** Одновременных запросов на экземпляр; 0 и меньше — без ограничения. */
    @Value("${app.gigachat.max-concurrent:5}")
    private int maxConcurrent = 5;
    /** Эмбеддинги под тем же лимитом (делят ли они квоту потоков ключа — не установлено). */
    @Value("${app.gigachat.limit-embeddings:true}")
    private boolean limitEmbeddings = true;
    /** Предел ожидания очереди для вызовов без проверки остановки прогона, мс; 0 — без предела. */
    @Value("${app.gigachat.queue-max-wait-millis:600000}")
    private long queueMaxWaitMillis = DEFAULT_QUEUE_MAX_WAIT_MILLIS;
    private final long noticeAfterMillis;
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition changed = lock.newCondition();
    private final Deque<Object> queue = new ArrayDeque<>();
    private int active;

    /** Конструктор для Spring: настройки приходят в поля из конфигурации. */
    public GigaChatConcurrencyLimiter() {
        this.noticeAfterMillis = NOTICE_AFTER_MILLIS;
    }

    /**
     * Конструктор с явными настройками (тесты и режим без ограничения).
     *
     * @param maxConcurrent     одновременных запросов; 0 и меньше — без ограничения
     * @param limitEmbeddings   эмбеддинги под тем же лимитом
     * @param noticeAfterMillis порог ожидания для лога и уведомления, мс
     */
    GigaChatConcurrencyLimiter(int maxConcurrent, boolean limitEmbeddings, long noticeAfterMillis) {
        this(maxConcurrent, limitEmbeddings, noticeAfterMillis, DEFAULT_QUEUE_MAX_WAIT_MILLIS);
    }

    /**
     * Конструктор с явными настройками и пределом ожидания очереди (тесты).
     *
     * @param maxConcurrent       одновременных запросов; 0 и меньше — без ограничения
     * @param limitEmbeddings     эмбеддинги под тем же лимитом
     * @param noticeAfterMillis   порог ожидания для лога и уведомления, мс
     * @param queueMaxWaitMillis  предел ожидания очереди для вызовов без проверки остановки, мс; 0 — без предела
     */
    GigaChatConcurrencyLimiter(int maxConcurrent, boolean limitEmbeddings, long noticeAfterMillis, long queueMaxWaitMillis) {
        this.maxConcurrent = maxConcurrent;
        this.limitEmbeddings = limitEmbeddings;
        this.noticeAfterMillis = noticeAfterMillis;
        this.queueMaxWaitMillis = queueMaxWaitMillis;
    }

    /**
     * Ограничитель без ограничения — до внедрения Spring и в клиентах, созданных вручную.
     *
     * @return ограничитель, пропускающий все вызовы сразу
     */
    static GigaChatConcurrencyLimiter unlimited() {
        return new GigaChatConcurrencyLimiter(0, false, NOTICE_AFTER_MILLIS);
    }

    /**
     * Выполняет одну попытку запроса к GigaChat под разрешением очереди.
     *
     * @param call      сама попытка (HTTP-вызов)
     * @param cancelled проверка остановки прогона (null — без проверки)
     * @param notice    получатель уведомлений об ожидании в журнал прогона (null — только лог)
     * @param <T>       тип ответа
     * @return ответ вызова
     * @throws GigaChatException при остановке прогона или прерывании ожидания
     */
    public <T> T call(Supplier<T> call, BooleanSupplier cancelled, Consumer<String> notice) {
        if (maxConcurrent <= 0) {
            return call.get();
        }
        if (HOLDING.get() != null) {
            return nestedCall(call);
        }
        Permit permit = acquire(cancelled, notice);
        HOLDING.set(Boolean.TRUE);
        try {
            return call.get();
        } finally {
            HOLDING.remove();
            permit.close();
        }
    }

    /**
     * Запрос эмбеддингов: под общим лимитом, если включён {@code app.gigachat.limit-embeddings}.
     *
     * @param call      сама попытка (HTTP-вызов)
     * @param cancelled проверка остановки прогона (null — без проверки)
     * @param notice    получатель уведомлений об ожидании (null — только лог)
     * @param <T>       тип ответа
     * @return ответ вызова
     */
    public <T> T callEmbeddings(Supplier<T> call, BooleanSupplier cancelled, Consumer<String> notice) {
        return limitEmbeddings ? call(call, cancelled, notice) : call.get();
    }

    /**
     * Берёт разрешение, дожидаясь своей очереди. Основа и для реактивного варианта:
     * полученное разрешение обязательно закрыть ({@link Permit#close()} идемпотентен).
     *
     * @param cancelled проверка остановки прогона (null — без проверки; такой вызов ждёт не дольше
     *                  {@code app.gigachat.queue-max-wait-millis})
     * @param notice    получатель уведомлений об ожидании (null — только лог)
     * @return разрешение на один запрос
     * @throws GigaChatException при остановке прогона, прерывании или исчерпании предела ожидания
     */
    Permit acquire(BooleanSupplier cancelled, Consumer<String> notice) {
        if (maxConcurrent <= 0) {
            return Permit.free();
        }
        Object ticket = new Object();
        long start = System.currentTimeMillis();
        boolean granted = false;
        boolean noticed = false;
        enqueue(ticket);
        try {
            while (!granted) {
                granted = awaitTurn(ticket);
                if (!granted) {
                    checkCancelled(cancelled);
                    checkWaitLimit(cancelled, start);
                    noticed = noticeIfLong(notice, start, noticed);
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new GigaChatException(INTERRUPTED, e);
        } finally {
            if (!granted) {
                abandon(ticket);
            }
        }
        Permit permit = new Permit(this);
        reportGranted(notice, start, noticed);
        return permit;
    }

    /**
     * Регистрирует метрики занятости: запросы в работе, в очереди и лимит.
     *
     * @param registry реестр метрик
     */
    @Override
    public void bindTo(MeterRegistry registry) {
        Gauge.builder("gigachat.requests.active", this, GigaChatConcurrencyLimiter::inFlight)
                .description("Запросы к GigaChat, держащие разрешение").register(registry);
        Gauge.builder("gigachat.requests.waiting", this, GigaChatConcurrencyLimiter::waiting)
                .description("Запросы к GigaChat в очереди за разрешением").register(registry);
        Gauge.builder("gigachat.requests.limit", this, GigaChatConcurrencyLimiter::maxConcurrent)
                .description("Лимит одновременных запросов к GigaChat (0 — без ограничения)").register(registry);
    }

    /**
     * Запросов, держащих разрешение.
     *
     * @return число выданных и не закрытых разрешений
     */
    int inFlight() {
        lock.lock();
        try {
            return active;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Запросов в очереди за разрешением.
     *
     * @return длина очереди
     */
    int waiting() {
        lock.lock();
        try {
            return queue.size();
        } finally {
            lock.unlock();
        }
    }

    /**
     * Лимит одновременных запросов.
     *
     * @return настроенный лимит (0 и меньше — без ограничения)
     */
    int maxConcurrent() {
        return maxConcurrent;
    }

    /**
     * Эмбеддинги под общим лимитом.
     *
     * @return значение {@code app.gigachat.limit-embeddings}
     */
    boolean isLimitEmbeddings() {
        return limitEmbeddings;
    }

    /** Возвращает разрешение и будит очередь. */
    void release() {
        lock.lock();
        try {
            active--;
            changed.signalAll();
        } finally {
            lock.unlock();
        }
    }

    private <T> T nestedCall(Supplier<T> call) {
        log.warn("[{}] GigaChat: вложенный вызов на потоке, уже держащем разрешение, — без очереди",
                CurrentUserHolder.getCurrentUser());
        return call.get();
    }

    private void enqueue(Object ticket) {
        lock.lock();
        try {
            queue.addLast(ticket);
        } finally {
            lock.unlock();
        }
    }

    /**
     * Ждёт сигнала не дольше шага опроса; при своей очереди и свободном месте забирает разрешение.
     *
     * @param ticket билет очереди
     * @return {@code true}, если разрешение взято, {@code false} — по таймауту шага опроса
     * @throws InterruptedException при прерывании ожидания
     */
    @SuppressWarnings("java:S2274") // await не в while: повтор ожидания и лимиты (остановка прогона, queue-max-wait) держит
    // цикл acquire() на уровне метода — вложенный while здесь задерживал бы реакцию на остановку между сигналами
    private boolean awaitTurn(Object ticket) throws InterruptedException {
        lock.lock();
        try {
            if (!isTurn(ticket)) {
                boolean signaled = changed.await(POLL_MILLIS, TimeUnit.MILLISECONDS);
                if (!signaled || !isTurn(ticket)) {
                    return false;
                }
            }
            queue.removeFirst();
            active++;
            changed.signalAll();
            return true;
        } finally {
            lock.unlock();
        }
    }

    private boolean isTurn(Object ticket) {
        return queue.peekFirst() == ticket && active < maxConcurrent;
    }

    /** Убирает билет из очереди (отмена, прерывание) и будит следующего. */
    private void abandon(Object ticket) {
        lock.lock();
        try {
            queue.remove(ticket);
            changed.signalAll();
        } finally {
            lock.unlock();
        }
    }

    private static void checkCancelled(BooleanSupplier cancelled) {
        if (cancelled != null && cancelled.getAsBoolean()) {
            throw new GigaChatException(GigaChatClient.CANCELLED);
        }
    }

    /**
     * Предел ожидания очереди для вызова без проверки остановки прогона.
     *
     * @param cancelled проверка остановки прогона (null — вызов без прогона)
     * @param start     начало ожидания, мс
     * @throws GigaChatException если ожидание превысило {@code queueMaxWaitMillis}
     */
    private void checkWaitLimit(BooleanSupplier cancelled, long start) {
        if (cancelled != null || queueMaxWaitMillis <= 0 || System.currentTimeMillis() - start <= queueMaxWaitMillis) {
            return;
        }
        long minutes = Math.max(1, queueMaxWaitMillis / 60_000);
        log.warn("[{}] GigaChat: ожидание очереди {} мин исчерпано — занято {} из {}, ждут {}",
                CurrentUserHolder.getCurrentUser(), minutes, inFlight(), maxConcurrent, waiting());
        throw new GigaChatException(QUEUE_WAIT_EXHAUSTED + minutes + " мин исчерпано");
    }

    /** Один раз за ожидание, после порога: INFO в лог и уведомление в журнал прогона. */
    private boolean noticeIfLong(Consumer<String> notice, long start, boolean noticed) {
        if (noticed || System.currentTimeMillis() - start < noticeAfterMillis) {
            return noticed;
        }
        int queued = waiting();
        log.info("[{}] GigaChat: очередь запросов — занято {} из {}, ждут {}; ожидание дольше {} мс",
                CurrentUserHolder.getCurrentUser(), inFlight(), maxConcurrent, queued, noticeAfterMillis);
        tell(notice, "все " + maxConcurrent + " потоков GigaChat заняты — шаг ждёт очереди (ожидающих: " + queued + ")");
        return true;
    }

    /** Сообщает о пройденной очереди, только если об ожидании уже сообщалось. */
    private void reportGranted(Consumer<String> notice, long start, boolean noticed) {
        if (!noticed) {
            return;
        }
        long seconds = (System.currentTimeMillis() - start) / 1000;
        log.info("[{}] GigaChat: очередь пройдена за {} с — занято {} из {}, ждут {}",
                CurrentUserHolder.getCurrentUser(), seconds, inFlight(), maxConcurrent, waiting());
        tell(notice, "очередь к GigaChat пройдена за " + seconds + " с — запрос отправлен");
    }

    /** Уведомление в журнал; сбой получателя не должен ни ронять запрос, ни терять разрешение. */
    private static void tell(Consumer<String> notice, String text) {
        if (notice == null) {
            return;
        }
        try {
            notice.accept(text);
        } catch (RuntimeException e) {
            log.warn("[{}] GigaChat: уведомление об очереди не доставлено: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /** Разрешение на один запрос; закрытие идемпотентно. */
    static final class Permit implements AutoCloseable {

        private final GigaChatConcurrencyLimiter owner;
        private final AtomicBoolean closed = new AtomicBoolean();

        Permit(GigaChatConcurrencyLimiter owner) {
            this.owner = owner;
        }

        /**
         * Разрешение режима без ограничения: закрытие ничего не делает.
         *
         * @return пустое разрешение
         */
        static Permit free() {
            return new Permit(null);
        }

        /** Возвращает разрешение ограничителю; повторное закрытие ничего не делает. */
        @Override
        public void close() {
            if (owner != null && closed.compareAndSet(false, true)) {
                owner.release();
            }
        }
    }
}
