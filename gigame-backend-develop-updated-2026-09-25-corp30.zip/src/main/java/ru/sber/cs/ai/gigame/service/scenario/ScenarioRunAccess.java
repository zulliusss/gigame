package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.commons.lang3.ObjectUtils;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.model.ScenarioRun;

/**
 * Правило доступа к прогону сценария.
 * <p>
 * Общий сценарий запускают разные пользователи, и прогон содержит тексты
 * входных документов запустившего. Поэтому прогон (детали, DOCX-экспорт,
 * файлы output-узлов, возобновление, управление выполнением, вопросы агента)
 * доступен только его автору. Старые прогоны без автора ({@code userId == null},
 * созданы до появления поля) доступны владельцу сценария — как было раньше.
 * <p>
 * Идентификатор пользователя нормализуется как в {@code UserUtils}
 * и {@code CurrentUserHolder}: пустое значение означает {@value #ANONYMOUS}.
 */
public final class ScenarioRunAccess {

    /**
     * Идентификатор анонимного пользователя.
     */
    static final String ANONYMOUS = "anonymous";

    private ScenarioRunAccess() {
    }

    /**
     * Нормализует идентификатор пользователя: {@code null} и пустая строка
     * означают анонимного пользователя.
     *
     * @param userId идентификатор пользователя (может быть {@code null})
     * @return идентификатор пользователя или {@value #ANONYMOUS}
     */
    public static String normalizeUser(String userId) {
        return ObjectUtils.isEmpty(userId) ? ANONYMOUS : userId;
    }

    /**
     * Проверяет, доступен ли прогон пользователю.
     *
     * @param run             прогон
     * @param scenarioOwnerId владелец сценария прогона (нужен только для прогонов без автора)
     * @param userId          текущий пользователь (может быть {@code null})
     * @return {@code true} — пользователь автор прогона, либо у прогона нет автора
     * и пользователь владелец сценария
     */
    public static boolean canAccess(ScenarioRun run, String scenarioOwnerId, String userId) {
        String user = normalizeUser(userId);
        if (run.getUserId() == null) {
            return user.equals(scenarioOwnerId);
        }
        return user.equals(run.getUserId());
    }

    /**
     * Проверяет доступ к прогону и отказывает, если пользователь не автор
     * (для прогона без автора — не владелец сценария).
     *
     * @param run             прогон
     * @param scenarioOwnerId владелец сценария прогона
     * @param userId          текущий пользователь (может быть {@code null})
     * @throws AccessDeniedException прогон недоступен пользователю
     */
    public static void checkAccess(ScenarioRun run, String scenarioOwnerId, String userId) {
        if (!canAccess(run, scenarioOwnerId, userId)) {
            throw new AccessDeniedException("illegal userId");
        }
    }
}
