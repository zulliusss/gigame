package ru.sber.cs.ai.gigame.service;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.TextSplitter;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Индексация документов: разбиение на фрагменты, эмбеддинги, запись в pgvector.
 * <p>
 * Эмбеддинги считаются ВНЕ транзакции: вызовы GigaChat ждут в очереди лимитера и
 * длятся минутами, а соединение БД из пула Hikari на это время удерживаться не должно
 * (иначе пул исчерпывается и падают прогоны). Транзакции короткие: смена статуса на
 * processing, запись фрагментов + ready, запись ошибки.
 * <p>
 * Сбой эмбеддингов (исключение клиента GigaChat, пустой или нулевой вектор) —
 * это статус {@code error} с причиной, а не «ready» с мусорным индексом: фрагменты
 * документа при ошибке не записываются, а уже записанные удаляются; повторная
 * индексация возможна кнопкой «Переиндексировать». Документы, оставшиеся в
 * {@code processing} после рестарта сервера, при старте помечаются {@code error}.
 */
@Service
@Slf4j
public class DocumentIndexService {
    /** Текст ошибки для документов, чья индексация оборвалась вместе с JVM. */
    static final String RESTART_MESSAGE = "индексация прервана перезапуском сервера — "
            + "переиндексируйте документ или загрузите файл заново";
    private static final int EMBEDDING_BATCH = 50;
    private static final String STATUS_PROCESSING = "processing";
    private static final String STATUS_READY = "ready";
    private static final String STATUS_ERROR = "error";

    private final TransactionTemplate transactionTemplate;
    private final KBDocumentRepository kbDocumentRepository;
    private final DocumentRepository documentRepository;
    private final EmbeddingService embeddingService;
    private final TextSplitter textSplitter;
    private final GigaChatClient gigaChatClient;

    /** Размер фрагмента (символы) до согласования с пределом текста эмбеддинга. */
    @Value("${app.embedding.chunk-size:1000}")
    private int chunkSize = 1000;

    /** Перекрытие соседних фрагментов (символы). */
    @Value("${app.embedding.overlap:200}")
    private int overlap = 200;

    /**
     * Предел длины текста одного эмбеддинга у клиента GigaChat: фрагмент длиннее
     * усекается клиентом молча, поэтому фрагменты режутся не длиннее предела.
     */
    @Value("${app.embedding.text-max-length:800}")
    private int textMaxLength = 800;

    /** Предел фрагментов на документ; остаток текста не индексируется. 0 и меньше — без предела. */
    @Value("${app.embedding.max-chunks-per-document:2000}")
    private int maxChunksPerDocument = 2000;

    public DocumentIndexService(PlatformTransactionManager transactionManager, KBDocumentRepository kbDocumentRepository, DocumentRepository documentRepository, EmbeddingService embeddingService, TextSplitter textSplitter, GigaChatClient gigaChatClient) {
        this.kbDocumentRepository = kbDocumentRepository;
        this.documentRepository = documentRepository;
        this.embeddingService = embeddingService;
        this.textSplitter = textSplitter;
        this.gigaChatClient = gigaChatClient;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    @PostConstruct
    void init() {
        if (effectiveChunkSize() < chunkSize) {
            log.warn("app.embedding.chunk-size={} больше app.embedding.text-max-length={}: фрагменты режутся по {} символов, "
                    + "иначе хвост каждого фрагмента не попадал бы в вектор", chunkSize, textMaxLength, effectiveChunkSize());
        }
        log.info("DocumentIndexService: chunkSize={}, overlap={}, maxChunksPerDocument={}",
                effectiveChunkSize(), effectiveOverlap(), maxChunksPerDocument);
    }

    /**
     * Восстановление после рестарта: документы, оставшиеся в {@code processing}
     * (их поток индексации умер вместе с JVM), помечаются {@code error} с текстом
     * {@link #RESTART_MESSAGE} — иначе они вечно отображаются «индексируется».
     * Постановка в очередь заново не делается намеренно: файл после рестарта
     * недоступен (разбор шёл в фоне), а массовая переиндексация при старте
     * упирается в квоту GigaChat; пользователь переиндексирует сам.
     */
    @EventListener(ApplicationReadyEvent.class)
    public void failInterruptedIndexing() {
        List<KBDocument> interrupted = kbDocumentRepository.findByStatus(STATUS_PROCESSING);
        if (interrupted.isEmpty()) {
            return;
        }
        transactionTemplate.execute(status -> {
            for (KBDocument kbDoc : interrupted) {
                kbDoc.setStatus(STATUS_ERROR);
                kbDoc.setErrorMessage(RESTART_MESSAGE);
            }
            return kbDocumentRepository.saveAll(interrupted);
        });
        log.warn("Документы баз знаний, чья индексация прервана рестартом сервера, помечены error: {}", interrupted.size());
    }

    /**
     * Разбивает текст на фрагменты, вычисляет векторные эмбеддинги и сохраняет их.
     * <p>
     * Фрагменты сохраняются в векторное хранилище с использованием pgvector.
     * эмбеддинги вычисляются пакетами по 50 фрагментов (ограничение GigaChat API),
     * вне транзакции; запись фрагментов — своей короткой транзакцией.
     * Сбой эмбеддингов пробрасывается вызывающему — фрагменты не записываются.
     *
     * @param documentId UUID документа
     * @param text       полный извлечённый текст
     */
    public void indexDocument(UUID documentId, String text) {
        log.info("[{}] indexDocument, documentId={}", CurrentUserHolder.getCurrentUser(), documentId);
        List<String> chunks = limitChunks(split(text), documentId).chunks();
        if (chunks.isEmpty()) {
            return;
        }
        List<float[]> allEmbeddings = computeEmbeddings(chunks);
        embeddingService.storeDocumentChunks(documentId, chunks, allEmbeddings);
        log.info("[{}] Проиндексирован документ {}: {} фрагментов", CurrentUserHolder.getCurrentUser(), documentId, chunks.size());
    }

    /**
     * Переиндексирует документ в базе знаний: удаляет старые фрагменты,
     * заново вычисляет эмбеддинги и обновляет статус.
     * Выбрасывает исключение, если запись KBDocument не найдена.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @return обновлённый KBDocumentResponse
     */
    public KBDocumentResponse reindexDocument(UUID kbId, UUID documentId) {
        log.info("[{}] reindexDocument, kbId={}, documentId={}", CurrentUserHolder.getCurrentUser(), kbId, documentId);
        // транзакция 1: старые фрагменты удалены, статус processing
        KBDocument kbDoc = transactionTemplate.execute(status -> {
            KBDocument found = kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(kbId, documentId)
                    .orElseThrow(() -> new NotFoundException(
                            "Документ базы знаний не найден: kbId=" + kbId + " docId=" + documentId));
            embeddingService.deleteKBDocumentChunks(kbId, documentId);
            found.setStatus(STATUS_PROCESSING);
            found.setErrorMessage(null);
            return kbDocumentRepository.save(found);
        });
        KBDocument saved;
        try {
            // эмбеддинги — вне транзакции
            Chunked chunked = loadChunks(documentId);
            List<float[]> allEmbeddings = computeEmbeddings(chunked.chunks());
            // транзакция 2: фрагменты записаны, статус ready
            saved = transactionTemplate.execute(status -> markReady(kbId, documentId, kbDoc, chunked, allEmbeddings));
            log.info("[{}] Переиндексирован документ {} в KB {}: {} фрагментов", CurrentUserHolder.getCurrentUser(), documentId, kbId, chunked.chunks().size());
        } catch (Exception e) {
            log.error("[{}] Переиндексация не удалась для документа {} в KB {}", CurrentUserHolder.getCurrentUser(), documentId, kbId, e);
            // транзакция 3: статус error
            saved = transactionTemplate.execute(status -> markError(kbDoc, reason(e)));
        }
        return KBMapper.toKBDocumentResponse(saved);
    }

    /**
     * Асинхронно разбивает, вычисляет эмбеддинги и сохраняет текст документа
     * как векторные данные базы знаний (см. {@link #indexKBDocument}).
     * <p>
     * Выполняется на отдельном потоке (@Async, общий пул {@code spring.task.execution});
     * при переполнении очереди пула вызывающий получает
     * {@link org.springframework.core.task.TaskRejectedException}.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @param kbDocId    UUID записи KBDocument
     */
    @Async
    public void indexDocumentAsync(UUID kbId, UUID documentId, UUID kbDocId) {
        indexKBDocument(kbId, documentId, kbDocId);
    }

    /**
     * Индексирует документ базы знаний в текущем потоке: фрагменты, эмбеддинги
     * (вне транзакции), запись фрагментов со статусом ready одной короткой
     * транзакцией. Любая ошибка — статус error с причиной, фрагменты документа
     * в этой базе удалены.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @param kbDocId    UUID записи KBDocument
     */
    public void indexKBDocument(UUID kbId, UUID documentId, UUID kbDocId) {
        log.info("[{}] indexKBDocument, kbId={}, documentId={}, kbDocId={}",
                CurrentUserHolder.getCurrentUser(), kbId, documentId, kbDocId);
        try {
            Chunked chunked = loadChunks(documentId);
            List<float[]> allEmbeddings = computeEmbeddings(chunked.chunks());
            transactionTemplate.execute(status -> {
                KBDocument kbDoc = kbDocumentRepository.findById(kbDocId)
                        .orElseThrow(() -> new IllegalStateException("KBDocument не найден: " + kbDocId));
                return markReady(kbId, documentId, kbDoc, chunked, allEmbeddings);
            });
            log.info("Проиндексирован документ {} в KB {}: {} фрагментов", documentId, kbId, chunked.chunks().size());
        } catch (Exception e) {
            log.error("Не удалось проиндексировать документ {} в KB {}", documentId, kbId, e);
            markIndexingFailed(kbId, documentId, kbDocId, reason(e));
        }
    }

    /**
     * Фиксирует сбой индексации: фрагменты документа в базе удалены, статус
     * error с текстом причины (одной транзакцией). Используется и снаружи —
     * когда индексация не началась (разбор не удался, очередь переполнена).
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @param kbDocId    UUID записи KBDocument
     * @param message    причина для error_message
     * @return обновлённая запись либо {@code null}, если записи уже нет
     */
    public KBDocument markIndexingFailed(UUID kbId, UUID documentId, UUID kbDocId, String message) {
        return transactionTemplate.execute(status -> {
            embeddingService.deleteKBDocumentChunks(kbId, documentId);
            return kbDocumentRepository.findById(kbDocId)
                    .map(kbDoc -> markError(kbDoc, message))
                    .orElse(null);
        });
    }

    /**
     * Фрагменты извлечённого текста документа (чтение без транзакции).
     *
     * @param documentId UUID документа
     * @return непустой список фрагментов (не больше предела) и их полное число
     * @throws NotFoundException     документ не найден
     * @throws IllegalStateException текст пуст или не дал фрагментов
     */
    private Chunked loadChunks(UUID documentId) {
        Document doc = documentRepository.findById(documentId)
                .orElseThrow(() -> new NotFoundException("Документ не найден: " + documentId));
        if (doc.getExtractedText() == null || doc.getExtractedText().isBlank()) {
            throw new IllegalStateException("Документ не содержит извлечённого текста");
        }
        Chunked chunked = limitChunks(split(doc.getExtractedText()), documentId);
        if (chunked.chunks().isEmpty()) {
            throw new IllegalStateException("Документ не дал фрагментов");
        }
        return chunked;
    }

    /**
     * Разбиение текста фрагментами не длиннее предела текста эмбеддинга.
     *
     * @param text текст документа
     * @return фрагменты
     */
    private List<String> split(String text) {
        return textSplitter.split(text, effectiveChunkSize(), effectiveOverlap());
    }

    /** Размер фрагмента: не больше предела текста эмбеддинга (если он задан). */
    int effectiveChunkSize() {
        return textMaxLength > 0 ? Math.min(chunkSize, textMaxLength) : chunkSize;
    }

    /** Перекрытие не больше половины фрагмента — иначе фрагменты почти дублируют друг друга. */
    private int effectiveOverlap() {
        return Math.min(overlap, effectiveChunkSize() / 2);
    }

    /**
     * Первые {@code app.embedding.max-chunks-per-document} фрагментов; остаток
     * не индексируется (книга Excel на 26 млн символов дала бы десятки тысяч
     * вызовов эмбеддингов на один документ).
     *
     * @param chunks     все фрагменты
     * @param documentId UUID документа (для журнала)
     * @return фрагменты не более предела и их полное число
     */
    private Chunked limitChunks(List<String> chunks, UUID documentId) {
        if (maxChunksPerDocument <= 0 || chunks.size() <= maxChunksPerDocument) {
            return new Chunked(chunks, chunks.size());
        }
        log.warn("[{}] Документ {}: фрагментов {} больше предела {} — индексируются только первые",
                CurrentUserHolder.getCurrentUser(), documentId, chunks.size(), maxChunksPerDocument);
        return new Chunked(new ArrayList<>(chunks.subList(0, maxChunksPerDocument)), chunks.size());
    }

    /**
     * Эмбеддинги фрагментов пакетами по 50 (ограничение GigaChat API) — вне транзакции.
     * Ответ проверяется: число векторов равно числу фрагментов, вектор не пустой и
     * не нулевой — иначе сбой, а не «ready» с мусорным индексом.
     *
     * @param chunks фрагменты
     * @return эмбеддинги в порядке фрагментов
     * @throws IllegalStateException ответ клиента не годится для индекса
     */
    private List<float[]> computeEmbeddings(List<String> chunks) {
        List<float[]> allEmbeddings = new ArrayList<>();
        for (int i = 0; i < chunks.size(); i += EMBEDDING_BATCH) {
            List<String> batch = chunks.subList(i, Math.min(i + EMBEDDING_BATCH, chunks.size()));
            List<float[]> embeddings = gigaChatClient.getEmbeddings(batch);
            validateEmbeddings(batch, embeddings, i);
            allEmbeddings.addAll(embeddings);
        }
        return allEmbeddings;
    }

    private static void validateEmbeddings(List<String> batch, List<float[]> embeddings, int offset) {
        if (embeddings == null || embeddings.size() != batch.size()) {
            throw new IllegalStateException("сервис эмбеддингов вернул " + (embeddings == null ? 0 : embeddings.size())
                    + " векторов вместо " + batch.size());
        }
        for (int j = 0; j < embeddings.size(); j++) {
            if (isEmptyVector(embeddings.get(j))) {
                throw new IllegalStateException("сервис эмбеддингов вернул пустой вектор для фрагмента " + (offset + j + 1));
            }
        }
    }

    private static boolean isEmptyVector(float[] vector) {
        if (vector == null || vector.length == 0) {
            return true;
        }
        for (float v : vector) {
            if (v != 0f) {
                return false;
            }
        }
        return true;
    }

    /** Причина сбоя для error_message: сообщение исключения либо его класс. */
    private static String reason(Exception e) {
        String message = e.getMessage();
        return message == null || message.isBlank() ? e.getClass().getSimpleName() : message;
    }

    /** Внутри транзакции: запись фрагментов базы знаний и статус ready (с пометкой о неполном индексе). */
    private KBDocument markReady(UUID kbId, UUID documentId, KBDocument kbDoc,
                                 Chunked chunked, List<float[]> embeddings) {
        embeddingService.storeKBChunks(kbId, documentId, chunked.chunks(), embeddings);
        kbDoc.setChunkCount(chunked.chunks().size());
        kbDoc.setStatus(STATUS_READY);
        kbDoc.setErrorMessage(chunked.note());
        return kbDocumentRepository.save(kbDoc);
    }

    /** Внутри транзакции: статус error с текстом причины. */
    private KBDocument markError(KBDocument kbDoc, String message) {
        kbDoc.setStatus(STATUS_ERROR);
        kbDoc.setErrorMessage(message);
        return kbDocumentRepository.save(kbDoc);
    }

    /**
     * Фрагменты документа после применения предела и их полное число.
     *
     * @param chunks фрагменты для индексации (не больше предела)
     * @param total  сколько фрагментов дал весь текст
     */
    record Chunked(List<String> chunks, int total) {

        /**
         * Пометка для error_message документа, если текст проиндексирован не целиком.
         *
         * @return текст пометки либо {@code null}, когда проиндексировано всё
         */
        String note() {
            if (total <= chunks.size()) {
                return null;
            }
            return "проиндексированы первые " + chunks.size() + " из " + total
                    + " фрагментов (предел app.embedding.max-chunks-per-document)";
        }
    }
}
