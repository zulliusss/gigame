package ru.sber.cs.ai.gigame.service.annotate;

import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFComment;
import org.apache.poi.xwpf.usermodel.XWPFComments;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.xmlbeans.XmlCursor;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTRPr;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTText;

import javax.xml.namespace.QName;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * Разметка находок в DOCX: цитата подсвечивается цветом уровня риска, к ней прикрепляется комментарий Word
 * с текстом находки. Документ не пересобирается — меняются только раны абзацев с цитатой.
 * <p>
 * Цитата ищется по абзацам тела и таблиц ({@link TextLocator}); текст абзаца собирается из ранов, поэтому
 * найденный диапазон делит раны по границам цитаты (свойства ранов копируются). Цитата длиннее абзаца или
 * через абзацы подсвечивается по началу, о чём остаётся пометка.
 */
public final class DocxAnnotator {

    private static final String W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    private static final String AUTHOR = "GigaMe";
    /** Сколько знаков отмеченного куска показывать в отчёте. */
    private static final int NOTE_FRAGMENT_CHARS = 80;

    private DocxAnnotator() {
    }

    /**
     * Итог разметки документа.
     *
     * @param content   размеченный документ
     * @param annotated сколько находок отмечено
     * @param notes     пометки по находкам, которые не найдены или отмечены частично
     */
    public record Result(byte[] content, int annotated, List<String> notes) {
    }

    /** Абзац с найденным диапазоном цитаты. */
    private record Hit(XWPFParagraph paragraph, TextLocator.Span span) {
    }

    /**
     * Размечает находки в документе.
     *
     * @param docx     исходный документ
     * @param findings находки этого документа
     * @return размеченный документ и пометки
     * @throws IOException документ не открывается или не записывается
     */
    public static Result annotate(byte[] docx, List<Finding> findings) throws IOException {
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(docx))) {
            List<XWPFParagraph> paragraphs = allParagraphs(doc);
            XWPFComments comments = doc.getDocComments() != null ? doc.getDocComments() : doc.createComments();
            List<String> notes = new ArrayList<>();
            int annotated = 0;
            for (Finding finding : findings) {
                Hit hit = locate(paragraphs, finding);
                if (hit == null) {
                    notes.add("находка № " + finding.number() + ": цитата в документе не найдена — не отмечена");
                    continue;
                }
                if (!mark(hit, finding, comments)) {
                    notes.add("находка № " + finding.number() + ": цитату не удалось подсветить — не отмечена");
                    continue;
                }
                annotated++;
                if (hit.span().partial()) {
                    notes.add("находка № " + finding.number() + ": цитата найдена не целиком — отмечено «"
                            + fragment(hit) + "»");
                }
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.write(out);
            return new Result(out.toByteArray(), annotated, notes);
        }
    }

    /** Абзацы тела документа и всех таблиц (включая вложенные) в порядке следования. */
    static List<XWPFParagraph> allParagraphs(XWPFDocument doc) {
        List<XWPFParagraph> out = new ArrayList<>();
        collect(doc.getBodyElements(), out);
        return out;
    }

    private static void collect(List<IBodyElement> elements, List<XWPFParagraph> out) {
        for (IBodyElement element : elements) {
            if (element instanceof XWPFParagraph paragraph) {
                out.add(paragraph);
            } else if (element instanceof XWPFTable table) {
                collectTable(table, out);
            }
        }
    }

    private static void collectTable(XWPFTable table, List<XWPFParagraph> out) {
        for (XWPFTableRow row : table.getRows()) {
            for (XWPFTableCell cell : row.getTableCells()) {
                collect(cell.getBodyElements(), out);
            }
        }
    }

    /** Абзац с цитатой: сначала полное совпадение, затем — по началу; для находок без цитаты — по числам. */
    private static Hit locate(List<XWPFParagraph> paragraphs, Finding finding) {
        Hit partial = null;
        for (XWPFParagraph paragraph : paragraphs) {
            TextLocator.Span span = finding.locateIn(paragraphText(paragraph));
            if (span == null) {
                continue;
            }
            if (!span.partial()) {
                return new Hit(paragraph, span);
            }
            if (partial == null || length(span) > length(partial.span())) {
                partial = new Hit(paragraph, span);
            }
        }
        return partial;
    }

    /**
     * Отмеченный кусок текста для отчёта — по нему видно, туда ли села подсветка.
     *
     * @param hit абзац и диапазон
     * @return текст диапазона, длинный — обрезан многоточием
     */
    private static String fragment(Hit hit) {
        String text = paragraphText(hit.paragraph());
        int end = Math.min(hit.span().end(), text.length());
        String piece = text.substring(Math.min(hit.span().start(), end), end).strip();
        return piece.length() > NOTE_FRAGMENT_CHARS ? piece.substring(0, NOTE_FRAGMENT_CHARS) + "…" : piece;
    }

    /** Длина найденного фрагмента: из частичных совпадений выбирается самое длинное. */
    private static int length(TextLocator.Span span) {
        return span.end() - span.start();
    }

    /** Текст абзаца как конкатенация текстов ранов — в тех же позициях, что и при делении ранов. */
    private static String paragraphText(XWPFParagraph paragraph) {
        StringBuilder sb = new StringBuilder();
        for (XWPFRun run : paragraph.getRuns()) {
            sb.append(run.text());
        }
        return sb.toString();
    }

    /**
     * Подсветка ранов цитаты и комментарий к ним.
     *
     * @param hit      абзац и диапазон цитаты
     * @param finding  находка
     * @param comments комментарии документа
     * @return легла ли разметка (нет — если в абзаце не нашлось ранов диапазона)
     */
    private static boolean mark(Hit hit, Finding finding, XWPFComments comments) {
        XWPFParagraph paragraph = hit.paragraph();
        List<XWPFRun> runs = isolate(paragraph, hit.span().start(), hit.span().end());
        if (runs.isEmpty()) {
            return false;
        }
        for (XWPFRun run : runs) {
            run.setTextHighlightColor(finding.color());
        }
        BigInteger id = nextCommentId(comments);
        XWPFComment comment = comments.createComment(id);
        comment.setAuthor(AUTHOR);
        comment.setInitials("GM");
        for (String line : finding.comment().split("\n")) {
            comment.createParagraph().createRun().setText(line);
        }
        XWPFRun first = runs.get(0);
        XWPFRun last = runs.get(runs.size() - 1);
        insertMarkup(first, "commentRangeStart", id, false);
        insertMarkup(last, "commentRangeEnd", id, true);
        XWPFRun reference = paragraph.insertNewRun(paragraph.getRuns().indexOf(last) + 1);
        reference.getCTR().addNewCommentReference().setId(id);
        return true;
    }

    /**
     * Раны, целиком лежащие в диапазоне [start, end): граничные раны делятся, если делятся безопасно
     * ({@link #splittable}). Если делить нельзя (ран с табуляцией, переносом строки, рисунком), берутся раны,
     * которые задевают диапазон — подсветка ляжет чуть шире цитаты, но текст документа не пострадает.
     *
     * @param paragraph абзац
     * @param start     начало диапазона в тексте абзаца
     * @param end       конец диапазона (исключительно)
     * @return раны для подсветки, пустой список — если диапазон вне абзаца
     */
    static List<XWPFRun> isolate(XWPFParagraph paragraph, int start, int end) {
        splitAt(paragraph, end);
        splitAt(paragraph, start);
        List<XWPFRun> inside = collect(paragraph, start, end, true);
        return inside.isEmpty() ? collect(paragraph, start, end, false) : inside;
    }

    /**
     * Раны абзаца, лежащие внутри диапазона либо задевающие его.
     *
     * @param paragraph абзац
     * @param start     начало диапазона
     * @param end       конец диапазона (исключительно)
     * @param strict    только раны целиком внутри диапазона
     * @return раны в порядке следования
     */
    private static List<XWPFRun> collect(XWPFParagraph paragraph, int start, int end, boolean strict) {
        List<XWPFRun> out = new ArrayList<>();
        int offset = 0;
        for (XWPFRun run : paragraph.getRuns()) {
            int length = run.text().length();
            boolean hit = strict ? offset >= start && offset + length <= end : offset < end && offset + length > start;
            if (hit && length > 0) {
                out.add(run);
            }
            offset += length;
        }
        return out;
    }

    private static void splitAt(XWPFParagraph paragraph, int at) {
        int offset = 0;
        List<XWPFRun> runs = paragraph.getRuns();
        for (int i = 0; i < runs.size(); i++) {
            XWPFRun run = runs.get(i);
            int length = run.text().length();
            if (at > offset && at < offset + length) {
                if (splittable(run)) {
                    splitRun(paragraph, i, run, at - offset);
                }
                return;
            }
            offset += length;
        }
    }

    /**
     * Можно ли делить ран по тексту: делятся только элементы {@code <w:t>}, поэтому текст рана должен из них
     * и складываться. У рана с табуляцией, переносом строки или рисунком текст шире — деление сдвинуло бы
     * позиции и попортило содержимое.
     *
     * @param run ран абзаца
     * @return {@code true}, если деление безопасно
     */
    private static boolean splittable(XWPFRun run) {
        StringBuilder sb = new StringBuilder();
        for (CTText text : run.getCTR().getTList()) {
            sb.append(text.getStringValue());
        }
        return sb.toString().equals(run.text());
    }

    private static void splitRun(XWPFParagraph paragraph, int index, XWPFRun run, int at) {
        String text = run.text();
        XWPFRun tail = paragraph.insertNewRun(index + 1);
        CTRPr properties = run.getCTR().getRPr();
        if (properties != null) {
            tail.getCTR().setRPr((CTRPr) properties.copy());
        }
        tail.setText(text.substring(at), 0);
        setText(run, text.substring(0, at));
    }

    private static void setText(XWPFRun run, String text) {
        CTR ctr = run.getCTR();
        while (ctr.sizeOfTArray() > 0) {
            ctr.removeT(0);
        }
        run.setText(text, 0);
    }

    private static BigInteger nextCommentId(XWPFComments comments) {
        BigInteger max = BigInteger.ZERO;
        for (XWPFComment existing : comments.getComments()) {
            try {
                max = max.max(new BigInteger(existing.getId()));
            } catch (NumberFormatException e) {
                // нечисловой идентификатор чужого комментария — не мешает нумерации
            }
        }
        return max.add(BigInteger.ONE);
    }

    /** Элемент commentRangeStart/commentRangeEnd перед раном или сразу после него. */
    private static void insertMarkup(XWPFRun run, String element, BigInteger id, boolean after) {
        try (XmlCursor cursor = run.getCTR().newCursor()) {
            if (after) {
                cursor.toEndToken();
                cursor.toNextToken();
            }
            cursor.beginElement(new QName(W_NS, element, "w"));
            cursor.insertAttributeWithValue(new QName(W_NS, "id", "w"), id.toString());
        }
    }
}
