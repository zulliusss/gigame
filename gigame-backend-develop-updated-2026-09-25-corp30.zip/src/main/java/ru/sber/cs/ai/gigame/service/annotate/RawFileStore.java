package ru.sber.cs.ai.gigame.service.annotate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * Склад исходных файлов загруженных документов на диске — для разметки находок в самих документах.
 * <p>
 * Кэш документов сценария хранит только извлечённый текст, а подсветить цитату можно лишь в исходном
 * DOCX или PDF. Файлы складываются по ключу кэша документов ({@code сценарий + пользователь}) под именем
 * документа (для документов из архива — «архив.zip/папка/файл.pdf») и хэшем его текста: одноимённые
 * документы с разным содержимым (догрузка второго лота с тем же «Договор.pdf») не перетирают друг друга.
 * Файлы живут {@code app.annotate.raw-ttl-hours} часов с последней загрузки и вычищаются плановой задачей;
 * новая загрузка без догрузки очищает склад ключа вместе с кэшем.
 * <p>
 * corp23: суммарный объём склада ограничен {@code app.annotate.raw-max-mb} (0 — без предела): перед записью
 * самые старые каталоги вытесняются с предупреждением, при нехватке места на диске файл не сохраняется —
 * загрузка не падает, разметка этого документа будет недоступна (пометка в отчёте разметки). Оригиналы
 * прогона закрепляются снимком {@link #snapshotForRun}: каталог {@code runs/<runId>} с жёсткими ссылками
 * (или копиями) на файлы ключа на момент запуска — новая загрузка без догрузки и чистка ключа во время
 * прогона их не трогают; снимки живут тот же срок и входят в общий объём (ссылки считаются как файлы —
 * оценка сверху).
 */
@Slf4j
@Service
public class RawFileStore {

    /** Подкаталог снимков оригиналов прогонов: {@code <корень>/runs/<runId>}. */
    static final String RUNS_DIR = "runs";
    /** Запас свободного места на диске сверх размера файла, байт: временные файлы multipart, POI и PDFBox. */
    static final long FREE_SPACE_MARGIN = 64L * 1024 * 1024;
    private static final String CONTENT_SUFFIX = ".bin";
    private static final String NAME_SUFFIX = ".name";
    private static final long MB = 1024L * 1024;

    @Value("${app.annotate.raw-dir:${java.io.tmpdir}/gigame-originals}")
    private String rootDir;

    @Value("${app.annotate.raw-ttl-hours:24}")
    private int ttlHours;

    /** Предел суммарного объёма склада, МБ; 0 и меньше — без предела. */
    @Value("${app.annotate.raw-max-mb:2048}")
    private int maxMb = 2048;

    /** Занятый объём склада, байт; -1 — ещё не посчитан (считается обходом при первом обращении). */
    private long usedBytes = -1;

    /** Конструктор для Spring (настройки внедряются в поля). */
    public RawFileStore() {
    }

    /**
     * Склад с заданным каталогом и сроком жизни (тесты), предел объёма — по умолчанию.
     *
     * @param rootDir  корневой каталог
     * @param ttlHours срок жизни файлов ключа, часов
     */
    public RawFileStore(String rootDir, int ttlHours) {
        this(rootDir, ttlHours, 2048);
    }

    /**
     * Склад с заданным каталогом, сроком жизни и пределом объёма (тесты).
     *
     * @param rootDir  корневой каталог
     * @param ttlHours срок жизни файлов ключа, часов
     * @param maxMb    предел суммарного объёма, МБ (0 — без предела)
     */
    public RawFileStore(String rootDir, int ttlHours, int maxMb) {
        this.rootDir = rootDir;
        this.ttlHours = ttlHours;
        this.maxMb = maxMb;
    }

    /**
     * Сохраняет исходный файл документа под ключом «имя + хэш текста»: документ с тем же именем и текстом
     * перезаписывается, с тем же именем и другим текстом — хранится рядом.
     *
     * @param key     ключ кэша документов
     * @param name    имя документа
     * @param text    извлечённый текст документа (как в кэше документов; {@code null} — ключ только по имени)
     * @param content содержимое файла
     * @return {@code true}, если файл на складе (пустое содержимое — нечего сохранять, тоже {@code true});
     *         {@code false} — не сохранён (нет места, ошибка записи): разметка документа будет недоступна
     */
    public boolean save(UUID key, String name, String text, byte[] content) {
        if (content == null || content.length == 0) {
            return true;
        }
        long size = content.length;
        try {
            if (!reserve(size)) {
                log.warn("Склад исходных файлов: «{}» ({} КБ) не сохранён — нет места (предел склада {} МБ или диск) — "
                        + "разметка этого документа будет недоступна", name, size / 1024, maxMb);
                return false;
            }
            Path dir = Files.createDirectories(keyDir(key));
            String stem = stem(name, text);
            Files.write(dir.resolve(stem + CONTENT_SUFFIX), content);
            Files.writeString(dir.resolve(stem + NAME_SUFFIX), name, StandardCharsets.UTF_8);
            Files.setLastModifiedTime(dir, FileTime.from(Instant.now()));
            return true;
        } catch (IOException e) {
            release(size);
            log.warn("Склад исходных файлов: «{}» не сохранён ({}) — разметка этого документа будет недоступна",
                    name, e.getMessage());
            return false;
        }
    }

    /**
     * Исходный файл документа: сначала из снимка прогона, затем со склада ключа.
     *
     * @param key   ключ кэша документов
     * @param runId прогон, для которого снят снимок ({@code null} — только склад ключа)
     * @param name  имя документа
     * @param text  текст документа (как при сохранении)
     * @return содержимое либо пусто, если файл не сохранялся или уже вычищен
     */
    public Optional<byte[]> load(UUID key, UUID runId, String name, String text) {
        String file = stem(name, text) + CONTENT_SUFFIX;
        Path path = runId == null ? null : runDir(runId).resolve(file);
        if (path == null || !Files.isRegularFile(path)) {
            path = keyDir(key).resolve(file);
        }
        if (!Files.isRegularFile(path)) {
            return Optional.empty();
        }
        try {
            return Optional.of(Files.readAllBytes(path));
        } catch (IOException e) {
            log.warn("Склад исходных файлов: «{}» не прочитан ({})", name, e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * Закрепляет оригиналы ключа за прогоном: каталог {@code runs/<runId>} с жёсткими ссылками (при невозможности —
     * копиями) на файлы ключа на момент вызова. Повторный вызов для того же прогона ничего не делает. Если склад
     * ключа пуст (очищен новой загрузкой), источником служит снимок предыдущего прогона (возобновление).
     *
     * @param key           ключ кэша документов
     * @param runId         прогон
     * @param previousRunId прогон-предшественник при возобновлении ({@code null} — нет)
     */
    public synchronized void snapshotForRun(UUID key, UUID runId, UUID previousRunId) {
        Path target = runDir(runId);
        if (Files.isDirectory(target)) {
            return;
        }
        Path source = keyDir(key);
        if (!Files.isDirectory(source) && previousRunId != null) {
            source = runDir(previousRunId);
        }
        if (!Files.isDirectory(source)) {
            return;
        }
        try {
            Files.createDirectories(target);
            long linked = linkAll(source, target);
            Files.setLastModifiedTime(target, FileTime.from(Instant.now()));
            addUsed(linked);
            log.info("Склад исходных файлов: снимок оригиналов прогона {} из {} ({} КБ)", runId, source.getFileName(), linked / 1024);
        } catch (IOException e) {
            log.warn("Склад исходных файлов: снимок оригиналов прогона {} не снят ({}) — разметка возьмёт файлы ключа",
                    runId, e.getMessage());
        }
    }

    /**
     * Удаляет все файлы ключа (новая загрузка без догрузки); снимки прогонов не трогаются.
     *
     * @param key ключ кэша документов
     */
    public synchronized void clear(UUID key) {
        deleteTree(keyDir(key));
    }

    /**
     * Плановая чистка: каталоги ключей, к которым не было загрузок дольше срока жизни, и снимки прогонов
     * старше срока жизни удаляются.
     */
    @Scheduled(fixedRateString = "${app.annotate.cleanup-rate-ms:3600000}")
    public synchronized void evictStale() {
        Instant deadline = Instant.now().minus(Math.max(1, ttlHours), ChronoUnit.HOURS);
        for (Path dir : keyDirs()) {
            if (modifiedBefore(dir, deadline)) {
                deleteTree(dir);
            }
        }
        for (Path dir : runDirs()) {
            if (modifiedBefore(dir, deadline)) {
                deleteTree(dir);
            }
        }
    }

    /**
     * Занятый объём склада, байт (обход каталогов при первом обращении).
     *
     * @return занятый объём
     */
    public synchronized long usedBytes() {
        if (usedBytes < 0) {
            usedBytes = sizeOf(Paths.get(rootDir));
        }
        return usedBytes;
    }

    /**
     * Ключ файла на складе: SHA-256 от имени и SHA-256 текста (без текста — от имени, как прежде).
     *
     * @param name имя документа
     * @param text текст документа
     * @return шестнадцатеричный ключ
     */
    static String stem(String name, String text) {
        String base = text == null ? name : name + "\n" + DocumentService.sha256Hex(text.getBytes(StandardCharsets.UTF_8));
        return DocumentService.sha256Hex(base.getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Резервирует место под файл: при превышении предела объёма вытесняет самые старые каталоги (сначала
     * ключей, затем снимков прогонов), затем проверяет свободное место на диске.
     *
     * @param size размер файла, байт
     * @return {@code true}, если файл можно записывать
     */
    private synchronized boolean reserve(long size) throws IOException {
        long limit = maxMb * MB;
        Path root = Files.createDirectories(Paths.get(rootDir));
        if (limit > 0) {
            if (size > limit) {
                return false;
            }
            if (usedBytes() + size > limit) {
                evictOldest(usedBytes() + size - limit);
            }
            if (usedBytes() + size > limit) {
                return false;
            }
        }
        if (Files.getFileStore(root).getUsableSpace() < size + FREE_SPACE_MARGIN) {
            log.warn("Склад исходных файлов: на диске {} меньше {} МБ свободного места", root, (size + FREE_SPACE_MARGIN) / MB);
            return false;
        }
        addUsed(size);
        return true;
    }

    private synchronized void release(long size) {
        addUsed(-size);
    }

    private void addUsed(long delta) {
        if (usedBytes >= 0) {
            usedBytes = Math.max(0, usedBytes + delta);
        }
    }

    /** Вытесняет самые старые каталоги (ключи, затем снимки прогонов), пока не освободится {@code needed} байт. */
    private void evictOldest(long needed) {
        long freed = 0;
        List<Path> candidates = new ArrayList<>(keyDirs());
        candidates.addAll(runDirs());
        for (Path dir : candidates) {
            if (freed >= needed) {
                return;
            }
            long size = sizeOf(dir);
            log.warn("Склад исходных файлов: предел объёма {} МБ достигнут — вытеснен каталог {} ({} КБ)",
                    maxMb, dir.getFileName(), size / 1024);
            deleteTree(dir);
            freed += size;
        }
    }

    /** Каталоги ключей от самых старых к новым. */
    private List<Path> keyDirs() {
        return sortedDirs(Paths.get(rootDir), dir -> !RUNS_DIR.equals(dir.getFileName().toString()));
    }

    /** Каталоги снимков прогонов от самых старых к новым. */
    private List<Path> runDirs() {
        return sortedDirs(Paths.get(rootDir).resolve(RUNS_DIR), dir -> true);
    }

    private List<Path> sortedDirs(Path parent, Predicate<Path> filter) {
        if (!Files.isDirectory(parent)) {
            return List.of();
        }
        try (Stream<Path> dirs = Files.list(parent)) {
            return dirs.filter(Files::isDirectory).filter(filter)
                    .sorted(Comparator.comparing(RawFileStore::modifiedAt)).toList();
        } catch (IOException e) {
            log.warn("Склад исходных файлов: каталог {} не прочитан ({})", parent, e.getMessage());
            return List.of();
        }
    }

    /** Жёсткие ссылки (или копии) всех файлов каталога; возвращает их суммарный размер. */
    private static long linkAll(Path source, Path target) throws IOException {
        long linked = 0;
        try (Stream<Path> files = Files.list(source)) {
            for (Path file : files.filter(Files::isRegularFile).toList()) {
                linked += linkOrCopy(file, target.resolve(file.getFileName()));
            }
        }
        return linked;
    }

    private static long linkOrCopy(Path source, Path target) throws IOException {
        try {
            Files.createLink(target, source);
        } catch (IOException | UnsupportedOperationException e) {
            Files.copy(source, target);
        }
        return Files.size(target);
    }

    private Path keyDir(UUID key) {
        return Paths.get(rootDir).resolve(key.toString());
    }

    private Path runDir(UUID runId) {
        return Paths.get(rootDir).resolve(RUNS_DIR).resolve(runId.toString());
    }

    private static Instant modifiedAt(Path dir) {
        try {
            return Files.getLastModifiedTime(dir).toInstant();
        } catch (IOException e) {
            return Instant.MAX;
        }
    }

    private static boolean modifiedBefore(Path dir, Instant deadline) {
        Instant modified = modifiedAt(dir);
        return !modified.equals(Instant.MAX) && modified.isBefore(deadline);
    }

    private static long sizeOf(Path dir) {
        if (!Files.isDirectory(dir)) {
            return 0;
        }
        try (Stream<Path> files = Files.walk(dir)) {
            return files.filter(Files::isRegularFile).mapToLong(RawFileStore::fileSize).sum();
        } catch (IOException e) {
            return 0;
        }
    }

    private static long fileSize(Path file) {
        try {
            return Files.size(file);
        } catch (IOException e) {
            return 0;
        }
    }

    private void deleteTree(Path dir) {
        if (!Files.exists(dir)) {
            return;
        }
        long size = sizeOf(dir);
        try {
            Files.walkFileTree(dir, new SimpleFileVisitor<>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    Files.delete(file);
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult postVisitDirectory(Path directory, IOException exc) throws IOException {
                    Files.delete(directory);
                    return FileVisitResult.CONTINUE;
                }
            });
            addUsed(-size);
        } catch (IOException e) {
            log.warn("Склад исходных файлов: каталог {} не удалён ({})", dir, e.getMessage());
            usedBytes = -1;
        }
    }
}
