package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.Document;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с загруженными документами.
 * <p>
 * Предоставляет стандартные CRUD-операции для сущности Document.
 *
 * @see Document
 */
@Repository
public interface DocumentRepository extends JpaRepository<Document, UUID> {

    /**
     * Документы-сироты: загружены раньше границы, не входят ни в одну базу знаний
     * и не упомянуты в {@code messages.document_ids} ни одного сообщения — файл
     * загрузили в диалог, но вопрос с ним так и не отправили (или кэш документов
     * истёк раньше). Ссылки из сообщений собираются одним проходом
     * ({@code NOT IN} по развёрнутому JSONB-массиву — хеш-подплан PostgreSQL),
     * а не подзапросом на каждый документ.
     *
     * @param cutoff граница по дате загрузки (created_at раньше — кандидат)
     * @param limit  максимум идентификаторов за вызов (пачка удаления)
     * @return идентификаторы сирот, самые старые первыми
     */
    @Query(value = "SELECT d.id FROM {h-schema}documents d "
            + "WHERE d.created_at < :cutoff "
            + "AND NOT EXISTS (SELECT 1 FROM {h-schema}kb_documents k WHERE k.document_id = d.id) "
            + "AND CAST(d.id AS TEXT) NOT IN ("
            + "SELECT e.v FROM {h-schema}messages m, jsonb_array_elements_text(m.document_ids) e(v) "
            + "WHERE m.document_ids IS NOT NULL AND jsonb_typeof(m.document_ids) = 'array' AND e.v IS NOT NULL) "
            + "ORDER BY d.created_at ASC "
            + "LIMIT :limit",
            nativeQuery = true)
    List<UUID> findOrphanIds(@Param("cutoff") OffsetDateTime cutoff, @Param("limit") int limit);
}
