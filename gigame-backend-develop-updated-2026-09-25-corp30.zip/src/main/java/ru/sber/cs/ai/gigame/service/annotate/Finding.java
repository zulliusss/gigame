package ru.sber.cs.ai.gigame.service.annotate;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Находка заключения, которую нужно показать в исходном документе.
 *
 * @param number       номер находки (позиция строки в результате, с 1)
 * @param documentHint имя документа и раздел из строки заключения
 * @param quote        дословная цитата (пусто — находка без цитаты)
 * @param level        уровень риска
 * @param comment      текст комментария к подсветке
 * @param numbers      числа находки (нормализованные: без разрядки, с точкой): у находки с цитатой — из цитаты,
 *                     без цитаты — из поля «числа_из»
 */
public record Finding(int number, String documentHint, String quote, String level, String comment,
                      List<String> numbers) {

    /** Наименьшее число знаков-цифр, чтобы число считалось суммой, а не номером пункта. */
    static final int MIN_NUMBER_DIGITS = 5;
    private static final Pattern NUMBER = Pattern.compile("\\d[\\d\\s\\u00a0]{2,}(?:[.,]\\d{1,2})?");
    private static final Set<String> NO_QUOTE = Set.of("", "—", "-", "без цитаты", "нет");

    /**
     * Строит находку из строки результата узла по настройке разметки.
     *
     * @param number номер находки
     * @param row    строка результата
     * @param cfg    настройка разметки
     * @return находка
     */
    public static Finding of(int number, Map<String, Object> row, AnnotationConfig cfg) {
        String quote = value(row, cfg.quoteField());
        boolean hasQuote = !NO_QUOTE.contains(quote.toLowerCase(Locale.ROOT));
        return new Finding(number, value(row, cfg.documentField()), hasQuote ? quote : "",
                value(row, cfg.levelField()), comment(number, row, cfg),
                numbersOf(hasQuote ? quote : value(row, cfg.numbersField())));
    }

    /**
     * Где находка в тексте (corp25): цитата целиком или частично ({@link TextLocator#find}), а если цитаты нет
     * в тексте — числа находки. У находки с цитатой числа берутся из самой цитаты: кодовая находка «15570200,00 ₽ …
     * 13117560,00 ₽» не совпадает с ячейкой «15 570 200,00» из-за знака рубля, но число в ней то же. Такое
     * совпадение для находки с цитатой — частичное: в отчёте видно, что отмечено только число.
     *
     * @param text текст документа (абзац, страница, ячейка)
     * @return диапазон в тексте либо {@code null}
     */
    public TextLocator.Span locateIn(String text) {
        if (hasQuote()) {
            TextLocator.Span span = TextLocator.find(text, quote);
            if (span != null) {
                return span;
            }
        }
        for (String value : numbers) {
            TextLocator.Span span = TextLocator.find(text, value);
            if (span != null) {
                return hasQuote() ? new TextLocator.Span(span.start(), span.end(), true) : span;
            }
        }
        return null;
    }

    /** Есть ли у находки дословная цитата. */
    public boolean hasQuote() {
        return !quote.isEmpty();
    }

    /** Есть ли что искать: цитата либо числа. */
    public boolean searchable() {
        return hasQuote() || !numbers.isEmpty();
    }

    /**
     * Цвет подсветки по уровню риска: имя из палитры выделения Word.
     *
     * @return red / yellow / green / cyan
     */
    public String color() {
        String upper = level.toUpperCase(Locale.ROOT);
        if (upper.contains("КРИТИЧ") || upper.contains("ВЫСОК")) {
            return "red";
        }
        if (upper.contains("СРЕДН")) {
            return "yellow";
        }
        return upper.contains("НИЗК") ? "green" : "cyan";
    }

    /**
     * Числа текста в нормализованном виде (как их хранит {@link TextLocator#normalize}): не короче
     * {@link #MIN_NUMBER_DIGITS} цифр, без повторов.
     *
     * @param text текст находки
     * @return числа
     */
    static List<String> numbersOf(String text) {
        Set<String> out = new LinkedHashSet<>();
        Matcher m = NUMBER.matcher(text);
        while (m.find()) {
            String normalized = TextLocator.normalize(m.group()).text();
            if (normalized.chars().filter(Character::isDigit).count() >= MIN_NUMBER_DIGITS) {
                out.add(normalized);
            }
        }
        return new ArrayList<>(out);
    }

    private static String comment(int number, Map<String, Object> row, AnnotationConfig cfg) {
        StringBuilder sb = new StringBuilder();
        String level = value(row, cfg.levelField());
        if (!level.isEmpty()) {
            sb.append('[').append(level).append("] ");
        }
        sb.append(value(row, cfg.titleField()));
        for (String field : cfg.detailFields()) {
            String detail = value(row, field);
            if (!detail.isEmpty() && !"—".equals(detail) && !"-".equals(detail)) {
                sb.append('\n').append(cfg.label(field)).append(": ").append(detail);
            }
        }
        sb.append("\nНаходка № ").append(number).append(" — GigaMe");
        return sb.toString();
    }

    private static String value(Map<String, Object> row, String field) {
        Object value = row.get(field);
        return value == null ? "" : String.valueOf(value).strip();
    }
}
