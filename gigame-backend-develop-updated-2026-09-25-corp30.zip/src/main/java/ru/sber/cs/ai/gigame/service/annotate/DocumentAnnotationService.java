package ru.sber.cs.ai.gigame.service.annotate;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * Размеченные исходники по находкам выходного узла: копии DOCX и PDF с подсветкой цитат и комментариями
 * плюс текстовый отчёт о том, что отмечено, а что и почему нет. Результат — ZIP, который выходной узел
 * складывает в {@link RunArtifactStore}, а скачивание файла узла отдаёт вместе с Excel.
 * <p>
 * Документ находки определяется по имени файла в поле «документ» строки (имя из строки должно содержать
 * имя файла документа прогона), а если имя не указано — по тому, в тексте какого документа есть цитата.
 * Строки служебных уровней (паспорт, выводы) пропускаются. Находки без цитаты (кодовые: расхождение
 * сумм) привязываются по числам из текста находки.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DocumentAnnotationService {

    /** Имя отчёта в ZIP. */
    public static final String REPORT_ENTRY = "разметка — отчёт.txt";
    /** Имя Excel в ZIP скачивания. */
    public static final String EXCEL_ENTRY = "result.xlsx";
    private static final String SUFFIX = " — разметка GigaMe";
    private static final Pattern OCR_PAGE = Pattern.compile("--- страница (\\d+)");
    /** Суффикс дубля имени « (2)» перед расширением: «Договор (2).pdf» → «Договор.pdf». */
    private static final Pattern DUPLICATE_SUFFIX = Pattern.compile("^(.*) \\(\\d+\\)(\\.[^./]*)?$");

    private final RawFileStore rawFileStore;

    /**
     * Строит ZIP размеченных документов по строкам результата узла.
     *
     * @param key      ключ кэша документов прогона (склад исходников)
     * @param runId    прогон (снимок оригиналов на момент запуска; {@code null} — только склад ключа)
     * @param cfg      настройка разметки
     * @param rows     строки результата узла
     * @param docTexts тексты документов прогона по имени (одноимённые — с суффиксом {@link #uniqueName})
     * @return содержимое ZIP
     */
    public byte[] annotate(UUID key, UUID runId, AnnotationConfig cfg, List<Map<String, Object>> rows,
                           Map<String, String> docTexts) {
        List<String> report = new ArrayList<>();
        Map<String, List<Finding>> byDocument = group(rows, cfg, docTexts, report);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            for (Map.Entry<String, List<Finding>> entry : byDocument.entrySet()) {
                Optional<byte[]> marked = annotateDocument(key, runId, entry.getKey(), entry.getValue(), docTexts, report);
                if (marked.isPresent()) {
                    zip.putNextEntry(new ZipEntry(entryName(entry.getKey())));
                    zip.write(marked.get());
                    zip.closeEntry();
                }
            }
            zip.putNextEntry(new ZipEntry(REPORT_ENTRY));
            zip.write(String.join("\n", report).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        } catch (IOException e) {
            throw new IllegalStateException("ZIP размеченных документов не собран: " + e.getMessage(), e);
        }
        return bytes.toByteArray();
    }

    /**
     * ZIP скачивания: Excel узла плюс все записи ZIP разметки.
     *
     * @param annotations ZIP разметки из склада артефактов
     * @param xlsx        Excel узла
     * @return содержимое ZIP
     * @throws IOException ZIP не читается или не собирается
     */
    public static byte[] withExcel(byte[] annotations, byte[] xlsx) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream out = new ZipOutputStream(bytes);
             ZipInputStream in = new ZipInputStream(new ByteArrayInputStream(annotations))) {
            out.putNextEntry(new ZipEntry(EXCEL_ENTRY));
            out.write(xlsx);
            out.closeEntry();
            for (ZipEntry entry = in.getNextEntry(); entry != null; entry = in.getNextEntry()) {
                out.putNextEntry(new ZipEntry(entry.getName()));
                in.transferTo(out);
                out.closeEntry();
            }
        }
        return bytes.toByteArray();
    }

    /** Находки по документам (строки служебных уровней и без документа — в отчёт). */
    private Map<String, List<Finding>> group(List<Map<String, Object>> rows, AnnotationConfig cfg,
                                             Map<String, String> docTexts, List<String> report) {
        Map<String, List<Finding>> byDocument = new LinkedHashMap<>();
        int number = 0;
        for (Map<String, Object> row : rows) {
            Object level = row.get(cfg.levelField());
            if (level != null && cfg.skipLevels().contains(String.valueOf(level).strip())) {
                continue;
            }
            number++;
            Finding finding = Finding.of(number, row, cfg);
            if (!finding.searchable()) {
                report.add("находка № " + number + ": ни цитаты, ни сумм — в документе не отмечена");
                continue;
            }
            String document = resolveDocument(finding, docTexts);
            if (document == null) {
                report.add("находка № " + number + ": документ не определён — в «" + finding.documentHint()
                        + "» нет имени загруженного файла, а цитата не найдена ни в одном документе — не отмечена");
                continue;
            }
            byDocument.computeIfAbsent(document, k -> new ArrayList<>()).add(finding);
        }
        return byDocument;
    }

    /**
     * ZIP только с отчётом — когда разметка не выполнена: скачивание файла узла отдаёт Excel и причину,
     * а не молча Excel без разметки.
     *
     * @param note причина
     * @return содержимое ZIP
     */
    public static byte[] reportOnly(String note) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            zip.putNextEntry(new ZipEntry(REPORT_ENTRY));
            zip.write(note.getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        } catch (IOException e) {
            throw new IllegalStateException("ZIP отчёта разметки не собран: " + e.getMessage(), e);
        }
        return bytes.toByteArray();
    }

    /**
     * Имя, не занятое среди документов: при коллизии перед расширением добавляется « (2)», « (3)», … —
     * одноимённые документы с разным содержимым (второй лот с тем же «Договор.pdf») не схлопываются.
     *
     * @param taken занятые имена
     * @param name  желаемое имя
     * @return свободное имя
     */
    public static String uniqueName(Map<String, ?> taken, String name) {
        if (!taken.containsKey(name)) {
            return name;
        }
        int dot = name.lastIndexOf('.');
        boolean hasExtension = dot > name.lastIndexOf('/');
        String stem = hasExtension ? name.substring(0, dot) : name;
        String extension = hasExtension ? name.substring(dot) : "";
        for (int i = 2; ; i++) {
            String candidate = stem + " (" + i + ")" + extension;
            if (!taken.containsKey(candidate)) {
                return candidate;
            }
        }
    }

    /**
     * Имя без суффикса дубля « (n)» перед расширением.
     *
     * @param name имя (возможно, с суффиксом)
     * @return имя без суффикса (без суффикса — как есть)
     */
    static String plainName(String name) {
        Matcher m = DUPLICATE_SUFFIX.matcher(name);
        return m.matches() ? m.group(1) + (m.group(2) == null ? "" : m.group(2)) : name;
    }

    /**
     * Документ находки: по имени файла в поле «документ», иначе — по тексту, где есть цитата. Среди одноимённых
     * документов (суффикс дубля) предпочитается тот, в тексте которого есть цитата.
     */
    static String resolveDocument(Finding finding, Map<String, String> docTexts) {
        String hint = finding.documentHint().toLowerCase(Locale.ROOT);
        String best = null;
        int bestLength = 0;
        for (String name : docTexts.keySet()) {
            String base = baseName(name).toLowerCase(Locale.ROOT);
            String plain = plainName(base);
            if (base.isEmpty() || !(hint.contains(base) || hint.contains(plain))) {
                continue;
            }
            boolean longer = plain.length() > bestLength;
            boolean sameNameWithQuote = plain.length() == bestLength && best != null
                    && finding.locateIn(docTexts.get(best)) == null && finding.locateIn(docTexts.get(name)) != null;
            if (longer || sameNameWithQuote) {
                best = name;
                bestLength = plain.length();
            }
        }
        if (best != null) {
            return best;
        }
        for (Map.Entry<String, String> entry : docTexts.entrySet()) {
            if (finding.locateIn(entry.getValue()) != null) {
                return entry.getKey();
            }
        }
        return null;
    }

    /**
     * Книга Excel по расширению имени: размечается заливкой ячеек и примечаниями ({@link XlsAnnotator}).
     *
     * @param lower имя файла строчными буквами
     * @return {@code true}, если это книга Excel
     */
    private static boolean isBook(String lower) {
        return lower.endsWith(".xlsx") || lower.endsWith(".xlsm") || lower.endsWith(".xls");
    }

    private Optional<byte[]> annotateDocument(UUID key, UUID runId, String name, List<Finding> findings,
                                              Map<String, String> docTexts, List<String> report) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (!lower.endsWith(".docx") && !lower.endsWith(".pdf") && !isBook(lower)) {
            report.add(name + ": формат не размечается (только DOCX, PDF и книги Excel); находок: " + findings.size());
            return Optional.empty();
        }
        Optional<byte[]> original = loadOriginal(key, runId, name, docTexts.get(name));
        if (original.isEmpty()) {
            report.add(name + ": исходный файл недоступен (загрузите документы заново и повторите прогон) — не размечен");
            return Optional.empty();
        }
        try {
            if (lower.endsWith(".docx")) {
                DocxAnnotator.Result result = DocxAnnotator.annotate(original.get(), findings);
                return reported(name, result.annotated(), findings.size(), result.notes(), result.content(), report);
            }
            if (isBook(lower)) {
                XlsAnnotator.Result result = XlsAnnotator.annotate(original.get(), findings);
                return reported(name, result.annotated(), findings.size(), result.notes(), result.content(), report);
            }
            if (lower.endsWith(".pdf")) {
                PdfAnnotator.Result result = PdfAnnotator.annotate(original.get(), targets(findings, docTexts.get(name)));
                return reported(name, result.annotated(), findings.size(), result.notes(), result.content(), report);
            }
        } catch (Exception e) {
            log.warn("Разметка документа «{}» не удалась: {}", name, e.getMessage());
            report.add(name + ": документ не размечен (" + e.getMessage() + ")");
        }
        return Optional.empty();
    }

    /** Оригинал по имени и тексту; имя с суффиксом дубля пробуется как есть и без суффикса. */
    private Optional<byte[]> loadOriginal(UUID key, UUID runId, String name, String text) {
        Optional<byte[]> original = rawFileStore.load(key, runId, name, text);
        String plain = plainName(name);
        return original.isPresent() || plain.equals(name) ? original : rawFileStore.load(key, runId, plain, text);
    }

    private static Optional<byte[]> reported(String name, int annotated, int total, List<String> notes,
                                             byte[] content, List<String> report) {
        report.add(name + ": отмечено находок " + annotated + " из " + total);
        for (String note : notes) {
            report.add("  " + note);
        }
        return annotated > 0 ? Optional.of(content) : Optional.empty();
    }

    /** Находки PDF с подсказкой страницы по тексту OCR (маркеры «--- страница N ---»). */
    private static List<PdfAnnotator.Target> targets(List<Finding> findings, String text) {
        List<PdfAnnotator.Target> targets = new ArrayList<>();
        for (Finding finding : findings) {
            targets.add(new PdfAnnotator.Target(finding, ocrPage(text, finding)));
        }
        return targets;
    }

    static Integer ocrPage(String text, Finding finding) {
        TextLocator.Span span = text == null ? null : finding.locateIn(text);
        if (span == null) {
            return null;
        }
        Integer page = null;
        Matcher m = OCR_PAGE.matcher(text);
        while (m.find() && m.start() < span.start()) {
            page = Integer.parseInt(m.group(1));
        }
        return page;
    }

    /** Имя записи ZIP: путь внутри архива без имени самого архива, суффикс разметки перед расширением. */
    static String entryName(String name) {
        String path = name;
        int archive = path.toLowerCase(Locale.ROOT).indexOf(".zip/");
        if (archive < 0) {
            archive = path.toLowerCase(Locale.ROOT).indexOf(".7z/");
        }
        if (archive >= 0) {
            path = path.substring(path.indexOf('/', archive) + 1);
        }
        int dot = path.lastIndexOf('.');
        return dot > path.lastIndexOf('/') ? path.substring(0, dot) + SUFFIX + path.substring(dot) : path + SUFFIX;
    }

    private static String baseName(String name) {
        return name.substring(name.lastIndexOf('/') + 1);
    }
}
