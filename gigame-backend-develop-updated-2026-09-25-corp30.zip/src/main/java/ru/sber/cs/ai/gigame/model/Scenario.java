package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.type.SqlTypes;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Сущность сценария (workflow) для выполнения AI-операций.
 * <p>
 * Сценарии представляют собой графы узлов (input, output, loop, switch, if_node),
 * которые выполняются для автоматизации сложных задач с использованием AI.
 *
 * @see ScenarioRun
 */
@Entity
@Table(name = "scenarios")

@Getter
@Setter
@NoArgsConstructor
public class Scenario {

    /**
     * Уникальный идентификатор сценария (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Название сценария.
     */
    @Column(nullable = false)
    private String name;

    /**
     * Описание сценария и его назначения.
     */
    @Column(columnDefinition = "TEXT")
    private String description;

    /**
     * JSON-данные графа сценария, содержащие узлы и рёбра.
     * Формат: {"nodes": [...], "edges": [...]}
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "graph_data", columnDefinition = "jsonb")
    private Map<String, Object> graphData;

    /**
     * Идентификатор пользователя, создавшего сценарий.
     * Используется для изоляции данных между пользователями.
     */
    @Column(name = "user_id")
    private String userId;

    /**
     * Признак общего сценария: общий сценарий виден всем пользователям на
     * странице сценариев, его можно запускать, клонировать и оценивать.
     * Изменять и удалять сценарий по-прежнему может только владелец.
     */
    @Column(name = "shared", nullable = false)
    private Boolean shared = false;

    /**
     * Дата и время создания сценария (автоматически устанавливается).
     */
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    /**
     * Дата и время последнего обновления (автоматически обновляется).
     */
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;
}
