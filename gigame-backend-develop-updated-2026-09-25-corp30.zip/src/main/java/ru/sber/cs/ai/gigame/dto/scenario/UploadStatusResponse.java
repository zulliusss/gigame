package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;

import java.util.List;

/**
 * DTO статуса фоновой обработки загруженных файлов сценария
 * ({@code GET /api/scenarios/{id}/upload-status}).
 * <p>
 * Поля и лимиты — строго по схеме {@code UploadStatusResponse} статической
 * спецификации: корп. шлюз SOWA отклоняет ответ с лишними ключами
 * (additionalProperties: false) или со значениями вне лимитов.
 *
 * @param status    статус задачи: processing, done, failed, none
 * @param files     общее количество файлов (0..100)
 * @param documents количество распознанных документов (0..1000): во время processing —
 *                  разобрано документов текущей партии, после завершения — документов в кэше сценария
 * @param warnings  предупреждения разбора (не больше 1000, каждое до 1024 символов)
 * @param error     сообщение об ошибке при status=failed (до 1024 символов), иначе пустая строка
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        name = "UploadStatusResponse",
        description = "Статус фоновой обработки загруженных файлов",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record UploadStatusResponse(
        @Schema(
                description = "Статус задачи",
                allowableValues = {"processing", "done", "failed", "none"}
        )
        String status,

        @Schema(
                description = "Общее количество файлов",
                minimum = "0",
                maximum = "100"
        )
        int files,

        @Schema(
                description = "Количество распознанных документов",
                minimum = "0",
                maximum = "1000"
        )
        int documents,

        @ArraySchema(
                schema = @Schema(description = "Предупреждение при разборе",
                        maxLength = 1024,
                        pattern = "^[\\w\\W]{0,1024}$"),
                maxItems = 1000
        )
        List<String> warnings,

        @Schema(
                description = "Сообщение об ошибке (при status=failed)",
                nullable = true,
                maxLength = 1024,
                pattern = "^[\\w\\W]{0,1024}$"
        )
        String error
) {

    /**
     * maximum поля files.
     */
    public static final int MAX_FILES = 100;

    /**
     * maximum поля documents.
     */
    public static final int MAX_DOCUMENTS = 1000;

    /**
     * maxItems массива warnings.
     */
    public static final int MAX_WARNINGS = 1000;

    /**
     * maxLength элемента warnings и поля error.
     */
    public static final int MAX_TEXT_LENGTH = 1024;

    /**
     * Создаёт статус, приводя значения к лимитам схемы: числа зажимаются
     * в диапазон, из предупреждений берутся первые 1000 (клиент дочитывает их
     * по возрастающему индексу), длинные тексты усекаются с многоточием.
     *
     * @param status    статус задачи
     * @param files     общее количество файлов
     * @param documents во время processing — разобрано документов текущей партии,
     *                  после завершения — документов в кэше сценария
     * @param warnings  предупреждения разбора (может быть {@code null})
     * @param error     текст ошибки (может быть {@code null} — отдаётся пустая строка)
     * @return статус в пределах схемы
     */
    public static UploadStatusResponse of(String status, int files, int documents,
                                          List<String> warnings, String error) {
        List<String> limitedWarnings = warnings == null
                ? List.of()
                : SchemaLimitUtils.firstItems(warnings, MAX_WARNINGS).stream()
                        .map(w -> SchemaLimitUtils.clip(w, MAX_TEXT_LENGTH))
                        .toList();
        return new UploadStatusResponse(
                status,
                SchemaLimitUtils.clamp(files, 0, MAX_FILES),
                SchemaLimitUtils.clamp(documents, 0, MAX_DOCUMENTS),
                limitedWarnings,
                error == null ? "" : SchemaLimitUtils.clip(error, MAX_TEXT_LENGTH));
    }
}
