package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorTransformNode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;

/**
 * Проверка графа до создания прогона: операции узлов «Трансформация», которых нет в этой версии бэкенда.
 * <p>
 * Сценарий, собранный под более новый дистрибутив, иначе запускался и падал на узле «Трансформация»
 * с «неизвестной операцией» — уже после дорогих LLM-узлов. Список поддерживаемых операций —
 * {@link ScenarioExecutorTransformNode#SUPPORTED_OPERATIONS}.
 * <p>
 * Объект операции без ключа «оп» (например, «имя» вместо «оп») — ошибка правил, а не версии бэкенда: о нём
 * отдельный текст с найденными ключами и советом исправить правила узла.
 */
public final class ScenarioOperationsValidator {

    /** Начало текста ошибки; дальше — найденные операции с метками узлов через «; ». */
    static final String PREFIX = "Сценарий использует операции, которых нет в этой версии бэкенда: ";
    /** Окончание текста ошибки. */
    static final String SUFFIX = " — обновите дистрибутив бэкенда";
    /** Начало текста ошибки об операциях без «оп»; дальше — описания с метками узлов через «; ». */
    static final String NO_OPERATION_PREFIX = "Ошибка в правилах узлов «Трансформация»: ";
    /** Начало описания объекта операции без имени: нет ключа «оп» либо «оп»: null, объект или массив. */
    static final String NO_OPERATION = "операция без ключа «оп»";
    /** Окончание текста ошибки об операциях без «оп»: обновление бэкенда тут не поможет. */
    static final String NO_OPERATION_SUFFIX = " — исправьте правила узла";
    /** Сколько символов значения «оп» (null, объект, массив) показывается в тексте ошибки. */
    private static final int MAX_VALUE_CHARS = 40;

    private ScenarioOperationsValidator() {
    }

    /**
     * Проверяет операции всех узлов «Трансформация» графа (без под-сценариев).
     *
     * @param graphData граф сценария (null и узлы без данных пропускаются)
     * @throws ScenarioException если есть операции, которых нет в этой версии бэкенда, или операции без «оп»
     */
    public static void validate(GraphDataDto graphData) {
        throwIfAny(problemsOf(graphData, ""));
        ScenarioRegexValidator.throwIfAny(ScenarioRegexValidator.problemsOf(graphData, ""));
    }

    /**
     * Проверяет операции узлов «Трансформация» графа и графов его под-сценариев.
     * <p>
     * Под-сценарий — узел «Под-сценарий» с id сценария в {@code data.value}. Графы обходятся по уровням
     * на ту же глубину, которую выполняет движок ({@link ScenarioEngine#MAX_SUB_DEPTH}); каждый сценарий
     * проверяется один раз, поэтому циклы и повторные ссылки не обходятся заново. Некорректный id
     * и ненайденный под-сценарий ошибкой проверки не считаются — о них, как и прежде, сообщит движок.
     *
     * @param graphData  граф запускаемого сценария
     * @param scenarioId id запускаемого сценария (null — неизвестен)
     * @param scenarios  поиск сценария по id
     * @throws ScenarioException если есть операции, которых нет в этой версии бэкенда
     */
    public static void validate(GraphDataDto graphData, UUID scenarioId, Function<UUID, Optional<Scenario>> scenarios) {
        List<String> problems = problemsOf(graphData, "");
        // regex-параметры операций тоже проверяются до создания прогона (см. ScenarioRegexValidator)
        List<String> regexProblems = ScenarioRegexValidator.problemsOf(graphData, "");
        Set<UUID> visited = new HashSet<>();
        visited.add(scenarioId);
        List<GraphDataDto> level = graphData == null ? List.of() : List.of(graphData);
        for (int depth = 0; depth < ScenarioEngine.MAX_SUB_DEPTH && !level.isEmpty(); depth++) {
            level = subScenarioGraphs(level, visited, scenarios, problems, regexProblems);
        }
        throwIfAny(problems);
        ScenarioRegexValidator.throwIfAny(regexProblems);
    }

    /**
     * Графы ещё не проверенных под-сценариев уровня; их проблемы дописываются в {@code problems}
     * (операции) и {@code regexProblems} (regex-параметры).
     */
    private static List<GraphDataDto> subScenarioGraphs(List<GraphDataDto> level, Set<UUID> visited,
                                                        Function<UUID, Optional<Scenario>> scenarios,
                                                        List<String> problems, List<String> regexProblems) {
        List<GraphDataDto> next = new ArrayList<>();
        for (GraphDataDto graph : level) {
            for (UUID subId : subScenarioIds(graph)) {
                Optional<Scenario> sub = visited.add(subId) ? scenarios.apply(subId) : Optional.empty();
                sub.ifPresent(scenario -> {
                    GraphDataDto subGraph = GraphDataMapper.toDto(scenario.getGraphData());
                    String where = " под-сценария «" + name(scenario, subId) + "»";
                    problems.addAll(problemsOf(subGraph, where));
                    regexProblems.addAll(ScenarioRegexValidator.problemsOf(subGraph, where));
                    next.add(subGraph);
                });
            }
        }
        return next;
    }

    private static List<String> problemsOf(GraphDataDto graphData, String where) {
        List<String> problems = new ArrayList<>();
        if (graphData == null || graphData.nodes() == null) {
            return problems;
        }
        for (NodeDto node : graphData.nodes()) {
            if (isType(node, ScenarioNodeType.TRANSFORM_NODE)) {
                problems.addAll(nodeProblems(node.data().rules(), " в узле «" + label(node) + "»" + where));
            }
        }
        return problems;
    }

    /**
     * Проблемы правил одного узла: неизвестные операции (««новая» в узле …», без повторов) и объекты операций без
     * имени («операция без ключа «оп» (найдены ключи: имя, шаблон) в узле …» — в правилах, собранных внешней моделью,
     * вместо «оп» бывает «имя»).
     *
     * @param rules правила узла «Трансформация» (строка JSON)
     * @param in    «в узле «метка»» с под-сценарием
     * @return описания проблем без повторов: сначала неизвестные операции, затем операции без «оп»
     */
    private static List<String> nodeProblems(String rules, String in) {
        Set<String> problems = new LinkedHashSet<>();
        for (String operation : ScenarioExecutorTransformNode.unsupportedOperations(rules)) {
            if (!ScenarioExecutorTransformNode.OPERATION_NOT_SET.equals(operation)) {
                problems.add("«" + operation + "»" + in);
            }
        }
        for (JsonNode op : ScenarioExecutorTransformNode.operationsOf(rules)) {
            JsonNode name = op.get("оп");
            if (name == null || name.isNull() || name.isContainerNode()) {
                problems.add(NO_OPERATION + " (найдены ключи: " + keys(op) + ")" + in);
            }
        }
        return List.copyOf(problems);
    }

    /** Ключи объекта операции через запятую; у «оп» — и значение («оп: null»), чтобы было видно, почему имени нет. */
    private static String keys(JsonNode op) {
        List<String> keys = new ArrayList<>();
        op.fieldNames().forEachRemaining(key -> keys.add("оп".equals(key) ? key + ": " + abbreviate(op.get(key).toString()) : key));
        return keys.isEmpty() ? "нет" : String.join(", ", keys);
    }

    private static String abbreviate(String value) {
        return value.length() > MAX_VALUE_CHARS ? value.substring(0, MAX_VALUE_CHARS) + "…" : value;
    }

    /** Корректные id под-сценариев узлов «Под-сценарий» графа в порядке узлов. */
    private static List<UUID> subScenarioIds(GraphDataDto graphData) {
        List<UUID> ids = new ArrayList<>();
        if (graphData.nodes() == null) {
            return ids;
        }
        for (NodeDto node : graphData.nodes()) {
            UUID id = isType(node, ScenarioNodeType.SUBSCENARIO_NODE) ? parseId(node.data().value()) : null;
            if (id != null) {
                ids.add(id);
            }
        }
        return ids;
    }

    private static UUID parseId(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(value.trim());
        } catch (IllegalArgumentException e) {
            // некорректный id — не ошибка проверки операций: движок сообщит о нём, как и прежде
            return null;
        }
    }

    /**
     * Ошибка запуска: неизвестные операции — «обновите дистрибутив бэкенда», операции без «оп» — «исправьте правила узла»
     * (прежде они попадали в неизвестные как «(не задана)» с советом обновить бэкенд).
     */
    private static void throwIfAny(List<String> problems) {
        List<String> unknown = problems.stream().filter(p -> !p.startsWith(NO_OPERATION)).toList();
        List<String> unnamed = problems.stream().filter(p -> p.startsWith(NO_OPERATION)).toList();
        List<String> messages = new ArrayList<>();
        if (!unknown.isEmpty()) {
            messages.add(PREFIX + String.join("; ", unknown) + SUFFIX);
        }
        if (!unnamed.isEmpty()) {
            messages.add(NO_OPERATION_PREFIX + String.join("; ", unnamed) + NO_OPERATION_SUFFIX);
        }
        if (!messages.isEmpty()) {
            throw new ScenarioException(String.join(". ", messages));
        }
    }

    private static boolean isType(NodeDto node, ScenarioNodeType type) {
        return node != null && node.data() != null && type.toString().equals(node.type());
    }

    private static String label(NodeDto node) {
        String label = node.data().label();
        return label == null || label.isBlank() ? node.id() : label;
    }

    private static String name(Scenario scenario, UUID id) {
        String name = scenario.getName();
        return name == null || name.isBlank() ? id.toString() : name;
    }
}
