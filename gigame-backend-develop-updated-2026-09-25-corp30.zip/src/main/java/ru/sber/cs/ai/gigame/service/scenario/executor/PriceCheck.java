package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Сверка цены договора с ценой победителя по протоколу с учётом валюты и условия «не более».
 * <p>
 * Протокол часто пишет «цена договора не более 100 000,00 руб.», а договор — конкретные 99 500,00 руб.:
 * это не расхождение. Цены в разных валютах числами не сравниваются — если в протоколе есть цена в валюте
 * договора (поле «цены_все»), берётся она, иначе итог «ТРЕБУЕТ УТОЧНЕНИЯ».
 */
// S5852: шаблоны сумм применяются к коротким числовым блокам протокола/договора, длина лимитирована — риск ReDoS
// сведён к минимуму, правки нецелесообразны (бизнес-шаблоны, см. Rules.md).
@SuppressWarnings("java:S5852")
final class PriceCheck {

    /** Допуск сравнения денежных сумм. */
    static final double EPSILON = 0.005;
    private static final Pattern AMOUNT = Pattern.compile("-?\\d[\\d \\u00A0]*(?:[.,]\\d{1,2})?");
    private static final Pattern PRICE_WITH_CURRENCY = Pattern.compile(
            "(\\d[\\d \\u00A0]*(?:[.,]\\d{1,2})?)\\s*(RUB|USD|EUR|CNY|руб|долл|евро|юан|\\$|€|₽)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Признак валюты в записи → код. */
    private static final String[][] CURRENCY_KEYS = {
        {"руб", "RUB"}, {"rub", "RUB"}, {"₽", "RUB"}, {"usd", "USD"}, {"долл", "USD"}, {"$", "USD"},
        {"eur", "EUR"}, {"евро", "EUR"}, {"€", "EUR"}, {"cny", "CNY"}, {"юан", "CNY"},
    };
    private static final Pattern CAP = Pattern.compile("не\\s+(?:более|выше|превыша)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private PriceCheck() {
    }

    /** Итог сверки: статус и пояснение. */
    record Verdict(String status, String text) {
    }

    /**
     * Сверка цены.
     *
     * @param contract JSON условий договора
     * @param lot      JSON лота протокола (выбранного по ИНН, номеру или цене)
     * @return итог
     */
    static Verdict check(JsonNode contract, JsonNode lot) {
        Double sum = amount(contract.path("сумма").isMissingNode() ? contract.path("сумма_руб") : contract.path("сумма"));
        Double price = lot == null ? null : amount(lot.path("цена_победителя"));
        if (sum == null || price == null) {
            return new Verdict("НЕТ ДАННЫХ", "цена не указана числом в договоре или протоколе");
        }
        String contractCurrency = currency(contract.path("валюта").asText(""));
        String lotCurrency = currency(lot.path("валюта").asText(""));
        if (!contractCurrency.equals(lotCurrency)) {
            Double same = priceInCurrency(lot.path("цены_все").asText(""), contractCurrency);
            if (same == null) {
                return new Verdict("ТРЕБУЕТ УТОЧНЕНИЯ", "валюты различаются: протокол " + money(price) + " " + lotCurrency
                        + ", договор " + money(sum) + " " + contractCurrency + " — суммы в разных валютах не сравниваются");
            }
            price = same;
        }
        String described = "протокол " + money(price) + " " + contractCurrency + ", договор " + money(sum) + " " + contractCurrency;
        if (CAP.matcher(lot.path("условие_цены").asText("")).find()) {
            return sum <= price + EPSILON
                    ? new Verdict("СООТВЕТСТВУЕТ", described + " — цена договора не превышает предельную цену «не более» по протоколу")
                    : new Verdict("РАСХОЖДЕНИЕ", described + " — цена договора выше предельной на " + money(sum - price));
        }
        return Math.abs(sum - price) <= EPSILON
                ? new Verdict("СОВПАДАЕТ", described)
                : new Verdict("РАСХОЖДЕНИЕ", described + " — разница " + money(sum - price));
    }

    /**
     * Сумма или число из числа либо строки («1 234 567,89 руб.»; «-1» — признак «не задано», а не 1).
     *
     * @param node значение поля
     * @return сумма либо {@code null}
     */
    static Double amount(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) {
            return null;
        }
        if (node.isNumber()) {
            return node.asDouble();
        }
        Matcher m = AMOUNT.matcher(node.asText(""));
        return m.find() ? Double.parseDouble(m.group().replaceAll("[ \\u00A0]", "").replace(',', '.')) : null;
    }

    /**
     * Код валюты: RUB, USD, EUR, CNY; пустое значение — RUB.
     *
     * @param raw валюта как в ответе модели
     * @return код
     */
    static String currency(String raw) {
        String c = raw.strip().toLowerCase(Locale.ROOT);
        if (c.isEmpty() || c.startsWith("не ")) {
            return "RUB";
        }
        for (String[] pair : CURRENCY_KEYS) {
            if (c.contains(pair[0])) {
                return pair[1];
            }
        }
        return raw.strip().toUpperCase(Locale.ROOT);
    }

    private static Double priceInCurrency(String all, String code) {
        Matcher m = PRICE_WITH_CURRENCY.matcher(all);
        while (m.find()) {
            if (currency(m.group(2)).equals(code)) {
                return Double.parseDouble(m.group(1).replaceAll("[ \\u00A0]", "").replace(',', '.'));
            }
        }
        return null;
    }

    static String money(double value) {
        return String.format(Locale.ROOT, "%.2f", value);
    }
}
