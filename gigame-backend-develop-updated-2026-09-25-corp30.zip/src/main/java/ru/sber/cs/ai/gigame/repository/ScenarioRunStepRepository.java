package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputView;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с шагами выполнения сценариев.
 * <p>
 * Предоставляет методы для получения истории выполнения узлов сценария.
 *
 * @see ScenarioRunStep
 */
@Repository
public interface ScenarioRunStepRepository extends JpaRepository<ScenarioRunStep, UUID> {

    /**
     * Возвращает все шаги указанного запуска, отсортированные по времени начала (хронологический порядок).
     * Вторичный ключ сортировки — идентификатор: шаги с одинаковым started_at (копии шагов при
     * возобновлении, параллельные волны) возвращаются в стабильном порядке, а не в порядке чтения БД.
     *
     * @param runId идентификатор запуска сценария
     * @return список шагов выполнения
     */
    @Query("select s from ScenarioRunStep s where s.runId = :runId order by s.startedAt asc, s.id asc")
    List<ScenarioRunStep> findByRunIdOrderByStartedAtAsc(@Param("runId") UUID runId);

    /**
     * Результаты шагов одного узла запуска без тяжёлых полей (input_data, prompt_used):
     * для внутренних читателей результата узла (файл output-узла, узел-донор,
     * нарастающий итог) — полные шаги здесь не нужны.
     *
     * @param runId  идентификатор запуска
     * @param nodeId идентификатор узла
     * @return проекции шагов узла в хронологическом порядке
     */
    List<StepOutputView> findViewByRunIdAndNodeIdOrderByStartedAtAsc(UUID runId, String nodeId);

    /**
     * Результаты всех шагов запуска без тяжёлых полей (input_data, prompt_used).
     *
     * @param runId идентификатор запуска
     * @return проекции шагов в хронологическом порядке
     */
    List<StepOutputView> findViewByRunIdOrderByStartedAtAsc(UUID runId);

    /**
     * corp23, лёгкая ретенция: у шагов, завершённых (или начатых, если завершения нет) раньше границы,
     * очищаются тяжёлые поля — входные данные (полный текст комплекта у входного узла) и промпт;
     * результат и статусы остаются.
     *
     * @param cutoff граница срока хранения тяжёлых полей
     * @return число очищенных шагов
     */
    @Modifying(clearAutomatically = true)
    @Query("update ScenarioRunStep s set s.inputData = null, s.promptUsed = null "
            + "where coalesce(s.completedAt, s.startedAt) < :cutoff "
            + "and (s.inputData is not null or s.promptUsed is not null)")
    int clearPayloadsBefore(@Param("cutoff") OffsetDateTime cutoff);
}
