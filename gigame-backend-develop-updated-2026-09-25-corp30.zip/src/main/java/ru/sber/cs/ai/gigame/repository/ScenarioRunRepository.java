package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.ScenarioRun;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с запусками сценариев.
 * <p>
 * Предоставляет методы для управления выполнением сценариев.
 *
 * @see ScenarioRun
 */
@Repository
public interface ScenarioRunRepository extends JpaRepository<ScenarioRun, UUID> {

    /**
     * Возвращает все запуски указанного сценария, отсортированные по времени начала (новые первыми).
     *
     * @param scenarioId идентификатор сценария
     * @return список запусков сценария
     */
    List<ScenarioRun> findByScenarioIdOrderByStartedAtDesc(UUID scenarioId);

    /**
     * Запуски сценария, выполненные указанным пользователем (новые первыми).
     *
     * @param scenarioId идентификатор сценария
     * @param userId     автор запусков
     * @return список запусков пользователя
     */
    List<ScenarioRun> findByScenarioIdAndUserIdOrderByStartedAtDesc(UUID scenarioId, String userId);

    /**
     * История запусков для владельца сценария: его собственные запуски и
     * старые запуски без автора (новые первыми).
     *
     * @param scenarioId идентификатор сценария
     * @param userId     владелец сценария
     * @return список запусков владельца и запусков без автора
     */
    @Query("select r from ScenarioRun r where r.scenarioId = :scenarioId "
            + "and (r.userId = :userId or r.userId is null) order by r.startedAt desc")
    List<ScenarioRun> findOwnerRuns(@Param("scenarioId") UUID scenarioId, @Param("userId") String userId);

    /**
     * Успешно завершённые (completed) запуски сценария пользователем, последние по времени
     * завершения первыми. Пересекающиеся прогоны упорядочиваются по окончанию, а не по старту.
     *
     * @param scenarioId идентификатор сценария
     * @param userId     автор запусков
     * @return завершённые запуски пользователя
     */
    @Query("select r from ScenarioRun r where r.scenarioId = :scenarioId and r.userId = :userId "
            + "and r.status = 'completed' order by r.completedAt desc nulls last")
    List<ScenarioRun> findCompletedRunsByUser(@Param("scenarioId") UUID scenarioId, @Param("userId") String userId);

    /**
     * Успешно завершённые (completed) запуски для владельца сценария: его собственные
     * и старые запуски без автора, последние по времени завершения первыми.
     *
     * @param scenarioId идентификатор сценария
     * @param userId     владелец сценария
     * @return завершённые запуски владельца и запуски без автора
     */
    @Query("select r from ScenarioRun r where r.scenarioId = :scenarioId "
            + "and (r.userId = :userId or r.userId is null) "
            + "and r.status = 'completed' order by r.completedAt desc nulls last")
    List<ScenarioRun> findCompletedOwnerRuns(@Param("scenarioId") UUID scenarioId, @Param("userId") String userId);

    /**
     * Все запуски в указанном статусе (для восстановления после рестарта).
     *
     * @param status статус запуска
     * @return список запусков
     */
    List<ScenarioRun> findByStatus(String status);

    /**
     * Количество запусков по каждому из перечисленных сценариев.
     *
     * @param scenarioIds идентификаторы сценариев
     * @return пары [scenarioId, count]
     */
    @Query("select r.scenarioId, count(r) from ScenarioRun r "
            + "where r.scenarioId in :scenarioIds group by r.scenarioId")
    List<Object[]> countByScenarioIds(@Param("scenarioIds") List<UUID> scenarioIds);

    /**
     * Идентификаторы запусков, подлежащих удалению по сроку хранения: начаты раньше
     * {@code cutoff}, не выполняются сейчас, и это не последний успешно завершённый
     * запуск пары «сценарий + пользователь» (на нём держится нарастающий итог
     * «накапливать»; запуски без автора считаются одной парой).
     *
     * @param cutoff граница срока хранения (started_at раньше — кандидат)
     * @return идентификаторы устаревших запусков
     */
    @Query("select r.id from ScenarioRun r where r.startedAt < :cutoff and r.status <> 'running' "
            + "and (r.status <> 'completed' or exists (select n.id from ScenarioRun n "
            + "where n.scenarioId = r.scenarioId and coalesce(n.userId, '') = coalesce(r.userId, '') "
            + "and n.status = 'completed' and n.completedAt > r.completedAt))")
    List<UUID> findExpiredRunIds(@Param("cutoff") OffsetDateTime cutoff);
}
