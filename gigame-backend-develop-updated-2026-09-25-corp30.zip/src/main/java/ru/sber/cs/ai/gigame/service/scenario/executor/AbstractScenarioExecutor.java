package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Getter
public abstract class AbstractScenarioExecutor {
    /**
     * Максимальная длина текста документа для включения полного содержимого в промпт.
     * Документы длиннее этого лимита обрезаются.
     */
    @Setter
    private int docCharLimit;

    /**
     * Документы больше предела делятся на части с повтором инструкции (corp21, {@code app.scenario.document-overflow=split},
     * деление — {@code GigaChatClient.splitBySize}), а не обрезаются; {@code false} — прежняя обрезка до {@code docCharLimit}.
     */
    @Setter
    @Getter
    private boolean overflowSplit = true;

    /**
     * Предел значения выражения {{output:…}}/{{json:…}}, остающегося в инструкции узла (corp23,
     * {@code app.scenario.expression-inline-chars}); длиннее — уходит блоком в делимый контекст.
     */
    @Setter
    private int expressionInlineChars = DEFAULT_EXPRESSION_INLINE_CHARS;

    /** Предел значения выражения в инструкции по умолчанию (как {@code app.scenario.expression-inline-chars}). */
    public static final int DEFAULT_EXPRESSION_INLINE_CHARS = 4000;

    /** Границы обрезки в режиме отката по убыванию приоритета: блок результата узла, абзац, строка. */
    private static final List<String> CUT_BOUNDARIES = List.of("\n\n=== РЕЗУЛЬТАТ ОТ", "\n\n", "\n");

    static final String OPERATOR_CONTAINS = "contains";
    static final String OPERATOR_NOT_CONTAINS = "not_contains";
    static final String OPERATOR_EQUALS = "equals";
    static final String OPERATOR_GREATER_THAN = "greater_than";
    static final String OPERATOR_LESS_THAN = "less_than";
    static final String OPERATOR_STARTSWITH = "startswith";

    protected final ScenarioRunNode node;

    protected String prompt;

    /**
     * Частичное состояние узла на момент сбоя (чекпойнт): агентские узлы
     * кладут сюда собранные наблюдения — движок сохраняет их в шаг, а
     * возобновление отдаёт агенту рабочим файлом, чтобы дорогой цикл
     * не начинался с нуля после обрыва сети.
     */
    protected String checkpoint;

    /** Пометки об обрезках при сборке промпта (документы, результаты шагов) до их вывода в журнал. */
    private final List<String> truncationNotes = new ArrayList<>();

    protected AbstractScenarioExecutor(ScenarioRunNode node) {
        this.node = node;
        prompt = "";
    }

    /**
     * Возвращает текущего пользователя прогона.
     * <p>
     * Исполнители исполняются в пулах потоков (последовательная рекурсия или
     * параллельные волны), где {@link ThreadLocal} хранилище {@link CurrentUserHolder}
     * не всегда достигает потока узла (частая смена потоков между пулами). Поэтому
     * в качестве источника userId используется {@code runnerUserId} из графа
     * (проставляется движком при старте/возобновлении прогона), а ThreadLocal — только
     * как запасной вариант, когда граф ещё не содержит пользователя.
     *
     * @return userId, запустивший прогон (null — аноним/не определён)
     */
    protected String currentUser() {
        String user = CurrentUserHolder.getCurrentUser();
        if (user == null && node.getGraph() != null && node.getGraph().getRunnerUserId() != null) {
            user = node.getGraph().getRunnerUserId();
            CurrentUserHolder.setCurrentUser(user);
        }
        return user;
    }

    @SuppressWarnings("unused")
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        return null;
    }

    /**
     * Вычисляет множество узлов, которые следует пропустить при условном переходе.
     * <p>
     * Используется при выполнении Switch/If узлов для определения, какие узлы
     * недостижимы из-за ветвления.
     *
     * @param unchosenTargets невыбранные цели
     * @param chosenTargets   выбранные цели
     * @param successors      карта successor-узлов
     * @return множество узлов для пропуска
     */
    protected Set<String> getSkipSet(Set<String> unchosenTargets,
                                     Set<String> chosenTargets,
                                     Map<String, List<String>> successors) {
        Set<String> reachableFromChosen = new HashSet<>();
        for (String ct : chosenTargets) {
            reachableFromChosen.addAll(getAllDescendants(ct, successors));
        }

        Set<String> skip = new HashSet<>();
        for (String ut : unchosenTargets) {
            for (String n : getAllDescendants(ut, successors)) {
                if (!reachableFromChosen.contains(n)) {
                    skip.add(n);
                }
            }
        }
        return skip;
    }

    /**
     * Находит всех потомков узла в графе.
     * <p>
     * Использует DFS (глубинный поиск) для обхода графа.
     *
     * @param nodeId идентификатор узла
     * @param graph  граф в виде map(nodeId -> List&lt;successorIds&gt;)
     * @return множество всех потомков
     */
    private Set<String> getAllDescendants(String nodeId, Map<String, List<String>> graph) {
        Set<String> visited = new HashSet<>();
        Deque<String> stack = new ArrayDeque<>();
        stack.push(nodeId);
        while (!stack.isEmpty()) {
            String nid = stack.pop();
            if (visited.contains(nid)) {
                continue;
            }
            visited.add(nid);
            for (String neighbor : graph.getOrDefault(nid, List.of())) {
                stack.push(neighbor);
            }
        }
        return visited;
    }

    /**
     * Строит промпт для узла обработки.
     * <p>
     * Собирает контекст из документов, предыдущего вывода и RAG-фрагментов.
     * Ограничивает размер контекста по MAX_CONTEXT.
     *
     * @param documentsText текст документа
     * @param kbChunks      RAG-фрагменты из базы знаний
     * @param ragConfigured флаг, что RAG настроен
     * @return сформированный промпт
     */
    protected String buildPrompt(String input,
                                 String documentsText,
                                 List<String> kbChunks,
                                 boolean ragConfigured) {

        String promptTemplate = node.getPrompt();
        // Выражения {{output:Метка}} / {{json:Метка:путь}} дают адресный доступ к выходам
        // конкретных узлов. Если они используются, автоматический блок «Результаты
        // предыдущих шагов» не добавляется — контекстом управляет автор сценария.
        boolean hasExpressions = ExpressionResolver.hasExpressions(promptTemplate);
        List<String> contextParts = new ArrayList<>();
        if (hasExpressions) {
            promptTemplate = resolveExpressions(promptTemplate, contextParts);
        }

        if (!documentsText.isEmpty()) {
            contextParts.add("Документы:\n" + cutIfTruncating(documentsText, "документ", "[... документы обрезаны ...]"));
        }

        if (!input.isEmpty() && !hasExpressions) {
            contextParts.add("Результаты предыдущих шагов:\n"
                    + cutIfTruncating(input, "результат предыдущих шагов", "[... обрезано ...]"));
        }

        if (kbChunks != null && !kbChunks.isEmpty()) {
            String joined = String.join("\n\n---\n\n", kbChunks);
            contextParts.add(
                    "Релевантные фрагменты из базы знаний (используй их для ответа):\n" + joined
            );
        } else if (ragConfigured) {
            contextParts.add(
                    "⚠️ БАЗА ЗНАНИЙ ПОДКЛЮЧЕНА, НО РЕЛЕВАНТНЫХ ФРАГМЕНТОВ НЕ НАЙДЕНО.\n" +
                            "В твоём ответе явно укажи: «В базе знаний не найдено релевантных " +
                            "данных для этого запроса». НЕ ВЫДУМЫВАЙ никакие исторические аналоги, " +
                            "средние значения, справочные данные или примеры — если их нет во " +
                            "входных данных, их НЕТ."
            );
        }

        String context = String.join("\n\n", contextParts);
        // невидимая граница «инструкция | контекст»: при «context too long» клиент делит только контекст,
        // повторяя инструкцию в каждой части (см. GigaChatClient.chatCompletionSplittable)
        return GigaChatClient.splittableContent(promptTemplate, context, mergeArraysOnSplit());
    }

    /**
     * Подстановка выражений в инструкцию узла (corp23): значение не длиннее {@code expressionInlineChars} остаётся
     * в инструкции, длинное (выход узла) уходит блоком в делимый контекст за границей «инструкция | контекст» —
     * инструкция остаётся короткой и повторяется в каждой части, а значение делится вместе с документами. Раньше
     * значения до {@code docCharLimit} каждое подставлялись в инструкцию, она становилась неделимой, и 422 не
     * лечился делением. В режиме обрезки значение усекается до {@code docCharLimit} с пометкой в журнал прогона
     * (раньше усечение было видно только по маркеру в промпте).
     *
     * @param template     промпт узла с выражениями
     * @param contextParts блоки контекста (сюда добавляются вынесенные значения)
     * @return инструкция с подставленными короткими значениями и ссылками на вынесенные
     */
    private String resolveExpressions(String template, List<String> contextParts) {
        int cap = overflowSplit ? Integer.MAX_VALUE : docCharLimit;
        var resolved = ExpressionResolver.resolveDetaching(template, node.getGraph().getNodeMap(),
                expressionInlineChars, cap);
        if (resolved.kept() < resolved.total()) {
            noteTruncation("текст подстановок выражений в промпте", resolved.kept(), resolved.total());
        }
        contextParts.addAll(resolved.blocks());
        return resolved.text();
    }

    /**
     * Режим обрезки (откат {@code DOCUMENT_OVERFLOW=truncate}): текст длиннее {@code docCharLimit} обрезается по
     * границе блока результата узла, абзаца или строки перед пределом ({@link #boundaryCut}) — не посреди JSON или
     * строки, — с маркером в промпте и пометкой в журнал прогона. В режиме деления текст возвращается целиком:
     * его делит клиент по границам документов и абзацев ({@code GigaChatClient.splitBySize}).
     *
     * @param text   документы либо результаты предыдущих шагов
     * @param what   что обрезано (для пометки)
     * @param marker маркер обрезки в промпте
     * @return текст целиком либо обрезанный с маркером
     */
    private String cutIfTruncating(String text, String what, String marker) {
        if (overflowSplit || text.length() <= docCharLimit) {
            return text;
        }
        int cut = boundaryCut(text, docCharLimit);
        noteTruncation(what, cut, text.length());
        return text.substring(0, cut) + "\n\n" + marker;
    }

    /**
     * Позиция обрезки не позже {@code limit}: ближайшая к пределу граница из {@link #CUT_BOUNDARIES} не раньше
     * половины предела, иначе сам предел (текст без переводов строк).
     *
     * @param text  текст
     * @param limit предел длины
     * @return индекс конца оставляемой части
     */
    static int boundaryCut(String text, int limit) {
        for (String boundary : CUT_BOUNDARIES) {
            int at = text.lastIndexOf(boundary, limit);
            if (at >= limit / 2) {
                return at;
            }
        }
        return limit;
    }

    /**
     * Объединять ли JSON-массивы ответов частей, если промпт пришлось делить
     * из-за лимита контекста (узлы с контрактом json_массив).
     *
     * @return {@code false} по умолчанию
     */
    protected boolean mergeArraysOnSplit() {
        return false;
    }

    /**
     * Запоминает обрезку фрагмента промпта до {@code docCharLimit}: пометки
     * забирает {@link #drainTruncationNotes()} и выводит в журнал прогона —
     * раньше обрезка была видна только в тексте использованного промпта.
     *
     * @param what  что обрезано («документ», «результаты предыдущих шагов»)
     * @param kept  сколько символов осталось
     * @param total сколько было
     */
    protected void noteTruncation(String what, int kept, int total) {
        truncationNotes.add("⚠ " + what + " обрезан: " + kept + " из " + total + " символов");
    }

    /**
     * Пометки об обрезках, накопленные с прошлого вызова; список очищается.
     *
     * @return пометки (пусто, если обрезок не было)
     */
    protected List<String> drainTruncationNotes() {
        List<String> notes = new ArrayList<>(truncationNotes);
        truncationNotes.clear();
        return notes;
    }

    protected List<String> prepareNextInput() {
        List<String> result = new ArrayList<>();
        var output = node.getOutput();
        var label = node.getLabel();
        if (output != null && !output.isEmpty()) {
            result.add("=== РЕЗУЛЬТАТ ОТ \"" + label + "\" ===\n" + String.join("\n\n", output));
        }
        return result;
    }
}
