package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.api.chat.GigaChatApi;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;
import org.springframework.web.client.RestClient;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.lang.reflect.Field;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * HTTP-вызов фильтра GigaFilter: {@code POST {spring.ai.gigachat.base-url}{app.gigachat.profanity-check.path}}.
 * <p>
 * В spring-ai-gigachat 1.1.x метода проверки фильтром нет, а {@code GigaChatModel} шлёт только
 * {@code /chat/completions}; поэтому запрос отправляется {@link RestClient} бина {@link GigaChatApi} (поле
 * {@code restClient}): тот же base-url, токен либо mTLS-сертификаты, SSL и обработчик ошибок
 * {@code GigaChatResponseErrorHandler} — секреты не дублируются. Поле не найдено или бина нет — сбой «фильтр
 * недоступен» (запрос к модели уйдёт с включённым цензором). Ожидание ответа ограничено
 * {@code app.gigachat.profanity-check.timeout-millis} (read-timeout клиента рассчитан на генерацию — минуты).
 * Первый ответ фильтра за запуск приложения (успех или ошибка) пишется в лог усечённо — формат ответа на корп-ключе
 * виден без отладки; заголовки (токен) не пишутся. Прерывание ожидающего потока (остановка прогона, остановка пула
 * параллельных групп) — не сбой фильтра: бросается {@link GigaChatException} {@link #INTERRUPTED}, автомат доступности
 * не затрагивается.
 */
@Component
@Slf4j
public class GigaFilterTransport {

    /** Предел тела ответа фильтра в логе, знаков. */
    static final int RAW_LOG_LIMIT = 500;
    /** Ошибка прерванного ожидания ответа фильтра (поток узла остановлен): не сбой фильтра. */
    static final String INTERRUPTED = "Ожидание ответа фильтра GigaFilter прервано";
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final Field API_REST_CLIENT = ReflectionUtils.findField(GigaChatApi.class, "restClient", RestClient.class);
    private static final Pattern SPACES = Pattern.compile("\\s+");

    private final Supplier<RestClient> restClientSource;
    private final AtomicBoolean rawLogged = new AtomicBoolean();
    // NOSONAR java:S1075 — путь фильтра — значение из @Value с дефолтом (настраиваемый параметр приложения)
    @Value("${app.gigachat.profanity-check.path:/filter/check}")
    private String path = "/filter/check";
    @Value("${app.gigachat.profanity-check.timeout-millis:30000}")
    private long timeoutMillis = 30_000L;
    @Value("${app.gigachat.max-concurrent:5}")
    private int maxConcurrent = 5;
    /** Потоки вызовов фильтра (daemon); создаётся при первом вызове. */
    @SuppressWarnings("java:S3077") // volatile — безопасная публикация лениво создаваемого пула (pool())
    private volatile ExecutorService pool;

    /**
     * Транспорт через клиент бина {@link GigaChatApi}.
     *
     * @param apiProvider провайдер API GigaChat (бина может не быть — фильтр недоступен)
     */
    @Autowired
    public GigaFilterTransport(ObjectProvider<GigaChatApi> apiProvider) {
        this(() -> restClientOf(apiProvider.getIfAvailable()));
    }

    /**
     * Транспорт с заданным источником клиента (тесты, раннеры).
     *
     * @param restClientSource источник {@link RestClient} с base-url и авторизацией ({@code null} — фильтр недоступен)
     */
    GigaFilterTransport(Supplier<RestClient> restClientSource) {
        this.restClientSource = restClientSource;
    }

    /**
     * {@link RestClient} бина GigaChatApi (приватное поле библиотеки).
     *
     * @param api API GigaChat ({@code null} — нет клиента)
     * @return клиент либо {@code null}
     */
    static RestClient restClientOf(GigaChatApi api) {
        if (api == null || API_REST_CLIENT == null) {
            return null;
        }
        ReflectionUtils.makeAccessible(API_REST_CLIENT);
        return (RestClient) ReflectionUtils.getField(API_REST_CLIENT, api);
    }

    /**
     * Проверка сообщений фильтром.
     *
     * @param request тело запроса
     * @return вердикт либо сбой
     * @throws GigaChatException {@link #INTERRUPTED}, если ожидающий поток прерван (сбоем фильтра не считается)
     */
    public GigaFilterCheck.Outcome check(GigaFilterCheck.Request request) {
        RestClient client;
        String json;
        try {
            client = restClientSource.get();
            json = MAPPER.writeValueAsString(request);
        } catch (JsonProcessingException | RuntimeException e) {
            return GigaFilterCheck.Outcome.failed(null, "клиент GigaChat API недоступен: " + shorten(e.getMessage(), 200));
        }
        if (client == null) {
            return GigaFilterCheck.Outcome.failed(null, "клиент GigaChat API недоступен (нет бина GigaChatApi)");
        }
        Future<ResponseEntity<String>> future = pool().submit(() -> client.post().uri(path)
                .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)
                .body(json).retrieve().toEntity(String.class));
        return await(future);
    }

    /** Ожидание ответа с потолком {@code timeoutMillis}; таймаут отменяет обмен. */
    private GigaFilterCheck.Outcome await(Future<ResponseEntity<String>> future) {
        try {
            return parse(future.get(timeoutMillis, TimeUnit.MILLISECONDS));
        } catch (TimeoutException e) {
            future.cancel(true);
            return GigaFilterCheck.Outcome.failed(null, "таймаут ответа фильтра " + timeoutMillis + " мс");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            future.cancel(true);
            throw new GigaChatException(INTERRUPTED, e);
        } catch (ExecutionException e) {
            return failure(e.getCause() == null ? e : e.getCause());
        }
    }

    /** Ответ 200: вердикт is_profane либо «непонятный ответ». */
    private GigaFilterCheck.Outcome parse(ResponseEntity<String> entity) {
        int status = entity.getStatusCode().value();
        String body = entity.getBody() == null ? "" : entity.getBody();
        logRawOnce(status, entity.getHeaders().getFirst("x-request-id"), body);
        GigaFilterCheck.Response response;
        try {
            response = MAPPER.readValue(body, GigaFilterCheck.Response.class);
        } catch (JsonProcessingException e) {
            return GigaFilterCheck.Outcome.failed(status, "непонятный ответ фильтра: " + shorten(body, 200));
        }
        return response == null || response.profane() == null
                ? GigaFilterCheck.Outcome.failed(status, "в ответе фильтра нет is_profane: " + shorten(body, 200))
                : GigaFilterCheck.Outcome.verdict(response.profane());
    }

    /** Ответ с кодом ошибки либо сбой соединения; у 429 — подсказка Retry-After. */
    private GigaFilterCheck.Outcome failure(Throwable error) {
        Integer status = GigaChatFailureReason.httpStatus(error);
        String message = error.getClass().getSimpleName() + ": " + error.getMessage();
        if (status != null) {
            logRawOnce(status, null, String.valueOf(error.getMessage()));
        }
        return GigaFilterCheck.Outcome.failed(status, shorten(message, 300), GigaChatRetryAfter.millis(error));
    }

    /** Первый ответ фильтра за запуск — в лог (усечённо). */
    private void logRawOnce(int status, String requestId, String body) {
        if (!rawLogged.compareAndSet(false, true)) {
            return;
        }
        if (status == 200) {
            log.info("GigaFilter: первый ответ фильтра за запуск — HTTP 200, x-request-id={}: {}", requestId,
                    shorten(body, RAW_LOG_LIMIT));
        } else {
            log.warn("GigaFilter: первый ответ фильтра за запуск — HTTP {}: {}", status, shorten(body, RAW_LOG_LIMIT));
        }
    }

    /** Пул вызовов фильтра: max(2, 2 × max-concurrent) daemon-потоков. */
    private ExecutorService pool() {
        ExecutorService current = pool;
        if (current == null) {
            synchronized (this) {
                if (pool == null) {
                    pool = Executors.newFixedThreadPool(Math.max(2, 2 * maxConcurrent), r -> {
                        Thread t = new Thread(r, "gigafilter-call");
                        t.setDaemon(true);
                        return t;
                    });
                }
                current = pool;
            }
        }
        return current;
    }

    /** Останавливает пул вызовов фильтра при выключении приложения. */
    @PreDestroy
    public void shutdown() {
        ExecutorService current = pool;
        if (current != null) {
            current.shutdownNow();
        }
    }

    /** Одна строка без лишних пробелов, не длиннее limit. */
    static String shorten(String text, int limit) {
        String line = SPACES.matcher(String.valueOf(text)).replaceAll(" ").strip();
        return line.length() <= limit ? line : line.substring(0, limit) + "…";
    }
}
