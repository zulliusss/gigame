package ru.sber.cs.ai.gigame.service.annotate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

/**
 * Склад бинарных артефактов прогона на диске: ZIP размеченных документов выходного узла.
 * <p>
 * Результаты шагов хранятся в БД текстом; ZIP с документами в текст не укладывается и нужен лишь при
 * скачивании файла узла. Артефакт лежит в {@code <корень>/<runId>/<nodeId>.zip}
 * {@code app.annotate.artifact-ttl-hours} часов и вычищается плановой задачей.
 */
@Slf4j
@Service
public class RunArtifactStore {

    private static final String SUFFIX = ".zip";

    @Value("${app.annotate.artifact-dir:${java.io.tmpdir}/gigame-run-files}")
    private String rootDir;

    @Value("${app.annotate.artifact-ttl-hours:168}")
    private int ttlHours;

    /** Конструктор для Spring (настройки внедряются в поля). */
    public RunArtifactStore() {
    }

    /**
     * Склад с заданным каталогом и сроком жизни (тесты).
     *
     * @param rootDir  корневой каталог
     * @param ttlHours срок жизни артефактов, часов
     */
    public RunArtifactStore(String rootDir, int ttlHours) {
        this.rootDir = rootDir;
        this.ttlHours = ttlHours;
    }

    /**
     * Сохраняет артефакт узла прогона.
     *
     * @param runId   идентификатор прогона
     * @param nodeId  идентификатор узла
     * @param content содержимое ZIP
     */
    public void save(UUID runId, String nodeId, byte[] content) {
        try {
            Path file = file(runId, nodeId);
            Files.createDirectories(file.getParent());
            Files.write(file, content);
        } catch (IOException e) {
            log.warn("Артефакты прогона {}: файл узла {} не сохранён ({})", runId, nodeId, e.getMessage());
        }
    }

    /**
     * Артефакт узла прогона.
     *
     * @param runId  идентификатор прогона
     * @param nodeId идентификатор узла
     * @return содержимое либо пусто
     */
    public Optional<byte[]> load(UUID runId, String nodeId) {
        Path file = file(runId, nodeId);
        if (!Files.isRegularFile(file)) {
            return Optional.empty();
        }
        try {
            return Optional.of(Files.readAllBytes(file));
        } catch (IOException e) {
            log.warn("Артефакты прогона {}: файл узла {} не прочитан ({})", runId, nodeId, e.getMessage());
            return Optional.empty();
        }
    }

    /**
     * Плановая чистка артефактов старше срока жизни (пустые каталоги прогонов удаляются).
     */
    @Scheduled(fixedRateString = "${app.annotate.cleanup-rate-ms:3600000}")
    public void evictStale() {
        Path root = Paths.get(rootDir);
        if (!Files.isDirectory(root)) {
            return;
        }
        Instant deadline = Instant.now().minus(Math.max(1, ttlHours), ChronoUnit.HOURS);
        try (Stream<Path> files = Files.walk(root)) {
            files.filter(Files::isRegularFile).filter(file -> modifiedBefore(file, deadline)).forEach(this::delete);
        } catch (IOException e) {
            log.warn("Артефакты прогона: чистка не удалась ({})", e.getMessage());
        }
    }

    private Path file(UUID runId, String nodeId) {
        String safe = nodeId.matches("[A-Za-z0-9_.-]{1,64}") ? nodeId
                : DocumentService.sha256Hex(nodeId.getBytes(StandardCharsets.UTF_8));
        return Paths.get(rootDir).resolve(runId.toString()).resolve(safe + SUFFIX);
    }

    private static boolean modifiedBefore(Path file, Instant deadline) {
        try {
            return Files.getLastModifiedTime(file).toInstant().isBefore(deadline);
        } catch (IOException e) {
            return false;
        }
    }

    private void delete(Path file) {
        try {
            Files.deleteIfExists(file);
            deleteIfEmpty(file.getParent());
        } catch (IOException e) {
            log.warn("Артефакты прогона: {} не удалён ({})", file, e.getMessage());
        }
    }

    private static void deleteIfEmpty(Path dir) throws IOException {
        try (Stream<Path> rest = Files.list(dir)) {
            if (rest.findAny().isPresent()) {
                return;
            }
        }
        Files.deleteIfExists(dir);
    }
}
