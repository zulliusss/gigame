package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ru.sber.cs.ai.gigame.model.Prompt;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий базы промптов.
 */
public interface PromptRepository extends JpaRepository<Prompt, UUID> {

    /**
     * Промпты, видимые пользователю: его собственные и все общие.
     *
     * @param userId идентификатор пользователя
     * @return промпты, новые сверху
     */
    List<Prompt> findByUserIdOrSharedTrueOrderByUpdatedAtDesc(String userId);

    /**
     * Атомарный инкремент счётчика использований (одним UPDATE в БД: параллельные
     * «использовать» не теряют инкременты, как при чтении-изменении-записи сущности).
     *
     * @param id идентификатор промпта
     * @return число обновлённых строк (0 — промпта нет)
     */
    @Modifying
    @Query("update Prompt p set p.usageCount = p.usageCount + 1 where p.id = :id")
    int incrementUsageCount(@Param("id") UUID id);
}
