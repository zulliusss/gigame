package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.List;

/**
 * JSON-объекты верхнего уровня, встречающиеся в тексте ответов моделей (в том числе внутри блоков ```json).
 * Разбор — общий ({@link LlmJson}): объект с десятичной запятой («"сумма": 1234567,89») чинится,
 * а не пропускается.
 */
final class JsonBlocks {

    private JsonBlocks() {
    }

    /**
     * Все разбираемые JSON-объекты текста по порядку (непересекающиеся).
     *
     * @param text текст
     * @return объекты
     */
    static List<JsonNode> objects(String text) {
        List<JsonNode> result = new ArrayList<>();
        for (LlmJson.Parsed block : parsedObjects(text)) {
            result.add(block.node());
        }
        return result;
    }

    /**
     * Все разбираемые JSON-объекты текста по порядку вместе с пометкой починки оборванного объекта
     * ({@link LlmJson.Parsed#repair()}): текст разбирается один раз, объекты затем выбираются из списка.
     *
     * @param text текст
     * @return разобранные объекты
     */
    static List<LlmJson.Parsed> parsedObjects(String text) {
        return LlmJson.all(text == null ? "" : text, LlmJson.OBJECT).blocks();
    }

    /**
     * Объект с заданным значением поля «тип_документа».
     *
     * @param blocks разобранные объекты ({@link #parsedObjects})
     * @param type   тип документа
     * @return объект с пометкой починки либо {@code null}
     */
    static LlmJson.Parsed byDocumentType(List<LlmJson.Parsed> blocks, String type) {
        for (LlmJson.Parsed block : blocks) {
            if (type.equalsIgnoreCase(block.node().path("тип_документа").asText("").strip())) {
                return block;
            }
        }
        return null;
    }
}
