package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.Arrays;
import java.util.UUID;

/**
 * Фоновая обработка файла, загруженного в базу знаний: разбор, распознавание
 * скана и индексация — вне HTTP-запроса. Загрузка отвечает клиенту сразу
 * документом в статусе {@code processing}; минуты OCR и эмбеддингов больше не
 * упираются в таймаут корпоративного шлюза, после которого клиент повторял
 * загрузку и плодил дубликаты.
 * <p>
 * Отдельный компонент, а не метод {@link KBService}: {@code @Async} работает
 * только через прокси, то есть при вызове из другого бина.
 */
@Service
@Slf4j
public class KBUploadProcessor {

    private final DocumentService documentService;
    private final DocumentIndexService indexService;
    private final DocumentRepository documentRepository;
    private final TransactionTemplate transactionTemplate;

    public KBUploadProcessor(PlatformTransactionManager transactionManager, DocumentService documentService,
                             DocumentIndexService indexService, DocumentRepository documentRepository) {
        this.documentService = documentService;
        this.indexService = indexService;
        this.documentRepository = documentRepository;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    /**
     * Ставит обработку файла в очередь общего пула {@code spring.task.execution}
     * (тот же исполнитель, что у индексации). При переполнении очереди вызывающий
     * получает {@link org.springframework.core.task.TaskRejectedException}.
     *
     * @param upload файл и документ базы знаний, созданный для него
     */
    @Async
    public void processAsync(PendingUpload upload) {
        CurrentUserHolder.withUser(upload.userId(), () -> {
            process(upload);
            return null;
        });
    }

    /**
     * Обработка в текущем потоке: текст извлечён и записан в документ (короткая
     * транзакция), затем индексация ({@link DocumentIndexService#indexKBDocument}).
     * Сбой разбора — статус error с причиной, индексация не запускается.
     *
     * @param upload файл и документ базы знаний
     */
    void process(PendingUpload upload) {
        log.info("[{}] Фоновая обработка файла «{}» для KB {}: {} КБ",
                CurrentUserHolder.getCurrentUser(), upload.filename(), upload.kbId(), upload.content().length / 1024);
        String text;
        try {
            text = documentService.extractText(upload.filename(), upload.contentType(), upload.content());
            transactionTemplate.execute(status -> saveText(upload.documentId(), text));
        } catch (Exception e) {
            log.error("[{}] Разбор файла «{}» для KB {} не удался", CurrentUserHolder.getCurrentUser(),
                    upload.filename(), upload.kbId(), e);
            indexService.markIndexingFailed(upload.kbId(), upload.documentId(), upload.kbDocId(),
                    "Не удалось извлечь текст: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            return;
        }
        indexService.indexKBDocument(upload.kbId(), upload.documentId(), upload.kbDocId());
    }

    private Document saveText(UUID documentId, String text) {
        Document document = documentRepository.findById(documentId)
                .orElseThrow(() -> new IllegalStateException("Документ не найден: " + documentId));
        document.setExtractedText(text);
        return documentRepository.save(document);
    }

    /**
     * Файл, принятый в базу знаний, и созданные для него записи.
     *
     * @param kbId        UUID базы знаний
     * @param documentId  UUID документа
     * @param kbDocId     UUID записи KBDocument (статус processing)
     * @param userId      пользователь, загрузивший файл (для журнала фонового потока)
     * @param filename    имя файла
     * @param contentType тип контента
     * @param content     содержимое файла
     */
    public record PendingUpload(UUID kbId, UUID documentId, UUID kbDocId, String userId,
                                String filename, String contentType, byte[] content) {

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            PendingUpload that = (PendingUpload) o;
            return java.util.Objects.equals(kbId, that.kbId)
                    && java.util.Objects.equals(documentId, that.documentId)
                    && java.util.Objects.equals(kbDocId, that.kbDocId)
                    && java.util.Objects.equals(userId, that.userId)
                    && java.util.Objects.equals(filename, that.filename)
                    && java.util.Objects.equals(contentType, that.contentType)
                    && Arrays.equals(content, that.content);
        }

        @Override
        public int hashCode() {
            int result = java.util.Objects.hash(kbId, documentId, kbDocId, userId, filename, contentType);
            result = 31 * result + Arrays.hashCode(content);
            return result;
        }

        @Override
        public String toString() {
            return "PendingUpload[kbId=" + kbId + ", documentId=" + documentId + ", kbDocId=" + kbDocId
                    + ", userId=" + userId + ", filename=" + filename + ", contentType=" + contentType
                    + ", content=" + java.util.Arrays.toString(content) + "]";
        }
    }
}
