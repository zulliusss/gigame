package ru.sber.cs.ai.gigame.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;
import org.apache.commons.compress.utils.SeekableInMemoryByteChannel;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Распаковка ZIP- и 7z-архивов с документами для сценариев.
 * <p>
 * Возвращает только содержательные документы: служебные файлы ЭДО
 * (электронные подписи, хэши, паспорта, технологические квитанции,
 * протоколы передачи) отфильтровываются. Вложенные архивы распаковываются
 * рекурсивно. Имя каждого документа включает имя архива и путь внутри него
 * ("архив.zip/папка/файл.pdf") — путь используется для группировки документов.
 * Файлы неподдерживаемого формата и архивы глубже лимита вложенности не теряются
 * молча: их имена возвращаются в {@link ExtractionResult#skippedNames()}.
 */
@Slf4j
public final class ZipExtractor {

    /** Файл, извлечённый из архива: полное имя (архив + путь внутри) и содержимое. */
    public record ExtractedFile(String name, byte[] content) {

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            ExtractedFile that = (ExtractedFile) o;
            return name.equals(that.name) && Arrays.equals(content, that.content);
        }

        @Override
        public int hashCode() {
            int result = name.hashCode();
            result = 31 * result + Arrays.hashCode(content);
            return result;
        }

        @Override
        public String toString() {
            return "ExtractedFile[name=" + name + ", content.length=" + content.length + "]";
        }
    }

    /**
     * Результат распаковки.
     *
     * @param files        содержательные документы
     * @param skippedCount число всех пропущенных файлов (служебные ЭДО + неподдерживаемые + глубокие архивы)
     * @param lostCount    число пропущенных файлов, которые могли нести содержание
     *                     (неподдерживаемый формат, архив глубже лимита вложенности)
     * @param skippedNames имена первых {@link #MAX_SKIPPED_NAMES} таких файлов (для предупреждения загрузки)
     */
    public record ExtractionResult(List<ExtractedFile> files, int skippedCount, int lostCount, List<String> skippedNames) {

        /**
         * Текст предупреждения о потерянных файлах архива либо {@code null}, если терять было нечего.
         *
         * @param zipName имя архива
         * @return текст предупреждения
         */
        public String lostWarning(String zipName) {
            if (lostCount <= 0) {
                return null;
            }
            String more = lostCount > skippedNames.size() ? ", …" : "";
            return "архив " + zipName + ": пропущено " + lostCount + " файлов ("
                    + String.join(", ", skippedNames) + more + ")";
        }
    }

    /**
     * Предел записей архива вместе с вложенными по умолчанию (corp26; до corp26 — жёстко 500). Служебные файлы ЭДО
     * (подписи, хэши, технологические XML) в предел не входят: в пакетах ЭДО их больше, чем документов, и архив опыта
     * на 2217 записей, из которых 1235 служебных, отвергался целиком. Настройка —
     * {@code app.document.max-archive-entries}.
     */
    static final int DEFAULT_MAX_ENTRIES = 5000;
    /**
     * Потолок всех записей архива вместе со служебными — защита от архива из миллиона пустых «подписей»; вторая
     * защита — {@link #MAX_TOTAL_UNCOMPRESSED_BYTES}.
     */
    static final int MAX_ALL_ENTRIES = 50_000;
    static final long MAX_TOTAL_UNCOMPRESSED_BYTES = 500L * 1024 * 1024;
    static final int MAX_NESTING_DEPTH = 3;
    /** Сколько имён пропущенных файлов попадает в предупреждение. */
    static final int MAX_SKIPPED_NAMES = 5;

    /** Кодировка имён записей для архивов без UTF-8-флага (архивы из Windows-инструментов). */
    private static final Charset LEGACY_NAME_CHARSET = Charset.forName("CP866");

    /** Расширения служебных файлов ЭДО (подписи и хэши). */
    private static final Set<String> SIGNATURE_EXTENSIONS = Set.of("sig", "sgn", "hash", "hash2012", "p7s");

    /**
     * Технологические XML оператора ЭДО (DP_IZVPOL, DP_PDPOL, DP_PDOTPR, DP_UVUTOCH,
     * DP_PRANNUL — извещения, подтверждения дат, уведомления): содержания документа
     * не несут. Прочие XML (УПД продавца ON_NSCHFDOPPR, титул покупателя
     * ON_NSCHFDOPPOK, акты ON_AKTREZRAB, корректировки ON_NKORSCHFDOPPR) идут в парсер.
     */
    private static final String SERVICE_XML_PREFIX = "dp_";

    /**
     * Служебные файлы Windows, macOS и Office, которые попадают в комплект при упаковке или загрузке папки (базовое имя
     * в нижнем регистре): файл блокировки Word/Excel «~$Договор.docx» (162 байта, по содержимому не docx), AppleDouble
     * «._Акт.pdf», desktop.ini и его копии «desktop (N).ini», Thumbs.db, ehthumbs.db, .DS_Store, ярлыки .lnk, временные
     * .tmp. Письма 25.09.2026 (Егорова «Ошибка 403», Борисов «Иновью»): «~$…docx» давал предупреждение «файл не обработан
     * (повреждён…)», 35 копий desktop.ini — предупреждения о пропуске.
     */
    private static final Pattern OS_JUNK_NAME = Pattern.compile(
            "~\\$.*|\\._.*|desktop(?: \\(\\d+\\))?\\.ini|(?:eh)?thumbs(?: \\(\\d+\\))?\\.db|\\.ds_store|.*\\.(?:tmp|lnk)");

    /** Папка ресурсов, которую Finder (macOS) кладёт в архив рядом с документами. */
    private static final String MACOS_RESOURCE_DIR = "__MACOSX";

    private ZipExtractor() {
    }

    /**
     * Распаковывает архив (ZIP или 7z — по расширению имени), отфильтровывая
     * служебные файлы.
     *
     * @param zipName имя архива (используется как префикс имён документов)
     * @param bytes   содержимое архива
     * @return содержательные документы и учёт пропущенных файлов
     * @throws FileException если архив повреждён или превышены лимиты распаковки
     */
    public static ExtractionResult extract(String zipName, byte[] bytes) {
        return extract(zipName, bytes, DEFAULT_MAX_ENTRIES);
    }

    /**
     * Распаковывает архив с заданным пределом записей (служебные файлы ЭДО в предел не входят).
     *
     * @param zipName    имя архива (используется как префикс имён документов)
     * @param bytes      содержимое архива
     * @param maxEntries предел содержательных записей вместе с вложенными архивами; меньше 1 — умолчание
     * @return содержательные документы и учёт пропущенных файлов
     * @throws FileException если архив повреждён или превышены лимиты распаковки
     */
    public static ExtractionResult extract(String zipName, byte[] bytes, int maxEntries) {
        List<ExtractedFile> files = new ArrayList<>();
        Budget budget = new Budget(maxEntries > 0 ? maxEntries : DEFAULT_MAX_ENTRIES);
        if ("7z".equals(extension(zipName))) {
            extract7zInto(zipName, bytes, 1, files, budget);
        } else {
            extractInto(zipName, bytes, 1, files, budget);
        }
        if (budget.seen == 0) {
            // ZipInputStream на «мусорных» байтах молча отдаёт 0 записей
            throw new FileException("Архив пуст или повреждён: " + zipName);
        }
        log.info("Архив '{}': извлечено {} документ(ов), пропущено {} служебных/неподдерживаемых файлов (из них потенциально содержательных {})",
                zipName, files.size(), budget.skipped, budget.lost);
        return new ExtractionResult(files, budget.skipped, budget.lost, budget.lostNames);
    }

    private static final class Budget {
        final int maxEntries;
        /** Все записи вместе со служебными — для потолка {@link #MAX_ALL_ENTRIES} и проверки «архив пуст». */
        int seen;
        /** Содержательные записи — для предела {@link #maxEntries}. */
        int entries;
        long uncompressedBytes;
        int skipped;
        int lost;
        final List<String> lostNames = new ArrayList<>();

        Budget(int maxEntries) {
            this.maxEntries = maxEntries;
        }

        void lose(String name) {
            skipped++;
            lost++;
            if (lostNames.size() < MAX_SKIPPED_NAMES) {
                lostNames.add(name);
            }
        }
    }

    private static void extractInto(String prefix, byte[] bytes, int depth,
                                    List<ExtractedFile> out, Budget budget) {
        try (ZipInputStream zis = new ZipInputStream(new ByteArrayInputStream(bytes), LEGACY_NAME_CHARSET)) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                processEntry(prefix, entry, zis, depth, out, budget);
            }
        } catch (FileException e) {
            throw e;
        } catch (IOException e) {
            throw new FileException("Не удалось распаковать архив: " + prefix + unpackReason(e), e);
        }
    }

    /**
     * Причина сбоя распаковки для маркера и предупреждения загрузки: раньше текст причины оставался только
     * в cause, и пользователь видел «Не удалось распаковать архив: x.zip», не понимая, что архив под паролем
     * («encrypted ZIP entry not supported», «Cannot read encrypted content … without a password») или повреждён
     * («invalid entry CRC»). Видимость package-private для тестов.
     *
     * @param e ошибка библиотеки распаковки
     * @return « (причина)»
     */
    static String unpackReason(IOException e) {
        String message = e.getMessage() == null || e.getMessage().isBlank() ? e.getClass().getSimpleName() : e.getMessage();
        String lower = message.toLowerCase(Locale.ROOT);
        if (lower.contains("encrypted") || lower.contains("password")) {
            return " (архив защищён паролем — снимите пароль и загрузите заново)";
        }
        return " (" + message + ")";
    }

    /**
     * Обрабатывает одну запись архива: учитывает лимит записей, пропускает
     * служебные файлы, вложенный zip распаковывает рекурсивно (с учётом глубины),
     * содержательный документ добавляет в результат.
     */
    private static void processEntry(String prefix, ZipEntry entry, ZipInputStream zis, int depth,
                                     List<ExtractedFile> out, Budget budget) throws IOException {
        String rawName = entry.getName() == null ? "" : fixLegacyName(entry.getName());
        String entryName = (rawName == null ? "" : rawName).replace('\\', '/');
        countEntry(entryName, budget);
        String fullName = prefix + "/" + entryName;
        String ext = extension(entryName);

        if ("zip".equals(ext) || "7z".equals(ext)) {
            recurseNestedArchive(fullName, ext, readEntry(zis, entryName, budget), depth, out, budget);
            return;
        }
        if (isJunk(entryName)) {
            skip(entryName, budget);
            return;
        }
        out.add(new ExtractedFile(fullName, readEntry(zis, entryName, budget)));
    }

    /**
     * Учёт записи в пределах архива: все записи — в потолок {@link #MAX_ALL_ENTRIES}, содержательные (не служебные
     * файлы ЭДО) — в настраиваемый предел.
     *
     * @param entryName имя записи внутри архива
     * @param budget    учёт распаковки
     * @throws FileException если предел превышен
     */
    private static void countEntry(String entryName, Budget budget) {
        if (++budget.seen > MAX_ALL_ENTRIES) {
            throw new FileException("Архив содержит слишком много файлов (лимит " + MAX_ALL_ENTRIES
                    + " вместе со служебными файлами ЭДО)");
        }
        if (!isServiceFile(entryName) && ++budget.entries > budget.maxEntries) {
            throw new FileException("Архив содержит слишком много файлов (лимит " + budget.maxEntries
                    + ", служебные файлы ЭДО не считаются)");
        }
    }

    /** Служебный файл ЭДО — тихий пропуск; неподдерживаемый формат — в учёт потерь. */
    private static void skip(String entryName, Budget budget) {
        if (isServiceFile(entryName)) {
            budget.skipped++;
        } else {
            budget.lose(entryName);
        }
    }

    /** Вложенный архив (zip/7z): рекурсивная распаковка с контролем глубины. */
    private static void recurseNestedArchive(String fullName, String ext, byte[] bytes, int depth,
                                             List<ExtractedFile> out, Budget budget) {
        if (depth >= MAX_NESTING_DEPTH) {
            log.warn("Пропущен вложенный архив '{}': превышена глубина вложенности {}",
                    fullName, MAX_NESTING_DEPTH);
            budget.lose(fullName.substring(fullName.lastIndexOf('/') + 1) + " (вложенность глубже " + MAX_NESTING_DEPTH + ")");
            return;
        }
        if ("7z".equals(ext)) {
            extract7zInto(fullName, bytes, depth + 1, out, budget);
        } else {
            extractInto(fullName, bytes, depth + 1, out, budget);
        }
    }

    /**
     * Распаковка 7z-архива (commons-compress + XZ for Java): та же логика, что
     * у ZIP — фильтр служебных файлов, рекурсия вложенных архивов, общие лимиты.
     * 7z требует произвольного доступа, поэтому читается из памяти целиком
     * (SeekableInMemoryByteChannel), а не потоково.
     */
    private static void extract7zInto(String prefix, byte[] bytes, int depth,
                                      List<ExtractedFile> out, Budget budget) {
        try (SevenZFile sevenZ = SevenZFile.builder()
                .setSeekableByteChannel(new SeekableInMemoryByteChannel(bytes)).get()) {
            SevenZArchiveEntry entry;
            while ((entry = sevenZ.getNextEntry()) != null) {
                if (entry.isDirectory()) {
                    continue;
                }
                String entryName = entry.getName() == null ? "" : entry.getName().replace('\\', '/');
                countEntry(entryName, budget);
                String fullName = prefix + "/" + entryName;
                String ext = extension(entryName);
                boolean isArchive = "zip".equals(ext) || "7z".equals(ext);
                if (isArchive) {
                    recurseNestedArchive(fullName, ext,
                            readStream(sevenZ.getInputStream(entry), entryName, budget), depth, out, budget);
                } else if (isJunk(entryName)) {
                    skip(entryName, budget);
                } else {
                    out.add(new ExtractedFile(fullName,
                            readStream(sevenZ.getInputStream(entry), entryName, budget)));
                }
            }
        } catch (FileException e) {
            throw e;
        } catch (IOException e) {
            throw new FileException("Не удалось распаковать архив: " + prefix + unpackReason(e), e);
        }
    }

    private static byte[] readEntry(ZipInputStream zis, String entryName, Budget budget) throws IOException {
        return readStream(zis, entryName, budget);
    }

    /** Читает поток записи архива с учётом общего лимита распакованных байт. */
    private static byte[] readStream(InputStream in, String entryName, Budget budget) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[64 * 1024];
        int read;
        while ((read = in.read(buf)) > 0) {
            budget.uncompressedBytes += read;
            if (budget.uncompressedBytes > MAX_TOTAL_UNCOMPRESSED_BYTES) {
                throw new FileException("Превышен лимит распакованного размера архива ("
                        + (MAX_TOTAL_UNCOMPRESSED_BYTES / (1024 * 1024)) + " МБ) на файле: " + entryName);
            }
            bos.write(buf, 0, read);
        }
        return bos.toByteArray();
    }

    /**
     * Имя записи архива без UTF-8-флага, прочитанное как CP866. Архивы macOS
     * (Finder) пишут имена в UTF-8 без флага: после CP866 кириллица превращается
     * в «Р»+псевдографику. Если в имени есть символы псевдографики, исходные байты
     * перекодируются как строгий UTF-8; неудача — имя остаётся как есть.
     * Видимость package-private для тестов.
     *
     * @param name имя записи после декодирования CP866
     * @return исправленное имя либо исходное
     */
    static String fixLegacyName(String name) {
        if (name == null || !looksGarbled(name)) {
            return name;
        }
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(name.getBytes(LEGACY_NAME_CHARSET))).toString();
        } catch (CharacterCodingException e) {
            return name;
        }
    }

    /** Псевдографика CP866 (U+2500–U+25FF) в имени файла — признак UTF-8-байтов, прочитанных как CP866. */
    private static boolean looksGarbled(String name) {
        for (int i = 0; i < name.length(); i++) {
            char c = name.charAt(i);
            if (c >= '─' && c <= '◿') {
                return true;
            }
        }
        return false;
    }

    /**
     * Служебный файл ЭДО или неизвестный формат — в обработку не идёт. Документ известного, но не
     * поддерживаемого формата (doc, rtf, odt — {@link FileUtils#isKnownDocumentExtension}) мусором не считается:
     * он доходит до разбора и получает маркер «формат не поддерживается», а не пропадает из прогона молча.
     * Видимость package-private для тестов.
     */
    static boolean isJunk(String entryPath) {
        return isServiceFile(entryPath) || !FileUtils.isKnownDocumentExtension(extension(baseName(entryPath)));
    }

    /**
     * Служебный файл ЭДО (подписи, хэши, паспорта ЭП, протоколы передачи,
     * технологические XML оператора) или операционной системы и Office ({@link #isOsJunk}) — пропускается без
     * предупреждения.
     */
    static boolean isServiceFile(String entryPath) {
        String baseName = baseName(entryPath);
        String lower = baseName.toLowerCase(Locale.ROOT);
        String ext = extension(baseName);

        if (isOsJunk(entryPath) || SIGNATURE_EXTENSIONS.contains(ext)) {
            return true;
        }
        // паспорта ЭП: Passport(01).txt и т.п.
        if ("txt".equals(ext) && lower.startsWith("passport")) {
            return true;
        }
        // протоколы оператора ЭДО о передаче документа
        if ("pdf".equals(ext) && lower.contains("протокол передачи документа")) {
            return true;
        }
        return "xml".equals(ext) && lower.startsWith(SERVICE_XML_PREFIX);
    }

    /**
     * Служебный файл Windows, macOS или Office: блокировка «~$…», AppleDouble «._…», desktop.ini и его копии, Thumbs.db,
     * .DS_Store, *.tmp, *.lnk (см. {@link #OS_JUNK_NAME}) либо запись из папки «__MACOSX». Документом не является ни
     * в архиве, ни среди файлов, загруженных россыпью (папкой).
     *
     * @param path имя файла или путь записи архива (разделители «/» или «\»)
     * @return {@code true} — служебный файл, в разбор не идёт
     */
    public static boolean isOsJunk(String path) {
        if (path == null || path.isEmpty()) {
            return false;
        }
        String normalized = path.replace('\\', '/');
        if (("/" + normalized).contains("/" + MACOS_RESOURCE_DIR + "/")) {
            return true;
        }
        return OS_JUNK_NAME.matcher(baseName(normalized).toLowerCase(Locale.ROOT)).matches();
    }

    private static String baseName(String entryPath) {
        return entryPath.substring(entryPath.lastIndexOf('/') + 1);
    }

    private static String extension(String name) {
        int dotIdx = name.lastIndexOf('.');
        return dotIdx < 0 ? "" : name.substring(dotIdx + 1).toLowerCase(Locale.ROOT);
    }
}
