package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputView;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.KBService;
import ru.sber.cs.ai.gigame.service.annotate.AnnotationConfig;
import ru.sber.cs.ai.gigame.service.annotate.DocumentAnnotationService;
import ru.sber.cs.ai.gigame.service.annotate.RunArtifactStore;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.InMemoryFilePart;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Дополнительные возможности output-узла, включаемые через его {@code rules}:
 * <ul>
 *   <li>{@code "накапливать": true} — нарастающий итог: к строкам текущего
 *   прогона дописываются строки того же output-узла из ПРЕДЫДУЩЕГО прогона
 *   сценария тем же пользователем (партия за партией: обработали первые документы, догрузили
 *   следующие — форма содержит все строки);</li>
 *   <li>{@code "в_базу_знаний": "<uuid БЗ>"} — реестр: результат узла
 *   сохраняется текстовым документом в базу знаний, где накапливается
 *   реестр обработанных заявок для кросс-проверок через RAG.</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScenarioOutputSupportService {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private final ScenarioRunRepository scenarioRunRepository;
    private final ScenarioRunStepRepository scenarioRunStepRepository;
    private final KBService kbService;
    private final ScenarioRepository scenarioRepository;
    private final DocumentAnnotationService documentAnnotationService;
    private final RunArtifactStore runArtifactStore;

    /**
     * Разметка исходных документов: если в rules Excel-узла есть {@code "разметка_документов"},
     * по строкам результата в исходных DOCX и PDF прогона подсвечиваются цитаты находок с комментариями,
     * ZIP размеченных документов складывается в артефакты прогона — скачивание файла узла отдаёт его
     * вместе с Excel. Любая ошибка разметки — предупреждение в лог, прогон продолжается.
     *
     * @param run    текущий прогон
     * @param node   output-узел
     * @param result результат узла (текст с JSON-массивом строк)
     */
    public void annotateIfConfigured(ScenarioRun run, ScenarioRunNode node, String result) {
        AnnotationConfig cfg = AnnotationConfig.parse(node.getRules());
        if (cfg == null) {
            return;
        }
        try {
            UUID key = DocsTextCacheService.scenarioKey(run.getScenarioId(), node.getGraph().getRunnerUserId());
            Map<String, String> docTexts = new LinkedHashMap<>();
            for (ScenarioRunDoc doc : node.getGraph().getDocMap().values()) {
                // одноимённые документы с разным текстом (второй лот с тем же «Договор.pdf») не схлопываются
                docTexts.put(DocumentAnnotationService.uniqueName(docTexts, doc.getFilename()), doc.getText());
            }
            List<Map<String, Object>> rows = ScenarioResultToXlsx.rowsOf(result);
            byte[] zip = documentAnnotationService.annotate(key, run.getId(), cfg, rows, docTexts);
            runArtifactStore.save(run.getId(), node.getId(), zip);
            log.info("[{}] Разметка документов узла {} прогона {}: строк {}, ZIP {} байт",
                    CurrentUserHolder.getCurrentUser(), node.getId(), run.getId(), rows.size(), zip.length);
        } catch (Exception e) {
            log.warn("[{}] Разметка документов узла {} не удалась ({}) — прогон продолжается",
                    CurrentUserHolder.getCurrentUser(), node.getId(), e.getMessage());
            saveFailureNote(run, node, e.getMessage());
        }
    }

    /**
     * Разметка не выполнена — в артефакты прогона кладётся ZIP с одним отчётом о причине: скачивание файла
     * узла отдаст Excel и отчёт, а не молча Excel без разметки.
     *
     * @param run    прогон
     * @param node   output-узел
     * @param reason причина
     */
    private void saveFailureNote(ScenarioRun run, ScenarioRunNode node, String reason) {
        try {
            runArtifactStore.save(run.getId(), node.getId(),
                    DocumentAnnotationService.reportOnly("разметка документов не выполнена: " + reason));
        } catch (Exception e) {
            log.warn("[{}] Отчёт о неудавшейся разметке узла {} не сохранён ({})",
                    CurrentUserHolder.getCurrentUser(), node.getId(), e.getMessage());
        }
    }

    /**
     * Нарастающий итог: если в rules узла включено {@code "накапливать"},
     * строки этого же узла из предыдущего прогона сценария дописываются
     * ПЕРЕД строками текущего результата (новое — ниже ранее обработанного).
     * Любая проблема (нет прошлых прогонов, не распарсились строки) — результат
     * возвращается без изменений.
     *
     * @param run    текущий прогон
     * @param node   output-узел
     * @param result результат узла (текст с JSON-массивом строк)
     * @return слитый JSON-массив строк либо исходный результат
     */
    public String accumulateIfConfigured(ScenarioRun run, ScenarioRunNode node, String result) {
        Map<String, Object> rules = parseRules(node.getRules());
        if (!Boolean.parseBoolean(String.valueOf(rules.get("накапливать")))) {
            return result;
        }
        try {
            List<Map<String, Object>> current = parseRows(result);
            if (current == null) {
                return result;
            }
            List<Map<String, Object>> previous = previousRows(run, node);
            if (previous.isEmpty()) {
                return result;
            }
            List<Map<String, Object>> merged = new ArrayList<>(previous);
            merged.addAll(current);
            log.info("[{}] Нарастающий итог узла {}: {} строк прошлых прогонов + {} новых",
                    CurrentUserHolder.getCurrentUser(), node.getId(), previous.size(), current.size());
            return objectMapper.writeValueAsString(merged);
        } catch (Exception e) {
            log.warn("[{}] Нарастающий итог узла {} не собран ({}) — используется текущий результат",
                    CurrentUserHolder.getCurrentUser(), node.getId(), e.getMessage());
            return result;
        }
    }

    /**
     * Реестр: если в rules узла задан {@code "в_базу_знаний"}, результат
     * сохраняется текстовым документом в указанную базу знаний. Ошибка
     * сохранения НЕ роняет прогон (реестр вторичен) — только предупреждение
     * в лог.
     * <p>
     * corp23: документ-реестр один на пару «сценарий + автор прогона» (имя {@link #registryName}) и
     * заменяется каждым прогоном (прежний удаляется вместе с эмбеддингами), а не добавляется: при
     * «накапливать» каждый реестр содержал все прежние строки, и RAG находил одну заявку в десятках копий.
     * Реестр с тем же содержимым (SHA-256) остаётся без переиндексации.
     *
     * @param run    текущий прогон
     * @param node   output-узел
     * @param result результат узла
     */
    public void saveToKnowledgeBaseIfConfigured(ScenarioRun run, ScenarioRunNode node, String result) {
        Map<String, Object> rules = parseRules(node.getRules());
        Object kbIdRaw = rules.get("в_базу_знаний");
        if (kbIdRaw == null || String.valueOf(kbIdRaw).isBlank()) {
            return;
        }
        try {
            UUID kbId = UUID.fromString(String.valueOf(kbIdRaw).strip());
            String filename = registryName(run);
            // без id прогона в тексте: одинаковый результат даёт одинаковый хэш — повтор не переиндексируется
            String content = "Реестр результатов сценария " + run.getScenarioId() + "\n\n" + result;
            byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
            int replaced = kbService.removeDocumentsByFilename(kbId, filename, DocumentService.sha256Hex(bytes));
            kbService.addDocumentToKB(kbId, new InMemoryFilePart(filename, bytes));
            log.info("[{}] Результат узла {} прогона {} сохранён в базу знаний {} ({}, прежних реестров удалено: {})",
                    CurrentUserHolder.getCurrentUser(), node.getId(), run.getId(), kbId, filename, replaced);
        } catch (Exception e) {
            log.warn("[{}] Не удалось сохранить результат узла {} в базу знаний ({}) — прогон продолжается",
                    CurrentUserHolder.getCurrentUser(), node.getId(), e.getMessage());
        }
    }

    /**
     * Имя документа-реестра в базе знаний: стабильно для пары «сценарий + автор прогона».
     *
     * @param run прогон
     * @return имя файла {@code registry-<scenarioId>-<userId>.txt}
     */
    static String registryName(ScenarioRun run) {
        String user = run.getUserId() == null || run.getUserId().isBlank() ? "shared" : run.getUserId();
        return "registry-" + run.getScenarioId() + "-" + user + ".txt";
    }

    /** Строки этого же узла из последнего прогона сценария, где узел завершился успешно. */
    private List<Map<String, Object>> previousRows(ScenarioRun run, ScenarioRunNode node) {
        List<ScenarioRun> runs = previousRuns(run);
        for (ScenarioRun previous : runs) {
            if (previous.getId().equals(run.getId())) {
                continue;
            }
            // только шаги этого узла и только их результат — без промптов и входов всех шагов прогона
            List<StepOutputView> steps = scenarioRunStepRepository
                    .findViewByRunIdAndNodeIdOrderByStartedAtAsc(previous.getId(), node.getId());
            for (StepOutputView step : steps) {
                if (step.getOutputData() == null) {
                    continue;
                }
                Object prevResult = step.result();
                List<Map<String, Object>> rows = parseRows(String.valueOf(prevResult));
                if (rows != null && !rows.isEmpty()) {
                    // последний завершённый прогон, где форма этого узла построена
                    return rows;
                }
            }
        }
        return List.of();
    }

    /**
     * Прогоны сценария — источники нарастающего итога. Общий сценарий запускают
     * разные пользователи — берутся только прогоны автора текущего прогона;
     * владельцу сценария, как и в истории запусков, — ещё и старые прогоны без автора
     * (созданные до появления поля), чтобы цепочка партий не оборвалась после обновления.
     * Берутся только успешно завершённые прогоны, последние по времени завершения
     * первыми: у пересекающихся прогонов одного пользователя позже стартовавший мог
     * завершиться раньше, и выбор по старту терял партию завершившегося последним.
     * Для прогона без автора — прежнее поведение (любые прогоны сценария).
     */
    private List<ScenarioRun> previousRuns(ScenarioRun run) {
        if (run.getUserId() == null) {
            return scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(run.getScenarioId());
        }
        boolean scenarioOwner = scenarioRepository.findById(run.getScenarioId())
                .map(Scenario::getUserId)
                .filter(run.getUserId()::equals)
                .isPresent();
        return scenarioOwner
                ? scenarioRunRepository.findCompletedOwnerRuns(run.getScenarioId(), run.getUserId())
                : scenarioRunRepository.findCompletedRunsByUser(run.getScenarioId(), run.getUserId());
    }

    /** @return строки JSON-массива из текста результата либо {@code null}, если массива нет */
    private List<Map<String, Object>> parseRows(String result) {
        try {
            String json = ScenarioResultToXlsx.extractJson(result);
            if (!json.trim().startsWith("[")) {
                return List.of();
            }
            return objectMapper.readValue(json, new TypeReference<>() {
            });
        } catch (Exception e) {
            return List.of();
        }
    }

    /** @return rules узла как карта; пустая карта при отсутствии или невалидном JSON */
    private Map<String, Object> parseRules(String rulesJson) {
        if (rulesJson == null || rulesJson.isBlank() || rulesJson.trim().startsWith("[")) {
            return Map.of();
        }
        try {
            return objectMapper.readValue(rulesJson, new TypeReference<>() {
            });
        } catch (Exception e) {
            return Map.of();
        }
    }
}
