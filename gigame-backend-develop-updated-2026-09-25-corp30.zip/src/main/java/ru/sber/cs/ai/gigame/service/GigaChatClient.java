package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatEmbeddingOptions;
import chat.giga.springai.GigaChatModel;
import chat.giga.springai.GigaChatOptions;
import chat.giga.springai.api.chat.GigaChatApi;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.content.Media;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.exception.AgentContextOverflowException;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.exception.GigaChatRefusedException;
import ru.sber.cs.ai.gigame.exception.GigaFilterBlockedException;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Тонкая обёртка над Spring AI моделями (авто-настроенные GigaChat).
 * <p>
 * Сохраняет те же сигнатуры публичных методов, чтобы ChatService и ScenarioEngine
 * не требовали изменений.
 *
 * @see ChatModel
 * @see EmbeddingModel
 */
@Service
@Slf4j
// Когнитивная сложность оркестрации tool-цикла и деления запроса, короткие служебные
// ключи JSON и вложенные условия сообщений — правки нецелесообразны (см. Rules.md).
@SuppressWarnings({ "java:S3776", "java:S1192", "java:S3358" })
public class GigaChatClient {

    /** Предохранитель раундов tool-цикла (инструменты лимитируются раньше). */
    static final int TOOL_ROUNDS_LIMIT = 60;
    /** Последние K tool-ответов остаются полными при сжатии истории. */
    static final int COMPACT_KEEP_LAST = 2;
    /** Tool-ответы короче порога не сжимаются (сжимать нечего). */
    static final int COMPACT_MIN_CHARS = 1500;
    /** Последнее сообщение с ответами инструментов не сжимается при укладке истории агента в бюджет контекста. */
    static final int FIT_KEEP_LAST = 1;
    /** Код ответа «превышен лимит запросов». */
    static final int HTTP_TOO_MANY_REQUESTS = 429;
    /** Начало кодов ответа «ошибка сервера». */
    static final int HTTP_SERVER_ERROR = 500;
    /** Код 5xx отдельным числом в тексте ошибки без кода ответа (а не часть числа токенов, как «502» в «135021»). */
    private static final Pattern SERVER_ERROR_CODE = Pattern.compile("(?<!\\d)50[0234](?!\\d)");
    /** Код 429 отдельным числом в тексте ошибки без кода ответа. */
    private static final Pattern RATE_LIMIT_CODE = Pattern.compile("(?<!\\d)429(?!\\d)");
    /** Глубина обхода цепочки причин ошибки. */
    private static final int CAUSE_DEPTH = 8;
    /** Максимум дозапросов «продолжи» при обрыве ответа по лимиту длины. */
    static final int MAX_CONTINUATIONS = 4;
    static final String CONTINUE_PROMPT = "Твой ответ оборвался по лимиту длины. Продолжи ТОЧНО с места обрыва: "
            + "не повторяй уже написанное, без вступлений, пояснений и повторения заголовков — только продолжение текста.";
    /** Маркер в конце ответа, который остался усечённым по лимиту длины после всех дозапросов. */
    public static final String TRUNCATED_MARKER = "[… ответ модели усечён по лимиту длины …]";
    /** Маркер в конце усечённого ответа, хвост которого зациклился: повтор обрезан, дочитывание прекращено. */
    public static final String LOOP_MARKER = "[… ответ модели зациклился — повтор обрезан]";
    /** Кратчайший повторяющийся кусок хвоста, символов (один символ — законные заполнители «____», «....»). */
    static final int LOOP_MIN_UNIT = 2;
    /** Длиннейший повторяющийся кусок хвоста, символов. */
    static final int LOOP_MAX_UNIT = 80;
    /**
     * Сколько раз кусок должен повториться подряд до конца ответа, чтобы считаться зацикливанием. Проверка на всех
     * выходах узлов 29 прогонов регресса 16.09.2026 (срезы через каждые 97 символов) сработала только на «10 шт.; »
     * узла s4 Субботина; законные таблицы («| Да | Нет | Нет |») подряд до 25 раз один кусок не повторяют.
     */
    static final int LOOP_MIN_REPEATS = 25;
    /** Хвост ответа, в котором ищется повтор, символов. */
    static final int LOOP_TAIL_CHARS = 3000;
    /** Сколько первых вхождений повтора остаётся в ответе. */
    static final int LOOP_KEEP_REPEATS = 3;
    /** Глубина деления контекста при «context too long»: до 2^3 = 8 частей. */
    static final int MAX_SPLIT_DEPTH = 3;
    /** Контекст короче порога не делится — «context too long» на нём означает слишком длинную инструкцию. */
    static final int MIN_SPLIT_CONTEXT = 2_000;
    /**
     * Невидимая граница «инструкция | контекст» в тексте промпта узла (U+2063 INVISIBLE SEPARATOR):
     * при «context too long» делится только контекст после неё, перед отправкой модели вырезается.
     */
    public static final String SPLIT_BOUNDARY = "\u2063";
    /** Невидимая подсказка в конце промпта (U+2064): при делении объединять JSON-массивы ответов частей. */
    public static final String MERGE_ARRAYS_HINT = "\u2064";
    /** Заголовок собранного из частей ответа: «=== Часть 1/N (…) ===» либо «=== Ответ собран из N частей (…)». */
    private static final Pattern PARTS_HEADER = Pattern.compile("^=== (?:Часть 1/(\\d+)|Ответ собран из (\\d+) частей) ");
    /** Начало уведомлений журнала прогона об отказе цензора GigaChat на запросе узла. */
    static final String REFUSAL_NOTICE = "⚠ модель отказалась (ограничение темы GigaChat)";

    private final ChatModel chatModel;
    private final EmbeddingModel embeddingModel;
    /**
     * API файлового хранилища GigaChat (может отсутствовать в тестовом контексте).
     */
    private final ObjectProvider<GigaChatApi> gigaChatApiProvider;
    /** Общий ограничитель одновременных запросов к GigaChat; до внедрения Spring — без ограничения. */
    private GigaChatConcurrencyLimiter concurrencyLimiter = GigaChatConcurrencyLimiter.unlimited();
    /** Распознавание отказа цензора GigaChat в ответах узлам сценария; до внедрения Spring — встроенные фразы. */
    private GigaChatRefusal refusalDetector = GigaChatRefusal.defaults();
    /**
     * Фильтр GigaFilter на входе и выходе и параметр profanity_check; до внедрения Spring (клиенты, созданные вручную) —
     * выключен: запросы как раньше.
     */
    private GigaFilterGuard profanityGuard = GigaFilterGuard.disabled();
    /**
     * Вызовы фильтра GigaFilter под общим ограничителем: одно разрешение на проход проверки запроса, без уведомлений
     * об очереди в журнал прогона (иначе каждый проход добавлял бы пару строк «потоки заняты / очередь пройдена»),
     * остановка прогона прерывает проверку между вызовами фильтра.
     */
    private final GigaFilterGuard.Limited filterLimited = new GigaFilterGuard.Limited() {
        @Override
        public <T> T call(Supplier<T> call) {
            return concurrencyLimiter.call(call, runCancelCheck(), null);
        }

        @Override
        public boolean cancelled() {
            BooleanSupplier check = runCancelCheck();
            return check != null && check.getAsBoolean();
        }
    };
    /**
     * Предел вызовов модели на один запрос узла при делении документа из-за отказа цензора (вместе с первым полным
     * запросом): отклонённые части делятся в ширину (сначала все части уровня), пока бюджет покрывает обе половины,
     * иначе помечаются. Отказ цензора приходит до генерации (проба 16.09.2026: 0,1–0,8 с, prompt_tokens=1,
     * completion_tokens=0), поэтому умолчание покрывает полное дерево деления глубины {@link #MAX_SPLIT_DEPTH}.
     */
    @Value("${app.gigachat.refusal-split-max-calls:16}")
    private int refusalSplitMaxCalls = 16;
    /**
     * Предел длины части контекста при упреждающем делении (corp21, {@link #splitBySize}); по умолчанию равен
     * {@code app.chat.document-char-limit} — прежнему пределу обрезки документов.
     */
    @Value("${app.gigachat.split-part-chars:${app.chat.document-char-limit:200000}}")
    private int splitPartChars = 200_000;
    /** Перекрытие соседних частей при упреждающем делении, знаков. */
    @Value("${app.gigachat.split-overlap-chars:2000}")
    private int splitOverlapChars = 2000;
    /**
     * Бюджет контекста агентного цикла, токенов: перед каждым раундом история больше бюджета сжимается
     * ({@link AgentContextBudget#fit}); окно модели — 130048 токенов.
     */
    @Value("${app.agent.max-context-tokens:100000}")
    private int agentMaxContextTokens = AgentContextBudget.DEFAULT_MAX_CONTEXT_TOKENS;
    /** Символов на токен в оценке размера истории агента. */
    @Value("${app.agent.chars-per-token:3.0}")
    private double agentCharsPerToken = AgentContextBudget.DEFAULT_CHARS_PER_TOKEN;
    @Value("${app.embedding.text-max-length:800}")
    private int textMaxLength;
    @Value("${app.embedding.batch-size:50}")
    private int batchSize;
    /**
     * Повторные попытки вызова GigaChat при временных сбоях (429, 5xx, сеть).
     * Дорогие многоузловые сценарии не должны падать из-за разового сбоя API.
     */
    @Value("${app.gigachat.retry.max-attempts:3}")
    private int retryMaxAttempts;
    @Value("${app.gigachat.retry.delay-millis:3000}")
    private long retryDelayMillis;
    @Value("${app.gigachat.retry.delay-429-millis:30000}")
    private long retryDelay429Millis;
    /**
     * Превышение лимита запросов (429): шаг не падает, а ждёт и продолжается
     * сам — пауза удваивается от delay-429-millis до rate-limit-max-delay-millis,
     * пока суммарное ожидание не превысит rate-limit-max-wait-millis.
     */
    @Value("${app.gigachat.retry.rate-limit-max-wait-millis:1800000}")
    private long rateLimitMaxWaitMillis = 1_800_000;
    @Value("${app.gigachat.retry.rate-limit-max-delay-millis:300000}")
    private long rateLimitMaxDelayMillis = 300_000;
    /**
     * Недоступность GigaChat (5xx, таймаут, обрыв соединения, DNS): шаг встаёт на паузу и продолжается сам,
     * пауза удваивается от delay-millis до unavailable-max-delay-millis, пока суммарное ожидание не превысит
     * unavailable-max-wait-millis. Значение 0 — прежнее правило: max-attempts попыток с линейной задержкой.
     */
    @Value("${app.gigachat.retry.unavailable-max-wait-millis:1800000}")
    private long unavailableMaxWaitMillis;
    @Value("${app.gigachat.retry.unavailable-max-delay-millis:120000}")
    private long unavailableMaxDelayMillis = 120_000;
    /**
     * Пауза перед единственным повтором после 401: библиотека spring-ai-gigachat обновляет токен только
     * по плановому сроку (95 % TTL) и на 401 не реагирует; за паузу соседний вызов мог получить новый токен.
     */
    @Value("${app.gigachat.retry.unauthorized-retry-delay-millis:1500}")
    private long unauthorizedRetryDelayMillis = 1500;
    /**
     * Страховочный потолок одного сетевого LLM-вызова, секунд (больше
     * read-timeout клиента): read-timeout изредка не срабатывает — после
     * волны 429 JDK-клиент повисал в CompletableFuture.get() без отмены,
     * и поток узла висел часами. По истечении потолка вызов прерывается
     * и уходит в общий retry (как таймаут ответа — не больше двух повторов).
     */
    @Value("${app.gigachat.call-hard-timeout-seconds:660}")
    private long callHardTimeoutSeconds;
    /**
     * Размер пула потоков страховочных LLM-вызовов; 0 — по умолчанию
     * max(2, 2 × app.gigachat.max-concurrent). Пул ограничен: при сработавшем
     * потолке ожидания поток остаётся занят до ответа сети, и безграничный
     * cached-пул рос бы с каждым повисшим вызовом.
     */
    @Value("${app.gigachat.llm-call-pool-size:0}")
    private int llmCallPoolSize;
    @Value("${app.gigachat.max-concurrent:5}")
    private int maxConcurrent = 5;
    /** Потоки страховочных LLM-вызовов (daemon — не держат остановку JVM); создаётся при первом вызове. */
    @SuppressWarnings("java:S3077") // volatile — безопасная публикация лениво создаваемого пула (llmCallPool())
    private volatile ExecutorService llmCallPool;

    /**
     * Стек счётчиков токенов текущего потока: движок сценариев открывает кадр
     * перед выполнением узла и закрывает после — все LLM-вызовы узла суммируются.
     * Стек (а не одиночный счётчик) нужен для вложенных под-сценариев:
     * закрытый кадр вливается в родительский.
     */
    private static final ThreadLocal<Deque<long[]>> USAGE_CAPTURE =
            ThreadLocal.withInitial(ArrayDeque::new);
    /**
     * Проверка остановки прогона для потока узла: при взведённом флаге
     * ретраи прерываются — иначе отмена ждала бы весь бюджет повторов
     * (наблюдалось: cancel при мёртвой сети ждал 3×10-минутных таймаута).
     */
    /**
     * Проверка остановки для потока без прогона (REST, чат, индексация): ограничитель применяет к таким вызовам
     * предел ожидания очереди {@code app.gigachat.queue-max-wait-millis}; узел прогона ждёт очередь до своей остановки.
     */
    static final java.util.function.BooleanSupplier NO_RUN = () -> false;
    private static final ThreadLocal<java.util.function.BooleanSupplier> RUN_CANCEL_CHECK =
            ThreadLocal.withInitial(() -> NO_RUN);
    /** Сообщение о паузе повторов в журнал прогона (узел, чей поток ждёт GigaChat). */
    private static final ThreadLocal<Consumer<String>> RUN_WAIT_NOTICE =
            ThreadLocal.withInitial(() -> notice -> { });
    /**
     * Id вложения, которое {@link #chatCompletionWithFile} загрузило в хранилище само (до повторов) и само удалит
     * в finally: {@link #deleteUploadedMedia} такой id пропускает — иначе повтор запроса под фильтром GigaFilter
     * ({@code guardedCall}) шёл бы с уже удалённым файлом.
     */
    private static final ThreadLocal<String> OWN_ATTACHMENT = new ThreadLocal<>();
    /** Ошибка вызова, прерванного остановкой прогона (а не отказом GigaChat). */
    static final String CANCELLED = "Запрос к GigaChat прерван: прогон остановлен";
    /** Начало ошибки страховочного потолка вызова; распознаётся как таймаут ответа (не больше двух повторов). */
    static final String HARD_TIMEOUT = "Страховочный timeout LLM-вызова";

    @Autowired
    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel,
                          ObjectProvider<GigaChatApi> gigaChatApiProvider) {
        this.chatModel = chatModel;
        this.embeddingModel = embeddingModel;
        this.gigaChatApiProvider = gigaChatApiProvider;
    }

    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel) {
        this(chatModel, embeddingModel, null);
    }

    /**
     * Внедряет общий ограничитель одновременных запросов к GigaChat.
     *
     * @param limiter ограничитель (null — без ограничения)
     */
    @Autowired(required = false)
    public void setConcurrencyLimiter(GigaChatConcurrencyLimiter limiter) {
        this.concurrencyLimiter = limiter == null ? GigaChatConcurrencyLimiter.unlimited() : limiter;
    }

    /**
     * Внедряет распознавание отказа цензора GigaChat для узлов сценария (фразы из {@code app.gigachat.refusal-phrases}).
     *
     * @param detector распознавание отказа (null — только встроенные фразы)
     */
    @Autowired(required = false)
    public void setRefusalDetector(GigaChatRefusal detector) {
        this.refusalDetector = detector == null ? GigaChatRefusal.defaults() : detector;
    }

    /**
     * Внедряет проверку фильтром GigaFilter и решение о profanity_check ({@code app.gigachat.profanity-check.*}).
     *
     * @param guard проверка (null — выключена, запросы как раньше)
     */
    @Autowired(required = false)
    public void setProfanityGuard(GigaFilterGuard guard) {
        this.profanityGuard = guard == null ? GigaFilterGuard.disabled() : guard;
    }

    /**
     * Открывает кадр учёта токенов для текущего потока.
     */
    public static void beginUsageCapture() {
        USAGE_CAPTURE.get().push(new long[1]);
    }

    /** Ставит проверку остановки прогона для текущего потока (ретраи прерываются). */
    public static void setRunCancelCheck(java.util.function.BooleanSupplier check) {
        RUN_CANCEL_CHECK.set(check == null ? NO_RUN : check);
    }

    /** Снимает проверку остановки прогона с текущего потока. */
    public static void clearRunCancelCheck() {
        RUN_CANCEL_CHECK.remove();
    }

    /**
     * Ставит для текущего потока вывод сообщений о паузах повторов в журнал прогона.
     *
     * @param notice получатель текста паузы (null — без вывода)
     */
    public static void setRunWaitNotice(Consumer<String> notice) {
        RUN_WAIT_NOTICE.set(notice == null ? text -> { } : notice);
    }

    /** Снимает вывод сообщений о паузах с текущего потока. */
    public static void clearRunWaitNotice() {
        RUN_WAIT_NOTICE.remove();
    }

    /**
     * Закрывает кадр учёта и возвращает суммарные токены кадра.
     * Токены вливаются в родительский кадр (вложенные под-сценарии).
     *
     * @return суммарные total_tokens кадра или {@code null}, если токенов не было
     */
    public static Integer endUsageCapture() {
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            return null;
        }
        long total = stack.pop()[0];
        if (!stack.isEmpty()) {
            stack.peek()[0] += total;
        } else {
            USAGE_CAPTURE.remove();
        }
        return total > 0 ? (int) Math.min(total, Integer.MAX_VALUE) : null;
    }

    /**
     * Добавляет usage LLM-вызова в открытый кадр учёта (если он есть).
     */
    public static void addCapturedUsage(Map<String, Object> usage) {
        if (usage == null) {
            return;
        }
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            USAGE_CAPTURE.remove();
            return;
        }
        Object total = usage.get("total_tokens");
        if (total instanceof Number number && stack.peek() != null) {
            stack.peek()[0] += number.longValue();
        }
    }

    // -------------------------------------------------------------------------
    // Chat completion (synchronous)
    // -------------------------------------------------------------------------

    /**
     * Синхронное выполнение чат-запроса.
     *
     * @param messages список сообщений в формате {role, content}
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages) {
        log.info("[{}] chatCompletion, messages={}",
                CurrentUserHolder.getCurrentUser(), messages.size());
        return chatCompletion(messages, null, null);
    }

    /**
     * Синхронный чат-запрос с переопределением модели и температуры
     * (настройки конкретного узла сценария).
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletion, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        return chatCompletionResult(messages, model, temperature).text();
    }

    /**
     * Результат чат-запроса: текст ответа и статистика использования токенов.
     *
     * @param text  текст ответа ассистента
     * @param usage {prompt_tokens, completion_tokens, total_tokens} или {@code null},
     *              если провайдер не вернул статистику
     */
    public record ChatResult(String text, Map<String, Object> usage, int parts) {

        /**
         * Ответ одним запросом (частей — 1).
         *
         * @param text  текст ответа
         * @param usage статистика usage
         */
        public ChatResult(String text, Map<String, Object> usage) {
            this(text, usage, 1);
        }
    }

    /**
     * Синхронный чат-запрос с переопределением модели/температуры,
     * возвращающий текст ответа вместе со статистикой usage.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionResult(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionResult, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        return chatCompletionScreened(messages, model, temperature);
    }

    /**
     * Скрининг контекста документов фильтром GigaFilter один раз до вызова (заблокированные фрагменты — маркером,
     * уведомления в журнал прогона) и запрос с делением при необходимости. Деление при 422 «context too long» и при
     * отказе цензора получает уже очищенные сообщения: части собираются без границы, и проверка входа части иначе
     * находила бы заблокированный фрагмент и роняла узел. Пометки об удалённых фрагментах — в начале итогового ответа
     * (целого или собранного из частей).
     *
     * @param messages    сообщения запроса
     * @param model       модель GigaChat (null — по умолчанию)
     * @param temperature температура (null — по умолчанию)
     * @return ответ с пометками об удалённых фрагментах
     */
    private ChatResult chatCompletionScreened(List<Map<String, String>> messages, String model, Double temperature) {
        GigaFilterGuard.Screened screened = profanityGuard.screenContext(messages, filterLimited, RUN_WAIT_NOTICE.get());
        ChatResult result = chatCompletionSplitting(screened.messages(), model, temperature, 0);
        return screened.notes().isEmpty() ? result : new ChatResult(screened.prefixed(result.text()), result.usage());
    }

    /**
     * Обёртка над одиночным вызовом при 422 «context too long» (запрос больше
     * контекстного окна модели). Сообщение с границей {@link #SPLIT_BOUNDARY}
     * (промпт узла сценария: инструкция + контекст) делится по контексту — см.
     * {@link #chatCompletionSplittable}. Прочие сообщения (свободный текст) — по
     * прежнему правилу: самое длинное режется пополам по границе строки, ответы
     * половин конкатенируются. Глубина деления — до {@link #MAX_SPLIT_DEPTH}
     * (максимум 8 частей); дальше ошибка отдаётся как есть.
     * <p>
     * В потоке узла сценария (поставлена проверка остановки прогона) действует политика отказа цензора —
     * см. {@link #completionCheckingRefusal}: отказ сразу делит контекст сообщения с границей (бюджет вызовов
     * {@code app.gigachat.refusal-split-max-calls}), без границы — {@link GigaChatRefusedException}.
     */
    private ChatResult chatCompletionSplitting(List<Map<String, String>> messages, String model,
                                               Double temperature, int depth) {
        log.info("[{}] GigaChatClient.chatCompletionSplitting, messages={}, model={}, temperature={}, depth={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature, depth);
        int sizedBoundary = oversizedBoundary(messages, depth);
        if (sizedBoundary >= 0) {
            return splitBySize(messages, sizedBoundary, model, temperature);
        }
        try {
            return completionCheckingRefusal(messages, model, temperature);
        } catch (GigaChatRefusedException e) {
            return splitAfterRefusal(messages, model, temperature, e);
        } catch (RuntimeException e) {
            if (depth >= MAX_SPLIT_DEPTH || !isContextTooLong(e)) {
                throw e;
            }
            int boundary = boundaryMessage(messages);
            if (boundary >= 0) {
                return splitByBoundary(messages, boundary, model, temperature, e);
            }
            int idx = -1;
            int max = 0;
            for (int i = 0; i < messages.size(); i++) {
                int len = String.valueOf(messages.get(i).get("content")).length();
                if (len > max) {
                    max = len;
                    idx = i;
                }
            }
            if (idx < 0 || max < 20_000) {
                throw e;
            }
            String content = String.valueOf(messages.get(idx).get("content"));
            int cut = content.lastIndexOf('\n', content.length() / 2);
            if (cut < max / 4) {
                cut = content.length() / 2;
            }
            log.warn("[{}] GigaChat: запрос превышает контекст модели ({} символов) — "
                    + "делю сообщение на 2 части (глубина {})", CurrentUserHolder.getCurrentUser(), max, depth + 1);
            ChatResult r1 = callWithReplacedContent(messages, idx, content.substring(0, cut),
                    model, temperature, depth);
            ChatResult r2 = callWithReplacedContent(messages, idx, content.substring(cut),
                    model, temperature, depth);
            return new ChatResult(r1.text() + "\n\n" + r2.text(),
                    mergeUsage(r1.usage(), r2.usage()));
        }
    }

    /**
     * Сообщение с границей {@link #SPLIT_BOUNDARY}, чей контекст больше {@code split-part-chars}: такой запрос делится
     * заранее, не дожидаясь 422 (только на верхнем уровне деления).
     *
     * @param messages сообщения запроса
     * @param depth    глубина деления
     * @return индекс сообщения либо -1
     */
    private int oversizedBoundary(List<Map<String, String>> messages, int depth) {
        int boundary = depth == 0 ? boundaryMessage(messages) : -1;
        return boundary >= 0 && contextLength(messages.get(boundary)) > splitPartChars ? boundary : -1;
    }

    private ChatResult callWithReplacedContent(List<Map<String, String>> messages, int idx,
                                               String part, String model, Double temperature,
                                               int depth) {
        return chatCompletionSplitting(replaceContent(messages, idx, part), model, temperature, depth + 1);
    }

    /** Копия списка сообщений с заменённым текстом сообщения idx. */
    private static List<Map<String, String>> replaceContent(List<Map<String, String>> messages, int idx, String part) {
        List<Map<String, String>> copy = new ArrayList<>();
        for (int i = 0; i < messages.size(); i++) {
            copy.add(i == idx
                    ? Map.of("role", messages.get(i).getOrDefault("role", "user"), "content", part)
                    : messages.get(i));
        }
        return copy;
    }

    /**
     * Чат-запрос узла сценария с неделимой инструкцией и делимым контекстом.
     * <p>
     * Запрос уходит одним user-сообщением «инструкция + контекст»; между ними
     * стоит невидимая граница {@link #SPLIT_BOUNDARY} (та же, что ставит
     * {@code AbstractScenarioExecutor.buildPrompt}), перед отправкой модели
     * она вырезается. Если GigaChat отвечает 422 «context too long», делится
     * ТОЛЬКО контекст (по границам документов, страниц, абзацев — см.
     * {@link PromptSplitter#cutPoint}), а инструкция повторяется в каждой части;
     * глубина деления — до {@link #MAX_SPLIT_DEPTH} (максимум 8 частей). Ответы
     * частей помечаются «=== Часть k/N (запрос разделён из-за лимита контекста) ===»,
     * в журнал прогона уходит уведомление; при {@code mergeJsonArrays} (в сообщении —
     * {@link #MERGE_ARRAYS_HINT}) JSON-массивы частей объединяются в один (узлы с
     * контрактом json_массив). Прежнее деление сообщения пополам отправляло
     * вторую половину без инструкции — модель пересказывала документ, а строки терялись.
     *
     * @param instruction     инструкция узла (не делится)
     * @param context         документы и результаты предыдущих шагов (делится); пусто — обычный запрос
     * @param model           модель GigaChat (null — по умолчанию)
     * @param temperature     температура (null — по умолчанию)
     * @param mergeJsonArrays объединять JSON-массивы ответов частей
     * @return текст ответа и суммарный usage
     */
    public ChatResult chatCompletionSplittable(String instruction, String context, String model,
                                               Double temperature, boolean mergeJsonArrays) {
        log.info("[{}] GigaChatClient.chatCompletionSplittable, instruction={}, context={}, model={}",
                CurrentUserHolder.getCurrentUser(), instruction == null ? 0 : instruction.length(),
                context == null ? 0 : context.length(), model);
        return chatCompletionResult(List.of(Map.of("role", "user", "content",
                splittableContent(instruction, context, mergeJsonArrays))), model, temperature);
    }

    /**
     * Текст сообщения «инструкция + граница + контекст (+ подсказка слияния массивов)».
     *
     * @param instruction     инструкция (не делится)
     * @param context         контекст (делится); пусто — граница не ставится
     * @param mergeJsonArrays объединять JSON-массивы ответов частей при делении
     * @return текст сообщения с невидимыми маркерами
     */
    public static String splittableContent(String instruction, String context, boolean mergeJsonArrays) {
        String head = instruction == null ? "" : instruction;
        if (context == null || context.isEmpty()) {
            return head;
        }
        return head + SPLIT_BOUNDARY + "\n\n" + context + (mergeJsonArrays ? MERGE_ARRAYS_HINT : "");
    }

    /**
     * Число частей, из которых собран ответ (по заголовку {@link PromptSplitter#partHeader}); 1 — ответ одним запросом.
     *
     * @param text текст ответа
     * @return число частей
     */
    public static int partsOf(String text) {
        Matcher m = text == null ? null : PARTS_HEADER.matcher(text);
        if (m == null || !m.find()) {
            return 1;
        }
        return Integer.parseInt(m.group(1) != null ? m.group(1) : m.group(2));
    }

    /** Текст сообщения без служебных маркеров деления (то, что уходит модели). */
    public static String stripSplitMarkers(String content) {
        return content == null ? null : content.replace(SPLIT_BOUNDARY, "").replace(MERGE_ARRAYS_HINT, "");
    }

    /**
     * Индекс сообщения с границей деления либо -1.
     *
     * @param messages сообщения запроса
     * @return индекс первого сообщения с {@link #SPLIT_BOUNDARY} либо -1
     */
    static int boundaryMessage(List<Map<String, String>> messages) {
        for (int i = 0; i < messages.size(); i++) {
            if (String.valueOf(messages.get(i).get("content")).contains(SPLIT_BOUNDARY)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Деление контекста сообщения с границей на части; инструкция повторяется в каждой.
     * Причина — «context too long» либо отказ цензора ({@link GigaChatRefusedException}): при отказе уведомление
     * уходит в журнал прогона сразу, а вызовы ограничены бюджетом {@code app.gigachat.refusal-split-max-calls}
     * (первое деление — 2 вызова из бюджета). Смещения частей считаются в контексте после границы.
     */
    private ChatResult splitByBoundary(List<Map<String, String>> messages, int idx, String model,
                                       Double temperature, RuntimeException cause) {
        String content = String.valueOf(messages.get(idx).get("content"));
        boolean merge = content.endsWith(MERGE_ARRAYS_HINT);
        int boundary = content.indexOf(SPLIT_BOUNDARY);
        String instruction = content.substring(0, boundary).stripTrailing();
        String raw = content.substring(boundary + SPLIT_BOUNDARY.length(),
                merge ? content.length() - MERGE_ARRAYS_HINT.length() : content.length());
        String context = raw.strip();
        boolean refusal = cause instanceof GigaChatRefusedException;
        SplitRequest request = new SplitRequest(messages, idx, instruction, model, temperature,
                new SplitBudget(refusalSplitMaxCalls), new ArrayList<>());
        if (context.length() < MIN_SPLIT_CONTEXT || (refusal && !request.budget().reserve(2))) {
            throw cause;
        }
        // полный запрос уже отвергнут — сразу первое деление, без повторной отправки целиком
        log.warn("[{}] GigaChat: {} (контекст {} символов) — делю контекст на 2 части, инструкция повторяется",
                CurrentUserHolder.getCurrentUser(),
                refusal ? "модель отказалась отвечать (ограничение темы)" : "запрос превышает контекст модели",
                context.length());
        if (refusal) {
            RUN_WAIT_NOTICE.get().accept(REFUSAL_NOTICE + " — документ делится на части (не больше "
                    + refusalSplitMaxCalls + " запросов к модели), отклонённые фрагменты будут помечены");
        }
        divideContext(request, context, raw.length() - raw.stripLeading().length(), 0);
        divideRefusedInBreadth(request);
        return assembleParts(request.parts(), merge, refusal);
    }

    /**
     * Вызов «инструкция + часть контекста»; при «context too long» контекст делится пополам, части — рекурсивно.
     * Отказ цензора на части: часть остаётся среди ответов отклонённой; делить ли её глубже, решает деление в ширину
     * ({@link #divideRefusedInBreadth}), а часть, которую делить нельзя (глубина, длина), помечается сразу.
     *
     * @param request параметры деления запроса
     * @param context часть контекста
     * @param offset  смещение части в контексте сообщения
     * @param depth   глубина деления части
     */
    private void callSplitting(SplitRequest request, String context, int offset, int depth) {
        String content = context.isEmpty() ? request.instruction() : request.instruction() + "\n\n" + context;
        boolean divisible = divisible(depth, context);
        try {
            ChatResult result = completionCheckingRefusal(replaceContent(request.messages(), request.idx(), content),
                    request.model(), request.temperature());
            request.parts().add(new Part(result, null, offset, context, depth));
        } catch (GigaChatRefusedException e) {
            Part part = new Part(null, e.getRefusal(), offset, context, depth);
            request.parts().add(part);
            if (!divisible) {
                markRefused(part);
            }
        } catch (RuntimeException e) {
            if (!divisible || !isContextTooLong(e)) {
                throw e;
            }
            log.warn("[{}] GigaChat: запрос превышает контекст модели (контекст {} символов) — "
                    + "делю контекст на 2 части (глубина {}), инструкция повторяется", CurrentUserHolder.getCurrentUser(),
                    context.length(), depth + 1);
            divideContext(request, context, offset, depth);
        }
    }

    /**
     * Деление отклонённых моделью частей в ширину: сначала все отклонённые части уровня (по порядку контекста), затем
     * следующий уровень, пока позволяют глубина, длина и бюджет вызовов. При делении в глубину бюджет уходил на первую
     * отклонённую часть, а остальные отклонённые половины помечались целиком (2–3 триггера в разных местах документа —
     * помечено 63–87 % текста). Если начиная со второго уровня не принята ни одна часть, отказ сплошной (например, на
     * инструкцию, которая повторяется в каждой части): деление прекращается, части помечаются.
     *
     * @param request параметры деления запроса (накопитель частей по порядку контекста)
     */
    private void divideRefusedInBreadth(SplitRequest request) {
        for (int depth = 1; depth < MAX_SPLIT_DEPTH; depth++) {
            List<Part> level = refusedDivisible(request.parts(), depth);
            boolean solid = depth >= 2 && !level.isEmpty() && noneAccepted(request.parts());
            if (solid) {
                log.warn("[{}] GigaChat: модель отказала во всех частях после {} уровней деления — деление прекращено",
                        CurrentUserHolder.getCurrentUser(), depth);
            }
            for (Part part : level) {
                divideOrMark(request, part, solid);
            }
        }
    }

    /**
     * Отклонённая часть уровня: деление на 2 половины в пределах бюджета вызовов (половины встают на место части) либо
     * пометка; уведомление в журнал прогона — сразу.
     *
     * @param request параметры деления запроса
     * @param part    отклонённая часть, которую можно делить
     * @param stop    деление прекращено (сплошной отказ)
     */
    private void divideOrMark(SplitRequest request, Part part, boolean stop) {
        if (stop || !request.budget().reserve(2)) {
            markRefused(part);
            return;
        }
        log.warn("[{}] GigaChat отказался обработать часть контекста ({} символов) — делю её на 2 части (глубина {})",
                CurrentUserHolder.getCurrentUser(), part.context().length(), part.depth() + 1);
        RUN_WAIT_NOTICE.get().accept("⚠ фрагмент " + span(part) + " отклонён моделью — делю его на 2 части");
        SplitRequest halves = request.withParts(new ArrayList<>());
        divideContext(halves, part.context(), part.offset(), part.depth());
        int at = request.parts().indexOf(part);
        request.parts().remove(at);
        request.parts().addAll(at, halves.parts());
    }

    /** Отклонённая часть помечается в ответе: лог и уведомление в журнал прогона. */
    private static void markRefused(Part part) {
        log.warn("[{}] GigaChat отказался обработать часть контекста ({} символов) — часть помечена отклонённой",
                CurrentUserHolder.getCurrentUser(), part.context().length());
        RUN_WAIT_NOTICE.get().accept("⚠ фрагмент " + span(part) + " отклонён моделью (ограничение темы GigaChat) — "
                + "помечен в ответе, остальные части обрабатываются");
    }

    /** Знаки части в контексте сообщения: «(знаки a–b контекста)». */
    private static String span(Part part) {
        return "(знаки " + (part.offset() + 1) + "–" + (part.offset() + part.context().length()) + " контекста)";
    }

    /** Часть можно делить дальше: глубина меньше {@link #MAX_SPLIT_DEPTH} и длина не меньше {@link #MIN_SPLIT_CONTEXT}. */
    private static boolean divisible(int depth, String context) {
        return depth < MAX_SPLIT_DEPTH && context.length() >= MIN_SPLIT_CONTEXT;
    }

    /** Отклонённые части уровня, которые можно делить, по порядку контекста. */
    private static List<Part> refusedDivisible(List<Part> parts, int depth) {
        List<Part> level = new ArrayList<>();
        for (Part part : parts) {
            if (part.result() == null && part.depth() == depth && divisible(depth, part.context())) {
                level.add(part);
            }
        }
        return level;
    }

    /** Ни одна часть не принята моделью. */
    private static boolean noneAccepted(List<Part> parts) {
        for (Part part : parts) {
            if (part.result() != null) {
                return false;
            }
        }
        return true;
    }

    /** Деление контекста пополам по {@link PromptSplitter#cutPoint}; обе половины — {@link #callSplitting} глубиной depth + 1. */
    private void divideContext(SplitRequest request, String context, int offset, int depth) {
        int cut = PromptSplitter.cutPoint(context);
        String right = context.substring(cut);
        String rightPart = right.stripLeading();
        callSplitting(request, context.substring(0, cut).stripTrailing(), offset, depth + 1);
        callSplitting(request, rightPart, offset + cut + right.length() - rightPart.length(), depth + 1);
    }

    /**
     * Ответы частей: заголовки «Часть k/N» либо объединённый JSON-массив; итоговое уведомление в журнал прогона
     * (об отклонённых частях уведомления ушли по ходу деления). Отклонённые моделью части заменяются маркером
     * {@link GigaChatRefusal#partMarker} со знаками контекста и началом фрагмента; отклонены все —
     * {@link GigaChatRefusedException}.
     *
     * @param parts           ответы частей по порядку
     * @param mergeJsonArrays объединять JSON-массивы принятых частей
     * @param refusal         деление из-за отказа цензора (иначе — из-за лимита контекста)
     * @return собранный ответ и суммарный usage принятых частей
     */
    private static ChatResult assembleParts(List<Part> parts, boolean mergeJsonArrays, boolean refusal) {
        return assembleParts(parts, mergeJsonArrays, refusal, true);
    }

    /**
     * То же, с выбором уведомления: при упреждающем делении по размеру уведомление уже ушло до запросов.
     *
     * @param parts           ответы частей по порядку
     * @param mergeJsonArrays объединять JSON-массивы принятых частей
     * @param refusal         деление из-за отказа цензора
     * @param notify          отправлять итоговое уведомление в журнал прогона
     * @return собранный ответ, суммарный usage и число частей
     */
    private static ChatResult assembleParts(List<Part> parts, boolean mergeJsonArrays, boolean refusal, boolean notify) {
        if (parts.size() == 1 && parts.get(0).result() != null) {
            return parts.get(0).result();
        }
        int total = parts.size();
        Map<String, Object> usage = null;
        List<String> texts = new ArrayList<>();
        String refused = null;
        for (Part part : parts) {
            if (part.result() == null) {
                refused = part.refusal();
            } else {
                usage = mergeUsage(usage, part.result().usage());
                texts.add(part.result().text());
            }
        }
        // слияние массивов — до уведомления: раньше журнал сообщал «объединены» по флагу, даже если слияние не состоялось
        PromptSplitter.MergedArrays merged = mergeJsonArrays && !texts.isEmpty() ? mergeArrays(parts) : null;
        notifyParts(total, texts.size(), refusal, notify, mergeJsonArrays, merged);
        if (texts.isEmpty()) {
            throw new GigaChatRefusedException(refused);
        }
        return new ChatResult(joinParts(parts, merged, refusal), usage, total);
    }

    /**
     * Слияние JSON-массивов ответов частей.
     *
     * @param parts ответы частей по порядку (у отклонённой части ответа нет)
     * @return результат слияния либо {@code null}, если массива нет ни в одной части
     */
    private static PromptSplitter.MergedArrays mergeArrays(List<Part> parts) {
        return PromptSplitter.mergeJsonArrays(parts.stream().map(p -> p.result() == null ? null : p.result().text()).toList());
    }

    /**
     * Уведомление в журнал прогона о сборке ответа из частей: итог деления и итог слияния JSON-массивов. При упреждающем
     * делении уведомление о делении ушло до запросов — тогда сообщается только о неполном слиянии.
     *
     * @param total           число частей
     * @param accepted        число принятых частей
     * @param refusal         деление из-за отказа цензора
     * @param notify          отправлять итоговое уведомление о делении
     * @param mergeJsonArrays слияние запрошено (узел с контрактом json_массив)
     * @param merged          результат слияния ({@code null} — массива нет ни в одной части)
     */
    private static void notifyParts(int total, int accepted, boolean refusal, boolean notify, boolean mergeJsonArrays,
                                    PromptSplitter.MergedArrays merged) {
        String mergeNote = mergeNote(mergeJsonArrays, merged);
        if (notify) {
            RUN_WAIT_NOTICE.get().accept(refusal
                    ? REFUSAL_NOTICE + " — ответ собран из " + total + " частей: принято " + accepted
                            + ", отклонено " + (total - accepted)
                    : "запрос превышает контекст модели — разделён на " + total
                            + " частей, инструкция повторена в каждой; ответы помечены «Часть k/" + total + "»"
                            + (mergeNote.isEmpty() ? "" : ", " + mergeNote));
        } else if (mergeJsonArrays && (merged == null || !merged.withoutArray().isEmpty())) {
            // упреждающее деление уведомило до запросов — о неполном слиянии сообщается отдельно
            RUN_WAIT_NOTICE.get().accept("⚠ " + mergeNote);
        }
    }

    /**
     * Итог слияния JSON-массивов частей для уведомления в журнал прогона.
     *
     * @param mergeJsonArrays слияние запрошено (узел с контрактом json_массив)
     * @param merged          результат слияния ({@code null} — массива нет ни в одной части)
     * @return текст итога либо пустая строка, если слияние не запрашивалось
     */
    private static String mergeNote(boolean mergeJsonArrays, PromptSplitter.MergedArrays merged) {
        if (!mergeJsonArrays) {
            return "";
        }
        if (merged == null) {
            return "JSON-массивы частей НЕ объединены: массива нет ни в одной части";
        }
        if (merged.withoutArray().isEmpty()) {
            return "JSON-массивы частей объединены";
        }
        return "JSON-массивы частей объединены; в частях " + merged.withoutArray().stream().map(String::valueOf)
                .collect(Collectors.joining(", ")) + " массива нет — их ответ в примечании перед массивом";
    }

    /**
     * Текст ответа из частей: объединённый JSON-массив принятых частей (маркеры отклонённых и примечания с ответами
     * частей без массива — перед массивом) либо части под заголовками «Часть k/N» (отклонённая — маркер вместо
     * ответа).
     */
    private static String joinParts(List<Part> parts, PromptSplitter.MergedArrays merged, boolean refusal) {
        int total = parts.size();
        String reason = refusal ? PromptSplitter.REFUSAL_REASON : PromptSplitter.CONTEXT_REASON;
        StringBuilder sb = new StringBuilder();
        if (merged != null) {
            sb.append("=== Ответ собран из ").append(total).append(" частей (").append(reason)
                    .append("), JSON-массивы частей объединены ===\n");
            for (int i = 0; i < total; i++) {
                Part part = parts.get(i);
                if (part.result() == null) {
                    sb.append(refusedMarker(part, i + 1, total)).append('\n');
                } else if (merged.withoutArray().contains(i + 1)) {
                    sb.append("Примечание — в ответе части ").append(i + 1).append('/').append(total)
                            .append(" JSON-массива нет, ответ части:\n").append(part.result().text().strip()).append('\n');
                }
            }
            return sb.append(merged.json()).toString();
        }
        for (int i = 0; i < total; i++) {
            ChatResult result = parts.get(i).result();
            sb.append(i == 0 ? "" : "\n\n").append(PromptSplitter.partHeader(i + 1, total, reason)).append('\n')
                    .append(result == null ? refusedMarker(parts.get(i), i + 1, total) : result.text());
        }
        return sb.toString();
    }

    /** Маркер отклонённой части: номер, знаки контекста, начало фрагмента. */
    private static String refusedMarker(Part part, int number, int total) {
        return GigaChatRefusal.partMarker(number, total, part.offset() + 1, part.offset() + part.context().length(),
                part.context());
    }

    /**
     * Ответ части при делении контекста: принятый ответ либо текст отказа модели (часть отклонена).
     *
     * @param result  ответ части ({@code null}, если часть отклонена)
     * @param refusal текст отказа ({@code null}, если часть принята)
     * @param offset  смещение части в контексте сообщения
     * @param context текст части контекста
     * @param depth   глубина деления части (половины полного контекста — 1)
     */
    private record Part(ChatResult result, String refusal, int offset, String context, int depth) {
    }

    /**
     * Параметры деления контекста одного запроса.
     *
     * @param messages    сообщения исходного запроса
     * @param idx         индекс сообщения с границей
     * @param instruction инструкция (повторяется в каждой части)
     * @param model       модель GigaChat (null — по умолчанию)
     * @param temperature температура (null — по умолчанию)
     * @param budget      бюджет вызовов на деление из-за отказа цензора
     * @param parts       ответы частей по порядку (накопитель)
     */
    private record SplitRequest(List<Map<String, String>> messages, int idx, String instruction, String model,
                                Double temperature, SplitBudget budget, List<Part> parts) {

        /** Те же параметры и бюджет с другим накопителем частей (половины отклонённой части). */
        SplitRequest withParts(List<Part> collected) {
            return new SplitRequest(messages, idx, instruction, model, temperature, budget, collected);
        }
    }

    /** Бюджет вызовов модели на деление из-за отказа цензора; первый полный запрос уже израсходовал один вызов. */
    private static final class SplitBudget {

        private final int max;
        private int used = 1;

        SplitBudget(int max) {
            this.max = max;
        }

        /** Резервирует вызовы, если бюджет их покрывает. */
        boolean reserve(int calls) {
            if (used + calls > max) {
                return false;
            }
            used += calls;
            return true;
        }
    }

    /**
     * Ответ одиночного вызова и признак отказа цензора.
     *
     * @param result  ответ модели (при отказе — текст отказа)
     * @param refused модель отказалась: finish_reason цензора либо фраза отказа
     */
    private record Completion(ChatResult result, boolean refused) {
    }

    /**
     * Одиночный вызов с политикой отказа цензора для узла сценария (поток, где движок поставил проверку
     * остановки прогона {@link #setRunCancelCheck}): отказ — finish_reason цензора
     * ({@link GigaChatRefusal#isBlacklisted}) либо фраза отказа ({@link GigaChatRefusal#isRefusal}) —
     * {@link GigaChatRefusedException}, дальше деление документа ({@link #splitAfterRefusal}). Повтора «с безопасной
     * рамкой» нет: проба 16.09.2026 — отказ приходит за 0,8 с (классификатор входа до генерации), рамка и снятие роли
     * его не снимали, повтор только тратил вызов. Вне прогона (чат {@code ChatService}, REST, БЗ, память агента:
     * проверки остановки нет) ответ возвращается как есть — там отказ доходит до пользователя; в лог — предупреждение.
     *
     * @param messages    сообщения запроса
     * @param model       модель GigaChat (null — по умолчанию)
     * @param temperature температура (null — по умолчанию)
     * @return ответ модели (не отказ, либо вне прогона — любой)
     * @throws GigaChatRefusedException если модель отказала в потоке узла сценария
     */
    private ChatResult completionCheckingRefusal(List<Map<String, String>> messages, String model, Double temperature) {
        Completion completion = completionOnce(messages, model, temperature);
        if (!completion.refused()) {
            return completion.result();
        }
        if (runCancelCheck() == null) {
            log.warn("[{}] GigaChat отказался отвечать (ограничение темы) вне прогона — ответ возвращён как есть",
                    CurrentUserHolder.getCurrentUser());
            return completion.result();
        }
        throw new GigaChatRefusedException(completion.result().text());
    }

    /** Длина контекста сообщения с границей (текст после {@link #SPLIT_BOUNDARY} без подсказки слияния). */
    private static int contextLength(Map<String, String> message) {
        String content = String.valueOf(message.get("content"));
        int boundary = content.indexOf(SPLIT_BOUNDARY);
        if (boundary < 0) {
            return 0;
        }
        int end = content.endsWith(MERGE_ARRAYS_HINT) ? content.length() - MERGE_ARRAYS_HINT.length() : content.length();
        return end - boundary - SPLIT_BOUNDARY.length();
    }

    /**
     * Упреждающее деление контекста больше предела {@code app.gigachat.split-part-chars} (corp21): раньше исполнитель
     * узла обрезал документы до {@code app.chat.document-char-limit} и хвост терялся молча. Теперь контекст уходит
     * целиком, а здесь режется на части не длиннее предела по границам документов/страниц/абзацев с перекрытием
     * {@code app.gigachat.split-overlap-chars}; инструкция повторяется в каждой части, ответы собираются как при
     * делении по «context too long» (часть, всё же не влезшая в контекст модели, делится дальше пополам).
     *
     * @param messages    сообщения запроса
     * @param idx         индекс сообщения с границей
     * @param model       модель GigaChat (null — по умолчанию)
     * @param temperature температура (null — по умолчанию)
     * @return собранный ответ частей
     */
    private ChatResult splitBySize(List<Map<String, String>> messages, int idx, String model, Double temperature) {
        String content = String.valueOf(messages.get(idx).get("content"));
        boolean merge = content.endsWith(MERGE_ARRAYS_HINT);
        int boundary = content.indexOf(SPLIT_BOUNDARY);
        String instruction = content.substring(0, boundary).stripTrailing();
        String context = content.substring(boundary + SPLIT_BOUNDARY.length(),
                merge ? content.length() - MERGE_ARRAYS_HINT.length() : content.length()).strip();
        List<int[]> ranges = PromptSplitter.sizedRanges(context, splitPartChars, splitOverlapChars);
        log.warn("[{}] GigaChat: контекст {} символов больше предела {} — делю на {} частей с перекрытием {}, инструкция повторяется",
                CurrentUserHolder.getCurrentUser(), context.length(), splitPartChars, ranges.size(), splitOverlapChars);
        RUN_WAIT_NOTICE.get().accept("документы больше предела " + splitPartChars + " символов — обработаны в "
                + ranges.size() + " частях с перекрытием " + splitOverlapChars + " знаков, инструкция повторена в каждой; "
                + "ответы помечены «Часть k/" + ranges.size() + "»" + (merge ? ", JSON-массивы частей объединены" : ""));
        SplitRequest request = new SplitRequest(messages, idx, instruction, model, temperature,
                new SplitBudget(refusalSplitMaxCalls), new ArrayList<>());
        for (int[] range : ranges) {
            callSplitting(request, context.substring(range[0], range[1]).strip(), range[0], 1);
        }
        return assembleParts(request.parts(), merge, false, false);
    }

    /**
     * Отказ модели: сообщение с границей {@link #SPLIT_BOUNDARY} делится по контексту, без границы деление
     * невозможно — ошибка узла.
     */
    private ChatResult splitAfterRefusal(List<Map<String, String>> messages, String model, Double temperature,
                                         GigaChatRefusedException refusal) {
        int boundary = boundaryMessage(messages);
        if (boundary < 0) {
            throw refusal;
        }
        return splitByBoundary(messages, boundary, model, temperature, refusal);
    }

    /**
     * Запрос больше контекстного окна модели: 422 «context too long» либо 413 «Tokens limit exceeded»
     * (тот же случай, другим кодом) — контекст делится с повтором инструкции.
     *
     * @param e исключение вызова
     * @return {@code true}, если ошибка в цепочке причин — превышение контекста
     */
    static boolean isContextTooLong(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            String msg = String.valueOf(t.getMessage()).toLowerCase(Locale.ROOT);
            if (msg.contains("context too long")
                    || (msg.contains("422") && msg.contains("invalid params"))
                    || (msg.contains("413") && msg.contains("tokens limit"))) {
                return true;
            }
        }
        return false;
    }

    static Map<String, Object> mergeUsage(Map<String, Object> a, Map<String, Object> b) {
        if (a == null || a.isEmpty()) {
            return b;
        }
        if (b == null || b.isEmpty()) {
            return a;
        }
        Map<String, Object> sum = new HashMap<>();
        for (var e : a.entrySet()) {
            long va = e.getValue() instanceof Number n ? n.longValue() : 0;
            long vb = b.get(e.getKey()) instanceof Number n ? n.longValue() : 0;
            sum.put(e.getKey(), va + vb);
        }
        return sum;
    }

    /**
     * Одиночный запрос: вызов (контекст документов уже прошёл скрининг фильтром GigaFilter —
     * {@link #chatCompletionScreened}), распознавание отказа цензора (finish_reason либо фраза), дочитывание
     * оборванного ответа.
     *
     * @param messages    сообщения запроса
     * @param model       модель GigaChat (null — по умолчанию)
     * @param temperature температура (null — по умолчанию)
     * @return ответ и признак отказа (при отказе — текст отказа без дочитывания)
     */
    private Completion completionOnce(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionOnce, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        Prompt prompt;
        if (model == null && temperature == null) {
            prompt = toPrompt(messages);
        } else {
            var options = GigaChatOptions.builder();
            if (model != null) {
                options.model(model);
            }
            if (temperature != null) {
                options.temperature(temperature);
            }
            prompt = new Prompt(toPrompt(messages).getInstructions(), options.build());
        }
        ChatResponse response = callWithRetry(prompt);
        if (response == null) {
            throw new GigaChatException("GigaChat вернул пустой ответ");
        }
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        if (isRefused(response)) {
            return new Completion(new ChatResult(responseText(response), usage), true);
        }
        return new Completion(continueIfTruncated(prompt, response, usage), false);
    }

    /**
     * Отказ цензора: finish_reason цензора в метаданных (основной признак, в лог — с x-request-id) либо фраза отказа.
     *
     * @param response ответ модели
     * @return {@code true}, если модель отказалась отвечать
     */
    private boolean isRefused(ChatResponse response) {
        if (GigaChatRefusal.isBlacklisted(response)) {
            log.warn("[{}] GigaChat: отказ цензора (finish_reason={}, x-request-id={})", CurrentUserHolder.getCurrentUser(),
                    response.getResult().getMetadata().getFinishReason(),
                    response.getMetadata() == null ? null : response.getMetadata().getId());
            return true;
        }
        return refusalDetector.isRefusal(responseText(response));
    }

    /** Текст ответа модели либо {@code null}, если ответа нет. */
    private static String responseText(ChatResponse response) {
        if (response == null || response.getResult() == null || response.getResult().getOutput() == null) {
            return null;
        }
        return response.getResult().getOutput().getText();
    }

    /**
     * Дочитывание ответа, оборванного по лимиту длины выхода модели
     * (finish_reason = length): в историю добавляются уже полученный текст и
     * просьба продолжить с места обрыва, куски склеиваются. До
     * {@link #MAX_CONTINUATIONS} дозапросов. Без этого длинные структурные
     * ответы (JSON на 8 лотов, таблицы критериев) приходили без хвоста, и
     * следующий кодовый узел падал «во входе не найден JSON-массив».
     */
    private ChatResult continueIfTruncated(Prompt prompt, ChatResponse first, Map<String, Object> firstUsage) {
        return continueText(prompt.getInstructions(), prompt.getOptions(), first, firstUsage);
    }

    /**
     * Общее дочитывание для обычного запроса и финального ответа агента: история
     * дополняется полученным текстом и просьбой продолжить. Если модель вместо
     * продолжения запрашивает инструменты, дочитывание прекращается. Ответ,
     * оставшийся усечённым после {@link #MAX_CONTINUATIONS} дозапросов, получает
     * маркер {@link #TRUNCATED_MARKER} и уведомление в журнал прогона — раньше
     * хвост терялся молча.
     * <p>
     * Перед каждым дочитыванием (и после последнего) хвост усечённого ответа проверяется на зацикливание
     * ({@link #cutRepeatLoop}): зациклившийся ответ не дочитывается, повтор обрезается, ставится
     * {@link #LOOP_MARKER}. Субботин, s4 (16.09.2026): «10 шт.; » до лимита, 4 дочитывания, 14,5 мин и 186 тыс. токенов.
     *
     * @param messages   история запроса
     * @param options    опции модели (в т.ч. инструменты агента)
     * @param first      первый ответ
     * @param firstUsage usage первого ответа
     * @return склеенный текст и суммарный usage
     */
    @SuppressWarnings("java:S135") // break по трём независимым причинам остановки дочитывания: флаг усложнил бы чтение
    private ChatResult continueText(List<Message> messages, ChatOptions options, ChatResponse first,
                                    Map<String, Object> firstUsage) {
        StringBuilder text = new StringBuilder(first.getResult().getOutput().getText());
        Map<String, Object> usage = firstUsage;
        ChatResponse response = first;
        boolean refusedTail = false;
        boolean looped = false;
        boolean contextFull = false;
        for (int round = 1; isTruncated(response) && round <= MAX_CONTINUATIONS; round++) {
            looped = cutRepeatLoop(text);
            if (looped) {
                break;
            }
            log.warn("[{}] GigaChat: ответ оборван по лимиту длины ({} символов) — дочитываю, раунд {}",
                    CurrentUserHolder.getCurrentUser(), text.length(), round);
            List<Message> history = new ArrayList<>(messages);
            history.add(new AssistantMessage(text.toString()));
            history.add(new UserMessage(CONTINUE_PROMPT));
            Continuation next = continuation(history, options, text.length());
            contextFull = next.contextFull();
            if (contextFull) {
                break;
            }
            response = next.response();
            if (response == null || response.getResult() == null || response.getResult().getOutput() == null) {
                break;
            }
            Map<String, Object> part = extractUsage(response);
            addCapturedUsage(part);
            usage = mergeUsage(usage, part);
            // отказ цензора на дочитывании: текст отказа к ответу не приклеивается, конец ответа помечается
            refusedTail = GigaChatRefusal.isBlacklisted(response);
            if (refusedTail || response.getResult().getOutput().hasToolCalls()) {
                log.warn("[{}] GigaChat: {} — дочитывание прекращено", CurrentUserHolder.getCurrentUser(),
                        refusedTail ? "дочитывание отклонено цензором (finish_reason=blacklist)" : "при дочитывании модель запросила инструменты");
                break;
            }
            text.append(response.getResult().getOutput().getText());
        }
        boolean truncated = !looped && isTruncated(response);
        if (truncated && cutRepeatLoop(text)) {
            truncated = false;
        }
        markUnfinished(text, refusedTail, truncated, contextFull);
        return new ChatResult(text.toString(), usage);
    }

    /**
     * Ответ дозапроса «продолжи» либо признак, что история с накопленным текстом больше окна модели.
     *
     * @param response    ответ модели ({@code null}, если контекст заполнен)
     * @param contextFull дозапрос отвергнут как «context too long»
     */
    private record Continuation(ChatResponse response, boolean contextFull) {
    }

    /**
     * Дозапрос «продолжи»: история растёт на весь уже полученный ответ, и для части, полученной делением почти под
     * окно, дозапрос отвергается «context too long». Дочитывание тогда прекращается, а полученный текст сохраняется
     * (получит маркер усечения) — раньше исключение уходило в деление контекста, часть делилась заново, и почти
     * полный ответ выбрасывался.
     *
     * @param history   история с накопленным текстом и просьбой продолжить
     * @param options   опции модели
     * @param textChars длина накопленного ответа (для лога)
     * @return ответ либо признак заполненного контекста
     */
    private Continuation continuation(List<Message> history, ChatOptions options, int textChars) {
        try {
            return new Continuation(callWithRetry(new Prompt(history, options)), false);
        } catch (RuntimeException e) {
            if (!isContextTooLong(e)) {
                throw e;
            }
            log.warn("[{}] GigaChat: дозапрос продолжения больше окна модели (накоплено {} символов ответа) — "
                    + "дочитывание прекращено, полученный текст сохранён", CurrentUserHolder.getCurrentUser(), textChars);
            return new Continuation(null, true);
        }
    }

    /**
     * Маркер {@link #TRUNCATED_MARKER} и уведомление в журнал прогона, если конец ответа отсутствует: дочитывание
     * отклонено цензором, невозможно из-за заполненного контекста или ответ остался усечённым после всех дозапросов.
     *
     * @param text        склеенный ответ
     * @param refusedTail дочитывание отклонено цензором
     * @param truncated   ответ остался усечённым по лимиту длины
     * @param contextFull дозапрос отвергнут как «context too long»
     */
    private static void markUnfinished(StringBuilder text, boolean refusedTail, boolean truncated, boolean contextFull) {
        if (!refusedTail && !truncated && !contextFull) {
            return;
        }
        String notice;
        if (refusedTail) {
            notice = "⚠ дочитывание ответа отклонено цензором GigaChat — конец ответа отсутствует, поставлен маркер";
        } else if (contextFull) {
            notice = "⚠ дочитывание ответа невозможно: контекст модели заполнен (422) — конец ответа отсутствует, "
                    + "полученный текст сохранён, поставлен маркер";
        } else {
            notice = "ответ модели усечён по лимиту длины после " + MAX_CONTINUATIONS
                    + " дозапросов — конец ответа отсутствует, поставлен маркер";
        }
        RUN_WAIT_NOTICE.get().accept(notice);
        text.append('\n').append(TRUNCATED_MARKER);
    }

    /**
     * Зацикливание в хвосте усечённого ответа ({@link #repeatLoop}): повтор обрезается до
     * {@link #LOOP_KEEP_REPEATS} первых целых вхождений ({@link #wordShift}), ставится {@link #LOOP_MARKER},
     * в журнал прогона — уведомление. Дочитывать такой ответ бессмысленно: модель продолжает тот же повтор.
     *
     * @param text накопленный ответ (обрезается на месте)
     * @return {@code true} — повтор найден, ответ обрезан и помечен
     */
    static boolean cutRepeatLoop(StringBuilder text) {
        RepeatLoop loop = repeatLoop(text);
        if (loop == null) {
            return false;
        }
        String raw = text.substring(loop.start(), loop.start() + loop.unit());
        int shift = wordShift(raw);
        String unit = (raw.substring(shift) + raw.substring(0, shift)).replaceAll("\\s+", " ").strip();
        log.warn("[{}] GigaChat: ответ зациклился — кусок «{}» повторён {} раз подряд ({} символов), дочитывание прекращено",
                CurrentUserHolder.getCurrentUser(), unit, loop.repeats(), text.length());
        RUN_WAIT_NOTICE.get().accept("⚠ ответ модели зациклился: «" + unit + "» повторено " + loop.repeats()
                + " раз подряд — дочитывание прекращено, повтор обрезан, поставлен маркер");
        text.setLength(loop.start() + shift + LOOP_KEEP_REPEATS * loop.unit());
        text.append('\n').append(LOOP_MARKER);
        return true;
    }

    /**
     * Вырожденный повтор в хвосте ответа: кусок {@link #LOOP_MIN_UNIT}–{@link #LOOP_MAX_UNIT} символов (с буквой или
     * цифрой — заполнители «____» и отступы пробелами не в счёт) повторён подряд не меньше {@link #LOOP_MIN_REPEATS}
     * раз до самого конца ответа в последних {@link #LOOP_TAIL_CHARS} символах. Ищется кратчайший такой кусок.
     *
     * @param text ответ
     * @return повтор (начало серии — первое вхождение во всём ответе) либо {@code null}
     */
    static RepeatLoop repeatLoop(CharSequence text) {
        int length = text.length();
        int from = Math.max(0, length - LOOP_TAIL_CHARS);
        for (int unit = LOOP_MIN_UNIT; unit <= LOOP_MAX_UNIT; unit++) {
            int start = periodicTailStart(text, from, unit);
            if ((length - start) / unit >= LOOP_MIN_REPEATS && hasLetterOrDigit(text, start, unit)) {
                int first = periodicTailStart(text, 0, unit);
                return new RepeatLoop(first, unit, (length - first) / unit);
            }
        }
        return null;
    }

    /**
     * Начало серии с периодом {@code unit}, доходящей до конца текста: {@code text[i] == text[i + unit]} для всех
     * позиций серии; поиск назад не дальше {@code from}.
     */
    private static int periodicTailStart(CharSequence text, int from, int unit) {
        int i = text.length() - unit - 1;
        while (i >= from && text.charAt(i) == text.charAt(i + unit)) {
            i--;
        }
        return i + 1;
    }

    /**
     * Сдвиг начала серии повторов к началу «слова» — сразу за последним пробельным символом куска: серия «10 шт.; »
     * находится с середины («0 шт.; 1»), а обрезка и уведомление должны идти по целым вхождениям.
     *
     * @param unit кусок повтора с начала серии
     * @return сдвиг (0 — кусок без пробелов или уже кончается пробелом)
     */
    private static int wordShift(String unit) {
        int shift = unit.length();
        while (shift > 0 && !Character.isWhitespace(unit.charAt(shift - 1))) {
            shift--;
        }
        return shift == unit.length() ? 0 : shift;
    }

    private static boolean hasLetterOrDigit(CharSequence text, int start, int unit) {
        for (int i = start; i < start + unit; i++) {
            if (Character.isLetterOrDigit(text.charAt(i))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Зацикливание хвоста ответа.
     *
     * @param start   начало серии повторов в ответе
     * @param unit    длина повторяющегося куска
     * @param repeats сколько раз кусок повторён до конца ответа
     */
    record RepeatLoop(int start, int unit, int repeats) {
    }

    /** Ответ оборван моделью по лимиту выходных токенов. */
    static boolean isTruncated(ChatResponse response) {
        if (response == null || response.getResult() == null || response.getResult().getMetadata() == null) {
            return false;
        }
        String reason = response.getResult().getMetadata().getFinishReason();
        return "length".equalsIgnoreCase(reason) || "max_tokens".equalsIgnoreCase(reason);
    }

    /**
     * Агентский чат-запрос с инструментами (function calling GigaChat).
     * <p>
     * Модель сама решает, какие инструменты вызвать; цикл
     * «модель → инструмент → модель» выполняет {@code GigaChatModel}
     * (internal tool execution), финальный текст возвращается одним ответом.
     * Ограничение числа обращений — на стороне самих инструментов.
     * <p>
     * Контекст модели: перед каждым раундом история укладывается в бюджет {@code app.agent.max-context-tokens}
     * ({@link AgentContextBudget#fit}: старые ответы инструментов — пометкой); ответ 422 «context too long» — один
     * повтор раунда за цикл со сжатием всех ответов инструментов, сжимать нечего или повтор снова превысил окно —
     * {@link AgentContextOverflowException}. Фильтр GigaFilter проверяет ответы инструментов до сжатия.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param tools       инструменты, доступные модели
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return финальный текст ответа и usage последнего вызова
     * @throws AgentContextOverflowException запрос больше окна модели и после сжатия истории
     */
    public ChatResult chatCompletionWithTools(List<Map<String, String>> messages,
                                              List<ToolCallback> tools,
                                              String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionWithTools, messages={}, tools={}, model={}",
                CurrentUserHolder.getCurrentUser(), messages.size(),
                tools == null ? 0 : tools.size(), model);
        Map<String, ToolCallback> byName = new HashMap<>();
        for (ToolCallback tool : tools) {
            byName.put(tool.getToolDefinition().name(), tool);
        }
        ToolLoop loop = new ToolLoop(new ArrayList<>(toPrompt(messages).getInstructions()), toolOptions(tools, model, temperature),
                new AgentContextBudget(agentMaxContextTokens, agentCharsPerToken), AgentContextBudget.toolChars(tools));
        for (int round = 0; round < TOOL_ROUNDS_LIMIT; round++) {
            ChatResponse response = toolRound(loop);
            Map<String, Object> usage = extractUsage(response);
            addCapturedUsage(usage);
            AssistantMessage out = response.getResult().getOutput();
            if (!out.hasToolCalls()) {
                return finalToolAnswer(loop.history, loop.options, response, usage);
            }
            loop.history.add(out);
            // результат инструмента, отклонённый фильтром GigaFilter, заменяется пометкой — агент продолжает;
            // фильтр проверяет полный ответ инструмента, сжатие истории — после него
            loop.history.add(profanityGuard.screenToolResults(executeToolCalls(out, byName), filterLimited, RUN_WAIT_NOTICE.get()));
            compactToolHistory(loop.history);
        }
        throw new GigaChatException("Лимит раундов инструментов ("
                + TOOL_ROUNDS_LIMIT + ") исчерпан без финального ответа");
    }

    /** Состояние tool-цикла: история, опции запроса, бюджет контекста и признак использованного повтора после 422. */
    private static final class ToolLoop {
        private final List<Message> history;
        private final GigaChatOptions options;
        private final AgentContextBudget budget;
        private final long toolChars;
        private boolean overflowRetried;

        private ToolLoop(List<Message> history, GigaChatOptions options, AgentContextBudget budget, long toolChars) {
            this.history = history;
            this.options = options;
            this.budget = budget;
            this.toolChars = toolChars;
        }
    }

    /**
     * Раунд tool-цикла: история укладывается в бюджет контекста, ответ 422 «context too long» —
     * {@link #retryCompressed}.
     *
     * @param loop состояние цикла
     * @return ответ модели с сообщением
     */
    private ChatResponse toolRound(ToolLoop loop) {
        fitHistory(loop);
        try {
            return toolResponse(callWithRetry(new Prompt(loop.history, loop.options)));
        } catch (RuntimeException e) {
            AgentContextBudget.Overflow overflow = contextOverflow(e);
            if (overflow == null) {
                throw e;
            }
            return retryCompressed(loop, overflow, e);
        }
    }

    /**
     * Повтор раунда после 422 «context too long» со сжатием всех ответов инструментов — один на цикл.
     *
     * @param loop     состояние цикла
     * @param overflow размеры превышения из ответа модели
     * @param cause    ошибка вызова
     * @return ответ модели на сжатую историю
     * @throws AgentContextOverflowException сжимать нечего, повтор уже был либо повтор снова превысил окно
     */
    private ChatResponse retryCompressed(ToolLoop loop, AgentContextBudget.Overflow overflow, RuntimeException cause) {
        int compressed = loop.overflowRetried ? 0 : AgentContextBudget.compressAll(loop.history);
        if (compressed == 0) {
            throw new AgentContextOverflowException(overflow.requested(), overflow.maximum(), cause);
        }
        loop.overflowRetried = true;
        String notice = "⚠ контекст агента больше окна модели (" + AgentContextOverflowException.limits(overflow.requested(),
                overflow.maximum()) + ") — ответы инструментов сжаты (" + compressed + "), раунд повторяется";
        log.warn("[{}] Агент: {}", CurrentUserHolder.getCurrentUser(), notice);
        RUN_WAIT_NOTICE.get().accept(notice);
        try {
            return toolResponse(callWithRetry(new Prompt(loop.history, loop.options)));
        } catch (RuntimeException e) {
            AgentContextBudget.Overflow again = contextOverflow(e);
            if (again == null) {
                throw e;
            }
            throw new AgentContextOverflowException(again.requested(), again.maximum(), e);
        }
    }

    /**
     * Превышение окна модели в ошибке вызова; вызов, прерванный остановкой прогона, не повторяется.
     *
     * @param e ошибка вызова
     * @return размеры превышения либо {@code null}
     */
    private static AgentContextBudget.Overflow contextOverflow(RuntimeException e) {
        return CANCELLED.equals(e.getMessage()) ? null : AgentContextBudget.overflow(e);
    }

    /** История больше бюджета контекста: ответы инструментов, кроме последнего сообщения с ними, — пометкой. */
    private static void fitHistory(ToolLoop loop) {
        int compressed = loop.budget.fit(loop.history, loop.toolChars, FIT_KEEP_LAST);
        if (compressed > 0) {
            log.warn("[{}] Агент: история больше бюджета контекста ≈{} токенов — ответы инструментов усечены: {}",
                    CurrentUserHolder.getCurrentUser(), loop.budget.tokens(loop.budget.maxChars()), compressed);
        }
    }

    /**
     * Ответ модели с сообщением ассистента.
     *
     * @param response ответ модели
     * @return тот же ответ
     * @throws GigaChatException ответ пустой
     */
    private static ChatResponse toolResponse(ChatResponse response) {
        if (response == null || response.getResult() == null || response.getResult().getOutput() == null) {
            throw new GigaChatException("GigaChat вернул пустой ответ");
        }
        return response;
    }

    /**
     * Опции агентского запроса: модель, температура, инструменты; цикл ведём сами (не internal execution): это
     * позволяет сжимать историю между раундами — старые тяжёлые результаты инструментов не пересылаются моделью
     * заново на каждом раунде.
     */
    private static GigaChatOptions toolOptions(List<ToolCallback> tools, String model, Double temperature) {
        var options = GigaChatOptions.builder();
        if (model != null) {
            options.model(model);
        }
        if (temperature != null) {
            options.temperature(temperature);
        }
        GigaChatOptions built = options.build();
        built.setToolCallbacks(tools);
        built.setInternalToolExecutionEnabled(false);
        return built;
    }

    /**
     * Финальный ответ агента (без вызовов инструментов): дочитывается так же, как обычный (finish_reason=length).
     * Отказ цензора: в потоке узла сценария — {@link GigaChatRefusedException} (иначе текст отказа стал бы
     * результатом узла), вне прогона — текст как есть.
     */
    private ChatResult finalToolAnswer(List<Message> history, GigaChatOptions options, ChatResponse response,
                                       Map<String, Object> usage) {
        if (isRefused(response)) {
            if (runCancelCheck() != null) {
                throw new GigaChatRefusedException(responseText(response));
            }
            log.warn("[{}] GigaChat отказался отвечать агенту (ограничение темы) вне прогона — ответ возвращён как есть",
                    CurrentUserHolder.getCurrentUser());
            return new ChatResult(responseText(response), usage);
        }
        ChatResult finalAnswer = continueText(history, options, response, usage);
        return new ChatResult(sanitizeToolText(finalAnswer.text()), finalAnswer.usage());
    }

    /** Исполняет вызовы инструментов раунда; ошибка инструмента — ответ модели. */
    private static ToolResponseMessage executeToolCalls(AssistantMessage out,
                                                        Map<String, ToolCallback> byName) {
        List<ToolResponseMessage.ToolResponse> responses = new ArrayList<>();
        for (AssistantMessage.ToolCall call : out.getToolCalls()) {
            ToolCallback tool = byName.get(call.name());
            String result;
            try {
                result = tool == null
                        ? "{\"error\": \"неизвестный инструмент " + call.name() + "\"}"
                        : tool.call(call.arguments());
            } catch (Exception e) {
                result = "{\"error\": \"" + String.valueOf(e.getMessage())
                        .replace('"', '\'') + "\"}";
            }
            responses.add(new ToolResponseMessage.ToolResponse(
                    call.id(), call.name(), result));
        }
        return ToolResponseMessage.builder().responses(responses).build();
    }

    /**
     * Сжатие истории цикла (по мотивам deepagents summarization): все
     * tool-ответы, кроме последних {@link #COMPACT_KEEP_LAST}, длиннее
     * {@link #COMPACT_MIN_CHARS} заменяются коротким маркером — тяжёлые
     * фрагменты чтения не пересылаются на каждом последующем раунде
     * (наблюдалось: узел жёг 400-700k токенов на росте истории).
     * Нужное агент всегда может перечитать инструментом заново.
     */
    static void compactToolHistory(List<Message> history) {
        List<Integer> toolIdx = new ArrayList<>();
        for (int i = 0; i < history.size(); i++) {
            if (history.get(i) instanceof ToolResponseMessage) {
                toolIdx.add(i);
            }
        }
        for (int k = 0; k < toolIdx.size() - COMPACT_KEEP_LAST; k++) {
            int i = toolIdx.get(k);
            ToolResponseMessage msg = (ToolResponseMessage) history.get(i);
            List<ToolResponseMessage.ToolResponse> compacted = new ArrayList<>();
            boolean changed = false;
            for (ToolResponseMessage.ToolResponse r : msg.getResponses()) {
                if (r.responseData().length() > COMPACT_MIN_CHARS) {
                    compacted.add(new ToolResponseMessage.ToolResponse(r.id(), r.name(),
                            "{\"note\": \"[сжато] результат " + r.name() + " ("
                                    + r.responseData().length() + " симв) уже обработан "
                                    + "ранее; при необходимости вызови инструмент снова\"}"));
                    changed = true;
                } else {
                    compacted.add(r);
                }
            }
            if (changed) {
                history.set(i, ToolResponseMessage.builder().responses(compacted).build());
            }
        }
    }

    /**
     * После вызовов функций GigaChat может вернуть служебный токен
     * {@code <|superquote|>} вместо кавычек в финальном тексте (артефакт
     * function calling) — восстанавливаем обычные кавычки.
     *
     * @param text финальный текст ответа
     * @return текст с обычными кавычками
     */
    static String sanitizeToolText(String text) {
        return text == null ? null : text.replace("<|superquote|>", "\"");
    }

    /**
     * Чат-запрос с файлом-вложением: файл загружается в файловое хранилище GigaChat один раз ДО повторов
     * ({@link #uploadAttachment}) и удаляется в {@code finally} — и при сбое попытки. Раньше файл загружала
     * библиотека ({@code GigaChatModel} для Media без id) на каждой попытке, а удалялся он только после успешного
     * ответа: попытка, упавшая после загрузки (429, 5xx, таймаут ответа), оставляла файл-сироту в хранилище ключа.
     * Без API хранилища (тестовый контекст) вложение по-прежнему загружает библиотека, а удаляется оно по id из
     * метаданных ответа.
     *
     * @param userText    текст запроса к модели
     * @param filename    имя файла (для хранилища)
     * @param content     содержимое файла
     * @param mimeType    MIME-тип файла (например, application/pdf)
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @param maxTokens   лимит токенов ответа (null — значение по умолчанию;
     *                    для полной перепечатки многостраничного скана нужен запас)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionWithFile(String userText, String filename, byte[] content,
                                             String mimeType, String model, Double temperature,
                                             Integer maxTokens) {
        log.info("[{}] GigaChatClient.chatCompletionWithFile, filename='{}', contentType={}, size={}, model={}",
                CurrentUserHolder.getCurrentUser(), filename, mimeType,
                content == null ? 0 : content.length, model);
        var api = gigaChatApiProvider != null ? gigaChatApiProvider.getIfAvailable() : null;
        // имя файла уходит в Content-Disposition хранилища GigaChat: кириллица,
        // пути и пробелы ломают обработку файла — передаётся безопасное ASCII-имя
        var media = Media.builder()
                .mimeType(MimeType.valueOf(mimeType))
                .data(content)
                .name(safeAttachmentName(filename))
                .build();
        String uploadedId = uploadAttachment(api, media);
        var attached = uploadedId == null ? media : Media.builder()
                .mimeType(media.getMimeType())
                .data(content)
                .name(media.getName())
                .id(uploadedId)
                .build();
        var userMessage = UserMessage.builder().text(userText).media(attached).build();
        var options = GigaChatOptions.builder();
        if (model != null) {
            options.model(model);
        }
        if (temperature != null) {
            options.temperature(temperature);
        }
        if (maxTokens != null) {
            options.maxTokens(maxTokens);
        }
        Prompt prompt = new Prompt(List.of(userMessage), options.build());
        OWN_ATTACHMENT.set(uploadedId);
        try {
            return completeWithFile(prompt, filename, maxTokens);
        } finally {
            OWN_ATTACHMENT.remove();
            deleteAttachment(api, uploadedId);
        }
    }

    /**
     * Загрузка вложения в хранилище GigaChat под ограничителем и с повторами (429, 5xx).
     *
     * @param api   API хранилища ({@code null} — файл загрузит библиотека при вызове модели)
     * @param media вложение без id
     * @return id файла в хранилище либо {@code null}, если загрузка не выполнялась
     */
    private String uploadAttachment(GigaChatApi api, Media media) {
        if (api == null) {
            return null;
        }
        var uploaded = withRetry(() -> limited(() -> api.uploadFile(media)));
        var body = uploaded == null ? null : uploaded.getBody();
        return body == null || body.id() == null ? null : body.id().toString();
    }

    /**
     * Удаление вложения, загруженного {@link #uploadAttachment}: ошибка удаления не прерывает обработку
     * (файл приватный и лишь занимает квоту хранилища).
     */
    private void deleteAttachment(GigaChatApi api, String id) {
        if (api == null || id == null) {
            return;
        }
        try {
            // удаление — тоже запрос к ключу GigaChat: под общим ограничителем, как и загрузка файла
            limited(() -> api.deleteFile(id));
        } catch (Exception e) {
            log.warn("[{}] Не удалось удалить вложение {} из хранилища GigaChat: {}", CurrentUserHolder.getCurrentUser(), id, e.getMessage());
        }
    }

    /**
     * Ответ модели на запрос с вложением: пустой ответ — ошибка, отказ цензора — {@link GigaChatRefusedException},
     * обрыв по лимиту токенов — маркер {@link #TRUNCATED_MARKER}; файлы, загруженные библиотекой, удаляются по id
     * из метаданных ответа.
     */
    private ChatResult completeWithFile(Prompt prompt, String filename, Integer maxTokens) {
        ChatResponse response = callWithRetry(prompt);
        if (response == null || response.getResult() == null || response.getResult().getOutput() == null) {
            throw new GigaChatException("GigaChat вернул пустой ответ");
        }
        deleteUploadedMedia(response);
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        String text = response.getResult().getOutput().getText();
        if (isRefused(response)) {
            // отказ цензора не становится распознанным текстом ни в прогоне, ни при загрузке документа
            throw new GigaChatRefusedException(text);
        }
        if (isTruncated(response)) {
            // дочитать нельзя: вложение уже удалено из хранилища, повторная загрузка — новый запрос;
            // без маркера обрыв распознанной страницы (max_tokens) оставался незаметным
            log.warn("[{}] GigaChat: ответ на вложение '{}' оборван по лимиту токенов ({}) — поставлен маркер",
                    CurrentUserHolder.getCurrentUser(), filename, maxTokens);
            text = text + "\n" + TRUNCATED_MARKER;
        }
        return new ChatResult(text, usage);
    }

    /**
     * Безопасное ASCII-имя вложения для файлового хранилища GigaChat:
     * расширение сохраняется, остальное заменяется хэшем исходного имени.
     *
     * @param filename исходное имя файла (может содержать путь и кириллицу)
     * @return имя вида {@code attachment-1a2b3c4d.pdf}
     */
    static String safeAttachmentName(String filename) {
        if (filename == null || filename.isBlank()) {
            return "";
        }
        String ext = "";
        int dot = filename.lastIndexOf('.');
        if (dot >= 0 && filename.substring(dot + 1).matches("[A-Za-z0-9]{1,8}")) {
            ext = "." + filename.substring(dot + 1).toLowerCase(Locale.ROOT);
        }
        return "attachment-" + Integer.toHexString(filename.hashCode()) + ext;
    }

    /**
     * Удаляет из файлового хранилища GigaChat файлы, загруженные моделью
     * для этого запроса (их id — в метаданных ответа). Ошибка удаления не
     * прерывает обработку: файлы приватные и лишь занимают квоту хранилища.
     *
     * @param response ответ модели
     */
    private void deleteUploadedMedia(ChatResponse response) {
        try {
            var api = gigaChatApiProvider != null ? gigaChatApiProvider.getIfAvailable() : null;
            if (api == null || response.getMetadata() == null) {
                return;
            }
            Object ids = response.getMetadata().get(GigaChatModel.UPLOADED_MEDIA_IDS);
            if (!(ids instanceof Collection<?> list)) {
                return;
            }
            for (Object id : list) {
                if (String.valueOf(id).equals(OWN_ATTACHMENT.get())) {
                    // вложение, загруженное chatCompletionWithFile: удаляется там в finally (повтор под GigaFilter
                    // идёт с тем же файлом)
                    continue;
                }
                // удаление — тоже запрос к ключу GigaChat: под общим ограничителем, как и загрузка файла
                limited(() -> api.deleteFile(String.valueOf(id)));
            }
        } catch (Exception e) {
            log.warn("[{}] Не удалось удалить файлы из хранилища GigaChat: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /**
     * Извлекает статистику использования токенов из ответа модели.
     *
     * @param response ответ Spring AI
     * @return map с ключами prompt_tokens/completion_tokens/total_tokens или {@code null}
     */
    private Map<String, Object> extractUsage(ChatResponse response) {
        try {
            var metadata = response.getMetadata();
            if (metadata == null || metadata.getUsage() == null) {
                return Map.of();
            }
            var usage = metadata.getUsage();
            Map<String, Object> map = new HashMap<>();
            map.put("prompt_tokens", usage.getPromptTokens());
            map.put("completion_tokens", usage.getCompletionTokens());
            map.put("total_tokens", usage.getTotalTokens());
            return map;
        } catch (Exception e) {
            log.info("[{}] Не удалось извлечь usage из ответа GigaChat: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return Map.of();
        }
    }

    /**
     * Вызов чат-модели с повторными попытками при временных сбоях.
     * <p>
     * Повторяются: 429 (превышение лимита — увеличенная задержка), 5xx, сетевые
     * таймауты. Не повторяются: 4xx-ошибки данных (400, 401, 402, 413) —
     * повтор их не исправит. Задержка растёт линейно с номером попытки.
     * Используется реактивный retryWhen — без блокировки потоков boundedElastic
     * в ожидании повтора.
     *
     * <p>
     * Фильтр GigaFilter и profanity_check ({@link GigaFilterGuard}): при выключенной проверке (input=false,
     * output=false, agent=true) промпт уходит как раньше, иначе — {@link #guardedCall}.
     *
     * @param prompt промпт
     * @return ответ модели
     */
    private ChatResponse callWithRetry(Prompt prompt) {
        if (!profanityGuard.active()) {
            return sendWithRetry(prompt);
        }
        return guardedCall(prompt);
    }

    /** Вызов модели с повторами при временных сбоях (без фильтра). */
    private ChatResponse sendWithRetry(Prompt prompt) {
        return withRetry(() -> callWithHardTimeout(prompt), () -> modelName(prompt));
    }

    /**
     * Вызов под фильтром GigaFilter: проверка входа (заблокирован — {@link GigaFilterBlockedException}, модель не
     * вызывается), profanity_check по решению проверки (цензор выключается, только если вход прошёл фильтр), проверка
     * ответа с аргументами вызовов инструментов (заблокирован — исключение, файлы ответа удаляются). Фильтр недоступен
     * (после повторов 429/5xx самой проверки) для ответа, полученного с выключенным цензором, — повтор запроса с
     * {@code profanity_check=true} (требование ДКБ), его ответ принимается и при недоступном фильтре.
     *
     * @param prompt промпт
     * @return ответ модели
     */
    private ChatResponse guardedCall(Prompt prompt) {
        Boolean flag = censorFlag(profanityGuard.admit(prompt.getInstructions(), filterLimited));
        ChatResponse response = sendWithRetry(withProfanityCheck(prompt, flag));
        if (outputChecked(response) || !Boolean.FALSE.equals(flag)) {
            return response;
        }
        log.warn("[{}] GigaFilter недоступен для проверки ответа, полученного с выключенным цензором, — "
                + "повтор запроса с profanity_check=true", CurrentUserHolder.getCurrentUser());
        addCapturedUsage(extractUsage(response));
        deleteUploadedMedia(response);
        ChatResponse again = sendWithRetry(withProfanityCheck(prompt, Boolean.TRUE));
        outputChecked(again);
        return again;
    }

    /**
     * Проверка ответа фильтром: текст и аргументы запрошенных вызовов инструментов (ответ-отказ цензора не
     * проверяется). Блокировка — до исполнения инструментов: заблокированные аргументы не попадают ни в инструмент
     * (журнал прогона, рабочие документы), ни в историю следующего раунда.
     *
     * @param response ответ модели
     * @return {@code true} — проверен или проверять нечего; {@code false} — фильтр недоступен
     * @throws GigaFilterBlockedException ответ заблокирован (файлы, загруженные для запроса, удаляются)
     */
    private boolean outputChecked(ChatResponse response) {
        AssistantMessage answer = response == null || GigaChatRefusal.isBlacklisted(response) || response.getResult() == null
                ? null : response.getResult().getOutput();
        try {
            return profanityGuard.checkAnswer(answer, filterLimited);
        } catch (GigaFilterBlockedException e) {
            if (response != null) {
                addCapturedUsage(extractUsage(response));
                deleteUploadedMedia(response);
            }
            throw e;
        }
    }

    /**
     * Значение profanity_check запроса: решение проверки входа; без решения (agent=true) поле не ставится, но если
     * в глобальных опциях модели цензор выключен ({@code spring.ai.gigachat.chat.options.profanity-check=false}) —
     * явный {@code true}.
     *
     * @param admitted решение проверки входа
     * @return значение поля либо {@code null} — не ставить
     */
    private Boolean censorFlag(Boolean admitted) {
        if (admitted != null) {
            return admitted;
        }
        ChatOptions defaults = chatModel.getDefaultOptions();
        return defaults instanceof GigaChatOptions giga && Boolean.FALSE.equals(giga.getProfanityCheck()) ? Boolean.TRUE : null;
    }

    /**
     * Промпт с параметром profanity_check: копия опций (модель, температура, инструменты сохраняются).
     *
     * @param prompt промпт
     * @param flag   значение ({@code null} — промпт без изменений)
     * @return промпт для отправки
     */
    static Prompt withProfanityCheck(Prompt prompt, Boolean flag) {
        if (flag == null) {
            return prompt;
        }
        GigaChatOptions options = prompt.getOptions() instanceof GigaChatOptions giga
                ? giga.toBuilder().profanityCheck(flag).build()
                : GigaChatOptions.builder().profanityCheck(flag).build();
        return new Prompt(prompt.getInstructions(), options);
    }

    /**
     * Имя модели запроса для текста ошибки: из опций промпта, иначе модель по умолчанию.
     *
     * @param prompt промпт
     * @return имя модели или {@code null}, если неизвестно
     */
    private String modelName(Prompt prompt) {
        ChatOptions options = prompt.getOptions();
        if (options != null && options.getModel() != null) {
            return options.getModel();
        }
        ChatOptions defaults = chatModel.getDefaultOptions();
        return defaults == null ? null : defaults.getModel();
    }

    /**
     * Вызов модели на отдельном потоке с жёстким потолком ожидания
     * {@code callHardTimeoutSeconds}: по истечении вызов прерывается,
     * а ошибка (в тексте — «timeout») уходит в общий retry как временная.
     * Поток узла при любом поведении сети освобождается гарантированно.
     */
    private ChatResponse callWithHardTimeout(Prompt prompt) {
        return limited(() -> sendWithHardTimeout(prompt));
    }

    /**
     * Одна HTTP-попытка с потолком ожидания; выполняется под разрешением ограничителя, взятым
     * до отправки (ожидание очереди не расходует потолок) и отпущенным сразу после попытки.
     */
    private ChatResponse sendWithHardTimeout(Prompt prompt) {
        if (callHardTimeoutSeconds <= 0) {
            return chatModel.call(prompt);
        }
        Future<ChatResponse> future = llmCallPool().submit(() -> chatModel.call(prompt));
        try {
            return future.get(callHardTimeoutSeconds, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            future.cancel(true);
            throw new GigaChatException(HARD_TIMEOUT + ": ответ не получен за " + callHardTimeoutSeconds + " с", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            future.cancel(true);
            throw new GigaChatException("LLM-вызов прерван", e);
        } catch (ExecutionException e) {
            throw e.getCause() instanceof RuntimeException re
                    ? re
                    : new GigaChatException("Сбой LLM-вызова", e.getCause());
        }
    }

    /**
     * Ограниченный пул страховочных LLM-вызовов: размер — {@code app.gigachat.llm-call-pool-size}
     * либо max(2, 2 × max-concurrent); создаётся при первом обращении (в тестах без Spring — с умолчаниями).
     *
     * @return пул потоков LLM-вызовов
     */
    private ExecutorService llmCallPool() {
        ExecutorService pool = llmCallPool;
        if (pool == null) {
            synchronized (this) {
                if (llmCallPool == null) {
                    int size = llmCallPoolSize > 0 ? llmCallPoolSize : Math.max(2, 2 * maxConcurrent);
                    llmCallPool = Executors.newFixedThreadPool(size, r -> {
                        Thread t = new Thread(r, "llm-call");
                        t.setDaemon(true);
                        return t;
                    });
                }
                pool = llmCallPool;
            }
        }
        return pool;
    }

    /** Останавливает пул страховочных LLM-вызовов при выключении приложения. */
    @PreDestroy
    public void shutdownLlmCallPool() {
        ExecutorService pool = llmCallPool;
        if (pool != null) {
            pool.shutdownNow();
        }
    }

    private <T> T withRetry(Supplier<T> call) {
        return withRetry(call, () -> null);
    }

    /**
     * Вызов с повторами по {@link GigaChatRetryPolicy}; неповторяемая ошибка или исчерпанные паузы —
     * {@link GigaChatException} «Не удалось выполнить запрос к GigaChat: краткая причина».
     * <p>
     * Таймаут ответа (read-timeout клиента, страховочный потолок) повторяется не больше
     * {@link GigaChatRetryPolicy#TIMEOUT_RETRIES} раз; 401 — один повтор после короткой паузы (библиотека
     * на 401 токен не обновляет, см. {@code unauthorizedRetryDelayMillis}); при 429 пауза не меньше
     * {@code Retry-After} ответа в пределах {@code rate-limit-max-delay-millis}.
     *
     * @param call  вызов
     * @param model имя модели запроса для текста причины (вычисляется только при ошибке)
     * @return результат вызова
     */
    private <T> T withRetry(Supplier<T> call, Supplier<String> model) {
        var cancelled = RUN_CANCEL_CHECK.get();
        var notice = RUN_WAIT_NOTICE.get();
        var policy = new GigaChatRetryPolicy(new GigaChatRetryPolicy.Settings(retryDelay429Millis, rateLimitMaxDelayMillis,
                rateLimitMaxWaitMillis, retryDelayMillis, unavailableMaxDelayMillis, unavailableMaxWaitMillis, retryMaxAttempts), model);
        boolean retriedUnauthorized = false;
        while (true) {
            try {
                return call.get();
            } catch (RuntimeException e) {
                if (cancelled.getAsBoolean()) {
                    log.info("[{}] GigaChat: прогон остановлен — повторы прерваны", CurrentUserHolder.getCurrentUser());
                    throw new GigaChatException(CANCELLED, e);
                }
                String msg = failureText(e);
                if (!retriedUnauthorized && isUnauthorized(e)) {
                    retriedUnauthorized = true;
                    log.warn("[{}] GigaChat: 401 — единственный повтор через {} мс: {}", CurrentUserHolder.getCurrentUser(),
                            unauthorizedRetryDelayMillis, msg);
                    sleepUnlessCancelled(unauthorizedRetryDelayMillis, cancelled);
                    continue;
                }
                GigaChatRetryPolicy.Wait wait = nextWait(policy, msg, e);
                long delay = Math.max(wait.delayMillis(), Math.min(GigaChatRetryAfter.millis(e), rateLimitMaxDelayMillis));
                log.warn("[{}] GigaChat: {}: {}", CurrentUserHolder.getCurrentUser(), wait.notice(), msg);
                notice.accept(wait.notice());
                sleepUnlessCancelled(delay, cancelled);
            }
        }
    }

    /** Пауза по политике: таймаут ответа — своя короткая ветка, остальное — по виду сбоя. */
    private static GigaChatRetryPolicy.Wait nextWait(GigaChatRetryPolicy policy, String msg, RuntimeException e) {
        if (isRequestTimeout(msg)) {
            return policy.nextAfterTimeout(e);
        }
        return policy.next(isRateLimited(msg, e), isTransientFailure(msg, e), e);
    }

    /**
     * Ответ на запрос не получен за таймаут: read-timeout клиента ({@code JdkClientHttpRequest} Spring 6.2
     * отменяет обмен по таймеру и бросает {@code HttpTimeoutException} без текста — распознаётся по классу
     * в цепочке причин; JDK-клиент — «request timed out») либо страховочный потолок вызова.
     * Таймаут соединения ({@code HttpConnectTimeoutException}, «connect timed out») — недоступность сервиса,
     * а не долгая генерация: остаётся в бюджете недоступности.
     *
     * @param msg текст ошибки с классами и сообщениями по цепочке причин
     * @return {@code true}, если запрос оборван таймаутом ответа
     */
    static boolean isRequestTimeout(String msg) {
        String lower = msg.toLowerCase(Locale.ROOT);
        if (lower.contains("connect timed out") || msg.contains("HttpConnectTimeoutException")) {
            return false;
        }
        return msg.contains("HttpTimeoutException") || lower.contains("request timed out") || msg.contains(HARD_TIMEOUT);
    }

    /**
     * Ответ GigaChat 401 (токен отозван или протух раньше плановой замены).
     *
     * @param e исключение вызова
     * @return {@code true}, если в цепочке причин ответ с кодом 401
     */
    static boolean isUnauthorized(Throwable e) {
        return Integer.valueOf(401).equals(GigaChatFailureReason.httpStatus(e));
    }

    /** Ожидание кусками по 2 с с проверкой остановки прогона. */
    private static void sleepUnlessCancelled(long millis, java.util.function.BooleanSupplier cancelled) {
        long end = System.currentTimeMillis() + millis;
        while (System.currentTimeMillis() < end && !cancelled.getAsBoolean()) {
            try {
                Thread.sleep(Math.min(2000, Math.max(1, end - System.currentTimeMillis())));
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    /**
     * Превышение лимита запросов (429) — повторяется с увеличенной задержкой. Решает код ответа из цепочки причин
     * ({@link GigaChatFailureReason#httpStatus}); без кода — текст ошибки, код отдельным числом.
     *
     * @param msg текст ошибки с цепочкой причин
     * @param e   исключение вызова
     * @return {@code true}, если ошибка — превышение лимита
     */
    static boolean isRateLimited(String msg, Throwable e) {
        Integer status = GigaChatFailureReason.httpStatus(e);
        if (status != null) {
            return status == HTTP_TOO_MANY_REQUESTS;
        }
        if (msg.contains("413") && msg.contains("Tokens limit")) {
            return false;
        }
        return RATE_LIMIT_CODE.matcher(msg).find() || msg.contains("Too Many Requests");
    }

    /**
     * Временный сбой (5xx, сетевая ошибка ввода-вывода, таймаут, обрыв соединения, неразрешённое имя хоста) —
     * повторяется. Решает код ответа из цепочки причин ({@link GigaChatFailureReason#httpStatus}): 5xx — временный,
     * 4xx — нет (422 «context too long 135021» раньше считался 502 по подстроке числа токенов и повторялся до 30 мин).
     * Без кода — сетевой сбой в цепочке причин ({@link #isNetworkFailure}) либо текст ошибки.
     *
     * @param msg текст ошибки с цепочкой причин
     * @param e   исключение вызова
     * @return {@code true}, если сбой временный
     */
    static boolean isTransientFailure(String msg, Throwable e) {
        Integer status = GigaChatFailureReason.httpStatus(e);
        if (status != null) {
            return status >= HTTP_SERVER_ERROR;
        }
        if (isNetworkFailure(e)) {
            return true;
        }
        if (msg.contains("413") && msg.contains("Tokens limit")) {
            return false;
        }
        // имя не разрешилось (DNS через туннель мигает) — такой же временный сбой, как обрыв соединения
        return SERVER_ERROR_CODE.matcher(msg).find()
                || msg.contains("timed out") || msg.contains("timeout")
                || msg.contains("Connection") || msg.contains("connection")
                || msg.contains("UnresolvedAddress") || msg.contains("UnknownHost");
    }

    /**
     * Сетевой сбой вызова: ошибка ввода-вывода в цепочке причин. Обрыв соединения до ответа приходит как
     * {@code ResourceAccessException} «I/O error on POST request … HTTP/1.1 header parser received no bytes» с
     * {@code IOException}/{@code EOFException} внутри — в тексте нет ни «timeout», ни «connection», и прежде такой
     * сбой не повторялся (узел h3 прогона ПЗД упал с первой попытки).
     *
     * @param e исключение вызова
     * @return {@code true}, если в цепочке причин ошибка ввода-вывода
     */
    static boolean isNetworkFailure(Throwable e) {
        Throwable t = e;
        for (int depth = 0; t != null && depth < CAUSE_DEPTH; depth++) {
            if (t instanceof ResourceAccessException || t instanceof IOException || t instanceof WebClientRequestException) {
                return true;
            }
            t = t.getCause() == t ? null : t.getCause();
        }
        return false;
    }

    /**
     * Текст сбоя с цепочкой причин (класс и сообщение каждой) — по нему распознаются
     * временные сбои: у «I/O error on POST request» причина (UnresolvedAddressException,
     * таймаут) лежит глубже верхнего сообщения.
     *
     * @param e исключение
     * @return сообщения и классы по цепочке причин
     */
    private static String failureText(Throwable e) {
        StringBuilder sb = new StringBuilder();
        Throwable t = e;
        for (int depth = 0; t != null && depth < 8; depth++) {
            sb.append(t.getClass().getSimpleName()).append(": ").append(t.getMessage()).append("; ");
            t = t.getCause() == t ? null : t.getCause();
        }
        return sb.toString();
    }

    // -------------------------------------------------------------------------
    // Завершение чата (последовательное)
    // -------------------------------------------------------------------------

    /**
     * Потоковое выполнение чат-запроса, возвращает Flux текстовых фрагментов.
     * <p>
     * Использует синхронный вызов, обёрнутый в Flux — у GigaChat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ.
     *
     * @param messages список сообщений в формате {role, content}
     * @return Flux строк текста
     */
    public Flux<String> chatCompletionStream(List<Map<String, String>> messages) {
        return chatCompletionStreamResult(messages, null, null).map(ChatResult::text);
    }

    /**
     * Потоковый чат-запрос с переопределением модели/температуры и usage в результате.
     * <p>
     * Используется синхронный вызов, обёрнутый в Flux — у spring-ai-gigachat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ одним элементом.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return Flux с единственным ChatResult
     */
    public Flux<ChatResult> chatCompletionStreamResult(List<Map<String, String>> messages,
                                                       String model, Double temperature) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] GigaChatClient.chatCompletionStreamResult, messages={}, model={}",
                userId, messages.size(), model);
        return Flux.defer(() -> {
            CurrentUserHolder.setCurrentUser(userId);
            log.info("[{}] Start chat completion (synchronous)", userId);
            ChatResult result = chatCompletionResult(messages, model, temperature);
            log.info("[{}] Chat completion completed, {} characters", userId, result.text().length());
            return Flux.just(result);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    // -------------------------------------------------------------------------
    // эмбеддинги
    // -------------------------------------------------------------------------

    /**
     * Получает векторные эмбеддинги для списка текстов.
     * <p>
     * Пакетная обработка: по 50 текстов за раз. Текст усекается до 800 символов
     * (ограничение GigaChat ~514 токенов). Пакет, для которого эмбеддинги не получены
     * (ошибка после повторов, пустой ответ), — {@link GigaChatException}: раньше вместо него
     * возвращались нулевые векторы, и документ помечался проиндексированным, оставаясь невидимым для поиска.
     *
     * @param texts список текстов для эмбеддинги
     * @return список массивов float[] векторных эмбеддингов
     * @throws GigaChatException если эмбеддинги хотя бы одного пакета не получены
     */
    public List<float[]> getEmbeddings(List<String> texts) {
        log.info("[{}] GigaChatClient.getEmbeddings, texts={}",
                CurrentUserHolder.getCurrentUser(),
                texts == null ? 0 : texts.size());
        if (texts == null) {
            return List.of();
        }
        List<String> truncated = texts.stream()
                .map(t -> t.length() > textMaxLength ? t.substring(0, textMaxLength) : t)
                .toList();
        long cut = texts.stream().filter(t -> t.length() > textMaxLength).count();
        if (cut > 0) {
            // усечение по началу видно в логе: вектор вопроса длиннее предела строится не по всему тексту
            log.warn("[{}] GigaChat: {} из {} текстов эмбеддинга длиннее предела {} символов (самый длинный {}) — усечены по началу",
                    CurrentUserHolder.getCurrentUser(), cut, texts.size(), textMaxLength,
                    texts.stream().mapToInt(String::length).max().orElse(0));
        }

        List<float[]> results = new ArrayList<>();
        // размер пакета из настроек; у клиента, созданного без Spring (тесты), поле может быть нулевым
        int size = Math.max(1, batchSize);
        for (int i = 0; i < truncated.size(); i += size) {
            List<String> batch = truncated.subList(i, Math.min(i + size, truncated.size()));
            results.addAll(embeddingBatch(batch, i / size));
        }
        return results;
    }

    /**
     * Эмбеддинги одного пакета текстов под ограничителем и повторами.
     *
     * @param batch  тексты пакета
     * @param number номер пакета (для текста ошибки)
     * @return векторы пакета
     * @throws GigaChatException если ответ не получен или пуст
     */
    private List<float[]> embeddingBatch(List<String> batch, int number) {
        // Используются специфичные для GigaChat опции, чтобы избежать NPE при getModel()
        var opts = GigaChatEmbeddingOptions.builder()
                .withModel("Embeddings").withDimensions(1024).build();
        EmbeddingResponse response;
        try {
            response = withRetry(() -> limitedEmbeddings(() -> embeddingModel.call(new EmbeddingRequest(batch, opts))));
        } catch (GigaChatException e) {
            log.error("[{}] Эмбеддинги пакета {} не получены: {}", CurrentUserHolder.getCurrentUser(), number, e.getMessage());
            throw e;
        } catch (RuntimeException e) {
            log.error("[{}] Эмбеддинги пакета {} не получены: {}", CurrentUserHolder.getCurrentUser(), number, e.getMessage());
            throw new GigaChatException("Эмбеддинги пакета " + number + " не получены: " + e.getMessage(), e);
        }
        // NOSONAR java:S2589 — вложение может вернуть null (test embeddingsNullResponseThrows): здесь это
        // осмысленный кейс, а не мёртвый код; getResults() при null упал бы с NPE вместо нужного исключения.
        if (response == null || response.getResults() == null) {
            throw new GigaChatException("Эмбеддинги пакета " + number + " не получены: пустой ответ GigaChat");
        }
        return response.getResults().stream().map(Embedding::getOutput).toList();
    }

    // -------------------------------------------------------------------------
    // Внутренние вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Одна попытка чат-запроса под общим ограничителем: разрешение держится только
     * на время самого вызова и отпускается до паузы повтора в {@code withRetry}.
     * Ожидание очереди прерывается остановкой прогона и видно в его журнале.
     *
     * @param call попытка вызова модели
     * @param <T>  тип ответа
     * @return ответ модели
     */
    private <T> T limited(Supplier<T> call) {
        return concurrencyLimiter.call(call, runCancelCheck(), RUN_WAIT_NOTICE.get());
    }

    /**
     * Проверка остановки прогона для ограничителя: {@code null} для потока без прогона — к такому
     * вызову ограничитель применяет предел ожидания очереди.
     *
     * @return проверка остановки или {@code null}
     */
    private static java.util.function.BooleanSupplier runCancelCheck() {
        var check = RUN_CANCEL_CHECK.get();
        return check == NO_RUN ? null : check;
    }

    /**
     * Одна попытка запроса эмбеддингов под общим ограничителем (если он распространяется на эмбеддинги).
     *
     * @param call попытка вызова модели эмбеддингов
     * @param <T>  тип ответа
     * @return ответ модели
     */
    private <T> T limitedEmbeddings(Supplier<T> call) {
        return concurrencyLimiter.callEmbeddings(call, runCancelCheck(), RUN_WAIT_NOTICE.get());
    }

    /**
     * Преобразует наш формат List&lt;Map&lt;role,content&gt;&gt; в Spring AI Prompt.
     *
     * @param messages список сообщений
     * @return объект Prompt для Spring AI
     */
    private Prompt toPrompt(List<Map<String, String>> messages) {
        List<Message> aiMessages = new ArrayList<>();
        for (Map<String, String> msg : messages) {
            String role = msg.get("role");
            String content = stripSplitMarkers(msg.get("content"));
            // отсутствующий role — пользователь, пустой content — пустое сообщение (Spring AI не принимает null)
            if (role == null) {
                role = "user";
            }
            if (content == null) {
                content = "";
            }
            switch (role) {
                case "system" -> aiMessages.add(new SystemMessage(content));
                case "assistant" -> aiMessages.add(new AssistantMessage(content));
                default /*user*/ -> aiMessages.add(new UserMessage(content));
            }
        }
        return new Prompt(aiMessages);
    }
}
