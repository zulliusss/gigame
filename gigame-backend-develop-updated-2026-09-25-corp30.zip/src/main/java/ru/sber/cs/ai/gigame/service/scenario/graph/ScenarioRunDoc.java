package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
public class ScenarioRunDoc {
    /** Статус: текст извлечён полностью. */
    public static final String STATUS_OK = "ok";
    /** Статус: текст получен распознаванием скана (суммы стоит перепроверить). */
    public static final String STATUS_OCR = "ocr";
    /** Статус: текст извлечён частично (нераспознанные страницы, обрезанные строки, листы сверх лимита, кодировка). */
    public static final String STATUS_TRUNCATED = "truncated";
    /** Статус: документ не разобран — вместо текста маркер ручной проверки. */
    public static final String STATUS_UNREADABLE = "unreadable";

    /** Начало текста-заглушки нечитаемого документа (ставит ScenarioService). */
    public static final String MANUAL_CHECK_MARKER = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]";
    /** Начало текста распознанного скана (ставит ScanOcrService). */
    private static final String OCR_MARKER = "[РАСПОЗНАНО";
    /** Фрагменты маркеров частичной потери текста, которые ставят парсеры и OCR. */
    private static final List<String> PARTIAL_MARKERS = List.of(
            "не распознан", "[...обрезано: больше", "[... листы сверх лимита", "[кодировка не распознана",
            "без текстового слоя", "[… ответ модели усечён");

    private final String filename;
    private final String text;
    /**
     * Рабочий файл, записанный агентом (write_file): виден последующим
     * агент-узлам, но НЕ является источником для цитатной валидации —
     * иначе агент подтверждал бы значения цитатами из собственного конспекта.
     */
    private final boolean workNote;
    /**
     * Статус разбора документа ({@link #STATUS_OK}, {@link #STATUS_OCR},
     * {@link #STATUS_TRUNCATED}, {@link #STATUS_UNREADABLE}) — выставляется при
     * загрузке по маркерам в тексте, чтобы кодовые узлы и выгрузка не принимали
     * служебные маркеры за данные.
     */
    private final String status;
    @Setter
    private String docClass;

    public ScenarioRunDoc(String filename, String text) {
        this(filename, text, false);
    }

    public ScenarioRunDoc(String filename, String text, boolean workNote) {
        this.filename = filename;
        this.text = text;
        this.workNote = workNote;
        this.status = workNote ? STATUS_OK : detectStatus(text);
    }

    /**
     * Статус по маркерам текста: маркер ручной проверки в начале — нечитаем;
     * префикс OCR — распознан; маркеры нераспознанных страниц, обрезки строк,
     * листов сверх лимита, кодировки — частично; иначе — полный.
     *
     * @param text текст документа
     * @return статус
     */
    public static String detectStatus(String text) {
        if (text == null) {
            return STATUS_OK;
        }
        if (isUnreadable(text)) {
            return STATUS_UNREADABLE;
        }
        for (String marker : PARTIAL_MARKERS) {
            if (text.contains(marker)) {
                return STATUS_TRUNCATED;
            }
        }
        return text.startsWith(OCR_MARKER) ? STATUS_OCR : STATUS_OK;
    }

    /**
     * Документ не разобран (текст — маркер ручной проверки).
     *
     * @param text текст документа
     * @return {@code true}, если вместо текста маркер
     */
    public static boolean isUnreadable(String text) {
        return text != null && text.startsWith(MANUAL_CHECK_MARKER);
    }

    /**
     * Причина, по которой документ не разобран: текст маркера после «Документ «имя»».
     *
     * @param text текст-маркер
     * @return причина (пусто для читаемого документа)
     */
    public static String unreadableReason(String text) {
        if (!isUnreadable(text)) {
            return "";
        }
        String body = text.substring(MANUAL_CHECK_MARKER.length()).strip();
        int from = body.indexOf('»');
        String reason = from >= 0 ? body.substring(from + 1) : body;
        reason = reason.replaceFirst("^\\s*(?:не распознан|не удалось обработать|не распакован)?\\s*:?\\s*", "").strip();
        int dot = reason.indexOf(". ");
        return dot > 0 ? reason.substring(0, dot) : reason;
    }

    /**
     * Документ не разобран.
     *
     * @return {@code true} для статуса {@link #STATUS_UNREADABLE}
     */
    public boolean isUnreadable() {
        return STATUS_UNREADABLE.equals(status);
    }
}
