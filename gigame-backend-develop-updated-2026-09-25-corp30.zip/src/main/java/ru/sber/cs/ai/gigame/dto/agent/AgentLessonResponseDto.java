package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;

import java.time.OffsetDateTime;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * DTO урока агента для ответов.
 * Используется во всех GET/POST/PUT endpoints контроллера {@code /api/agent/lessons}.
 *
 * @param id          идентификатор урока
 * @param scenarioId  сценарий-владелец; null — общий урок
 * @param userId      автор урока
 * @param lesson      текст правила
 * @param source      источник: user | reviser | auto | system
 * @param approved    общие уроки применяются только после одобрения
 * @param createdAt   дата создания
 * @param updatedAt   дата последнего обновления
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Урок агента",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentLessonResponseDto(
        @Schema(description = "Идентификатор урока")
        UUID id,

        @Schema(
                description = "Идентификатор сценария; null — общий урок",
                pattern = "^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})?$"
        )
        UUID scenarioId,

        @Schema(description = "Автор урока (ID пользователя)")
        String userId,

        @Schema(
                description = "Текст урока",
                maxLength = 4000
        )
        String lesson,

        @Schema(
                description = "Источник урока",
                pattern = "^(user|reviser|auto|system)$"
        )
        String source,

        @Schema(description = "Одобрен ли общий урок для применения")
        Boolean approved,

        @Schema(description = "Дата создания")
        OffsetDateTime createdAt,

        @Schema(description = "Дата последнего обновления")
        OffsetDateTime updatedAt
) {

    /**
     * maxLength поля lesson в статической спецификации.
     */
    public static final int LESSON_MAX_LENGTH = 4000;

    /**
     * pattern поля user_id в спецификации. Идентификатор вне шаблона (например
     * «anonymous» у запросов без X-UserId) в ответ не отдаётся.
     */
    private static final Pattern USER_ID_PATTERN = Pattern.compile("^[A-Z0-9]{0,16}$");

    /**
     * Преобразует сущность {@link AgentLesson} в DTO, приводя значения к лимитам
     * схемы: текст урока (склейка вопроса и ответа, правило от LLM) усекается
     * до 4000 символов с многоточием, даты — в UTC с точностью до микросекунд,
     * user_id вне шаблона схемы опускается.
     *
     * @param entity сущность урока
     * @return DTO в пределах схемы
     */
    public static AgentLessonResponseDto from(AgentLesson entity) {
        String userId = entity.getUserId();
        return new AgentLessonResponseDto(
                entity.getId(),
                entity.getScenarioId(),
                userId != null && USER_ID_PATTERN.matcher(userId).matches() ? userId : null,
                SchemaLimitUtils.clip(entity.getLesson(), LESSON_MAX_LENGTH),
                entity.getSource(),
                entity.getApproved(),
                SchemaLimitUtils.utcMicros(entity.getCreatedAt()),
                SchemaLimitUtils.utcMicros(entity.getUpdatedAt())
        );
    }
}
