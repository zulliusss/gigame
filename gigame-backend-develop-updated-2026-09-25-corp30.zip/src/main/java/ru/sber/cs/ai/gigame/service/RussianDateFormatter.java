package ru.sber.cs.ai.gigame.service;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Форматтер значений Excel с датами «дд.мм.гггг»: стандартный {@link DataFormatter}
 * даёт «7/1/20», нечитаемое для русских документов и регэкспов Формы 3
 * (ждут dd.MM.yyyy). Общий для потокового разбора XLSX и бинарного XLS.
 * <p>
 * Локаль чисел зафиксирована — русская ({@link #NUMBERS}): без неё {@link DataFormatter}
 * берёт локаль JVM, и одна и та же ячейка «0.00» на стенде Windows ru-RU давала «61,00»,
 * а на проме (Linux, en) — «61.00»; «#,##0.00 "₽"» — «1 338 698,00 ₽» против «1,338,698.00 ₽».
 * Все сценарии отлажены на стенде, то есть на русском формате, и на проме молча ломались:
 * Форма 3 не видела сумму формы (кейс Хинт, письмо «Ошибка с рейтингом», 23.09.2026),
 * АЗК v3c не разбирала ставки отчёта ЭТП (комплект УБ2026-0145, письмо Костыгиной 23.09.2026).
 * Теперь текст Excel на любом контуре такой же, как на стенде: десятичная запятая, разряды —
 * неразрывный пробел; даты по-прежнему переопределены в dd.MM.yyyy.
 */
final class RussianDateFormatter extends DataFormatter {

    /** Локаль чисел: русская — формат, на котором отлажены сценарии. */
    static final Locale NUMBERS = new Locale("ru", "RU");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    /** Форматтер с фиксированной русской локалью чисел — не зависит от локали JVM. */
    RussianDateFormatter() {
        super(NUMBERS);
    }

    @Override
    public String formatRawCellContents(double value, int formatIndex, String formatString, boolean use1904Windowing) {
        if (DateUtil.isADateFormat(formatIndex, formatString) && DateUtil.isValidExcelDate(value)) {
            LocalDateTime date = DateUtil.getLocalDateTime(value, use1904Windowing);
            return date.toLocalTime().equals(LocalTime.MIDNIGHT) ? date.toLocalDate().format(DATE) : date.format(DATE_TIME);
        }
        return super.formatRawCellContents(value, formatIndex, formatString, use1904Windowing);
    }
}
