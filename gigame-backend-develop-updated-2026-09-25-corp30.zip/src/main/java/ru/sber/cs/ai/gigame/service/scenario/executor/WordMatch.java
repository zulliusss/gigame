package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Вхождение слова (фразы) в текст целым словом: границы — не буквы и не цифры,
 * без учёта регистра; вхождение сразу после отрицания «не» не считается.
 * Так «СООТВЕТСТВУЕТ» не находится в «НЕ СООТВЕТСТВУЕТ», а «акт» — в «Контракт».
 */
final class WordMatch {

    private WordMatch() {
    }

    /**
     * Есть ли в тексте слово целиком и не под отрицанием.
     *
     * @param text текст
     * @param word слово или фраза
     * @return {@code true}, если найдено
     */
    static boolean containsWord(String text, String word) {
        if (text == null || word == null || word.isBlank()) {
            return false;
        }
        Matcher m = Pattern.compile("(?<![\\p{L}\\p{N}])" + Pattern.quote(word.strip()) + "(?![\\p{L}\\p{N}])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE).matcher(text);
        while (m.find()) {
            if (!negated(text, m.start())) {
                return true;
            }
        }
        return false;
    }

    private static boolean negated(String text, int start) {
        String before = text.substring(0, start).stripTrailing().toLowerCase(Locale.ROOT);
        return before.endsWith("не")
                && (before.length() == 2 || !Character.isLetterOrDigit(before.charAt(before.length() - 3)));
    }
}
