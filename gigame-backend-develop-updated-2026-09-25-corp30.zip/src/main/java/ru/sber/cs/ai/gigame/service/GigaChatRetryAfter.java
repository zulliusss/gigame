package ru.sber.cs.ai.gigame.service;

import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Подсказка {@code Retry-After} ответа GigaChat 429 — пауза перед повтором не меньше неё.
 * <p>
 * Заголовок берётся из ответа в цепочке причин ({@link RestClientResponseException},
 * {@link WebClientResponseException}) либо из пометки {@link #MARKER} в тексте ошибки: обработчик
 * ответов {@link GigaChatResponseErrorHandler} дописывает её к сообщению, потому что исключения
 * spring-ai ({@code NonTransientAiException}) заголовков не несут. Учитываются только значения
 * в секундах; дата в заголовке пропускается.
 */
final class GigaChatRetryAfter {

    /** Пометка в тексте ошибки: «Retry-After=N» (секунды). */
    static final String MARKER = "Retry-After=";
    private static final Pattern MARKED = Pattern.compile(Pattern.quote(MARKER) + "(\\d{1,7})");
    private static final int MAX_DEPTH = 8;

    private GigaChatRetryAfter() {
    }

    /**
     * Пауза из {@code Retry-After} ответа, мс.
     *
     * @param error исключение вызова (с цепочкой причин)
     * @return пауза в миллисекундах; 0, если заголовка нет или он не число
     */
    static long millis(Throwable error) {
        Throwable t = error;
        for (int depth = 0; t != null && depth < MAX_DEPTH; depth++) {
            long found = fromThrowable(t);
            if (found > 0) {
                return found;
            }
            t = t.getCause() == t ? null : t.getCause();
        }
        return 0;
    }

    private static long fromThrowable(Throwable t) {
        if (t instanceof RestClientResponseException rest) {
            return fromHeaders(rest.getResponseHeaders());
        }
        if (t instanceof WebClientResponseException web) {
            return fromHeaders(web.getHeaders());
        }
        Matcher m = MARKED.matcher(String.valueOf(t.getMessage()));
        return m.find() ? seconds(m.group(1)) : 0;
    }

    private static long fromHeaders(HttpHeaders headers) {
        return headers == null ? 0 : seconds(headers.getFirst(HttpHeaders.RETRY_AFTER));
    }

    /**
     * Секунды заголовка в миллисекунды; не число (дата, пусто) — 0.
     *
     * @param value значение заголовка
     * @return миллисекунды или 0
     */
    static long seconds(String value) {
        if (value == null || !value.strip().matches("\\d{1,7}")) {
            return 0;
        }
        return Long.parseLong(value.strip()) * 1000;
    }
}
