package ru.sber.cs.ai.gigame.service.scenario;

import lombok.Getter;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.buffer.DataBufferLimitException;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.FileTooLargeException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.exception.UnsupportedFormatException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRating;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.model.ScenarioVersion;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRatingRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputView;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.ScanOcrService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorTransformNode;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.FileUtils;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;
import ru.sber.cs.ai.gigame.utils.UserUtils;
import ru.sber.cs.ai.gigame.utils.ZipExtractor;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;
import ru.sber.cs.ai.gigame.service.annotate.AnnotationConfig;
import ru.sber.cs.ai.gigame.service.annotate.DocumentAnnotationService;
import ru.sber.cs.ai.gigame.service.annotate.RawFileStore;
import ru.sber.cs.ai.gigame.service.annotate.RunArtifactStore;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Сервис управления сценариями.
 * <p>
 * Реализует простые операции CRUD для сценариев, запусков и шагов.
 * Логика выполнения сценариев находится в {@link ScenarioEngine}.
 *
 * @see Scenario
 * @see ScenarioRun
 * @see ScenarioRunStep
 */
@Service
@Slf4j
@SuppressWarnings({"java:S1192", "java:S5852"}) // повторы строк; S5852: шаблон чисел использует possessive-квантификаторы, вход лимитирован
public class ScenarioService {

    /**
     * Лимиты длин полей из OpenAPI-схемы ответа списка сценариев: корп. шлюз
     * валидирует ОТВЕТЫ по схеме, и один сценарий с более длинным name или
     * description ломает выдачу списка для ВСЕХ пользователей — поэтому
     * значения мягко обрезаются при создании и обновлении.
     */
    static final int MAX_NAME_LENGTH = 64;
    static final int MAX_DESCRIPTION_LENGTH = 255;

    /**
     * Одиночное число в записи с точкой либо запятой (эталоны сумм из transform-узла).
     * Possessive-квантификаторы ({2,}+, {4,}+) исключают раскрутку при разборе длинных
     * цифровых блоков: {@code find} по частичному совпадению не рискует квадратичным
     * временем (катастрофический бэктрекинг).
     */
    private static final Pattern REFERENCE_NUMBER =
            Pattern.compile("(?<!\\d)(\\d{2,}+[.,]\\d{1,2}|\\d{4,}+)(?!\\d)");

    /** Начало текста-заглушки документа, который не удалось разобрать (скан без OCR, битый файл, архив). */
    public static final String MANUAL_CHECK_MARKER = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]";

    /** Причина отказа в запуске: документы сценария были в кэше, но сняты TTL или вытеснением. */
    public static final String DOCUMENTS_LOST_MESSAGE =
            "Документы сценария не загружены или устарели — загрузите их заново";

    /** Ошибка скачивания файла узла с разметкой, когда ZIP разметки на диске больше нет. */
    static final String ANNOTATION_ARTIFACT_MISSING =
            "Файл разметки истёк или недоступен после перезапуска — повторите прогон";

    /** Предупреждение загрузки: исходный файл не попал на склад разметки. */
    static final String ORIGINAL_NOT_STORED =
            "исходный файл не сохранён для разметки (нет места на складе исходных файлов) — разметка этого документа будет недоступна";

    /**
     * Максимум документов на прогон после распаковки архивов
     * ({@code app.scenario.max-documents-per-run}, env {@code SCENARIO_MAX_DOCUMENTS}).
     * Большие наборы догружаются частями: POST /upload?append=true.
     */
    @Value("${app.scenario.max-documents-per-run:500}")
    @Getter
    private int maxDocumentsPerRun = 500;

    /**
     * Параллельность извлечения текста документов при загрузке: большие комплекты
     * (сотни страниц PDF, OCR сканов) при последовательном парсинге превышают
     * таймауты корпоративных шлюзов.
     */
    @Value("${app.document.parse-parallelism:4}")
    private int parseParallelism = 4;

    /**
     * Предел записей одного архива вместе с вложенными, без служебных файлов ЭДО (corp26;
     * {@code app.document.max-archive-entries}, env {@code DOCUMENT_MAX_ARCHIVE_ENTRIES}). До corp26 — жёстко 500.
     */
    @Value("${app.document.max-archive-entries:5000}")
    private int maxArchiveEntries = 5000;

    /** Мегабайт — для пределов размера в сообщениях. */
    private static final long MEBIBYTE = 1024L * 1024;

    /** Сколько имён пропущенных служебных файлов попадает в предупреждение загрузки. */
    private static final int SKIPPED_NAMES_SHOWN = 5;

    /**
     * Порог длины текста PDF, ниже которого документ считается сканом без текстового слоя.
     */
    @Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars;

    /**
     * Лимит размера одного документа при загрузке в сценарий (тот же
     * {@code app.document.max-file-size}, что и у загрузки документов в БЗ):
     * WebFlux не применяет spring.servlet.multipart.*, поэтому размер проверяется кодом.
     * По умолчанию 100 МБ. Архивы (ZIP/7z) этим пределом не ограничены — только суммой запроса
     * ({@code app.scenario.max-upload-bytes}) и пределами распакованных документов.
     */
    @Value("${app.document.max-file-size:104857600}")
    private long maxFileSizeBytes = 100L * 1024 * 1024;

    /**
     * Суммарный лимит байтов файлов одного запроса загрузки
     * ({@code app.scenario.max-upload-bytes}, env {@code SCENARIO_MAX_UPLOAD_BYTES}):
     * байты всех файлов запроса держатся в heap до разбора.
     */
    @Value("${app.scenario.max-upload-bytes:314572800}")
    private long maxUploadBytes = 300L * 1024 * 1024;

    /**
     * Сколько последних версий сценария хранить (каждая — полный снимок graph_data).
     */
    @Value("${app.scenario.versions-keep:50}")
    private int versionsKeep = 50;

    private final ScenarioRepository scenarioRepository;
    private final ScenarioRunRepository scenarioRunRepository;
    private final ScenarioRunStepRepository scenarioRunStepRepository;
    private final ScenarioVersionRepository scenarioVersionRepository;
    private final ScenarioEngine scenarioEngine;
    private final DocumentService documentService;
    private final ScanOcrService scanOcrService;
    private final ScenarioRatingRepository scenarioRatingRepository;
    private final KnowledgeBaseRepository knowledgeBaseRepository;

    /**
     * Self-injection для вызова @Transactional-методов через AOP-прокси.
     * Без этого вызов {@code this.updateScenario(...)} внутри того же бина
     * не создаёт транзакцию, аннотация игнорируется.
     */
    private final AtomicReference<ScenarioService> self = new AtomicReference<>();
    /** Склад исходных файлов для разметки находок ({@code null} — разметка не настроена). */
    private RawFileStore rawFileStore;
    /** Склад ZIP размеченных документов прогона ({@code null} — разметка не настроена). */
    private RunArtifactStore runArtifactStore;
    /** Кэш документов сценария — для отказа в запуске по устаревшему комплекту ({@code null} — проверки нет). */
    private DocsTextCacheService docsTextCacheService;

    public ScenarioService(ScenarioRepository scenarioRepository,
                           ScenarioRunRepository scenarioRunRepository,
                           ScenarioRunStepRepository scenarioRunStepRepository,
                           ScenarioVersionRepository scenarioVersionRepository,
                           ScenarioEngine scenarioEngine,
                           DocumentService documentService,
                           ScanOcrService scanOcrService,
                           ScenarioRatingRepository scenarioRatingRepository,
                           KnowledgeBaseRepository knowledgeBaseRepository) {
        this.scenarioRepository = scenarioRepository;
        this.scenarioRunRepository = scenarioRunRepository;
        this.scenarioRunStepRepository = scenarioRunStepRepository;
        this.scenarioVersionRepository = scenarioVersionRepository;
        this.scenarioEngine = scenarioEngine;
        this.documentService = documentService;
        this.scanOcrService = scanOcrService;
        this.scenarioRatingRepository = scenarioRatingRepository;
        this.knowledgeBaseRepository = knowledgeBaseRepository;
    }

    @Autowired
    public void setSelf(@Lazy ScenarioService self) {
        this.self.set(self);
    }

    /**
     * Склады разметки документов (необязательны: без них загрузка и скачивание работают как прежде).
     *
     * @param rawStore      склад исходных файлов документов
     * @param artifactStore склад артефактов прогона (ZIP размеченных документов)
     */
    @Autowired(required = false)
    public void setAnnotationStores(RawFileStore rawStore, RunArtifactStore artifactStore) {
        this.rawFileStore = rawStore;
        this.runArtifactStore = artifactStore;
    }

    /**
     * Кэш документов сценария: перед созданием прогона проверяется, что документы пользователя
     * не устарели по TTL и не вытеснены (необязателен: без него запуск идёт как прежде).
     *
     * @param cache кэш документов
     */
    @Autowired(required = false)
    public void setDocsTextCacheService(DocsTextCacheService cache) {
        this.docsTextCacheService = cache;
    }

    // -------------------------------------------------------------------------
    // CRUD сценариев
    // -------------------------------------------------------------------------

    /**
     * Возвращает список всех сценариев, отсортированных по дате обновления.
     *
     * @return список сценариев пользователя
     */
    public List<ScenarioResponse> getScenarios() {
        String uid = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getScenarios", uid);
        List<Scenario> scenarios = scenarioRepository.findAllByUserIdOrSharedTrueOrderByUpdatedAtDesc(uid);
        List<UUID> ids = scenarios.stream().map(Scenario::getId).toList();
        List<ScenarioRating> allRatings = ids.isEmpty()
                ? List.of()
                : scenarioRatingRepository.findByScenarioIdIn(ids);
        Map<UUID, long[]> ratingSums = ratingSummaries(allRatings);
        Map<UUID, Integer> myRatings = myRatings(allRatings, uid);
        Map<UUID, Long> runCounts = runCounts(ids);
        return scenarios.stream()
                .map(s -> toStatisticsResponse(s, uid, ratingSums, myRatings, runCounts))
                .toList();
    }

    /**
     * Сводка оценок по сценариям: id — массив [сумма оценок, количество].
     */
    private Map<UUID, long[]> ratingSummaries(List<ScenarioRating> ratings) {
        Map<UUID, long[]> summary = new HashMap<>();
        for (ScenarioRating rating : ratings) {
            long[] acc = summary.computeIfAbsent(rating.getScenarioId(), k -> new long[2]);
            acc[0] += rating.getRating();
            acc[1]++;
        }
        return summary;
    }

    /**
     * Оценки текущего пользователя по сценариям.
     */
    private Map<UUID, Integer> myRatings(List<ScenarioRating> ratings, String uid) {
        Map<UUID, Integer> mine = new HashMap<>();
        for (ScenarioRating rating : ratings) {
            if (uid.equals(rating.getUserId())) {
                mine.put(rating.getScenarioId(), rating.getRating());
            }
        }
        return mine;
    }

    /**
     * Количество запусков по сценариям.
     */
    private Map<UUID, Long> runCounts(List<UUID> ids) {
        Map<UUID, Long> counts = new HashMap<>();
        if (ids.isEmpty()) {
            return counts;
        }
        for (Object[] row : scenarioRunRepository.countByScenarioIds(ids)) {
            counts.put((UUID) row[0], (Long) row[1]);
        }
        return counts;
    }

    /**
     * Собирает DTO сценария со статистикой (рейтинг, запуски, владение).
     */
    private ScenarioResponse toStatisticsResponse(Scenario s, String uid,
                                                  Map<UUID, long[]> ratingSums,
                                                  Map<UUID, Integer> myRatings,
                                                  Map<UUID, Long> runCounts) {
        long[] acc = ratingSums.get(s.getId());
        Double avg = acc == null ? null : Math.round(acc[0] * 10.0 / acc[1]) / 10.0;
        Long count = acc == null ? 0L : acc[1];
        return new ScenarioResponse(
                s.getId(), s.getName(), s.getDescription(), s.getCreatedAt(), s.getUpdatedAt(),
                Boolean.TRUE.equals(s.getShared()),
                uid.equals(s.getUserId()),
                avg, count,
                myRatings.get(s.getId()),
                runCounts.getOrDefault(s.getId(), 0L));
    }

    /**
     * Ставит или обновляет оценку сценария текущим пользователем (1..5).
     * Оценивать можно общие сценарии и собственные.
     *
     * @param id     UUID сценария
     * @param rating оценка от 1 до 5
     */
    @Transactional
    public void rateScenario(UUID id, int rating) {
        log.info("[{}] rateScenario, id={}, rating={}", CurrentUserHolder.getCurrentUser(), id, rating);
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Оценка должна быть от 1 до 5");
        }
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Scenario not found: " + id));
        String uid = CurrentUserHolder.getCurrentUser();
        if (!Boolean.TRUE.equals(scenario.getShared())) {
            UserUtils.checkUserId(uid, scenario.getUserId());
        }
        ScenarioRating vote = new ScenarioRating();
        vote.setScenarioId(id);
        vote.setUserId(uid);
        vote.setRating(rating);
        scenarioRatingRepository.save(vote);
    }

    /**
     * Возвращает один сценарий с полными данными графа.
     * Выбрасывает исключение, если сценарий не найден.
     *
     * @param id     UUID сценария
     * @return подробная информация о сценарии
     */
    public ScenarioDetailResponse getScenario(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getScenario, id={}", userId, id);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Scenario not found: " + id));
        if (!Boolean.TRUE.equals(scenario.getShared())) {
            // общий сценарий доступен всем на чтение и запуск; личный — только владельцу
            UserUtils.checkUserId(userId, scenario.getUserId());
        }
        return ScenarioMapper.toDetailResponse(scenario);
    }

    /**
     * Создаёт новый сценарий.
     *
     * @param name        имя сценария
     * @param description описание сценария (опционально)
     * @param graphData   данные графа (узлы и рёбра)
     * @return созданный сценарий
     */
    @Transactional
    public ScenarioResponse createScenario(String name, String description, GraphDataDto graphData) {
        log.info("[{}] createScenario, name='{}'", CurrentUserHolder.getCurrentUser(), name);
        Scenario scenario = new Scenario();
        scenario.setName(clip(name, MAX_NAME_LENGTH));
        scenario.setDescription(clip(description, MAX_DESCRIPTION_LENGTH));
        scenario.setGraphData(graphData != null ? GraphDataMapper.fromDto(graphData) : Map.of());
        scenario.setUserId(CurrentUserHolder.getCurrentUser());
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Обновляет существующий сценарий.
     *
     * @param id          UUID сценария
     * @param name        новое имя (опционально)
     * @param description новое описание (опционально)
     * @param graphData   новые данные графа (опционально)
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse updateScenario(UUID id, String name, String description,
                                           GraphDataDto graphData) {
        log.info("[{}] updateScenario, id={}", CurrentUserHolder.getCurrentUser(), id);
        return self.get().updateScenario(id, name, description, graphData, null);
    }

    /**
     * Обновляет существующий сценарий, включая признак общего доступа.
     *
     * @param id          UUID сценария
     * @param name        новое имя (опционально)
     * @param description новое описание (опционально)
     * @param graphData   новые данные графа (опционально)
     * @param shared      признак общего доступа (null — не менять)
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse updateScenario(UUID id, String name, String description,
                                           GraphDataDto graphData, Boolean shared) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] updateScenario, id={}", CurrentUserHolder.getCurrentUser(), id);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        var version = new ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenario.getId());
        version.setVersionNo(
                scenarioVersionRepository
                        .findFirstByScenarioIdOrderByVersionNoDesc(scenario.getId())
                        .map(v -> v.getVersionNo() + 1)
                        .orElse(1));
        version.setName(scenario.getName());
        version.setDescription(scenario.getDescription());
        version.setGraphData(scenario.getGraphData());
        version.setCreatedAt(OffsetDateTime.now());
        scenarioVersionRepository.save(version);
        pruneVersions(scenario.getId(), version.getVersionNo());
        if (name != null) {
            scenario.setName(clip(name, MAX_NAME_LENGTH));
        }
        if (description != null) {
            scenario.setDescription(clip(description, MAX_DESCRIPTION_LENGTH));
        }
        if (graphData != null) {
            scenario.setGraphData(GraphDataMapper.fromDto(graphData));
        }
        if (shared != null) {
            scenario.setShared(shared);
        }
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Мягкая обрезка строки до лимита схемы ответа (с многоточием).
     *
     * @param value исходное значение (может быть null)
     * @param max   максимальная длина по схеме
     * @return значение не длиннее лимита
     */
    private static String clip(String value, int max) {
        if (value == null || value.length() <= max) {
            return value;
        }
        return value.substring(0, max - 1) + "…";
    }

    /**
     * Список версий сценария (метаданные, без графов).
     *
     * @param id UUID сценария
     * @return версии от новых к старым
     */
    public List<Map<String, Object>> getVersions(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getVersions, id={}", userId, id);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        return scenarioVersionRepository.findByScenarioIdOrderByVersionNoDesc(id).stream()
                .map(v -> Map.<String, Object>of(
                        "version_no", v.getVersionNo(),
                        "name", v.getName() == null ? "" : v.getName(),
                        "created_at", v.getCreatedAt()))
                .toList();
    }

    /**
     * Восстанавливает сценарий из версии. Текущее состояние предварительно
     * сохраняется как новая версия — откат отката возможен.
     *
     * @param id        UUID сценария
     * @param versionNo номер версии
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse restoreVersion(UUID id, int versionNo) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] restoreVersion, id={}, versionNo={}", userId, id, versionNo);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        var version = scenarioVersionRepository.findByScenarioIdAndVersionNo(id, versionNo)
                .orElseThrow(() -> new NotFoundException("Версия " + versionNo + " не найдена"));
        var snapshot = new ScenarioVersion();
        snapshot.setId(UUID.randomUUID());
        snapshot.setScenarioId(scenario.getId());
        snapshot.setVersionNo(
                scenarioVersionRepository
                        .findFirstByScenarioIdOrderByVersionNoDesc(scenario.getId())
                        .map(v -> v.getVersionNo() + 1)
                        .orElse(1));
        snapshot.setName(scenario.getName());
        snapshot.setDescription(scenario.getDescription());
        snapshot.setGraphData(scenario.getGraphData());
        snapshot.setCreatedAt(OffsetDateTime.now());
        scenarioVersionRepository.save(snapshot);
        pruneVersions(scenario.getId(), snapshot.getVersionNo());
        scenario.setName(version.getName());
        scenario.setDescription(version.getDescription());
        scenario.setGraphData(version.getGraphData());
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Возобновляет упавший прогон с места сбоя: создаёт новый прогон, восстанавливая
     * результаты завершённых LLM-узлов из шагов исходного (без повторных обращений
     * к GigaChat за уже полученными ответами).
     *
     * @param runId  идентификатор упавшего прогона
     * @return поток SSE-событий нового прогона
     */
    public Flux<ServerSentEvent<Map<String, Object>>> resumeScenarioRun(UUID runId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] resumeScenarioRun, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        ScenarioRun oldRun = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new IllegalArgumentException("Запуск сценария не найден: " + runId));
        Scenario model = scenarioRepository.findById(oldRun.getScenarioId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        // общий сценарий может запускать любой пользователь, но возобновлять — только свой прогон:
        // шаги исходного прогона несут тексты входных документов его автора
        if (!Boolean.TRUE.equals(model.getShared())) {
            UserUtils.checkUserId(userId, model.getUserId());
        }
        ScenarioRunAccess.checkAccess(oldRun, model.getUserId(), userId);
        // идущий или успешный прогон не возобновляется: повтор задвоил бы его работу
        if (!"failed".equals(oldRun.getStatus())) {
            throw new ScenarioException("Возобновить можно только прогон, завершившийся ошибкой");
        }
        GraphDataDto graphData = GraphDataMapper.toDto(model.getGraphData());
        // базы знаний и под-сценарии графа по UUID: чужие личные недоступны запускающему
        ScenarioAccessValidator.validate(graphData, oldRun.getScenarioId(), userId,
                scenarioRepository::findById, knowledgeBaseRepository::findById);
        // до создания нового прогона: сценарий и его под-сценарии могли быть изменены под более новый дистрибутив
        ScenarioOperationsValidator.validate(graphData, oldRun.getScenarioId(), scenarioRepository::findById);
        List<ScenarioRunStep> oldSteps = scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(runId);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(oldRun.getScenarioId());
        run.setUserId(ScenarioRunAccess.normalizeUser(userId));
        run.setStatus("running");
        run.setStartedAt(OffsetDateTime.now());
        run = scenarioRunRepository.save(run);
        // оригиналы для разметки: склад ключа, а если он очищен новой загрузкой — снимок упавшего прогона
        snapshotOriginals(run, userId, runId);
        return scenarioEngine.resumeScenario(run, graphData, oldSteps, userId);
    }

    /**
     * Создаёт копию сценария с суффиксом "(копия)".
     *
     * @param id UUID сценария
     * @return дубликат сценария
     */
    @Transactional
    public ScenarioResponse duplicateScenario(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] duplicateScenario, id={}", CurrentUserHolder.getCurrentUser(), id);
        Scenario original = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        if (!Boolean.TRUE.equals(original.getShared())) {
            // общий сценарий может клонировать себе любой пользователь
            UserUtils.checkUserId(userId, original.getUserId());
        }
        Scenario copy = new Scenario();
        copy.setName(original.getName() + " (копия)");
        copy.setDescription(original.getDescription());
        copy.setGraphData(original.getGraphData());
        copy.setUserId(CurrentUserHolder.getCurrentUser());
        copy = scenarioRepository.save(copy);
        return ScenarioMapper.toResponse(copy);
    }

    /**
     * Оставляет не больше {@code app.scenario.versions-keep} последних версий сценария:
     * каждая версия — полный снимок graph_data, и без ограничения таблица росла
     * с каждым сохранением.
     *
     * @param scenarioId      идентификатор сценария
     * @param latestVersionNo номер только что сохранённой версии
     */
    private void pruneVersions(UUID scenarioId, int latestVersionNo) {
        int maxDeletable = latestVersionNo - Math.max(1, versionsKeep);
        if (maxDeletable > 0) {
            scenarioVersionRepository.deleteOldVersions(scenarioId, maxDeletable);
        }
    }

    /**
     * Удаляет сценарий по идентификатору.
     *
     * @param id UUID сценария
     */
    @Transactional
    public void deleteScenario(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] deleteScenario, id={}", CurrentUserHolder.getCurrentUser(), id);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        // одним DELETE: прогоны и шаги (JSONB с текстами документов) удаляет FK ON DELETE CASCADE в БД,
        // JPA-каскад грузил бы их все в память
        scenarioRepository.deleteScenarioById(id);
    }

    // -------------------------------------------------------------------------
    // Запросы запусков сценариев
    // -------------------------------------------------------------------------

    /**
     * Возвращает список запусков текущего пользователя для указанного сценария.
     * Общий сценарий запускают разные пользователи — каждый видит только свои
     * запуски; владелец сценария дополнительно видит старые запуски без автора.
     *
     * @param scenarioId UUID сценария
     * @return список запусков, отсортированных по дате начала
     */
    public List<ScenarioRunResponse> getScenarioRuns(UUID scenarioId) {
        var userId = ScenarioRunAccess.normalizeUser(CurrentUserHolder.getCurrentUser());
        log.info("[{}] getScenarioRuns, scenarioId={}", CurrentUserHolder.getCurrentUser(), scenarioId);
        Scenario scenario = scenarioRepository.findById(scenarioId)
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + scenarioId));
        List<ScenarioRun> runs = userId.equals(scenario.getUserId())
                ? scenarioRunRepository.findOwnerRuns(scenarioId, userId)
                : scenarioRunRepository.findByScenarioIdAndUserIdOrderByStartedAtDesc(scenarioId, userId);
        return runs.stream()
                .map(ScenarioMapper::toRunResponse)
                .toList();
    }

    /**
     * Возвращает детальную информацию о запуске сценария со всеми шагами.
     *
     * @param runId  UUID запуска
     * @return детальная информация о запуске
     */
    public ScenarioRunDetailResponse getScenarioRun(UUID runId) {
        log.info("[{}] getScenarioRun, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        return buildRunDetail(runId, true);
    }

    /**
     * Собирает детальную информацию о запуске с проверкой доступа.
     *
     * @param runId        UUID запуска
     * @param schemaLimits {@code true} — REST-ответ по схеме: итог до 500 000 символов,
     *                     ошибки шагов до 255, не больше 100 шагов (первые 99 и последний);
     *                     {@code false} — DOCX-экспорт: полный итог и все шаги
     * @return детальная информация о запуске
     * @throws NotFoundException запуск или его сценарий не найден
     */
    private ScenarioRunDetailResponse buildRunDetail(UUID runId, boolean schemaLimits) {
        var userId = CurrentUserHolder.getCurrentUser();
        // NotFoundException — 404: прогоны удаляются вместе со сценарием (ON DELETE CASCADE),
        // и IllegalArgumentException отдавал на карточку прогона удалённого сценария 500
        ScenarioRun run = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new NotFoundException("Запуск сценария не найден: " + runId));
        Scenario scenario = scenarioRepository.findById(run.getScenarioId())
                .orElseThrow(() -> new NotFoundException("Сценарий не найден: " + run.getScenarioId()));
        ScenarioRunAccess.checkAccess(run, scenario.getUserId(), userId);
        List<ScenarioRunStep> steps = scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(run.getId());
        List<ScenarioRunStepResponse> stepResponses = schemaLimits
                ? SchemaLimitUtils.firstItemsAndLast(steps, ScenarioMapper.RUN_STEPS_MAX_ITEMS).stream()
                        .map(ScenarioMapper::toStepResponse).toList()
                : steps.stream().map(ScenarioMapper::toExportStepResponse).toList();
        return new ScenarioRunDetailResponse(
                run.getId(),
                run.getScenarioId(),
                run.getStatus(),
                run.getInputDocumentIds(),
                schemaLimits ? ScenarioMapper.clipRunResult(run.getResult()) : run.getResult(),
                run.getStartedAt(),
                run.getCompletedAt(),
                stepResponses
        );
    }

    /**
     * Сохраняет запуск сценария.
     *
     * @param run запуск сценария
     * @return сохраненный запуск
     */
    @Transactional
    @SuppressWarnings("unused")
    public ScenarioRun saveScenarioRun(ScenarioRun run) {
        return scenarioRunRepository.save(run);
    }

    /**
     * Проверяет, что текущий пользователь может управлять прогоном и читать его
     * данные (продолжение, отключение пошагового режима, остановка, вопросы
     * агента): автор прогона, для старого прогона без автора — владелец сценария.
     *
     * @param runId UUID запуска
     * @throws NotFoundException     запуск не найден
     */
    public void checkRunAccess(UUID runId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] checkRunAccess, runId={}", userId, runId);
        ScenarioRun run = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new NotFoundException("Запуск сценария не найден: " + runId));
        String ownerId = run.getUserId() != null
                ? null
                : scenarioRepository.findById(run.getScenarioId()).map(Scenario::getUserId).orElse(null);
        ScenarioRunAccess.checkAccess(run, ownerId, userId);
    }

    public Flux<ServerSentEvent<Map<String, Object>>> runScenario(UUID id, Boolean stepMode) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] runScenario, scenarioId={}, stepMode={}", CurrentUserHolder.getCurrentUser(), id, stepMode);
        var model = scenarioRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        // общий сценарий доступен для запуска всем пользователям
        if (!Boolean.TRUE.equals(model.getShared())) {
            UserUtils.checkUserId(userId, model.getUserId());
        }
        var scenario = ScenarioMapper.toDetailResponse(model);
        // базы знаний и под-сценарии графа по UUID: чужие личные недоступны запускающему
        ScenarioAccessValidator.validate(scenario.graphData(), id, userId,
                scenarioRepository::findById, knowledgeBaseRepository::findById);
        // до создания прогона: неизвестная операция (и в под-сценариях) иначе роняла бы прогон уже после дорогих LLM-узлов
        ScenarioOperationsValidator.validate(scenario.graphData(), id, scenarioRepository::findById);
        // до создания прогона: комплект, снятый из кэша по TTL/вытеснению, иначе давал «успешный» прогон без документов
        rejectIfDocumentsLost(scenario.graphData(), id, userId);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(id);
        run.setUserId(ScenarioRunAccess.normalizeUser(userId));
        run.setStatus("running");
        run.setStartedAt(OffsetDateTime.now());
        run = scenarioRunRepository.save(run);

        if (Boolean.TRUE.equals(stepMode)) {
            scenarioEngine.enableStepMode(run.getId().toString());
        }

        run = scenarioRunRepository.save(run);
        // оригиналы для разметки — в снимок прогона, как и тексты документов при приёме команды
        snapshotOriginals(run, userId, null);
        return scenarioEngine.executeScenario(run, scenario.graphData(), userId);
    }

    /**
     * Отказ в запуске, если документы пользователя по сценарию были в кэше, но сняты TTL или вытеснением
     * ({@link DocsTextCacheService#isEvicted(UUID)}), а входной узел графа ожидает документы (у него есть
     * потомки). Раньше такой прогон принимался со снимком из нуля документов, входной узел не активировал
     * детей и прогон завершался COMPLETED с пустым итогом — пользователь не видел причины. Сценарий, по
     * которому загрузок не было (в том числе после рестарта сервиса — кэш и задачи в памяти), запускается
     * как раньше. Проверка идёт до создания прогона, отказ — тем же кадром, что у проверки операций.
     *
     * @param graphData  граф сценария
     * @param scenarioId идентификатор сценария
     * @param userId     запускающий пользователь (null — аноним)
     * @throws ScenarioException если документы устарели
     */
    void rejectIfDocumentsLost(GraphDataDto graphData, UUID scenarioId, String userId) {
        if (docsTextCacheService == null || !inputNodeExpectsDocuments(graphData)) {
            return;
        }
        UUID key = DocsTextCacheService.scenarioKey(scenarioId, userId);
        if (docsTextCacheService.isEvicted(key) && docsTextCacheService.getCachedDocumentTexts(key).isEmpty()) {
            log.warn("[{}] Запуск сценария {} отклонён: документы по ключу {} сняты из кэша (TTL/вытеснение)",
                    userId, scenarioId, key);
            throw new ScenarioException(DOCUMENTS_LOST_MESSAGE);
        }
    }

    /**
     * Входной узел графа ожидает документы: у него есть исходящие рёбра (без документов
     * входной узел не активирует потомков, и прогон завершается пустым).
     *
     * @param graphData граф сценария
     * @return {@code true}, если у узла типа «Вход» есть потомки
     */
    static boolean inputNodeExpectsDocuments(GraphDataDto graphData) {
        if (graphData == null || graphData.nodes() == null || graphData.edges() == null) {
            return false;
        }
        Set<String> inputIds = graphData.nodes().stream()
                .filter(n -> ScenarioNodeType.INPUT_NODE.toString().equals(n.type()))
                .map(NodeDto::id)
                .collect(Collectors.toSet());
        return graphData.edges().stream().anyMatch(e -> inputIds.contains(e.source()));
    }

    public List<String> getDocumentsText(List<FilePart> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        log.info("[{}] getDocumentsText, files={}", CurrentUserHolder.getCurrentUser(), files.size());
        return getDocuments(files, uploadEvents).stream().map(DocumentText::text).toList();
    }

    /**
     * Превращает загруженные файлы в документы для прогона сценария.
     * <p>
     * ZIP- и 7z-архивы распаковываются ({@link ZipExtractor}): служебные файлы ЭДО
     * отфильтровываются, а имя каждого документа включает путь внутри архива.
     * PDF без текстового слоя (скан) не отбрасывается — его текст заменяется
     * маркером «ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА», который проходит по конвейеру
     * до итоговой таблицы. Извлечение текста идёт параллельно
     * ({@code app.document.parse-parallelism}) с сохранением порядка документов.
     *
     * @param files        загруженные файлы (в т.ч. ZIP/7z)
     * @param uploadEvents накопитель SSE-событий прогресса (может быть {@code null})
     * @return документы: имя + извлечённый текст
     */
    public List<DocumentText> getDocuments(List<FilePart> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        log.info("[{}] getDocuments, files={}", CurrentUserHolder.getCurrentUser(), files.size());
        return parseFiles(readFiles(files), uploadEvents);
    }

    /**
     * Загруженный файл до разбора: имя + байты содержимого (архив ещё не распакован).
     */
    public record RawFile(String name, byte[] content) {
        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof RawFile rawFile)) {
                return false;
            }
            return name.equals(rawFile.name) && java.util.Arrays.equals(content, rawFile.content);
        }

        @Override
        public int hashCode() {
            int result = name.hashCode();
            result = 31 * result + java.util.Arrays.hashCode(content);
            return result;
        }

        @Override
        @NonNull
        public String toString() {
            return "RawFile[" + "name=" + name + ", content=" + java.util.Arrays.toString(content) + ']';
        }
    }

    /**
     * Быстрая фаза загрузки: читает байты всех файлов из HTTP-запроса.
     * Медленный разбор ({@link #parseFiles}) можно выполнять уже вне запроса —
     * на этом построен асинхронный режим загрузки
     * ({@link ScenarioUploadTaskService}).
     *
     * Суммарный размер файлов запроса ограничен {@code app.scenario.max-upload-bytes}
     * (422 при превышении — большие наборы догружаются партиями, append=true).
     * Файл, который разбирается как документ, больше {@code app.document.max-file-size} — 413 с именем
     * файла ({@link FileTooLargeException}). Архив (ZIP/7z) этим пределом не ограничен:
     * его держат сумма запроса и пределы распакованных документов (422 на разборе), иначе архив
     * комплекта больше предела документа (55,5 МБ при 50 МБ) отклонялся бы целиком.
     *
     * @param files загруженные файлы
     * @return файлы: имя + содержимое
     * @throws FileTooLargeException файл (не архив) больше предела размера одного документа
     */
    public List<RawFile> readFiles(List<FilePart> files) {
        List<RawFile> raw = new ArrayList<>();
        long total = 0;
        for (FilePart file : files) {
            String filename = FileUtils.getFilename(file);
            byte[] content = readFileContent(file, filename);
            total += content.length;
            if (total > maxUploadBytes) {
                throw new FileException("Суммарный размер файлов запроса превышает лимит "
                        + (maxUploadBytes / (1024 * 1024)) + " МБ (на файле «" + filename
                        + "») — загрузите файлы партиями: POST /upload?append=true");
            }
            raw.add(new RawFile(filename, content));
        }
        return raw;
    }

    /**
     * Медленная фаза загрузки: распаковка архивов и параллельное извлечение
     * текста документов (правила — см. {@link #getDocuments}).
     *
     * @param files        файлы: имя + байты содержимого
     * @param uploadEvents накопитель SSE-событий прогресса (может быть {@code null})
     * @return документы: имя + извлечённый текст
     */
    public List<DocumentText> parseFiles(List<RawFile> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        List<RawDocument> raws = collectRawDocuments(files, uploadEvents);
        List<DocumentText> documents = parseAllParallel(raws, uploadEvents);
        if (documents.size() > maxDocumentsPerRun) {
            throw new FileException("Слишком много документов после распаковки архивов: "
                    + documents.size() + ". Максимум: " + maxDocumentsPerRun);
        }
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_done", "count", documents.size()))
                    .build());
        }
        return documents;
    }

    /**
     * Собирает сырые документы: архивы (ZIP/7z) распаковываются, остальные
     * файлы попадают в накопитель как есть. Служебные файлы Windows, macOS и Office, загруженные россыпью
     * ({@link ZipExtractor#isOsJunk}: «~$Договор.docx», desktop.ini, Thumbs.db, .DS_Store…), в разбор не идут —
     * о них одно предупреждение загрузки.
     *
     * @param files        файлы: имя + содержимое
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return сырые документы для извлечения текста
     */
    private List<RawDocument> collectRawDocuments(List<RawFile> files,
                                                  List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        List<RawDocument> raws = new ArrayList<>();
        List<String> osJunk = new ArrayList<>();
        for (int i = 0; i < files.size(); i++) {
            RawFile file = files.get(i);
            emitUploadProgress(uploadEvents, file.name(), i + 1, files.size());
            if (isArchive(file.name())) {
                appendArchiveDocuments(raws, file.name(), file.content(), uploadEvents);
            } else if (ZipExtractor.isOsJunk(file.name())) {
                osJunk.add(file.name());
            } else {
                raws.add(new RawDocument(file.name(), file.content(), null));
            }
        }
        warnSkippedOsJunk(osJunk, uploadEvents);
        return raws;
    }

    /**
     * Предупреждение загрузки о служебных файлах, пропущенных среди загруженных россыпью: число и первые имена.
     *
     * @param names        имена пропущенных файлов
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     */
    private void warnSkippedOsJunk(List<String> names, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        if (names.isEmpty()) {
            return;
        }
        String shown = String.join(", ", names.subList(0, Math.min(names.size(), SKIPPED_NAMES_SHOWN)));
        String more = names.size() > SKIPPED_NAMES_SHOWN ? ", …" : "";
        log.info("[{}] Загрузка: пропущено служебных файлов ОС/Office — {} ({}{})", CurrentUserHolder.getCurrentUser(),
                names.size(), shown, more);
        emitUploadWarning(uploadEvents, names.get(0), "пропущено служебных файлов Windows/macOS/Office: " + names.size()
                + " (" + shown + more + ") — это не документы, в прогон не идут");
    }

    /**
     * Архив, который при разборе распаковывается (ZIP или 7z по расширению имени, без учёта регистра).
     *
     * @param filename имя файла
     * @return true — архив
     */
    private static boolean isArchive(String filename) {
        String lower = filename.toLowerCase();
        return lower.endsWith(".zip") || lower.endsWith(".7z");
    }

    /**
     * Отправляет SSE-событие прогресса загрузки файла (если накопитель задан).
     *
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @param filename     имя загружаемого файла
     * @param current      номер текущего файла (с 1)
     * @param total        общее количество файлов
     */
    private void emitUploadProgress(List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                    String filename, int current, int total) {
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_progress",
                            "file", filename, "current", current, "total", total))
                    .build());
        }
    }

    /**
     * Читает содержимое загруженного файла в массив байт с проверкой предела по ходу чтения:
     * документ — не больше {@code app.document.max-file-size} (413 с именем файла), архив — не больше суммы
     * запроса {@code app.scenario.max-upload-bytes} (422). Раньше файл сначала целиком попадал в heap
     * и только потом сравнивался с пределом.
     *
     * @param file     загруженный файл
     * @param filename имя файла (для сообщения об ошибке)
     * @return содержимое файла
     * @throws FileTooLargeException документ больше предела размера одного документа
     * @throws FileException         архив больше суммы запроса либо файл не читается
     */
    private byte[] readFileContent(FilePart file, String filename) {
        boolean archive = isArchive(filename);
        long limit = archive ? maxUploadBytes : maxFileSizeBytes;
        try (InputStream inputStream = FileUtils.toInputStream(file, limit).block()) {
            if (inputStream == null) {
                throw new FileException("Не удалось прочитать файл: " + filename);
            }
            return inputStream.readAllBytes();
        } catch (DataBufferLimitException e) {
            if (archive) {
                throw new FileException("Суммарный размер файлов запроса превышает лимит "
                        + (maxUploadBytes / (1024 * 1024)) + " МБ (на файле «" + filename
                        + "») — загрузите файлы партиями: POST /upload?append=true", e);
            }
            throw new FileTooLargeException(filename, maxFileSizeBytes);
        } catch (Exception e) {
            throw new FileException("Не удалось прочитать файл: " + filename, e);
        }
    }

    /**
     * Сырой документ до извлечения текста: имя + байты содержимого. Документ-маркер
     * ({@code marker != null}) не разбирается — его текст уже готов (архив не распакован).
     */
    private record RawDocument(String name, byte[] content, String marker) {
        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof RawDocument rawDocument)) {
                return false;
            }
            return name.equals(rawDocument.name) && java.util.Arrays.equals(content, rawDocument.content)
                    && java.util.Objects.equals(marker, rawDocument.marker);
        }

        @Override
        public int hashCode() {
            int result = name.hashCode();
            result = 31 * result + java.util.Arrays.hashCode(content);
            return 31 * result + java.util.Objects.hashCode(marker);
        }

        @Override
        @NonNull
        public String toString() {
            return "RawDocument[" + "name=" + name + ", content=" + java.util.Arrays.toString(content)
                    + ", marker=" + marker + ']';
        }
    }

    /**
     * Распаковывает ZIP/7z-архив и добавляет его файлы в накопитель сырых документов.
     * Проблемный архив (пароль, лимиты, повреждение, нет поддерживаемых документов)
     * НЕ роняет партию: вместо него в прогон идёт документ-маркер «архив не распакован»
     * с причиной, а в лог загрузки — предупреждение. Пропущенные файлы неподдерживаемого
     * формата и архивы глубже лимита вложенности тоже дают предупреждение.
     *
     * @param raws         накопитель сырых документов прогона (пополняется)
     * @param filename     имя архива
     * @param content      содержимое архива
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     */
    private void appendArchiveDocuments(List<RawDocument> raws, String filename, byte[] content,
                                        List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        ZipExtractor.ExtractionResult extraction;
        try {
            extraction = ZipExtractor.extract(filename, content, maxArchiveEntries);
        } catch (FileException e) {
            log.warn("Архив «{}» не распакован ({}) — документ-маркер", filename, e.getMessage());
            raws.add(archiveMarker(filename, e.getMessage(), uploadEvents));
            return;
        }
        if (extraction.files().isEmpty()) {
            raws.add(archiveMarker(filename, "архив не содержит поддерживаемых документов"
                    + (extraction.lostCount() > 0 ? " (" + String.join(", ", extraction.skippedNames()) + ")" : ""), uploadEvents));
            return;
        }
        String lost = extraction.lostWarning(filename);
        if (lost != null) {
            emitUploadWarning(uploadEvents, filename, lost);
        }
        for (var extracted : extraction.files()) {
            raws.add(new RawDocument(extracted.name(), extracted.content(), null));
        }
    }

    /** Документ-маркер вместо нераспакованного архива + предупреждение загрузки. */
    private RawDocument archiveMarker(String filename, String reason,
                                      List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        emitUploadWarning(uploadEvents, filename, "архив не распакован: " + reason);
        return new RawDocument(filename, new byte[0], MANUAL_CHECK_MARKER + " Архив «" + filename
                + "» не распакован: " + reason + ". Документы архива в прогон не попали — проверьте архив вручную.");
    }

    /**
     * Извлекает текст всех документов параллельно (пул
     * {@code app.document.parse-parallelism} потоков) с сохранением порядка:
     * синхронная загрузка больших комплектов (сотни страниц PDF, OCR сканов)
     * при последовательном парсинге превышает таймауты корпоративных шлюзов.
     *
     * @param raws         документы: имя + сырое содержимое (текст ещё не извлечён)
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return распарсенные документы в исходном порядке
     */
    private List<DocumentText> parseAllParallel(List<RawDocument> raws,
                                                List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        List<DocumentText> documents = new ArrayList<>();
        List<ServerSentEvent<Map<String, Object>>> events = uploadEvents == null
                ? null
                : Collections.synchronizedList(uploadEvents);
        // NOSONAR java:S2095 — пул закрывается через pool.shutdownNow() в finally ниже;
        // try-with-resources недоступен: ExecutorService не реализует AutoCloseable на Java 17.
        ExecutorService pool = Executors.newFixedThreadPool(
                Math.max(1, Math.min(parseParallelism, Math.max(raws.size(), 1))));
        try {
            List<Callable<DocumentText>> tasks = new ArrayList<>();
            for (RawDocument raw : raws) {
                tasks.add(parseTask(raw, events));
            }
            for (Future<DocumentText> future : pool.invokeAll(tasks)) {
                documents.add(future.get());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new FileException("Обработка файлов прервана", e);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            // причина обязана попасть в лог: Error (OOM и т.п.) минует мягкую
            // деградацию parseDocument, и без стека инцидент не диагностируется
            log.error("Ошибка обработки файлов при загрузке", cause);
            throw cause instanceof RuntimeException runtime
                    ? runtime
                    : new FileException("Ошибка обработки файлов", cause);
        } finally {
            pool.shutdownNow();
        }
        return documents;
    }

    /**
     * Задача парсинга одного документа: маркированный (уже извлечённый ранее) проходит коротким путём.
     *
     * @param raw    документ (имя, сырое содержимое, извлекающий маркер)
     * @param events накопитель SSE-событий (может быть {@code null})
     * @return задача с текстом документа
     */
    private Callable<DocumentText> parseTask(RawDocument raw,
                                             List<ServerSentEvent<Map<String, Object>>> events) {
        return () -> raw.marker() != null
                ? markerDocument(raw.name(), raw.marker(), events)
                : parseDocument(raw.name(), raw.content(), events);
    }

    /**
     * Парсит один документ. Нечитаемый файл (повреждён, XML-бомба внутри docx,
     * неподдержанное содержимое, формат doc/rtf/odt) НЕ роняет загрузку всего комплекта — документ
     * получает маркер ручной проверки и проходит по конвейеру, а в лог загрузки
     * уходит предупреждение. Документ из архива больше {@code app.document.max-file-size}
     * тоже становится маркером (его байты уже в heap, а отказ ронял всю партию после разбора
     * и OCR остальных документов); прямые файлы больше предела отсекает {@link #readFiles} (413).
     */
    private DocumentText parseDocument(String filename, byte[] content,
                                       List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        if (content.length > maxFileSizeBytes) {
            long limitMb = maxFileSizeBytes / MEBIBYTE;
            log.warn("Файл «{}» из архива больше предела {} МБ ({} МБ) — маркер ручной проверки", filename, limitMb,
                    content.length / MEBIBYTE);
            return unreadableDocument(filename, uploadEvents, "файл больше " + limitMb + " МБ — не разобран, требуется ручная проверка",
                    "файл больше предела " + limitMb + " МБ (" + (content.length / MEBIBYTE) + " МБ) и не разобран");
        }
        String text;
        String contentType;
        try {
            contentType = FileUtils.detectContentType(filename, content);
            documentService.rejectOoxmlBomb(filename, contentType, content);
            text = documentService.parseText(new ByteArrayInputStream(content), contentType);
        } catch (UnsupportedFormatException e) {
            // честная причина вместо «повреждён»: пользователь пересохраняет файл, а не ищет повреждение
            log.warn("Файл «{}» не обработан: {} — маркер ручной проверки", filename, e.getMessage());
            return unreadableDocument(filename, uploadEvents, e.getMessage() + " — требуется ручная проверка", e.getMessage());
        } catch (Exception e) {
            log.warn("Не удалось обработать файл «{}» ({}) — маркер ручной проверки",
                    filename, e.getMessage());
            return unreadableDocument(filename, uploadEvents,
                    "файл не обработан (повреждён или неподдерживаемое содержимое) — требуется ручная проверка",
                    "файл повреждён или содержит неподдерживаемое содержимое");
        }
        text = recognizeIfNeeded(filename, contentType, content, text, uploadEvents);
        if (text.startsWith(DocumentService.ENCODING_MARKER)) {
            emitUploadWarning(uploadEvents, filename, "кодировка текстового файла не распознана — текст может быть искажён");
        }
        if (text.isBlank()) {
            // любой тип файла (docx/xlsx/txt/…): пустой текст после разбора раньше молча уходил в прогон
            log.warn("Документ «{}» пуст после разбора", filename);
            emitUploadWarning(uploadEvents, filename, "документ пуст: " + filename);
        }
        emitUploadEvent(uploadEvents, Map.of("type", "upload_parsed", "file", filename, "chars", text.length()));
        return new DocumentText(filename, text, content);
    }

    /**
     * Складывает исходные файлы разобранных документов для разметки находок ({@link RawFileStore});
     * без склада (тесты, сервис без Spring) ничего не делает. Документ, не попавший на склад (предел объёма,
     * нет места на диске), — только предупреждение в лог: загрузка не падает, разметка документа будет недоступна.
     *
     * @param key       ключ кэша документов сценария пользователя
     * @param documents разобранные документы партии
     */
    public void storeOriginals(UUID key, List<DocumentText> documents) {
        storeOriginals(key, documents, null);
    }

    /**
     * То же, что {@link #storeOriginals(UUID, List)}, с событием {@code upload_warning} на каждый документ,
     * не попавший на склад: пометка видна в статусе загрузки (GET upload-status).
     *
     * @param key          ключ кэша документов сценария пользователя
     * @param documents    разобранные документы партии
     * @param uploadEvents события загрузки ({@code null} — без событий)
     */
    public void storeOriginals(UUID key, List<DocumentText> documents,
                               List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        if (rawFileStore == null) {
            return;
        }
        for (DocumentText document : documents) {
            if (!rawFileStore.save(key, document.filename(), document.text(), document.content())) {
                emitUploadWarning(uploadEvents, document.filename(), ORIGINAL_NOT_STORED);
            }
        }
    }

    /**
     * Закрепляет оригиналы документов за прогоном ({@link RawFileStore#snapshotForRun}): новая загрузка без
     * догрузки или чистка склада во время долгого прогона не лишают его разметки. Без склада ничего не делает.
     *
     * @param run           принятый прогон
     * @param userId        запускающий пользователь (ключ кэша документов)
     * @param previousRunId прогон-предшественник при возобновлении ({@code null} — нет)
     */
    private void snapshotOriginals(ScenarioRun run, String userId, UUID previousRunId) {
        if (rawFileStore != null) {
            rawFileStore.snapshotForRun(DocsTextCacheService.scenarioKey(run.getScenarioId(), userId), run.getId(), previousRunId);
        }
    }

    /**
     * Очищает склад исходных файлов ключа (новая загрузка без догрузки — вместе с кэшем текстов).
     *
     * @param key ключ кэша документов сценария пользователя
     */
    public void clearOriginals(UUID key) {
        if (rawFileStore != null) {
            rawFileStore.clear(key);
        }
    }

    /**
     * Документ-маркер ручной проверки вместо файла, который не разобран, плюс предупреждение загрузки.
     *
     * @param filename     имя файла
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @param warning      текст предупреждения загрузки
     * @param reason       причина в тексте маркера
     * @return документ-маркер
     */
    private DocumentText unreadableDocument(String filename, List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                            String warning, String reason) {
        emitUploadWarning(uploadEvents, filename, warning);
        return new DocumentText(filename, MANUAL_CHECK_MARKER + " Документ «" + filename + "» не удалось обработать: "
                + reason + ". Автоматический анализ невозможен — проверьте документ вручную.");
    }

    /**
     * Распознавание по типу: изображение — как одностраничный скан; PDF без текстового слоя или с половиной
     * страниц-картинок — скан; PDF с отдельными страницами-картинками — смешанный; остальное — как есть.
     *
     * @param filename     имя файла
     * @param contentType  тип контента
     * @param content      содержимое файла
     * @param text         текст, извлечённый парсером
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return текст документа
     */
    private String recognizeIfNeeded(String filename, String contentType, byte[] content, String text,
                                     List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        if ("image".equals(contentType)) {
            return handleImage(filename, content, uploadEvents);
        }
        if (!"pdf".equals(contentType)) {
            return text;
        }
        if (text.strip().length() < minParsedChars || documentService.isScanPdf(content, text)) {
            return handleScanPdf(filename, content, uploadEvents, text);
        }
        return handleMixedPdf(filename, content, uploadEvents, text);
    }

    /**
     * Изображение (фото акта, скан в jpg/png/tiff/bmp): оборачивается в одностраничный PDF и распознаётся
     * через GigaChat как скан; при выключенном OCR, нечитаемой картинке или сбое распознавания — маркер
     * ручной проверки. Раньше такие файлы получали маркер «повреждён», а из архива выпадали молча.
     *
     * @param filename     имя файла
     * @param content      содержимое изображения
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return распознанный текст либо маркер ручной проверки
     */
    private String handleImage(String filename, byte[] content, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        byte[] pdf;
        try {
            pdf = documentService.imageToPdf(content, filename);
        } catch (IOException | RuntimeException e) {
            log.warn("Изображение «{}» не читается ({}) — маркер ручной проверки", filename, e.getMessage());
            return unreadableDocument(filename, uploadEvents, "изображение не читается — требуется ручная проверка",
                    "изображение повреждено или его формат не поддерживается").text();
        }
        String recognized = recognizeScan(filename, pdf, uploadEvents, "", false);
        if (recognized != null) {
            return recognized;
        }
        log.warn("Изображение «{}» не распознано (OCR выключен или не удался) — маркер ручной проверки", filename);
        emitUploadWarning(uploadEvents, filename, "изображение не распознано (OCR выключен или не удался) — требуется ручная проверка");
        return MANUAL_CHECK_MARKER + " Документ «" + filename + "» не распознан: изображение без текстового слоя (скан). "
                + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
    }

    /**
     * PDF без текстового слоя: при включённом OCR ({@code app.document.ocr-via-gigachat})
     * скан распознаётся через файловое хранилище GigaChat, при выключенном или при
     * ошибке распознавания — маркер ручной проверки (прежнее поведение).
     *
     * @param filename     имя файла
     * @param content      содержимое PDF
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @param parsed       текстовый слой (штамп ЭДО), добавляется к распознанному тексту
     * @return распознанный текст либо маркер ручной проверки
     */
    private String handleScanPdf(String filename, byte[] content,
                                 List<ServerSentEvent<Map<String, Object>>> uploadEvents, String parsed) {
        String recognized = recognizeScan(filename, content, uploadEvents, parsed, false);
        if (recognized != null) {
            return recognized;
        }
        log.warn("PDF без текстового слоя (скан): {} — документ помечен для ручной проверки", filename);
        emitUploadWarning(uploadEvents, filename,
                "PDF без текстового слоя (скан) — требуется ручная проверка");
        return MANUAL_CHECK_MARKER + " Документ «" + filename
                + "» не распознан: PDF без текстового слоя (скан). "
                + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
    }

    /**
     * Распознавание скана через GigaChat с предупреждением по результату
     * (отказ модели, пересказ целиком, нераспознанные страницы, обрыв ответа;
     * у смешанного PDF — перечень распознанных страниц).
     *
     * @param mixed смешанный PDF: в предупреждении перечисляются распознанные страницы
     * @return распознанный текст со штампом ЭДО либо {@code null}, если OCR выключен или не удался
     */
    private String recognizeScan(String filename, byte[] content,
                                 List<ServerSentEvent<Map<String, Object>>> uploadEvents, String parsed, boolean mixed) {
        if (!scanOcrService.isEnabled()) {
            return null;
        }
        emitUploadEvent(uploadEvents, Map.of("type", "upload_ocr", "file", filename));
        try {
            // ход постраничного OCR — в статус загрузки: иначе счётчик документов «застывает» на десятки минут
            String recognized = scanOcrService.recognize(filename, content, (file, page, total) ->
                    emitUploadEvent(uploadEvents, Map.of("type", "upload_ocr_page", "file", file, "page", page, "total", total)));
            emitUploadWarning(uploadEvents, filename, ScanOcrService.uploadWarning(recognized, mixed));
            // документ, который модель отказалась распознавать, — маркер ручной проверки без штампа
            return recognized.startsWith(MANUAL_CHECK_MARKER) ? recognized : DocumentService.withParsed(recognized, parsed);
        } catch (Exception e) {
            log.warn("OCR скана «{}» не удался ({}) — маркер ручной проверки", filename, e.getMessage());
            return null;
        }
    }

    /**
     * Смешанный PDF: текстовый слой есть, но часть страниц — картинки (меньше
     * половины, иначе документ считается сканом; пустые страницы без изображений
     * картинками не считаются — {@link DocumentService#isImagePage}). При включённом OCR документ
     * распознаётся постранично (страницы с текстом берутся как есть), при
     * выключенном — к тексту дописываются маркеры нераспознанных страниц и
     * уходит предупреждение. Раньше такие страницы терялись молча.
     *
     * @param filename     имя файла
     * @param content      содержимое PDF
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @param parsed       текстовый слой
     * @return текст документа с распознанными страницами либо с маркерами
     */
    private String handleMixedPdf(String filename, byte[] content,
                                  List<ServerSentEvent<Map<String, Object>>> uploadEvents, String parsed) {
        List<Integer> textless = documentService.textlessPages(content);
        if (textless.isEmpty()) {
            return parsed;
        }
        String pages = textless.stream().map(String::valueOf).collect(Collectors.joining(", "));
        if (scanOcrService.isEnabled()) {
            String recognized = recognizeScan(filename, content, uploadEvents, "", true);
            if (recognized != null) {
                return recognized;
            }
        }
        emitUploadWarning(uploadEvents, filename, "страницы " + pages + " без текстового слоя — не распознаны");
        StringBuilder sb = new StringBuilder(parsed);
        for (int page : textless) {
            sb.append("\n\n[страница ").append(page).append(" без текстового слоя — не распознана]");
        }
        return sb.toString();
    }

    /** Готовый документ-маркер (архив не распакован): без разбора, с событием upload_parsed. */
    private DocumentText markerDocument(String filename, String marker,
                                        List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        emitUploadEvent(uploadEvents, Map.of("type", "upload_parsed", "file", filename, "chars", marker.length()));
        return new DocumentText(filename, marker);
    }

    private void emitUploadWarning(List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                   String filename, String message) {
        emitUploadEvent(uploadEvents, Map.of("type", "upload_warning", "file", filename, "message", message));
    }

    /**
     * Кладёт событие загрузки в накопитель задачи (если он задан): из событий
     * «upload_warning» и «upload_parsed» статус загрузки берёт предупреждения
     * и число разобранных документов.
     *
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @param data         данные события с полем «type»
     */
    private static void emitUploadEvent(List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                        Map<String, Object> data) {
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder().data(data).build());
        }
    }

    /**
     * DOCX-экспорт прогона. В файл идут полный итог и все шаги: усечение по
     * JSON-схеме относится только к REST-ответу {@link #getScenarioRun(UUID)}.
     *
     * @param runId        UUID запуска
     * @param includeSteps включать ли шаги выполнения
     * @return DOCX-файл
     */
    public ResponseEntity<Resource> extractToDocx(UUID runId, boolean includeSteps) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] extractToDocx, runId={}, includeSteps={}", userId, runId, includeSteps);
        // доступ к прогону (автор; для прогона без автора — владелец сценария) проверяет buildRunDetail
        ScenarioRunDetailResponse runDetail = buildRunDetail(runId, false);
        return ExportToDocx.generateDocx(runId, runDetail, includeSteps);
    }

    /**
     * Отдаёт файл output-узла завершённого прогона: XLSX/текст генерируется
     * из сохранённого результата шага. WS-событие FILE_OUTPUT несёт только
     * «файл готов» — сами байты клиент забирает этой ручкой (base64-файлы
     * в кадре раздували сокет для корп. шлюза).
     *
     * @param runId  идентификатор прогона
     * @param nodeId идентификатор output-узла сценария
     * @return файл с корректным именем и MIME-типом
     */
    public ResponseEntity<Resource> downloadRunFile(UUID runId, String nodeId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] downloadRunFile, runId={}, nodeId='{}'", userId, runId, nodeId);
        ScenarioRun run = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Run not found"));
        Scenario model = scenarioRepository.findById(run.getScenarioId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        // файл строится из результатов прогона — только автору (прогон без автора — владельцу сценария)
        ScenarioRunAccess.checkAccess(run, model.getUserId(), userId);
        GraphDataDto graph = GraphDataMapper.toDto(model.getGraphData());
        var node = graph.nodes().stream()
                .filter(n -> nodeId.equals(n.id()))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Node not found"));
        // только шаг этого узла и только результат — без входов и промптов всех шагов прогона
        String result = scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(runId, nodeId).stream()
                .findFirst()
                .map(StepOutputView::result)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Step not found"));
        String mode = node.data() == null || node.data().mode() == null
                ? "" : node.data().mode().toUpperCase();
        return switch (mode) {
            case "EXCEL" -> excelResponse(runId, nodeId, node.data().rules(), ScenarioResultToXlsx.jsonToXlsx(result, node.data().rules(),
                    referenceNumbers(runId, graph, node.data().rules()),
                    enrichmentLines(runId, graph, node.data().rules()),
                    headerLine(runId, graph, node.data().rules())));
            // в живых сценариях встречаются оба варианта режима текстового файла
            case "TEXT_FILE", "TEXT" -> fileResponse("result.txt", "text/plain",
                    result.getBytes(StandardCharsets.UTF_8));
            default -> throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Узел не является файловым выходом");
        };
    }

    /**
     * Эталонные числа для кодовой выверки Excel: конфиг {@code "сверка_чисел":
     * {"из_узла": "<метка>"}} указывает узел (обычно transform, извлекающий суммы
     * из документов кодом), из результата которого собираются все числа.
     * LLM теряет разряды при переписывании сумм — эталон из кода закрывает это.
     *
     * @param runId     идентификатор прогона
     * @param graph     граф сценария
     * @param rulesJson правила выходного узла
     * @return числа в записи с точкой или пустое множество, если сверка не настроена
     */
    private Set<String> referenceNumbers(UUID runId, GraphDataDto graph, String rulesJson) {
        String sourceResult = donorNodeResult(runId, graph, rulesJson, "сверка_чисел");
        if (sourceResult == null) {
            return Set.of();
        }
        Set<String> numbers = new LinkedHashSet<>();
        Matcher m = REFERENCE_NUMBER.matcher(sourceResult);
        while (m.find()) {
            numbers.add(m.group(1).replace(",", "."));
        }
        log.info("[{}] Сверка чисел Excel: эталонов {}", CurrentUserHolder.getCurrentUser(), numbers.size());
        return numbers;
    }

    /**
     * Строки исходной формы участника для кодового обогащения Excel: конфиг
     * {@code "обогащение_формы": {"из_узла": "<метка>"}} указывает transform-узел,
     * извлёкший строки исходной таблицы кодом. Выход строится ПОВЕРХ этих строк:
     * каждая строка формы сохраняется, сопоставленные получают данные анализа,
     * остальные — заглушки (незачёт «Нет данных»). Так исходная форма участника
     * не затирается результатом.
     *
     * @param runId     идентификатор прогона
     * @param graph     граф сценария
     * @param rulesJson правила выходного узла
     * @return результат узла-донора или {@code null}, если обогащение не настроено
     */
    private String enrichmentLines(UUID runId, GraphDataDto graph, String rulesJson) {
        return donorNodeResult(runId, graph, rulesJson, "обогащение_формы");
    }

    /**
     * Шапка исходной формы из узла, указанного в
     * {@code "обогащение_формы": {"шапка_из_узла": "<метка>"}}.
     *
     * @param runId     идентификатор прогона
     * @param graph     граф сценария
     * @param rulesJson правила выходного узла
     * @return результат узла-донора шапки или {@code null}, если не настроен
     */
    private String headerLine(UUID runId, GraphDataDto graph, String rulesJson) {
        return donorNodeResult(runId, graph, rulesJson, "обогащение_формы", "шапка_из_узла");
    }

    /**
     * Результат узла, указанного в rules как {@code "<configKey>": {"из_узла": "<метка>"}}.
     *
     * @param runId     идентификатор прогона
     * @param graph     граф сценария
     * @param rulesJson правила выходного узла
     * @param configKey ключ настройки в rules
     * @return результат узла-донора или {@code null}, если не настроен или не найден
     */
    private String donorNodeResult(UUID runId, GraphDataDto graph, String rulesJson,
                                   String configKey) {
        return donorNodeResult(runId, graph, rulesJson, configKey, "из_узла");
    }

    /**
     * То же, с произвольным полем метки донора внутри конфига.
     *
     * @param runId      идентификатор прогона
     * @param graph      граф сценария
     * @param rulesJson  правила выходного узла
     * @param configKey  ключ настройки в rules
     * @param labelField поле с меткой узла-донора внутри настройки
     * @return результат узла-донора или {@code null}
     */
    private String donorNodeResult(UUID runId, GraphDataDto graph, String rulesJson,
                                   String configKey, String labelField) {
        if (rulesJson == null || rulesJson.isBlank()) {
            return null;
        }
        String sourceLabel = donorLabel(rulesJson, configKey, labelField);
        if (sourceLabel == null) {
            return null;
        }
        String sourceNodeId = graph.nodes().stream()
                .filter(n -> n.data() != null && sourceLabel.equals(n.data().label()))
                .map(NodeDto::id)
                .findFirst().orElse(null);
        if (sourceNodeId == null) {
            log.warn("[{}] {}: узел-донор «{}» не найден в графе", CurrentUserHolder.getCurrentUser(), configKey, sourceLabel);
            return null;
        }
        return scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(runId, sourceNodeId).stream()
                .findFirst()
                .map(StepOutputView::result)
                .map(ScenarioExecutorTransformNode::stripWarnings)
                .orElse(null);
    }

    /**
     * Метка узла-донора из rules ({@code "<configKey>": {"из_узла": "<метка>"}}).
     *
     * @param rulesJson  правила выходного узла
     * @param configKey  ключ настройки
     * @param labelField поле с меткой узла-донора внутри настройки
     * @return метка узла или {@code null}, если механизм не настроен
     */
    private static String donorLabel(String rulesJson, String configKey, String labelField) {
        try {
            Map<String, Object> rules = new ObjectMapper()
                    .readValue(rulesJson, new TypeReference<>() { });
            if (!(rules.get(configKey) instanceof Map<?, ?> check)
                    || check.get(labelField) == null) {
                return null;
            }
            return String.valueOf(check.get(labelField));
        } catch (Exception e) {
            // rules без валидного JSON — механизм просто не настроен
            return null;
        }
    }

    /**
     * Файл Excel-узла: сам XLSX либо — если узел размечал исходные документы ({@code "разметка_документов"}
     * в его правилах, ZIP разметки лежит в складе артефактов) — ZIP с XLSX и размеченными документами.
     * ZIP размеченных документов живёт только на диске: если разметка настроена, а файла нет (перезапуск,
     * срок хранения), — ошибка 404 с понятным текстом, а не молча {@code result.xlsx} без разметки.
     *
     * @param runId  идентификатор прогона
     * @param nodeId идентификатор узла
     * @param rules  правила узла
     * @param xlsx   содержимое XLSX
     * @return ответ с файлом
     */
    private ResponseEntity<Resource> excelResponse(UUID runId, String nodeId, String rules, byte[] xlsx) {
        Optional<byte[]> annotations = runArtifactStore == null ? Optional.empty() : runArtifactStore.load(runId, nodeId);
        if (annotations.isEmpty()) {
            if (runArtifactStore != null && AnnotationConfig.configured(rules)) {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, ANNOTATION_ARTIFACT_MISSING);
            }
            return fileResponse("result.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", xlsx);
        }
        try {
            return fileResponse("result.zip", "application/zip",
                    DocumentAnnotationService.withExcel(annotations.get(), xlsx));
        } catch (IOException e) {
            throw new FileException("Ошибка сборки ZIP размеченных документов", e);
        }
    }

    private static ResponseEntity<Resource> fileResponse(String filename, String mime, byte[] bytes) {
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                .header("Content-Type", mime)
                .body(new ByteArrayResource(bytes));
    }
}
