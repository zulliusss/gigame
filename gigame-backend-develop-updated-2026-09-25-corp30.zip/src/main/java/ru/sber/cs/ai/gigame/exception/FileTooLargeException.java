package ru.sber.cs.ai.gigame.exception;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Файл загрузки больше допустимого размера — HTTP 413 «Payload Too Large» с телом
 * {@link ru.sber.cs.ai.gigame.dto.ErrorResponse}.
 * <p>
 * Бросается кодом, когда имя файла известно (быстрая фаза загрузки сценария), а текст
 * {@link #message(String, long)} использует и обработчик превышений лимитов multipart WebFlux,
 * где имя файла неизвестно. На 413 фронт делит партию и режет ZIP-архив на части.
 */
public class FileTooLargeException extends ApplicationRuntimeException {

    /** HTTP-код «Payload Too Large». */
    public static final int STATUS = 413;

    private static final long KIBIBYTE = 1024L;

    private static final long MEBIBYTE = KIBIBYTE * 1024;

    /**
     * Создаёт исключение с понятным текстом.
     *
     * @param filename   имя файла (null или пустое — без имени)
     * @param limitBytes предел размера одного файла, байты
     */
    public FileTooLargeException(String filename, long limitBytes) {
        super(message(filename, limitBytes), STATUS);
    }

    /**
     * Текст ошибки: «Файл «имя» больше допустимого размера N МБ — разделите архив на части
     * или загрузите документы по отдельности».
     *
     * @param filename   имя файла (null или пустое — текст без имени)
     * @param limitBytes предел размера одного файла, байты
     * @return текст для пользователя
     */
    public static String message(String filename, long limitBytes) {
        String name = filename == null || filename.isBlank() ? "" : " «" + filename + "»";
        return "Файл" + name + " больше допустимого размера " + megabytes(limitBytes)
                + " МБ — разделите архив на части или загрузите документы по отдельности";
    }

    /**
     * Байты в мегабайтах для текста: целое число либо до двух знаков после запятой.
     *
     * @param bytes байты
     * @return мегабайты, например «100» или «0,5»
     */
    static String megabytes(long bytes) {
        return scaled(bytes, MEBIBYTE);
    }

    /**
     * Байты в килобайтах для текста: целое число либо до двух знаков после запятой.
     *
     * @param bytes байты
     * @return килобайты, например «256» или «0,5»
     */
    static String kilobytes(long bytes) {
        return scaled(bytes, KIBIBYTE);
    }

    /**
     * Байты в заданных единицах для текста: до двух знаков после запятой, без хвостовых нулей, с запятой.
     *
     * @param bytes байты
     * @param unit  байт в одной единице
     * @return значение для текста
     */
    private static String scaled(long bytes, long unit) {
        BigDecimal value = BigDecimal.valueOf(bytes)
                .divide(BigDecimal.valueOf(unit), 2, RoundingMode.HALF_UP)
                .stripTrailingZeros();
        return value.toPlainString().replace('.', ',');
    }
}
