package ru.sber.cs.ai.gigame.service.annotate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Настройка разметки исходных документов в правилах Excel-узла:
 * <pre>
 * "разметка_документов": {
 *   "документ": "з3",              — поле строки с именем документа (и разделом)
 *   "цитата": "з8",                — поле с дословной цитатой
 *   "уровень": "з4",               — поле уровня риска (цвет подсветки; строки служебных уровней пропускаются)
 *   "заголовок": "з2",             — поле-заголовок комментария
 *   "поля": ["з5", "з6"],          — поля, добавляемые в комментарий с подписями из «колонки» узла
 *   "числа_из": "з2",              — для находок без цитаты: числа из этого поля ищутся в документе
 *   "пропускать_уровни": ["ПАСПОРТ", "ВЫВОД", "РЕКОМЕНДАЦИЯ"]
 * }
 * </pre>
 * Все ключи необязательны — значения по умолчанию соответствуют заключению ПЗД. Подписи полей для
 * комментария берутся из «колонки» тех же правил ({@code {"ключ": "з5", "заголовок": "Чем грозит"}}).
 *
 * @param documentField поле имени документа
 * @param quoteField    поле цитаты
 * @param levelField    поле уровня
 * @param titleField    поле заголовка комментария
 * @param detailFields  поля деталей комментария
 * @param numbersField  поле, из которого берутся числа для находок без цитаты
 * @param skipLevels    уровни, строки которых не размечаются
 * @param labels        подписи полей по ключу
 */
@Slf4j
public record AnnotationConfig(String documentField, String quoteField, String levelField, String titleField,
                               List<String> detailFields, String numbersField, Set<String> skipLevels,
                               Map<String, String> labels) {

    /** Ключ настройки в правилах узла. */
    public static final String KEY = "разметка_документов";

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final List<String> DEFAULT_DETAILS = List.of("з5", "з6");
    private static final List<String> DEFAULT_SKIP = List.of("ПАСПОРТ", "ВЫВОД", "РЕКОМЕНДАЦИЯ");

    /**
     * Есть ли в правилах узла настройка разметки.
     *
     * @param rulesJson правила выходного узла (может быть {@code null})
     * @return {@code true}, если разметка настроена
     */
    public static boolean configured(String rulesJson) {
        return parse(rulesJson) != null;
    }

    /**
     * Читает настройку из правил узла.
     *
     * @param rulesJson правила выходного узла (может быть {@code null})
     * @return настройка либо {@code null}, если разметка не настроена или правила не разбираются
     */
    @SuppressWarnings("unchecked")
    public static AnnotationConfig parse(String rulesJson) {
        // узел без правил отдаёт «[]»: разметка не настроена, это не ошибка разбора и не повод для WARN
        if (rulesJson == null || !rulesJson.strip().startsWith("{")) {
            return null;
        }
        Map<String, Object> rules;
        try {
            rules = MAPPER.readValue(rulesJson, new TypeReference<>() { });
        } catch (Exception e) {
            log.warn("Разметка документов: правила узла не разбираются ({})", e.getMessage());
            return null;
        }
        if (!(rules.get(KEY) instanceof Map<?, ?> raw)) {
            return null;
        }
        Map<String, Object> cfg = (Map<String, Object>) raw;
        return new AnnotationConfig(
                text(cfg, "документ", "з3"),
                text(cfg, "цитата", "з8"),
                text(cfg, "уровень", "з4"),
                text(cfg, "заголовок", "з2"),
                strings(cfg.get("поля"), DEFAULT_DETAILS),
                text(cfg, "числа_из", text(cfg, "заголовок", "з2")),
                new LinkedHashSet<>(strings(cfg.get("пропускать_уровни"), DEFAULT_SKIP)),
                labels(rules.get("колонки")));
    }

    /**
     * Подпись поля для комментария: заголовок колонки Excel либо сам ключ.
     *
     * @param field ключ поля
     * @return подпись
     */
    public String label(String field) {
        return labels.getOrDefault(field, field);
    }

    private static String text(Map<String, Object> cfg, String key, String fallback) {
        Object value = cfg.get(key);
        return value == null || String.valueOf(value).isBlank() ? fallback : String.valueOf(value).strip();
    }

    private static List<String> strings(Object raw, List<String> fallback) {
        if (!(raw instanceof List<?> list)) {
            return fallback;
        }
        List<String> out = new ArrayList<>();
        for (Object item : list) {
            if (item != null && !String.valueOf(item).isBlank()) {
                out.add(String.valueOf(item).strip());
            }
        }
        return out.isEmpty() ? fallback : out;
    }

    private static Map<String, String> labels(Object columns) {
        Map<String, String> out = new LinkedHashMap<>();
        if (!(columns instanceof List<?> list)) {
            return out;
        }
        for (Object item : list) {
            if (item instanceof Map<?, ?> column && column.get("ключ") != null && column.get("заголовок") != null) {
                out.put(String.valueOf(column.get("ключ")), String.valueOf(column.get("заголовок")));
            }
        }
        return out;
    }
}
