package ru.sber.cs.ai.gigame.service.annotate;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDColor;
import org.apache.pdfbox.pdmodel.graphics.color.PDDeviceRGB;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationHighlight;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationText;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.TextPosition;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Разметка находок в PDF: цитата выделяется аннотацией-подсветкой цвета уровня риска с текстом находки
 * во всплывающей заметке, рядом ставится значок комментария. Страницы без текстового слоя (сканы,
 * распознанные через OCR) точной подсветки не получают — на странице ставится заметка с текстом находки.
 * <p>
 * Текст страниц извлекается с позициями знаков ({@link PositionStripper}), цитата ищется в нём
 * ({@link TextLocator}), по найденным знакам строятся прямоугольники подсветки по строкам.
 */
public final class PdfAnnotator {

    private static final String AUTHOR = "GigaMe";
    private static final float NOTE_SIZE = 18f;
    private static final float DESCENT = 0.25f;

    private PdfAnnotator() {
    }

    /**
     * Находка с подсказкой страницы для документа без текстового слоя.
     *
     * @param finding  находка
     * @param pageHint номер страницы (с 1) по тексту OCR либо {@code null}
     */
    public record Target(Finding finding, Integer pageHint) {
    }

    /**
     * Итог разметки документа.
     *
     * @param content   размеченный документ
     * @param annotated сколько находок отмечено (подсветкой или заметкой)
     * @param notes     пометки по находкам, отмеченным без подсветки или не найденным
     */
    public record Result(byte[] content, int annotated, List<String> notes) {
    }

    /** Текст страницы и позиции его знаков ({@code null} — разделитель слов или строк). */
    private record PageText(int index, String text, List<TextPosition> positions) {
    }

    /** Найденное место: страница и диапазон её текста. */
    private record Placement(PageText page, TextLocator.Span span) {
    }

    /**
     * Размечает находки в документе.
     *
     * @param pdf     исходный документ
     * @param targets находки этого документа
     * @return размеченный документ и пометки
     * @throws IOException документ не открывается или не записывается
     */
    public static Result annotate(byte[] pdf, List<Target> targets) throws IOException {
        try (PDDocument doc = Loader.loadPDF(pdf)) {
            List<PageText> pages = extract(doc);
            List<String> notes = new ArrayList<>();
            int annotated = 0;
            for (Target target : targets) {
                Finding finding = target.finding();
                Placement placement = locate(pages, finding);
                if (placement != null) {
                    highlight(doc, placement, finding);
                    annotated++;
                    if (placement.span().partial()) {
                        notes.add("находка № " + finding.number() + ": цитата найдена не целиком — отмечен найденный "
                                + "фрагмент на странице " + (placement.page().index() + 1));
                    }
                } else if (target.pageHint() != null && target.pageHint() <= doc.getNumberOfPages()) {
                    note(doc.getPage(target.pageHint() - 1), finding, true);
                    annotated++;
                    notes.add("находка № " + finding.number() + ": страница " + target.pageHint()
                            + " без текстового слоя — заметка без подсветки");
                } else {
                    notes.add("находка № " + finding.number() + ": цитата в документе не найдена — не отмечена");
                }
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.save(out);
            return new Result(out.toByteArray(), annotated, notes);
        }
    }

    private static List<PageText> extract(PDDocument doc) throws IOException {
        List<PageText> pages = new ArrayList<>();
        PositionStripper stripper = new PositionStripper();
        for (int page = 1; page <= doc.getNumberOfPages(); page++) {
            stripper.reset();
            stripper.setStartPage(page);
            stripper.setEndPage(page);
            stripper.getText(doc);
            pages.add(new PageText(page - 1, stripper.text.toString(), new ArrayList<>(stripper.positions)));
        }
        return pages;
    }

    /** Страница с цитатой: сначала полное совпадение, затем — по началу; без цитаты — по числам. */
    private static Placement locate(List<PageText> pages, Finding finding) {
        Placement partial = null;
        for (PageText page : pages) {
            TextLocator.Span span = finding.locateIn(page.text());
            if (span == null) {
                continue;
            }
            if (!span.partial()) {
                return new Placement(page, span);
            }
            if (partial == null || length(span) > length(partial.span())) {
                partial = new Placement(page, span);
            }
        }
        return partial;
    }

    /** Длина найденного фрагмента: из частичных совпадений выбирается самое длинное. */
    private static int length(TextLocator.Span span) {
        return span.end() - span.start();
    }

    private static void highlight(PDDocument doc, Placement placement, Finding finding) throws IOException {
        PDPage page = doc.getPage(placement.page().index());
        float height = page.getMediaBox().getHeight();
        Map<Integer, List<TextPosition>> lines = new LinkedHashMap<>();
        for (int i = placement.span().start(); i < placement.span().end(); i++) {
            TextPosition position = placement.page().positions().get(i);
            if (position != null) {
                lines.computeIfAbsent(Math.round(position.getYDirAdj()), key -> new ArrayList<>()).add(position);
            }
        }
        if (lines.isEmpty()) {
            note(page, finding, false);
            return;
        }
        float[] quads = new float[lines.size() * 8];
        PDRectangle bounds = null;
        int offset = 0;
        for (List<TextPosition> line : lines.values()) {
            PDRectangle box = lineBox(line, height);
            bounds = bounds == null ? box : union(bounds, box);
            quads[offset++] = box.getLowerLeftX();
            quads[offset++] = box.getUpperRightY();
            quads[offset++] = box.getUpperRightX();
            quads[offset++] = box.getUpperRightY();
            quads[offset++] = box.getLowerLeftX();
            quads[offset++] = box.getLowerLeftY();
            quads[offset++] = box.getUpperRightX();
            quads[offset++] = box.getLowerLeftY();
        }
        PDAnnotationHighlight mark = new PDAnnotationHighlight();
        mark.setRectangle(bounds);
        mark.setQuadPoints(quads);
        mark.setColor(color(finding));
        mark.setContents(finding.comment());
        mark.setTitlePopup(AUTHOR);
        page.getAnnotations().add(mark);
        mark.constructAppearances();
        note(page, finding, false, bounds.getLowerLeftX() - NOTE_SIZE, bounds.getUpperRightY());
    }

    private static PDRectangle lineBox(List<TextPosition> line, float pageHeight) {
        float left = Float.MAX_VALUE;
        float right = 0;
        float top = 0;
        float bottom = Float.MAX_VALUE;
        for (TextPosition position : line) {
            float baseline = pageHeight - position.getYDirAdj();
            float glyph = position.getHeightDir();
            left = Math.min(left, position.getXDirAdj());
            right = Math.max(right, position.getXDirAdj() + position.getWidthDirAdj());
            top = Math.max(top, baseline + glyph);
            bottom = Math.min(bottom, baseline - glyph * DESCENT);
        }
        return new PDRectangle(left, bottom, right - left, top - bottom);
    }

    private static PDRectangle union(PDRectangle a, PDRectangle b) {
        float left = Math.min(a.getLowerLeftX(), b.getLowerLeftX());
        float bottom = Math.min(a.getLowerLeftY(), b.getLowerLeftY());
        float right = Math.max(a.getUpperRightX(), b.getUpperRightX());
        float top = Math.max(a.getUpperRightY(), b.getUpperRightY());
        return new PDRectangle(left, bottom, right - left, top - bottom);
    }

    /** Значок заметки в левом верхнем углу страницы (страница без текстового слоя или без позиций). */
    private static void note(PDPage page, Finding finding, boolean noLayer) throws IOException {
        PDRectangle box = page.getMediaBox();
        note(page, finding, noLayer, box.getLowerLeftX() + NOTE_SIZE, box.getUpperRightY() - NOTE_SIZE);
    }

    private static void note(PDPage page, Finding finding, boolean noLayer, float x, float top) throws IOException {
        PDAnnotationText note = new PDAnnotationText();
        note.setRectangle(new PDRectangle(Math.max(0, x), Math.max(0, top - NOTE_SIZE), NOTE_SIZE, NOTE_SIZE));
        note.setName(PDAnnotationText.NAME_COMMENT);
        note.setContents((noLayer ? "Страница без текстового слоя — место находки уточните по цитате.\n" : "")
                + finding.comment());
        note.setTitlePopup(AUTHOR);
        note.setColor(color(finding));
        note.setOpen(false);
        page.getAnnotations().add(note);
        note.constructAppearances();
    }

    private static PDColor color(Finding finding) {
        float[] rgb = switch (finding.color()) {
            case "red" -> new float[] {1f, 0.45f, 0.45f};
            case "yellow" -> new float[] {1f, 0.9f, 0.2f};
            case "green" -> new float[] {0.6f, 0.95f, 0.6f};
            default -> new float[] {0.55f, 0.9f, 1f};
        };
        return new PDColor(rgb, PDDeviceRGB.INSTANCE);
    }

    /** Извлечение текста страницы со знаками в позициях: слова и строки разделены пробелом и переводом строки. */
    private static final class PositionStripper extends PDFTextStripper {

        private final StringBuilder text = new StringBuilder();
        private final List<TextPosition> positions = new ArrayList<>();

        PositionStripper() {
            setSortByPosition(true);
        }

        void reset() {
            text.setLength(0);
            positions.clear();
        }

        @Override
        protected void writeString(String string, List<TextPosition> textPositions) {
            for (TextPosition position : textPositions) {
                String unicode = position.getUnicode();
                for (int i = 0; i < unicode.length(); i++) {
                    text.append(unicode.charAt(i));
                    positions.add(position);
                }
            }
        }

        @Override
        protected void writeWordSeparator() {
            text.append(' ');
            positions.add(null);
        }

        @Override
        protected void writeLineSeparator() {
            text.append('\n');
            positions.add(null);
        }
    }
}
