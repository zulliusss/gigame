package ru.sber.cs.ai.gigame.service.annotate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Поиск дословной цитаты находки в тексте документа с возвратом позиций в ИСХОДНОМ тексте.
 * <p>
 * Цитата в заключении и текст документа различаются оформлением: кавычки «» и "", тире и дефисы,
 * ё/е, регистр, неразрывные и повторные пробелы, разрядка чисел («289 523 339,14» в документе против
 * «289523339.14» в кодовой находке). Оба текста приводятся к одному виду ({@link #normalize}), при этом для
 * каждого знака нормализованного текста запоминается позиция знака-источника, поэтому найденный фрагмент
 * возвращается как диапазон исходного текста — по нему подсвечиваются знаки документа.
 * <p>
 * Цитата, которой нет целиком (сокращена многоточием, переходит через абзац), ищется по началу
 * ({@link #PREFIX_CHARS} знаков до границы слова) — такой результат помечен как частичный. Если и начала нет,
 * подбираются куски цитаты вокруг многоточия ({@link #findEllipsisPart}), ячейка строки таблицы
 * ({@link #findCellFragment}) и, последним, самое длинное окно подряд идущих слов цитаты
 * ({@link #findWordWindow}) — модель часто пересказывает часть цитаты своими словами.
 */
public final class TextLocator {

    /** Длина начала цитаты для частичного поиска. */
    static final int PREFIX_CHARS = 80;
    /** Короче этого нормализованная цитата не ищется — совпадения были бы случайными. */
    static final int MIN_QUOTE_CHARS = 8;
    /** Минимум слов в окне нечёткого поиска. */
    static final int MIN_WINDOW_WORDS = 2;
    /** Доля знаков цитаты, которую обязано покрыть окно нечёткого поиска. */
    static final double MIN_WINDOW_RATIO = 0.5;
    private static final String QUOTE_TRIM = "«»\"'„“”‘’ \t\n";
    private static final Pattern ELLIPSIS = Pattern.compile("\\s*(?:\\.{3}|…)\\s*");

    private TextLocator() {
    }

    /**
     * Нормализованный текст и позиции исходных знаков.
     *
     * @param text        нормализованный текст
     * @param sourceIndex позиция в исходном тексте для каждого знака нормализованного
     */
    public record Normalized(String text, int[] sourceIndex) {
    }

    /**
     * Найденный фрагмент исходного текста.
     *
     * @param start   начало (включительно)
     * @param end     конец (исключительно)
     * @param partial найдено только начало цитаты
     */
    public record Span(int start, int end, boolean partial) {
    }

    /**
     * Приводит текст к виду для сравнения: строчные буквы, е вместо ё, одинаковые кавычки и тире,
     * одиночные пробелы, числа без разрядки и с точкой вместо запятой.
     *
     * @param source исходный текст
     * @return нормализованный текст с позициями источника
     */
    public static Normalized normalize(String source) {
        StringBuilder sb = new StringBuilder(source.length());
        int[] map = new int[source.length() + 1];
        boolean pendingSpace = false;
        for (int i = 0; i < source.length(); i++) {
            char c = fold(source.charAt(i));
            if (c == 0) {
                continue;
            }
            if (c == ' ') {
                pendingSpace = sb.length() > 0;
                continue;
            }
            boolean afterDigit = sb.length() > 0 && Character.isDigit(sb.charAt(sb.length() - 1));
            if (c == ',' && afterDigit && nextIsDigit(source, i)) {
                c = '.';
            }
            if (pendingSpace && !(afterDigit && Character.isDigit(c))) {
                map[sb.length()] = i;
                sb.append(' ');
            }
            pendingSpace = false;
            map[sb.length()] = i;
            sb.append(c);
        }
        return new Normalized(sb.toString(), Arrays.copyOf(map, sb.length()));
    }

    /**
     * Ищет цитату в тексте: сначала целиком, затем — по началу, затем — нестрогими способами.
     *
     * @param source текст документа (абзац, страница)
     * @param quote  цитата из находки
     * @return диапазон исходного текста либо {@code null}, если цитата не найдена или слишком коротка
     */
    public static Span find(String source, String quote) {
        if (source == null || quote == null) {
            return null;
        }
        String needle = normalize(cleanQuote(quote)).text().strip();
        if (needle.length() < MIN_QUOTE_CHARS) {
            return null;
        }
        Normalized text = normalize(source);
        int at = text.text().indexOf(needle);
        if (at >= 0) {
            return span(text, at, needle.length(), false);
        }
        if (needle.length() > PREFIX_CHARS) {
            String prefix = prefixToWord(needle);
            at = text.text().indexOf(prefix);
            if (at >= 0) {
                return span(text, at, prefix.length(), true);
            }
        }
        return findLoose(text, quote, needle);
    }

    /**
     * Нестрогий поиск цитаты, которой нет дословно: куски вокруг многоточия, затем ячейка строки таблицы,
     * затем окно подряд идущих слов. Любой такой результат — частичное совпадение.
     *
     * @param text   нормализованный текст документа
     * @param quote  цитата из находки как есть
     * @param needle нормализованная цитата
     * @return диапазон исходного текста либо {@code null}
     */
    private static Span findLoose(Normalized text, String quote, String needle) {
        Span span = findEllipsisPart(text, quote);
        if (span == null) {
            span = findCellFragment(text, quote);
        }
        return span != null ? span : findWordWindow(text, needle);
    }

    /**
     * Цитата, сокращённая моделью многоточием («НМЦ … 289523339,14»): ищется самый длинный кусок между
     * многоточиями — обычно это и есть значимая часть находки.
     *
     * @param text  нормализованный текст
     * @param quote цитата из находки
     * @return диапазон куска либо {@code null}
     */
    private static Span findEllipsisPart(Normalized text, String quote) {
        String[] parts = ELLIPSIS.split(quote);
        if (parts.length < 2) {
            return null;
        }
        List<String> needles = new ArrayList<>();
        for (String part : parts) {
            String needle = normalize(cleanQuote(part)).text().strip();
            if (needle.length() >= MIN_QUOTE_CHARS) {
                needles.add(needle);
            }
        }
        return longestHit(text, needles);
    }

    /**
     * Нечёткий поиск: модель пересказывает часть цитаты, а остальное приводит дословно. Ищется самое длинное
     * окно подряд идущих слов цитаты, которое есть в тексте: не короче {@link #MIN_WINDOW_WORDS} слов,
     * {@link #MIN_QUOTE_CHARS} знаков вдвое и доли {@link #MIN_WINDOW_RATIO} от знаков цитаты — иначе подсветка
     * села бы на случайный оборот.
     *
     * @param text   нормализованный текст
     * @param needle нормализованная цитата
     * @return диапазон окна либо {@code null}
     */
    private static Span findWordWindow(Normalized text, String needle) {
        String[] words = needle.split(" ");
        int floor = Math.max(2 * MIN_QUOTE_CHARS, (int) (needle.length() * MIN_WINDOW_RATIO));
        if (text.text().length() < floor) {
            return null;
        }
        for (int size = words.length - 1; size >= MIN_WINDOW_WORDS; size--) {
            for (int from = 0; from + size <= words.length; from++) {
                String window = String.join(" ", Arrays.copyOfRange(words, from, from + size));
                int at = window.length() < floor ? -1 : text.text().indexOf(window);
                if (at >= 0) {
                    return span(text, at, window.length(), true);
                }
            }
        }
        return null;
    }

    /**
     * Первое совпадение из кусков цитаты, начиная с самого длинного.
     *
     * @param text    нормализованный текст
     * @param needles нормализованные куски цитаты
     * @return диапазон куска (частичное совпадение) либо {@code null}
     */
    private static Span longestHit(Normalized text, List<String> needles) {
        needles.sort(Comparator.comparingInt(String::length).reversed());
        for (String needle : needles) {
            int at = text.text().indexOf(needle);
            if (at >= 0) {
                return span(text, at, needle.length(), true);
            }
        }
        return null;
    }

    /**
     * Цитата-строка таблицы («&lt; ячейка | ячейка &gt;», как таблицы выглядят в тексте документа): ячейки лежат
     * в разных абзацах DOCX, целиком строка не найдётся — ищется самая длинная ячейка, найденная в тексте.
     *
     * @param text  нормализованный текст
     * @param quote цитата из находки
     * @return диапазон ячейки (частичное совпадение) либо {@code null}
     */
    private static Span findCellFragment(Normalized text, String quote) {
        if (quote.indexOf('|') < 0) {
            return null;
        }
        List<String> cells = new ArrayList<>();
        for (String cell : quote.split("\\|")) {
            String needle = normalize(cleanQuote(cell.replace('<', ' ').replace('>', ' '))).text().strip();
            if (needle.length() >= MIN_QUOTE_CHARS) {
                cells.add(needle);
            }
        }
        return longestHit(text, cells);
    }

    private static Span span(Normalized text, int at, int length, boolean partial) {
        int last = at + length - 1;
        return new Span(text.sourceIndex()[at], text.sourceIndex()[last] + 1, partial);
    }

    /**
     * Цитата без обрамляющих кавычек и завершающего многоточия.
     *
     * @param quote цитата из находки
     * @return очищенная цитата
     */
    static String cleanQuote(String quote) {
        String q = quote.strip();
        int start = 0;
        int end = q.length();
        while (start < end && (QUOTE_TRIM.indexOf(q.charAt(start)) >= 0 || q.charAt(start) == '…')) {
            start++;
        }
        while (end > start && (QUOTE_TRIM.indexOf(q.charAt(end - 1)) >= 0 || q.charAt(end - 1) == '…' || q.startsWith("...", end - 3))) {
            end -= q.startsWith("...", end - 3) ? 3 : 1;
        }
        return q.substring(start, end);
    }

    private static String prefixToWord(String needle) {
        int cut = needle.lastIndexOf(' ', PREFIX_CHARS);
        return needle.substring(0, cut > MIN_QUOTE_CHARS ? cut : PREFIX_CHARS).strip();
    }

    private static boolean nextIsDigit(String source, int i) {
        return i + 1 < source.length() && Character.isDigit(source.charAt(i + 1));
    }

    /** Знак после нормализации: 0 — знак выбрасывается, ' ' — любой пробел. */
    private static char fold(char c) {
        if (Character.isWhitespace(c) || c == ' ' || c == ' ' || c == ' ') {
            return ' ';
        }
        return switch (c) {
            case '­', '​', '﻿' -> 0;
            case 'ё', 'Ё' -> 'е';
            case '«', '»', '„', '“', '”', '″' -> '"';
            case '‘', '’', '`', '′' -> '\'';
            case '–', '—', '−', '‐', '‑' -> '-';
            default -> Character.toLowerCase(c);
        };
    }
}
