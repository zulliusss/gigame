package ru.sber.cs.ai.gigame.utils;

import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.multipart.FilePart;
import reactor.core.publisher.Mono;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.UnsupportedFormatException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Утилитный класс для работы с файлами в реактивном контексте.
 * <p>
 * Предоставляет методы для преобразования FilePart в InputStream
 * в рамках реактивной обработки multipart-загрузок.
 *
 * @see FilePart
 * @see Mono
 */
public class FileUtils {
    private static final Pattern FILENAME_PATTERN = Pattern.compile("filename=\"?([^\";]+)\"?", Pattern.CASE_INSENSITIVE);
    /** Начало ZIP-контейнера (книги Office 2007+). */
    private static final byte[] ZIP_SIGNATURE = {0x50, 0x4B, 0x03, 0x04};
    /** Начало составного документа OLE2 (бинарные книги Excel 97–2003). */
    private static final byte[] OLE2_SIGNATURE = {(byte) 0xD0, (byte) 0xCF, 0x11, (byte) 0xE0};
    /** Начало PDF («%PDF-»). */
    private static final byte[] PDF_SIGNATURE = {0x25, 0x50, 0x44, 0x46, 0x2D};
    /** Сколько первых записей ZIP просматривается, чтобы узнать документ Office 2007+ по содержимому. */
    private static final int OOXML_SCAN_ENTRIES = 16;

    /**
     * Маппинг расширений файлов на типы контента.
     * Поддерживаемые форматы: PDF, DOCX, XLSX, XLS (бинарный), PPTX, XML,
     * изображения (JPG, PNG, TIFF, BMP — распознаются как одностраничный скан),
     * а также текстовые: TXT, CSV/TSV, MD, JSON, YAML, LOG (читаются как plain text).
     */
    private static final Map<String, String> EXTENSION_MAP = Map.ofEntries(
            Map.entry("pdf", "pdf"),
            Map.entry("docx", "docx"),
            Map.entry("xlsx", "xlsx"),
            Map.entry("xls", "xls"),
            Map.entry("pptx", "pptx"),
            Map.entry("xml", "xml"),
            Map.entry("jpg", "image"),
            Map.entry("jpeg", "image"),
            Map.entry("png", "image"),
            Map.entry("tif", "image"),
            Map.entry("tiff", "image"),
            Map.entry("bmp", "image"),
            Map.entry("txt", "txt"),
            Map.entry("text", "txt"),
            Map.entry("csv", "txt"),
            Map.entry("tsv", "txt"),
            Map.entry("md", "txt"),
            Map.entry("json", "txt"),
            Map.entry("yaml", "txt"),
            Map.entry("yml", "txt"),
            Map.entry("log", "txt")
    );

    /**
     * Форматы документов, которые парсер не читает: расширение → подсказка пользователю. Такой файл получает
     * честную причину «формат не поддерживается» ({@link UnsupportedFormatException}), а не «повреждён»,
     * и из архива не выбрасывается молча.
     */
    private static final Map<String, String> UNSUPPORTED_FORMATS = Map.of(
            "doc", "Word 97-2003 — сохраните документ как DOCX или PDF",
            "rtf", "RTF — сохраните документ как DOCX или PDF",
            "odt", "OpenDocument — сохраните документ как DOCX или PDF",
            "ods", "OpenDocument — сохраните книгу как XLSX или PDF",
            "odp", "OpenDocument — сохраните презентацию как PPTX или PDF",
            "ppt", "PowerPoint 97-2003 — сохраните презентацию как PPTX или PDF"
    );

    private FileUtils() {
    }

    /**
     * Преобразует FilePart в Mono&lt;InputStream&gt; для реактивной обработки.
     * <p>
     * Собирает все фрагменты данных из FilePart в один byte[] массив
     * и возвращает их как ByteArrayInputStream внутри Mono.
     *
     * @param filePart загруженный файл
     * @return Mono, содержащее InputStream с данными файла
     */
    public static Mono<InputStream> toInputStream(FilePart filePart) {
        return toInputStream(filePart, Integer.MAX_VALUE);
    }

    /**
     * То же, что {@link #toInputStream(FilePart)}, но с пределом размера, который проверяется по ходу чтения
     * частей: файл больше предела в память целиком не попадает — чтение обрывается
     * {@link org.springframework.core.io.buffer.DataBufferLimitException}, уже собранные буферы освобождаются.
     *
     * @param filePart загруженный файл
     * @param maxBytes предел размера, байты (больше — ошибка предела)
     * @return Mono, содержащее InputStream с данными файла
     */
    public static Mono<InputStream> toInputStream(FilePart filePart, long maxBytes) {
        int limit = (int) Math.min(Math.max(maxBytes, 0), Integer.MAX_VALUE);
        return DataBufferUtils.join(filePart.content(), limit)
                .handle((dataBuffer, sink) -> {
                    byte[] bytes = new byte[dataBuffer.readableByteCount()];
                    dataBuffer.read(bytes);
                    DataBufferUtils.release(dataBuffer);
                    sink.next(new ByteArrayInputStream(bytes));
                });
    }

    /**
     * Извлекает расширение файла из его имени.
     *
     * @param filename имя файла
     * @return расширение в нижнем регистре или "bin" если расширение не найдено
     */
    private static String extractExtension(String filename) {
        int dotIdx = filename.lastIndexOf('.');
        if (dotIdx < 0) {
            return "bin";
        }
        return filename.substring(dotIdx + 1);
    }

    /**
     * Сопоставляет расширение файла с нормализованным строковым типом контента.
     *
     * @param filename имя файла
     * @return тип контента: "pdf", "docx", "xlsx" или "txt"
     * @throws IllegalArgumentException если расширение не поддерживается
     */
    public static String detectContentType(String filename) {
        String ext = extractExtension(filename).toLowerCase();
        String type = EXTENSION_MAP.get(ext);
        if (type == null) {
            String hint = UNSUPPORTED_FORMATS.get(ext);
            if (hint != null) {
                throw new UnsupportedFormatException(ext, hint);
            }
            throw new FileException("Unsupported file extension: ." + ext);
        }
        return type;
    }

    /**
     * Поддерживается ли расширение файла парсером документов (единый список
     * с {@link #detectContentType(String)} — распаковка архивов не должна
     * отбрасывать форматы, которые парсер умеет читать).
     *
     * @param extension расширение без точки, в любом регистре
     * @return {@code true}, если файл с таким расширением разбирается
     */
    public static boolean isSupportedExtension(String extension) {
        return extension != null && EXTENSION_MAP.containsKey(extension.toLowerCase());
    }

    /**
     * Расширение документа, о котором пользователю нужно сообщить: парсер его читает либо формат известен, но не
     * поддерживается (doc, rtf, odt, …). Такие файлы из архива не выбрасываются молча — документ получает маркер
     * с причиной; прочие расширения (exe, sig) — служебный мусор.
     *
     * @param extension расширение без точки, в любом регистре
     * @return {@code true}, если файл должен дойти до разбора (пусть и с маркером «формат не поддерживается»)
     */
    public static boolean isKnownDocumentExtension(String extension) {
        return isSupportedExtension(extension) || extension != null && UNSUPPORTED_FORMATS.containsKey(extension.toLowerCase());
    }

    /**
     * Тип контента по расширению с поправкой на фактическое содержимое файла.
     * <p>
     * Почтовые клиенты сохраняют вложения под короткими именами («3_1~1 (1).XLS», «ДОГОВО~1.DOC»), и документ
     * Office 2007+ (ZIP-контейнер) получает чужое расширение: бинарный парсер падал, форма участника не разбиралась,
     * DOCX под .doc считался неподдерживаемым. Поэтому сигнатура содержимого главнее расширения: «%PDF-» — PDF при
     * любом расширении; ZIP с word/, xl/, ppt/ внутри — docx/xlsx/pptx, если расширение не Office 2007+;
     * старая бинарная книга (OLE2) с расширением .xlsx — xls.
     *
     * @param filename имя файла
     * @param content  содержимое файла
     * @return тип контента по сигнатуре, иначе по расширению
     */
    public static String detectContentType(String filename, byte[] content) {
        String bySignature = typeBySignature(filename, content);
        return bySignature != null ? bySignature : detectContentType(filename);
    }

    /**
     * Тип по сигнатуре содержимого, когда расширение ему не соответствует; {@code null} — определять по расширению.
     */
    private static String typeBySignature(String filename, byte[] content) {
        String byExtension = EXTENSION_MAP.get(extractExtension(filename).toLowerCase());
        if (startsWith(content, PDF_SIGNATURE)) {
            return "pdf";
        }
        if (startsWith(content, ZIP_SIGNATURE) && !isOoxmlType(byExtension)) {
            String ooxml = ooxmlType(content);
            return ooxml != null ? ooxml : "xls".equals(byExtension) ? "xlsx" : null;
        }
        if (startsWith(content, OLE2_SIGNATURE) && "xlsx".equals(byExtension)) {
            return "xls";
        }
        return null;
    }

    private static boolean isOoxmlType(String type) {
        return "docx".equals(type) || "xlsx".equals(type) || "pptx".equals(type);
    }

    /**
     * Документ Office 2007+ по именам первых записей ZIP: word/ — docx, xl/ — xlsx, ppt/ — pptx. Данные записей
     * не распаковываются в память, читаются только заголовки.
     *
     * @param content содержимое ZIP-контейнера
     * @return тип контента либо {@code null}, если это не документ Office
     */
    private static String ooxmlType(byte[] content) {
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(content))) {
            ZipEntry entry;
            for (int i = 0; i < OOXML_SCAN_ENTRIES && (entry = zip.getNextEntry()) != null; i++) {
                String name = entry.getName();
                if (name.startsWith("word/")) {
                    return "docx";
                }
                if (name.startsWith("xl/")) {
                    return "xlsx";
                }
                if (name.startsWith("ppt/")) {
                    return "pptx";
                }
            }
        } catch (IOException e) {
            // повреждённый ZIP: тип берётся по расширению, а понятную ошибку даст разбор
        }
        return null;
    }

    private static boolean startsWith(byte[] content, byte[] signature) {
        if (content == null || content.length < signature.length) {
            return false;
        }
        for (int i = 0; i < signature.length; i++) {
            if (content[i] != signature[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Извлекает имена файлов из списка FilePart.
     * <p>
     * Получает имя файла из заголовка Content-Disposition каждого FilePart.
     *
     * @param files Список FilePart с файлами
     * @return Список имен файлов
     */
    public static List<String> getFilenamesFromFileParts(List<FilePart> files) {
        return files.stream()
                .map(FileUtils::getFilename)
                .toList();
    }

    /**
     * Извлекает имя файла из FilePart через заголовок Content-Disposition.
     * <p>
     * В отличие от {@link FilePart#filename()}, сохраняет относительный путь
     * (например, при загрузке каталога через webkitdirectory).
     *
     * @param filePart загруженный файл
     * @return имя файла (возможно, с относительным путём)
     */
    public static String getFilename(FilePart filePart) {
        HttpHeaders headers = filePart.headers();
        @SuppressWarnings("java:S2583")
        String disposition = headers == null ? null : headers.getFirst(HttpHeaders.CONTENT_DISPOSITION);
        if (disposition == null || disposition.isBlank()) {
            return filePart.filename();
        }
        Matcher matcher = FILENAME_PATTERN.matcher(disposition);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return filePart.filename();
    }

}
