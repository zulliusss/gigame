package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitProcessingProgressEvent;

/**
 * Узел «Контроль» (stop-and-error): проверяет условие на входных данных и,
 * если оно НЕ выполнено, прерывает сценарий с заданным сообщением об ошибке.
 * <p>
 * Конфигурация (те же поля, что у If): field — искомая строка/поле (опционально,
 * сужает проверку до строки, содержащей поле), operator — contains / not_contains /
 * equals / greater_than / less_than, value — сравниваемое значение.
 * Текст сообщения об ошибке — в поле prompt узла.
 * При выполненном условии вход передаётся дальше без изменений.
 */
@Slf4j
public class ScenarioExecutorControlNode extends AbstractScenarioExecutor {

    private static final Pattern NUMBER_PATTERN = Pattern.compile("-?[\\d\\s]+[,.]?\\d*");

    protected ScenarioExecutorControlNode(ScenarioRunNode node) {
        super(node);
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] ControlNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        if (hasParentErrorInput()) {
            // условие на тексте ошибки родителя не вычисляется (not_contains прошёл бы ложно) —
            // контроль не пройден, сценарий останавливается с явной причиной
            String msg = "вход содержит ошибку узла-родителя — условие не проверялось, контроль не пройден";
            prompt = "[контроль без LLM] " + msg;
            emitProcessingProgressEvent(sink, node, 0, 0, "⚠ " + msg);
            throw new ScenarioException("КОНТРОЛЬ: " + msg);
        }
        String inputAll = resolveInput();
        if (inputAll.isBlank()) {
            // нет ни входа, ни документов: not_contains на пустой строке «проходил» бы контроль
            prompt = "[контроль без LLM] вход пуст → НАРУШЕНО";
            throw new ScenarioException("КОНТРОЛЬ: контроль не пройден — вход пуст "
                    + "(узел не получил ни входных данных, ни документов)");
        }
        String field = resolveField();
        String operator = resolveOperator();
        String compareValue = resolveCompareValue();

        String textToCheck = resolveTextToCheck(inputAll, field);
        boolean ok = isConditionMet(operator, textToCheck, compareValue);
        String inputText = describeInput(field);

        updatePrompt(inputText, operator, compareValue, ok);

        if (!ok) {
            throw buildControlException(inputText, operator, compareValue);
        }

        String result = "✓ Контроль пройден: " + inputText + " " + operator + " «" + compareValue + "»";
        node.getOutput().add(result);
        passInputToChildren();
        return result;
    }

    /** Во входе есть текст ошибки узла-родителя (on_error=continue/branch). */
    private boolean hasParentErrorInput() {
        return node.getInput().stream().anyMatch(s -> s.contains(ScenarioEngine.NODE_ERROR_PREFIX));
    }

    /**
     * Собирает входные данные: из документов, если вход пуст, иначе из строк входа.
     */
    private String resolveInput() {
        if (node.getInput().isEmpty() && !node.getDocList().isEmpty()) {
            return node.getDocList().stream()
                    .map(id -> node.getGraph().getDocMap().get(id).getText())
                    .collect(Collectors.joining("\n\n"));
        }
        return String.join("\n\n", node.getInput());
    }

    private String resolveField() {
        return node.getField() == null ? "" : node.getField();
    }

    private String resolveOperator() {
        return node.getOperator() == null ? OPERATOR_CONTAINS : node.getOperator();
    }

    /**
     * Разрешает значение сравнения: если это выражение {{output:...}} / {{json:...}},
     * подставляет результат выражения.
     */
    private String resolveCompareValue() {
        String value = node.getValue() == null ? "" : node.getValue();
        if (ExpressionResolver.hasExpressions(value)) {
            return ExpressionResolver.resolve(value, node.getGraph().getNodeMap());
        }
        return value;
    }

    /**
     * Определяет текст для проверки: если поле — выражение, подставляет его;
     * если поле задано — фильтрует строки входа, содержащие это поле;
     * иначе проверяется весь вход.
     */
    private String resolveTextToCheck(String inputAll, String field) {
        if (ExpressionResolver.hasExpressions(field)) {
            return ExpressionResolver.resolve(field, node.getGraph().getNodeMap());
        }
        if (!field.isEmpty()) {
            StringBuilder matched = new StringBuilder();
            for (String line : inputAll.split("\n")) {
                if (line.toLowerCase().contains(field.toLowerCase())) {
                    matched.append(line).append("\n");
                }
            }
            return matched.toString();
        }
        return inputAll;
    }

    private static String describeInput(String field) {
        return field.isEmpty() ? "вход" : "поле «" + field + "»";
    }

    private void updatePrompt(String inputText, String operator, String compareValue, boolean ok) {
        prompt = "[контроль без LLM] условие: " + inputText
                + " " + operator + " «" + compareValue + "» → " + (ok ? "выполнено" : "НАРУШЕНО");
    }

    /**
     * Создаёт исключение с сообщением об ошибке контроля.
     * Если у узла задан prompt, используется он, иначе генерируется стандартное сообщение.
     */
    private ScenarioException buildControlException(String inputText, String operator, String compareValue) {
        String message = node.getPrompt() == null || node.getPrompt().isBlank()
                ? "Контроль не пройден: " + inputText + " " + operator + " «" + compareValue + "»"
                : node.getPrompt();
        return new ScenarioException("КОНТРОЛЬ: " + message);
    }

    /**
     * Передаёт входные данные дочерним узлам без изменений (контроль прозрачен для данных).
     */
    private void passInputToChildren() {
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.addInputs(node.getId(), node.getInput());
        }
    }

    private boolean isConditionMet(String operator, String textToCheck, String compareValue) {
        return switch (operator) {
            case OPERATOR_NOT_CONTAINS -> !textToCheck.toLowerCase().contains(compareValue.toLowerCase());
            case OPERATOR_EQUALS -> textToCheck.toLowerCase().trim().equals(compareValue.toLowerCase());
            case OPERATOR_GREATER_THAN -> compareNumeric(textToCheck, compareValue, true);
            case OPERATOR_LESS_THAN -> compareNumeric(textToCheck, compareValue, false);
            default -> textToCheck.toLowerCase().contains(compareValue.toLowerCase());
        };
    }

    private boolean compareNumeric(String text, String thresholdStr, boolean greaterThan) {
        try {
            Matcher matcher = NUMBER_PATTERN.matcher(text.replace(" ", ""));
            if (!matcher.find()) {
                return false;
            }
            double val = Double.parseDouble(matcher.group().replace(",", ".").replace(" ", ""));
            double threshold = Double.parseDouble(thresholdStr.replace(",", ".").replace(" ", ""));
            return greaterThan ? val > threshold : val < threshold;
        } catch (Exception e) {
            return false;
        }
    }
}
