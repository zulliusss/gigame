package ru.sber.cs.ai.gigame.service.scenario;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Срок хранения прогонов сценариев. Раз в сутки удаляет прогоны старше
 * {@code app.scenario.run-retention-days} дней (0 — выключено) вместе с шагами
 * (ON DELETE CASCADE) и вопросами агента (внешнего ключа нет — чистятся явно).
 * Выполняющиеся прогоны и последний успешно завершённый прогон каждой пары
 * «сценарий + пользователь» не удаляются: на последнем держится нарастающий итог
 * output-узла («накапливать»).
 * <p>
 * corp23: при выключенной чистке — предупреждение при старте (шаги прогонов растут без предела);
 * отдельно лёгкая ретенция тяжёлых полей: через {@code app.scenario.step-payload-retention-days} дней
 * (по умолчанию 30) у шагов очищаются input_data (полный текст комплекта) и prompt_used, результат и
 * статусы остаются — карточка прогона и нарастающий итог работают как прежде.
 */
@Slf4j
@Service
public class ScenarioRunRetentionService {

    /** Размер пачки удаляемых прогонов в одной транзакции. */
    static final int BATCH_SIZE = 200;

    private final ScenarioRunRepository runRepository;
    private final AgentQuestionRepository questionRepository;
    private final ScenarioRunStepRepository stepRepository;
    private final TransactionTemplate transactionTemplate;

    /** Срок хранения прогонов в днях; 0 и меньше — чистка выключена. */
    @Value("${app.scenario.run-retention-days:0}")
    private int retentionDays;

    /** Срок хранения тяжёлых полей шагов (input_data, prompt_used) в днях; 0 и меньше — не очищаются. */
    @Value("${app.scenario.step-payload-retention-days:30}")
    private int stepPayloadRetentionDays = 30;

    public ScenarioRunRetentionService(PlatformTransactionManager transactionManager,
                                       ScenarioRunRepository runRepository,
                                       AgentQuestionRepository questionRepository,
                                       ScenarioRunStepRepository stepRepository) {
        this.runRepository = runRepository;
        this.questionRepository = questionRepository;
        this.stepRepository = stepRepository;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    /**
     * Предупреждение при старте, если чистка прогонов выключена: шаги прогонов (полные тексты комплектов)
     * копятся без предела.
     */
    @PostConstruct
    void warnIfRetentionDisabled() {
        if (retentionDays <= 0) {
            log.warn("Срок хранения прогонов не задан (app.scenario.run-retention-days=0): шаги прогонов не удаляются; "
                    + "задайте SCENARIO_RUN_RETENTION_DAYS. Тяжёлые поля шагов очищаются через {} дн.", stepPayloadRetentionDays);
        }
    }

    /**
     * Плановая чистка: через 10 минут после старта и далее раз в сутки. Вместе с
     * устаревшими прогонами очищаются тяжёлые поля старых шагов ({@link #purgeStepPayloads})
     * и удаляются вопросы-сироты (см. {@link #purgeOrphanQuestions}).
     */
    @Scheduled(initialDelayString = "${app.scenario.run-retention-initial-delay-ms:600000}",
            fixedDelayString = "${app.scenario.run-retention-interval-ms:86400000}")
    public void purgeExpiredRuns() {
        try {
            OffsetDateTime now = OffsetDateTime.now();
            purgeExpiredRuns(now);
            purgeStepPayloads(now);
            purgeOrphanQuestions();
        } catch (Exception e) {
            log.warn("Чистка прогонов по сроку хранения не выполнена: {}", e.getMessage());
        }
    }

    /**
     * corp17: удаляет вопросы агента прогонов, которых больше нет — прогон удалён
     * вместе со сценарием (каскадом в БД) или до появления внешнего ключа; раньше
     * такие сироты не удалялись никогда. Не зависит от срока хранения прогонов.
     *
     * @return число удалённых вопросов
     */
    int purgeOrphanQuestions() {
        Integer deleted = transactionTemplate.execute(status -> questionRepository.deleteOrphans());
        int count = deleted == null ? 0 : deleted;
        if (count > 0) {
            log.info("Чистка вопросов агента: удалено {} вопросов удалённых прогонов", count);
        }
        return count;
    }

    /**
     * Удаляет прогоны старше срока хранения относительно указанного момента.
     *
     * @param now текущий момент
     * @return число удалённых прогонов
     */
    int purgeExpiredRuns(OffsetDateTime now) {
        if (retentionDays <= 0) {
            return 0;
        }
        OffsetDateTime cutoff = now.minusDays(retentionDays);
        List<UUID> expired = runRepository.findExpiredRunIds(cutoff);
        if (expired.isEmpty()) {
            log.info("Чистка прогонов: устаревших прогонов (старше {} дн.) нет", retentionDays);
            return 0;
        }
        for (int from = 0; from < expired.size(); from += BATCH_SIZE) {
            List<UUID> batch = expired.subList(from, Math.min(from + BATCH_SIZE, expired.size()));
            transactionTemplate.execute(status -> {
                questionRepository.deleteByRunIds(batch);
                runRepository.deleteAllByIdInBatch(batch);
                return null;
            });
        }
        log.info("Чистка прогонов: удалено {} прогонов старше {} дн. (до {})", expired.size(), retentionDays, cutoff);
        return expired.size();
    }

    /**
     * Лёгкая ретенция: у шагов старше {@code app.scenario.step-payload-retention-days} дней очищаются
     * входные данные и промпт; результат и статусы остаются.
     *
     * @param now текущий момент
     * @return число очищенных шагов
     */
    int purgeStepPayloads(OffsetDateTime now) {
        if (stepPayloadRetentionDays <= 0) {
            return 0;
        }
        OffsetDateTime cutoff = now.minusDays(stepPayloadRetentionDays);
        Integer cleared = transactionTemplate.execute(status -> stepRepository.clearPayloadsBefore(cutoff));
        int count = cleared == null ? 0 : cleared;
        if (count > 0) {
            log.info("Чистка шагов: у {} шагов старше {} дн. очищены входные данные и промпт (результаты сохранены)",
                    count, stepPayloadRetentionDays);
        }
        return count;
    }

    void setRetentionDays(int retentionDays) {
        this.retentionDays = retentionDays;
    }

    void setStepPayloadRetentionDays(int stepPayloadRetentionDays) {
        this.stepPayloadRetentionDays = stepPayloadRetentionDays;
    }
}
