package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Сервис для кэширования текстов загруженных документов по идентификаторам диалогов или сценариев.
 * <p>
 * Кэш ограничен числом записей ({@code cache.max-size}, по умолчанию 200) и суммарным объёмом
 * текстов ({@code cache.max-total-chars}, по умолчанию 300 млн символов): при превышении вытесняется
 * самая давняя по обращению запись ДРУГОГО ключа (не та, что записывается, и не та, по которой идёт
 * загрузка) — с предупреждением в лог. TTL ({@code cache.ttl-minutes}, по умолчанию 720 = 12 часов)
 * остаётся запасным: раньше умолчание 10 минут вычищало комплект, пока пользователь читал
 * предупреждения загрузки, и прогон молча шёл по нулю документов. Записи, снятые TTL или
 * вытеснением, запоминаются ({@link #isEvicted(UUID)}): запуск прогона по такому ключу отклоняется
 * с просьбой загрузить документы заново, а не выполняется «успешно» без документов.
 * Фоновая задача чистки запускается раз в минуту ({@code cache.eviction-rate-ms}).
 * <p>
 * Документы сценария хранятся по производному ключу {@link #scenarioKey(UUID, String)}
 * (сценарий + пользователь): общий сценарий запускают разные пользователи, и их
 * загрузки не должны перетирать и подменять друг друга. Диалоги принадлежат одному
 * пользователю и хранятся по идентификатору диалога.
 */
@Service
@Slf4j
public class DocsTextCacheService {

    /**
     * Предел числа запомненных вытесненных ключей ({@link #evictedKeys}): при переполнении набор
     * сбрасывается — это только память о «документы были, но устарели» для отказа в запуске.
     */
    private static final int MAX_EVICTED_KEYS = 10_000;

    /**
     * Максимальное количество диалогов/сценариев в кэше.
     */
    @Value("${cache.max-size:200}")
    private int maxSize;

    /**
     * Время жизни записи в минутах с момента последнего обращения (запасной механизм, 12 часов).
     */
    @Value("${cache.ttl-minutes:720}")
    private int ttlMinutes;

    /**
     * Предел суммарного объёма текстов всех записей кэша, символов; 0 — без предела.
     */
    @Value("${cache.max-total-chars:300000000}")
    private long maxTotalChars;

    /**
     * Хранит тексты загруженных документов для каждого диалога или сценария.
     * Ключ: идентификатор диалога или сценария, Значение: список текстов документов.
     */
    private final Map<UUID, CacheEntry<List<String>>> documentTextsCache = new ConcurrentHashMap<>();
    private final Map<UUID, CacheEntry<List<String>>> fileNamesCache = new ConcurrentHashMap<>();
    private final Map<UUID, CacheEntry<List<String>>> docIdsCache = new ConcurrentHashMap<>();

    /**
     * Сценарии, по которым идёт загрузка документов: их записи не вычищаются по TTL.
     * Разбор второй партии сканов длится десятки минут, и первая партия (форма участника,
     * критерии) без этой защиты устаревала до старта прогона (Комплект 4, 13.09.2026).
     * Значение — число незавершённых загрузок ключа: завершение одной загрузки
     * не снимает защиту, пока идёт другая.
     */
    private final Map<UUID, Integer> uploading = new ConcurrentHashMap<>();

    /**
     * Ключи, чьи записи сняты TTL или вытеснением по числу/объёму (не явной очисткой): документы
     * были, но пропали. Новая запись или явная очистка ключа снимает пометку.
     */
    private final Set<UUID> evictedKeys = ConcurrentHashMap.newKeySet();

    @PostConstruct
    void init() {
        log.info("DocsTextCacheService: maxSize={}, ttl={}min, maxTotalChars={}", maxSize, ttlMinutes, maxTotalChars);
    }

    /**
     * Ключ кэша документов сценария для конкретного пользователя. Общий сценарий
     * запускают разные пользователи: документы одного не должны попадать в прогон
     * другого, а загрузка одного — стирать документы другого. Пустой пользователь
     * приравнивается к «anonymous», как в {@link CurrentUserHolder}: HTTP-загрузка
     * и WebSocket-запуск без заголовка X-UserId получают один и тот же ключ.
     *
     * @param scenarioId идентификатор сценария
     * @param userId     идентификатор пользователя (null или пусто — аноним)
     * @return производный UUID ключа кэша
     */
    public static UUID scenarioKey(UUID scenarioId, String userId) {
        String user = ObjectUtils.isEmpty(userId) ? "anonymous" : userId;
        return UUID.nameUUIDFromBytes((scenarioId + ":" + user).getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Сохраняет тексты документов для указанного id.
     *
     * @param id            идентификатор диалога или сценария
     * @param documentTexts список текстов документов
     */
    public synchronized void cacheDocumentTexts(UUID id, List<String> documentTexts, List<String> fileNames, List<String> docIds) {
        log.info("[{}] Кэширование {} текстов документов для диалога {}", CurrentUserHolder.getCurrentUser(), documentTexts.size(), id);
        evictIfNeeded(id);
        long chars = charsOf(documentTexts);
        // запись перезаписывает свой прежний объём: в предел входит только новый
        evictForVolume(id, chars - charsOfEntry(id));
        documentTextsCache.put(id, new CacheEntry<>(documentTexts, chars));
        fileNamesCache.put(id, new CacheEntry<>(fileNames));
        docIdsCache.put(id, new CacheEntry<>(docIds));
        evictedKeys.remove(id);
    }

    /**
     * Догружает тексты документов к уже закэшированным (для больших наборов,
     * которые не помещаются в один multipart-запрос: партии по ~100 файлов).
     * Если кэша для id ещё нет — эквивалентно {@link #cacheDocumentTexts}.
     * <p>
     * Тексты, имена и идентификаторы обновляются под общей блокировкой записи:
     * снимок {@link #getCachedDocuments(UUID)} не видит их рассогласованными.
     * Чтения отдельных списков блокировку не берут.
     *
     * @param id            идентификатор сценария
     * @param documentTexts тексты новых документов
     * @param fileNames     имена новых документов
     * @param docIds        идентификаторы новых документов
     * @return суммарное число документов в кэше после догрузки
     */
    public synchronized int appendDocumentTexts(UUID id, List<String> documentTexts,
                                   List<String> fileNames, List<String> docIds) {
        // догрузка обходила лимит maxSize: новая запись вытесняет самую давнюю, как и cacheDocumentTexts
        evictIfNeeded(id);
        long added = charsOf(documentTexts);
        evictForVolume(id, added);
        documentTextsCache.compute(id, (key, existing) -> {
            List<String> merged = existing != null
                    ? new ArrayList<>(existing.value)
                    : new ArrayList<>();
            merged.addAll(documentTexts);
            return new CacheEntry<>(merged, (existing == null ? 0 : existing.chars) + added);
        });
        evictedKeys.remove(id);
        fileNamesCache.compute(id, (key, existing) -> {
            List<String> merged = existing != null
                    ? new ArrayList<>(existing.value)
                    : new ArrayList<>();
            merged.addAll(fileNames);
            return new CacheEntry<>(merged);
        });
        docIdsCache.compute(id, (key, existing) -> {
            List<String> merged = existing != null
                    ? new ArrayList<>(existing.value)
                    : new ArrayList<>();
            merged.addAll(docIds);
            return new CacheEntry<>(merged);
        });
        int total = documentTextsCache.get(id).value.size();
        log.info("[{}] Догрузка кэша документов {}: +{}, всего {}", CurrentUserHolder.getCurrentUser(), id, documentTexts.size(), total);
        return total;
    }

    /**
     * Получает тексты документов для указанного id.
     *
     * @param id идентификатор диалога или сценария
     * @return список текстов документов или пустой список, если кэш пуст
     */
    public List<String> getCachedDocumentTexts(UUID id) {
        CacheEntry<List<String>> entry = documentTextsCache.get(id);
        if (entry != null) {
            entry.touch();
            return entry.value;
        }
        return List.of();
    }

    /**
     * Согласованный снимок документов: тексты и имена файлов читаются одной
     * операцией под блокировкой записи (догрузка, очистка и вытеснение не
     * разводят их между собой) и копируются — последующие изменения кэша
     * снимок не меняют. Используется при приёме команды прогона.
     *
     * @param id идентификатор диалога или сценария
     * @return снимок документов либо пустой Optional, если текстов в кэше нет
     */
    public synchronized Optional<CachedDocuments> getCachedDocuments(UUID id) {
        CacheEntry<List<String>> texts = documentTextsCache.get(id);
        if (texts == null) {
            return Optional.empty();
        }
        CacheEntry<List<String>> names = fileNamesCache.get(id);
        texts.touch();
        touchEntry(names);
        List<String> fileNames = names == null ? List.of() : names.value;
        return Optional.of(new CachedDocuments(Collections.unmodifiableList(new ArrayList<>(texts.value)),
                Collections.unmodifiableList(new ArrayList<>(fileNames))));
    }

    /**
     * Получает список файлов для указанного id.
     *
     * @param id идентификатор диалога или сценария
     * @return список текстов документов или null, если кэш пуст
     */
    public List<String> getCachedFileNames(UUID id) {
        var entry = fileNamesCache.get(id);
        if (entry != null) {
            entry.touch();
            return entry.value;
        }
        return List.of();
    }

    /**
     * Получает список идентификаторов документов для указанного id.
     *
     * @param id идентификатор диалога или сценария
     * @return список идентификаторов документов или пустой список, если кэш пуст
     */
    public List<String> getCachedDocIds(UUID id) {
        CacheEntry<List<String>> entry = docIdsCache.get(id);
        if (entry != null) {
            entry.touch();
            return entry.value;
        }
        return List.of();
    }

    /**
     * Удаляет кэш текстов документов для указанного диалога или сценария.
     *
     * @param id идентификатор диалога или сценария
     */
    public synchronized void clearCache(UUID id) {
        log.info("[{}] Очистка кэша документов для диалога(сценария) {}", CurrentUserHolder.getCurrentUser(), id);
        documentTextsCache.remove(id);
        fileNamesCache.remove(id);
        docIdsCache.remove(id);
        // явная очистка (новая загрузка без догрузки, удаление диалога) — не «документы устарели»
        evictedKeys.remove(id);
    }

    /**
     * Были ли документы ключа сняты из кэша не по воле пользователя — по TTL либо вытеснением
     * по числу записей или объёму. По такому ключу запуск прогона отклоняется с просьбой загрузить
     * документы заново; ключ, по которому загрузок не было (или после рестарта сервиса), не помечен.
     *
     * @param id идентификатор диалога или сценария (ключ кэша)
     * @return {@code true}, если записи ключа были вытеснены и с тех пор не перезаписаны
     */
    public boolean isEvicted(UUID id) {
        return evictedKeys.contains(id);
    }

    /**
     * Очищает весь кэш документов.
     */
    @SuppressWarnings("unused")
    public void clearAllCache() {
        log.info("[{}] Очистка всего кэша документов", CurrentUserHolder.getCurrentUser());
        documentTextsCache.clear();
        fileNamesCache.clear();
        docIdsCache.clear();
    }

    /**
     * Фоновая задача: раз в минуту удаляет записи, срок жизни которых истёк.
     */
    @Scheduled(fixedRateString = "${cache.eviction-rate-ms:60000}")
    public synchronized void evictStaleEntries() {
        long now = System.nanoTime();
        long ttlNanos = TimeUnit.NANOSECONDS.convert(ttlMinutes, TimeUnit.MINUTES);
        int removed = 0;
        removed += evictStale(documentTextsCache, now, ttlNanos);
        removed += evictStale(fileNamesCache, now, ttlNanos);
        removed += evictStale(docIdsCache, now, ttlNanos);
        if (removed > 0) {
            log.info("Evicted {} stale cache entries", removed);
        }
    }

    /**
     * Помечает сценарий как занятый загрузкой: пока идёт разбор очередной партии
     * документов, уже закэшированные партии не вычищаются по TTL. Пометки
     * считаются: каждой пометке соответствует одно снятие.
     *
     * @param id идентификатор сценария
     */
    public void markUploading(UUID id) {
        uploading.merge(id, 1, Integer::sum);
        touch(id);
    }

    /**
     * Снимает одну пометку загрузки и продлевает жизнь записей сценария.
     * Защита от TTL снимается, только когда завершены все загрузки ключа.
     *
     * @param id идентификатор сценария
     */
    public void unmarkUploading(UUID id) {
        uploading.computeIfPresent(id, (key, count) -> count > 1 ? count - 1 : null);
        touch(id);
    }

    /**
     * Продлевает жизнь записей сценария без чтения (опрос статуса загрузки клиентом).
     *
     * @param id идентификатор диалога или сценария
     */
    public void touch(UUID id) {
        touchEntry(documentTextsCache.get(id));
        touchEntry(fileNamesCache.get(id));
        touchEntry(docIdsCache.get(id));
    }

    private static void touchEntry(CacheEntry<?> entry) {
        if (entry != null) {
            entry.touch();
        }
    }

    private <V> int evictStale(Map<UUID, CacheEntry<V>> cache, long nowNanos, long ttlNanos) {
        int[] removed = {0};
        cache.entrySet().removeIf(e -> {
            boolean stale = !uploading.containsKey(e.getKey()) && nowNanos - e.getValue().lastAccessNanos > ttlNanos;
            if (stale) {
                removed[0]++;
                markEvicted(e.getKey());
            }
            return stale;
        });
        return removed[0];
    }

    /**
     * Запоминает ключ, снятый TTL или вытеснением: по нему запуск прогона будет отклонён
     * до новой загрузки документов.
     *
     * @param id вытесненный ключ
     */
    private void markEvicted(UUID id) {
        if (evictedKeys.size() >= MAX_EVICTED_KEYS) {
            evictedKeys.clear();
        }
        evictedKeys.add(id);
    }

    /**
     * Суммарная длина текстов записи, символов.
     *
     * @param texts тексты документов ({@code null} — 0)
     * @return сумма длин
     */
    private static long charsOf(List<String> texts) {
        long chars = 0;
        if (texts != null) {
            for (String text : texts) {
                chars += text == null ? 0 : text.length();
            }
        }
        return chars;
    }

    /**
     * Объём текстов записи ключа, символов (0 — записи нет).
     *
     * @param id ключ
     * @return объём записи
     */
    private long charsOfEntry(UUID id) {
        CacheEntry<List<String>> entry = documentTextsCache.get(id);
        return entry == null ? 0 : entry.chars;
    }

    /**
     * Суммарный объём текстов всех записей кэша, символов.
     *
     * @return объём кэша
     */
    private long totalChars() {
        long total = 0;
        for (CacheEntry<List<String>> entry : documentTextsCache.values()) {
            total += entry.chars;
        }
        return total;
    }

    /**
     * Держит суммарный объём текстов в пределе {@code cache.max-total-chars}: пока с учётом
     * записываемых {@code incomingChars} символов предел превышен, вытесняется самая давняя по
     * обращению запись другого ключа (не записываемого и не занятого загрузкой) — с предупреждением
     * в лог, т.к. документы того ключа придётся загружать заново. Если вытеснять нечего (все записи
     * заняты загрузкой или в кэше только записываемый ключ), запись всё равно принимается.
     *
     * @param idToKeep      ключ, который сейчас записывается
     * @param incomingChars сколько символов добавляется (может быть отрицательным при перезаписи меньшим)
     */
    private void evictForVolume(UUID idToKeep, long incomingChars) {
        if (maxTotalChars <= 0) {
            return;
        }
        while (totalChars() + incomingChars > maxTotalChars) {
            Optional<UUID> victim = documentTextsCache.entrySet().stream()
                    .filter(e -> !e.getKey().equals(idToKeep) && !uploading.containsKey(e.getKey()))
                    .min(Map.Entry.comparingByValue(Comparator.comparingLong(a -> a.lastAccessNanos)))
                    .map(Map.Entry::getKey);
            if (victim.isEmpty()) {
                log.warn("[{}] Кэш документов превышает предел {} символов ({} + {}), но вытеснять нечего — запись {} принята сверх предела",
                        CurrentUserHolder.getCurrentUser(), maxTotalChars, totalChars(), incomingChars, idToKeep);
                return;
            }
            UUID oldest = victim.get();
            long freed = charsOfEntry(oldest);
            documentTextsCache.remove(oldest);
            fileNamesCache.remove(oldest);
            docIdsCache.remove(oldest);
            markEvicted(oldest);
            log.warn("[{}] Кэш документов превысил предел {} символов: вытеснена давняя запись {} ({} символов) ради записи {} (+{} символов) — её документы придётся загрузить заново",
                    CurrentUserHolder.getCurrentUser(), maxTotalChars, oldest, freed, idToKeep, incomingChars);
        }
    }

    /**
     * Если кэш заполнен (maxSize), удаляет самую давнюю по обращению запись
     * (не совпадающую с {@code idToKeep}) сразу из всех трёх карт: тексты, имена
     * и идентификаторы документов одного ключа не должны расходиться. Записи,
     * по которым идёт загрузка ({@link #markUploading(UUID)}), не вытесняются —
     * загрузка в диалог одного пользователя не стирает документы, которые
     * другой пользователь ещё догружает в сценарий.
     *
     * @param idToKeep ключ, который сейчас записывается
     */
    private void evictIfNeeded(UUID idToKeep) {
        // maxSize <= 0 (сервис без настроек) — без ограничения размера
        if (maxSize <= 0 || documentTextsCache.size() < maxSize || documentTextsCache.containsKey(idToKeep)) {
            return;
        }
        documentTextsCache.entrySet().stream()
                .filter(e -> !uploading.containsKey(e.getKey()))
                .min(Map.Entry.comparingByValue(
                        Comparator.comparingLong(a -> a.lastAccessNanos)))
                .map(Map.Entry::getKey)
                .ifPresent(oldest -> {
                    documentTextsCache.remove(oldest);
                    fileNamesCache.remove(oldest);
                    docIdsCache.remove(oldest);
                    markEvicted(oldest);
                    log.info("[{}] Evicted oldest cache entry: {}", CurrentUserHolder.getCurrentUser(), oldest);
                });
    }

    /**
     * Снимок документов сценария (диалога): тексты и имена файлов в одном порядке.
     *
     * @param texts     тексты документов
     * @param fileNames имена файлов документов
     */
    public record CachedDocuments(List<String> texts, List<String> fileNames) {

        /**
         * Пустой снимок: документы не загружались либо устарели.
         */
        public static final CachedDocuments EMPTY = new CachedDocuments(List.of(), List.of());
    }

    /**
     * Обёртка для значения кэша с меткой времени последнего доступа.
     */
    private static final class CacheEntry<V> {
        final V value;
        /** Объём текстов записи, символов (у записей имён и идентификаторов — 0). */
        final long chars;
        volatile long lastAccessNanos;

        CacheEntry(V value) {
            this(value, 0);
        }

        CacheEntry(V value, long chars) {
            this.value = value;
            this.chars = chars;
            this.lastAccessNanos = System.nanoTime();
        }

        void touch() {
            this.lastAccessNanos = System.nanoTime();
        }
    }
}
