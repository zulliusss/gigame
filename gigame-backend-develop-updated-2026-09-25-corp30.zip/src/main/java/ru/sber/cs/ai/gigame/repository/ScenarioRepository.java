package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.Scenario;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с сценариями (workflows).
 * <p>
 * Предоставляет методы для управления сценариями и получения списка всех сценариев.
 *
 * @see Scenario
 */
@Repository
public interface ScenarioRepository extends JpaRepository<Scenario, UUID> {

    /**
     * Возвращает все сценарии, отсортированные по дате последнего обновления (новые первыми).
     *
     * @return список всех сценариев
     */
    List<Scenario> findAllByUserIdOrderByUpdatedAtDesc(String userId);

    /**
     * Сценарии, видимые пользователю: его собственные и все общие.
     *
     * @param userId идентификатор пользователя
     * @return сценарии, новые сверху
     */
    List<Scenario> findAllByUserIdOrSharedTrueOrderByUpdatedAtDesc(String userId);

    /**
     * Удаляет сценарий одним запросом, не загружая прогоны и шаги в память:
     * их удаляет БД по FK ON DELETE CASCADE (scenario_runs.scenario_id, scenario_run_steps.run_id).
     *
     * @param id идентификатор сценария
     * @return число удалённых строк (0 — сценария не было)
     */
    @Modifying(flushAutomatically = true, clearAutomatically = true)
    @Query("delete from Scenario s where s.id = :id")
    int deleteScenarioById(@Param("id") UUID id);
}
