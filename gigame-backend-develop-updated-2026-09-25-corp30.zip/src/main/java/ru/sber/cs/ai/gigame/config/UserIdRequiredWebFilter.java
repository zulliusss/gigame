package ru.sber.cs.ai.gigame.config;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;

import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.regex.Pattern;

/**
 * Обязательный заголовок {@code X-UserId} на {@code /api/**} и {@code /ws/**}.
 * <p>
 * Без заголовка все запросы считаются одним пользователем «anonymous» и видят его данные.
 * На корп-контуре заголовок обязан проставлять шлюз, поэтому его отсутствие или недопустимое
 * значение (в том числе литерал «anonymous») — признак запроса в обход шлюза: ответ 401
 * с {@link ErrorResponse}. Включается флагом {@code app.security.require-user-id}
 * (env {@code REQUIRE_USER_ID}, по умолчанию выключен — локальный стенд без шлюза).
 * Actuator, документация и прочие пути не затрагиваются. Путь берётся относительно
 * {@code spring.webflux.base-path}.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class UserIdRequiredWebFilter implements WebFilter {

    /** Допустимое значение заголовка: латиница, цифры, «_» и «-», от 1 до 64 символов. */
    static final Pattern USER_ID = Pattern.compile("^[A-Za-z0-9_-]{1,64}$");
    static final String HEADER = "X-UserId";
    private static final String ANONYMOUS = "anonymous";

    private final boolean required;
    private final ObjectMapper objectMapper;

    public UserIdRequiredWebFilter(@Value("${app.security.require-user-id:false}") boolean required,
                                   ObjectMapper objectMapper) {
        this.required = required;
        this.objectMapper = objectMapper;
        log.info("Обязательный заголовок X-UserId на /api/** и /ws/**: {}", required ? "включён" : "выключен");
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        if (!required || !isProtected(request)) {
            return chain.filter(exchange);
        }
        String userId = request.getHeaders().getFirst(HEADER);
        if (isValid(userId)) {
            return chain.filter(exchange);
        }
        String path = request.getPath().pathWithinApplication().value();
        log.warn("Запрос без допустимого X-UserId отклонён: {} {}", request.getMethod(), path);
        return reject(exchange.getResponse(), userId == null
                ? "Отсутствует обязательный заголовок X-UserId"
                : "Недопустимое значение заголовка X-UserId");
    }

    /**
     * Защищённый ли путь: {@code /api/**} и {@code /ws/**} относительно base-path приложения.
     *
     * @param request запрос
     * @return {@code true} — заголовок обязателен
     */
    static boolean isProtected(ServerHttpRequest request) {
        String path = request.getPath().pathWithinApplication().value();
        return path.startsWith("/api/") || path.startsWith("/ws/");
    }

    /**
     * Допустимое ли значение заголовка: соответствует шаблону и не литерал «anonymous».
     *
     * @param userId значение заголовка (может быть {@code null})
     * @return {@code true} — значение допустимо
     */
    static boolean isValid(String userId) {
        return userId != null && USER_ID.matcher(userId).matches() && !ANONYMOUS.equalsIgnoreCase(userId);
    }

    private Mono<Void> reject(ServerHttpResponse response, String message) {
        response.setStatusCode(HttpStatus.UNAUTHORIZED);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        ErrorResponse body = ErrorResponse.builder()
                .statusCode(HttpStatus.UNAUTHORIZED.value())
                .error(HttpStatus.UNAUTHORIZED.getReasonPhrase())
                .message(message)
                .timestamp(OffsetDateTime.now(ZoneOffset.UTC).truncatedTo(ChronoUnit.MILLIS))
                .build();
        byte[] json;
        try {
            json = objectMapper.writeValueAsBytes(body);
        } catch (JsonProcessingException e) {
            log.error("Ошибка сериализации ответа 401", e);
            json = "{}".getBytes(StandardCharsets.UTF_8);
        }
        return response.writeWith(Mono.just(response.bufferFactory().wrap(json)));
    }
}
