package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO вопроса агента пользователю для ответов {@code GET /api/agent/questions}
 * и {@code POST /api/agent/questions/{id}/answer}.
 * <p>
 * Ключи в snake_case и лимиты — строго по схеме {@code AgentQuestion}
 * статической спецификации: корп. шлюз SOWA отклоняет ответ с лишними ключами
 * (additionalProperties: false). Сущность JPA напрямую не отдаётся.
 *
 * @param id         идентификатор вопроса
 * @param runId      прогон
 * @param scenarioId сценарий
 * @param nodeLabel  метка узла (до 255 символов)
 * @param question   текст вопроса (до 4000 символов)
 * @param answer     ответ пользователя (до 4000 символов)
 * @param answeredAt дата ответа (UTC, микросекунды)
 * @param createdAt  дата создания (UTC, микросекунды)
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        name = "AgentQuestion",
        description = "Вопрос агента пользователю (асинхронный human-in-the-loop)",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentQuestionResponseDto(
        @Schema(
                description = "Уникальный идентификатор вопроса",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Идентификатор прогона",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID runId,

        @Schema(
                description = "Идентификатор сценария",
                nullable = true,
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID scenarioId,

        @Schema(
                description = "Метка узла сценария",
                maxLength = 255,
                pattern = "^[\\w\\W]{0,255}$"
        )
        String nodeLabel,

        @Schema(
                description = "Текст вопроса",
                maxLength = 4000,
                pattern = "^[\\w\\W]{0,4000}$"
        )
        String question,

        @Schema(
                description = "Ответ пользователя",
                nullable = true,
                maxLength = 4000,
                pattern = "^[\\w\\W]{0,4000}$"
        )
        String answer,

        @Schema(
                description = "Дата и время ответа",
                nullable = true,
                maxLength = 32
        )
        OffsetDateTime answeredAt,

        @Schema(
                description = "Дата и время создания вопроса",
                maxLength = 32
        )
        OffsetDateTime createdAt
) {

    /**
     * maxLength поля node_label.
     */
    public static final int NODE_LABEL_MAX_LENGTH = 255;

    /**
     * maxLength полей question и answer.
     */
    public static final int TEXT_MAX_LENGTH = 4000;

    /**
     * Преобразует сущность {@link AgentQuestion} в DTO, приводя значения к
     * лимитам схемы: длинные тексты усекаются с многоточием, даты — в UTC
     * с точностью до микросекунд.
     *
     * @param entity сущность вопроса
     * @return DTO в пределах схемы
     */
    public static AgentQuestionResponseDto from(AgentQuestion entity) {
        return new AgentQuestionResponseDto(
                entity.getId(),
                entity.getRunId(),
                entity.getScenarioId(),
                SchemaLimitUtils.clip(entity.getNodeLabel(), NODE_LABEL_MAX_LENGTH),
                SchemaLimitUtils.clip(entity.getQuestion(), TEXT_MAX_LENGTH),
                SchemaLimitUtils.clip(entity.getAnswer(), TEXT_MAX_LENGTH),
                SchemaLimitUtils.utcMicros(entity.getAnsweredAt()),
                SchemaLimitUtils.utcMicros(entity.getCreatedAt())
        );
    }
}
