package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Проверка одной строки характеристики из таблицы требований по тексту позиции в договоре.
 * <p>
 * Порядок: дословное вхождение (без учёта пробелов, переносов, регистра и знаков препинания) →
 * все слова и числа строки по порядку с небольшими разрывами (номер страницы, обрыв колонки PDF) →
 * те же слова без модальных «должен (быть)», «обязан»: требование «Ричтрак должен быть оснащен фарами» выполняет договор
 * «Ричтрак оснащен фарами» (эталон АЗК, строка «Особенности») →
 * числовой порог «не менее / не более N»: в договоре после названия характеристики берётся число
 * и сравнивается с порогом. Иначе строка считается не найденной — её смысл проверяет модель.
 * <p>
 * Название характеристики для порога ищется целыми словами: «Длина вил» не находится в «Общая длина с вилами - 2410 мм»
 * (иначе за порог «не более 1220» бралось бы 2410 — ложное «ПОРОГ НАРУШЕН»). В пояснении порога значение из договора
 * показывается без соседних характеристик: «в договоре «3200 мм»», а не «3200 мм Эксплуатационная масса с АКБ - 3960 кг …».
 */
final class SpecLineCheck {

    /** Наибольший разрыв (в нормализованных символах) между соседними словами строки в договоре. */
    static final int MAX_GAP = 80;
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern CONDITION = Pattern.compile("не\\s+(менее|ниже|меньше|более|выше|больше)", FLAGS);
    private static final Pattern NUMBER = Pattern.compile("(\\d{1,3}(?:[ \\u00A0]\\d{3})+|\\d+)(?:[.,](\\d+))?\\s*(тыс)?", FLAGS);
    /** Сколько символов исходного текста после названия характеристики просматривается в поисках значения. */
    private static final int VALUE_WINDOW = 120;
    /** Значение порога из договора в пояснении не длиннее (символов). */
    private static final int VALUE_SHOWN = 60;
    /** Конец значения в договоре: «;», «|», запятая перед словом, начало следующей характеристики с заглавной буквы. */
    private static final Pattern VALUE_END = Pattern.compile("[;|]|,\\s+(?=\\p{L})|\\s(?=\\p{Lu}\\p{Ll}{2,})");
    /** Модальные слова требования: «должен быть оснащен» в договоре пишут «оснащен». */
    private static final Set<String> MODAL = Set.of("должен", "должна", "должно", "должны", "обязан", "обязана", "обязано", "обязаны");
    private static final String BE = "быть";
    /** Строка без модальных слов короче (слов) — сверка без них не выполняется: одно слово найдётся где угодно. */
    private static final int MIN_PLAIN_TOKENS = 2;
    private static final Pattern NEGATION = Pattern.compile("(?<![\\p{L}\\p{N}])не(?![\\p{L}\\p{N}])", FLAGS);

    private SpecLineCheck() {
    }

    /** Итог проверки строки. */
    enum Status {
        EXACT, GAPPED, THRESHOLD_OK, THRESHOLD_FAIL, MISSING
    }

    /** Итог проверки: статус и пояснение (пороги или слова, которых нет в договоре). */
    record LineResult(Status status, String detail) {
    }

    /** Участок нормализованного текста договора [from, to). */
    record Block(int from, int to) {
    }

    /**
     * Проверяет строку характеристики по участкам договора, относящимся к позиции.
     *
     * @param line     строка характеристики из таблицы требований
     * @param contract нормализованный текст договора
     * @param blocks   участки договора, относящиеся к позиции
     * @return итог проверки
     */
    static LineResult check(String line, NormalizedText contract, List<Block> blocks) {
        String norm = NormalizedText.normalize(line);
        List<String> tokens = NormalizedText.tokens(line);
        for (Block b : blocks) {
            if (contract.norm().substring(b.from(), b.to()).contains(norm)) {
                return new LineResult(Status.EXACT, "");
            }
        }
        for (Block b : blocks) {
            if (sequenceEnd(contract.norm(), tokens, b) >= 0) {
                return new LineResult(Status.GAPPED, "");
            }
        }
        if (matchesWithoutModal(line, tokens, contract, blocks)) {
            return new LineResult(Status.GAPPED, "");
        }
        LineResult threshold = threshold(line, contract, blocks);
        return threshold != null ? threshold : new LineResult(Status.MISSING, missingWords(tokens, contract, blocks));
    }

    /**
     * Слова строки без модальных «должен (быть)», «обязан» найдены в договоре по порядку. Вхождение, в котором между словами
     * стоит отрицание «не», не засчитывается, если в самой строке «не» нет («Ричтрак не оснащен фарами»).
     *
     * @param line     строка характеристики
     * @param tokens   слова строки
     * @param contract нормализованный текст договора
     * @param blocks   участки договора, относящиеся к позиции
     * @return {@code true}, если строка с модальными словами найдена без них
     */
    private static boolean matchesWithoutModal(String line, List<String> tokens, NormalizedText contract, List<Block> blocks) {
        List<String> plain = withoutModal(tokens);
        if (plain.size() == tokens.size() || plain.size() < MIN_PLAIN_TOKENS) {
            return false;
        }
        boolean lineNegated = NEGATION.matcher(line).find();
        for (Block b : blocks) {
            if (sequenceEnd(contract.norm(), plain, b, (from, to) -> lineNegated || !negated(contract, from, to)) >= 0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Слова без модальных «должен», «должна», «должно», «должны», «обязан…» и следующего за ними «быть».
     *
     * @param tokens нормализованные слова строки
     * @return слова без модальных
     */
    static List<String> withoutModal(List<String> tokens) {
        List<String> result = new ArrayList<>();
        boolean afterModal = false;
        for (String token : tokens) {
            boolean modal = MODAL.contains(token);
            if (!modal && !(afterModal && BE.equals(token))) {
                result.add(token);
            }
            afterModal = modal;
        }
        return result;
    }

    private static boolean negated(NormalizedText contract, int from, int to) {
        int rawFrom = contract.rawPos(from);
        int rawTo = Math.max(rawFrom, contract.rawPos(to - 1) + 1);
        return NEGATION.matcher(contract.raw().substring(rawFrom, rawTo)).find();
    }

    /**
     * Конец последовательного вхождения слов в участке (с разрывами не больше {@link #MAX_GAP}).
     *
     * @param norm   нормализованный текст
     * @param tokens слова по порядку
     * @param block  участок поиска
     * @return позиция после последнего слова либо -1
     */
    static int sequenceEnd(String norm, List<String> tokens, Block block) {
        return sequenceEnd(norm, tokens, block, (start, end) -> true);
    }

    /**
     * Конец первого последовательного вхождения слов в участке, которое принимает условие.
     *
     * @param norm   нормализованный текст
     * @param tokens слова по порядку
     * @param block  участок поиска
     * @param accept условие на вхождение: начало и конец в нормализованном тексте
     * @return позиция после последнего слова либо -1
     */
    private static int sequenceEnd(String norm, List<String> tokens, Block block, BiPredicate<Integer, Integer> accept) {
        if (tokens.isEmpty()) {
            return -1;
        }
        int start = norm.indexOf(tokens.get(0), block.from());
        while (start >= 0 && start < block.to()) {
            int end = followFrom(norm, tokens, start + tokens.get(0).length(), block.to());
            if (end >= 0 && accept.test(start, end)) {
                return end;
            }
            start = norm.indexOf(tokens.get(0), start + 1);
        }
        return -1;
    }

    /**
     * Вхождение начинается и заканчивается на границе слова исходного текста.
     *
     * @param text  текст договора
     * @param start начало вхождения в нормализованном тексте
     * @param end   конец вхождения (исключительно) в нормализованном тексте
     * @return {@code true}, если до начала и после конца нет буквы или цифры
     */
    static boolean wholeWords(NormalizedText text, int start, int end) {
        int before = text.rawPos(start) - 1;
        int after = text.rawPos(end - 1) + 1;
        return (before < 0 || !Character.isLetterOrDigit(text.raw().charAt(before)))
                && (after >= text.raw().length() || !Character.isLetterOrDigit(text.raw().charAt(after)));
    }

    private static int followFrom(String norm, List<String> tokens, int pos, int limit) {
        int cursor = pos;
        for (int i = 1; i < tokens.size(); i++) {
            int at = norm.indexOf(tokens.get(i), cursor);
            if (at < 0 || at - cursor > MAX_GAP || at + tokens.get(i).length() > limit) {
                return -1;
            }
            cursor = at + tokens.get(i).length();
        }
        return cursor;
    }

    private static LineResult threshold(String line, NormalizedText contract, List<Block> blocks) {
        Matcher cm = CONDITION.matcher(line);
        if (!cm.find()) {
            return null;
        }
        Double required = number(line.substring(cm.end()));
        List<String> label = withoutModal(NormalizedText.tokens(line.substring(0, cm.start())));
        if (required == null || label.isEmpty()) {
            return null;
        }
        boolean minimum = isMinimum(cm.group(1));
        for (Block b : blocks) {
            int end = sequenceEnd(contract.norm(), label, b, (from, to) -> wholeWords(contract, from, to));
            if (end >= 0) {
                return compare(contract.snippet(end, end + VALUE_WINDOW, VALUE_WINDOW), required, minimum);
            }
        }
        return null;
    }

    private static LineResult compare(String contractValue, double required, boolean minimum) {
        Matcher cm = CONDITION.matcher(contractValue);
        boolean conditioned = cm.find() && cm.start() < 3;
        String valueText = conditioned ? contractValue.substring(cm.end()) : contractValue;
        Double actual = number(valueText);
        if (actual == null || conditioned && isMinimum(cm.group(1)) != minimum) {
            return null;
        }
        boolean ok = minimum ? actual >= required : actual <= required;
        String detail = "требование " + (minimum ? "не менее " : "не более ") + format(required) + ", в договоре «" + shownValue(contractValue) + "»";
        return new LineResult(ok ? Status.THRESHOLD_OK : Status.THRESHOLD_FAIL, detail);
    }

    /**
     * Значение из договора для пояснения порога: от начала до конца первого числа с единицей, без следующих характеристик
     * («1400 кг Грузоподъёмность остаточная - 500 кг» → «1400 кг»). Иначе в строке «ПОРОГ НАРУШЕН» оказываются чужие числа,
     * и модель или читатель относят их к нарушенной характеристике.
     *
     * @param contractValue текст договора после названия характеристики
     * @return значение с единицей, не длиннее {@link #VALUE_SHOWN} символов
     */
    static String shownValue(String contractValue) {
        String value = contractValue.strip();
        Matcher number = NUMBER.matcher(value);
        if (!number.find()) {
            return cut(value);
        }
        int digitsEnd = number.group(2) != null ? number.end(2) : number.end(1);
        Matcher end = VALUE_END.matcher(value);
        return cut(end.find(digitsEnd) ? value.substring(0, end.start()).strip() : value);
    }

    private static String cut(String value) {
        return value.length() <= VALUE_SHOWN ? value : value.substring(0, VALUE_SHOWN).strip() + "…";
    }

    private static boolean isMinimum(String word) {
        String w = word.toLowerCase(Locale.ROOT);
        return w.startsWith("мен") || w.startsWith("ниж");
    }

    /**
     * Первое число строки с учётом разрядных пробелов, дробной части и множителя «тыс.».
     *
     * @param text строка
     * @return число либо {@code null}
     */
    static Double number(String text) {
        Matcher m = NUMBER.matcher(text);
        if (!m.find()) {
            return null;
        }
        String whole = m.group(1).replaceAll("[ \\u00A0]", "");
        double value = Double.parseDouble(m.group(2) == null ? whole : whole + "." + m.group(2));
        return m.group(3) == null ? value : value * 1000;
    }

    private static String format(double value) {
        return value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value);
    }

    private static String missingWords(List<String> tokens, NormalizedText contract, List<Block> blocks) {
        List<String> missing = new ArrayList<>();
        for (String token : tokens) {
            if (blocks.stream().noneMatch(b -> contract.norm().substring(b.from(), b.to()).contains(token))) {
                missing.add(token);
            }
        }
        return missing.isEmpty() ? "слова есть, но не подряд" : "нет в тексте позиции: " + String.join(", ", missing);
    }
}
