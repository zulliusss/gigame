package ru.sber.cs.ai.gigame.service;

import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Распознавание отказа цензора GigaChat в ответе модели. Основной признак — {@code finish_reason = "blacklist"}
 * в метаданных ответа ({@link #isBlacklisted}; HTTP 200, проба API 16.09.2026). Запасной — фразы отказа: цензор
 * отвечает одним из текстов «Как и любая языковая модель, GigaChat не обладает собственным мнением… разговоры на
 * некоторые темы временно ограничены», «Генеративные языковые модели не обладают собственным мнением… разговоры на
 * чувствительные темы могут быть ограничены», «К сожалению, иногда генеративные языковые модели… ответы на вопросы,
 * связанные с чувствительными темами, временно ограничены» (наблюдалось на п.3.1.1.1 чек-листа ТЗ аудита пожарной
 * безопасности). Без распознавания узел сценария завершался успехом с этим текстом («тихий успех»).
 * <p>
 * Фразы ищутся без учёта регистра (ё = е, пробелы схлопнуты) в первых {@link #WINDOW} знаках ответа; к встроенным
 * {@link #BUILT_IN} добавляются фразы из {@code app.gigachat.refusal-phrases}. Защита от ложных срабатываний:
 * ответ, начинающийся с JSON, блока кода или таблицы, — не отказ; ответ длиннее {@link #LONG_ANSWER} знаков — отказ,
 * только если фраза стоит в первых {@link #LONG_ANSWER_HEAD} знаках. Отказ OCR ({@code ScanOcrService.isRefusal} —
 * просьба предоставить документ) — другой случай, здесь не распознаётся. Что делает клиент при отказе — см.
 * {@link GigaChatClient}: деление контекста с бюджетом вызовов, пометка отклонённых частей, ошибка узла.
 */
@Component
public class GigaChatRefusal {

    /** Ключ настройки дополнительных фраз отказа (YAML-список либо строка через запятую). */
    public static final String PHRASES_PROPERTY = "app.gigachat.refusal-phrases";
    /**
     * Значения finish_reason отказа цензора: {@code blacklist} (API v1) и причины фильтров API v2 (при отдельно
     * согласованном доступе) — в нижнем регистре.
     */
    public static final Set<String> REFUSAL_FINISH_REASONS = Set.of("blacklist", "request_blacklist",
            "request_whitelist", "request_filter", "response_blacklist");
    /** Начало ответа, в котором ищутся фразы отказа, знаков. */
    static final int WINDOW = 600;
    /** Ответ длиннее порога считается отказом, только если фраза стоит в самом начале. */
    static final int LONG_ANSWER = 1500;
    /** «Самое начало» длинного ответа, знаков. */
    static final int LONG_ANSWER_HEAD = 200;
    /** Предел цитаты начала отклонённого фрагмента в маркере, знаков. */
    static final int QUOTE_LIMIT = 60;
    /** Встроенные фразы отказа GigaChat (в нижнем регистре, ё заменена на е). */
    static final List<String> BUILT_IN = List.of(
            "не обладает собственным мнением",
            "не обладают собственным мнением",
            "разговоры на некоторые темы временно ограничены",
            "разговоры на чувствительные темы",
            "связанные с чувствительными темами",
            "не люблю менять тему разговора",
            "что-то в вашем вопросе меня смущает",
            "не могу обсуждать эту тему",
            "предпочту не отвечать");
    private static final Pattern SPACES = Pattern.compile("\\s+");

    private final List<String> phrases;

    /**
     * Конструктор для Spring: дополнительные фразы — из {@value #PHRASES_PROPERTY}
     * (YAML-список либо строка через запятую, например из переменной окружения).
     *
     * @param environment окружение приложения
     */
    @Autowired
    public GigaChatRefusal(Environment environment) {
        this(Binder.get(environment).bind(PHRASES_PROPERTY, Bindable.listOf(String.class)).orElse(List.of()));
    }

    /**
     * Распознавание со встроенными и дополнительными фразами.
     *
     * @param extraPhrases дополнительные фразы отказа (регистр не важен; пустые пропускаются)
     */
    public GigaChatRefusal(List<String> extraPhrases) {
        List<String> all = new ArrayList<>(BUILT_IN);
        for (String phrase : extraPhrases == null ? List.<String>of() : extraPhrases) {
            String normalized = normalize(phrase);
            if (!normalized.isEmpty()) {
                all.add(normalized);
            }
        }
        this.phrases = List.copyOf(all);
    }

    /**
     * Распознавание только со встроенными фразами — до внедрения Spring и в клиентах, созданных вручную.
     *
     * @return распознавание по {@link #BUILT_IN}
     */
    public static GigaChatRefusal defaults() {
        return new GigaChatRefusal(List.of());
    }

    /**
     * Отказ цензора по метаданным ответа: finish_reason из {@link #REFUSAL_FINISH_REASONS} (регистр не важен).
     *
     * @param response ответ модели ({@code null} и ответ без метаданных — не отказ)
     * @return {@code true}, если модель завершила ответ по причине цензора
     */
    public static boolean isBlacklisted(ChatResponse response) {
        return response != null && response.getResults() != null && response.hasFinishReasons(REFUSAL_FINISH_REASONS);
    }

    /**
     * Отказ ли это цензора: фраза отказа в начале ответа, ответ не начинается с данных.
     *
     * @param text ответ модели
     * @return {@code true}, если ответ распознан как отказ
     */
    public boolean isRefusal(String text) {
        String answer = text == null ? "" : text.strip();
        if (answer.isEmpty() || startsWithData(answer)) {
            return false;
        }
        int at = phraseIndex(normalize(answer.substring(0, Math.min(answer.length(), WINDOW))));
        return at >= 0 && (answer.length() <= LONG_ANSWER || at < LONG_ANSWER_HEAD);
    }

    /**
     * Маркер отклонённой моделью части ответа при делении контекста: номер части, знаки контекста и начало фрагмента.
     * Скобки JSON в цитате заменяются круглыми: маркер стоит перед объединённым массивом или между частями, и цитата
     * вида «{"лот": 1}» стала бы первым JSON ответа для {@code LlmJson.first} (Excel-выход, выражения, Форма 3).
     *
     * @param part     номер части (с 1)
     * @param total    число частей
     * @param from     первый знак фрагмента в контексте (с 1)
     * @param to       последний знак фрагмента в контексте
     * @param fragment текст фрагмента (для цитаты начала)
     * @return «[часть k/N (знаки a–b контекста) не обработана: модель отказалась — ограничение темы GigaChat;
     *         начало фрагмента: «…»]»
     */
    public static String partMarker(int part, int total, int from, int to, String fragment) {
        String line = SPACES.matcher(fragment == null ? "" : fragment).replaceAll(" ").strip();
        String head = line.length() <= QUOTE_LIMIT ? line : line.substring(0, QUOTE_LIMIT) + "…";
        String quote = head.replace('{', '(').replace('}', ')').replace('[', '(').replace(']', ')');
        return "[часть " + part + "/" + total + " (знаки " + from + "–" + to + " контекста) не обработана: "
                + "модель отказалась — ограничение темы GigaChat; начало фрагмента: «" + quote + "»]";
    }

    /** Позиция самой ранней фразы отказа в нормализованном тексте либо -1. */
    private int phraseIndex(String head) {
        int first = -1;
        for (String phrase : phrases) {
            int at = head.indexOf(phrase);
            if (at >= 0 && (first < 0 || at < first)) {
                first = at;
            }
        }
        return first;
    }

    /** Ответ начинается с данных: JSON-объект или массив, блок кода, таблица. */
    private static boolean startsWithData(String answer) {
        char first = answer.charAt(0);
        return first == '{' || first == '[' || first == '|' || answer.startsWith("```");
    }

    /** Нижний регистр, ё → е, пробелы схлопнуты. */
    private static String normalize(String text) {
        if (text == null) {
            return "";
        }
        return SPACES.matcher(text.toLowerCase(Locale.ROOT).replace('ё', 'е')).replaceAll(" ").strip();
    }
}
