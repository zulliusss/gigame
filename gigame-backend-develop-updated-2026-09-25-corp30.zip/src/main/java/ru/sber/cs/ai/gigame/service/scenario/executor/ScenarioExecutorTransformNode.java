package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.LlmJson;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitProcessingProgressEvent;

/**
 * Узел «Трансформация»: детерминированные операции над текстом без LLM.
 * <p>
 * Вход — тексты документов узла (если подключены) либо результаты предыдущих узлов.
 * Конфигурация — в поле rules узла (настраивается формой в UI):
 * <pre>
 * {"операции": [
 *   {"оп": "извлечь_regex", "шаблон": "№\\s*(\\d+)", "группа": 1, "все": true, "разделитель": "\n"},
 *   {"оп": "заменить", "найти": "...", "на": "...", "regex": false},
 *   {"оп": "оставить_строки", "шаблон": "..."},
 *   {"оп": "удалить_строки", "шаблон": "..."},
 *   {"оп": "json_поле", "путь": "участники[0].название"},
 *   {"оп": "слить_json_массивы", "дедуп_по": ["тип", "цитата"], "дедуп_регекс": "\\s*\\([^)]*\\)\\s*$"},
 *   {"оп": "проверить_цитаты", "поле": "цитата", "мин_длина": 12, "документы": "^(?!КП_)"},
 *   {"оп": "установить_поле", "поле": "з4", "значение": "ПАСПОРТ", "если_поле": "з2", "шаблон": "^Способ закупки:"},
 *   {"оп": "реестр_документов"},
 *   {"оп": "строки_формы3", "критерии_из_узла": "Критерии (текст)"},
 *   {"оп": "удалить_объекты", "поле": "достоверность", "шаблон": "об отсутствии",
 *        "и_поле": "з4", "и_шаблон": "^(ВЫСОКИЙ|СРЕДНИЙ|НИЗКИЙ)$"},
 *   {"оп": "нумеровать", "поле": "№", "если_поле": "з4", "шаблон": "^(ВЫСОКИЙ|СРЕДНИЙ|НИЗКИЙ)$"},
 *   {"оп": "проверить_секции", "шаблон_секции": "^ЛОТ\\s*№\\s*(\\d+)\\s*\\(Квалификационн",
 *        "ожидаемо_из_узла": "Номера лотов", "критерий_проверки": "Проверка полноты лотов (код)"},
 *   {"оп": "рубли_из_процента", "секция_шаблон": "^ЛОТ\\s*№\\s*(\\d+)"},
 *   {"оп": "даты_из_периода", "суффикс_дат": "календарные даты"},
 *   {"оп": "технологии_из_таблицы", "текст_из_узла": "Раздел 6 (методика оценки)"},
 *   {"оп": "сверить_характеристики", "классы_требований": "документация|техническое_задание", "класс_договора": "договор"},
 *   {"оп": "сверить_подписантов", "класс_договора": "договор"},
 *   {"оп": "сверить_цену_и_сроки"},
 *   {"оп": "сверить_обеспечение"},
 *   {"оп": "месяцы_из_дат", "суффикс_месяцев": "допустимые месяцы", "суффикс_дат": "календарные даты"},
 *   {"оп": "извлечь_из_документов", "имя": "ПЗ", "шаблон": "НМЦД[^\d]{0,40}(\d[\d ]+,\d{2})", "все": true},
 *   {"оп": "взять_символы", "от": 0, "до": 1000},
 *   {"оп": "первые_строки", "n": 20},
 *   {"оп": "последние_строки", "n": 20},
 *   {"оп": "уникальные_строки"}
 * ]}
 * </pre>
 * Операции применяются по цепочке сверху вниз.
 */
@Slf4j
// Служебные короткие ключи JSON-мап, бизнес-шаблоны регулярных выражений и когнитивная сложность
// детерминированных операций узла — правки здесь нецелесообразны (тесты привязаны к формулировкам), см. Rules.md.
// S5852: шаблоны применяются к тексту документа ограниченной длины — риск ReDoS сведён к минимуму.
@SuppressWarnings({"java:S1192", "java:S3776", "java:S5843", "java:S5852", "java:S5854", "java:S5857", "java:S5850",
        "java:S5869", "java:S2479", "java:S5998", "java:S1479", "java:S135", "java:S1168", "java:S3358"})
public class ScenarioExecutorTransformNode extends AbstractScenarioExecutor {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    /**
     * Операции, которые выполняет эта версия бэкенда, — ровно метки case в {@link #apply}.
     * По этому списку граф проверяется до запуска прогона ({@link #unsupportedOperations}).
     */
    public static final Set<String> SUPPORTED_OPERATIONS = Set.of(
            "извлечь_regex", "заменить", "оставить_строки", "удалить_строки", "json_поле", "слить_json_массивы",
            "проверить_цитаты", "удалить_объекты", "установить_поле", "секция_из_заголовков", "последовательность",
            "норма_из_базы", "прикрепить_по_номеру", "нумеровать", "удалить_поля", "элементы_лотов",
            "проверить_технологии_лотов", "дополнить_строки", "рубли_из_процента", "даты_из_периода",
            "технологии_из_таблицы", "сверить_характеристики", "сверить_подписантов", "сверить_цену_и_сроки", "сверить_обеспечение",
            "месяцы_из_дат", "проверить_секции", "реестр_документов", "строки_формы3", "сверить_суммы",
            "проверить_проценты", "сверить_даты", "извлечь_из_документов", "взять_символы", "первые_строки",
            "последние_строки", "уникальные_строки");

    /** Имя операции в проверке графа для элемента без «оп» или с «оп»: null — исполнитель его не выполнит. */
    public static final String OPERATION_NOT_SET = "(не задана)";

    /** Граница между цифрой и буквой (в любом порядке) — для нормализации цитат. */
    private static final Pattern DIGIT_LETTER = Pattern.compile("(?<=\\d)(?=[a-zа-я])|(?<=[a-zа-я])(?=\\d)");

    /** Ядро цитаты в «ёлочках» (не короче 6 символов). */
    private static final Pattern QUOTED_CORE = Pattern.compile("«([^»]{6,})»");

    /** Вердикт признака перед цитатой («засчитывается: …», «не засчитывается: …») — в документе его нет. */
    private static final Pattern VERDICT_PREFIX = Pattern.compile("^\\s*(не )?засчитывается:\\s*",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Заголовок блока предупреждений в конце результата узла. */
    public static final String WARNINGS_HEADER = "=== ПРЕДУПРЕЖДЕНИЯ ===";
    /** Предел длины результата одной операции по умолчанию (настройка {@code app.scenario.max-transform-chars}). */
    public static final int DEFAULT_MAX_TRANSFORM_CHARS = 5_000_000;
    /** Предел списка «последовательность»: «максимум» больше него обрезается (список 10⁹ строк ронял JVM). */
    static final int SEQUENCE_HARD_MAX = 10_000;
    /** Упоминание даты заключения договора («договор … от 01.02.2024») — есть ли что сверять в «сверить_даты». */
    private static final Pattern CONTRACT_DATE = Pattern.compile(
            "договор[а-я]*[^\\n]{0,80}?от\\s+\\d{2}\\.\\d{2}\\.\\d{4}",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Предупреждения операций текущего выполнения (журнал прогона + блок в результате). */
    private final List<String> warnings = new ArrayList<>();
    /** Поток событий текущего выполнения — для предупреждений операций. */
    private FluxSink<ServerSentEvent<Map<String, Object>>> eventSink;
    /** Структурный индекс нормативки по id базы знаний (операция «норма_из_базы»). */
    private java.util.function.Function<java.util.UUID, NormIndex> normIndexLoader;
    /** Предел длины результата одной операции: «заменить» regex-ом мог раздуть текст до OutOfMemoryError. */
    private int maxTransformChars = DEFAULT_MAX_TRANSFORM_CHARS;

    protected ScenarioExecutorTransformNode(ScenarioRunNode node) {
        super(node);
    }

    public void setNormIndexLoader(java.util.function.Function<java.util.UUID, NormIndex> loader) {
        this.normIndexLoader = loader;
    }

    /**
     * Ставит предел длины результата одной операции (настройка {@code app.scenario.max-transform-chars}).
     *
     * @param limit предел в символах (меньше 1 — значение по умолчанию)
     */
    public void setMaxTransformChars(int limit) {
        this.maxTransformChars = limit < 1 ? DEFAULT_MAX_TRANSFORM_CHARS : limit;
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] TransformNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        eventSink = sink;
        warnings.clear();
        String text = inputText();
        List<Map<String, Object>> operations = parseOperations();
        StringBuilder logView = new StringBuilder("[трансформация без LLM]\n");
        for (Map<String, Object> op : operations) {
            String name = String.valueOf(op.get("оп"));
            text = apply(name, op, text);
            logView.append("- ").append(name).append(" → ").append(text.length()).append(" символов\n");
        }
        for (String warning : warnings) {
            logView.append("⚠ ").append(warning).append('\n');
        }
        prompt = logView.toString();
        node.getOutput().add(text);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.addInputs(node.getId(), input);
        }
        // блок предупреждений — в результат шага (карточка шага, итог прогона); в выход для
        // потомков он не попадает: код-потребители (JSON-массивы, значения доноров) его не ждут
        return withWarnings(text);
    }

    /**
     * Предупреждение операции: в журнал прогона (событие «⚠ операция «X»: …»), в лог
     * и в блок «=== ПРЕДУПРЕЖДЕНИЯ ===» результата узла. Раньше заглушки операций
     * («не найдено», «сверка не выполнена») уходили дальше как данные, и журнал молчал.
     *
     * @param operation имя операции
     * @param message   суть предупреждения
     */
    private void warn(String operation, String message) {
        String line = "операция «" + operation + "»: " + message;
        warnings.add(line);
        log.warn("[{}] Свод: {}", currentUser(), line);
        emitProcessingProgressEvent(eventSink, node, 0, 0, "⚠ " + line);
    }

    /**
     * Результат узла с блоком предупреждений в конце (если они были).
     *
     * @param text результат операций
     * @return результат с блоком «=== ПРЕДУПРЕЖДЕНИЯ ===» либо исходный текст
     */
    private String withWarnings(String text) {
        if (warnings.isEmpty()) {
            return text;
        }
        StringBuilder sb = new StringBuilder(text).append("\n\n").append(WARNINGS_HEADER);
        for (String warning : warnings) {
            sb.append("\n- ").append(warning);
        }
        return sb.toString();
    }

    /**
     * Результат узла без блока предупреждений — для кодовых читателей сохранённого
     * результата шага (эталонные числа, строки формы для Excel).
     *
     * @param text результат шага (может быть {@code null})
     * @return текст до блока предупреждений
     */
    public static String stripWarnings(String text) {
        if (text == null) {
            return null;
        }
        int at = text.lastIndexOf("\n\n" + WARNINGS_HEADER);
        return at < 0 ? text : text.substring(0, at);
    }

    private String inputText() {
        if (!node.getDocList().isEmpty()) {
            return node.getDocList().stream()
                    .map(id -> node.getGraph().getDocMap().get(id).getText())
                    .collect(Collectors.joining("\n\n"));
        }
        return String.join("\n\n", node.getInput());
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseOperations() {
        Map<String, Object> config = parseConfig(node.getRules());
        Object ops = config.get("операции");
        if (!(ops instanceof List<?> list) || list.isEmpty()) {
            throw new ScenarioException("Узел «Трансформация»: список операций пуст");
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object o : list) {
            if (o instanceof Map) {
                result.add((Map<String, Object>) o);
            }
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseConfig(Object raw) {
        try {
            if (raw instanceof Map) {
                return (Map<String, Object>) raw;
            }
            if (raw instanceof String s && !s.isBlank()) {
                Map<String, Object> config = MAPPER.readValue(s, Map.class);
                if (config != null) {
                    return config;
                }
            }
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось разобрать конфигурацию: " + e.getMessage());
        }
        throw new ScenarioException("Узел «Трансформация»: не заданы операции (настройте узел в панели)");
    }

    /**
     * Операции из правил узла, которых нет в этой версии бэкенда (нет в {@link #SUPPORTED_OPERATIONS}).
     * <p>
     * Пустые правила, некорректный JSON и конфигурация без массива «операции» ошибкой проверки не считаются —
     * о них, как и прежде, сообщит исполнитель при выполнении узла. Объект операции без «оп» или с «оп»: null
     * исполнитель считает неизвестной операцией, поэтому он попадает в результат как {@link #OPERATION_NOT_SET}.
     *
     * @param rules правила узла «Трансформация» (строка JSON)
     * @return имена неизвестных операций в порядке появления, без повторов
     */
    public static List<String> unsupportedOperations(String rules) {
        Set<String> unknown = new LinkedHashSet<>();
        for (JsonNode op : operationsOf(rules)) {
            String name = operationName(op);
            if (!SUPPORTED_OPERATIONS.contains(name)) {
                unknown.add(name);
            }
        }
        return List.copyOf(unknown);
    }

    /** Имя операции объекта; без «оп», с «оп»: null, объектом или массивом —{@link #OPERATION_NOT_SET}. */
    private static String operationName(JsonNode op) {
        JsonNode name = op.get("оп");
        return name == null || name.isNull() || name.isContainerNode() ? OPERATION_NOT_SET : name.asText();
    }

    /**
     * Массив «операции» из правил узла; для пустых, некорректных и прочих правил — пустой список.
     * По нему проверка графа до запуска компилирует и пробует regex-параметры операций.
     *
     * @param rules правила узла «Трансформация» (строка JSON)
     * @return объекты операций по порядку
     */
    public static List<JsonNode> operationsOf(String rules) {
        if (rules == null || rules.isBlank()) {
            return List.of();
        }
        JsonNode ops;
        try {
            ops = MAPPER.readTree(rules).path("операции");
        } catch (JsonProcessingException e) {
            // некорректный JSON — не ошибка проверки графа: исполнитель узла сообщит о нём, как и прежде
            return List.of();
        }
        List<JsonNode> result = new ArrayList<>();
        if (ops.isArray()) {
            ops.forEach(op -> {
                if (op.isObject()) {
                    result.add(op);
                }
            });
        }
        return result;
    }

    /**
     * Одна кодовая операция по запросу извне (инструменты агента): документы —
     * из графа узла, ошибка возвращается текстом, а не исключением.
     *
     * @param name  имя операции («сверить_суммы», «проверить_цитаты», …)
     * @param op    параметры операции
     * @param input входной текст (для операций над JSON-массивом)
     * @return результат операции или «ОШИБКА: …»
     */
    public String runOperation(String name, Map<String, Object> op, String input) {
        try {
            Map<String, Object> withName = new LinkedHashMap<>(op);
            withName.put("оп", name);
            return apply(name, withName, input == null ? "" : input);
        } catch (RuntimeException e) {
            return "ОШИБКА: " + e.getMessage();
        }
    }

    private String apply(String name, Map<String, Object> op, String text) {
        String result = applyOperation(name, op, text);
        if (result == null) {
            result = "";
        }
        if (result.length() > maxTransformChars) {
            throw new ScenarioException("Узел «Трансформация», операция «" + name + "»: результат "
                    + result.length() + " символов превышает предел " + maxTransformChars + " — сузьте операцию");
        }
        stubWarning(name, result);
        return result;
    }

    /**
     * Целочисленный параметр операции с понятной ошибкой вместо NumberFormatException.
     *
     * @param op       конфиг операции
     * @param key      имя параметра
     * @param fallback значение, если параметр не задан
     * @param opName   имя операции для текста ошибки
     * @return значение параметра
     */
    private static int intParam(Map<String, Object> op, String key, int fallback, String opName) {
        Object raw = op.get(key);
        if (raw == null) {
            return fallback;
        }
        String value = String.valueOf(raw).strip();
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            throw new ScenarioException("Узел «Трансформация», операция «" + opName + "»: параметр «" + key
                    + "» должен быть целым числом, получено «" + value + "»");
        }
    }

    /**
     * Заглушка вместо данных в результате операции («не найдено», «сверка не выполнена»,
     * пустой результат) — предупреждение в журнал прогона и в результат узла.
     *
     * @param name   имя операции
     * @param result результат операции
     */
    private void stubWarning(String name, String result) {
        String message = switch (name) {
            case "извлечь_regex" -> result.isEmpty() ? "совпадений шаблона не найдено — результат пуст" : null;
            case "извлечь_из_документов" -> "не найдено".equals(result) ? "значение в документах не найдено" : null;
            case "сверить_суммы" -> result.endsWith("не найдено")
                    ? "упоминаний сумм рядом с меткой не найдено — сверка не выполнена" : null;
            case "проверить_проценты" -> result.contains("проверка пропущена")
                    ? "базовая сумма (НМЦ) в документах не найдена — проверка пропущена" : null;
            case "сверить_характеристики" -> specStub(result);
            case "сверить_подписантов" -> result.contains("сверка не выполнена")
                    ? "ФИО подписантов в преамбуле не найдены — сверка не выполнена" : null;
            case "сверить_цену_и_сроки" -> priceStub(result);
            default -> null;
        };
        if (message != null) {
            warn(name, message);
        }
    }

    /** JSON договора не найден либо оборван (строки {@link PriceTermOps#TRUNCATED_MARK}: поля после обрыва не проверены). */
    private static String priceStub(String result) {
        if (result.contains("проверка не выполнена")) {
            return "JSON условий договора не найден — проверка не выполнена";
        }
        String truncated = result.lines().filter(line -> line.startsWith(PriceTermOps.TRUNCATED_MARK))
                .map(line -> line.replaceFirst("^⚠\\s*", "")).collect(Collectors.joining("; "));
        return truncated.isEmpty() ? null : truncated;
    }

    /** Заглушка «сверить_характеристики»: нет документов с требованиями, договора или таблицы характеристик. */
    private static String specStub(String result) {
        if (result.contains(SpecCheckOps.NO_REQUIREMENTS)) {
            return "документация и ТЗ не приложены — характеристики не сверены";
        }
        if (result.contains("ДОГОВОР НЕ ПРИЛОЖЕН")) {
            return "договор не приложен — характеристики не сверены";
        }
        if (result.contains("ТАБЛИЦА ХАРАКТЕРИСТИК НЕ НАЙДЕНА")) {
            return "таблица характеристик не найдена — сверка кодом не выполнена";
        }
        return null;
    }

    private String applyOperation(String name, Map<String, Object> op, String text) {
        try {
            return switch (name) {
                case "извлечь_regex" -> extractRegex(op, text);
                case "заменить" -> replaceOp(op, text);
                case "оставить_строки" -> filterLines(op, text, true);
                case "удалить_строки" -> filterLines(op, text, false);
                case "json_поле" -> jsonField(op, text);
                case "слить_json_массивы" -> mergeJsonArrays(op, text);
                case "проверить_цитаты" -> verifyCitations(op, text);
                case "удалить_объекты" -> removeObjects(op, text);
                case "установить_поле" -> setField(op, text);
                case "секция_из_заголовков" -> sectionFromHeaders(op, text);
                case "последовательность" -> sequence(op, text);
                case "норма_из_базы" -> normFromBase(op, text);
                case "прикрепить_по_номеру" -> attachByNumber(op, text);
                case "нумеровать" -> numberObjects(op, text);
                case "удалить_поля" -> removeFields(op, text);
                case "элементы_лотов" -> lotElements(op, text);
                case "проверить_технологии_лотов" -> checkLotTechnologies(op, text);
                case "дополнить_строки" -> addRequiredRows(op, text);
                case "рубли_из_процента" -> rublesFromPercent(op, text);
                case "даты_из_периода" -> datesFromPeriod(op, text);
                case "технологии_из_таблицы" -> technologiesFromTable(op, text);
                case "сверить_характеристики" -> SpecCheckOps.check(op, node.getGraph().getDocMap().values());
                case "сверить_подписантов" -> SignerCheckOps.check(op, node.getGraph().getDocMap().values());
                case "сверить_цену_и_сроки" -> PriceTermOps.check(text);
                case "сверить_обеспечение" -> SecurityCheckOps.check(text);
                case "месяцы_из_дат" -> monthsFromDates(op, text);
                case "проверить_секции" -> checkSections(op, text);
                case "реестр_документов" -> Form3Ops.registry(sources());
                case "строки_формы3" -> Form3Ops.rows(op, text, donorOutput(op, "критерии_из_узла"),
                        donorOutput(op, "форма_из_узла"), donorOutput(op, "шапка_из_узла"));
                case "сверить_суммы" -> compareAmounts(op);
                case "проверить_проценты" -> checkPercentages(op);
                case "сверить_даты" -> compareDates(op);
                case "извлечь_из_документов" -> extractFromDocs(op);
                case "взять_символы" -> substringOp(op, text);
                case "первые_строки" -> headTail(op, text, true);
                case "последние_строки" -> headTail(op, text, false);
                case "уникальные_строки" -> uniqueLines(text);
                default -> throw new ScenarioException("Узел «Трансформация»: неизвестная операция «" + name + "»");
            };
        } catch (PatternSyntaxException e) {
            throw new ScenarioException("Узел «Трансформация», операция «" + name
                    + "»: некорректное регулярное выражение: " + e.getDescription());
        }
    }

    /**
     * Удаляет повторяющиеся строки, сохраняя порядок первых вхождений.
     * Пустые строки отбрасываются. Например, извлечённые regex-ом значения
     * ячеек (повторяющиеся на каждом уровне иерархии) сводятся к перечню
     * уникальных с сохранением привязки к маркерам разделов.
     */
    private String uniqueLines(String text) {
        Set<String> seen = new LinkedHashSet<>();
        for (String line : text.split("\n")) {
            String trimmed = line.strip();
            if (!trimmed.isEmpty()) {
                seen.add(trimmed);
            }
        }
        return String.join("\n", seen);
    }

    private String extractRegex(Map<String, Object> op, String text) {
        Pattern p = SafeRegex.compile(String.valueOf(op.get("шаблон")), Pattern.MULTILINE, "шаблон");
        int group = intParam(op, "группа", 0, "извлечь_regex");
        boolean all = Boolean.parseBoolean(String.valueOf(op.getOrDefault("все", "true")));
        String sep = String.valueOf(op.getOrDefault("разделитель", "\n"));
        Matcher m = SafeRegex.matcher(p, text);
        List<String> found = new ArrayList<>();
        while (m.find()) {
            found.add(m.group(Math.min(group, m.groupCount())));
            if (!all) {
                break;
            }
        }
        return String.join(sep, found);
    }

    private String replaceOp(Map<String, Object> op, String text) {
        String find = String.valueOf(op.get("найти"));
        String repl = String.valueOf(op.getOrDefault("на", ""));
        boolean regex = Boolean.parseBoolean(String.valueOf(op.getOrDefault("regex", "false")));
        if (!regex) {
            return text.replace(find, repl);
        }
        try {
            return SafeRegex.replaceAll(SafeRegex.compile(find, 0, "найти"), text, repl);
        } catch (IndexOutOfBoundsException e) {
            throw new ScenarioException("Узел «Трансформация», операция «заменить»: в замене «на» указана группа, "
                    + "которой нет в шаблоне «найти»: " + e.getMessage());
        }
    }

    private String filterLines(Map<String, Object> op, String text, boolean keep) {
        Pattern p = SafeRegex.compile(String.valueOf(op.get("шаблон")), 0, "шаблон");
        // общий дедлайн на все строки: построчный поиск катастрофическим шаблоном иначе длился бы N × таймаут
        long deadline = SafeRegex.deadline();
        return Arrays.stream(text.split("\n", -1))
                .filter(line -> SafeRegex.matcher(p, line, deadline).find() == keep)
                .collect(Collectors.joining("\n"));
    }

    /**
     * Сливает все JSON-массивы объектов из входного текста в один массив.
     * <p>
     * Детерминированная замена LLM-слиянию: результаты нескольких групп/итераций
     * (каждая выдала свой JSON-массив) объединяются в порядке появления во входе.
     * Массивы ищутся отдельно в каждом блоке вклада родителя «=== РЕЗУЛЬТАТ ОТ "…" ===»
     * ({@link MergeInputScan}): лишняя кавычка модели в выходе одного родителя больше не прячет
     * массивы следующих; в блоке с повреждённой разметкой лишняя кавычка «""ключ":» убирается, незакрытая
     * строка обходится пересинхронизацией, а узел получает предупреждение «в выходе «X» JSON повреждён —
     * часть объектов могла быть пропущена».
     * Числа с десятичной запятой и недопустимые экранирования «\X» чинятся. Если ни одного
     * массива не найдено — ошибка узла; если блок «[…]» во входе есть, но не разбирается, —
     * в ошибке текст ошибки разбора и фрагмент входа вокруг её позиции
     * ({@link LlmJson#arrayParseError}). Необязательный параметр «дедуп_по» (список ключей) убирает
     * повторы: объекты с одинаковыми значениями перечисленных ключей (без учёта
     * регистра и краевых пробелов) схлопываются до первого вхождения — разные
     * группы документов часто выдают одну и ту же находку.
     */
    private String mergeJsonArrays(Map<String, Object> op, String text) {
        // все непересекающиеся массивы по порядку появления (по блокам вкладов родителей); пустой массив — валидный
        // вклад («находок нет»): без этого узел падал на комплектах, где ни один документ не дал записей
        MergeInputScan.Result arrays = MergeInputScan.scan(text);
        if (arrays.arrays().isEmpty()) {
            // «[…]» есть, но не разобран — ошибка парсера и место во входе, а не «массивов нет»
            String parseError = LlmJson.arrayParseError(text);
            throw new ScenarioException("Узел «Трансформация», операция «слить_json_массивы»: "
                    + (parseError == null ? "во входе не найдено ни одного JSON-массива объектов"
                    : "не удалось разобрать JSON-массив: " + parseError));
        }
        arrays.warnings().forEach(warning -> warn("слить_json_массивы", warning));
        List<Object> merged = new ArrayList<>();
        for (JsonNode array : arrays.arrays()) {
            for (Object o : (List<?>) LlmJson.toValue(array)) {
                if (o instanceof Map) {
                    merged.add(o);
                }
            }
        }
        return serializeMerged(excludeTypesByDonor(op, limitByType(op, dedupeByKeys(op, merged))));
    }

    /**
     * Обрезает находки по лимиту на тип (конфиг {@code "лимит_типов"}:
     * {@code {"тип находки": N}}): per-документные вызовы узлов плодят
     * повторы одной и той же кодовой находки с разными цитатами — обычный
     * дедуп их не схлопывает. Типы без лимита не трогаются.
     */
    @SuppressWarnings("unchecked")
    private List<Object> limitByType(Map<String, Object> op, List<Object> merged) {
        if (!(op.get("лимит_типов") instanceof Map<?, ?> limitsRaw) || limitsRaw.isEmpty()) {
            return merged;
        }
        Map<String, Object> limits = (Map<String, Object>) limitsRaw;
        Map<String, Integer> counts = new LinkedHashMap<>();
        List<Object> result = new ArrayList<>();
        for (Object o : merged) {
            String type = String.valueOf(((Map<String, Object>) o).get("тип")).strip().toLowerCase();
            Object limitRaw = null;
            for (Map.Entry<String, Object> e : limits.entrySet()) {
                if (e.getKey().strip().toLowerCase().equals(type)) {
                    limitRaw = e.getValue();
                }
            }
            if (limitRaw == null) {
                result.add(o);
                continue;
            }
            int limit = Integer.parseInt(String.valueOf(limitRaw));
            int used = counts.merge(type, 1, Integer::sum);
            if (used <= limit) {
                result.add(o);
            }
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private List<Object> dedupeByKeys(Map<String, Object> op, List<Object> merged) {
        if (!(op.get("дедуп_по") instanceof List<?> keys) || keys.isEmpty()) {
            return merged;
        }
        String strip = String.valueOf(op.getOrDefault("дедуп_регекс", "")).strip();
        Pattern stripPattern = strip.isEmpty() ? null
                : SafeRegex.compile(strip, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "дедуп_регекс");
        Set<String> seen = new LinkedHashSet<>();
        List<Object> result = new ArrayList<>();
        for (Object o : merged) {
            Map<String, Object> m = (Map<String, Object>) o;
            StringBuilder sig = new StringBuilder();
            for (Object k : keys) {
                Object v = m.get(String.valueOf(k));
                String key = v == null ? "" : String.valueOf(v);
                if (stripPattern != null) {
                    key = SafeRegex.replaceAll(stripPattern, key, "");
                }
                sig.append(key.strip().toLowerCase()).append('\u0001');
            }
            if (seen.add(sig.toString())) {
                result.add(o);
            }
        }
        return result;
    }

    private String serializeMerged(List<Object> merged) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(merged);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать объединённый массив: "
                    + e.getMessage());
        }
    }

    /**
     * Дополняет каждый объект свода находок полями «документ» и «достоверность»:
     * поле «цитата» ищется в текстах всех документов прогона — точное вхождение
     * либо покрытие слов цитаты не ниже 0.8 в окне двойной длины (вставки в
     * тексте документа не мешают). Находки-констатации отсутствия («нет …»,
     * «отсутств…») получают достоверность «н/п (об отсутствии)» — им цитата
     * не полагается. Префикс вердикта признака («засчитывается: », «не засчитывается: »)
     * перед поиском отбрасывается, значение поля не меняется. Параметров у операции нет.
     */
    private String verifyCitations(Map<String, Object> op, String text) {
        // во входе могут быть тексты других узлов со скобками «[ < … > ]» (таблицы документации) — берётся
        // первая «[», с которой разбирается массив объектов
        List<?> arr = parseObjectArray("проверить_цитаты", text);
        Pattern docNames = SafeRegex.compile(String.valueOf(op.getOrDefault("документы", ".")),
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "документы");
        List<DocIndex> docs = node.getGraph().getDocMap().values().stream()
                .filter(d -> SafeRegex.find(docNames, d.getFilename()))
                .map(d -> new DocIndex(d.getFilename(), normForSearch(d.getText())))
                .toList();
        List<Object> out = new ArrayList<>();
        for (Object o : arr) {
            if (o instanceof Map<?, ?> raw) {
                Map<String, Object> m = new LinkedHashMap<>();
                raw.forEach((k, v) -> m.put(String.valueOf(k), v));
                locateCitation(m, docs, String.valueOf(op.getOrDefault("поле", "цитата")),
                        Integer.parseInt(String.valueOf(op.getOrDefault("мин_длина", "12"))));
                out.add(m);
            }
        }
        return serializeMerged(out);
    }

    /**
     * Совпадает ли значение поля объекта с шаблоном (объект не Map или поле
     * отсутствует — не совпадает).
     *
     * @param o       объект массива
     * @param field   имя поля
     * @param pattern шаблон
     * @return {@code true}, если поле есть и шаблон найден в его значении
     */
    private static boolean fieldMatches(Object o, String field, Pattern pattern) {
        Object value = o instanceof Map<?, ?> m ? m.get(field) : null;
        return value != null && SafeRegex.find(pattern, String.valueOf(value));
    }

    /**
     * Проставляет каждому объекту массива поле секции ({@code "поле"}, по умолчанию
     * «секция») — значение поля заголовка ({@code "поле_заголовка"}, по умолчанию
     * «критерий») последнего встреченного объекта-заголовка; заголовок — объект,
     * чей критерий отвечает {@code "шаблон_заголовка"} («ЛОТ №1 (Квалификационные
     * требования)»); сам заголовок секции не получает (пустая строка). Так правила
     * «установить_поле» получают контекст блока: «весь блок квалификационных
     * требований = нет», не затирая строку-заголовок.
     */
    private String sectionFromHeaders(Map<String, Object> op, String text) {
        String field = String.valueOf(op.getOrDefault("поле", "секция")).strip();
        String keyField = String.valueOf(op.getOrDefault("поле_заголовка", "критерий")).strip();
        Pattern header = SafeRegex.compile(String.valueOf(op.getOrDefault("шаблон_заголовка", "^(ЛОТ\\s*№|Общая информация)")),
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "шаблон_заголовка");
        List<?> arr = parseObjectArray("секция_из_заголовков", text);
        String current = "";
        int headers = 0;
        for (Object o : arr) {
            if (o instanceof Map<?, ?> m) {
                @SuppressWarnings("unchecked")
                Map<String, Object> target = (Map<String, Object>) m;
                String key = String.valueOf(target.getOrDefault(keyField, ""));
                if (SafeRegex.find(header, key)) {
                    current = key;
                    headers++;
                    target.put(field, "");
                    continue;
                }
                target.put(field, current);
            }
        }
        log.info("Свод: операция «секция_из_заголовков» нашла {} заголовков", headers);
        return serializeMerged(new ArrayList<>(arr));
    }

    /**
     * Запасной список «1..N»: если вход пуст (пустая строка или JSON-массив без
     * элементов), число N берётся регексом {@code "шаблон"} (первая группа) из выхода
     * узла-донора {@code "из_узла"} — например «Количество лотов закупки | 3» — и
     * возвращается JSON-массив строк {@code ["1","2","3"]} (не более {@code "максимум"},
     * по умолчанию 50). Непустой JSON-массив номеров возвращается без номеров больше N
     * (дата «по лоту 12.05.2026» не порождает лот 12; отключается {@code "отсечь_лишние": "false"});
     * при {@code "если_пусто": "false"} последовательность строится всегда. Без донора,
     * при ненайденном узле-доноре, без числа или при нечисловой группе вход не меняется.
     *
     * @param op   конфиг операции
     * @param text вход (пустой либо JSON-массив номеров)
     * @return JSON-массив номеров лотов
     */
    private String sequence(Map<String, Object> op, String text) {
        boolean onlyIfEmpty = !"false".equalsIgnoreCase(String.valueOf(op.getOrDefault("если_пусто", "true")));
        String trimmed = text == null ? "" : text.strip();
        boolean empty = trimmed.isEmpty() || trimmed.replaceAll("[\\s\\[\\]]", "").isEmpty();
        String donor = String.valueOf(op.getOrDefault("из_узла", "")).strip();
        int n = donorCount(op, donor);
        if (n < 0) {
            return text;
        }
        if (onlyIfEmpty && !empty) {
            boolean clamp = !"false".equalsIgnoreCase(String.valueOf(op.getOrDefault("отсечь_лишние", "true")));
            return clamp ? dropNumbersAbove(text, n, donor) : text;
        }
        // «максимум»: 999999999 строил список 10⁹ строк — OutOfMemoryError всей JVM
        int max = Math.min(intParam(op, "максимум", 50, "последовательность"), SEQUENCE_HARD_MAX);
        if (n > max) {
            log.warn("[{}] Свод: операция «последовательность» — {} больше максимума {}, обрезано", currentUser(), n, max);
            n = max;
        }
        List<String> items = new ArrayList<>();
        for (int i = 1; i <= n; i++) {
            items.add("\"" + i + "\"");
        }
        log.info("[{}] Свод: операция «последовательность» построила список 1..{} по узлу «{}»", currentUser(), n, donor);
        return "[" + String.join(",", items) + "]";
    }

    /**
     * Число из выхода узла-донора для «последовательности»: первая группа регекса
     * {@code "шаблон"} (без группы — всё совпадение), только цифры.
     *
     * @param op    конфиг операции
     * @param donor метка узла-донора
     * @return число либо -1, если донор не задан, не найден, числа нет или группа не число
     */
    private int donorCount(Map<String, Object> op, String donor) {
        String donorText = donorOutput(op, "из_узла");
        if (donor.isEmpty() || donorText.startsWith("[выражение:")) {
            warn("последовательность", "узел-донор «" + donor + "» не задан или не найден — вход оставлен без изменений");
            return -1;
        }
        String regex = String.valueOf(op.getOrDefault("шаблон", "(\\d+)"));
        Matcher m = SafeRegex.matcher(SafeRegex.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "шаблон"), donorText);
        if (!m.find()) {
            warn("последовательность", "число не найдено в выходе узла «" + donor + "» — вход оставлен без изменений");
            return -1;
        }
        String group = m.group(m.groupCount() >= 1 ? 1 : 0);
        if (group == null || !group.strip().matches("\\d{1,9}")) {
            warn("последовательность", "группа «" + group + "» из узла «" + donor + "» не число — вход оставлен без изменений");
            return -1;
        }
        return Integer.parseInt(group.strip());
    }

    /**
     * Оставляет в JSON-массиве номеров только числа не больше N (остальное — ложные
     * совпадения вроде дат); нечисловые элементы и вход не в виде массива не трогаются.
     *
     * @param text  вход — JSON-массив строк/чисел
     * @param n     число лотов по донору
     * @param donor метка узла-донора (для лога)
     * @return массив без лишних номеров
     */
    private String dropNumbersAbove(String text, int n, String donor) {
        if (text == null) {
            return null;
        }
        List<?> items;
        try {
            items = MAPPER.readValue(text.strip(), List.class);
        } catch (Exception e) {
            return text;
        }
        List<Object> kept = new ArrayList<>();
        List<String> dropped = new ArrayList<>();
        for (Object o : items) {
            String s = String.valueOf(o).strip();
            boolean above = s.matches("\\d{1,9}") && Integer.parseInt(s) > n;
            if (above) {
                dropped.add(s);
            } else {
                kept.add(o);
            }
        }
        if (dropped.isEmpty()) {
            return text;
        }
        log.warn("[{}] Свод: операция «последовательность» — номера {} больше числа лотов {} по узлу «{}», отброшены",
                currentUser(), dropped, n, donor);
        try {
            return MAPPER.writeValueAsString(kept);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация», операция «последовательность»: " + e.getMessage());
        }
    }

    /**
     * Присваивает полю объектов JSON-массива значение, если другое поле
     * совпадает с шаблоном (конфиг {@code {"оп": "установить_поле", "поле": "з4",
     * "значение": "ПАСПОРТ", "если_поле": "з2", "шаблон": "^(Способ закупки|НМЦ/НМЦД):"}}).
     * Необязательное {@code "значение_из_узла"} дописывает к значению выход
     * узла с этой меткой (например, способ закупки, определённый кодом), а
     * {@code "кроме_значений"} — regex, при совпадении с которым выход донора
     * не подставляется (например «не найдено»). Так паспорт закупки и уровень
     * находок по материалам участников задаются кодом, а не моделью.
     *
     * @param op   конфиг операции
     * @param text вход с JSON-массивом объектов
     * @return массив с обновлёнными объектами
     * {@code "только_пустые": "true"} — значение ставится лишь в пустое поле.
     */
    private String setField(Map<String, Object> op, String text) {
        String field = String.valueOf(op.getOrDefault("поле", "")).strip();
        String regex = String.valueOf(op.getOrDefault("шаблон", "")).strip();
        if (field.isEmpty() || regex.isEmpty()) {
            return text;
        }
        String condField = String.valueOf(op.getOrDefault("если_поле", field)).strip();
        Pattern pattern = SafeRegex.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "шаблон");
        String value = String.valueOf(op.getOrDefault("значение", ""));
        String donor = String.valueOf(op.getOrDefault("значение_из_узла", "")).strip();
        if (!donor.isEmpty()) {
            String donorText = ExpressionResolver.resolveFull("{{output:" + donor + "}}",
                    node.getGraph().getNodeMap()).strip();
            String skip = String.valueOf(op.getOrDefault("кроме_значений", "")).strip();
            if (!skip.isEmpty() && SafeRegex.find(
                    SafeRegex.compile(skip, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "кроме_значений"), donorText)) {
                // наружу — чистый массив: во входе мог быть текст донора со скобками таблиц «[ < … > ]»
                return serializeMerged(new ArrayList<>(parseObjectArray("установить_поле", text)));
            }
            value += donorText;
        }
        List<?> arr = parseObjectArray("установить_поле", text);
        // «только_пустые»: значение ставится лишь там, где поле ещё не заполнено (запасной текст не затирает ответ агента)
        boolean onlyEmpty = "true".equalsIgnoreCase(String.valueOf(op.getOrDefault("только_пустые", "false")));
        int changed = 0;
        for (Object o : arr) {
            if (fieldMatches(o, condField, pattern) && o instanceof Map<?, ?> m) {
                @SuppressWarnings("unchecked")
                Map<String, Object> target = (Map<String, Object>) m;
                Object existing = target.get(field);
                if (onlyEmpty && existing != null && !String.valueOf(existing).strip().isEmpty()) {
                    continue;
                }
                target.put(field, value);
                changed++;
            }
        }
        log.info("Свод: операция «установить_поле» присвоила «{}» {} объектам", field, changed);
        return serializeMerged(new ArrayList<>(arr));
    }

    /**
     * Текст нормы из базы знаний по реквизиту справочника — кодом, без модели
     * (конфиг {@code {"оп": "норма_из_базы", "реквизит_из": "з9", "поле": "з10",
     * "база_из_узла": "Агент нормы 223-ФЗ", "макс_символов": 600, "макс_норм": 2}}):
     * база берётся у узла с указанной меткой (или {@code "база"} — id явно), для каждого
     * объекта реквизит из поля {@code реквизит_из} разрешается в {@link NormIndex},
     * в поле {@code поле} пишется «реквизит: «текст части» [документ]».
     */
    private String normFromBase(Map<String, Object> op, String text) {
        String from = String.valueOf(op.getOrDefault("реквизит_из", "з9")).strip();
        String field = String.valueOf(op.getOrDefault("поле", "з10")).strip();
        java.util.UUID kbId = normKbId(op);
        if (normIndexLoader == null || kbId == null) {
            warn("норма_из_базы", "база знаний не найдена — поле «" + field + "» не заполнено");
            return text;
        }
        NormIndex index = normIndexLoader.apply(kbId);
        int maxChars = Integer.parseInt(String.valueOf(op.getOrDefault("макс_символов", "600")));
        int maxHits = Integer.parseInt(String.valueOf(op.getOrDefault("макс_норм", "2")));
        List<?> arr = parseObjectArray("норма_из_базы", text);
        int filled = 0;
        for (Object o : arr) {
            if (o instanceof Map<?, ?> m) {
                @SuppressWarnings("unchecked")
                Map<String, Object> target = (Map<String, Object>) m;
                String value = normText(index, String.valueOf(target.getOrDefault(from, "")), maxChars, maxHits);
                if (!value.isEmpty()) {
                    target.put(field, value);
                    filled++;
                }
            }
        }
        log.info("[{}] Свод: операция «норма_из_базы» заполнила «{}» у {} объектов (индекс: {} документов)",
                currentUser(), field, filled, index.size());
        return serializeMerged(new ArrayList<>(arr));
    }

    /**
     * Прикрепляет к N-му объекту JSON-массива текст строки «НАХОДКА №N: …» из выхода
     * узла-донора (конфиг {@code {"оп": "прикрепить_по_номеру", "из_узла": "Агент нормы 223-ФЗ",
     * "поле": "норма_агент", "шаблон": "НАХОДКА №(\\d+):\\s*(.*)"}}): группа 1 шаблона —
     * номер (позиция объекта в массиве, с 1), группа 2 — текст. Так ответы агентов
     * по находкам попадают в сами находки, и дальше каждую можно обрабатывать отдельно.
     * {@code "только_номера_из_узла"} — метка узла с JSON-массивом объектов, чьи поля «№»
     * ограничивают допустимые номера: ответы с другими номерами (например, выдуманные
     * агентом на пустой список проблемных строк) не прикрепляются. {@code "поле_значения"} —
     * поле строки, с которым сверяется «правильно: «X»» из ответа: при совпадении ответ
     * «РАСХОЖДЕНИЕ …» переписывается в «ПОДТВЕРЖДАЮ — значение совпадает …».
     */
    private String attachByNumber(Map<String, Object> op, String text) {
        String field = String.valueOf(op.getOrDefault("поле", "")).strip();
        String donor = String.valueOf(op.getOrDefault("из_узла", "")).strip();
        if (field.isEmpty() || donor.isEmpty()) {
            return text;
        }
        String regex = String.valueOf(op.getOrDefault("шаблон", "(?:НАХОДКА\\s*)?№\\s*(\\d+)\\s*:\\s*(.*)"));
        Pattern p = SafeRegex.compile(regex, 0, "шаблон");
        String donorText = ExpressionResolver.resolveFull("{{output:" + donor + "}}", node.getGraph().getNodeMap());
        Map<Integer, String> byNumber = new LinkedHashMap<>();
        long deadline = SafeRegex.deadline();
        for (String line : donorText.split("\\R")) {
            Matcher m = SafeRegex.matcher(p, line.strip(), deadline);
            if (m.find() && m.groupCount() >= 2 && m.group(1).matches("\\d{1,9}")) {
                byNumber.putIfAbsent(Integer.parseInt(m.group(1)), m.group(2).strip());
            }
        }
        List<?> arr = parseObjectArray("прикрепить_по_номеру", text);
        Set<Integer> allowed = allowedNumbers(op);
        String valueField = String.valueOf(op.getOrDefault("поле_значения", "")).strip();
        int attached = 0;
        for (int i = 0; i < arr.size(); i++) {
            String value = byNumber.get(i + 1);
            if (allowed != null && !allowed.contains(i + 1)) {
                continue;
            }
            if (value != null && arr.get(i) instanceof Map<?, ?> m) {
                @SuppressWarnings("unchecked")
                Map<String, Object> target = (Map<String, Object>) m;
                target.put(field, reconcileAgentText(value, valueField.isEmpty() ? null : target.get(valueField)));
                attached++;
            }
        }
        log.info("[{}] Свод: операция «прикрепить_по_номеру» из «{}» заполнила «{}» у {} объектов из {}",
                currentUser(), donor, field, attached, arr.size());
        return serializeMerged(new ArrayList<>(arr));
    }

    /**
     * Ответ агента с учётом значения строки: «РАСХОЖДЕНИЕ — правильно: «X» …» при X,
     * равном значению строки (без учёта регистра, пробелов и кавычек), становится
     * «ПОДТВЕРЖДАЮ — значение совпадает …» — агент нередко «исправляет» вычисленные
     * даты периода на те же самые, потому что дословно их в документации нет.
     *
     * @param agentText ответ агента по строке
     * @param rowValue  значение строки (null — сверка выключена)
     * @return ответ, возможно переписанный
     */
    static String reconcileAgentText(String agentText, Object rowValue) {
        if (rowValue == null || !agentText.toUpperCase(java.util.Locale.ROOT).startsWith("РАСХОЖДЕНИЕ")) {
            return agentText;
        }
        Matcher m = Pattern.compile("правильно\\s*:\\s*[«\"]?([^»\"]+)[»\"]?", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE)
                .matcher(agentText);
        if (!m.find()) {
            return agentText;
        }
        String normalizedAgent = m.group(1).replaceAll("[\\s«»\"]", "").toLowerCase(java.util.Locale.ROOT);
        String normalizedRow = String.valueOf(rowValue).replaceAll("[\\s«»\"]", "").toLowerCase(java.util.Locale.ROOT);
        if (normalizedAgent.isEmpty() || !normalizedAgent.equals(normalizedRow)) {
            return agentText;
        }
        return "ПОДТВЕРЖДАЮ — значение совпадает (агент указал то же: " + m.group(1).strip() + ")"
                + agentText.substring(m.end()).replaceFirst("^[\\s»\"]*;?\\s*", "; ").replaceFirst("; $", "");
    }

    /**
     * Элементы цикла по лотам из строк таблиц документации этого лота (конфиг
     * {@code {"оп": "элементы_лотов", "номера_из_узла": "Номера лотов", "разделы": [{"метка": "Требования лота (Раздел 2)",
     * "из_узла": "Раздел 2 (требования к участникам)"}, …]}}): вход — JSON-массив номеров лотов (иначе берётся
     * выход {@code "номера_из_узла"}); для каждого номера N из текста каждого раздела вырезаются ячейки таблиц
     * «&lt; Лот №N | … &gt;» и «&lt; N | … &gt;» и строки «Лот №N …»; элемент —
     * «Номер лота: N» и блоки «&lt;метка&gt;:\n&lt;строки лота&gt;» (нет строк — «(строк этого лота в разделе нет)»).
     * Модель в цикле видит требования только своего лота и не путает лоты.
     *
     * @param op   конфиг операции
     * @param text вход (JSON-массив номеров лотов либо пусто)
     * @return JSON-массив строк-элементов
     */
    private String lotElements(Map<String, Object> op, String text) {
        // номера — из первого JSON-массива во входе (вход несёт заголовок «=== РЕЗУЛЬТАТ ОТ … ===»), иначе из донора
        String array = firstJsonArray(text);
        List<String> numbers = donorItems(array.isEmpty() ? firstJsonArray(donorOutput(op, "номера_из_узла")) : array);
        List<Map<String, String>> sections = new ArrayList<>();
        Object raw = op.get("разделы");
        if (raw instanceof List<?> list) {
            for (Object o : list) {
                if (o instanceof Map<?, ?> m) {
                    sections.add(Map.of("метка", String.valueOf(m.get("метка")),
                            "текст", ExpressionResolver.resolveFull("{{output:" + m.get("из_узла") + "}}", node.getGraph().getNodeMap())));
                }
            }
        }
        List<String> items = new ArrayList<>();
        for (String number : numbers) {
            StringBuilder sb = new StringBuilder("Номер лота: ").append(number);
            for (Map<String, String> section : sections) {
                String rows = String.join("\n", lotRows(section.get("текст"), number));
                sb.append("\n").append(section.get("метка")).append(":\n")
                        .append(rows.isEmpty() ? "(строк этого лота в разделе нет — требования общие для всех лотов)" : rows);
            }
            items.add(sb.toString());
        }
        log.info("[{}] Свод: операция «элементы_лотов» построила {} элементов по {} разделам", currentUser(), items.size(), sections.size());
        return serializeMerged(new ArrayList<>(items));
    }

    /**
     * Обязательные строки секций (конфиг {@code {"оп": "дополнить_строки", "секция_шаблон": "^ЛОТ\\s*№",
     * "обязательные": ["Наличие квалификационных требований", …], "значение": "…", "источник": "…"}}): в каждой секции,
     * чьё поле «секция» отвечает регексу, для каждого обязательного критерия, которого нет, после последней строки секции
     * добавляется строка с этим критерием, заданным значением и «достоверность»: «добавлено кодом — модель строку пропустила».
     *
     * @param op   конфиг операции
     * @param text вход с JSON-массивом строк критериев
     * @return массив с добавленными строками
     */
    private String addRequiredRows(Map<String, Object> op, String text) {
        Pattern section = SafeRegex.compile(String.valueOf(op.getOrDefault("секция_шаблон", "^ЛОТ\\s*№")),
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "секция_шаблон");
        List<String> required = new ArrayList<>();
        if (op.get("обязательные") instanceof List<?> list) {
            list.forEach(o -> required.add(String.valueOf(o).strip()));
        }
        String value = String.valueOf(op.getOrDefault("значение", "не извлечено моделью — проверить по документации"));
        String source = String.valueOf(op.getOrDefault("источник", "добавлено кодом"));
        Map<String, List<Map<String, Object>>> bySection = new LinkedHashMap<>();
        List<Object> out = new ArrayList<>();
        for (Object o : parseObjectArray("дополнить_строки", text)) {
            out.add(o);
            if (o instanceof Map<?, ?> m && SafeRegex.find(section, m.get("секция") == null ? "" : String.valueOf(m.get("секция")))) {
                @SuppressWarnings("unchecked")
                Map<String, Object> row = (Map<String, Object>) m;
                bySection.computeIfAbsent(String.valueOf(row.get("секция")), k -> new ArrayList<>()).add(row);
            }
        }
        int added = 0;
        for (Map.Entry<String, List<Map<String, Object>>> e : bySection.entrySet()) {
            Set<String> present = new LinkedHashSet<>();
            e.getValue().forEach(r -> present.add(String.valueOf(r.get("критерий")).strip().toLowerCase(java.util.Locale.ROOT)));
            int insertAt = out.indexOf(e.getValue().get(e.getValue().size() - 1)) + 1;
            for (String criterion : required) {
                if (present.contains(criterion.toLowerCase(java.util.Locale.ROOT))) {
                    continue;
                }
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("критерий", criterion);
                row.put("значение", value);
                row.put("источник", source);
                row.put("секция", e.getKey());
                row.put("достоверность", "добавлено кодом — модель строку пропустила");
                out.add(insertAt++, row);
                added++;
            }
        }
        log.info("[{}] Свод: операция «дополнить_строки» добавила {} обязательных строк в {} секций", currentUser(), added, bySection.size());
        return serializeMerged(out);
    }

    /**
     * Порог сопоставимого опыта в рублях считается кодом из процента от НМЦД лота
     * (см. {@link LotThresholdOps}): объединённая ячейка «100% от НМЦД» таблицы Раздела 2
     * достаётся при разборе docx только первому лоту, и модель для остальных лотов пишет «Нет».
     */
    private String rublesFromPercent(Map<String, Object> op, String text) {
        List<Object> rows = new ArrayList<>(parseObjectArray("рубли_из_процента", text));
        int done = LotThresholdOps.rublesFromPercent(op, rows);
        log.info("[{}] Свод: операция «рубли_из_процента» рассчитала {} порогов в рублях", currentUser(), done);
        return serializeMerged(rows);
    }

    /**
     * Строки «Технология N» методических секций лотов — из таблицы Раздела 6 «Номер лота | Технологии»
     * (см. {@link LotTechTableOps}): в цикле по лотам модель теряла и искажала технологии.
     */
    private String technologiesFromTable(Map<String, Object> op, String text) {
        List<Object> rows = new ArrayList<>(parseObjectArray("технологии_из_таблицы", text));
        int done = LotTechTableOps.apply(rows, donorOutput(op, "текст_из_узла"));
        log.info("[{}] Свод: операция «технологии_из_таблицы» записала технологии {} лотов из таблицы", currentUser(), done);
        return serializeMerged(rows);
    }

    /**
     * Календарные даты периода опыта считаются кодом из формулировки периода и даты начала
     * срока подачи заявок (см. {@link PeriodDatesOps}): модель переносила в строку даты из примера промпта.
     */
    private String datesFromPeriod(Map<String, Object> op, String text) {
        List<Object> rows = new ArrayList<>(parseObjectArray("даты_из_периода", text));
        int done = PeriodDatesOps.datesFromPeriod(op, rows);
        log.info("[{}] Свод: операция «даты_из_периода» пересчитала {} периодов", currentUser(), done);
        return serializeMerged(rows);
    }

    /**
     * Перечень допустимых месяцев периода считается кодом из строки «… — календарные даты»
     * (см. {@link PeriodMonthsOps}): на длинных периодах модель сокращает перечень многоточием.
     */
    private String monthsFromDates(Map<String, Object> op, String text) {
        List<Object> rows = new ArrayList<>(parseObjectArray("месяцы_из_дат", text));
        int done = PeriodMonthsOps.monthsFromDates(op, rows);
        log.info("[{}] Свод: операция «месяцы_из_дат» пересчитала {} перечней месяцев", currentUser(), done);
        return serializeMerged(rows);
    }

    /**
     * Текст раздела без строк, относящихся к какому-либо лоту (ячейки «&lt; Лот №N | … &gt;», «&lt; N | … &gt;»
     * и строки «Лот №N …»), — то, что документация говорит для всех лотов.
     *
     * @param text текст раздела
     * @return текст без строк лотов
     */
    static String lotFreeText(String text) {
        if (text == null) {
            return "";
        }
        String withoutCells = text.replaceAll("(?iu)<\\s*(?:Лот[а-яё]*\\s*№?\\s*)?\\d{1,2}(?![\\d.,])\\s*\\|[^>]*>", " ");
        return withoutCells.replaceAll("(?ium)^[^\\n<]*(?<![а-яё])Лот[а-яё]*\\s*№?\\s*\\d{1,2}(?![\\d.,])[^\\n]*$", " ");
    }

    /** Первый разбираемый JSON-массив в тексте либо пустая строка. */
    private static String firstJsonArray(String text) {
        LlmJson.Parsed block = text == null ? null : LlmJson.first(text, LlmJson.ARRAY).first();
        return block == null ? "" : block.json();
    }

    /**
     * Строки документации, относящиеся к лоту: ячейки таблиц «&lt; Лот №N | … &gt;» / «&lt; N | … &gt;»
     * и строки текста «Лот №N …» (границы — не цифры).
     *
     * @param text   текст раздела
     * @param number номер лота
     * @return найденные строки по порядку, без повторов
     */
    static List<String> lotRows(String text, String number) {
        Set<String> rows = new LinkedHashSet<>();
        if (text == null || number == null || number.isBlank()) {
            return List.of();
        }
        String n = Pattern.quote(number.strip().replaceFirst("^0+(?=\\d)", ""));
        Matcher cell = Pattern.compile("<\\s*(?:Лот[а-яё]*\\s*№?\\s*)?0*" + n + "(?![\\d.,])\\s*\\|([^>]*)>",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE).matcher(text);
        while (cell.find()) {
            rows.add(cell.group(0).strip());
        }
        Matcher line = Pattern.compile("^[^\\n<]*(?<![а-яё])Лот[а-яё]*\\s*№?\\s*0*" + n + "(?![\\d.,])[^\\n]*$",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.MULTILINE).matcher(text);
        while (line.find()) {
            rows.add(line.group(0).strip());
        }
        return new ArrayList<>(rows);
    }

    /**
     * Кодовая сверка технологий по лотам (конфиг {@code {"оп": "проверить_технологии_лотов", "элементы_из_узла":
     * "Элементы цикла по лотам", "удалять": "true"}}): у объекта с критерием «Технология N» и секцией «ЛОТ №K …»
     * значение ищется в элементе цикла лота K (строки таблиц этого лота); не найдено — «достоверность» =
     * «нет в строках лота K» и при {@code "удалять": "true"} объект убирается (модель приписала лоту чужую технологию).
     * Без строк лота в элементе (требования общие) проверка не применяется.
     *
     * @param op   конфиг операции
     * @param text вход с JSON-массивом строк критериев
     * @return массив с пометками (и без чужих технологий)
     */
    private String checkLotTechnologies(Map<String, Object> op, String text) {
        Map<String, String> elements = new LinkedHashMap<>();
        for (Object item : donorScalars(donorOutput(op, "элементы_из_узла"))) {
            Matcher m = Pattern.compile("^Номер лота:\\s*(\\d+)").matcher(String.valueOf(item));
            if (m.find()) {
                elements.put(m.group(1), String.valueOf(item));
            }
        }
        boolean drop = "true".equalsIgnoreCase(String.valueOf(op.getOrDefault("удалять", "false")));
        // общий текст разделов (без строк любых лотов): технология «для всех лотов» законна для каждого лота
        StringBuilder common = new StringBuilder();
        if (op.get("общий_текст_из_узлов") instanceof List<?> labels) {
            for (Object label : labels) {
                common.append(lotFreeText(ExpressionResolver.resolveFull("{{output:" + label + "}}", node.getGraph().getNodeMap()))).append('\n');
            }
        }
        Pattern section = Pattern.compile("ЛОТ\\s*№\\s*0*(\\d+)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        List<Object> out = new ArrayList<>();
        int flagged = 0;
        for (Object o : parseObjectArray("проверить_технологии_лотов", text)) {
            if (!(o instanceof Map<?, ?> m) || !String.valueOf(m.get("критерий")).strip().startsWith("Технология")) {
                out.add(o);
                continue;
            }
            String sectionName = String.valueOf(m.get("секция"));
            Matcher s = section.matcher(sectionName);
            String element = s.find() ? lotBlock(elements.get(s.group(1)), sectionName) : null;
            String value = String.valueOf(m.get("значение")).strip();
            if (element == null || element.contains("(строк этого лота в разделе нет") || value.isEmpty()
                    || Form3Ops.containsTechnology(element, value)
                    || !common.isEmpty() && Form3Ops.containsTechnology(common.toString(), value)) {
                out.add(o);
                continue;
            }
            flagged++;
            @SuppressWarnings("unchecked")
            Map<String, Object> target = (Map<String, Object>) m;
            target.put("достоверность", "нет в строках лота " + s.group(1));
            if (!drop) {
                out.add(o);
            }
        }
        log.info("[{}] Свод: операция «проверить_технологии_лотов» — технологий не из строк своего лота: {}{}",
                currentUser(), flagged, drop ? " (убраны)" : "");
        return serializeMerged(out);
    }

    /**
     * Блок элемента цикла, отвечающий секции критериев: квалификационная — блок с заголовком про Раздел 2,
     * методическая — про Раздел 6 (заголовок блока — строка «… (строки Раздела N …):»); без такого блока — весь элемент.
     *
     * @param element     элемент цикла лота
     * @param sectionName название секции («ЛОТ №K (Квалификационные требования)» / «… (Методические требования)»)
     * @return текст блока либо весь элемент (null — элемента нет)
     */
    static String lotBlock(String element, String sectionName) {
        if (element == null) {
            return null;
        }
        String wanted = sectionName.toLowerCase(java.util.Locale.ROOT).contains("методич") ? "6" : "2";
        String[] lines = element.split("\\n");
        StringBuilder block = null;
        for (String line : lines) {
            Matcher header = Pattern.compile("(?iu)раздел[а-я]*\\s*(\\d+)").matcher(line);
            boolean isHeader = line.strip().endsWith(":") && header.find();
            if (isHeader) {
                if (block != null) {
                    break;
                }
                if (wanted.equals(header.group(1))) {
                    block = new StringBuilder();
                }
                continue;
            }
            if (block != null) {
                block.append(line).append('\n');
            }
        }
        return block == null ? element : block.toString();
    }

    /**
     * Допустимые номера для «прикрепить_по_номеру»: поля «№» объектов JSON-массива узла
     * {@code "только_номера_из_узла"}; без опции — null (ограничения нет), при пустом
     * или неразборчивом выходе узла — пустое множество (ничего не прикрепляется).
     *
     * @param op конфиг операции
     * @return множество номеров либо null
     */
    private Set<Integer> allowedNumbers(Map<String, Object> op) {
        String label = String.valueOf(op.getOrDefault("только_номера_из_узла", "")).strip();
        if (label.isEmpty()) {
            return null;
        }
        Set<Integer> numbers = new LinkedHashSet<>();
        String donorText = donorOutput(op, "только_номера_из_узла");
        if (donorText.startsWith("[выражение:")) {
            warn("прикрепить_по_номеру", "узел «" + label + "» («только_номера_из_узла») не найден — ничего не прикреплено");
            return numbers;
        }
        try {
            for (Object o : parseObjectArray("прикрепить_по_номеру", donorText)) {
                Object raw = o instanceof Map<?, ?> m ? m.get("№") : null;
                String n = raw == null ? "" : String.valueOf(raw).strip();
                if (n.matches("\\d{1,9}")) {
                    numbers.add(Integer.parseInt(n));
                }
            }
        } catch (ScenarioException e) {
            warn("прикрепить_по_номеру", "у узла «" + label + "» нет массива номеров — ничего не прикреплено");
        }
        return numbers;
    }

    /**
     * Удаляет у каждого объекта JSON-массива перечисленные поля (конфиг
     * {@code {"оп": "удалить_поля", "поля": "исходная_строка, к2"}}, имена через запятую) —
     * например, чтобы агенту не уходили длинные служебные графы.
     *
     * @param op   конфиг операции
     * @param text вход с JSON-массивом объектов
     * @return массив без указанных полей
     */
    private String removeFields(Map<String, Object> op, String text) {
        List<String> fields = new ArrayList<>();
        Object raw = op.getOrDefault("поля", "");
        List<?> items = raw instanceof List<?> list ? list : List.of(String.valueOf(raw).split(","));
        for (Object f : items) {
            if (!String.valueOf(f).strip().isEmpty()) {
                fields.add(String.valueOf(f).strip());
            }
        }
        if (fields.isEmpty()) {
            return text;
        }
        List<?> arr = parseObjectArray("удалить_поля", text);
        int removed = 0;
        for (Object o : arr) {
            if (o instanceof Map<?, ?> m) {
                for (String f : fields) {
                    removed += m.containsKey(f) ? 1 : 0;
                    m.remove(f);
                }
            }
        }
        log.info("[{}] Свод: операция «удалить_поля» убрала {} значений полей {} у {} объектов",
                currentUser(), removed, fields, arr.size());
        return serializeMerged(new ArrayList<>(arr));
    }

    /**
     * Проставляет каждому объекту JSON-массива поле ({@code "поле"}, по умолчанию «№»)
     * — позицию объекта в массиве, с 1, строкой («3»); существующее значение
     * перезаписывается (конфиг {@code {"оп": "нумеровать", "поле": "№"}}). Так номера
     * строк свода задаются кодом после всех слияний и удалений, а не моделью.
     * <p>
     * Необязательные {@code "если_поле"} и {@code "шаблон"} (заданы оба) — нумеруются только
     * объекты, в значении поля «если_поле» которых найден шаблон (без учёта регистра), номера
     * 1, 2, 3… идут подряд среди них; остальные объекты не меняются (конфиг {@code {"оп": "нумеровать",
     * "поле": "з1", "если_поле": "з4", "шаблон": "^(ВЫСОКИЙ|СРЕДНИЙ|НИЗКИЙ)$"}} — паспортные строки
     * «ПАСПОРТ» без номера).
     *
     * @param op   конфиг операции
     * @param text вход с JSON-массивом объектов
     * @return массив с пронумерованными объектами
     */
    private String numberObjects(Map<String, Object> op, String text) {
        String field = String.valueOf(op.getOrDefault("поле", "№")).strip();
        if (field.isEmpty()) {
            field = "№";
        }
        String condField = String.valueOf(op.getOrDefault("если_поле", "")).strip();
        String regex = String.valueOf(op.getOrDefault("шаблон", "")).strip();
        Pattern condition = condField.isEmpty() || regex.isEmpty() ? null
                : SafeRegex.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "шаблон");
        List<?> arr = parseObjectArray("нумеровать", text);
        int numbered = 0;
        for (int i = 0; i < arr.size(); i++) {
            Object o = arr.get(i);
            if (o instanceof Map<?, ?> m && (condition == null || fieldMatches(o, condField, condition))) {
                @SuppressWarnings("unchecked")
                Map<String, Object> target = (Map<String, Object>) m;
                numbered++;
                // без условия номер — позиция в массиве (как прежде), с условием — порядок среди подходящих
                target.put(field, String.valueOf(condition == null ? i + 1 : numbered));
            }
        }
        log.info("[{}] Свод: операция «нумеровать» проставила «{}» {} объектам", currentUser(), field, numbered);
        return serializeMerged(new ArrayList<>(arr));
    }

    /**
     * Сверяет число секций-заголовков в JSON-массиве с ожидаемым числом элементов у
     * узла-донора (конфиг {@code {"оп": "проверить_секции", "шаблон_секции":
     * "^ЛОТ\\s*№\\s*(\\d+)\\s*\\(Квалификационн", "ожидаемо_из_узла": "Номера лотов",
     * "критерий_проверки": "Проверка полноты лотов (код)"}}): заголовок — объект, чьё
     * {@code "поле_заголовка"} (по умолчанию «критерий») отвечает регексу; номер лота —
     * первая группа регекса (без группы — весь заголовок). У донора один элемент — одна
     * непустая строка выхода либо элемент JSON-массива строк/чисел ({@code ["1","2"]}).
     * В конец массива добавляется строка {@code {"критерий": …, "значение": "извлечено M из N",
     * "источник": …, "достоверность": "проверка кодом"}} (M — число найденных ожидаемых
     * лотов без повторов, N — число лотов у донора): при полном совпадении —
     * «извлечено N из N — полно» и перечень лотов, при нехватке — «не извлечены лоты: …»,
     * при избытке или повторе заголовка — «лишние секции: …»; если донор не задан, не найден или пуст —
     * «ожидаемое число лотов неизвестно» с пояснением. Номера сравниваются строками
     * без краевых пробелов и ведущих нулей. Так полнота выгрузки лотов проверяется кодом.
     *
     * @param op   конфиг операции
     * @param text вход с JSON-массивом объектов
     * @return массив с добавленной строкой проверки
     */
    private String checkSections(Map<String, Object> op, String text) {
        String keyField = String.valueOf(op.getOrDefault("поле_заголовка", "критерий")).strip();
        Pattern section = SafeRegex.compile(String.valueOf(op.getOrDefault("шаблон_секции", "^ЛОТ\\s*№\\s*(\\d+)")),
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "шаблон_секции");
        String criterion = String.valueOf(op.getOrDefault("критерий_проверки", "Проверка полноты лотов (код)")).strip();
        String donor = String.valueOf(op.getOrDefault("ожидаемо_из_узла", "")).strip();
        List<?> arr = parseObjectArray("проверить_секции", text);
        List<String> found = sectionNumbers(arr, keyField, section);
        String donorText = donorOutput(op, "ожидаемо_из_узла");
        // ExpressionResolver сигналит об отсутствии узла текстом «[выражение: узел «…» не найден]»
        boolean donorMissing = donor.isEmpty() || donorText.startsWith("[выражение:");
        List<String> expected = donorMissing ? List.of() : donorItems(donorText);
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("критерий", criterion);
        if (expected.isEmpty()) {
            row.put("значение", "ожидаемое число лотов неизвестно");
            row.put("источник", unknownExpectedReason(donor, donorMissing, found));
        } else {
            fillSectionsVerdict(row, found, expected);
        }
        row.put("достоверность", "проверка кодом");
        List<Object> out = new ArrayList<>(arr);
        out.add(row);
        log.info("[{}] Свод: операция «проверить_секции» — секций {}, ожидалось {} (узел «{}»): {}; {}",
                currentUser(), found.size(), expected.size(), donor, row.get("значение"), row.get("источник"));
        return serializeMerged(out);
    }

    /**
     * Номера секций-заголовков массива по порядку: первая группа регекса либо весь
     * заголовок, нормализованные для сравнения.
     *
     * @param arr      массив объектов
     * @param keyField поле заголовка
     * @param section  регекс заголовка секции
     * @return номера секций
     */
    private static List<String> sectionNumbers(List<?> arr, String keyField, Pattern section) {
        List<String> numbers = new ArrayList<>();
        for (Object o : arr) {
            Object raw = o instanceof Map<?, ?> m ? m.get(keyField) : null;
            String key = raw == null ? "" : String.valueOf(raw);
            Matcher matcher = SafeRegex.matcher(section, key);
            if (matcher.find()) {
                String number = matcher.groupCount() >= 1 && matcher.group(1) != null ? matcher.group(1) : key;
                numbers.add(normalizeLotNumber(number));
            }
        }
        return numbers;
    }

    /**
     * Элементы выхода донора без повторов: значения JSON-массива строк/чисел либо
     * непустые строки текста, нормализованные как номера лотов.
     *
     * @param donorText выход узла-донора
     * @return ожидаемые номера лотов
     */
    private static List<String> donorItems(String donorText) {
        Set<String> items = new LinkedHashSet<>();
        for (Object item : donorScalars(donorText)) {
            String s = item == null ? "" : String.valueOf(item).strip();
            if (!s.isEmpty()) {
                items.add(normalizeLotNumber(s));
            }
        }
        return new ArrayList<>(items);
    }

    /** Элементы JSON-массива скаляров, если выход донора — такой массив, иначе строки текста. */
    private static List<?> donorScalars(String donorText) {
        String t = donorText.strip();
        if (t.startsWith("[") && t.endsWith("]")) {
            try {
                List<?> arr = MAPPER.readValue(t, List.class);
                if (arr.stream().noneMatch(o -> o instanceof Map || o instanceof List)) {
                    return arr;
                }
            } catch (Exception ignored) {
                // не JSON-массив — считаем непустые строки текста
            }
        }
        return Arrays.asList(t.split("\\R"));
    }

    /** Номер лота для сравнения: без краевых пробелов и ведущих нулей («03» → «3»). */
    private static String normalizeLotNumber(String raw) {
        return raw.strip().replaceFirst("^0+(?=\\d)", "");
    }

    /**
     * Заполняет «значение» и «источник» строки проверки по найденным номерам секций
     * и ожидаемым номерам донора: лишней считается секция, номера которой нет у донора
     * либо которая повторяется; не извлечённым — номер донора без заголовка.
     *
     * @param row      строка проверки
     * @param found    номера найденных секций по порядку
     * @param expected ожидаемые номера без повторов
     */
    private static void fillSectionsVerdict(Map<String, Object> row, List<String> found, List<String> expected) {
        Set<String> seen = new LinkedHashSet<>();
        List<String> extra = new ArrayList<>();
        for (String number : found) {
            if (!expected.contains(number) || !seen.add(number)) {
                extra.add(number);
            }
        }
        List<String> missing = new ArrayList<>();
        for (String number : expected) {
            if (!seen.contains(number)) {
                missing.add(number);
            }
        }
        // M — число найденных ожидаемых лотов без повторов: два заголовка «ЛОТ №1» — один лот
        int m = seen.size();
        int n = expected.size();
        if (missing.isEmpty() && extra.isEmpty()) {
            row.put("значение", "извлечено " + n + " из " + n + " — полно");
            row.put("источник", "лоты: " + String.join(", ", found));
            return;
        }
        row.put("значение", "извлечено " + m + " из " + n);
        String missingPart = missing.isEmpty() ? "" : "не извлечены лоты: " + String.join(", ", missing);
        String extraPart = extra.isEmpty() ? "" : "лишние секции: " + String.join(", ", extra);
        row.put("источник", Stream.of(missingPart, extraPart).filter(s -> !s.isEmpty()).collect(Collectors.joining("; ")));
    }

    /**
     * Пояснение к «ожидаемое число лотов неизвестно»: донор не задан, не найден или пуст.
     *
     * @param donor        метка узла-донора
     * @param donorMissing донор не задан или не найден в графе
     * @param found        номера найденных секций
     * @return текст для поля «источник»
     */
    private static String unknownExpectedReason(String donor, boolean donorMissing, List<String> found) {
        String reason;
        if (donor.isEmpty()) {
            reason = "не задан узел-донор («ожидаемо_из_узла»)";
        } else if (donorMissing) {
            reason = "узел-донор «" + donor + "» не найден";
        } else {
            reason = "выход узла-донора «" + donor + "» пуст";
        }
        return reason + "; найдено секций: " + found.size()
                + (found.isEmpty() ? "" : " (" + String.join(", ", found) + ")");
    }

    /** Id базы: явный «база» или у узла графа с меткой «база_из_узла». */
    private java.util.UUID normKbId(Map<String, Object> op) {
        String explicit = String.valueOf(op.getOrDefault("база", "")).strip();
        if (!explicit.isEmpty()) {
            return java.util.UUID.fromString(explicit);
        }
        String label = String.valueOf(op.getOrDefault("база_из_узла", "")).strip();
        for (ScenarioRunNode n : node.getGraph().getNodeMap().values()) {
            if (label.equals(n.getLabel()) && n.getKnowledgeBaseId() != null) {
                return n.getKnowledgeBaseId();
            }
        }
        return null;
    }

    /** «реквизит: «текст» [документ] | …» по первым найденным нормам. */
    private static String normText(NormIndex index, String requisites, int maxChars, int maxHits) {
        List<String> parts = new ArrayList<>();
        for (NormIndex.Hit hit : index.resolve(requisites)) {
            String body = hit.text().replaceAll("\\s+", " ").strip();
            if (body.length() > maxChars) {
                body = body.substring(0, maxChars) + "…";
            }
            parts.add(hit.requisite() + ": «" + body + "» [" + hit.document() + "]");
            if (parts.size() >= maxHits) {
                break;
            }
        }
        return String.join(" | ", parts);
    }

    /**
     * Документы узла (имя файла и текст) для кодовых операций Формы 3.
     *
     * @return документы в порядке карты документов графа
     */
    private List<Form3Ops.Source> sources() {
        List<Form3Ops.Source> list = new ArrayList<>();
        for (var d : node.getGraph().getDocMap().values()) {
            list.add(new Form3Ops.Source(d.getFilename(), d.getText()));
        }
        return list;
    }

    /**
     * Выход узла-донора по метке из конфига операции (пусто, если метка не задана).
     *
     * @param op  конфиг операции
     * @param key ключ конфига с меткой узла
     * @return текст выхода донора
     */
    private String donorOutput(Map<String, Object> op, String key) {
        String label = String.valueOf(op.getOrDefault(key, "")).strip();
        if (label.isEmpty()) {
            return "";
        }
        // выход донора читает код (массивы, тексты разделов) — без усечения, в отличие от промптов
        return ExpressionResolver.resolveFull("{{output:" + label + "}}", node.getGraph().getNodeMap());
    }

    /**
     * Первый JSON-массив объектов во входе (десятичные запятые чинятся); пустой «[]»
     * другого узла перед массивом объектов не «съедает» строки — предпочитается непустой.
     *
     * @param opName имя операции для сообщения об ошибке
     * @param text   вход
     * @return разобранный массив
     */
    private List<?> parseObjectArray(String opName, String text) {
        // во входе могут быть тексты других узлов со скобками «[…]» — берётся первая «[», с которой
        // разбирается массив объектов; прежде бралась просто первая скобка входа
        LlmJson.Selection selection = LlmJson.firstObjectArray(text);
        LlmJson.Parsed block = selection.first();
        if (block != null) {
            return (List<?>) block.value();
        }
        throw new ScenarioException("Узел «Трансформация», операция «" + opName + "»: "
                + (selection.lastError() == null ? "во входе не найден JSON-массив объектов"
                : "не удалось разобрать массив: " + selection.lastError()));
    }

    private void locateCitation(Map<String, Object> m, List<DocIndex> docs, String field, int minLength) {
        // значение поля не меняется: префикс вердикта отбрасывается только для поиска цитаты
        String cite = VERDICT_PREFIX.matcher(String.valueOf(m.getOrDefault(field, ""))).replaceFirst("");
        String low = cite.strip().toLowerCase();
        if (low.startsWith("нет ") || low.startsWith("отсутств")
                || low.startsWith("не устано") || low.startsWith("не указан")) {
            m.put("достоверность", "н/п (об отсутствии)");
            m.put("документ", "—");
            return;
        }
        String fragmentDoc = locateFragments(cite, docs);
        if (fragmentDoc != null) {
            m.put("достоверность", "точно (по фрагментам)");
            m.put("документ", fragmentDoc);
            return;
        }
        String c = normForSearch(cite);
        if (c.length() < minLength) {
            m.put("достоверность", "цитата слишком коротка");
            m.put("документ", "—");
            return;
        }
        String[] cw = c.split(" ");
        String bestDoc = "—";
        double bestCov = 0;
        for (DocIndex d : docs) {
            if (d.norm.contains(c)) {
                m.put("достоверность", "точно");
                m.put("документ", d.name);
                return;
            }
            double cov = d.coverage(cw);
            if (cov > bestCov) {
                bestCov = cov;
                bestDoc = d.name;
            }
        }
        m.put("достоверность", bestCov >= 0.8 ? "нечётко" : "НЕ НАЙДЕНА");
        m.put("документ", bestCov >= 0.8 ? bestDoc : "—");
    }

    /**
     * Составная цитата с многоточиями («обеспечения … 1% … 2500000,00» — так
     * формируют цитаты кодовые проверки процентов и дат): подтверждается,
     * если каждый фрагмент дословно есть в одном документе и фрагменты идут
     * по порядку.
     *
     * @param cite цитата
     * @param docs индексы документов
     * @return имя документа или {@code null}, если цитата не составная или не найдена
     */
    private static String locateFragments(String cite, List<DocIndex> docs) {
        if (!cite.contains("…") && !cite.contains("...")) {
            return null;
        }
        // ядро цитаты — внутри первой пары «…»; пояснение после кавычек («, но 1% от базы = …») не сверяется
        Matcher quoted = QUOTED_CORE.matcher(cite);
        String core = quoted.find() ? quoted.group(1) : cite;
        List<String> fragments = new ArrayList<>();
        for (String part : core.split("…|\\.\\.\\.")) {
            String norm = normForSearch(part);
            if (norm.length() >= 2) {
                fragments.add(norm);
            }
        }
        if (fragments.isEmpty()) {
            return null;
        }
        for (DocIndex d : docs) {
            int pos = 0;
            for (String fragment : fragments) {
                pos = d.norm.indexOf(fragment, pos);
                if (pos < 0) {
                    break;
                }
                pos += fragment.length();
            }
            if (pos >= 0) {
                return d.name;
            }
        }
        return null;
    }

    private static String normForSearch(String s) {
        if (s == null) {
            return "";
        }
        // «289523339,14руб.» и «289523339,14 руб.» должны совпадать: граница цифра/буква — пробел
        String spaced = DIGIT_LETTER.matcher(s.toLowerCase().replace('ё', 'е')).replaceAll(" ");
        return spaced.replaceAll("[^0-9a-zа-я]+", " ").strip();
    }

    /** Пословный индекс документа для быстрого поиска цитат вокруг якорного слова. */
    private static final class DocIndex {
        private final String name;
        private final String norm;
        private final String[] words;
        private final Map<String, List<Integer>> positions = new HashMap<>();

        DocIndex(String name, String norm) {
            this.name = name;
            this.norm = norm;
            this.words = norm.isEmpty() ? new String[0] : norm.split(" ");
            for (int i = 0; i < words.length; i++) {
                positions.computeIfAbsent(words[i], k -> new ArrayList<>()).add(i);
            }
        }

        /** Доля слов цитаты, идущих по порядку в окне вокруг самого длинного слова. */
        double coverage(String[] cw) {
            String anchor = "";
            for (String w : cw) {
                if (w.length() > anchor.length()) {
                    anchor = w;
                }
            }
            List<Integer> anchors = positions.get(anchor);
            if (anchors == null) {
                return 0;
            }
            int win = Math.max(cw.length * 2, cw.length + 6);
            double best = 0;
            int tried = 0;
            for (int pos : anchors) {
                if (tried++ > 200 || best >= 0.99) {
                    break;
                }
                int start = Math.max(0, pos - cw.length);
                int stop = Math.min(words.length, start + win);
                best = Math.max(best, orderedMatches(cw, start, stop) / (double) cw.length);
            }
            return best;
        }

        private int orderedMatches(String[] cw, int from, int to) {
            int width = to - from;
            int[] prev = new int[width + 1];
            int[] cur = new int[width + 1];
            for (String s : cw) {
                for (int j = 1; j <= width; j++) {
                    cur[j] = s.equals(words[from + j - 1])
                            ? prev[j - 1] + 1
                            : Math.max(prev[j], cur[j - 1]);
                }
                int[] t = prev;
                prev = cur;
                cur = t;
                java.util.Arrays.fill(cur, 0);
            }
            return prev[width];
        }
    }

    /**
     * Собирает по всем документам прогона упоминания сумм рядом с меткой
     * (по умолчанию НМЦ/НМЦД) и возвращает сводку для судьи: каждое значение и
     * документы, где оно встречено. Судья сам решает, какие значения обязаны
     * совпадать (итог в разных разделах), а какие различаются законно (лоты).
     * Параметры: «метка» (regex, по умолчанию «НМЦД?»), «окно» (максимум
     * символов между меткой и числом, по умолчанию 80).
     */
    private String compareAmounts(Map<String, Object> op) {
        String label = String.valueOf(op.getOrDefault("метка", "НМЦД?"));
        int window = intParam(op, "окно", 80, "сверить_суммы");
        Pattern p = SafeRegex.compile("(" + label + ")[^0-9]{0," + window + "}?"
                        + "(\\d[\\d\\s\\u00A0]{3,17}(?:[.,]\\d{1,2})?)(?![\\d])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "метка");
        Map<String, Set<String>> byValue = new LinkedHashMap<>();
        for (var d : node.getGraph().getDocMap().values()) {
            Matcher m = SafeRegex.matcher(p, d.getText());
            while (m.find()) {
                String raw = m.group(2).replace(" ", "").replace("\u00A0", "")
                        .replace(",", ".");
                double value;
                try {
                    value = Double.parseDouble(raw);
                } catch (NumberFormatException e) {
                    value = Double.NaN;
                }
                if (Double.isNaN(value) || value < 10_000) {
                    // проценты, номера пунктов и прочий шум рядом с меткой
                    continue;
                }
                byValue.computeIfAbsent(String.format(Locale.ROOT, "%.2f", value), k -> new LinkedHashSet<>())
                        .add(d.getFilename());
            }
        }
        StringBuilder sb = new StringBuilder("СВЕРКА СУММ ПО МЕТКЕ «" + label
                + "» ПО ВСЕМ ДОКУМЕНТАМ КОМПЛЕКТА:\n");
        if (byValue.isEmpty()) {
            return sb.append("упоминаний сумм рядом с меткой не найдено").toString();
        }
        for (var e : byValue.entrySet()) {
            sb.append("- ").append(e.getKey()).append(" руб.: ")
                    .append(String.join("; ", e.getValue())).append('\n');
        }
        sb.append("Различных значений: ").append(byValue.size());
        if (byValue.size() > 1) {
            sb.append(". Если среди значений есть суммы, обязанные совпадать "
                    + "(итоговая НМЦ в разных разделах одного документа), "
                    + "это противоречие комплекта.");
        }
        return sb.toString();
    }

    /**
     * Извлекает regex-ом значение из документов прогона, отфильтрованных по
     * ИМЕНИ файла: сначала пробуются документы, чьё имя матчится параметром
     * «имя» (regex, без учёта регистра), затем — при отсутствии совпадений и
     * «строго» != true — все остальные. Кандидаты перебираются в стабильном
     * порядке — по имени файла; при нескольких подходящих документах берётся
     * первый по имени, а в лог уходит предупреждение (выбор воспроизводим
     * между прогонами, но автору сценария стоит сузить «имя»).
     * Незаменимо, когда порядок документов недетерминирован, а значение нужно
     * брать из конкретного типа документа (ПЗ, извещение).
     * Параметры: «имя», «шаблон», «группа» (по умолчанию 1), «строго».
     */
    private String extractFromDocs(Map<String, Object> op) {
        Pattern nameP = SafeRegex.compile(String.valueOf(op.getOrDefault("имя", ".")),
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "имя");
        Pattern p = SafeRegex.compile(String.valueOf(op.get("шаблон")), Pattern.MULTILINE, "шаблон");
        int group = intParam(op, "группа", 1, "извлечь_из_документов");
        boolean strict = Boolean.parseBoolean(String.valueOf(op.getOrDefault("строго", "false")));
        boolean all = Boolean.parseBoolean(String.valueOf(op.getOrDefault("все", "false")));
        String sep = String.valueOf(op.getOrDefault("разделитель", "; "));
        List<ScenarioRunDoc> docs = node.getGraph().getDocMap().values().stream()
                .sorted(Comparator.comparing(d -> String.valueOf(d.getFilename())))
                .toList();
        for (boolean preferred : new boolean[]{true, false}) {
            List<ScenarioRunDoc> matched = new ArrayList<>();
            for (var d : docs) {
                if (SafeRegex.find(nameP, d.getFilename()) == preferred && SafeRegex.find(p, d.getText())) {
                    matched.add(d);
                }
            }
            if (!matched.isEmpty()) {
                return extractedValue(op, matched, p, group, all, sep);
            }
            if (strict) {
                break;
            }
        }
        return "не найдено";
    }

    /**
     * Значение из первого (по имени файла) подходящего документа; несколько
     * совпадений — предупреждение в лог с перечнем файлов.
     *
     * @param op      конфигурация операции (для текста предупреждения)
     * @param matched документы, в которых шаблон найден, по имени файла
     * @param p       шаблон значения
     * @param group   группа-значение
     * @param all     собирать все совпадения документа
     * @param sep     разделитель совпадений
     * @return значение с пометкой источника
     */
    private String extractedValue(Map<String, Object> op, List<ScenarioRunDoc> matched, Pattern p,
                                  int group, boolean all, String sep) {
        if (matched.size() > 1) {
            log.warn("[{}] Свод: операция «извлечь_из_документов» (шаблон «{}») — совпадения в {} документах {}; "
                            + "взят первый по имени файла «{}», сузьте параметр «имя»",
                    currentUser(), op.get("шаблон"), matched.size(),
                    matched.stream().map(ScenarioRunDoc::getFilename).toList(), matched.get(0).getFilename());
        }
        ScenarioRunDoc d = matched.get(0);
        Matcher m = SafeRegex.matcher(p, d.getText());
        if (!m.find()) {
            return "не найдено";
        }
        String value = all ? allMatches(m, group, sep)
                : m.group(Math.min(group, m.groupCount())).strip();
        return value + " [источник: " + d.getFilename() + "]";
    }

    /**
     * Все уникальные совпадения шаблона в документе (первое уже найдено
     * вызывающим кодом) через разделитель — например, НМЦД по каждому лоту
     * и итоговая сумма из одной пояснительной записки.
     *
     * @param m     матчер после успешного {@code find()}
     * @param group группа-значение
     * @param sep   разделитель
     * @return значения по порядку появления без повторов
     */
    private static String allMatches(Matcher m, int group, String sep) {
        Set<String> values = new LinkedHashSet<>();
        do {
            values.add(m.group(Math.min(group, m.groupCount())).strip());
        } while (m.find());
        return String.join(sep, values);
    }

    /**
     * Кодовая проверка процентных значений: находит в документах конструкции
     * «X% … СУММА» (в окне и с контекстным словом: обеспечение, аванс, скидка
     * и т.п.), берёт базу — максимальную сумму рядом с меткой НМЦ («база_метка»)
     * — и пересчитывает. Расхождение более чем в «допуск» раз (по умолчанию
     * 0.3, т.е. 30%) попадает в отчёт: LLM такие расхождения не считает.
     */
    private String checkPercentages(Map<String, Object> op) {
        String baseLabel = String.valueOf(op.getOrDefault("база_метка",
                "НМЦД?|начальн[а-я]+ (?:максимальн[а-я]+ )?(?:цен|стоимост)[а-я]*"));
        double tolerance = op.get("допуск") == null ? 0.3
                : Double.parseDouble(String.valueOf(op.get("допуск")));
        double base = maxAmountNearLabel(baseLabel);
        if (base <= 0) {
            return "ПРОВЕРКА ПРОЦЕНТНЫХ ЗНАЧЕНИЙ: базовая сумма (НМЦ) в документах не найдена, "
                    + "проверка пропущена";
        }
        Pattern keyword = Pattern.compile(
                "(?:обеспечени|аванс|задат|неустойк|скидк|штраф)[а-я]*",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.CANON_EQ);
        Pattern clause = Pattern.compile(
                "(\\d{1,2}(?:[.,]\\d{1,2})?)\\s*%[^0-9%]{0,120}(\\d[\\d\\s\\u00A0]{5,17}[.,]\\d{2})",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.CANON_EQ);
        List<String[]> mismatches = collectPercentMismatches(keyword, clause, base, tolerance);
        if ("json_находки".equals(String.valueOf(op.getOrDefault("формат", "текст")))) {
            return findingsJson("расхождение процента и суммы", mismatches);
        }
        StringBuilder sb = new StringBuilder("ПРОВЕРКА ПРОЦЕНТНЫХ ЗНАЧЕНИЙ (база "
                + String.format(Locale.ROOT, "%.2f", base) + " руб. по метке НМЦ):\n");
        if (mismatches.isEmpty()) {
            sb.append("расхождений между указанными процентами и суммами не найдено");
        }
        for (String[] mismatch : mismatches) {
            sb.append("- ").append(mismatch[0]).append(": ").append(mismatch[1]).append('\n');
        }
        return sb.toString();
    }

    /** @return несоответствия «процент ↔ сумма»: пары [имя файла, описание], без повторов */
    private List<String[]> collectPercentMismatches(Pattern keyword, Pattern clause,
                                                       double base, double tolerance) {
        List<String[]> mismatches = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (var doc : node.getGraph().getDocMap().values()) {
            collectPercentMismatchesForDoc(keyword, clause, base, tolerance, seen, mismatches, doc);
        }
        return mismatches;
    }

    /** Перебирает фразы-ключи документа и собирает найденные расхождения. */
    private void collectPercentMismatchesForDoc(Pattern keyword, Pattern clause, double base,
                                                double tolerance, Set<String> seen,
                                                List<String[]> mismatches, ScenarioRunDoc doc) {
        String text = doc.getText();
        // каждая фраза-ключ ищется отдельно; после неё — «% … сумма» в ограниченном окне
        Matcher k = keyword.matcher(text);
        int from = 0;
        while (k.find(from)) {
            String[] mismatch = percentMismatchFor(doc, k, text, clause, base, tolerance, seen);
            if (mismatch.length != 0) {
                mismatches.add(mismatch);
            }
            from = k.end();
        }
    }

    /** Расхождение по одной фразе-ключу документа или null, если его нет. */
    private String[] percentMismatchFor(ScenarioRunDoc doc, Matcher k, String text, Pattern clause,
                                        double base, double tolerance, Set<String> seen) {
        String keywordText = k.group();
        String suffix = text.substring(k.end());
        Matcher m = clause.matcher(suffix);
        boolean hasClause = m.find();
        String gap = hasClause ? suffix.substring(0, m.start(1)) : "";
        // между ключом и процентом допустимо не более 120 непроцентных символов
        boolean gapOk = hasClause && gap.length() <= 120 && gap.indexOf('%') < 0;
        if (!gapOk) {
            return new String[0];
        }
        double percent = Double.parseDouble(m.group(1).replace(",", "."));
        double amount = parseAmount(m.group(2));
        // эквивалент снятого в паттерне негативного просмотра (?![\d]): сумма
        // не должна обрываться внутри длинного десятичного числа
        int afterAmount = k.end() + m.end(2);
        boolean truncatedByDigit = afterAmount < text.length()
                && Character.isDigit(text.charAt(afterAmount));
        if (truncatedByDigit || percent <= 0 || amount <= 0
                || !seen.add(doc.getFilename() + "|" + percent + "|" + amount)) {
            return new String[0];
        }
        double expected = base * percent / 100;
        if (Math.abs(amount - expected) / expected <= tolerance) {
            return new String[0];
        }
        return new String[]{doc.getFilename(),
                "«" + keywordText + " … " + m.group(1) + "% … " + m.group(2).strip()
                        + "», но " + m.group(1) + "% от базы = "
                        + String.format(Locale.ROOT, "%.2f", expected)
                        + " руб. — расхождение, требует проверки"};
    }

    /** Сериализует кодовые находки в JSON-массив формата свода находок. */
    private String findingsJson(String type, List<String[]> mismatches) {
        List<Map<String, Object>> findings = new ArrayList<>();
        for (int i = 0; i < mismatches.size(); i++) {
            findings.add(Map.of("номер", i + 1, "тип", type,
                    "цитата", mismatches.get(i)[1], "место", mismatches.get(i)[0]));
        }
        try {
            return MAPPER.writeValueAsString(Map.of("находки", findings));
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать находки: "
                    + e.getMessage());
        }
    }

    /** @return максимальная сумма рядом с меткой (regex) по всем документам, или -1 */
    private double maxAmountNearLabel(String label) {
        Pattern p = SafeRegex.compile("(" + label + ")[^0-9]{0,80}?"
                        + "(\\d[\\d\\s\\u00A0]{5,17}(?:[.,]\\d{2}))(?![\\d])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "база_метка");
        double best = -1;
        for (var d : node.getGraph().getDocMap().values()) {
            Matcher m = SafeRegex.matcher(p, d.getText());
            while (m.find()) {
                double v = parseAmount(m.group(2));
                if (v > best) {
                    best = v;
                }
            }
        }
        return best;
    }

    /** @return сумма из текстовой записи с пробелами-разделителями, или -1 */
    private double parseAmount(String raw) {
        try {
            return Double.parseDouble(raw.replace(" ", "").replace("\u00A0", "")
                    .replace(",", "."));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Кодовая сверка дат: договор, заключённый ПОЗЖЕ начала периода оказания
     * услуг (услуги задним числом), — типовой риск, который LLM не вычисляет.
     * Ищет «договор … от D1» и в окне после — «(период|срок|услуг|действ)… с D2»;
     * если D1 позже D2 более чем на «минимум_дней» (по умолчанию 15) — в отчёт.
     */
    private String compareDates(Map<String, Object> op) {
        int minDays = op.get("минимум_дней") == null ? 15
                : Integer.parseInt(String.valueOf(op.get("минимум_дней")));
        // прямой порядок фраз: «договор … от D1 … период/услуги … с D2»
        Pattern direct = Pattern.compile("договор[а-я]*[^\\n]{0,80}?от\\s+(\\d{2}\\.\\d{2}\\.\\d{4})"
                        + "[\\s\\S]{0,250}?(?:период|срок|услуг|действ)[а-я]*"
                        + "[^\\n]{0,60}?с\\s+(\\d{2}\\.\\d{2}\\.\\d{4})",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.CANON_EQ);
        // обратный порядок: «период/услуги … с D2 … договор … от D1»
        Pattern reversed = Pattern.compile("(?:период[а-я]*|срок[а-я]*|услуг[а-я]*)[^\\n]{0,60}?"
                        + "с\\s+(\\d{2}\\.\\d{2}\\.\\d{4})[\\s\\S]{0,250}?договор[а-я]*"
                        + "[^\\n]{0,80}?от\\s+(\\d{2}\\.\\d{2}\\.\\d{4})",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        List<String[]> mismatches = collectDateMismatches(direct, 1, 2, minDays);
        mismatches.addAll(collectDateMismatches(reversed, 2, 1, minDays));
        boolean anyContractDate = node.getGraph().getDocMap().values().stream()
                .anyMatch(d -> d.getText() != null && CONTRACT_DATE.matcher(d.getText()).find());
        if (!anyContractDate) {
            // «не найдено» ниже означало бы «нарушений нет», хотя сверять было нечего
            warn("сверить_даты", "дат заключения договоров в документах не найдено — сверка не выполнена");
        }
        if ("json_находки".equals(String.valueOf(op.getOrDefault("формат", "текст")))) {
            return findingsJson("услуги до оформления договора", mismatches);
        }
        StringBuilder sb = new StringBuilder("СВЕРКА ДАТ ДОГОВОРОВ И ПЕРИОДОВ УСЛУГ:\n");
        if (mismatches.isEmpty()) {
            sb.append("договоров, заключённых позже начала периода услуг, не найдено");
        }
        for (String[] mismatch : mismatches) {
            sb.append("- ").append(mismatch[0]).append(": ").append(mismatch[1]).append('\n');
        }
        return sb.toString();
    }

    /**
     * Ищет пары «дата договора / начало периода услуг», где договор заключён
     * позже начала периода.
     *
     * @param signedGroup группа с датой заключения договора
     * @param startGroup  группа с датой начала периода услуг
     * @return пары [имя файла, описание], без повторов
     */
    private List<String[]> collectDateMismatches(Pattern p, int signedGroup, int startGroup,
                                                 int minDays) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        List<String[]> mismatches = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (var d : node.getGraph().getDocMap().values()) {
            Matcher m = p.matcher(d.getText());
            while (m.find()) {
                try {
                    LocalDate signed = LocalDate.parse(m.group(signedGroup), fmt);
                    LocalDate start = LocalDate.parse(m.group(startGroup), fmt);
                    long days = ChronoUnit.DAYS.between(start, signed);
                    if (days >= minDays
                            && seen.add(d.getFilename() + "|" + signed + "|" + start)) {
                        mismatches.add(new String[]{d.getFilename(),
                                "договор от " + m.group(signedGroup) + " покрывает период с "
                                        + m.group(startGroup) + " — услуги начинаются на " + days
                                        + " дн. раньше заключения договора "
                                        + "(оказание услуг до оформления)"});
                    }
                } catch (DateTimeParseException e) {
                    // нечисловая дата в тексте — пропускаем совпадение
                }
            }
        }
        return mismatches;
    }

    /**
     * Значение по пути из JSON во входе. Отсутствие поля (или JSON вовсе) — ошибка узла:
     * пометка «[выражение json: …]» раньше уходила дальше как данные. С опцией
     * {@code "пусто_если_нет": "true"} вместо ошибки — пустой результат и предупреждение.
     */
    private String jsonField(Map<String, Object> op, String text) {
        String path = String.valueOf(op.get("путь"));
        // переиспользуем механику выражений: {{json:...}} по текущему тексту
        String value = ExpressionResolver.extractJsonPathFromText(text, path);
        if (!value.startsWith("[выражение json:")) {
            return value;
        }
        if (Boolean.parseBoolean(String.valueOf(op.getOrDefault("пусто_если_нет", "false")))) {
            warn("json_поле", "поле «" + path + "» не найдено — результат пуст");
            return "";
        }
        throw new ScenarioException("Узел «Трансформация», операция «json_поле»: " + value);
    }

    private String substringOp(Map<String, Object> op, String text) {
        int from = op.get("от") == null ? 0 : Integer.parseInt(String.valueOf(op.get("от")));
        int to = op.get("до") == null ? text.length() : Integer.parseInt(String.valueOf(op.get("до")));
        from = Math.max(0, Math.min(from, text.length()));
        to = Math.max(from, Math.min(to, text.length()));
        return text.substring(from, to);
    }

    private String headTail(Map<String, Object> op, String text, boolean head) {
        String opName = head ? "первые_строки" : "последние_строки";
        int n = intParam(op, "n", 10, opName);
        if (n < 0) {
            throw new ScenarioException("Узел «Трансформация», операция «" + opName
                    + "»: параметр «n» должен быть неотрицательным, получено " + n);
        }
        String[] lines = text.split("\n", -1);
        if (lines.length <= n) {
            return text;
        }
        String[] slice = head
                ? Arrays.copyOfRange(lines, 0, n)
                : Arrays.copyOfRange(lines, lines.length - n, lines.length);
        return String.join("\n", slice);
    }

    /**
     * Удаляет из JSON-массива объекты, у которых значение поля {@code "поле"}
     * совпадает с regex {@code "шаблон"} (поиск подстроки, без учёта регистра).
     * Применение: после «проверить_цитаты» отсечь находки-констатации
     * отсутствия (достоверность «н/п (об отсутствии)») — модель плодит строки
     * «отсутствует информация о …» с цитатой «нет информации», судья их не
     * удерживает, а по правилам сценария такие строки в таблицу не входят.
     *
     * @param op   конфиг операции
     * @param text вход с JSON-массивом объектов
     * @return сериализованный массив без удалённых объектов
     */
    private String removeObjects(Map<String, Object> op, String text) {
        String field = String.valueOf(op.getOrDefault("поле", "цитата"));
        String regex = String.valueOf(op.getOrDefault("шаблон", ""));
        if (regex.isBlank()) {
            return text;
        }
        Pattern pattern = SafeRegex.compile(regex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "шаблон");
        List<?> arr = parseObjectArray("удалить_объекты", text);
        String andField = String.valueOf(op.getOrDefault("и_поле", "")).strip();
        String andRegex = String.valueOf(op.getOrDefault("и_шаблон", "")).strip();
        Pattern andPattern = andField.isEmpty() || andRegex.isEmpty() ? null
                : SafeRegex.compile(andRegex, Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "и_шаблон");
        List<Object> out = new ArrayList<>();
        int removed = 0;
        for (Object o : arr) {
            boolean drop = fieldMatches(o, field, pattern)
                    && (andPattern == null || fieldMatches(o, andField, andPattern));
            if (drop) {
                removed++;
            } else {
                out.add(o);
            }
        }
        log.info("[{}] Свод: операция «удалить_объекты» по полю «{}» удалила {} объектов", CurrentUserHolder.getCurrentUser(), field, removed);
        return serializeMerged(out);
    }

    /**
     * Условно исключает находки заданных типов по тексту узла-донора
     * (конфиг {@code "исключить_типы": {"по_узлу": "<метка>",
     * "если_не_содержит": "<regex>", "типы": ["…"]}}): если выход узла с этой
     * меткой НЕ содержит совпадения с regex, находки перечисленных типов
     * отбрасываются. Пример: находки «обоснование выбора единственного
     * поставщика» уместны только при способе закупки у ЕП — при конкурентном
     * способе (запрос предложений, конкурс) их не должно быть, что бы модель
     * ни нашла в исторических документах комплекта.
     *
     * @param op     конфиг операции
     * @param merged находки после лимитов
     * @return находки без исключённых типов
     */
    @SuppressWarnings("unchecked")
    private List<Object> excludeTypesByDonor(Map<String, Object> op, List<Object> merged) {
        if (!(op.get("исключить_типы") instanceof Map<?, ?> cfgRaw)) {
            return merged;
        }
        Map<String, Object> cfg = (Map<String, Object>) cfgRaw;
        String donorLabel = String.valueOf(cfg.getOrDefault("по_узлу", "")).strip();
        String condition = String.valueOf(cfg.getOrDefault("если_не_содержит", "")).strip();
        if (donorLabel.isEmpty() || condition.isEmpty()
                || !(cfg.get("типы") instanceof List<?> typesRaw) || typesRaw.isEmpty()) {
            return merged;
        }
        String donorText = ExpressionResolver.resolveFull("{{output:" + donorLabel + "}}",
                node.getGraph().getNodeMap());
        if (SafeRegex.find(SafeRegex.compile(condition, Pattern.CASE_INSENSITIVE, "если_не_содержит"), donorText)) {
            return merged;
        }
        Set<String> excluded = new LinkedHashSet<>();
        for (Object type : typesRaw) {
            excluded.add(String.valueOf(type).strip().toLowerCase());
        }
        List<Object> result = new ArrayList<>();
        int dropped = 0;
        for (Object o : merged) {
            String type = String.valueOf(((Map<String, Object>) o).get("тип")).strip().toLowerCase();
            if (excluded.contains(type)) {
                dropped++;
            } else {
                result.add(o);
            }
        }
        if (dropped > 0) {
            log.info("[{}] Свод: по узлу «{}» исключено находок {} (типы {})", CurrentUserHolder.getCurrentUser(), donorLabel, dropped, excluded);
        }
        return result;
    }

}
