package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorTransformNode;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Проверка regex-параметров операций узлов «Трансформация» до создания прогона: каждый шаблон
 * компилируется и прогоняется на синтетическом тексте в {@value #PROBE_CHARS} символов с
 * бюджетом {@value #PROBE_STEPS} обращений движка regex к символам текста. Катастрофический или
 * некорректный шаблон — отказ запуска с понятным текстом, а не поток пула прогонов, занятый навсегда.
 * Отклоняются шаблоны длиннее предела, некорректные, переполняющие стек на пробе и те, которым на пробе нужно
 * больше {@value #PROBE_STEPS} обращений к символам — независимо от класса сложности: и экспоненциальный
 * {@code (a+a+)+b}, и кубический {@code .*.*.*=.*}. Шаблон, уложившийся в бюджет (например {@code (a+)+$}),
 * на длинном реальном тексте может работать дольше — его останавливает дедлайн
 * {@link ru.sber.cs.ai.gigame.utils.SafeRegex} в прогоне.
 * <p>
 * Бюджет считается в шагах, а не по часам: вердикт не зависит от загрузки CPU пода и режима JIT.
 * Дедлайн пробы в миллисекундах на урезанном CPU отклонял обычный шаблон «оставить_строки» Формы 3
 * v6.4/v6.5 через раз («Сценарий завершился с ошибкой» без единого узла, письмо Егоровой 16.09).
 * Вердикт детерминирован и кэшируется по тексту шаблона.
 */
@SuppressWarnings({ "java:S1192", "java:S3626" })
public final class ScenarioRegexValidator {

    /** Длина синтетического текста пробы. */
    static final int PROBE_CHARS = 5000;

    /**
     * Бюджет пробы одного шаблона — обращений к символам тестовой строки. Замер на пробе: шаблоны корп-сценариев —
     * до 7 млн («оставить_строки» Формы 3 без якоря), квадратичные {@code (a+)+$}, {@code (a*)*b} — около 12 млн,
     * экспоненциальный {@code (a+a+)+b} — больше 1 млрд. Исчерпание бюджета — от долей секунды до нескольких секунд
     * на загруженном CPU, один раз на шаблон: вердикт кэшируется.
     */
    static final long PROBE_STEPS = 50_000_000L;

    /**
     * Длина повтора одной буквы в строке пробы: на нём экспоненциальные для движка Java шаблоны
     * ({@code (a+a+)+b}) не укладываются в бюджет шагов, а {@code (a|a?)+$} переполняет стек.
     * {@code (a*)*b} и {@code (a+)+$} Java выполняет за квадратичное время — такие ловит дедлайн в прогоне.
     */
    private static final int PROBE_RUN = 90;

    /** Длина единственной длинной строки пробы (повтор одной буквы). */
    private static final int PROBE_LONG_RUN = 2000;

    /** Начало текста ошибки; дальше — проблемы через «; ». */
    static final String PREFIX = "Сценарий содержит небезопасные регулярные выражения: ";

    /** Окончание текста ошибки. */
    static final String SUFFIX = " — упростите шаблоны";
    private static final int SHORT_PATTERN = 80;

    private static final int FLAGS = Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    /** Предел числа вердиктов в кэше: при заполнении кэш очищается. */
    private static final int CACHE_LIMIT = 256;

    /** Вердикт «шаблон в порядке» в кэше ({@link ConcurrentHashMap} не хранит null). */
    private static final String PASSED = "";

    /** Regex-параметры операций (вложенные — через точку). */
    private static final Map<String, List<String>> REGEX_FIELDS = Map.ofEntries(
            Map.entry("извлечь_regex", List.of("шаблон")),
            Map.entry("заменить", List.of("найти")),
            Map.entry("оставить_строки", List.of("шаблон")),
            Map.entry("удалить_строки", List.of("шаблон")),
            Map.entry("слить_json_массивы", List.of("дедуп_регекс", "исключить_типы.если_не_содержит")),
            Map.entry("проверить_цитаты", List.of("документы")),
            Map.entry("удалить_объекты", List.of("шаблон", "и_шаблон")),
            Map.entry("установить_поле", List.of("шаблон", "кроме_значений")),
            Map.entry("нумеровать", List.of("шаблон")),
            Map.entry("секция_из_заголовков", List.of("шаблон_заголовка")),
            Map.entry("последовательность", List.of("шаблон")),
            Map.entry("прикрепить_по_номеру", List.of("шаблон")),
            Map.entry("дополнить_строки", List.of("секция_шаблон")),
            Map.entry("проверить_секции", List.of("шаблон_секции")),
            Map.entry("рубли_из_процента", List.of("секция_шаблон", "нмцд_шаблон")),
            Map.entry("сверить_характеристики",
                    List.of("классы_требований", "класс_договора", "колонка_наименования", "колонка_характеристик",
                            "колонка_параметра", "колонка_значения")),
            Map.entry("сверить_подписантов", List.of("класс_договора")),
            Map.entry("строки_формы3", List.of("заказчики_в_рейтинге")),
            Map.entry("сверить_суммы", List.of("метка")),
            Map.entry("проверить_проценты", List.of("база_метка")),
            Map.entry("извлечь_из_документов", List.of("имя", "шаблон")));

    /** Синтетическая строка: буквы, цифры, пробелы, знаки, переводы строк и «!» в конце. */
    private static final String PROBE = buildProbe();

    /** Вердикты по тексту шаблона: {@link #PASSED} либо описание проблемы. */
    private static final Map<String, String> VERDICTS = new ConcurrentHashMap<>();

    private ScenarioRegexValidator() {
    }

    /**
     * Проблемы regex-параметров узлов «Трансформация» графа.
     *
     * @param graphData граф (null и узлы без данных пропускаются)
     * @param where     уточнение места (например, « под-сценария «X»») либо пустая строка
     * @return описания проблем в порядке узлов
     */
    public static List<String> problemsOf(GraphDataDto graphData, String where) {
        List<String> problems = new ArrayList<>();
        if (graphData == null || graphData.nodes() == null) {
            return problems;
        }
        for (NodeDto node : graphData.nodes()) {
            if (node == null || node.data() == null || !ScenarioNodeType.TRANSFORM_NODE.toString().equals(node.type())) {
                continue;
            }
            for (JsonNode op : ScenarioExecutorTransformNode.operationsOf(node.data().rules())) {
                problems.addAll(operationProblems(op, label(node) + where));
            }
        }
        return problems;
    }

    /**
     * Бросает исключение, если проблемы есть.
     *
     * @param problems проблемы
     * @throws ScenarioException если список не пуст
     */
    public static void throwIfAny(List<String> problems) {
        if (!problems.isEmpty()) {
            throw new ScenarioException(PREFIX + String.join("; ", problems) + SUFFIX);
        }
    }

    /**
     * Проверяет один шаблон: длина, компиляция, проба на синтетической строке. Вердикт кэшируется.
     *
     * @param regex шаблон
     * @return описание проблемы либо null, если шаблон в порядке
     */
    static String check(String regex) {
        String cached = VERDICTS.get(regex);
        if (cached == null) {
            cached = verdict(regex);
            if (VERDICTS.size() >= CACHE_LIMIT) {
                VERDICTS.clear();
            }
            VERDICTS.put(regex, cached);
        }
        return cached.isEmpty() ? null : cached;
    }

    /**
     * Число обращений движка regex к символам пробы при поиске всех совпадений шаблона (флаги пробы).
     * Больше {@link #PROBE_STEPS} — бюджет исчерпан, поиск остановлен.
     *
     * @param pattern скомпилированный шаблон
     * @return шагов поиска, не больше {@code PROBE_STEPS + 1}
     * @throws StackOverflowError если рекурсия движка regex переполняет стек
     */
    static long probeSteps(Pattern pattern) {
        StepCountingText text = new StepCountingText(PROBE, PROBE_STEPS);
        try {
            Matcher m = pattern.matcher(text);
            while (m.find()) {
                // все совпадения: считаются шаги полного прохода
                continue;
            }
        } catch (StepBudgetExceeded e) {
            // бюджет исчерпан: счётчик уже больше PROBE_STEPS, поиск остановлен
        }
        return text.steps;
    }

    /**
     * Вердикт по шаблону без кэша.
     *
     * @param regex шаблон
     * @return {@link #PASSED} либо описание проблемы
     */
    private static String verdict(String regex) {
        if (regex.length() > SafeRegex.MAX_PATTERN_LENGTH) {
            return "длиннее " + SafeRegex.MAX_PATTERN_LENGTH + " символов (" + regex.length() + ")";
        }
        Pattern pattern;
        try {
            pattern = Pattern.compile(regex, FLAGS);
        } catch (PatternSyntaxException e) {
            return "некорректно: " + e.getDescription();
        }
        try {
            return probeSteps(pattern) > PROBE_STEPS
                    ? "слишком медленное (больше " + PROBE_STEPS / 1_000_000 + " млн шагов поиска на тестовой строке из "
                    + PROBE_CHARS + " символов)"
                    : PASSED;
        } catch (StackOverflowError e) {
            // например «(a|a?)+$» на длинном повторе: рекурсия движка regex переполняет стек
            return "переполняет стек на тестовой строке из " + PROBE_CHARS + " символов";
        }
    }

    private static List<String> operationProblems(JsonNode op, String where) {
        List<String> problems = new ArrayList<>();
        String name = op.path("оп").asText("");
        List<String> fields = REGEX_FIELDS.getOrDefault(name, List.of());
        boolean plainReplace = "заменить".equals(name) && !"true".equalsIgnoreCase(op.path("regex").asText("false"));
        for (String field : fields) {
            JsonNode value = valueAt(op, field);
            if (plainReplace || !value.isTextual() || value.asText().isBlank()) {
                continue;
            }
            String reason = check(value.asText());
            if (reason != null) {
                problems.add("«" + field + "» операции «" + name + "» в узле «" + where + "»: " + reason
                        + " — шаблон «" + shortPattern(value.asText()) + "»");
            }
        }
        return problems;
    }

    /** Шаблон для сообщения об отказе: длинный обрезается до 80 символов. */
    private static String shortPattern(String regex) {
        return regex.length() <= SHORT_PATTERN ? regex : regex.substring(0, SHORT_PATTERN) + "…";
    }

    private static JsonNode valueAt(JsonNode op, String path) {
        JsonNode current = op;
        for (String token : path.split("\\.")) {
            current = current.path(token);
        }
        return current;
    }

    private static String label(NodeDto node) {
        String label = node.data().label();
        return label == null || label.isBlank() ? node.id() : label;
    }

    /**
     * Синтетический текст: одна строка из {@value #PROBE_LONG_RUN} одинаковых букв и строки по ~200
     * символов, как у таблиц и документов — повтор одной буквы ({@value #PROBE_RUN}), повтор цифры,
     * слова и ячейки через «|»; каждый блок обрывается
     * символом, который «ломает» совпадение. На таком повторе экспоненциальные шаблоны
     * ({@code (a+a+)+b}) не укладываются в {@value #PROBE_STEPS} шагов, а обычные
     * шаблоны сценариев с просмотром вперёд и {@code .*} по строке (Форма 3, АЗК) проходят:
     * одна строка в 4000 символов делала их квадратично медленными и давала ложный отказ.
     */
    private static String buildProbe() {
        StringBuilder sb = new StringBuilder(PROBE_CHARS + 256);
        // одна длинная строка: на ней «(a+a+)+b» не укладывается в бюджет шагов (замер: больше 1 млрд), «(a|a?)+$» переполняет
        // стек, а квадратичные «(a+)+$», «(a*)*b» и шаблоны сценариев укладываются в 13 млн шагов
        sb.append("a".repeat(PROBE_LONG_RUN)).append("!\n");
        String line = "a".repeat(PROBE_RUN) + "! " + "1".repeat(40) + "! " + "x y ".repeat(10)
                + "| абвг abcd 1234 56,78 (x) [y] a-b {z} | Договор № 123 от 01.01.2025 |\n";
        while (sb.length() < PROBE_CHARS - 1) {
            sb.append(line);
        }
        sb.setLength(PROBE_CHARS - 1);
        return sb.append('!').toString();
    }

    /** Текст пробы, считающий обращения к символам: при превышении бюджета поиск останавливается. */
    private static final class StepCountingText implements CharSequence {

        private final String text;
        private final long budget;
        private long steps;

        StepCountingText(String text, long budget) {
            this.text = text;
            this.budget = budget;
        }

        @Override
        public int length() {
            return text.length();
        }

        @Override
        public char charAt(int index) {
            if (++steps > budget) {
                throw new StepBudgetExceeded();
            }
            return text.charAt(index);
        }

        @Override
        public CharSequence subSequence(int start, int end) {
            return text.subSequence(start, end);
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /** Бюджет шагов пробы исчерпан (без стека: бросается из горячего цикла движка regex). */
    private static final class StepBudgetExceeded extends RuntimeException {

        private static final long serialVersionUID = 1L;

        StepBudgetExceeded() {
            super(null, null, false, false);
        }
    }
}
