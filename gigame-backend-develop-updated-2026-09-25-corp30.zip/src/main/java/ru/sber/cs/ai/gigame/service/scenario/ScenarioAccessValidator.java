package ru.sber.cs.ai.gigame.service.scenario;

import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;

/**
 * Проверка доступа запускающего пользователя к ресурсам графа до создания прогона.
 * <p>
 * Узел с {@code knowledge_base_id} читает базу знаний по UUID (RAG, инструмент kb_article,
 * «норма_из_базы»), узел «Под-сценарий» выполняет сценарий по UUID — оба без проверки доступа
 * в движке. Чужая личная база или чужой личный сценарий, чей id попал в граф, читались бы
 * запускающим. Правило то же, что у самих баз и сценариев: доступны общие и свои
 * ({@code shared || userId == runner}). Под-сценарии обходятся на глубину движка
 * ({@link ScenarioEngine#MAX_SUB_DEPTH}); в недоступный под-сценарий обход не заходит.
 * Ненайденные базы и сценарии, некорректные id проверкой не считаются — о них сообщит движок.
 */
public final class ScenarioAccessValidator {

    /** Обёртка графа с указанием, где он находится (пусто — запускаемый сценарий). */
    private record Level(GraphDataDto graph, String where) {
    }

    private ScenarioAccessValidator() {
    }

    /**
     * Проверяет доступ пользователя к базам знаний и под-сценариям графа (и графов под-сценариев).
     *
     * @param graphData      граф запускаемого сценария (null и узлы без данных пропускаются)
     * @param scenarioId     id запускаемого сценария (null — неизвестен)
     * @param runnerUserId   запускающий пользователь (пусто — аноним)
     * @param scenarios      поиск сценария по id
     * @param knowledgeBases поиск базы знаний по id
     * @throws ScenarioException есть база знаний или под-сценарий, недоступные пользователю
     */
    @SuppressWarnings("java:S3776") // когнитивная сложность: многофакторная проверка доступа по уровням под-сценариев
    public static void validate(GraphDataDto graphData, UUID scenarioId, String runnerUserId,
                                Function<UUID, Optional<Scenario>> scenarios,
                                Function<UUID, Optional<KnowledgeBase>> knowledgeBases) {
        String runner = ScenarioRunAccess.normalizeUser(runnerUserId);
        List<String> problems = new ArrayList<>();
        Set<UUID> visitedScenarios = new HashSet<>();
        visitedScenarios.add(scenarioId);
        Set<UUID> checkedBases = new HashSet<>();
        List<Level> level = graphData == null ? List.of() : List.of(new Level(graphData, ""));
        if (!level.isEmpty()) {
            checkKnowledgeBases(level.get(0), runner, knowledgeBases, checkedBases, problems);
        }
        for (int depth = 0; depth < ScenarioEngine.MAX_SUB_DEPTH && !level.isEmpty(); depth++) {
            List<Level> next = new ArrayList<>();
            for (Level current : level) {
                checkSubScenarios(current, runner, next, visitedScenarios,
                        scenarios, knowledgeBases, checkedBases, problems);
            }
            level = next;
        }
        if (!problems.isEmpty()) {
            throw new ScenarioException(String.join("; ", problems));
        }
    }

    /** Проверяет под-сценарии одного уровня глубины и собирает их графы для следующего уровня. */
    @SuppressWarnings("java:S107") // 8 параметров: контекст проверки доступа, собираемый результат и lookup-функции
    private static void checkSubScenarios(Level current, String runner, List<Level> next,
                                          Set<UUID> visitedScenarios,
                                          Function<UUID, Optional<Scenario>> scenarios,
                                          Function<UUID, Optional<KnowledgeBase>> knowledgeBases,
                                          Set<UUID> checkedBases, List<String> problems) {
        for (UUID subId : subScenarioIds(current.graph())) {
            Optional<Scenario> sub = visitedScenarios.add(subId) ? scenarios.apply(subId) : Optional.empty();
            sub.ifPresent(scenario -> {
                if (!canAccess(scenario, runner)) {
                    problems.add("Под-сценарий «" + name(scenario, subId) + "» недоступен пользователю" + current.where());
                    return;
                }
                Level subLevel = new Level(GraphDataMapper.toDto(scenario.getGraphData()),
                        " (под-сценарий «" + name(scenario, subId) + "»)");
                checkKnowledgeBases(subLevel, runner, knowledgeBases, checkedBases, problems);
                next.add(subLevel);
            });
        }
    }

    /**
     * Доступен ли сценарий пользователю: общий либо свой.
     *
     * @param scenario сценарий
     * @param runner   нормализованный пользователь
     * @return {@code true} — сценарий общий или принадлежит пользователю
     */
    public static boolean canAccess(Scenario scenario, String runner) {
        return Boolean.TRUE.equals(scenario.getShared()) || runner.equals(scenario.getUserId());
    }

    /**
     * Доступна ли база знаний пользователю: общая либо своя.
     *
     * @param kb     база знаний
     * @param runner нормализованный пользователь
     * @return {@code true} — база общая или принадлежит пользователю
     */
    public static boolean canAccess(KnowledgeBase kb, String runner) {
        return kb.isShared() || runner.equals(kb.getUserId());
    }

    /** Базы знаний узлов графа; каждая база проверяется один раз, проблемы дописываются в {@code problems}. */
    private static void checkKnowledgeBases(Level level, String runner,
                                            Function<UUID, Optional<KnowledgeBase>> knowledgeBases,
                                            Set<UUID> checkedBases, List<String> problems) {
        if (level.graph() == null || level.graph().nodes() == null) {
            return;
        }
        for (NodeDto node : level.graph().nodes()) {
            UUID kbId = node == null || node.data() == null ? null : parseId(node.data().knowledgeBaseId());
            if (kbId == null || !checkedBases.add(kbId)) {
                continue;
            }
            knowledgeBases.apply(kbId)
                    .filter(kb -> !canAccess(kb, runner))
                    .ifPresent(kb -> problems.add("База знаний «" + name(kb, kbId) + "» (" + kbId
                            + ") недоступна пользователю" + level.where()));
        }
    }

    /** Корректные id под-сценариев узлов «Под-сценарий» графа в порядке узлов. */
    private static List<UUID> subScenarioIds(GraphDataDto graphData) {
        List<UUID> ids = new ArrayList<>();
        if (graphData == null || graphData.nodes() == null) {
            return ids;
        }
        for (NodeDto node : graphData.nodes()) {
            boolean subNode = node != null && node.data() != null
                    && ScenarioNodeType.SUBSCENARIO_NODE.toString().equals(node.type());
            UUID id = subNode ? parseId(node.data().value()) : null;
            if (id != null) {
                ids.add(id);
            }
        }
        return ids;
    }

    private static UUID parseId(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(value.trim());
        } catch (IllegalArgumentException e) {
            // некорректный id — не вопрос доступа: движок сообщит о нём, как и прежде
            return null;
        }
    }

    private static String name(Scenario scenario, UUID id) {
        String name = scenario.getName();
        return name == null || name.isBlank() ? id.toString() : name;
    }

    private static String name(KnowledgeBase kb, UUID id) {
        String name = kb.getName();
        return name == null || name.isBlank() ? id.toString() : name;
    }
}
