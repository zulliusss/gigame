package ru.sber.cs.ai.gigame.service;

import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.util.function.Supplier;

/**
 * Политика повторов одного вызова GigaChat: сколько ждать перед следующей попыткой и когда сдаться.
 * <p>
 * Два независимых бюджета ожидания:
 * <ul>
 *   <li>превышение лимита запросов (429) — пауза удваивается от {@code base429} до {@code max429Delay},
 *       пока суммарное ожидание не превысит {@code max429Wait};</li>
 *   <li>недоступность GigaChat (5xx, таймаут, обрыв соединения, неразрешённое имя) — так же с удвоением от
 *       {@code baseUnavailable} до {@code maxUnavailableDelay} в пределах {@code maxUnavailableWait}: шаг встаёт на
 *       паузу и сам продолжается, когда сервис снова отвечает. При {@code maxUnavailableWait} = 0 — прежнее правило:
 *       не больше {@code maxAttempts} попыток с линейной задержкой;</li>
 *   <li>таймаут ответа на запрос (read-timeout клиента, страховочный потолок вызова) — отдельная ветка
 *       {@link #nextAfterTimeout}: не больше {@link #TIMEOUT_RETRIES} повторов с паузой {@code baseUnavailable}.
 *       Таймаут почти всегда означает, что сама генерация длиннее предела, и получасовой бюджет недоступности
 *       лишь повторял бы гарантированно обрывающийся запрос.</li>
 * </ul>
 * Прочие ошибки (400, 401, 402, 413 и т. п.) не повторяются. Текст ошибки всегда начинается с {@link #FAILED},
 * после двоеточия — краткая причина ({@link GigaChatFailureReason}): она попадает в шаг прогона и журнал пользователя.
 */
final class GigaChatRetryPolicy {

    /** Начало текста ошибки вызова, который не повторяется или исчерпал паузы; после двоеточия — краткая причина. */
    static final String FAILED = "Не удалось выполнить запрос к GigaChat";
    /** Предел повторов запроса, оборванного таймаутом ответа. */
    static final int TIMEOUT_RETRIES = 2;
    private static final int MAX_SHIFT = 10;
    private static final long MILLIS_IN_MINUTE = 60_000;

    private final Settings settings;
    /** Имя модели запроса для текста причины (вычисляется только при ошибке). */
    private final Supplier<String> model;
    private long waitedRateLimit;
    private long waitedUnavailable;
    private int rateLimitRound;
    private int unavailableRound;
    private int timeoutRound;

    /** Параметры политики. */
    record Settings(long base429, long max429Delay, long max429Wait,
                    long baseUnavailable, long maxUnavailableDelay, long maxUnavailableWait, int maxAttempts) {
    }

    /** Пауза перед следующей попыткой и её описание для журнала прогона. */
    record Wait(long delayMillis, String notice) {
    }

    GigaChatRetryPolicy(Settings settings) {
        this(settings, () -> null);
    }

    GigaChatRetryPolicy(Settings settings, Supplier<String> model) {
        this.settings = settings;
        this.model = model;
    }

    /**
     * Текст ошибки вызова GigaChat с краткой причиной.
     *
     * @param reason краткая причина
     * @return «Не удалось выполнить запрос к GigaChat: причина»
     */
    static String failedMessage(String reason) {
        return FAILED + ": " + reason;
    }

    /**
     * Следующая пауза после неудачного вызова.
     *
     * @param rateLimited      ошибка — превышение лимита (429)
     * @param transientFailure ошибка — временная недоступность
     * @param cause            исходная ошибка
     * @return пауза перед повтором
     * @throws GigaChatException если ошибка не повторяется или бюджет ожидания исчерпан
     */
    Wait next(boolean rateLimited, boolean transientFailure, RuntimeException cause) {
        if (rateLimited) {
            return rateLimitWait(cause);
        }
        if (transientFailure) {
            return settings.maxUnavailableWait() > 0 ? unavailableWait(cause) : legacyWait(cause);
        }
        throw new GigaChatException(failedMessage(reason(cause)), cause);
    }

    /**
     * Следующая пауза после запроса, оборванного таймаутом ответа (read-timeout клиента или страховочный
     * потолок вызова): не больше {@link #TIMEOUT_RETRIES} повторов с паузой {@code baseUnavailable}, без
     * получасового бюджета недоступности.
     *
     * @param cause исходная ошибка
     * @return пауза перед повтором
     * @throws GigaChatException если повторы исчерпаны
     */
    Wait nextAfterTimeout(RuntimeException cause) {
        if (++timeoutRound > TIMEOUT_RETRIES) {
            throw new GigaChatException(failedMessage("ответ не получен за таймаут запроса, повторы исчерпаны: "
                    + TIMEOUT_RETRIES + " (последняя ошибка: " + reason(cause) + ")"), cause);
        }
        long delay = Math.max(1, settings.baseUnavailable());
        return new Wait(delay, "ответ GigaChat не получен за таймаут запроса — повтор " + timeoutRound + " из "
                + TIMEOUT_RETRIES + " через " + delay / 1000 + " с");
    }

    private String reason(RuntimeException cause) {
        return GigaChatFailureReason.describe(cause, model.get());
    }

    private Wait rateLimitWait(RuntimeException cause) {
        long delay = doubled(settings.base429(), settings.max429Delay(), rateLimitRound);
        if (waitedRateLimit + delay > settings.max429Wait()) {
            throw new GigaChatException(failedMessage("превышен лимит запросов (429) — паузы исчерпаны: лимит не восстановился за "
                    + waitedRateLimit / MILLIS_IN_MINUTE + " мин ожидания"), cause);
        }
        rateLimitRound++;
        waitedRateLimit += delay;
        return new Wait(delay, "превышен лимит запросов GigaChat (429) — пауза " + delay / 1000
                + " с, шаг продолжится автоматически (ожидание " + waitedRateLimit / 1000 + " с)");
    }

    private Wait unavailableWait(RuntimeException cause) {
        long delay = doubled(settings.baseUnavailable(), settings.maxUnavailableDelay(), unavailableRound);
        if (waitedUnavailable + delay > settings.maxUnavailableWait()) {
            throw new GigaChatException(failedMessage("GigaChat недоступен дольше " + waitedUnavailable / MILLIS_IN_MINUTE
                    + " мин — паузы исчерпаны (последняя ошибка: " + reason(cause) + ")"), cause);
        }
        unavailableRound++;
        waitedUnavailable += delay;
        return new Wait(delay, "GigaChat недоступен — пауза " + delay / 1000 + " с, шаг продолжится автоматически, "
                + "когда сервис ответит (ожидание " + waitedUnavailable / 1000 + " с из " + settings.maxUnavailableWait() / 1000 + ")");
    }

    private Wait legacyWait(RuntimeException cause) {
        if (++unavailableRound > Math.max(1, settings.maxAttempts())) {
            throw new GigaChatException(failedMessage("GigaChat недоступен — попытки исчерпаны: " + Math.max(1, settings.maxAttempts())
                    + " (последняя ошибка: " + reason(cause) + ")"), cause);
        }
        long delay = settings.baseUnavailable() * unavailableRound;
        return new Wait(delay, "временный сбой GigaChat — повтор " + unavailableRound + " через " + delay + " мс");
    }

    private static long doubled(long base, long max, int round) {
        long safeBase = Math.max(1, base);
        return Math.min(safeBase << Math.min(round, MAX_SHIFT), Math.max(safeBase, max));
    }
}
