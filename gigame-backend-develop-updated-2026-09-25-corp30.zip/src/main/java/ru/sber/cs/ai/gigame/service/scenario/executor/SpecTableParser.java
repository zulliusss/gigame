package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Разбор таблицы характеристик продукции из текста документа (извещение, документация, техническое задание).
 * <p>
 * Таблицы docx приходят в тексте строками «&lt; ячейка | ячейка | … &gt;», ячейки могут быть многострочными.
 * Таблица характеристик — та, у которой в шапке есть колонка наименования и колонка характеристик
 * («№ п/п | Наименование продукции | Характеристики», «Наименование ТМЦ | Описание, технические и
 * функциональные характеристики»). Каждая строка таблицы — позиция: наименование и перечень строк характеристик.
 * <p>
 * Таблица «параметр — значение» («п\п | Наименование Оборудования | Требуемый параметр | Требуемое значение |
 * ед. изм. | кол-во»): каждая строка — одна характеристика «параметр: значение единица»; пустая (объединённая)
 * ячейка наименования продолжает позицию предыдущей строки. Единица из названия параметра («Высота подъема, мм»)
 * переносится за значение — как пишут в договоре («Высота подъема – 10500 мм»); колонка «ед. изм.» перед
 * колонкой количества относится к позиции («шт»), а не к значению, и не используется.
 * <p>
 * Требования вне таблицы (ГОСТ, сертификаты, упаковка) в сверку не попадают.
 */
// Бизнес-шаблоны регулярных выражений и когнитивная сложность — правки нецелесообразны (Rules.md).
@SuppressWarnings({"java:S5854", "java:S5857", "java:S5843", "java:S5869", "java:S2479", "java:S5998", "java:S3776",
        "java:S2259"})
final class SpecTableParser {

    /** Шаблон заголовка колонки параметра по умолчанию («Требуемый параметр», «Характеристика», «Наименование показателя»). */
    static final String PARAM_COLUMN = "параметр|характеристик|показател";
    /**
     * Шаблон заголовка колонки значения по умолчанию («Значение», «Требуемое значение», «Значение показателя»);
     * «Конкретные значения, предлагаемые участником» — не колонка требований.
     */
    static final String VALUE_COLUMN = "^\\s*(?:требуем\\S*\\s+)?значени";

    private static final Pattern ROW = Pattern.compile("^[\\[\\s]*< (.*?) >[\\s\\]]*$", Pattern.MULTILINE | Pattern.DOTALL);
    private static final Pattern CELL_SEPARATOR = Pattern.compile(" \\| ");
    private static final Pattern GAP = Pattern.compile("[\\s\\[\\]]*");
    private static final Pattern SPACES = Pattern.compile("\\s+");
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern UNIT_COLUMN = Pattern.compile("ед\\.?\\s*изм|единиц\\S*\\s+измерен", FLAGS);
    private static final Pattern QUANTITY_COLUMN = Pattern.compile("кол-?\\s*во|количеств|объ[её]м", FLAGS);
    /** Единица измерения в названии параметра: «мм», «кг», «кВт», «км/ч», «м3», «°С», «%». */
    private static final String UNIT = "(?:[кмсд]?м[23²³]?|[км]?г|т|л|мл|с|сек|мин|ч|сут|мес|шт|[кмг]?вт(?:·?ч)?|к?ва|[км]?в|м?а·?ч|м?а|[кмг]?гц"
            + "|дб|лм|лк|[кмг]?па|бар|атм|°\\s?[cс]|%|об|[км]?н|дж|л\\.\\s?с|[мг]бит|[кмгт]б|дюйм\\S{0,2})(?:/[\\p{L}\\d²³]{1,4})?";
    /** Параметр с единицей через запятую или в скобках: «Высота подъема , мм», «Мощность (кВт)». */
    private static final Pattern PARAM_UNIT = Pattern.compile("^(.*?\\S)\\s*(?:,\\s*(" + UNIT + ")|\\(\\s*(" + UNIT + ")\\s*\\))\\s*\\.?$", FLAGS);
    /** Параметр с составной единицей без запятой: «Скорость подъема с грузом м/с», «Расход л/мин» (не «Порты USB/HDMI»). */
    private static final Pattern PARAM_COMPOUND_UNIT = Pattern.compile("^(.*?\\S)\\s+([а-яёМ][а-яё]{0,3}\\d?/[а-яё\\d²³]{1,4})$");
    /** Строки характеристик короче (в нормализованном виде) — не характеристики, а обрывки. */
    private static final int MIN_LINE_CHARS = 4;
    /** Ячейка шапки длиннее — это строка с данными, а не заголовок. */
    private static final int MAX_HEADER_CHARS = 160;

    private SpecTableParser() {
    }

    /** Позиция таблицы: номер, наименование, строки характеристик и документ-источник. */
    record SpecPosition(String number, String name, List<String> lines, String source) {
    }

    /** Шаблоны заголовков колонок: наименование, характеристики, параметр и значение. */
    record Columns(Pattern name, Pattern spec, Pattern param, Pattern value) {
    }

    /** Колонки шапки: наименование и характеристики либо (таблица «параметр — значение») параметр, значение и единица; нет колонки — -1. */
    private record Header(int nameCol, int specCol, int paramCol, int valueCol, int unitCol) {

        boolean paramValue() {
            return valueCol >= 0;
        }

        int lastCol() {
            return Math.max(nameCol, Math.max(specCol, Math.max(paramCol, valueCol)));
        }
    }

    /** Разбираемая таблица: шапка и текущая позиция (для строк с объединённой ячейкой наименования). */
    private static final class Table {
        private final Header header;
        private String name;
        private String number;
        private SpecPosition current;

        Table(Header header) {
            this.header = header;
        }
    }

    /**
     * Позиции всех таблиц характеристик документа; колонки параметра и значения — по умолчанию.
     *
     * @param text     текст документа
     * @param source   имя файла-источника
     * @param nameCol  шаблон заголовка колонки наименования
     * @param specCol  шаблон заголовка колонки характеристик
     * @return позиции по порядку
     */
    static List<SpecPosition> parse(String text, String source, Pattern nameCol, Pattern specCol) {
        return parse(text, source, new Columns(nameCol, specCol, Pattern.compile(PARAM_COLUMN, FLAGS), Pattern.compile(VALUE_COLUMN, FLAGS)));
    }

    /**
     * Позиции всех таблиц характеристик документа.
     *
     * @param text    текст документа
     * @param source  имя файла-источника
     * @param columns шаблоны заголовков колонок
     * @return позиции по порядку
     */
    static List<SpecPosition> parse(String text, String source, Columns columns) {
        String value = text == null ? "" : text;
        List<SpecPosition> positions = new ArrayList<>();
        Matcher m = ROW.matcher(value);
        Table table = null;
        int previousEnd = -1;
        while (m.find()) {
            boolean contiguous = previousEnd >= 0 && GAP.matcher(value.substring(previousEnd, m.start())).matches();
            List<String> cells = List.of(CELL_SEPARATOR.split(m.group(1), -1));
            Header found = header(cells, columns);
            if (found != null) {
                table = new Table(found);
            } else if (table != null && contiguous) {
                addRow(positions, cells, table, source);
            } else {
                table = null;
            }
            previousEnd = m.end();
        }
        return positions;
    }

    /**
     * Строка характеристики таблицы «параметр — значение»: «параметр: значение единица». Единица из названия
     * параметра переносится за значение; пустой параметр (объединённая ячейка) — только значение.
     *
     * @param param параметр
     * @param value значение
     * @param unit  единица из колонки единиц (пусто — нет колонки)
     * @return строка характеристики; пусто, если значения нет
     */
    static String paramLine(String param, String value, String unit) {
        String v = collapse(value);
        if (v.isEmpty()) {
            return "";
        }
        String p = collapse(param);
        String u = collapse(unit);
        Matcher m = PARAM_UNIT.matcher(p);
        Matcher compound = PARAM_COMPOUND_UNIT.matcher(p);
        if (m.matches()) {
            p = m.group(1);
            u = m.group(2) != null ? m.group(2) : m.group(3);
        } else if (compound.matches()) {
            p = compound.group(1);
            u = compound.group(2);
        }
        String line = p.isEmpty() ? v : p + ": " + v;
        return u.isEmpty() || endsWithUnit(v, u) ? line : line + " " + u;
    }

    private static Header header(List<String> cells, Columns columns) {
        for (String cell : cells) {
            if (cell.length() > MAX_HEADER_CHARS) {
                return null;
            }
        }
        Header paramValue = paramValueHeader(cells, columns);
        return paramValue != null ? paramValue : specHeader(cells, columns.name(), columns.spec());
    }

    private static Header specHeader(List<String> cells, Pattern nameCol, Pattern specCol) {
        int name = -1;
        int spec = -1;
        for (int i = 0; i < cells.size(); i++) {
            String cell = cells.get(i);
            if (spec < 0 && SafeRegex.find(specCol, cell)) {
                spec = i;
            } else if (name < 0 && SafeRegex.find(nameCol, cell)) {
                name = i;
            }
        }
        return name >= 0 && spec >= 0 ? new Header(name, spec, -1, -1, -1) : null;
    }

    private static Header paramValueHeader(List<String> cells, Columns columns) {
        int value = column(cells, columns.value(), -1, -1);
        int param = value < 0 ? -1 : column(cells, columns.param(), value, -1);
        int name = param < 0 ? -1 : column(cells, columns.name(), value, param);
        return name < 0 ? null : new Header(name, -1, param, value, unitColumn(cells, value, param, name));
    }

    /** Первая колонка, заголовок которой совпал с шаблоном, кроме уже занятых. */
    private static int column(List<String> cells, Pattern pattern, int taken, int alsoTaken) {
        for (int i = 0; i < cells.size(); i++) {
            if (i != taken && i != alsoTaken && SafeRegex.find(pattern, cells.get(i))) {
                return i;
            }
        }
        return -1;
    }

    /** Колонка единицы значения; «ед. изм.» перед «кол-во» — единица позиции («шт»), а не значения. */
    private static int unitColumn(List<String> cells, int value, int param, int name) {
        for (int i = 0; i < cells.size(); i++) {
            if (i != value && i != param && i != name && UNIT_COLUMN.matcher(cells.get(i)).find()) {
                boolean quantityNext = i + 1 < cells.size() && QUANTITY_COLUMN.matcher(cells.get(i + 1)).find();
                return quantityNext ? -1 : i;
            }
        }
        return -1;
    }

    private static void addRow(List<SpecPosition> positions, List<String> cells, Table table, String source) {
        if (cells.size() <= table.header.lastCol()) {
            return;
        }
        if (table.header.paramValue()) {
            addParamValueRow(positions, cells, table, source);
        } else {
            addPosition(positions, cells, table.header, source);
        }
    }

    private static void addPosition(List<SpecPosition> positions, List<String> cells, Header header, String source) {
        String name = collapse(cells.get(header.nameCol()));
        List<String> lines = new ArrayList<>();
        for (String line : cells.get(header.specCol()).split("\\R")) {
            if (NormalizedText.normalize(line).length() >= MIN_LINE_CHARS) {
                lines.add(line.strip());
            }
        }
        if (NormalizedText.normalize(name).length() >= MIN_LINE_CHARS && !lines.isEmpty()) {
            positions.add(new SpecPosition(number(positions, cells, header), name, lines, source));
        }
    }

    private static void addParamValueRow(List<SpecPosition> positions, List<String> cells, Table table, String source) {
        Header header = table.header;
        String name = collapse(cells.get(header.nameCol()));
        if (!name.isEmpty() && !name.equals(table.name)) {
            table.name = name;
            table.number = number(positions, cells, header);
            table.current = null;
        }
        String unit = header.unitCol() >= 0 && header.unitCol() < cells.size() ? cells.get(header.unitCol()) : "";
        String line = paramLine(cells.get(header.paramCol()), cells.get(header.valueCol()), unit);
        if (table.name == null || NormalizedText.normalize(table.name).length() < MIN_LINE_CHARS
                || NormalizedText.normalize(line).length() < MIN_LINE_CHARS) {
            return;
        }
        if (table.current == null) {
            table.current = new SpecPosition(table.number, table.name, new ArrayList<>(), source);
            positions.add(table.current);
        }
        table.current.lines().add(line);
    }

    private static String number(List<SpecPosition> positions, List<String> cells, Header header) {
        return header.nameCol() > 0 ? cells.get(0).strip() : String.valueOf(positions.size() + 1);
    }

    private static String collapse(String cell) {
        return SPACES.matcher(cell).replaceAll(" ").strip();
    }

    /** Значение уже оканчивается единицей («не менее 10 мм» и единица «мм»). */
    private static boolean endsWithUnit(String value, String unit) {
        String v = value.toLowerCase(Locale.ROOT);
        v = v.endsWith(".") ? v.substring(0, v.length() - 1) : v;
        String u = unit.toLowerCase(Locale.ROOT);
        int at = v.length() - u.length();
        return v.endsWith(u) && (at == 0 || !Character.isLetter(v.charAt(at - 1)));
    }
}
