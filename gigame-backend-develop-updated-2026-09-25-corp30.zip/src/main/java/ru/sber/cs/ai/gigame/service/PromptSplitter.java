package ru.sber.cs.ai.gigame.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.List;

/**
 * Деление контекста промпта при ответе GigaChat «context too long» (и при отказе цензора на узле сценария) и сборка
 * ответов частей: точка разреза выбирается по границам документов, страниц и
 * абзацев (а не посреди строки), ответы частей помечаются заголовками
 * {@link #partHeader(int, int)}, JSON-массивы частей объединяются в один.
 */
final class PromptSplitter {

    /** Причина деления в заголовках частей: запрос больше контекстного окна модели. */
    static final String CONTEXT_REASON = "запрос разделён из-за лимита контекста";
    /** Причина деления в заголовках частей: отказ цензора GigaChat на запросе целиком. */
    static final String REFUSAL_REASON = "запрос разделён из-за ограничения темы GigaChat";
    /** Границы разреза по убыванию приоритета: документ группы, страница OCR, абзац, строка. */
    private static final List<String> BOUNDARIES = List.of("\n\n<<<Документ:", "\n--- страница", "\n\n", "\n");
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private PromptSplitter() {
    }

    /**
     * Заголовок части ответа при делении запроса из-за лимита контекста.
     *
     * @param part  номер части (с 1)
     * @param total число частей
     * @return строка-разделитель
     */
    static String partHeader(int part, int total) {
        return partHeader(part, total, CONTEXT_REASON);
    }

    /**
     * Заголовок части ответа при делении запроса по указанной причине.
     *
     * @param part   номер части (с 1)
     * @param total  число частей
     * @param reason причина деления ({@link #CONTEXT_REASON} либо {@link #REFUSAL_REASON})
     * @return строка-разделитель
     */
    static String partHeader(int part, int total, String reason) {
        return "=== Часть " + part + "/" + total + " (" + reason + ") ===";
    }

    /**
     * Позиция разреза контекста пополам: ближайшая к середине граница из
     * {@link #BOUNDARIES} в средней половине текста, иначе середина.
     *
     * @param context делимый контекст
     * @return индекс начала второй части
     */
    static int cutPoint(String context) {
        int mid = context.length() / 2;
        int low = context.length() / 4;
        int high = context.length() - low;
        for (String boundary : BOUNDARIES) {
            int before = context.lastIndexOf(boundary, mid);
            int after = context.indexOf(boundary, mid);
            int best = -1;
            if (before >= low && (after < 0 || mid - before <= after - mid)) {
                best = before;
            } else if (after >= 0 && after <= high) {
                best = after;
            }
            if (best > 0) {
                // граница остаётся в начале второй части (разделитель документа/страницы не теряется)
                return best;
            }
        }
        return mid;
    }

    /**
     * JSON-массив ответа части — последний разбираемый массив объектов (или пустой) по тем же правилам, что
     * проверка контракта json_массив ({@link LlmJson#last}): блок ```json в приоритете, «[]» или «[1]» в преамбуле
     * ответа настоящий массив не заслоняют (раньше брался первый сбалансированный «[…]»).
     *
     * @param text текст ответа модели
     * @return массив или {@code null}, если массива нет или он не разбирается
     */
    static ArrayNode jsonArray(String text) {
        if (text == null) {
            return null;
        }
        LlmJson.Parsed block = LlmJson.last(text, LlmJson.ARRAY_OF_OBJECTS_OR_EMPTY).first();
        return block != null && block.node() instanceof ArrayNode array ? array : null;
    }

    /**
     * Части контекста по размеру — для упреждающего деления документов больше предела (corp21): каждая часть не
     * длиннее {@code limit}, разрез — по ближайшей границе документа/страницы/абзаца/строки перед пределом, следующая
     * часть начинается на {@code overlap} знаков раньше конца предыдущей (с начала строки), чтобы факт на стыке частей
     * попал целиком хотя бы в одну из них.
     *
     * @param context контекст (после границы «инструкция | контекст»)
     * @param limit   предел длины части, знаков
     * @param overlap перекрытие соседних частей, знаков
     * @return границы частей [начало, конец) по порядку; одна часть, если контекст не длиннее предела
     */
    static List<int[]> sizedRanges(String context, int limit, int overlap) {
        List<int[]> ranges = new ArrayList<>();
        int length = context.length();
        int start = 0;
        while (true) {
            int end = start + limit >= length ? length : cutBefore(context, start + limit, start + limit / 2);
            ranges.add(new int[]{start, end});
            if (end >= length) {
                return ranges;
            }
            // следующая часть начинается раньше конца предыдущей (перекрытие с начала строки), но не раньше половины
            // предела от начала предыдущей — иначе часть из одной длинной строки повторялась бы почти целиком
            start = Math.min(end, Math.max(lineStart(context, end - overlap), start + limit / 2));
        }
    }

    /**
     * Позиция разреза не позже {@code target}: ближайшая к нему граница из {@link #BOUNDARIES} не раньше
     * {@code low}, иначе сам {@code target}.
     */
    static int cutBefore(String context, int target, int low) {
        for (String boundary : BOUNDARIES) {
            int at = context.lastIndexOf(boundary, target - 1);
            if (at > low) {
                return at;
            }
        }
        return target;
    }

    /** Начало строки, в которую попадает позиция {@code pos}. */
    static int lineStart(String context, int pos) {
        int nl = context.lastIndexOf('\n', Math.max(0, pos - 1));
        return nl < 0 ? 0 : nl + 1;
    }

    /**
     * Объединённый JSON-массив ответов частей.
     *
     * @param json         JSON объединённого массива
     * @param withoutArray номера (с 1) принятых частей, в ответе которых массива нет — их текст идёт в примечание
     */
    record MergedArrays(String json, List<Integer> withoutArray) {
    }

    /**
     * Объединяет JSON-массивы ответов частей в один. Часть без массива (ответ прозой «в этом фрагменте нарушений
     * нет») слияние не отменяет — её номер попадает в {@link MergedArrays#withoutArray}, а текст при сборке ответа
     * идёт в примечание перед массивом. Раньше одна такая часть отменяла объединение всех, ответ склеивался под
     * заголовками «Часть k/N», и Excel-узел видел только массив первой части.
     *
     * @param parts тексты ответов частей по порядку ({@code null} — часть отклонена, не учитывается)
     * @return объединённый массив либо {@code null}, если массива нет ни в одной части
     */
    static MergedArrays mergeJsonArrays(List<String> parts) {
        ArrayNode merged = MAPPER.createArrayNode();
        List<Integer> withoutArray = new ArrayList<>();
        boolean found = false;
        for (int i = 0; i < parts.size(); i++) {
            if (parts.get(i) == null) {
                continue;
            }
            ArrayNode array = jsonArray(parts.get(i));
            if (array == null) {
                withoutArray.add(i + 1);
            } else {
                found = true;
                merged.addAll(array);
            }
        }
        if (!found) {
            return null;
        }
        try {
            return new MergedArrays(MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(merged), withoutArray);
        } catch (Exception e) {
            return null;
        }
    }
}
