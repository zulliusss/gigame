package ru.sber.cs.ai.gigame.utils;

import org.apache.commons.lang3.StringUtils;
import ru.sber.cs.ai.gigame.exception.ScenarioException;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Регулярные выражения из JSON сценария (и из ответов модели) с защитой поды:
 * предел длины шаблона, кэш скомпилированных шаблонов и прерываемый поиск.
 * <p>
 * Стандартный {@link Matcher} не прерывается ни флагом остановки прогона, ни
 * {@code Thread.interrupt()}: катастрофический шаблон вроде {@code ^(\s*\S+\s*)+$}
 * на 200 000 символов занимал поток пула прогонов навсегда. Здесь текст оборачивается
 * в {@link CharSequence}, чей {@code charAt} каждые {@value #CHECK_EVERY} обращений
 * проверяет прерывание потока, флаг остановки прогона ({@link #setCancelCheck}) и
 * дедлайн ({@code app.scenario.regex-timeout-millis}, по умолчанию
 * {@value #DEFAULT_TIMEOUT_MILLIS} мс) и бросает {@link ScenarioException}.
 * <p>
 * Статические шаблоны кода через этот класс не идут — только пользовательские.
 */
public final class SafeRegex {

    /** Предел длины пользовательского шаблона. */
    public static final int MAX_PATTERN_LENGTH = 512;

    /** Дедлайн одного поиска по умолчанию, мс. */
    public static final long DEFAULT_TIMEOUT_MILLIS = 5000;

    /** Текст ошибки поиска, прерванного остановкой прогона. */
    public static final String CANCELLED = "Прогон остановлен пользователем";

    /** Через сколько обращений к символам текста выполняется проверка (степень двойки). */
    static final int CHECK_EVERY = 1024;

    private static final int CHECK_MASK = CHECK_EVERY - 1;

    private static final int CACHE_LIMIT = 256;

    private static final int PATTERN_IN_MESSAGE = 80;

    private static volatile long timeoutMillis = DEFAULT_TIMEOUT_MILLIS;

    /** Проверка остановки прогона для потока узла (ставит движок на время выполнения узла). */
    private static final ThreadLocal<BooleanSupplier> CANCEL_CHECK = ThreadLocal.withInitial(() -> () -> false);

    private static final Map<String, Pattern> CACHE = new ConcurrentHashMap<>();

    private SafeRegex() {
    }

    /**
     * Компилирует пользовательский шаблон (с кэшем).
     *
     * @param regex шаблон
     * @param flags флаги {@link Pattern}
     * @param name  имя параметра сценария — для текста ошибки
     * @return скомпилированный шаблон
     * @throws ScenarioException                     если шаблон длиннее {@value #MAX_PATTERN_LENGTH} символов
     * @throws java.util.regex.PatternSyntaxException если шаблон некорректен
     */
    public static Pattern compile(String regex, int flags, String name) {
        String source = regex == null ? "null" : regex;
        if (source.length() > MAX_PATTERN_LENGTH) {
            throw new ScenarioException("параметр «" + name + "»: регулярное выражение длиннее "
                    + MAX_PATTERN_LENGTH + " символов (" + source.length() + ") — упростите шаблон");
        }
        String key = flags + "\u0000" + source;
        Pattern cached = CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        Pattern compiled = Pattern.compile(source, flags);
        if (CACHE.size() >= CACHE_LIMIT) {
            CACHE.clear();
        }
        CACHE.put(key, compiled);
        return compiled;
    }

    /**
     * Дедлайн нового поиска: сейчас плюс таймаут.
     *
     * @return дедлайн в наносекундах {@link System#nanoTime()}
     */
    public static long deadline() {
        return deadlineAfter(timeoutMillis);
    }

    /**
     * Дедлайн через заданное число миллисекунд.
     *
     * @param millis миллисекунды
     * @return дедлайн в наносекундах {@link System#nanoTime()}
     */
    public static long deadlineAfter(long millis) {
        return System.nanoTime() + millis * 1_000_000L;
    }

    /**
     * Прерываемый матчер с собственным дедлайном.
     *
     * @param pattern шаблон
     * @param text    текст
     * @return матчер
     */
    public static Matcher matcher(Pattern pattern, CharSequence text) {
        return matcher(pattern, text, deadline());
    }

    /**
     * Прерываемый матчер с общим дедлайном (несколько поисков одной операции,
     * например построчный фильтр, укладываются в один таймаут).
     *
     * @param pattern       шаблон
     * @param text          текст
     * @param deadlineNanos дедлайн ({@link #deadline()})
     * @return матчер
     */
    public static Matcher matcher(Pattern pattern, CharSequence text, long deadlineNanos) {
        return pattern.matcher(new Guarded(text == null ? "" : text, pattern, deadlineNanos, CANCEL_CHECK.get()));
    }

    /**
     * Есть ли совпадение шаблона в тексте.
     *
     * @param pattern шаблон
     * @param text    текст
     * @return {@code true}, если найдено
     */
    public static boolean find(Pattern pattern, CharSequence text) {
        return matcher(pattern, text).find();
    }

    /**
     * Совпадает ли текст с шаблоном целиком.
     *
     * @param pattern шаблон
     * @param text    текст
     * @return {@code true}, если совпадает
     */
    public static boolean matches(Pattern pattern, CharSequence text) {
        return matcher(pattern, text).matches();
    }

    /**
     * Замена всех совпадений.
     *
     * @param pattern     шаблон
     * @param text        текст
     * @param replacement замена (синтаксис {@link Matcher#replaceAll(String)})
     * @return текст с заменами
     */
    public static String replaceAll(Pattern pattern, CharSequence text, String replacement) {
        return matcher(pattern, text).replaceAll(replacement);
    }

    /**
     * Таймаут одного поиска.
     *
     * @return миллисекунды
     */
    public static long getTimeoutMillis() {
        return timeoutMillis;
    }

    /**
     * Ставит таймаут одного поиска (настройка {@code app.scenario.regex-timeout-millis}).
     *
     * @param millis миллисекунды (меньше 1 — значение по умолчанию)
     */
    public static void setTimeoutMillis(long millis) {
        timeoutMillis = millis < 1 ? DEFAULT_TIMEOUT_MILLIS : millis;
    }

    /**
     * Ставит проверку остановки прогона для текущего потока: поиск прерывается,
     * когда она возвращает {@code true}.
     *
     * @param check проверка (null — без проверки)
     */
    public static void setCancelCheck(BooleanSupplier check) {
        CANCEL_CHECK.set(check == null ? () -> false : check);
    }

    /** Снимает проверку остановки прогона с текущего потока. */
    public static void clearCancelCheck() {
        CANCEL_CHECK.remove();
    }

    /**
     * Текст под поиском: каждые {@value #CHECK_EVERY} обращений к символу проверяет
     * прерывание потока, остановку прогона и дедлайн.
     */
    private static final class Guarded implements CharSequence {

        private final CharSequence text;
        private final Pattern pattern;
        private final long deadlineNanos;
        private final long startNanos;
        private final BooleanSupplier cancelled;
        private int calls;

        Guarded(CharSequence text, Pattern pattern, long deadlineNanos, BooleanSupplier cancelled) {
            this.text = text;
            this.pattern = pattern;
            this.deadlineNanos = deadlineNanos;
            this.startNanos = System.nanoTime();
            this.cancelled = cancelled;
        }

        /** Обращение к шаблону для текста ошибки, усечённое до {@value #PATTERN_IN_MESSAGE} знаков. */
        private static String describe(Pattern pattern) {
            return "«" + StringUtils.abbreviate(pattern.pattern(), PATTERN_IN_MESSAGE) + "»";
        }

        /** Время до дедлайна человекочитаемо («300 мс» / «5 с»). */
        private static String formatTimeout(long deadlineNanos, long startNanos) {
            // округление до миллисекунды: матчер создаётся чуть позже дедлайна («299 мс» вместо «300 мс»)
            long millis = Math.max(1, Math.round((deadlineNanos - startNanos) / 1_000_000.0));
            return millis % 1000 == 0 ? millis / 1000 + " с" : millis + " мс";
        }

        @Override
        public int length() {
            return text.length();
        }

        @Override
        public char charAt(int index) {
            if ((++calls & CHECK_MASK) == 0) {
                check();
            }
            return text.charAt(index);
        }

        @Override
        public CharSequence subSequence(int start, int end) {
            return text.subSequence(start, end);
        }

        @Override
        public String toString() {
            return text.toString();
        }

        private void check() {
            // прерывание снимается: ошибка узла затем сохраняется в БД в этом же потоке
            if (Thread.interrupted() || cancelled.getAsBoolean()) {
                throw new ScenarioException(CANCELLED);
            }
            if (System.nanoTime() - deadlineNanos > 0) {
                throw new ScenarioException("регулярное выражение " + describe(pattern) + " превысило "
                        + formatTimeout(deadlineNanos, startNanos) + " — упростите шаблон");
            }
        }
    }
}
