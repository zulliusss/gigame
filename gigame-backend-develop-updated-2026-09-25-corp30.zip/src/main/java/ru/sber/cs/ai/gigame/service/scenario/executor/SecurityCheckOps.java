package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.service.scenario.executor.PriceCheck.Verdict;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «сверить_обеспечение» узла «Трансформация»: размер обеспечения исполнения договора по договору
 * сверяется кодом с требованием закупки — полем «обеспечение_договора» JSON протокола, а если там его нет,
 * JSON документации.
 * <p>
 * Требование в процентах пересчитывается в рубли: «от цены (стоимости, суммы, лимита) договора» — от цены
 * договора, «от начальной (максимальной) цены», «от НМЦД» — от НМЦД лота протокола (лот выбирается так же,
 * как при сверке цены, см. {@link PriceTermOps#selectLot}). Сумма в договоре совпадает с расчётом, если
 * отличается от него не больше чем на 1 руб.; «не менее X%» и «не более X%» — нижняя и верхняя граница.
 * Фиксированная сумма требования сравнивается с суммой договора напрямую, процент в договоре без суммы — с
 * процентом требования.
 * <p>
 * Модель на этой сверке ошибается в арифметике: на комплекте «Перемещение УС» (письмо Бубнова, 24.09) в одном
 * прогоне из трёх требование «2% от общей стоимости (лимита) договора» при цене 83 369 110,00 и обеспечительном
 * платеже 1 667 382,20 получило «сумма обеспечения не соответствует расчёту». Что код однозначно не разбирает
 * (обеспечение не требуется, условие об авансе, несколько процентов или сумм, база процента не названа, в договоре
 * размера нет), получает итог {@link #NOT_ASSESSED} — такую сверку делает модель.
 * <pre>
 * {"оп": "сверить_обеспечение"}
 * </pre>
 */
final class SecurityCheckOps {

    /** Первая строка отчёта: по ней узел сравнения находит блок. */
    static final String HEADER = "ОБЕСПЕЧЕНИЕ — РАСЧЁТ (код)";
    /** Итог: сумма (процент) договора отвечает требованию. */
    static final String MATCH = "СОВПАДАЕТ";
    /** Итог: сумма (процент) договора требованию не отвечает. */
    static final String MISMATCH = "РАСХОЖДЕНИЕ";
    /** Итог: код требование однозначно не разобрал, сверку делает модель. */
    static final String NOT_ASSESSED = "НЕ ОЦЕНИВАЕТСЯ";

    /** Допуск сравнения сумм, руб.: договор округляет расчёт до копеек или до рублей. */
    private static final double SUM_TOLERANCE = 1.0;
    private static final double PERCENT_TOLERANCE = 1e-6;
    /** Меньшие числа в записи обеспечения — номера пунктов и сроки в днях, а не суммы. */
    private static final double MIN_AMOUNT = 100.0;
    private static final int MAX_QUOTE = 400;
    /** Сколько символов перед процентом смотреть на «не менее» / «не более». */
    private static final int BOUND_WINDOW = 20;
    private static final String FIELD = "обеспечение_договора";
    private static final String CONTRACT = "договор";
    private static final String PROTOCOL = "протокол";
    private static final String DOCUMENTATION = "документация";
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern PERCENT = Pattern.compile(
            "(\\d{1,3}(?:[.,]\\d{1,4})?)\\s*(?:\\([^()]{1,40}\\)\\s*)?(?:%|процент)", FLAGS);
    private static final Pattern DATE = Pattern.compile("\\d{1,2}\\.\\d{1,2}\\.\\d{2,4}");
    private static final Pattern AMOUNT = Pattern.compile(
            "\\d{1,3}(?:[ \\u00A0\\u202F]\\d{3})+(?:[.,]\\d{1,2})?(?!\\d)|\\d+(?:[.,]\\d{1,2})?(?!\\d)");
    private static final Pattern NOT_REQUIRED = Pattern.compile(
            "не\\s+(?:установлен|устанавлива|требуется|применя|предусмотрен)|отсутству|без\\s+обеспечени", FLAGS);
    private static final Pattern ADVANCE = Pattern.compile("аванс", FLAGS);
    private static final Pattern NMCD_BASE = Pattern.compile("НМЦ|начальн[а-яё]*\\s*\\(?\\s*максимальн", FLAGS);
    private static final Pattern PRICE_BASE = Pattern.compile(
            "(?:цен|стоимост|сумм|лимит)[а-яё]*(?:\\s*\\([^()]{0,40}\\))?\\s+(?:настоящего\\s+)?(?:договор|контракт)", FLAGS);
    private static final Pattern AT_LEAST = Pattern.compile("не\\s+менее(?:\\s+чем)?\\s*$", FLAGS);
    private static final Pattern AT_MOST = Pattern.compile("не\\s+(?:более|выше|превыша[а-яё]*)(?:\\s+чем)?\\s*$", FLAGS);
    private static final Pattern UNSET = Pattern.compile("^(?:не\\s+указан[оаы]?|нет\\s+данных|не\\s+задан[оаы]?|-1)?[.;]?$", FLAGS);

    private SecurityCheckOps() {
    }

    /** Граница требования: точное значение, «не менее» или «не более». */
    enum Bound {
        EXACT, AT_LEAST, AT_MOST;

        /**
         * Отвечает ли значение договора требованию.
         *
         * @param actual    значение договора
         * @param required  значение требования
         * @param tolerance допуск
         * @return {@code true}, если отвечает
         */
        boolean fits(double actual, double required, double tolerance) {
            return switch (this) {
                case EXACT -> Math.abs(actual - required) <= tolerance;
                case AT_LEAST -> actual >= required - tolerance;
                case AT_MOST -> actual <= required + tolerance;
            };
        }

        /** Приписка к расчёту для границы. */
        String note() {
            return switch (this) {
                case EXACT -> "";
                case AT_LEAST -> " (требование — не менее)";
                case AT_MOST -> " (требование — не более)";
            };
        }
    }

    /**
     * Процент из записи с границей, стоящей перед ним.
     *
     * @param value процент
     * @param bound граница
     */
    record Percent(double value, Bound bound) {
    }

    /**
     * Исходные данные сверки из JSON узлов.
     *
     * @param requirement требование к обеспечению (протокол либо документация), пусто — не указано
     * @param source      откуда требование: «протокол» или «документация»
     * @param contract    запись об обеспечении в договоре, пусто — не указано
     * @param price       цена договора либо {@code null}
     * @param nmcd        НМЦД лота протокола либо {@code null}
     */
    record Terms(String requirement, String source, String contract, Double price, Double nmcd) {

        /**
         * Данные из разобранных JSON-объектов: договор может прийти несколькими частями (запрос разделён из-за
         * лимита контекста) — берётся первое заданное значение поля по всем частям.
         *
         * @param blocks JSON-объекты входа
         * @return данные сверки
         */
        static Terms of(List<LlmJson.Parsed> blocks) {
            String fromProtocol = text(blocks, PROTOCOL, FIELD);
            String fromDocumentation = fromProtocol.isEmpty() ? text(blocks, DOCUMENTATION, FIELD) : "";
            String source = fromProtocol.isEmpty() && !fromDocumentation.isEmpty() ? DOCUMENTATION : PROTOCOL;
            Double price = amount(blocks, CONTRACT, "сумма");
            return new Terms(fromProtocol.isEmpty() ? fromDocumentation : fromProtocol, source, text(blocks, CONTRACT, FIELD),
                    price != null ? price : amount(blocks, CONTRACT, "сумма_руб"), lotNmcd(blocks));
        }
    }

    /** База процента: сумма и её название либо причина, по которой её нет. */
    private record Base(Double value, String label) {
    }

    /**
     * Отчёт о сверке обеспечения.
     *
     * @param text выходы предыдущих узлов (JSON договора, протокола, документации)
     * @return отчёт с итоговым JSON
     */
    static String check(String text) {
        Terms terms = Terms.of(JsonBlocks.parsedObjects(text));
        Verdict verdict = verdict(terms);
        StringBuilder sb = new StringBuilder(HEADER).append('\n');
        sb.append("Требование (").append(terms.source()).append("): «").append(quote(terms.requirement())).append("»\n");
        sb.append("Договор: «").append(quote(terms.contract())).append("»\n");
        sb.append("Итог: ").append(verdict.status()).append(" — ").append(verdict.text());
        if (NOT_ASSESSED.equals(verdict.status())) {
            sb.append("; сверку делает модель");
        }
        return sb.append("\n{\"обеспечение\": \"").append(verdict.status()).append("\"}").toString();
    }

    /**
     * Итог сверки.
     *
     * @param terms исходные данные
     * @return итог и пояснение с расчётом
     */
    static Verdict verdict(Terms terms) {
        String skip = skipReason(terms);
        if (skip != null) {
            return new Verdict(NOT_ASSESSED, skip);
        }
        List<Percent> percents = percents(terms.requirement());
        if (percents.size() > 1) {
            return new Verdict(NOT_ASSESSED, "в требовании несколько процентов");
        }
        return percents.isEmpty() ? byFixedSum(terms) : byPercent(terms, percents.get(0));
    }

    private static String skipReason(Terms terms) {
        if (terms.requirement().isEmpty()) {
            return "размер обеспечения в протоколе и документации не указан";
        }
        if (NOT_REQUIRED.matcher(terms.requirement()).find()) {
            return "по закупке обеспечение не требуется или не установлено";
        }
        if (ADVANCE.matcher(terms.requirement()).find()) {
            return "требование связано с авансом";
        }
        return terms.contract().isEmpty() ? "в договоре размер обеспечения не указан" : null;
    }

    private static Verdict byPercent(Terms terms, Percent required) {
        Base base = base(terms);
        if (base.value() == null) {
            return new Verdict(NOT_ASSESSED, base.label());
        }
        double expected = BigDecimal.valueOf(required.value() * base.value() / 100).setScale(2, RoundingMode.HALF_UP).doubleValue();
        String calc = percentText(required.value()) + "% × " + money(base.value()) + " (" + base.label() + ") = " + money(expected)
                + required.bound().note();
        List<Double> sums = amounts(terms.contract());
        Double actual = sums.isEmpty() ? null : closest(sums, expected);
        if (actual != null && required.bound().fits(actual, expected, SUM_TOLERANCE)) {
            return new Verdict(MATCH, calc + "; в договоре " + money(actual));
        }
        List<Percent> own = percents(terms.contract());
        if (own.size() == 1) {
            return byContractPercent(required, own.get(0).value(), actual, calc);
        }
        return actual == null
                ? new Verdict(NOT_ASSESSED, "в договоре нет суммы обеспечения числом")
                : new Verdict(MISMATCH, calc + "; в договоре " + money(actual) + ", разница " + money(actual - expected));
    }

    /**
     * Процент в договоре: совпал с требованием, а сумма договора расчёту не равна, — решает модель (число в записи
     * может быть ценой договора, а не суммой обеспечения).
     */
    private static Verdict byContractPercent(Percent required, double own, Double actual, String calc) {
        String percents = "в требовании " + percentText(required.value()) + "%, в договоре " + percentText(own) + "%";
        if (!required.bound().fits(own, required.value(), PERCENT_TOLERANCE)) {
            return new Verdict(MISMATCH, percents + required.bound().note());
        }
        return actual == null
                ? new Verdict(MATCH, percents)
                : new Verdict(NOT_ASSESSED, percents + ", но сумма в договоре " + money(actual) + " не равна расчёту " + calc);
    }

    private static Verdict byFixedSum(Terms terms) {
        List<Double> required = amounts(terms.requirement());
        if (required.size() != 1) {
            return new Verdict(NOT_ASSESSED, required.isEmpty() ? "в требовании нет ни процента, ни суммы" : "в требовании несколько сумм");
        }
        double expected = required.get(0);
        List<Double> sums = amounts(terms.contract());
        if (sums.isEmpty()) {
            return new Verdict(NOT_ASSESSED, "в договоре нет суммы обеспечения числом");
        }
        double actual = closest(sums, expected);
        String described = "требование " + money(expected) + "; в договоре " + money(actual);
        return Bound.EXACT.fits(actual, expected, SUM_TOLERANCE)
                ? new Verdict(MATCH, described)
                : new Verdict(MISMATCH, described + ", разница " + money(actual - expected));
    }

    private static Base base(Terms terms) {
        if (NMCD_BASE.matcher(terms.requirement()).find()) {
            return terms.nmcd() == null ? new Base(null, "процент от НМЦД, а НМЦД лота в протоколе не найдена")
                    : new Base(terms.nmcd(), "НМЦД лота");
        }
        if (PRICE_BASE.matcher(terms.requirement()).find()) {
            return terms.price() == null ? new Base(null, "процент от цены договора, а цена договора числом не указана")
                    : new Base(terms.price(), "цена договора");
        }
        return new Base(null, "база процента не названа");
    }

    /**
     * Разные проценты записи по порядку с границей «не менее» / «не более», стоящей перед числом.
     *
     * @param text запись
     * @return проценты
     */
    static List<Percent> percents(String text) {
        List<Percent> result = new ArrayList<>();
        Set<Double> seen = new LinkedHashSet<>();
        Matcher m = PERCENT.matcher(text);
        while (m.find()) {
            double value = Double.parseDouble(m.group(1).replace(',', '.'));
            if (seen.add(value)) {
                result.add(new Percent(value, bound(text.substring(Math.max(0, m.start() - BOUND_WINDOW), m.start()))));
            }
        }
        return result;
    }

    private static Bound bound(String before) {
        if (AT_LEAST.matcher(before).find()) {
            return Bound.AT_LEAST;
        }
        return AT_MOST.matcher(before).find() ? Bound.AT_MOST : Bound.EXACT;
    }

    /**
     * Разные денежные суммы записи по порядку: даты и проценты не считаются, числа меньше 100 — номера пунктов
     * и сроки, а не суммы. Разряды — через пробел, неразрывный или узкий неразрывный пробел.
     *
     * @param text запись
     * @return суммы
     */
    static List<Double> amounts(String text) {
        String cleaned = PERCENT.matcher(DATE.matcher(text).replaceAll(" ")).replaceAll(" ");
        Set<Double> values = new LinkedHashSet<>();
        Matcher m = AMOUNT.matcher(cleaned);
        while (m.find()) {
            double value = Double.parseDouble(m.group().replaceAll("[ \\u00A0\\u202F]", "").replace(',', '.'));
            if (value >= MIN_AMOUNT) {
                values.add(value);
            }
        }
        return new ArrayList<>(values);
    }

    private static double closest(List<Double> values, double target) {
        double best = values.get(0);
        for (double value : values) {
            if (Math.abs(value - target) < Math.abs(best - target)) {
                best = value;
            }
        }
        return best;
    }

    private static String text(List<LlmJson.Parsed> blocks, String type, String field) {
        for (LlmJson.Parsed block : blocks) {
            JsonNode node = block.node();
            String value = node.path(field).asText("").strip();
            if (isType(node, type) && !UNSET.matcher(value).matches()) {
                return value;
            }
        }
        return "";
    }

    private static Double amount(List<LlmJson.Parsed> blocks, String type, String field) {
        for (LlmJson.Parsed block : blocks) {
            Double value = PriceCheck.amount(block.node().path(field));
            if (isType(block.node(), type) && value != null && value > 0) {
                return value;
            }
        }
        return null;
    }

    private static Double lotNmcd(List<LlmJson.Parsed> blocks) {
        LlmJson.Parsed protocol = JsonBlocks.byDocumentType(blocks, PROTOCOL);
        LlmJson.Parsed contract = JsonBlocks.byDocumentType(blocks, CONTRACT);
        JsonNode lot = protocol == null || contract == null ? null : PriceTermOps.selectLot(protocol.node(), contract.node());
        Double value = lot == null ? null : PriceCheck.amount(lot.path("нмцд_лота_руб"));
        return value != null && value > 0 ? value : null;
    }

    private static boolean isType(JsonNode node, String type) {
        return type.equalsIgnoreCase(node.path("тип_документа").asText("").strip());
    }

    private static String quote(String text) {
        if (text.isEmpty()) {
            return "не указано";
        }
        return text.length() <= MAX_QUOTE ? text : text.substring(0, MAX_QUOTE) + "…";
    }

    /**
     * Сумма с разрядами через пробел и десятичной запятой: «1 667 382,20».
     *
     * @param value сумма
     * @return запись суммы
     */
    static String money(double value) {
        return String.format(Locale.ROOT, "%,.2f", value).replace(',', ' ').replace('.', ',');
    }

    private static String percentText(double value) {
        return BigDecimal.valueOf(value).stripTrailingZeros().toPlainString().replace('.', ',');
    }
}
