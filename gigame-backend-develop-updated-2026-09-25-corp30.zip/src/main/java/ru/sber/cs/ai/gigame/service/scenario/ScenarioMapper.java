package ru.sber.cs.ai.gigame.service.scenario;

import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;

import java.util.Set;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_DOCUMENTS_TEXT;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_ERROR;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_PREVIOUS_OUTPUT;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_RESULT;

public class ScenarioMapper {

    /**
     * Максимальная длина строкового поля шага в подробном отчёте прогона.
     * Полные тексты хранятся в БД и уходят в файловые выгрузки; отчёт — витрина
     * для человека, и корпоративные прокси (SOWA) валидируют его поля по схеме
     * с потолком 500 000 символов — больший ответ блокируется целиком (403).
     */
    private static final int REPORT_FIELD_LIMIT = 200_000;

    /**
     * maxLength поля output_data.error шага (ScenarioRunStepOutputDataResponse)
     * в статической спецификации. Полный текст ошибки остаётся в БД и в
     * WS-событии node_error.
     */
    static final int STEP_ERROR_LIMIT = 255;

    /**
     * maxLength итога прогона result (ScenarioRunDetailResponse) в статической
     * спецификации; итог вместе с пометкой усечения укладывается в этот лимит.
     */
    static final int RUN_RESULT_LIMIT = 500_000;

    /**
     * maxItems массива steps (ScenarioRunDetailResponse) в статической спецификации.
     */
    static final int RUN_STEPS_MAX_ITEMS = 100;

    /**
     * enum поля node_type шага (ScenarioRunStepResponse) в статической
     * спецификации: тип вне списка (например, «unknown») шлюз отклонил бы
     * вместе со всем отчётом, поэтому в REST-ответе он не отдаётся.
     */
    static final Set<String> STEP_NODE_TYPES = Set.of(
            "input", "output", "loop", "switch", "if_node", "processing", "calc",
            "aggregate", "transform", "subscenario", "control", "wait", "note");

    private ScenarioMapper() {
    }

    /**
     * Усекает строковое поле отчёта до {@link #REPORT_FIELD_LIMIT} с явной
     * пометкой об усечении; {@code null} и короткие значения — как есть.
     */
    private static String clipString(String value) {
        if (value == null || value.length() <= REPORT_FIELD_LIMIT) {
            return value;
        }
        return value.substring(0, REPORT_FIELD_LIMIT)
                + "\n\n…[показаны первые " + REPORT_FIELD_LIMIT + " из " + value.length()
                + " символов — полный текст доступен в файловых выгрузках узлов]";
    }

    /**
     * Усекает итог прогона до {@link #RUN_RESULT_LIMIT} с явной пометкой об
     * усечении: итог output-узла склеивает все входы (а в режиме «накапливать» —
     * и строки прошлых прогонов), и больший ответ шлюз блокирует целиком.
     *
     * @param value итог прогона (может быть {@code null})
     * @return итог не длиннее лимита спецификации; {@code null} и короткие значения — как есть
     */
    static String clipRunResult(String value) {
        if (value == null || value.length() <= RUN_RESULT_LIMIT) {
            return value;
        }
        return SchemaLimitUtils.clip(value, RUN_RESULT_LIMIT,
                "\n\n…[итог усечён до " + RUN_RESULT_LIMIT + " из " + value.length()
                        + " символов в ответе API — полный итог в DOCX-экспорте]");
    }

    /**
     * Преобразует сущность Scenario в DTO для ответа клиенту.
     *
     * @param s сущность сценария
     * @return DTO с метаданными сценария
     */
    static ScenarioResponse toResponse(Scenario s) {
        return new ScenarioResponse(
                s.getId(),
                s.getName(),
                s.getDescription(),
                s.getCreatedAt(),
                s.getUpdatedAt(),
                Boolean.TRUE.equals(s.getShared()),
                true,
                null,
                0L,
                null,
                0L
        );
    }

    /**
     * Преобразует сущность Scenario в DTO с полными данными графа.
     *
     * @param s сущность сценария
     * @return DTO с полной информацией о сценарии
     */
    static ScenarioDetailResponse toDetailResponse(Scenario s) {
        return new ScenarioDetailResponse(
                s.getId(),
                s.getName(),
                s.getDescription(),
                s.getCreatedAt(),
                s.getUpdatedAt(),
                GraphDataMapper.toDto(s.getGraphData()),
                Boolean.TRUE.equals(s.getShared())
        );
    }

    /**
     * Преобразует сущность ScenarioRun в DTO для ответа клиенту.
     *
     * @param r сущность запуска
     * @return DTO с метаданными запуска
     */
    static ScenarioRunResponse toRunResponse(ScenarioRun r) {
        return new ScenarioRunResponse(
                r.getId(),
                r.getScenarioId(),
                r.getStatus(),
                r.getInputDocumentIds(),
                r.getStartedAt(),
                r.getCompletedAt()
        );
    }

    /**
     * Преобразует сущность ScenarioRunStep в DTO для REST-ответа клиенту:
     * ошибка шага усечена до {@link #STEP_ERROR_LIMIT} по схеме, тип узла вне
     * {@link #STEP_NODE_TYPES} не отдаётся ({@code null} — ключ опускается).
     *
     * @param s сущность шага запуска
     * @return DTO с данными шага
     */
    static ScenarioRunStepResponse toStepResponse(ScenarioRunStep s) {
        return buildStepResponse(s, true);
    }

    /**
     * Преобразует сущность ScenarioRunStep в DTO для DOCX-экспорта: бинарный
     * файл шлюз по JSON-схеме не проверяет, поэтому ошибка шага усекается
     * только до {@link #REPORT_FIELD_LIMIT}, как до приведения REST-ответа к схеме.
     *
     * @param s сущность шага запуска
     * @return DTO с данными шага
     */
    static ScenarioRunStepResponse toExportStepResponse(ScenarioRunStep s) {
        return buildStepResponse(s, false);
    }

    private static ScenarioRunStepResponse buildStepResponse(ScenarioRunStep s, boolean schemaLimits) {
        return new ScenarioRunStepResponse(
                s.getId(),
                s.getNodeId(),
                schemaLimits ? schemaNodeType(s.getNodeType()) : s.getNodeType(),
                s.getStatus(),
                getScenarioRunStepInputDataResponse(s),
                getScenarioRunStepOutputDataResponse(s, schemaLimits),
                clipString(s.getPromptUsed()),
                s.getTokensUsed(),
                s.getStartedAt(),
                s.getCompletedAt()
        );
    }

    /**
     * Тип узла шага для REST-ответа: значение из enum спецификации либо {@code null}.
     *
     * @param nodeType тип узла из БД (может быть {@code null})
     * @return тип узла из {@link #STEP_NODE_TYPES} или {@code null}
     */
    private static String schemaNodeType(String nodeType) {
        return nodeType != null && STEP_NODE_TYPES.contains(nodeType) ? nodeType : null;
    }

    private static ScenarioRunStepOutputDataResponse getScenarioRunStepOutputDataResponse(ScenarioRunStep s,
                                                                                          boolean schemaLimits) {
        if (s.getOutputData() == null) {
            return null;
        }
        String error = s.getOutputData().get(KEY_ERROR);
        return new ScenarioRunStepOutputDataResponse(
                clipString(s.getOutputData().get(KEY_RESULT)),
                schemaLimits ? SchemaLimitUtils.clip(error, STEP_ERROR_LIMIT) : clipString(error)
        );
    }

    private static ScenarioRunStepInputDataResponse getScenarioRunStepInputDataResponse(ScenarioRunStep s) {
        if (s.getInputData() == null) {
            return null;
        }
        return new ScenarioRunStepInputDataResponse(
                clipString(s.getInputData().get(KEY_DOCUMENTS_TEXT)),
                clipString(s.getInputData().get(KEY_PREVIOUS_OUTPUT))
        );
    }
}
