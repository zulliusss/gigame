package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «даты_из_периода» узла «Трансформация»: календарные даты периода опыта
 * считаются кодом из формулировки периода и даты начала срока подачи заявок.
 * <p>
 * Модель переносила в строку «… — календарные даты» даты из примера промпта
 * («за последние 6 месяцев» при начале подачи 17.09.2025 → «с 08.04.2025 по 08.10.2025»).
 * Для каждой строки, чей критерий оканчивается на «— календарные даты», берётся строка
 * с критерием, равным началу (формулировка периода). Если в формулировке задан срок
 * «N лет/года/месяцев», отсчитанный до даты публикации (подачи заявок), значение
 * перезаписывается: «с [дата − N] по [дата]», где дата — из строки «Дата начала срока
 * подачи заявок» (для сроков до окончания подачи — из строки «Дата окончания срока подачи заявок»).
 * Формулировка «с ГГГГ г. по настоящее время» («с ГГГГ года по текущую дату») даёт «с 01.01.ГГГГ по [дата
 * начала срока подачи заявок]»; перечень допустимых месяцев затем строит операция «месяцы_из_дат».
 * Формулировки без числа срока и года начала и с явными датами не трогаются; «по настоящее время» без даты
 * начала подачи — тоже.
 * <pre>
 * {"оп": "даты_из_периода", "суффикс_дат": "календарные даты",
 *  "строка_начала_подачи": "Дата начала срока подачи заявок",
 *  "строка_окончания_подачи": "Дата окончания срока подачи заявок"}
 * </pre>
 */
final class PeriodDatesOps {

    private static final Pattern TERM = Pattern.compile(
            "(?<!\\d)(\\d{1,3})\\s*(?:\\([^)]{0,40}\\)\\s*)?(лет|года?|месяц(?:а|ев)?)(?![а-яё])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern RELATIVE = Pattern.compile("до\\s+(?:даты|дня|момента)|последн",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** «с 2021 г. по настоящее время», «с 2021 года по текущую дату»: группа 1 — год начала периода. */
    private static final Pattern SINCE_YEAR = Pattern.compile(
            "(?<![а-яё\\d])с\\s*(\\d{4})\\s*(?:г(?:ода|\\.)?\\s*)?по\\s+(?:настоящее\\s+время|текущую\\s+дату)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern EXPLICIT_DATES = Pattern.compile("\\d{2}\\.\\d{2}\\.\\d{4}[^\\n]{0,40}\\d{2}\\.\\d{2}\\.\\d{4}");
    private static final Pattern SUBMISSION_END = Pattern.compile("окончани[яе]\\s+(?:срока\\s+)?подачи",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern DATE = Pattern.compile("(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    /** Разумный предел срока в месяцах: больше — ошибка разбора, не период опыта. */
    private static final int MAX_MONTHS = 240;

    private PeriodDatesOps() {
    }

    /** Разобранный срок периода: число месяцев и исходная запись («6 (шесть) месяцев»). */
    private record Term(int months, String phrase) {
    }

    /**
     * Перезаписывает строки «… — календарные даты», если период задан сроком до даты публикации.
     *
     * @param op   параметры операции (суффикс критерия и названия строк с датами подачи заявок)
     * @param rows строки критериев (объекты с полями «критерий», «значение»)
     * @return число пересчитанных строк
     */
    static int datesFromPeriod(Map<String, Object> op, List<Object> rows) {
        Pattern dates = suffixPattern(String.valueOf(op.getOrDefault("суффикс_дат", "календарные даты")));
        LocalDate start = dateOfRow(rows, String.valueOf(op.getOrDefault("строка_начала_подачи", "Дата начала срока подачи заявок")));
        LocalDate end = dateOfRow(rows, String.valueOf(op.getOrDefault("строка_окончания_подачи", "Дата окончания срока подачи заявок")));
        int done = 0;
        for (Object o : rows) {
            if (o instanceof Map<?, ?> m && fillRow(cast(m), rows, dates, start, end)) {
                done++;
            }
        }
        return done;
    }

    private static boolean fillRow(Map<String, Object> datesRow, List<Object> rows, Pattern dates, LocalDate start, LocalDate end) {
        Matcher dm = dates.matcher(text(datesRow.get("критерий")));
        if (!dm.find()) {
            return false;
        }
        String wording = text(valueOf(rows, dm.group(1)));
        Term term = relativeTerm(wording);
        if (term == null) {
            return fillSinceYear(datesRow, dm.group(1).strip(), wording, start);
        }
        boolean fromEnd = SUBMISSION_END.matcher(wording).find();
        LocalDate base = fromEnd ? end : start;
        if (base == null) {
            return false;
        }
        String baseName = fromEnd ? "даты окончания срока подачи заявок" : "даты начала срока подачи заявок";
        write(datesRow, base.minusMonths(term.months()), base, "расчёт кодом по строке «" + dm.group(1).strip() + "»: "
                + term.phrase() + " до " + baseName + " (" + base.format(FORMAT) + ")");
        return true;
    }

    /**
     * Период «с ГГГГ г. по настоящее время» («с ГГГГ года по текущую дату»): с 1 января года по дату начала срока
     * подачи заявок. Модель подставляла дату окончания подачи (Приложение 3: «по 09.09.2024» вместо «по 16.08.2024»).
     *
     * @param datesRow  строка «… — календарные даты»
     * @param criterion начало критерия (строка с формулировкой периода)
     * @param wording   формулировка периода
     * @param start     дата начала срока подачи заявок; {@code null} — строка не трогается
     * @return {@code true}, если даты записаны
     */
    private static boolean fillSinceYear(Map<String, Object> datesRow, String criterion, String wording, LocalDate start) {
        Matcher sm = SINCE_YEAR.matcher(wording);
        if (start == null || EXPLICIT_DATES.matcher(wording).find() || !sm.find()) {
            return false;
        }
        LocalDate from = LocalDate.of(Integer.parseInt(sm.group(1)), 1, 1);
        if (from.isAfter(start) || ChronoUnit.MONTHS.between(from, start) > MAX_MONTHS) {
            return false;
        }
        write(datesRow, from, start, "расчёт кодом по строке «" + criterion + "»: " + sm.group().strip()
                + " — с 1 января по дату начала срока подачи заявок (" + start.format(FORMAT) + ")");
        return true;
    }

    /** Записывает в строку рассчитанный период «с ДД.ММ.ГГГГ по ДД.ММ.ГГГГ», источник расчёта и пометку достоверности. */
    private static void write(Map<String, Object> datesRow, LocalDate from, LocalDate to, String source) {
        datesRow.put("значение", "с " + from.format(FORMAT) + " по " + to.format(FORMAT));
        datesRow.put("источник", source);
        datesRow.put("достоверность", PeriodMonthsOps.CALCULATED);
    }

    /**
     * Срок периода из формулировки: число с единицей «лет/года/месяцев», отсчитанное до даты.
     *
     * @param wording формулировка периода из документации
     * @return срок либо {@code null}, если период не задан сроком или содержит явные даты
     */
    private static Term relativeTerm(String wording) {
        if (!RELATIVE.matcher(wording).find() || EXPLICIT_DATES.matcher(wording).find()) {
            return null;
        }
        Matcher tm = TERM.matcher(wording);
        if (!tm.find()) {
            return null;
        }
        int count = Integer.parseInt(tm.group(1));
        int months = tm.group(2).toLowerCase().startsWith("месяц") ? count : count * 12;
        return months > 0 && months <= MAX_MONTHS ? new Term(months, tm.group().strip()) : null;
    }

    /** Шаблон «[начало критерия] — [суффикс]»: группа 1 — начало критерия. */
    private static Pattern suffixPattern(String suffix) {
        return Pattern.compile("^\\s*(.*?)\\s*[—–-]\\s*" + Pattern.quote(suffix.strip()) + "\\s*$",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    }

    private static Object valueOf(List<Object> rows, String criterion) {
        for (Object o : rows) {
            if (o instanceof Map<?, ?> m && text(m.get("критерий")).strip().equalsIgnoreCase(criterion.strip())) {
                return m.get("значение");
            }
        }
        return null;
    }

    private static LocalDate dateOfRow(List<Object> rows, String criterion) {
        Matcher dm = DATE.matcher(text(valueOf(rows, criterion)));
        if (!dm.find()) {
            return null;
        }
        try {
            return LocalDate.parse(dm.group(1), FORMAT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> cast(Map<?, ?> m) {
        return (Map<String, Object>) m;
    }

    private static String text(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
