package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.exception.ScenarioException;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Калькулятор формул в стиле Excel для узла «Расчёт».
 * <p>
 * Поддерживает:
 * <ul>
 *   <li>числа (десятичный разделитель — точка; запятая допускается между цифрами),
 *       строки в кавычках ("..." или '...'), переменные (буквы/цифры/подчёркивание;
 *       пробел в имени показателя записывается подчёркиванием);</li>
 *   <li>операции + - * / (также × и ÷), унарный минус, скобки;</li>
 *   <li>сравнения &lt; &lt;= &gt; &gt;= = == &lt;&gt; != — результат 1 (истина) или 0 (ложь);</li>
 *   <li>функции (русские и английские имена, аргументы через «;»):
 *       ЕСЛИ/IF(условие; тогда; иначе), МИН/MIN, МАКС/MAX, СУММ/SUM, СРЗНАЧ/AVG,
 *       КОЛ/COUNT, ОКРУГЛ/ROUND(x; знаков), МОДУЛЬ/ABS, И/AND, ИЛИ/OR, НЕ/NOT,
 *       СОДЕРЖИТ/CONTAINS(текст; подстрока), ЗНАЧ/VAL(имя; по_умолчанию);</li>
 *   <li>агрегаты по колонке таблицы: МИН(цена) — если единственный аргумент является
 *       именем колонки, функция считается по всем строкам (как диапазон в Excel).</li>
 * </ul>
 * Все вычисления — BigDecimal.
 */
final class FormulaEvaluator {

    /**
     * Источник значений для вычисления: значения переменных текущей строки,
     * колонки таблицы для агрегатов и приём предупреждений (ЗНАЧ с дефолтом).
     */
    interface Context {
        /**
         * Значение переменной: BigDecimal, String или null, если отсутствует.
         */
        Object variable(String name);

        /**
         * Значения колонки по всем строкам таблицы (null — колонки нет).
         */
        List<Object> column(String name);

        /**
         * Предупреждение для отчёта (например, подставлено значение по умолчанию).
         */
        void warn(String message);

        /**
         * Поиск значения в другой таблице (функция ВПР): в таблице {@code table}
         * находится строка, где колонка {@code keyColumn} равна {@code keyValue},
         * и возвращается её значение из {@code valueColumn} (null — не найдено).
         */
        default Object lookup(String table, String keyColumn, Object keyValue, String valueColumn) {
            return null;
        }
    }

    private static final MathContext MC = new MathContext(12, RoundingMode.HALF_EVEN);
    private static final Set<String> AGGREGATES = Set.of(
            "МИН", "MIN", "МАКС", "MAX", "СУММ", "SUM", "СРЗНАЧ", "AVG", "КОЛ", "COUNT");
    /** Предел длины формулы. */
    static final int MAX_FORMULA_LENGTH = 2000;
    /** Предел вложенности скобок, унарных знаков и функций: глубже — StackOverflowError потока прогона. */
    static final int MAX_DEPTH = 200;
    /** Пределы числа знаков ОКРУГЛ: setScale(999999999) строил число на 10⁹ разрядов. */
    static final int MIN_ROUND_DIGITS = -10;
    static final int MAX_ROUND_DIGITS = 30;

    private final String text;
    private final Context ctx;
    private int pos;
    private int depth;

    private FormulaEvaluator(String text, Context ctx) {
        this.text = text;
        this.ctx = ctx;
    }

    /**
     * Вычисляет выражение; результат — число.
     *
     * @throws ScenarioException при синтаксической ошибке, неизвестной переменной,
     *                           делении на ноль — с понятным описанием
     */
    static BigDecimal eval(String expression, Context ctx) {
        Object result = evalRaw(expression, ctx);
        return toNumber(result, expression);
    }

    /**
     * Вычисляет выражение; результат — число или строка (для фильтров и сравнений).
     */
    static Object evalRaw(String expression, Context ctx) {
        if (expression.length() > MAX_FORMULA_LENGTH) {
            throw new ScenarioException("Формула длиннее " + MAX_FORMULA_LENGTH + " символов ("
                    + expression.length() + ") — упростите формулу");
        }
        var p = new FormulaEvaluator(expression, ctx);
        Object result = p.parseComparison();
        p.skipSpaces();
        if (p.pos < p.text.length()) {
            throw new ScenarioException("Формула «" + expression + "»: непонятный символ «"
                    + p.text.charAt(p.pos) + "» (позиция " + (p.pos + 1) + ")");
        }
        return result;
    }

    // ------------------------------------------------------------------
    // Разбор по уровням приоритета
    // ------------------------------------------------------------------

    private Object parseComparison() {
        Object left = parseAdditive();
        skipSpaces();
        String op = matchComparisonOp();
        if (op == null) {
            return left;
        }
        Object right = parseAdditive();
        return compare(left, right, op) ? BigDecimal.ONE : BigDecimal.ZERO;
    }

    private String matchComparisonOp() {
        for (String op : new String[]{"<=", ">=", "<>", "!=", "==", "<", ">", "="}) {
            if (text.startsWith(op, pos)) {
                pos += op.length();
                return op;
            }
        }
        return null;
    }

    private boolean compare(Object left, Object right, String op) {
        if (left instanceof String || right instanceof String) {
            String l = String.valueOf(left).trim();
            String r = String.valueOf(right).trim();
            return switch (op) {
                case "=", "==" -> l.equalsIgnoreCase(r);
                case "<>", "!=" -> !l.equalsIgnoreCase(r);
                default -> throw new ScenarioException("Формула «" + text + "»: строки сравниваются "
                        + "только через = и <>");
            };
        }
        int c = toNumber(left, text).compareTo(toNumber(right, text));
        return switch (op) {
            case "<" -> c < 0;
            case "<=" -> c <= 0;
            case ">" -> c > 0;
            case ">=" -> c >= 0;
            case "=", "==" -> c == 0;
            // <> и !=
            default -> c != 0;
        };
    }

    private Object parseAdditive() {
        Object value = parseTerm();
        while (true) {
            skipSpaces();
            if (match('+')) {
                value = toNumber(value, text).add(toNumber(parseTerm(), text), MC);
            } else if (match('-') || match('−')) {
                value = toNumber(value, text).subtract(toNumber(parseTerm(), text), MC);
            } else {
                return value;
            }
        }
    }

    private Object parseTerm() {
        Object value = parseFactor();
        while (true) {
            skipSpaces();
            if (match('*') || match('×')) {
                value = toNumber(value, text).multiply(toNumber(parseFactor(), text), MC);
            } else if (match('/') || match('÷')) {
                BigDecimal divisor = toNumber(parseFactor(), text);
                if (divisor.signum() == 0) {
                    throw new ScenarioException("Формула «" + text + "»: деление на ноль");
                }
                value = toNumber(value, text).divide(divisor, MC);
            } else {
                return value;
            }
        }
    }

    private Object parseFactor() {
        if (++depth > MAX_DEPTH) {
            throw new ScenarioException("Формула «" + text + "»: вложенность скобок и функций больше "
                    + MAX_DEPTH + " — упростите формулу");
        }
        try {
            return parseFactorBody();
        } finally {
            depth--;
        }
    }

    private Object parseFactorBody() {
        skipSpaces();
        if (match('-') || match('−')) {
            return toNumber(parseFactor(), text).negate();
        }
        if (match('+')) {
            return parseFactor();
        }
        if (match('(')) {
            return parseParenthesized();
        }
        return parseOperand();
    }

    private Object parseParenthesized() {
        Object value = parseComparison();
        skipSpaces();
        if (!match(')')) {
            throw new ScenarioException("Формула «" + text + "»: не закрыта скобка");
        }
        return value;
    }

    /**
     * Операнд: строковый литерал, число либо переменная/функция.
     */
    private Object parseOperand() {
        if (pos >= text.length()) {
            throw new ScenarioException("Формула «" + text + "»: ожидалось число, переменная, функция "
                    + "или скобка в конце выражения");
        }
        char c = text.charAt(pos);
        if (c == '"' || c == '\'') {
            return parseString();
        }
        if (Character.isDigit(c) || c == '.') {
            return parseNumber();
        }
        if (Character.isLetter(c) || c == '_') {
            return parseIdentOrFunction();
        }
        throw new ScenarioException("Формула «" + text + "»: ожидалось число, переменная, функция "
                + "или скобка на позиции " + (pos + 1));
    }

    // ------------------------------------------------------------------
    // Литералы, переменные и функции
    // ------------------------------------------------------------------

    private String parseString() {
        char quote = text.charAt(pos++);
        StringBuilder sb = new StringBuilder();
        while (pos < text.length() && text.charAt(pos) != quote) {
            sb.append(text.charAt(pos++));
        }
        if (pos >= text.length()) {
            throw new ScenarioException("Формула «" + text + "»: не закрыта кавычка строки");
        }
        pos++;
        return sb.toString();
    }

    private BigDecimal parseNumber() {
        int start = pos;
        boolean seenSeparator = false;
        while (pos < text.length()) {
            char c = text.charAt(pos);
            if (Character.isDigit(c)) {
                pos++;
            } else if ((c == '.' || c == ',') && !seenSeparator
                    && pos + 1 < text.length() && Character.isDigit(text.charAt(pos + 1))) {
                seenSeparator = true;
                pos++;
            } else {
                break;
            }
        }
        String raw = text.substring(start, pos).replace(',', '.');
        try {
            return new BigDecimal(raw);
        } catch (NumberFormatException e) {
            throw new ScenarioException("Формула «" + text + "»: некорректное число «" + raw + "»");
        }
    }

    private Object parseIdentOrFunction() {
        int start = pos;
        while (pos < text.length()) {
            char c = text.charAt(pos);
            if (Character.isLetterOrDigit(c) || c == '_') {
                pos++;
            } else {
                break;
            }
        }
        String name = text.substring(start, pos);
        skipSpaces();
        if (match('(')) {
            return callFunction(name.toUpperCase(Locale.ROOT).replace('Ё', 'Е'));
        }
        Object value = ctx.variable(name);
        if (value == null) {
            throw new ScenarioException("Формула «" + text + "»: неизвестная переменная «" + name + "»");
        }
        return value;
    }

    /**
     * Вызов функции: специальные формы (ЗНАЧ, ВПР) либо разбор аргументов и применение.
     */
    private Object callFunction(String fn) {
        // ЗНАЧ(имя; по_умолчанию): первый аргумент — имя, не вычисляется
        if ("ЗНАЧ".equals(fn) || "VAL".equals(fn)) {
            return callVal();
        }
        // ВПР(таблица; ключ_колонка; выражение_ключа; колонка_значения)
        if ("ВПР".equals(fn) || "VLOOKUP".equals(fn)) {
            return callVlookup();
        }
        return applyFunction(fn, parseArgs(fn));
    }

    /**
     * Разбирает аргументы функции (через «;» до закрывающей скобки).
     * Для агрегатных функций аргумент, являющийся чистым именем существующей
     * колонки, разворачивается в значения колонки по всем строкам
     * (как диапазон в Excel).
     */
    private List<Object> parseArgs(String fn) {
        boolean aggregate = AGGREGATES.contains(fn);
        List<Object> args = new ArrayList<>();
        skipSpaces();
        if (match(')')) {
            return args;
        }
        boolean more = true;
        while (more) {
            parseArgument(aggregate, args);
            skipSpaces();
            if (match(')')) {
                more = false;
            } else if (!match(';')) {
                throw new ScenarioException("Формула «" + text + "»: в функции " + fn
                        + " ожидался разделитель «;» или закрывающая скобка");
            }
        }
        return args;
    }

    /**
     * Один аргумент: для агрегатов чистое имя колонки разворачивается в её значения.
     */
    private void parseArgument(boolean aggregate, List<Object> args) {
        skipSpaces();
        if (aggregate && tryColumnArgument(args)) {
            return;
        }
        args.add(parseComparison());
    }

    /**
     * Попытка распознать «чистое имя колонки»; при промахе позиция
     * разбора откатывается и аргумент разбирается как выражение.
     */
    private boolean tryColumnArgument(List<Object> args) {
        int save = pos;
        String ident = peekPureIdentifierArg();
        if (ident == null) {
            return false;
        }
        List<Object> col = ctx.column(ident);
        if (col == null) {
            pos = save;
            return false;
        }
        args.addAll(colNumbers(col));
        return true;
    }

    /**
     * Если следующий аргумент — идентификатор целиком (до «;» или «)»),
     * потребляет его и возвращает имя; иначе возвращает null, не сдвигая позицию.
     */
    private String peekPureIdentifierArg() {
        int save = pos;
        skipSpaces();
        int start = pos;
        while (pos < text.length()) {
            char c = text.charAt(pos);
            if (Character.isLetterOrDigit(c) || c == '_') {
                pos++;
            } else {
                break;
            }
        }
        if (pos > start) {
            int after = pos;
            skipSpaces();
            if (pos < text.length() && (text.charAt(pos) == ';' || text.charAt(pos) == ')')) {
                pos = after;
                return text.substring(start, after);
            }
        }
        pos = save;
        return null;
    }

    private Object callVal() {
        skipSpaces();
        int start = pos;
        while (pos < text.length()
                && (Character.isLetterOrDigit(text.charAt(pos)) || text.charAt(pos) == '_')) {
            pos++;
        }
        String name = text.substring(start, pos);
        skipSpaces();
        if (!match(';')) {
            throw new ScenarioException("Формула «" + text + "»: ЗНАЧ(имя; по_умолчанию) — "
                    + "нужно значение по умолчанию");
        }
        Object fallback = parseComparison();
        skipSpaces();
        if (!match(')')) {
            throw new ScenarioException("Формула «" + text + "»: не закрыта скобка функции ЗНАЧ");
        }
        Object value = ctx.variable(name);
        if (value == null) {
            ctx.warn("показатель «" + name.replace('_', ' ') + "» отсутствует — принято значение "
                    + fallback + ", требуется ручная проверка");
            return fallback;
        }
        return value;
    }

    /**
     * ВПР(таблица; ключ_колонка; выражение_ключа; колонка_значения) — поиск
     * по другой таблице входа, как ВПР в Excel. Имена таблицы и колонок —
     * идентификаторы (не вычисляются), ключ — любое выражение.
     */
    private Object callVlookup() {
        String table = parseIdentArg("ВПР", "таблица");
        expectSemicolon("ВПР");
        String keyColumn = parseIdentArg("ВПР", "ключевая колонка");
        expectSemicolon("ВПР");
        Object keyValue = parseComparison();
        skipSpaces();
        expectSemicolon("ВПР");
        String valueColumn = parseIdentArg("ВПР", "колонка значения");
        skipSpaces();
        if (!match(')')) {
            throw new ScenarioException("Формула «" + text + "»: не закрыта скобка функции ВПР");
        }
        Object value = ctx.lookup(table, keyColumn, keyValue, valueColumn);
        if (value == null) {
            throw new ScenarioException("Формула «" + text + "»: ВПР не нашла в таблице «" + table
                    + "» строку с " + keyColumn + " = «" + keyValue + "» (колонка «" + valueColumn + "»)");
        }
        return value;
    }

    private String parseIdentArg(String fn, String what) {
        skipSpaces();
        int start = pos;
        while (pos < text.length()
                && (Character.isLetterOrDigit(text.charAt(pos)) || text.charAt(pos) == '_')) {
            pos++;
        }
        if (pos == start) {
            throw new ScenarioException("Формула «" + text + "»: в функции " + fn
                    + " ожидалось имя (" + what + ")");
        }
        return text.substring(start, pos);
    }

    private void expectSemicolon(String fn) {
        skipSpaces();
        if (!match(';')) {
            throw new ScenarioException("Формула «" + text + "»: в функции " + fn
                    + " ожидался разделитель «;»");
        }
    }

    private Object applyFunction(String fn, List<Object> args) {
        if (AGGREGATES.contains(fn)) {
            return applyAggregate(fn, args);
        }
        return switch (fn) {
            case "ЕСЛИ", "IF" -> applyIf(args);
            case "ОКРУГЛ", "ROUND" -> applyRound(args);
            case "МОДУЛЬ", "ABS" -> applyAbs(args);
            case "НЕ", "NOT" -> applyNot(args);
            case "И", "AND" -> applyAnd(args);
            case "ИЛИ", "OR" -> applyOr(args);
            case "СОДЕРЖИТ", "CONTAINS" -> applyContains(args);
            default -> throw new ScenarioException("Формула «" + text + "»: неизвестная функция «" + fn
                    + "». Доступны: ЕСЛИ, МИН, МАКС, СУММ, СРЗНАЧ, КОЛ, ОКРУГЛ, МОДУЛЬ, И, ИЛИ, НЕ, "
                    + "СОДЕРЖИТ, ЗНАЧ (и английские синонимы)");
        };
    }

    private Object applyIf(List<Object> args) {
        requireArgs("ЕСЛИ", args, 3);
        return toNumber(args.get(0), text).signum() != 0 ? args.get(1) : args.get(2);
    }

    private Object applyRound(List<Object> args) {
        if (args.size() != 1 && args.size() != 2) {
            throw new ScenarioException("Формула «" + text + "»: ОКРУГЛ(число; знаков)");
        }
        int digits = args.size() == 2 ? toNumber(args.get(1), text).intValue() : 0;
        if (digits < MIN_ROUND_DIGITS || digits > MAX_ROUND_DIGITS) {
            throw new ScenarioException("Формула «" + text + "»: число знаков ОКРУГЛ должно быть от "
                    + MIN_ROUND_DIGITS + " до " + MAX_ROUND_DIGITS + ", получено " + digits);
        }
        return toNumber(args.get(0), text).setScale(digits, RoundingMode.HALF_UP);
    }

    private Object applyAbs(List<Object> args) {
        requireArgs("МОДУЛЬ", args, 1);
        return toNumber(args.get(0), text).abs();
    }

    private Object applyNot(List<Object> args) {
        requireArgs("НЕ", args, 1);
        return toNumber(args.get(0), text).signum() == 0 ? BigDecimal.ONE : BigDecimal.ZERO;
    }

    private Object applyAnd(List<Object> args) {
        boolean all = args.stream().allMatch(a -> toNumber(a, text).signum() != 0);
        return all && !args.isEmpty() ? BigDecimal.ONE : BigDecimal.ZERO;
    }

    private Object applyOr(List<Object> args) {
        boolean any = args.stream().anyMatch(a -> toNumber(a, text).signum() != 0);
        return any ? BigDecimal.ONE : BigDecimal.ZERO;
    }

    private Object applyContains(List<Object> args) {
        requireArgs("СОДЕРЖИТ", args, 2);
        String haystack = String.valueOf(args.get(0)).toLowerCase(Locale.ROOT);
        String needle = String.valueOf(args.get(1)).toLowerCase(Locale.ROOT);
        return haystack.contains(needle) ? BigDecimal.ONE : BigDecimal.ZERO;
    }

    /**
     * Агрегатные функции (МИН/МАКС/СУММ/СРЗНАЧ/КОЛ) — по списку чисел из аргументов.
     */
    private Object applyAggregate(String fn, List<Object> args) {
        switch (fn) {
            case "МИН", "MIN" -> {
                return numbers(args).stream().min(BigDecimal::compareTo)
                        .orElseThrow(() -> emptyArgs(fn));
            }
            case "МАКС", "MAX" -> {
                return numbers(args).stream().max(BigDecimal::compareTo)
                        .orElseThrow(() -> emptyArgs(fn));
            }
            case "СУММ", "SUM" -> {
                return numbers(args).stream().reduce(BigDecimal.ZERO, (a, b) -> a.add(b, MC));
            }
            case "СРЗНАЧ", "AVG" -> {
                List<BigDecimal> nums = numbers(args);
                if (nums.isEmpty()) {
                    throw emptyArgs(fn);
                }
                BigDecimal sum = nums.stream().reduce(BigDecimal.ZERO, (a, b) -> a.add(b, MC));
                return sum.divide(new BigDecimal(nums.size()), MC);
            }
            // КОЛ/COUNT — количество числовых значений
            default -> {
                return new BigDecimal(numbers(args).size());
            }
        }
    }

    private void requireArgs(String fn, List<Object> args, int n) {
        if (args.size() != n) {
            throw new ScenarioException("Формула «" + text + "»: функция " + fn + " ожидает "
                    + n + " аргумент(а), получено " + args.size());
        }
    }

    private ScenarioException emptyArgs(String fn) {
        return new ScenarioException("Формула «" + text + "»: функции " + fn + " не передано "
                + "ни одного числа");
    }

    private List<BigDecimal> numbers(List<Object> args) {
        List<BigDecimal> result = new ArrayList<>();
        for (Object a : args) {
            if (a == null || Boolean.TRUE.equals(a)) {
                continue;
            }
            result.add(toNumber(a, text));
        }
        return result;
    }

    /**
     * Числовые значения колонки; пропуски (null) и нечисловые строки отбрасываются.
     */
    private static List<Object> colNumbers(List<Object> col) {
        List<Object> result = new ArrayList<>();
        for (Object v : col) {
            BigDecimal n = tryNumber(v);
            if (n != null) {
                result.add(n);
            }
        }
        return result;
    }

    private static BigDecimal tryNumber(Object v) {
        if (v instanceof BigDecimal b) {
            return b;
        }
        if (v instanceof Number n) {
            return new BigDecimal(n.toString());
        }
        if (v instanceof String s) {
            try {
                return new BigDecimal(s.trim().replace(" ", "").replace(",", "."));
            } catch (NumberFormatException e) {
                return null;
            }
        }
        return null;
    }

    private static BigDecimal toNumber(Object v, String expr) {
        BigDecimal n = tryNumber(v);
        if (n == null) {
            throw new ScenarioException("Формула «" + expr + "»: значение «" + v
                    + "» не является числом");
        }
        return n;
    }

    private void skipSpaces() {
        while (pos < text.length() && Character.isWhitespace(text.charAt(pos))) {
            pos++;
        }
    }

    private boolean match(char c) {
        if (pos < text.length() && text.charAt(pos) == c) {
            pos++;
            return true;
        }
        return false;
    }
}
