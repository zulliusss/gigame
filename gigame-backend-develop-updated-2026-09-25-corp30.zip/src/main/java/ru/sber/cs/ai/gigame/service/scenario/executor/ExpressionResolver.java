package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Выражения в промптах узлов — адресный доступ к выходам конкретных узлов:
 * <ul>
 *   <li>{@code {{output:Метка узла}}} — полный текст выхода узла с такой меткой (или id);</li>
 *   <li>{@code {{json:Метка узла:путь.к.полю}}} — значение поля из JSON-блока в выходе узла;
 *       путь — через точку, элементы массивов — {@code поле[0]}.</li>
 * </ul>
 * Если узел или поле не найдены, в текст подставляется явная пометка об ошибке —
 * автор сценария увидит её в результате шага.
 * <p>
 * Значение выражения в промпте ({@link #resolve}) усекается до предела текста документа
 * ({@code app.chat.document-char-limit}, см. {@link #setValueLimit}) с маркером — иначе
 * {@code {{output:…}}} обходил лимит и уносил в модель выход любого размера. Кодовые
 * потребители (операции узла «Трансформация») читают выход без усечения — {@link #resolveFull}.
 */
@Slf4j
public final class ExpressionResolver {

    /** Предел значения выражения в промпте по умолчанию (как {@code app.chat.document-char-limit}). */
    public static final int DEFAULT_VALUE_LIMIT = 200_000;

    /** Маркер усечения значения выражения. */
    static final String TRUNCATED_MARKER = "\n[... значение выражения обрезано ...]";

    private static final Pattern EXPR = Pattern.compile(
            "\\{\\{\\s*(output|json)\\s*:\\s*([^:}]+?)\\s*(?::\\s*([^}]+?)\\s*)?}}");

    /** Токен пути: имя поля и индексы; притяжательные квантификаторы — без бэктрекинга. */
    private static final Pattern PATH_TOKEN = Pattern.compile("^([^\\[\\]]*+)((?:\\[\\d+])*+)$");

    private static final Pattern PATH_INDEX = Pattern.compile("\\[(\\d+)]");

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static volatile int valueLimit = DEFAULT_VALUE_LIMIT;

    private ExpressionResolver() {
    }

    /**
     * Ставит предел значения выражения в промпте (настройка {@code app.chat.document-char-limit}).
     *
     * @param limit предел в символах (меньше 1 — значение по умолчанию)
     */
    public static void setValueLimit(int limit) {
        valueLimit = limit < 1 ? DEFAULT_VALUE_LIMIT : limit;
    }

    /**
     * Есть ли в шаблоне выражения.
     *
     * @param template текст промпта
     * @return true, если найдено хотя бы одно выражение
     */
    public static boolean hasExpressions(String template) {
        log.debug("[{}] hasExpressions, templateChars={}",
                CurrentUserHolder.getCurrentUser(), template == null ? 0 : template.length());
        return template != null && EXPR.matcher(template).find();
    }

    /**
     * Подставляет значения выражений в шаблон.
     *
     * @param template текст промпта с выражениями
     * @param nodeMap  карта узлов графа (id → узел)
     * @return текст с подставленными значениями
     */
    public static String resolve(String template, Map<String, ScenarioRunNode> nodeMap) {
        return resolve(template, nodeMap, valueLimit);
    }

    /**
     * Подставляет значения выражений без усечения — для кода, читающего выход узла
     * (массивы находок, тексты разделов), а не для промпта модели.
     *
     * @param template текст с выражениями
     * @param nodeMap  карта узлов графа (id → узел)
     * @return текст с подставленными значениями
     */
    public static String resolveFull(String template, Map<String, ScenarioRunNode> nodeMap) {
        return resolve(template, nodeMap, Integer.MAX_VALUE);
    }

    private static String resolve(String template, Map<String, ScenarioRunNode> nodeMap, int limit) {
        log.info("[{}] resolve, templateChars={}, nodes={}",
                CurrentUserHolder.getCurrentUser(), template == null ? 0 : template.length(),
                nodeMap == null ? 0 : nodeMap.size());
        Matcher m = EXPR.matcher(template);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String kind = m.group(1);
            String label = m.group(2).trim();
            String path = m.group(3) == null ? null : m.group(3).trim();
            m.appendReplacement(sb, Matcher.quoteReplacement(evaluate(kind, label, path, nodeMap, limit)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /**
     * Результат подстановки в пределах бюджета.
     *
     * @param text  текст с подставленными значениями
     * @param total суммарная длина значений выражений до усечения по бюджету
     * @param kept  суммарная длина значений после усечения (без маркеров)
     */
    public record Resolved(String text, int total, int kept) {
    }

    /**
     * Подставляет значения выражений в пределах общего бюджета (задание агента): текст шаблона вне выражений
     * сохраняется целиком, значения делят остаток бюджета — короткие входят целиком, излишек поровну достаётся
     * длинным ({@link #fairCap}); усечённое значение получает маркер {@link #TRUNCATED_MARKER}.
     *
     * @param template текст промпта с выражениями
     * @param nodeMap  карта узлов графа (id → узел)
     * @param budget   бюджет символов на весь текст
     * @return текст и длины значений до и после усечения
     */
    public static Resolved resolveWithin(String template, Map<String, ScenarioRunNode> nodeMap, int budget) {
        Matcher m = EXPR.matcher(template);
        List<String> values = new ArrayList<>();
        int instruction = template.length();
        while (m.find()) {
            String path = m.group(3) == null ? null : m.group(3).trim();
            values.add(evaluate(m.group(1), m.group(2).trim(), path, nodeMap, valueLimit));
            instruction -= m.end() - m.start();
        }
        int cap = fairCap(values, Math.max(0, budget - instruction));
        StringBuilder sb = new StringBuilder();
        int total = 0;
        int kept = 0;
        m.reset();
        for (int i = 0; m.find(); i++) {
            String value = values.get(i);
            total += value.length();
            kept += Math.min(value.length(), cap);
            String cut = value.length() > cap ? value.substring(0, cap) + TRUNCATED_MARKER : value;
            m.appendReplacement(sb, Matcher.quoteReplacement(cut));
        }
        m.appendTail(sb);
        return new Resolved(sb.toString(), total, kept);
    }

    /**
     * Предел длины одного значения при общем бюджете: значения по возрастанию длины, каждое короче равной доли
     * остатка входит целиком.
     *
     * @param values значения выражений
     * @param budget бюджет символов на все значения
     * @return предел длины значения ({@link Integer#MAX_VALUE} — все входят целиком)
     */
    static int fairCap(List<String> values, int budget) {
        List<Integer> lengths = values.stream().map(String::length).sorted().toList();
        int remaining = budget;
        for (int i = 0; i < lengths.size(); i++) {
            int share = remaining / (lengths.size() - i);
            if (lengths.get(i) > share) {
                return share;
            }
            remaining -= lengths.get(i);
        }
        return Integer.MAX_VALUE;
    }

    /**
     * Узлы, чей выход подставлен в шаблон целиком выражением {@code {{output:…}}} ({@code {{json:…}}} — только поле,
     * не в счёт): их вклад во вход узла не нужно добавлять в задание повторно.
     *
     * @param template текст промпта
     * @param nodeMap  карта узлов графа (id → узел)
     * @return id найденных узлов
     */
    public static Set<String> outputSources(String template, Map<String, ScenarioRunNode> nodeMap) {
        Set<String> ids = new HashSet<>();
        Matcher m = EXPR.matcher(template == null ? "" : template);
        while (m.find()) {
            ScenarioRunNode source = "output".equals(m.group(1)) ? findNode(m.group(2).trim(), nodeMap) : null;
            if (source != null) {
                ids.add(source.getId());
            }
        }
        return ids;
    }

    /**
     * Результат подстановки с выносом длинных значений из инструкции (промпт обычного узла, corp23): короткие
     * значения остаются в инструкции, длинные (выход узла) заменяются ссылкой, а их текст — отдельными блоками
     * для делимого контекста.
     *
     * @param text   инструкция с подставленными короткими значениями и ссылками на вынесенные
     * @param blocks блоки вынесенных значений (заголовок и текст) по порядку выражений
     * @param total  суммарная длина значений выражений до усечения
     * @param kept   суммарная длина значений после усечения (без маркеров)
     */
    public record Detached(String text, List<String> blocks, int total, int kept) {
    }

    /**
     * Подставляет выражения, вынося длинные значения в контекст: значение не длиннее {@code inlineLimit} остаётся
     * в инструкции, длиннее — уходит блоком «=== ЗНАЧЕНИЕ ВЫРАЖЕНИЯ N (output:Метка) ===», а в инструкции остаётся
     * ссылка на блок. Инструкция остаётся короткой и повторяется в каждой части при делении контекста, а значение
     * делится вместе с документами — раньше подстановка делала инструкцию неделимой, и 422 не лечился делением.
     * Значение длиннее {@code valueCap} усекается с маркером {@link #TRUNCATED_MARKER} (режим обрезки).
     *
     * @param template    текст промпта с выражениями
     * @param nodeMap     карта узлов графа (id → узел)
     * @param inlineLimit предел значения, остающегося в инструкции
     * @param valueCap    предел длины одного значения ({@link Integer#MAX_VALUE} — без усечения)
     * @return инструкция, блоки вынесенных значений и длины значений до и после усечения
     */
    public static Detached resolveDetaching(String template, Map<String, ScenarioRunNode> nodeMap,
                                            int inlineLimit, int valueCap) {
        Matcher m = EXPR.matcher(template);
        StringBuilder sb = new StringBuilder();
        List<String> blocks = new ArrayList<>();
        int total = 0;
        int kept = 0;
        while (m.find()) {
            String path = m.group(3) == null ? null : m.group(3).trim();
            String value = rawValue(m.group(1), m.group(2).trim(), path, nodeMap);
            total += value.length();
            kept += Math.min(value.length(), valueCap);
            String cut = value.length() > valueCap ? value.substring(0, valueCap) + TRUNCATED_MARKER : value;
            String replacement = cut;
            if (value.length() > inlineLimit) {
                int number = blocks.size() + 1;
                String name = m.group(1) + ":" + m.group(2).trim() + (path == null ? "" : ":" + path);
                blocks.add("=== ЗНАЧЕНИЕ ВЫРАЖЕНИЯ " + number + " (" + name + ") ===\n" + cut);
                replacement = "[значение выражения " + number + " (" + name + ") — в контексте ниже, блок «ЗНАЧЕНИЕ ВЫРАЖЕНИЯ "
                        + number + "»]";
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(replacement));
        }
        m.appendTail(sb);
        return new Detached(sb.toString(), blocks, total, kept);
    }

    private static String evaluate(String kind, String label, String path,
                                   Map<String, ScenarioRunNode> nodeMap, int limit) {
        String value = rawValue(kind, label, path, nodeMap);
        return value.length() > limit ? value.substring(0, limit) + TRUNCATED_MARKER : value;
    }

    /** Значение выражения без усечения: выход узла либо поле его JSON; узел не найден — пометка об ошибке. */
    private static String rawValue(String kind, String label, String path, Map<String, ScenarioRunNode> nodeMap) {
        ScenarioRunNode src = findNode(label, nodeMap);
        if (src == null) {
            return "[выражение: узел «" + label + "» не найден]";
        }
        String output = String.join("\n\n", src.getOutput());
        return "output".equals(kind) ? output : jsonValue(output, path, label);
    }

    private static String jsonValue(String output, String path, String label) {
        if (path == null || path.isBlank()) {
            return "[выражение json: не указан путь к полю]";
        }
        return extractJsonPath(output, path, label);
    }

    private static ScenarioRunNode findNode(String label, Map<String, ScenarioRunNode> nodeMap) {
        ScenarioRunNode byId = nodeMap.get(label);
        if (byId != null) {
            return byId;
        }
        for (ScenarioRunNode n : nodeMap.values()) {
            if (label.equalsIgnoreCase(String.valueOf(n.getLabel()).trim())) {
                return n;
            }
        }
        return null;
    }

    /**
     * Извлекает значение по пути из JSON-блока в произвольном тексте
     * (используется также узлом «Трансформация»).
     *
     * @param text текст с JSON-блоком
     * @param path путь через точку, элементы массивов — {@code поле[0]}
     * @return значение либо пометка об ошибке
     */
    public static String extractJsonPathFromText(String text, String path) {
        log.debug("[{}] extractJsonPath, path='{}', textChars={}",
                CurrentUserHolder.getCurrentUser(), path, text == null ? 0 : text.length());
        return extractJsonPath(text, path, "«текст»");
    }

    /**
     * Извлекает значение по пути из JSON-блока в тексте выхода узла.
     * Берётся первый разбираемый JSON-объект/массив в тексте (см. {@link #findJson}):
     * кандидаты перебираются с начала текста, неразбираемые пропускаются.
     */
    private static String extractJsonPath(String output, String path, String label) {
        Object root = findJson(output);
        if (root == null) {
            return "[выражение json: в выходе узла «" + label + "» нет разбираемого JSON]";
        }
        Object current = root;
        for (String rawToken : path.split("\\.")) {
            current = step(current, rawToken.trim(), path);
            if (current instanceof PathError error) {
                return error.message();
            }
        }
        return stringify(current);
    }

    /** Пометка об ошибке разбора пути (отличает ошибку от легитимного значения). */
    private record PathError(String message) {
    }

    /** Один шаг пути: поле токена (если есть), затем индексы массивов. */
    private static Object step(Object current, String token, String path) {
        Matcher idx = PATH_TOKEN.matcher(token);
        if (!idx.matches()) {
            return new PathError("[выражение json: некорректный путь «" + path + "»]");
        }
        Object value = current;
        String field = idx.group(1);
        if (!field.isEmpty()) {
            if (!(value instanceof Map<?, ?> map) || !map.containsKey(field)) {
                return new PathError("[выражение json: поле «" + field + "» не найдено (путь «"
                        + path + "»)]");
            }
            value = map.get(field);
        }
        return applyIndexes(value, idx.group(2), path);
    }

    /** Применяет цепочку индексов «[0][1]…» к значению. */
    private static Object applyIndexes(Object value, String indexes, String path) {
        Object current = value;
        Matcher arr = PATH_INDEX.matcher(indexes);
        while (arr.find()) {
            int i = Integer.parseInt(arr.group(1));
            if (!(current instanceof List<?> list) || i >= list.size()) {
                return new PathError("[выражение json: индекс [" + i + "] вне диапазона (путь «"
                        + path + "»)]");
            }
            current = list.get(i);
        }
        return current;
    }

    private static Object findJson(String text) {
        // первый разбираемый блок: ```json```, весь текст, затем сбалансированные блоки с начала
        LlmJson.Parsed block = LlmJson.first(text, LlmJson.ANY).first();
        return block == null ? null : block.value();
    }

    private static String stringify(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String s) {
            return s;
        }
        if (value instanceof Map || value instanceof List) {
            try {
                return MAPPER.writeValueAsString(value);
            } catch (Exception e) {
                return String.valueOf(value);
            }
        }
        return String.valueOf(value);
    }
}
