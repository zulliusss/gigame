package ru.sber.cs.ai.gigame.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Кэш вердиктов фильтра GigaFilter по хэшу фрагмента (LRU): одни и те же документы уходят в модель многократно
 * (циклы Формы 3, несколько узлов, дочитывание и раунды агента пересылают историю) — повторный фрагмент не
 * проверяется заново. Хранятся только определённые вердикты (ответ 200 с is_profane); ключ — SHA-256 роли и текста,
 * сам текст в памяти не держится.
 */
final class GigaFilterCache {

    private final Map<String, Boolean> verdicts;

    /**
     * Кэш на заданное число фрагментов.
     *
     * @param capacity предел числа вердиктов (меньше 1 — 1)
     */
    GigaFilterCache(int capacity) {
        int max = Math.max(1, capacity);
        this.verdicts = new LinkedHashMap<>(16, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, Boolean> eldest) {
                return size() > max;
            }
        };
    }

    /**
     * Вердикт фрагмента из кэша.
     *
     * @param key ключ {@link #key}
     * @return {@code true} — заблокирован, {@code false} — пропущен, {@code null} — нет в кэше
     */
    synchronized Boolean get(String key) {
        return verdicts.get(key);
    }

    /**
     * Запоминает вердикт фрагмента.
     *
     * @param key     ключ {@link #key}
     * @param profane фрагмент заблокирован
     */
    synchronized void put(String key, boolean profane) {
        verdicts.put(key, profane);
    }

    /**
     * Число вердиктов в кэше.
     *
     * @return размер кэша
     */
    synchronized int size() {
        return verdicts.size();
    }

    /**
     * Ключ фрагмента: SHA-256 роли и текста (hex).
     *
     * @param role роль сообщения проверки
     * @param text текст фрагмента
     * @return ключ кэша
     */
    static String key(String role, String text) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(String.valueOf(role).getBytes(StandardCharsets.UTF_8));
            digest.update((byte) '\n');
            return HexFormat.of().formatHex(digest.digest(String.valueOf(text).getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }
}
