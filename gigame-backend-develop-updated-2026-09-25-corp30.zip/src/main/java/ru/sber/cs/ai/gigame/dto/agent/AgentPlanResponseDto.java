package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.TextNode;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO плана из памяти планов агента для ответа {@code GET /api/agent/plans}.
 * <p>
 * Ключи в snake_case и лимиты — строго по схеме {@code AgentPlan} статической
 * спецификации: корп. шлюз SOWA отклоняет ответ с лишними ключами
 * (additionalProperties: false). Сущность JPA напрямую не отдаётся.
 *
 * @param id          идентификатор плана
 * @param scenarioId  сценарий
 * @param taskHash    SHA-256 нормализованного задания
 * @param taskPreview начало задания (до 1000 символов)
 * @param plan        JSON-массив пунктов плана (до 4000 символов)
 * @param uses        сколько раз план переиспользован (0..1000000)
 * @param createdAt   дата создания (UTC, микросекунды)
 * @param updatedAt   дата последнего обновления (UTC, микросекунды)
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        name = "AgentPlan",
        description = "Память планов агента. Проверенный чек-лист для задания",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentPlanResponseDto(
        @Schema(
                description = "Уникальный идентификатор плана",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Идентификатор сценария",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID scenarioId,

        @Schema(
                description = "SHA-256 нормализованного задания",
                maxLength = 64,
                pattern = "^[0-9a-fA-F]{64}$"
        )
        String taskHash,

        @Schema(
                description = "Начало задания — для страницы памяти",
                maxLength = 1000,
                pattern = "^[\\w\\W]{0,1000}$"
        )
        String taskPreview,

        @Schema(
                description = "JSON-массив пунктов плана",
                maxLength = 4000,
                pattern = "^[\\w\\W]{0,4000}$"
        )
        String plan,

        @Schema(
                description = "Сколько раз план переиспользован",
                minimum = "0",
                maximum = "1000000"
        )
        Integer uses,

        @Schema(
                description = "Дата и время создания плана",
                maxLength = 32
        )
        OffsetDateTime createdAt,

        @Schema(
                description = "Дата и время последнего обновления",
                maxLength = 32
        )
        OffsetDateTime updatedAt
) {

    /**
     * maxLength поля task_preview.
     */
    public static final int TASK_PREVIEW_MAX_LENGTH = 1000;

    /**
     * maxLength поля plan.
     */
    public static final int PLAN_MAX_LENGTH = 4000;

    /**
     * maximum поля uses.
     */
    public static final int USES_MAX = 1_000_000;

    /**
     * Разбор JSON-массива пунктов плана при усечении по пунктам.
     */
    private static final ObjectMapper PLAN_MAPPER = new ObjectMapper();

    /**
     * Преобразует сущность {@link AgentPlan} в DTO, приводя значения к лимитам
     * схемы: длинные тексты усекаются, даты — в UTC с точностью до микросекунд.
     *
     * @param entity сущность плана
     * @return DTO в пределах схемы
     */
    public static AgentPlanResponseDto from(AgentPlan entity) {
        return new AgentPlanResponseDto(
                entity.getId(),
                entity.getScenarioId(),
                entity.getTaskHash(),
                SchemaLimitUtils.clip(entity.getTaskPreview(), TASK_PREVIEW_MAX_LENGTH),
                limitPlan(entity.getPlan()),
                entity.getUses() == null ? null : SchemaLimitUtils.clamp(entity.getUses(), 0, USES_MAX),
                SchemaLimitUtils.utcMicros(entity.getCreatedAt()),
                SchemaLimitUtils.utcMicros(entity.getUpdatedAt())
        );
    }

    /**
     * План не длиннее {@link #PLAN_MAX_LENGTH}. JSON-массив пунктов усекается
     * отбрасыванием пунктов с конца, пока сериализация не уложится в лимит, —
     * страница памяти разбирает план как JSON и показывает нумерованный список.
     * Если пункты отброшены, последним элементом идёт маркер
     * «…ещё N пункт(ов) не показано — план в памяти хранится полностью».
     * Если не помещается даже первый пункт, он усекается с многоточием — массив
     * не бывает пустым. Строка, не являющаяся JSON-массивом, усекается с многоточием.
     *
     * @param plan план из БД (может быть {@code null})
     * @return план в пределах схемы; {@code null} и короткие значения — как есть
     */
    static String limitPlan(String plan) {
        if (plan == null || plan.length() <= PLAN_MAX_LENGTH) {
            return plan;
        }
        JsonNode node = readJsonOrNull(plan);
        if (node == null || !node.isArray()) {
            return SchemaLimitUtils.clip(plan, PLAN_MAX_LENGTH);
        }
        ArrayNode items = (ArrayNode) node;
        String json = items.toString();
        if (json.length() <= PLAN_MAX_LENGTH) {
            return json;
        }
        int kept = keptItemsCount(items);
        return kept > 0 ? keptItemsWithMarker(items, kept) : clippedFirstItem(items);
    }

    /**
     * Сколько первых пунктов помещается в лимит вместе с маркером отброшенных.
     *
     * @param items пункты плана, сериализация которых длиннее лимита
     * @return число первых пунктов (0 — не помещается даже первый)
     */
    private static int keptItemsCount(ArrayNode items) {
        int total = items.size();
        // «[» и «]»
        int length = 2;
        int kept = 0;
        for (int i = 0; i < total - 1; i++) {
            // пункт и запятая после него
            length += items.get(i).toString().length() + 1;
            if (length + TextNode.valueOf(droppedMarker(total - i - 1)).toString().length() > PLAN_MAX_LENGTH) {
                break;
            }
            kept = i + 1;
        }
        return kept;
    }

    /**
     * Первые пункты плана и маркер отброшенных последним элементом.
     *
     * @param items пункты плана
     * @param kept  число сохраняемых первых пунктов
     * @return JSON-массив
     */
    private static String keptItemsWithMarker(ArrayNode items, int kept) {
        ArrayNode limited = PLAN_MAPPER.createArrayNode();
        for (int i = 0; i < kept; i++) {
            limited.add(items.get(i));
        }
        limited.add(droppedMarker(items.size() - kept));
        return limited.toString();
    }

    /**
     * Первый пункт, усечённый так, чтобы сериализация (с маркером остальных
     * пунктов, если они есть) уложилась в лимит: экранирование в JSON удлиняет
     * текст, поэтому наибольшая подходящая длина текста ищется двоичным поиском
     * (пустой текст помещается всегда).
     *
     * @param items пункты плана (первый не помещается целиком)
     * @return JSON-массив из усечённого первого пункта и маркера
     */
    private static String clippedFirstItem(ArrayNode items) {
        JsonNode first = items.get(0);
        String text = first.isTextual() ? first.asText() : first.toString();
        int dropped = items.size() - 1;
        int low = 0;
        int high = Math.min(text.length(), PLAN_MAX_LENGTH);
        while (low < high) {
            int mid = (low + high + 1) / 2;
            if (firstItemJson(text, mid, dropped).length() <= PLAN_MAX_LENGTH) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        return firstItemJson(text, low, dropped);
    }

    /**
     * JSON-массив из первого пункта, усечённого до бюджета, и маркера отброшенных.
     *
     * @param text    текст первого пункта
     * @param budget  максимальная длина текста пункта
     * @param dropped число отброшенных пунктов (0 — без маркера)
     * @return JSON-массив
     */
    private static String firstItemJson(String text, int budget, int dropped) {
        ArrayNode limited = PLAN_MAPPER.createArrayNode();
        limited.add(SchemaLimitUtils.clip(text, budget));
        if (dropped > 0) {
            limited.add(droppedMarker(dropped));
        }
        return limited.toString();
    }

    /**
     * Маркер отброшенных пунктов плана.
     *
     * @param dropped число отброшенных пунктов
     * @return текст маркера
     */
    private static String droppedMarker(int dropped) {
        return "…ещё " + dropped + " пункт(ов) не показано — план в памяти хранится полностью";
    }

    private static JsonNode readJsonOrNull(String text) {
        try {
            return PLAN_MAPPER.readTree(text);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
