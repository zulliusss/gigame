package ru.sber.cs.ai.gigame.exception;

/**
 * Исключение проверки данных запроса, не прошедших ограничения спецификации
 * (например, длина поля больше maxLength): ответ 422 с телом {@code ErrorResponse}.
 */
public class ValidationException extends ApplicationRuntimeException {

    public ValidationException(String message) {
        super(message, 422);
    }
}
