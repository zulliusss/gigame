package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ru.sber.cs.ai.gigame.model.ScenarioVersion;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ScenarioVersionRepository extends JpaRepository<ScenarioVersion, UUID> {

    List<ScenarioVersion> findByScenarioIdOrderByVersionNoDesc(UUID scenarioId);

    Optional<ScenarioVersion> findByScenarioIdAndVersionNo(UUID scenarioId, Integer versionNo);

    Optional<ScenarioVersion> findFirstByScenarioIdOrderByVersionNoDesc(UUID scenarioId);

    /**
     * Удаляет версии сценария с номером не больше указанного (хранится не больше
     * {@code app.scenario.versions-keep} последних версий: каждая версия — полный
     * снимок graph_data).
     *
     * @param scenarioId   идентификатор сценария
     * @param maxVersionNo наибольший удаляемый номер версии
     */
    @Modifying
    @Query("delete from ScenarioVersion v where v.scenarioId = :scenarioId and v.versionNo <= :maxVersionNo")
    void deleteOldVersions(@Param("scenarioId") UUID scenarioId, @Param("maxVersionNo") int maxVersionNo);
}
