package ru.sber.cs.ai.gigame.service;

import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Бюджет контекста агентного цикла (tool-цикл GigaChat) в символах.
 * <p>
 * Размер запроса оценивается по символам: тексты сообщений, аргументы вызовов инструментов, ответы инструментов и
 * описания инструментов; токены — символы / {@code app.agent.chars-per-token}. Бюджет — {@code app.agent.max-context-tokens}
 * × chars-per-token: история сверх него сжимается перед раундом ({@link #fit}) — ответы инструментов заменяются
 * пометкой, агент при необходимости вызывает инструмент снова. Задание агента (подстановки выражений и результаты
 * предыдущих шагов) получает долю {@link #TASK_SHARE} бюджета. Ответ модели 422 «context too long N, maximum allowed
 * context is M» разбирается {@link #overflow}.
 */
public final class AgentContextBudget {

    /** Доля бюджета контекста на задание агента. */
    public static final double TASK_SHARE = 0.6;
    /** Бюджет контекста по умолчанию, токенов ({@code app.agent.max-context-tokens}). */
    public static final int DEFAULT_MAX_CONTEXT_TOKENS = 100_000;
    /** Символов на токен по умолчанию ({@code app.agent.chars-per-token}). */
    public static final double DEFAULT_CHARS_PER_TOKEN = 3.0;
    /** Текст ответа модели о превышении окна: «context too long 142410, maximum allowed context is 130048». */
    private static final Pattern OVERFLOW = Pattern.compile(
            "context too long:?\\s*(\\d{1,9})?(?:\\s*,\\s*maximum allowed context is\\s*(\\d{1,9}))?", Pattern.CASE_INSENSITIVE);
    private static final int MAX_DEPTH = 8;

    private final int maxContextTokens;
    private final double charsPerToken;

    /**
     * Превышение окна модели по ответу 422.
     *
     * @param requested запрошено токенов (0 — не указано)
     * @param maximum   максимум контекста модели, токенов (0 — не указано)
     */
    public record Overflow(int requested, int maximum) {
    }

    /**
     * Бюджет по настройкам.
     *
     * @param maxContextTokens бюджет контекста, токенов (меньше 1 — умолчание)
     * @param charsPerToken    символов на токен (не больше 0 — умолчание)
     */
    public AgentContextBudget(int maxContextTokens, double charsPerToken) {
        this.maxContextTokens = maxContextTokens < 1 ? DEFAULT_MAX_CONTEXT_TOKENS : maxContextTokens;
        this.charsPerToken = charsPerToken > 0 ? charsPerToken : DEFAULT_CHARS_PER_TOKEN;
    }

    /**
     * Бюджет с умолчаниями (клиенты и узлы, созданные без Spring).
     *
     * @return бюджет 100000 токенов по 3 символа
     */
    public static AgentContextBudget defaults() {
        return new AgentContextBudget(DEFAULT_MAX_CONTEXT_TOKENS, DEFAULT_CHARS_PER_TOKEN);
    }

    /**
     * Бюджет контекста в символах.
     *
     * @return max-context-tokens × chars-per-token
     */
    public int maxChars() {
        return (int) Math.min(Integer.MAX_VALUE, maxContextTokens * charsPerToken);
    }

    /**
     * Доля бюджета на задание агента в символах.
     *
     * @return {@link #TASK_SHARE} × {@link #maxChars()}
     */
    public int taskChars() {
        return (int) (maxChars() * TASK_SHARE);
    }

    /**
     * Символов в заданном числе токенов по оценке chars-per-token (окно модели из 422 → предел задания).
     *
     * @param tokens число токенов
     * @return символов
     */
    public int chars(long tokens) {
        return (int) Math.min(Integer.MAX_VALUE, tokens * charsPerToken);
    }

    /**
     * Оценка числа токенов.
     *
     * @param chars символов
     * @return символы / chars-per-token с округлением вверх
     */
    public long tokens(long chars) {
        return (long) Math.ceil(chars / charsPerToken);
    }

    /**
     * Символов в истории агента: тексты сообщений, вызовы инструментов (имя и аргументы), ответы инструментов.
     *
     * @param history история tool-цикла
     * @return оценка размера в символах
     */
    public static long historyChars(List<Message> history) {
        long chars = 0;
        for (Message message : history) {
            chars += messageChars(message);
        }
        return chars;
    }

    /**
     * Символов в описаниях инструментов запроса: имя, описание и схема аргументов.
     *
     * @param tools инструменты агента (null — нет)
     * @return оценка размера в символах
     */
    public static long toolChars(List<ToolCallback> tools) {
        long chars = 0;
        for (ToolCallback tool : tools == null ? List.<ToolCallback>of() : tools) {
            ToolDefinition definition = tool.getToolDefinition();
            chars += length(definition.name()) + length(definition.description()) + length(definition.inputSchema());
        }
        return chars;
    }

    /**
     * Укладывает историю в бюджет: если история с описаниями инструментов больше {@link #maxChars()}, ответы
     * инструментов, начиная со старых и кроме последних {@code keepLast} сообщений с ответами, заменяются пометкой
     * {@link #marker}, пока превышение не снято.
     *
     * @param history   история tool-цикла (изменяется на месте)
     * @param toolChars символов в описаниях инструментов
     * @param keepLast  сколько последних сообщений с ответами инструментов не сжимать
     * @return число заменённых ответов инструментов (0 — история в бюджете или сжимать нечего)
     */
    public int fit(List<Message> history, long toolChars, int keepLast) {
        long excess = historyChars(history) + toolChars - maxChars();
        return excess <= 0 ? 0 : compress(history, keepLast, excess);
    }

    /**
     * Сжимает все ответы инструментов истории (повтор раунда после 422 «context too long»).
     *
     * @param history история tool-цикла (изменяется на месте)
     * @return число заменённых ответов (0 — сжимать нечего: ответы короткие или уже заменены пометкой)
     */
    public static int compressAll(List<Message> history) {
        return compress(history, 0, Long.MAX_VALUE);
    }

    /**
     * Пометка вместо ответа инструмента — JSON, как и сам ответ.
     *
     * @param name  имя инструмента
     * @param chars длина исходного ответа
     * @return {"note":"[результат инструмента усечён: имя, N симв. — …]"}
     */
    public static String marker(String name, int chars) {
        String safeName = String.valueOf(name).replace("\\", "").replace("\"", "'");
        return "{\"note\":\"[результат инструмента усечён: " + safeName + ", " + chars
                + " симв. — бюджет контекста агента; при необходимости вызови инструмент снова]\"}";
    }

    /**
     * Превышение окна модели в цепочке причин ошибки вызова.
     *
     * @param error исключение вызова модели
     * @return размеры превышения либо {@code null}, если ошибка — не «context too long»
     */
    public static Overflow overflow(Throwable error) {
        Throwable t = error;
        for (int depth = 0; t != null && depth < MAX_DEPTH; depth++) {
            Overflow found = parseOverflow(t.getMessage());
            if (found != null) {
                return found;
            }
            t = t.getCause() == t ? null : t.getCause();
        }
        return null;
    }

    /**
     * Разбор текста «context too long N, maximum allowed context is M».
     *
     * @param text текст ошибки
     * @return размеры (не указанные — 0) либо {@code null}, если текста превышения нет
     */
    public static Overflow parseOverflow(String text) {
        Matcher m = OVERFLOW.matcher(text == null ? "" : text);
        if (!m.find()) {
            return null;
        }
        return new Overflow(number(m.group(1)), number(m.group(2)));
    }

    private static int number(String digits) {
        return digits == null ? 0 : Integer.parseInt(digits);
    }

    private static long messageChars(Message message) {
        if (message instanceof ToolResponseMessage tool) {
            long chars = 0;
            for (ToolResponseMessage.ToolResponse response : tool.getResponses()) {
                chars += length(response.name()) + length(response.responseData());
            }
            return chars;
        }
        long chars = length(message.getText());
        if (message instanceof AssistantMessage assistant && assistant.hasToolCalls()) {
            for (AssistantMessage.ToolCall call : assistant.getToolCalls()) {
                chars += length(call.name()) + length(call.arguments());
            }
        }
        return chars;
    }

    private static int length(String text) {
        return text == null ? 0 : text.length();
    }

    /** Сжатие со старых сообщений с ответами инструментов, пока не снято превышение {@code excess}. */
    private static int compress(List<Message> history, int keepLast, long excess) {
        List<Integer> toolIndexes = new ArrayList<>();
        for (int i = 0; i < history.size(); i++) {
            if (history.get(i) instanceof ToolResponseMessage) {
                toolIndexes.add(i);
            }
        }
        int replaced = 0;
        long left = excess;
        for (int k = 0; k < toolIndexes.size() - keepLast && left > 0; k++) {
            int index = toolIndexes.get(k);
            long before = messageChars(history.get(index));
            List<ToolResponseMessage.ToolResponse> responses = new ArrayList<>();
            int count = replaceResponses((ToolResponseMessage) history.get(index), responses);
            if (count > 0) {
                ToolResponseMessage shrunk = ToolResponseMessage.builder().responses(responses).build();
                history.set(index, shrunk);
                left -= before - messageChars(shrunk);
                replaced += count;
            }
        }
        return replaced;
    }

    /**
     * Ответы сообщения с пометкой вместо каждого ответа, хотя бы вдвое длиннее пометки (пометки и короткие ответы
     * остаются как есть); возвращает число заменённых.
     */
    private static int replaceResponses(ToolResponseMessage message, List<ToolResponseMessage.ToolResponse> out) {
        int count = 0;
        for (ToolResponseMessage.ToolResponse response : message.getResponses()) {
            int chars = length(response.responseData());
            String marker = marker(response.name(), chars);
            if (chars >= 2 * marker.length()) {
                out.add(new ToolResponseMessage.ToolResponse(response.id(), response.name(), marker));
                count++;
            } else {
                out.add(response);
            }
        }
        return count;
    }
}
