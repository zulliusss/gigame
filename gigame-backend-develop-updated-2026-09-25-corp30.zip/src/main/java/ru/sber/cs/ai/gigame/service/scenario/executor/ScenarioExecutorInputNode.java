package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitProcessingProgressEvent;


@Slf4j
public class ScenarioExecutorInputNode extends AbstractScenarioExecutor {

    /** Начало текста документа, который не удалось разобрать или распознать (маркер вместо текста). */
    static final String MANUAL_CHECK_MARKER = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]";

    protected ScenarioExecutorInputNode(ScenarioRunNode node) {
        super(node);
    }

    @SuppressWarnings("java:S2973") // forEach body: both adds are semantically one operation
    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] InputNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        List<String> runDocList = new ArrayList<>();
        List<String> resultList = new ArrayList<>();
        var docMap = node.getGraph().getDocMap();
        if (docMap.isEmpty()) {
            return "";
        }
        docMap.forEach((key, value) -> {
            if (value.isWorkNote()) {
                // рабочие файлы агента (чекпойнты возобновлённого прогона) — не входные документы
                return;
            }
            runDocList.add(key);
            resultList.add("<<<" + key + ">>>\n" +
                    value.getText() + "\n<<<END_" + key + ">>>");
        });
        long empty = runDocList.stream()
                .map(docMap::get)
                .filter(ScenarioExecutorInputNode::isEmptyOrMarker)
                .count();
        if (empty > 0) {
            // в журнал прогона: часть комплекта не несёт текста (пустой файл, скан без OCR, нечитаемый файл)
            emitProcessingProgressEvent(sink, node, 0, 0,
                    "документов " + runDocList.size() + ", из них пустых/маркерных " + empty);
        }
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getDocList().addAll(runDocList);
        }
        return String.join("\n\n", resultList);
    }

    /**
     * Документ без полезного текста: пустой либо маркер ручной проверки вместо текста.
     *
     * @param doc документ прогона
     * @return {@code true}, если текста нет
     */
    static boolean isEmptyOrMarker(ScenarioRunDoc doc) {
        String text = doc == null ? null : doc.getText();
        return text == null || text.isBlank() || text.startsWith(MANUAL_CHECK_MARKER);
    }
}
