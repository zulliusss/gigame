package ru.sber.cs.ai.gigame.service;

import ru.sber.cs.ai.gigame.dto.kb.KBDetailResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;

import java.util.List;

/**
 * Преобразование сущностей баз знаний в DTO ответов. Строковые поля усекаются
 * до maxLength спецификации {@code openapi/gigame.yaml}, массивы — до maxItems,
 * даты приводятся к UTC: корпоративный шлюз SOWA блокирует несоответствующий
 * ответ целиком (одна длинная ошибка индексации закрывала просмотр всей базы).
 */
public class KBMapper {
    /** maxLength полей name и description (KBResponse, KBDetailResponse). */
    static final int NAME_MAX_LENGTH = 255;
    /** maxLength поля content_type (KBDocumentResponse, DocumentViewResponse). */
    static final int CONTENT_TYPE_MAX_LENGTH = 64;
    /** maxLength поля status (KBDocumentResponse). */
    static final int STATUS_MAX_LENGTH = 32;
    /** maxLength поля error_message (KBDocumentResponse). */
    static final int ERROR_MESSAGE_MAX_LENGTH = 255;
    /** maxItems массивов documents (KBDetailResponse) и списка баз знаний. */
    static final int MAX_ITEMS = 1000;

    private KBMapper() {
    }

    /**
     * Преобразует сущность KnowledgeBase в DTO для ответа клиенту.
     *
     * @param kb              сущность базы знаний
     * @param requesterUserId нормализованный идентификатор запрашивающего пользователя
     * @return DTO с метаданными базы знаний
     */
    static KBResponse toKBResponse(KnowledgeBase kb, String requesterUserId) {
        return new KBResponse(
                kb.getId(),
                SchemaLimitUtils.clip(kb.getName(), NAME_MAX_LENGTH),
                SchemaLimitUtils.clip(kb.getDescription(), NAME_MAX_LENGTH),
                kb.isShared(),
                requesterUserId.equals(kb.getUserId()),
                SchemaLimitUtils.utcMicros(kb.getCreatedAt()),
                SchemaLimitUtils.utcMicros(kb.getUpdatedAt())
        );
    }

    /**
     * Преобразует базу знаний и её документы в подробный DTO: не больше
     * {@link #MAX_ITEMS} документов.
     *
     * @param kb              сущность базы знаний
     * @param requesterUserId нормализованный идентификатор запрашивающего пользователя
     * @param documents       документы базы
     * @return DTO базы знаний с документами
     */
    static KBDetailResponse toKBDetailResponse(KnowledgeBase kb, String requesterUserId, List<KBDocumentResponse> documents) {
        return new KBDetailResponse(
                kb.getId(),
                SchemaLimitUtils.clip(kb.getName(), NAME_MAX_LENGTH),
                SchemaLimitUtils.clip(kb.getDescription(), NAME_MAX_LENGTH),
                kb.isShared(),
                requesterUserId.equals(kb.getUserId()),
                SchemaLimitUtils.utcMicros(kb.getCreatedAt()),
                SchemaLimitUtils.utcMicros(kb.getUpdatedAt()),
                SchemaLimitUtils.firstItems(documents, MAX_ITEMS)
        );
    }

    /**
     * Преобразует сущность KBDocument в DTO для ответа клиенту. Имя файла
     * приводится к pattern схемы (запрещённые символы — «_», не длиннее 255),
     * error_message и остальные строки — к maxLength.
     *
     * @param kbDoc сущность документа базы знаний
     * @return DTO с метаданными документа базы знаний
     */
    static KBDocumentResponse toKBDocumentResponse(KBDocument kbDoc) {
        return toKBDocumentResponse(kbDoc, kbDoc.getErrorMessage());
    }

    /**
     * DTO документа базы знаний с подменённым текстом error_message — для
     * предупреждения, которое не сохраняется в БД (повторная загрузка того же
     * файла пропущена). Отдельного поля-признака в схеме нет
     * (additionalProperties: false), поэтому канал один.
     *
     * @param kbDoc   сущность документа базы знаний
     * @param message текст для error_message (усекается до maxLength)
     * @return DTO с метаданными документа
     */
    static KBDocumentResponse toKBDocumentResponse(KBDocument kbDoc, String message) {
        Document doc = kbDoc.getDocument();
        return new KBDocumentResponse(
                kbDoc.getId(),
                doc != null ? doc.getId() : kbDoc.getDocumentId(),
                SchemaLimitUtils.safeFilename(kbDoc.getFilename()),
                SchemaLimitUtils.clip(doc != null ? doc.getContentType() : null, CONTENT_TYPE_MAX_LENGTH),
                doc != null && doc.getSizeBytes() != null ? Math.max(-1, doc.getSizeBytes()) : 0,
                kbDoc.getChunkCount() != null ? Math.max(0, kbDoc.getChunkCount()) : 0,
                SchemaLimitUtils.clip(kbDoc.getStatus(), STATUS_MAX_LENGTH),
                SchemaLimitUtils.clip(message, ERROR_MESSAGE_MAX_LENGTH),
                SchemaLimitUtils.utcMicros(kbDoc.getCreatedAt())
        );
    }
}
