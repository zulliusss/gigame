package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.ScenarioRun;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с запусками сценариев.
 * <p>
 * Предоставляет методы для управления выполнением сценариев.
 *
 * @see ScenarioRun
 */
@Repository
public interface ScenarioRunRepository extends JpaRepository<ScenarioRun, UUID> {

    /**
     * Возвращает все запуски указанного сценария, отсортированные по времени начала (новые первыми).
     *
     * @param scenarioId идентификатор сценария
     * @return список запусков сценария
     */
    List<ScenarioRun> findByScenarioIdOrderByStartedAtDesc(UUID scenarioId);

    /**
     * Все запуски в указанном статусе (для восстановления после рестарта).
     *
     * @param status статус запуска
     * @return список запусков
     */
    List<ScenarioRun> findByStatus(String status);

    /**
     * Количество запусков по каждому из перечисленных сценариев.
     *
     * @param scenarioIds идентификаторы сценариев
     * @return пары [scenarioId, count]
     */
    @Query("select r.scenarioId, count(r) from ScenarioRun r "
            + "where r.scenarioId in :scenarioIds group by r.scenarioId")
    List<Object[]> countByScenarioIds(@Param("scenarioIds") List<UUID> scenarioIds);
}
