package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Интеграционные тесты для {@link ScenarioEngine}.
 * <p>
 * Тестирует публичный API executeScenario, который запускает doExecute в отдельном потоке.
 * <p>
 * Также тестирует doExecute напрямую через рефлексию.
 */
class ScenarioEngineIntegrationTest {

    // -------------------------------------------------------------------------
    // executeScenario integration tests
    // -------------------------------------------------------------------------

    @Test
    void testExecuteScenario_withValidGraph_returnsFlux() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockExecutor = getMockExecutor(graphData, inputNode, 0, "input");

        when(executorFactory.createExecutor(
                any(ScenarioRunNode.class))).thenReturn(mockExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withMultipleNodes_returnsFlux() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");

        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, outputNode),
                List.of(edge)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Input result");

        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, outputNode, 1, "Final output");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2);

        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withException_returnsFailedStatus() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());

        AbstractScenarioExecutor mockExecutor = getMockExecutorWithException(graphData, inputNode, "Test exception");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor);

        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_stepModePausesExecution() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("node-1");
        NodeDto outputNode = createOutputNode("node-2");

        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, outputNode),
                List.of(edge)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Step 1 result");
        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, outputNode, 1, "Step 2 result");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    @Test
    void testExecuteScenario_withSkippedNode_emitsSkippedStatus() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "Condition check");
        NodeDto outputNode = createOutputNode("output-1");

        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);

        AbstractScenarioExecutor mockExecutor1 = getMockExecutor(graphData, inputNode, 0, "Input result");
        AbstractScenarioExecutor mockExecutor2 = getMockExecutor(graphData, processingNode, 1, "");
        AbstractScenarioExecutor mockExecutor3 = getMockExecutor(graphData, outputNode, 2, "Final");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor1)
                .thenReturn(mockExecutor2)
                .thenReturn(mockExecutor3);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.executeScenario(run, graphData);

        assertNotNull(result);
    }

    // -------------------------------------------------------------------------
    // doExecute direct tests (via reflection)
    // -------------------------------------------------------------------------

    /**
     * Тестирует прямой вызов doExecute с валидным графом.
     * doExecute вызывается напрямую через рефлексию.
     */
    @Test
    void testDoExecute_withValidGraph_executesSuccessfully() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto node1 = createInputNode("node-1");
        NodeDto node2 = createOutputNode("node-2");
        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(List.of(node1, node2), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), anyString())).thenReturn(run);
        var step = createScenarioRunStep();
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(step);
        step.setInputData(Map.of(
                "documents_text", "",
                "previous_output", ""));
        step.setOutputData(Map.of("result", "result"));
        step.setPromptUsed("");
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(step);
        var mockExecutor = getMockExecutor(graphData, node1, 0, "Result");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class))).thenReturn(mockExecutor);

        // Создаем Flux и вызываем doExecute напрямую через рефлексию
        Flux<ServerSentEvent<Map<String, Object>>> flux = Flux.create(sink -> {
            try {
                var method = ScenarioEngine.class.getDeclaredMethod("doExecute",
                        FluxSink.class, ScenarioRun.class, GraphDataDto.class, String.class);
                method.setAccessible(true);
                method.invoke(engine, sink, run, graphData, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        });

        // Подписываемся на Flux и ждем завершения
        var events = flux.collectList().block();
        assertNotNull(events);
    }

    /**
     * Тестирует обработку исключений в doExecute.
     */
    @Test
    void testDoExecute_withException_handledCorrectly() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto node1 = createInputNode("node-1");
        NodeDto node2 = createOutputNode("node-2");
        EdgeDto edge = createEdge("e1", "node-1", "node-2");

        GraphDataDto graphData = new GraphDataDto(List.of(node1, node2), List.of(edge));
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory, cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        AbstractScenarioExecutor mockExecutor = getMockExecutorWithException(graphData, node1, "Test exception in doExecute");

        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockExecutor);

        when(stepService.setScenarioStepStatusFailed(any(ScenarioRunStep.class), anyString()))
                .thenReturn(createScenarioRunStep());
        // Ошибка узла (on_error=stop по умолчанию) пробрасывается из doExecute;
        // прогон завершается со статусом FAILED на уровне executeScenario
        Flux<ServerSentEvent<Map<String, Object>>> flux = engine.executeScenario(run, graphData);

        // Подписываемся на Flux - должен завершиться корректно (исключение обработано)
        var events = flux.collectList().block();
        assertNotNull(events);
        Mockito.verify(runService, Mockito.timeout(5000)).setScenarioRunStatusFailed(any(ScenarioRun.class));
    }

    // -------------------------------------------------------------------------
    // resumeScenario tests
    // -------------------------------------------------------------------------

    @Test
    void testResumeScenario_withValidGraph_restoresAndExecutes() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "промпт");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );

        var oldInputStep = createScenarioRunStep();
        oldInputStep.setNodeId("input-1");
        oldInputStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldInputStep.setStatus("completed");
        oldInputStep.setOutputData(Map.of(
                "result", "<<<DOC_1>>>\nТекст документа\n<<<END_DOC_1>>>",
                "doc_names", "файл.pdf"));

        var oldProcessingStep = createScenarioRunStep();
        oldProcessingStep.setNodeId("process-1");
        oldProcessingStep.setNodeType(ScenarioNodeType.PROCESSING_NODE.toString());
        oldProcessingStep.setStatus("completed");
        oldProcessingStep.setOutputData(Map.of("result", "результат обработки"));

        List<ScenarioRunStep> oldSteps = List.of(oldInputStep, oldProcessingStep);
        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.resumeScenario(run, graphData, oldSteps);

        assertNotNull(result);
    }

    @Test
    void testResumeScenario_withEmptyOldSteps_throwsScenarioException() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.resumeScenario(run, graphData, List.of());

        assertNotNull(result);
    }

    @Test
    void testResumeScenario_withStepModeEnabled_pausesCorrectly() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();

        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        engine.enableStepMode(run.getId().toString());

        var oldStep = createScenarioRunStep();
        oldStep.setNodeId("input-1");
        oldStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldStep.setStatus("completed");
        oldStep.setOutputData(Map.of("result", "<<<DOC_1>>>\ntext\n<<<END_DOC_1>>>", "doc_names", "test.pdf"));

        List<ScenarioRunStep> oldSteps = List.of(oldStep);

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        Flux<ServerSentEvent<Map<String, Object>>> result = engine.resumeScenario(run, graphData, oldSteps);

        assertNotNull(result);
    }

    // -------------------------------------------------------------------------
    // scheduleReadyNodes tests
    // -------------------------------------------------------------------------

    @Test
    void testScheduleReadyNodes_startNode_returns1() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        // Создаём граф с узлами
        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        // Вызываем scheduleReadyNodes через рефлексию
        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // Стартовый узел (input-1) должен быть запланирован
        assertEquals(1, started);
        assertTrue(scheduled.stream().anyMatch(n -> "input-1".equals(n.getId())));
    }

    @Test
    void testScheduleReadyNodes_allScheduled_returns0() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        // Все узлы уже запланированы
        scheduled.addAll(nodes);

        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // Ни один узел не должен быть запланирован
        assertEquals(0, started);
    }

    @Test
    void testScheduleReadyNodes_skipNode_returns0ForSkipped() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        // Граф: вход → обработка → выход (обработка может быть пропущена)
        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "промпт");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        // Создаём граф с узлами
        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        // Отмечаем все узлы, кроме processing, как завершённые (чтобы
        // scheduleNodeIfReady дошёл до проверки skip для process-1)
        for (var n : nodes) {
            if (!"process-1".equals(n.getId())) {
                n.setCompleted(true);
                n.setSkip(false);
            }
        }

        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // process-1 имеет skip=true и все родители завершены — узел пропускается
        assertEquals(0, started);
        // process-1 должен быть в skippedNodes (родители завершены, но не активирован)
        assertTrue(skippedNodes.stream().anyMatch(n -> "process-1".equals(n.getId())));
    }

    @Test
    void testScheduleReadyNodes_completedNode_returns0() throws Exception {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);
        @SuppressWarnings("unchecked")
        ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(
                Executors.newSingleThreadExecutor());
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();

        ScenarioRunGraph graph = new ScenarioRunGraph(graphData);
        ScenarioRunNode inputNodeInstance = graph.getNodeMap().get("input-1");

        // Узел уже завершён (completed=true — восстановлен из предыдущего прогона)
        inputNodeInstance.setCompleted(true);
        inputNodeInstance.setSkip(false);

        Collection<ScenarioRunNode> nodes = graph.getNodeMap().values();

        var method = ScenarioEngine.class.getDeclaredMethod("scheduleReadyNodes",
                FluxSink.class, ScenarioRun.class, Collection.class,
                ExecutorCompletionService.class, Set.class, Set.class);
        method.setAccessible(true);
        int started = (int) method.invoke(engine, sink, run, nodes, ecs, scheduled, skippedNodes);

        // Завершённый узел не планируется заново
        assertEquals(0, started);
        assertTrue(scheduled.stream().anyMatch(n -> "input-1".equals(n.getId())));
    }

    // -------------------------------------------------------------------------
    // resumeExecution tests
    // -------------------------------------------------------------------------

    /**
     * Вызов resumeExecution через рефлексию.
     */
    private void invokeResumeExecution(ScenarioEngine engine,
                                        FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                        ScenarioRun run,
                                        GraphDataDto graphData,
                                        List<ScenarioRunStep> oldSteps) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("resumeExecution",
                    FluxSink.class, ScenarioRun.class, GraphDataDto.class, List.class);
            method.setAccessible(true);
            method.invoke(engine, sink, run, graphData, oldSteps);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException) {
                throw (RuntimeException) cause;
            }
            throw new RuntimeException(cause);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void testResumeExecution_withValidOldSteps_completesSuccessfully() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        var repository = Mockito.mock(ScenarioRepository.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto processingNode = createProcessingNode("process-1", "промпт");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge1 = createEdge("e1", "input-1", "process-1");
        EdgeDto edge2 = createEdge("e2", "process-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processingNode, outputNode),
                List.of(edge1, edge2)
        );

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, repository, Mockito.mock(ScenarioOutputSupportService.class));

        var oldInputStep = createScenarioRunStep();
        oldInputStep.setNodeId("input-1");
        oldInputStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldInputStep.setStatus("completed");
        oldInputStep.setOutputData(Map.of(
                "result", "<<<DOC_1>>>\nТекст документа\n<<<END_DOC_1>>>",
                "doc_names", "файл.pdf"));

        var oldProcessingStep = createScenarioRunStep();
        oldProcessingStep.setNodeId("process-1");
        oldProcessingStep.setNodeType(ScenarioNodeType.PROCESSING_NODE.toString());
        oldProcessingStep.setStatus("completed");
        oldProcessingStep.setOutputData(Map.of("result", "обработан"));

        List<ScenarioRunStep> oldSteps = List.of(oldInputStep, oldProcessingStep);

        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any())).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());
        when(stepService.setScenarioStepStatusCompleted(any(ScenarioRunStep.class), anyString(), anyString(),
                anyString(), anyString())).thenReturn(createScenarioRunStep());
        when(stepService.copyStepToRun(any(UUID.class), any(ScenarioRunStep.class)))
                .thenReturn(createScenarioRunStep());

        var mockInputExecutor = getMockExecutor(graphData, inputNode, 0, "входной результат");
        when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenReturn(mockInputExecutor);

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        assertDoesNotThrow(() -> invokeResumeExecution(engine, sink, run, graphData, oldSteps));
    }

    @Test
    void testResumeExecution_withoutOldSteps_throwsScenarioException() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        var repository = Mockito.mock(ScenarioRepository.class);

        GraphDataDto graphData = new GraphDataDto(List.of(), List.of());
        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, repository, Mockito.mock(ScenarioOutputSupportService.class));

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        assertThrows(ScenarioException.class,
                () -> invokeResumeExecution(engine, sink, run, graphData, List.of()));
    }

    @Test
    void testRestoreAgentCheckpoints_failedStepBecomesWorkingDoc() {
        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode),
                List.of(createEdge("e1", "input-1", "output-1")));
        var graph = new ScenarioRunGraph(graphData);
        var failedStep = createScenarioRunStep();
        failedStep.setNodeId("agent-1");
        failedStep.setStatus("failed");
        failedStep.setOutputData(Map.of("error", "сеть",
                "checkpoint", "поиск 'НМЦ' -> 161560083"));
        var completedStep = createScenarioRunStep();
        completedStep.setNodeId("input-1");
        completedStep.setStatus("completed");

        ScenarioEngine.restoreAgentCheckpoints(graph, List.of(failedStep, completedStep));

        // чекпойнт упавшего узла стал рабочим файлом прогона, completed — нет
        var work = graph.getDocMap().values().stream()
                .filter(d -> d.isWorkNote()).toList();
        assertEquals(1, work.size());
        assertTrue(work.get(0).getFilename().contains("agent-1"));
        assertTrue(work.get(0).getText().contains("161560083"));
    }

    @Test
    void testResumeExecution_withoutInputResult_throwsScenarioException() {
        var runService = Mockito.mock(ScenarioRunService.class);
        var stepService = Mockito.mock(ScenarioRunStepService.class);
        var executorFactory = Mockito.mock(ScenarioExecutorFactory.class);
        var cacheService = Mockito.mock(DocsTextCacheService.class);
        var repository = Mockito.mock(ScenarioRepository.class);

        NodeDto inputNode = createInputNode("input-1");
        NodeDto outputNode = createOutputNode("output-1");
        EdgeDto edge = createEdge("e1", "input-1", "output-1");
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        ScenarioRun run = createScenarioRun();
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                cacheService, repository, Mockito.mock(ScenarioOutputSupportService.class));

        var oldStep = createScenarioRunStep();
        oldStep.setNodeId("input-1");
        oldStep.setNodeType(ScenarioNodeType.INPUT_NODE.toString());
        oldStep.setStatus("completed");
        // outputData без result — нечего восстанавливать

        @SuppressWarnings("unchecked")
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = Mockito.mock(FluxSink.class);

        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenReturn(createScenarioRunStep());

        assertThrows(ScenarioException.class,
                () -> invokeResumeExecution(engine, sink, run, graphData, List.of(oldStep)));
    }

    // -------------------------------------------------------------------------
    // Factory methods for test data
    // -------------------------------------------------------------------------

    private ScenarioRun createScenarioRun() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(UUID.randomUUID());
        run.setStatus("pending");
        return run;
    }

    private ScenarioRunStep createScenarioRunStep() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setRunId(UUID.randomUUID());
        step.setNodeId("node-1");
        step.setNodeType("input");
        step.setStatus("pending");
        return step;
    }

    private NodeDto createInputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private NodeDto createOutputNode(String id) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private NodeDto createProcessingNode(String id, String prompt) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Processing").prompt(prompt).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private EdgeDto createEdge(String id, String source, String target) {
        return new EdgeDto(id, source, target, new EdgeDataDto(null));
    }

    private AbstractScenarioExecutor getMockExecutor(GraphDataDto graphData, NodeDto node, int index, String inputResult) {
        return new AbstractScenarioExecutor(ScenarioRunNode.fromDto(index, node, new ScenarioRunGraph(graphData))) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                return inputResult;
            }

            @Override
            public String getPrompt() {
                return "";
            }

        };
    }

    private AbstractScenarioExecutor getMockExecutorWithException(GraphDataDto graphData, NodeDto node1, String exceptionText) {
        return new AbstractScenarioExecutor(
                ScenarioRunNode.fromDto(0, node1, new ScenarioRunGraph(graphData))) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                throw new RuntimeException(exceptionText);
            }

            @Override
            public String getPrompt() {
                return "";
            }
        };
    }
}
