package ru.sber.cs.ai.gigame.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.server.ResponseStatusException;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioCreate;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioUpdate;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {ScenarioController.class, TestConfiguration.class})
@WebFluxTest(controllers = ScenarioController.class)
@SuppressWarnings("unused")
class ScenarioControllerTest {

    @MockitoBean
    DocsTextCacheService docsTextCacheService;
    @Autowired
    private WebTestClient webClient;
    @Autowired
    private ObjectMapper objectMapper;
    @MockitoBean
    private ScenarioService scenarioService;
    @MockitoBean
    private ScenarioEngine scenarioEngine;
    @MockitoBean
    private ScenarioUploadTaskService scenarioUploadTaskService;
    private String userId;
    private UUID scenarioId;
    private UUID runId;
    private ScenarioResponse scenarioResponse;

    @BeforeEach
    void setUp() {
        userId = "test-user";
        scenarioId = UUID.randomUUID();
        runId = UUID.randomUUID();
        scenarioResponse = new ScenarioResponse(
                scenarioId,
                "Test Scenario",
                "Description",
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                false,
                true,
                5.0,
                10L,
                5,
                10L
        );
    }

    @Test
    void testListScenarios() {
        when(scenarioService.getScenarios(any())).thenReturn(List.of(scenarioResponse));

        webClient.get()
                .uri("/api/scenarios")
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class);
    }

    @Test
    void testCreateScenario() {
        ScenarioCreate body = new ScenarioCreate(
                "New Scenario",
                "Description",
                new GraphDataDto(
                        List.of(),
                        List.of()
                )
        );

        when(scenarioService.createScenario(any(), eq("New Scenario"), eq("Description"), any()))
                .thenReturn(scenarioResponse);

        webClient.post()
                .uri("/api/scenarios")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioResponse.class);
    }

    @Test
    void testGetScenario() {
        ScenarioDetailResponse result = new ScenarioDetailResponse(
                scenarioId,
                "Test Scenario",
                "Description",
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                new GraphDataDto(List.of(), List.of())
        );

        when(scenarioService.getScenario(any(), eq(scenarioId))).thenReturn(result);

        webClient.get()
                .uri("/api/scenarios/{id}", scenarioId)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioDetailResponse.class);
    }

    @Test
    void testUpdateScenario() {
        ScenarioUpdate body = new ScenarioUpdate(
                "Updated Scenario",
                "Updated description",
                new GraphDataDto(
                        List.of(),
                        List.of()
                ),
                null
        );

        ScenarioResponse updatedResponse = new ScenarioResponse(
                scenarioId,
                "Updated Scenario",
                "Updated description",
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                false,
                true,
                5.0,
                10L,
                5,
                10L
        );

        when(scenarioService.updateScenario(any(), eq(scenarioId), eq("Updated Scenario"), eq("Updated description"), any(), any()))
                .thenReturn(updatedResponse);

        webClient.put()
                .uri("/api/scenarios/{id}", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioResponse.class)
                .value(response -> {
                    assert response != null;
                    assertEquals("Updated Scenario", response.name());
                });
    }

    @Test
    void testDeleteScenario() {
        doNothing().when(scenarioService).deleteScenario(any(), eq(scenarioId));

        webClient.delete()
                .uri("/api/scenarios/{id}", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isNoContent();
    }

    @Test
    void duplicateScenario_ShouldReturnCopiedScenario() {
        // Given
        ScenarioResponse copiedResponse = new ScenarioResponse(
                UUID.randomUUID(),
                "Original Scenario (копия)",
                "Original description",
                OffsetDateTime.now(),
                OffsetDateTime.now()
        );

        when(scenarioService.duplicateScenario(userId, scenarioId))
                .thenReturn(copiedResponse);

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/duplicate", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioResponse.class)
                .value(response -> {
                    assert response != null;
                });
    }

    @Test
    void duplicateScenario_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        when(scenarioService.duplicateScenario(userId, scenarioId))
                .thenThrow(new IllegalArgumentException("Scenario not found: " + scenarioId));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/duplicate", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    // -------------------------------------------------------------------------
    // listRuns
    // -------------------------------------------------------------------------

    @Test
    void listRuns_ShouldReturnRunsList() {
        // Given
        ScenarioRunResponse run1 = new ScenarioRunResponse(
                UUID.randomUUID(),
                scenarioId,
                "completed",
                List.of("doc1", "doc2"),
                OffsetDateTime.now().minusDays(1),
                OffsetDateTime.now().minusDays(1)
        );

        ScenarioRunResponse run2 = new ScenarioRunResponse(
                UUID.randomUUID(),
                scenarioId,
                "failed",
                List.of("doc3"),
                OffsetDateTime.now().minusHours(2),
                OffsetDateTime.now().minusHours(2)
        );

        when(scenarioService.getScenarioRuns(userId, scenarioId))
                .thenReturn(List.of(run1, run2));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/runs", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class);
    }

    @Test
    void listRuns_ShouldReturnEmptyList_WhenNoRuns() {
        // Given
        when(scenarioService.getScenarioRuns(userId, scenarioId))
                .thenReturn(List.of());

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/runs", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectBody(List.class)
                .value(list -> {
                    assert list != null;
                    assert ((List<?>) list).isEmpty();
                });
    }

    @Test
    void listRuns_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        when(scenarioService.getScenarioRuns(userId, scenarioId))
                .thenThrow(new IllegalArgumentException("Сценарий не найден: " + scenarioId));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/runs", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    @Test
    void getRunDetail_ShouldReturnDetailedRunInfo() {
        // Given
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node-1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "2024-01-01"),
                new ScenarioRunStepOutputDataResponse("Результат", null),
                "Это промпт",
                10,
                OffsetDateTime.now().minusHours(1),
                OffsetDateTime.now()
        );

        ScenarioRunDetailResponse runDetail = new ScenarioRunDetailResponse(
                runId,
                scenarioId,
                "completed",
                List.of("doc1"),
                "Final result",
                OffsetDateTime.now().minusHours(1),
                OffsetDateTime.now(),
                List.of(step1)
        );

        when(scenarioService.getScenarioRun(userId, runId))
                .thenReturn(runDetail);

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioRunDetailResponse.class)
                .value(response -> {
                    assert response != null;
                    assert response.id().equals(runId);
                    assert response.scenarioId().equals(scenarioId);
                });
    }

    @Test
    void getRunDetail_ShouldReturnNotFound_WhenRunNotFound() {
        // Given
        when(scenarioService.getScenarioRun(userId, runId))
                .thenThrow(new IllegalArgumentException("Запуск сценария не найден: " + runId));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    // -------------------------------------------------------------------------
    // continueRun
    // -------------------------------------------------------------------------

    @Test
    void continueRun_ShouldContinueExecution() {
        // Given
        doNothing().when(scenarioEngine).continueStep(runId.toString());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/runs/{runId}/continue", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();
    }

    // -------------------------------------------------------------------------
    // disableStepMode
    // -------------------------------------------------------------------------

    @Test
    void disableStepMode_ShouldDisableStepModeAndContinue() {
        // Given
        doNothing().when(scenarioEngine).disableStepMode(runId.toString());

        // When & Then
        webClient.post()
                .uri("/api/scenarios/runs/{runId}/disable-step-mode", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();
    }

    // -------------------------------------------------------------------------
    // cancelRun
    // -------------------------------------------------------------------------

    @Test
    void cancelRun_ShouldRequestEngineCancel() {
        // Given
        when(scenarioEngine.requestCancel(runId.toString())).thenReturn(true);

        // When & Then
        webClient.post()
                .uri("/api/scenarios/runs/{runId}/cancel", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();
    }

    // -------------------------------------------------------------------------
    // downloadRunFile
    // -------------------------------------------------------------------------

    @Test
    void downloadRunFile_ShouldReturnFile() {
        // Given
        byte[] fileContent = "col1;col2".getBytes();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        when(scenarioService.downloadRunFile(userId, runId, "node-out"))
                .thenReturn(new ResponseEntity<>(new ByteArrayResource(fileContent),
                        headers, HttpStatus.OK));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}/files/{nodeId}", runId, "node-out")
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectBody(byte[].class);
    }

    @Test
    void downloadRunFile_ShouldReturnNotFound_WhenNodeIsNotFileOutput() {
        // Given
        when(scenarioService.downloadRunFile(userId, runId, "node-plain"))
                .thenThrow(new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Узел не является файловым выходом"));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}/files/{nodeId}", runId, "node-plain")
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isNotFound();
    }

    // -------------------------------------------------------------------------
    // exportRun
    // -------------------------------------------------------------------------

    @Test
    void exportRun_ShouldReturnDocxFile() {
        // Given
        byte[] docxContent = "mock docx content".getBytes();
        ByteArrayResource resource = new ByteArrayResource(docxContent) {
            @Override
            public String getFilename() {
                return "test.docx";
            }
        };

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.wordprocessingml.document"));

        when(scenarioService.extractToDocx(userId, runId, false))
                .thenReturn(new ResponseEntity<>(resource, headers, org.springframework.http.HttpStatus.OK));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}/export", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType("application/vnd.openxmlformats-officedocument.wordprocessingml.document")
                .expectBody(byte[].class);
    }

    @Test
    void exportRun_ShouldReturnNotFound_WhenRunNotFound() {
        // Given
        when(scenarioService.extractToDocx(userId, runId, false))
                .thenThrow(new IllegalArgumentException("Run not found: " + runId));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/runs/{runId}/export", runId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    // -------------------------------------------------------------------------
    // rateScenario
    // -------------------------------------------------------------------------

    @Test
    void rateScenario_ShouldReturnOk_WhenValidRating() {
        // Given
        doNothing().when(scenarioService).rateScenario(any(), eq(scenarioId), eq(5));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/rating", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new ru.sber.cs.ai.gigame.dto.scenario.ScenarioRateRequest(5))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void rateScenario_ShouldReturnBadRequest_WhenMissingRatingField() {
        // When & Then — DTO без поля rating → null → IllegalArgumentException
        webClient.post()
                .uri("/api/scenarios/{id}/rating", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new ru.sber.cs.ai.gigame.dto.scenario.ScenarioRateRequest(null))
                .exchange()
                .expectStatus().is5xxServerError();
    }

    @Test
    void rateScenario_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        doThrow(new IllegalArgumentException("Scenario not found: " + scenarioId))
                .when(scenarioService).rateScenario(any(), eq(scenarioId), eq(3));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/rating", scenarioId)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new ru.sber.cs.ai.gigame.dto.scenario.ScenarioRateRequest(3))
                .exchange()
                .expectStatus().is5xxServerError();
    }

    // -------------------------------------------------------------------------
    // listVersions / restoreVersion
    // -------------------------------------------------------------------------

    @Test
    void listVersions_ShouldReturnVersionList() {
        // Given
        java.util.Map<String, Object> v1 = Map.of("version_no", 1, "name", "v1", "created_at", OffsetDateTime.now());
        java.util.Map<String, Object> v2 = Map.of("version_no", 2, "name", "v2", "created_at", OffsetDateTime.now());
        when(scenarioService.getVersions(any(), eq(scenarioId))).thenReturn(List.of(v1, v2));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/versions", scenarioId)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class);
    }

    @Test
    void listVersions_ShouldReturnEmptyList_WhenNoVersions() {
        // Given
        when(scenarioService.getVersions(any(), eq(scenarioId))).thenReturn(List.of());

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/versions", scenarioId)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class)
                .value(list -> {
                    assert list != null;
                    assert ((List<?>) list).isEmpty();
                });
    }

    @Test
    void listVersions_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        when(scenarioService.getVersions(any(), eq(scenarioId)))
                .thenThrow(new IllegalArgumentException("Scenario not found: " + scenarioId));

        // When & Then
        webClient.get()
                .uri("/api/scenarios/{id}/versions", scenarioId)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    @Test
    void restoreVersion_ShouldReturnRestoredScenario() {
        // Given
        ScenarioResponse restored = new ScenarioResponse(
                scenarioId,
                "Restored Scenario",
                "Restored description",
                OffsetDateTime.now(),
                OffsetDateTime.now()
        );
        int versionNo = 3;
        when(scenarioService.restoreVersion(any(), eq(scenarioId), eq(versionNo)))
                .thenReturn(restored);

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/versions/{versionNo}/restore", scenarioId, versionNo)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(ScenarioResponse.class)
                .value(response -> {
                    assert response != null;
                    assertEquals("Restored Scenario", response.name());
                });
    }

    @Test
    void restoreVersion_ShouldReturnNotFound_WhenScenarioNotFound() {
        // Given
        int versionNo = 3;
        when(scenarioService.restoreVersion(any(), eq(scenarioId), eq(versionNo)))
                .thenThrow(new IllegalArgumentException("Scenario not found: " + scenarioId));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/versions/{versionNo}/restore", scenarioId, versionNo)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }

    @Test
    void restoreVersion_ShouldReturnNotFound_WhenVersionNotFound() {
        // Given
        int versionNo = 999;
        when(scenarioService.restoreVersion(any(), eq(scenarioId), eq(versionNo)))
                .thenThrow(new ru.sber.cs.ai.gigame.exception.NotFoundException("Версия 999 не найдена"));

        // When & Then
        webClient.post()
                .uri("/api/scenarios/{id}/versions/{versionNo}/restore", scenarioId, versionNo)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().is5xxServerError();
    }
}

