package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioRunResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var scenarioId = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var dto = new ScenarioRunResponse(id, scenarioId, "completed",
                List.of("doc1"), now, now);
        assertEquals(id, dto.id());
        assertEquals(scenarioId, dto.scenarioId());
        assertEquals("completed", dto.status());
        assertEquals(1, dto.inputDocumentIds().size());
        assertEquals("doc1", dto.inputDocumentIds().get(0));
        assertEquals(now, dto.startedAt());
        assertEquals(now, dto.completedAt());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioRunResponse(null, null, null, null, null, null);
        assertNull(dto.id());
        assertNull(dto.scenarioId());
        assertNull(dto.status());
        assertNull(dto.inputDocumentIds());
        assertNull(dto.startedAt());
        assertNull(dto.completedAt());
    }

    @Test
    void testConstruction_withEmptyInputDocumentIds() {
        var dto = new ScenarioRunResponse(null, null, null, List.of(), null, null);
        assertTrue(dto.inputDocumentIds().isEmpty());
    }
}