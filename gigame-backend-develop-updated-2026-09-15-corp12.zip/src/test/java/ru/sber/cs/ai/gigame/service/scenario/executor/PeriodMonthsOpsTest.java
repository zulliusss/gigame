package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Тесты операции «месяцы_из_дат»: перечень месяцев периода из строки «календарные даты».
 */
class PeriodMonthsOpsTest {

    private static final String QUAL = "Период опыта участника по квалификационным требованиям";
    private static final String METHOD = "Период опыта по методике оценки";

    private static Map<String, Object> row(String criterion, String value) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("критерий", criterion);
        m.put("значение", value);
        m.put("источник", "модель");
        return m;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> at(List<Object> rows, int i) {
        return (Map<String, Object>) rows.get(i);
    }

    @Test
    void rebuildsAbbreviatedMonthListFromDates() {
        // Приложение 3: 45 месяцев, модель сократила перечень многоточием — код строит полный
        List<Object> rows = new ArrayList<>();
        rows.add(row(QUAL + " — календарные даты", "с 01.01.2021 по 09.09.2024"));
        rows.add(row(QUAL + " — допустимые месяцы", "01.2021, 02.2021, ..., 08.2024, 09.2024"));
        rows.add(row(METHOD + " — календарные даты", "с 25.03.2025 по 25.03.2026"));
        rows.add(row(METHOD + " — допустимые месяцы", "03.2025, 04.2025"));

        assertEquals(2, PeriodMonthsOps.monthsFromDates(Map.of(), rows));
        String qual = String.valueOf(at(rows, 1).get("значение"));
        assertEquals(45, qual.split(", ").length, qual);
        assertEquals("01.2021, 02.2021, 03.2021", qual.substring(0, 25));
        assertEquals("09.2024", qual.substring(qual.length() - 7));
        assertEquals("03.2025, 04.2025, 05.2025, 06.2025, 07.2025, 08.2025, 09.2025, 10.2025, 11.2025, 12.2025, 01.2026, 02.2026, 03.2026",
                at(rows, 3).get("значение"));
        assertEquals("расчёт кодом по строке «" + METHOD + " — календарные даты»: первый месяц с 25-го числа, последний по 25-е число",
                at(rows, 3).get("источник"));
        assertEquals(PeriodMonthsOps.CALCULATED, at(rows, 3).get("достоверность"));
    }

    @Test
    void leavesRowWhenDatesMissingOrUnparsable() {
        List<Object> rows = new ArrayList<>();
        rows.add(row(QUAL + " — календарные даты", "не указано в документации, требуется решение закупщика"));
        rows.add(row(QUAL + " — допустимые месяцы", "не указано в документации, требуется решение закупщика"));
        rows.add(row(METHOD + " — допустимые месяцы", "нет"));

        assertEquals(0, PeriodMonthsOps.monthsFromDates(Map.of(), rows));
        assertEquals("не указано в документации, требуется решение закупщика", at(rows, 1).get("значение"));
        assertNull(at(rows, 1).get("достоверность"));
        assertEquals("нет", at(rows, 2).get("значение"));
    }

    @Test
    void skipsReversedOrAbsurdPeriods() {
        List<Object> rows = new ArrayList<>();
        rows.add(row(QUAL + " — календарные даты", "с 09.09.2024 по 01.01.2021"));
        rows.add(row(QUAL + " — допустимые месяцы", "?"));
        rows.add(row(METHOD + " - календарные даты", "с 01.01.1900 по 01.01.2026"));
        rows.add(row(METHOD + " - допустимые месяцы", "?"));

        assertEquals(0, PeriodMonthsOps.monthsFromDates(Map.of(), rows));
        assertEquals("?", at(rows, 1).get("значение"));
        assertEquals("?", at(rows, 3).get("значение"));
    }

    @Test
    void acceptsHyphenVariantsAndCustomSuffixes() {
        List<Object> rows = new ArrayList<>();
        rows.add(row("Период - даты", "с 17.03.2025 по 17.05.2025"));
        rows.add(row("Период - месяцы", "?"));

        assertEquals(1, PeriodMonthsOps.monthsFromDates(Map.of("суффикс_месяцев", "месяцы", "суффикс_дат", "даты"), rows));
        assertEquals("03.2025, 04.2025, 05.2025", at(rows, 1).get("значение"));
    }
}
