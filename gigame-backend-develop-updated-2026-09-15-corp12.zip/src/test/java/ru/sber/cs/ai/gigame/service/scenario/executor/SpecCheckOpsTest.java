package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Block;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Status;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecTableParser.SpecPosition;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты сверки характеристик кодом: разбор таблицы требований, проверка строк, отчёт по договору.
 */
class SpecCheckOpsTest {

    /** Таблица ТЗ из комплекта 2 письма Комягина (столы), как её отдаёт разбор docx. */
    private static final String TZ = "[ < № п/п | Наименование ТМЦ / услуги | Описание, технические и функциональные характеристики | Ед. измерения | Объем закупаемых ТМЦ / услуг >\n"
            + "< 1 | Стол барный | Ориентировочный вид стола на фото. \nВысота подстолья - 1020 мм \nДиаметр подстолья - 575 мм\n"
            + "Материал столешницы - прозрачное закаленное стекло. Снизу  матовое.\nТолщина столешницы - 5 мм\n"
            + "Предусмотреть скрытые элементы крепления столешницы к подстолью.\n\nСогласование материала и чертежа с заказчиком. | шт | 4 >\n"
            + "< 2 | Стол фуршетный | Высота подстолья - 915 мм\nНагрузка на столешницу - не менее 50 кг\nИстирание - не менее 50 000 циклов | шт | 1 > ]";

    /** Спецификация договора в тексте PDF: переносы строк внутри фраз и номер страницы. */
    private static final String CONTRACT = "ДОГОВОР № 50005802429\nСПЕЦИФИКАЦИЯ ПОСТАВКИ\n1 \nСтол барный \nОриентировочный вид стола на фото.  \n"
            + "Высота подстолья - 1020 мм  \nДиаметр подстолья - 575 мм \nМатериал столешницы - прозрачное \nзакаленное стекло. \n16 \n"
            + "Толщина столешницы - 5 мм \nПредусмотреть скрытые элементы крепления \nстолешницы к подстолью. \nСогласование материала и чертежа с \nзаказчиком. \n"
            + "2 \nСтол \nфуршетный \nВысота подстолья - 915 мм \nНагрузка на столешницу - 45 кг \nИстирание - не менее 50 тыс. циклов \n";

    private static ScenarioRunDoc doc(String name, String text, String cls) {
        ScenarioRunDoc d = new ScenarioRunDoc(name, text);
        d.setDocClass(cls);
        return d;
    }

    @Test
    void parsesPositionsOnlyFromCharacteristicsTable() {
        String text = "[ < № | Продукция | Количество >\n< 1 | Стол барный | 4 > ]\nГОСТ 16371-2014\n" + TZ;
        List<SpecPosition> positions = SpecTableParser.parse(text, "ТЗ.docx", Pattern.compile("наименован", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE),
                Pattern.compile("характеристик", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE));

        assertEquals(2, positions.size());
        assertEquals("Стол барный", positions.get(0).name());
        assertEquals("1", positions.get(0).number());
        assertEquals(7, positions.get(0).lines().size());
        assertEquals("Материал столешницы - прозрачное закаленное стекло. Снизу  матовое.", positions.get(0).lines().get(3));
        assertEquals(3, positions.get(1).lines().size());
    }

    @Test
    void lineCheckFindsExactGappedThresholdAndMissing() {
        NormalizedText text = NormalizedText.of("Высота подстолья - 1020 мм\nМатериал - закаленное\n17\nстекло\nНагрузка - 45 кг\nИстирание - не менее 50 тыс. циклов");
        List<Block> all = List.of(new Block(0, text.norm().length()));

        assertEquals(Status.EXACT, SpecLineCheck.check("Высота подстолья – 1020 мм.", text, all).status());
        assertEquals(Status.GAPPED, SpecLineCheck.check("Материал - закаленное стекло", text, all).status());
        assertEquals(Status.THRESHOLD_FAIL, SpecLineCheck.check("Нагрузка - не менее 50 кг", text, all).status());
        assertEquals(Status.THRESHOLD_OK, SpecLineCheck.check("Истирание - не менее 50 000 циклов", text, all).status());
        var missing = SpecLineCheck.check("Цвет подстолья - белый", text, all);
        assertEquals(Status.MISSING, missing.status());
        assertEquals("нет в тексте позиции: цвет, белый", missing.detail());
        assertEquals(50_000.0, SpecLineCheck.number("не менее 50 тыс. циклов"));
        assertEquals(1234.5, SpecLineCheck.number("1 234,5 руб."));
        assertNull(SpecLineCheck.number("без числа"));
    }

    @Test
    void reportsLinesMissingInContractPositionAndThresholdViolations() {
        String report = SpecCheckOps.check(Map.of(), List.of(doc("ТЗ.docx", TZ, "техническое_задание"), doc("Договор.pdf", CONTRACT, "договор")));

        assertTrue(report.contains("позиций 2, характеристик 10"), report);
        assertTrue(report.contains("не найдены 1"), report);
        assertTrue(report.contains("НЕ НАЙДЕНО ДОСЛОВНО | позиция 1 «Стол барный» | «Материал столешницы - прозрачное закаленное стекло. Снизу  матовое.» | нет в тексте позиции: снизу, матовое"), report);
        assertTrue(report.contains("ПОРОГ НАРУШЕН | позиция 2 «Стол фуршетный» | «Нагрузка на столешницу - не менее 50 кг» | требование не менее 50, в договоре «45 кг"), report);
        assertTrue(report.contains("порог выполнен 1"), report);
        assertTrue(report.contains("\"не_найдено\": 1, \"порог_нарушен\": 1, \"позиций_не_найдено\": 0"), report);
        assertFalse(report.contains("| «Высота подстолья - 915 мм» |"), report);
    }

    @Test
    void reportsMissingTableOrContract() {
        String noTable = SpecCheckOps.check(Map.of(), List.of(doc("Извещение.docx", "ГОСТ 16371-2014, сертификаты", "документация"), doc("Д.pdf", CONTRACT, "договор")));
        assertTrue(noTable.contains("ТАБЛИЦА ХАРАКТЕРИСТИК НЕ НАЙДЕНА"), noTable);
        assertTrue(noTable.contains("\"таблица_найдена\": false"), noTable);

        String noContract = SpecCheckOps.check(Map.of(), List.of(doc("ТЗ.docx", TZ, "техническое_задание"), doc("ПЗ.docx", "протокол", "протокол")));
        assertTrue(noContract.contains("ДОГОВОР НЕ ПРИЛОЖЕН"), noContract);
    }

    @Test
    void searchesWholeContractWhenPositionNameAbsent() {
        String contract = "Спецификация\nВысота подстолья - 1020 мм\nДиаметр подстолья - 575 мм\n";
        String tz = "[ < № | Наименование | Характеристики >\n< 1 | Стол барный круглый | Высота подстолья - 1020 мм\nДиаметр подстолья - 575 мм > ]";

        String report = SpecCheckOps.check(Map.of(), List.of(doc("ТЗ.docx", tz, "техническое_задание"), doc("Д.pdf", contract, "договор")));

        assertTrue(report.contains("ПОЗИЦИИ НЕ НАЙДЕНЫ В ДОГОВОРЕ ПО НАИМЕНОВАНИЮ"), report);
        assertTrue(report.contains("Все характеристики найдены в договоре."), report);
    }

    @Test
    void normalizedTextKeepsRawPositions() {
        NormalizedText text = NormalizedText.of("Ёлка – 50 000 шт.\nКонец");

        assertEquals("елка50000штконец", text.norm());
        assertEquals("50 000 шт.", text.snippet(4, 11, 100));
        assertEquals(List.of("елка", "50", "000"), NormalizedText.tokens("Ёлка 50 000"));
        assertEquals("Ёлка…", text.snippet(0, 11, 4));
    }
}
