package ru.sber.cs.ai.gigame.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.Future;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.ArrayList;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

import java.util.List;
import java.util.concurrent.TimeUnit;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты постраничного OCR: страницы-картинки распознаются по одной, страница
 * со штампом ЭДО берётся из текстового слоя, лимит страниц помечается.
 */
@ExtendWith(MockitoExtension.class)
class ScanOcrServiceTest {

    private static final String STAMP = "Document signed and transferred via EDO operator, registration number 12345";

    @Mock
    private GigaChatClient gigaChatClient;

    private static byte[] pdf(String... pageTexts) throws IOException {
        try (PDDocument doc = new PDDocument()) {
            for (String text : pageTexts) {
                addPage(doc, text);
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private static void addPage(PDDocument doc, String text) throws IOException {
        PDPage page = new PDPage();
        doc.addPage(page);
        if (text.isEmpty()) {
            return;
        }
        try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
            cs.beginText();
            cs.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
            cs.newLineAtOffset(50, 700);
            cs.showText(text);
            cs.endText();
        }
    }

    private ScanOcrService service() {
        ScanOcrService service = new ScanOcrService(gigaChatClient);
        ReflectionTestUtils.setField(service, "enabled", true);
        return service;
    }

    @Test
    void multiPageScanIsRecognizedPageByPageKeepingTextLayerPages() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Акт №1 текст страницы", Map.of()));

        String text = service().recognize("скан.pdf", pdf("", "", STAMP));

        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.startsWith(ScanOcrService.OCR_PREFIX + " Документ «скан.pdf»:"));
        assertTrue(text.contains("--- страница 1 ---\nАкт №1 текст страницы"));
        assertTrue(text.contains("--- страница 3 (текстовый слой) ---\n" + STAMP));
    }

    @Test
    void refusedPageIsRetriedWithFallbackPrompt() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Из предоставленного контекста невозможно сформировать полный текст", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("Заявка №219 к Договору", Map.of()))
                .thenReturn(new GigaChatClient.ChatResult("страница 2", Map.of()));

        String text = service().recognize("скан.pdf", pdf("", ""));

        verify(gigaChatClient, times(3)).chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"),
                any(), any(), any());
        assertTrue(text.contains("--- страница 1 ---\nЗаявка №219 к Договору"));
        assertTrue(ScanOcrService.isRefusal("Из предоставленного контекста невозможно сформировать полный и дословный текст"));
        assertFalse(ScanOcrService.isRefusal("Заявка №219 к Договору № АБ-С-ИТ-2020"));
    }

    @Test
    void singlePageScanIsRecognizedAsWholeDocument() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), eq("скан.pdf"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("одна страница", Map.of()));

        String text = service().recognize("скан.pdf", pdf(""));

        assertEquals(ScanOcrService.OCR_PREFIX + " Документ «скан.pdf»:\nодна страница", text);
        assertFalse(text.contains("--- страница"));
    }

    @Test
    void pagesBeyondLimitAreMarkedNotRecognized() throws IOException {
        when(gigaChatClient.chatCompletionWithFile(anyString(), startsWith("page-"), any(), eq("application/pdf"), any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("стр", Map.of()));
        ScanOcrService service = service();
        ReflectionTestUtils.setField(service, "ocrMaxPages", 2);

        String text = service.recognize("скан.pdf", pdf("", "", ""));

        verify(gigaChatClient, times(2)).chatCompletionWithFile(anyString(), anyString(), any(), anyString(), any(), any(), any());
        assertTrue(text.contains("[страницы 3–3 не распознаны: превышен лимит страниц OCR 2]"));
    }

    @Test
    void ocrRequestsAreLimitedByParallelism() throws Exception {
        // 4 потока разбора × OCR давали 429 GigaChat: по умолчанию распознавание идёт по одному запросу за раз
        AtomicInteger active = new AtomicInteger();
        AtomicInteger maxActive = new AtomicInteger();
        when(gigaChatClient.chatCompletionWithFile(anyString(), anyString(), any(), eq("application/pdf"), any(), any(), any()))
                .thenAnswer(inv -> {
                    maxActive.accumulateAndGet(active.incrementAndGet(), Math::max);
                    Thread.sleep(60);
                    active.decrementAndGet();
                    return new GigaChatClient.ChatResult("текст", Map.of());
                });
        ScanOcrService service = service();
        byte[] scan = pdf("");
        ExecutorService pool = Executors.newFixedThreadPool(3);
        try {
            List<Future<String>> results = new ArrayList<>();
            for (int i = 0; i < 3; i++) {
                results.add(pool.submit(() -> service.recognize("скан.pdf", scan)));
            }
            for (Future<String> f : results) {
                assertTrue(f.get(5, TimeUnit.SECONDS).contains("текст"));
            }
        } finally {
            pool.shutdownNow();
        }
        assertEquals(1, maxActive.get());
    }
}
