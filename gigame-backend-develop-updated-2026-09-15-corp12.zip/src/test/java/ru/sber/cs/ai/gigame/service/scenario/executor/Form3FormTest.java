package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты разбора исходной Формы 3 участника: колонки по шапке, наследование
 * объединённых ячеек, даты Excel, суммы в формате реестра.
 */
class Form3FormTest {

    static final String HEADER = "Наименование компании/ (Ведущего партнера, в случае подачи заявки в составе коллективного участника)"
            + " | Наименование Исполниеля по договору (указывается в случае подачи заявки в составе коллективного участника)"
            + " | Потверждение взаимосвязи (аффилированости) с ведущим партнером | Признак, аффилированости согласно документации"
            + " | Наименование компании заказчика (указывается заказчик по договору)"
            + " | Вариант 1. Наименование рейтинга и номер позиции заказчика по договору"
            + " | Вариант 2. Опыт выполнения работ для одного Заказчика | Реквизиты договора (Указать номер и дату договора/соглашения)"
            + " | Реквизиты спецификации/ заказа к договору для каждой спецификации/заказа - отдельная строка"
            + " | Реквизиты акта выполенных работ/УПД+отчет к УПД для каждого акта - отдельная строка"
            + " | Дата подписания акта / выполенных работ / УПД"
            + " | В рамках выполнения работ используются инструменты и технологии Java"
            + " | В рамках выполнения работ используются инструменты и технологии Python"
            + " | Сумма выполненных работ по акту/УПД | Наименование компании заказчика (указывается заказчик по договору ген. подряда)"
            + " | Реквизиты договора между генеральным подрядчиком и заказчиком работ | Дополнительная информация";

    static final String LINES = "ООО \"ЭЦС\" | ООО \"ЭЦС\" | не применимо | нет | ООО «ЛУКОЙЛ-Интер-Кард» | не применимо"
            + " | ООО «ЛУКОЙЛ-Интер-Кард» | № F637/45 от 30.01.2025 | не применимо | Акт №1 выполненных работ от 28.02.2025"
            + " | 2025-02-28 00:00:00 | да | нет | 2495000 | не применимо | не применимо | Раздел 5 Договора\n"
            + " |  |  |  |  |  |  |  |  | Акт №2 выполненных работ от 30.06.2025 | 30.06.2025 | да | да | 9 980 000,50 |  |  | \n"
            + " |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | строка без реквизитов\n";

    @Test
    void headerWithoutActColumnIsNotAForm() {
        assertNull(Form3Form.parse(""));
        assertNull(Form3Form.parse("Критерий | Значение | Источник"));
        assertNotNull(Form3Form.parse(HEADER));
    }

    @Test
    void rowsInheritMergedCellsAndSkipLinesWithoutAct() {
        List<Form3Form.Row> rows = Form3Form.parse(HEADER).rows(LINES);

        assertEquals(2, rows.size());
        Form3Form.Row first = rows.get(0);
        assertEquals("ООО \"ЭЦС\"", first.company());
        assertEquals("ООО «ЛУКОЙЛ-Интер-Кард»", first.customer());
        assertEquals("№ F637/45 от 30.01.2025", first.contract());
        assertEquals("не применимо", first.spec());
        assertEquals("Акт №1 выполненных работ от 28.02.2025", first.act());
        assertEquals("28.02.2025", first.actDate());
        assertEquals("2495000.00", first.amount());
        assertEquals(1, first.claimedTechs().size());
        Form3Form.Row second = rows.get(1);
        assertEquals("ООО «ЛУКОЙЛ-Интер-Кард»", second.customer());
        assertEquals("№ F637/45 от 30.01.2025", second.contract());
        assertEquals("30.06.2025", second.actDate());
        assertEquals("9980000.50", second.amount());
        assertEquals(2, second.claimedTechs().size());
        assertEquals(Set.of("30.06.2025"), second.dates());
    }

    @Test
    void actDateFallsBackToLastDateOfActText() {
        assertEquals("14.04.2025", Form3Form.actDate("", "УПД № 0000101604 от 14.04.2025 к ЗНЗО № 100000037040"));
        assertEquals("15.04.2025", Form3Form.actDate("15.04.2025", "УПД № 0000101604 от 14.04.2025"));
        assertEquals("", Form3Form.actDate("", "без даты"));
    }

    @Test
    void wordDatesOfFormAreRecognized() {
        assertEquals("28.06.2024", Form3Form.actDate("28 июня 2024 г.", ""));
        assertTrue(Form3Form.dates("АКТ №1 по Заявке №10 к Договору № ШТ-2023 от «21» апреля 2023 г. | 28 июня 2024 г.")
                .containsAll(Set.of("21.04.2023", "28.06.2024")));
    }

    @Test
    void amountsAreNormalizedToRegistryFormat() {
        assertEquals("3709814.48", Form3Form.amount("3709814,48"));
        assertEquals("1063178.54", Form3Form.amount("1 063 178.54"));
        assertEquals("2495000.00", Form3Form.amount("2495000"));
        assertEquals("100.50", Form3Form.amount("100.5"));
        assertEquals("", Form3Form.amount("не применимо"));
    }

    @Test
    void updNumbersAreTakenWithoutLeadingZeros() {
        assertEquals(Set.of("101604", "118359"),
                Form3Form.numbers(Form3Form.UPD_NUMBER, "УПД № 0000101604 от 14.04.2025; УПД №118359"));
        assertEquals(Set.of("970", "72"), Form3Form.numbers(Form3Form.UPD_NUMBER, "УПД от 23.12.2025 №970; УПД от от 27.01.2026 №72"));
    }
}
