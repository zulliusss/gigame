package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class ScenarioRunRepositoryTest {

    Scenario scenario;
    @Autowired
    private ScenarioRunRepository scenarioRunRepository;
    @Autowired
    private ScenarioRepository scenarioRepository;

    @BeforeEach
    void setUp() {
        scenario = new Scenario();
        scenario.setName("Тестовый сценарий");
        scenario.setDescription("Тестовый сценарий");
        scenarioRepository.save(scenario);
    }

    @Test
    void testFindById_returnsScenarioRun() {
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("running");

        ScenarioRun saved = scenarioRunRepository.save(run);

        ScenarioRun found = scenarioRunRepository.findById(saved.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("running", found.getStatus());
    }

    @Test
    void testFindByScenarioIdOrderByStartedAtDesc_returnsSortedRuns() {
        // явные метки времени: два save подряд попадают в одну миллисекунду, и порядок по startedAt плавает
        ScenarioRun run1 = new ScenarioRun();
        run1.setScenarioId(scenario.getId());
        run1.setStatus("pending");
        run1.setStartedAt(OffsetDateTime.now().minusMinutes(2));
        scenarioRunRepository.save(run1);

        ScenarioRun run2 = new ScenarioRun();
        run2.setScenarioId(scenario.getId());
        run2.setStatus("completed");
        run2.setStartedAt(OffsetDateTime.now().minusMinutes(1));
        scenarioRunRepository.save(run2);

        List<ScenarioRun> result = scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenario.getId());

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("completed", result.get(0).getStatus());
        assertEquals("pending", result.get(1).getStatus());
    }

    @Test
    void testFindByScenarioId_returnsEmptyList_whenNoRuns() {
        List<ScenarioRun> result = scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(UUID.randomUUID());
        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("running");

        ScenarioRun saved = scenarioRunRepository.save(run);
        assertNotNull(saved.getId());

        scenarioRunRepository.delete(saved);
        scenarioRunRepository.flush();

        assertFalse(scenarioRunRepository.findById(saved.getId()).isPresent());
    }
}
