package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Тесты операции «рубли_из_процента»: расчёт порога в рублях из процента от НМЦД лота.
 */
class LotThresholdOpsTest {

    private static final String QUAL_1 = "ЛОТ №1 (Квалификационные требования)";
    private static final String QUAL_2 = "ЛОТ №2 (Квалификационные требования)";
    private static final String METHOD_2 = "ЛОТ №2 (Методические требования)";
    private static final String GENERAL = "Общая информация по закупке для всех лотов";

    private static Map<String, Object> row(String criterion, String value, String source, String section) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("критерий", criterion);
        m.put("значение", value);
        m.put("источник", source);
        m.put("секция", section);
        return m;
    }

    private static List<Object> kit5() {
        List<Object> rows = new ArrayList<>();
        rows.add(row("НМЦД лота №1", "51052924,00 руб.", "РАЗДЕЛ 1, пункт 10", GENERAL));
        rows.add(row("НМЦД лота №2", "43 553 218,80 руб.", "РАЗДЕЛ 1, пункт 10", GENERAL));
        rows.add(row(LotThresholdOps.DEFAULT_PERCENT, "100% от НМЦД", "РАЗДЕЛ 2", QUAL_1));
        rows.add(row(LotThresholdOps.DEFAULT_RUBLES, "51052924,00 руб.", "РАЗДЕЛ 2", QUAL_1));
        rows.add(row(LotThresholdOps.DEFAULT_PERCENT, "100% от НМЦД", "РАЗДЕЛ 2", QUAL_2));
        rows.add(row(LotThresholdOps.DEFAULT_RUBLES, "Нет", "РАЗДЕЛ 2", QUAL_2));
        rows.add(row(LotThresholdOps.DEFAULT_PERCENT, "Нет", "РАЗДЕЛ 6", METHOD_2));
        rows.add(row(LotThresholdOps.DEFAULT_RUBLES, "Нет", "РАЗДЕЛ 6", METHOD_2));
        return rows;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> at(List<Object> rows, int i) {
        return (Map<String, Object>) rows.get(i);
    }

    @Test
    void computesRublesForLotWhereModelWroteNo() {
        // Комплект 5: объединённая ячейка «100% от НМЦД» — у лота 2 модель написала «Нет», код считает 100% × НМЦД лота №2
        List<Object> rows = kit5();

        int done = LotThresholdOps.rublesFromPercent(Map.of(), rows);

        assertEquals(1, done);
        assertEquals("43553218,80 руб.", at(rows, 5).get("значение"));
        assertEquals("расчёт кодом: 100% от НМЦД лота №2 (РАЗДЕЛ 1, пункт 10)", at(rows, 5).get("источник"));
        assertEquals(LotThresholdOps.CALCULATED, at(rows, 5).get("достоверность"));
        // лот 1 с указанной суммой и методическая секция с «Нет» в проценте не тронуты
        assertEquals("51052924,00 руб.", at(rows, 3).get("значение"));
        assertNull(at(rows, 3).get("достоверность"));
        assertEquals("Нет", at(rows, 7).get("значение"));
    }

    @Test
    void computesFractionalPercentWithRounding() {
        List<Object> rows = new ArrayList<>();
        rows.add(row("НМЦД лота №3", "1 000 001 руб.", "п. 10", GENERAL));
        rows.add(row(LotThresholdOps.DEFAULT_PERCENT, "не менее 12,5 % от НМЦД лота", "Раздел 2", "ЛОТ №3 (Квалификационные требования)"));
        rows.add(row(LotThresholdOps.DEFAULT_RUBLES, "не извлечено моделью — проверить по документации", "добавлено кодом",
                "ЛОТ №3 (Квалификационные требования)"));

        assertEquals(1, LotThresholdOps.rublesFromPercent(Map.of(), rows));
        assertEquals("125000,13 руб.", at(rows, 2).get("значение"));
    }

    @Test
    void usesSingleNmcdWithoutLotNumberForOneLotPurchase() {
        List<Object> rows = new ArrayList<>();
        rows.add(row("НМЦД", "2 000 000,00 руб.", "п. 10", GENERAL));
        rows.add(row(LotThresholdOps.DEFAULT_PERCENT, "50% от НМЦД", "Раздел 2", QUAL_1));
        rows.add(row(LotThresholdOps.DEFAULT_RUBLES, "", "Раздел 2", QUAL_1));

        assertEquals(1, LotThresholdOps.rublesFromPercent(Map.of(), rows));
        assertEquals("1000000,00 руб.", at(rows, 2).get("значение"));
        assertEquals("расчёт кодом: 50% от НМЦД лота №1 (п. 10)", at(rows, 2).get("источник"));
    }

    @Test
    void leavesRowsWhenNmcdMissingOrPercentNotAboutNmcd() {
        List<Object> rows = new ArrayList<>();
        rows.add(row(LotThresholdOps.DEFAULT_PERCENT, "100% от НМЦД", "Раздел 2", QUAL_1));
        rows.add(row(LotThresholdOps.DEFAULT_RUBLES, "Нет", "Раздел 2", QUAL_1));
        assertEquals(0, LotThresholdOps.rublesFromPercent(Map.of(), rows));
        assertEquals("Нет", at(rows, 1).get("значение"));

        rows.add(0, row("НМЦД лота №1", "100,00 руб.", "п. 10", GENERAL));
        at(rows, 1).put("значение", "30% от цены договора");
        assertEquals(0, LotThresholdOps.rublesFromPercent(Map.of(), rows));
        assertEquals("Нет", at(rows, 2).get("значение"));
    }

    @Test
    void parsesAmountsWithSpacesAndKopecks() {
        assertEquals(new BigDecimal("51052924.00"), LotThresholdOps.parseAmount("51052924,00 руб."));
        assertEquals(new BigDecimal("43553218.80"), LotThresholdOps.parseAmount("43 553 218,8 руб."));
        assertEquals(new BigDecimal("1000.00"), LotThresholdOps.parseAmount("1 000 руб."));
        assertNull(LotThresholdOps.parseAmount("Нет"));
    }
}
