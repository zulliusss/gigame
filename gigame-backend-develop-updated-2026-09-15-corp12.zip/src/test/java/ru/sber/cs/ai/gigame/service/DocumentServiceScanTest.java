package ru.sber.cs.ai.gigame.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты постраничного детектора скана: страница-штамп ЭДО с текстом подписей
 * не должна скрывать скан, а текстовый документ не должен уходить в OCR.
 */
class DocumentServiceScanTest {

    private static final String LONG_TEXT = "Document signed and transferred via EDO operator, registration number 12345";
    private final DocumentService service = new DocumentService(null, null, null);

    private static byte[] pdf(String... pageTexts) throws IOException {
        try (PDDocument doc = new PDDocument()) {
            for (String text : pageTexts) {
                addPage(doc, text);
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private static void addPage(PDDocument doc, String text) throws IOException {
        PDPage page = new PDPage();
        doc.addPage(page);
        if (text.isEmpty()) {
            return;
        }
        try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
            cs.beginText();
            cs.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
            cs.newLineAtOffset(50, 700);
            cs.showText(text);
            cs.endText();
        }
    }

    @Test
    void textDocumentIsNotScan() throws IOException {
        assertFalse(service.isScanPdf(pdf(LONG_TEXT, LONG_TEXT), LONG_TEXT + "\n" + LONG_TEXT));
    }

    @Test
    void scanWithEdoStampPageIsScan() throws IOException {
        // две страницы-картинки акта и страница-штамп с текстом подписей: текст выше порога, но это скан
        assertTrue(service.isScanPdf(pdf("", "", LONG_TEXT), LONG_TEXT));
    }

    @Test
    void shortTextIsScanWithoutPageCheck() {
        assertTrue(service.isScanPdf(new byte[0], "  \n "));
    }

    @Test
    void unreadablePdfWithLongTextIsNotScan() {
        assertFalse(service.isScanPdf("not a pdf".getBytes(), LONG_TEXT));
    }

    @Test
    void recognizedTextKeepsParsedStamp() {
        assertEquals("[РАСПОЗНАНО] акт\n\nштамп ЭДО", DocumentService.withParsed("[РАСПОЗНАНО] акт", " штамп ЭДО \n"));
        assertEquals("[РАСПОЗНАНО] акт", DocumentService.withParsed("[РАСПОЗНАНО] акт", "  "));
    }
}
