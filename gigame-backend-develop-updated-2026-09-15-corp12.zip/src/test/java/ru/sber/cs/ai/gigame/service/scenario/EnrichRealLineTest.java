package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EnrichRealLineTest {
    @Test
    void realLine() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", \"ключ_регекс\": \"УПД\\s*№?\\s*0*(\\d{3,10})|№\\s*0*(\\d{3,4})\\s+от\\s+\\d{2}\\.\\d{2}\\.\\d{4}\", "
                + "\"ключ_регекс_данных\": \"0*(\\d{3,10})\", \"ключ_данных\": \"к6\", \"колонка_исходной\": \"к0\", \"ключ_уникален\": \"true\", "
                + "\"ключ_регекс_запас\": \"(?<!\\d)№\\s*(5\\d{6})(?!\\d)|Спецификаци\\S{0,3}\\s*№?\\s*(5\\d{6})(?!\\d)\", \"ключ_данных_запас\": \"к5\", "
                + "\"ключ_регекс_данных_запас\": \"(?<!\\d)(5\\d{6})(?!\\d)\", "
                + "\"запас_сумма_дата\": {\"поле_суммы\": \"к10\", \"поле_даты\": \"к6\"}, \"лишние_данные\": \"убрать\", "
                + "\"заглушки\": {\"к15\": \"документы не найдены\"}}}";
        Map<String, Object> a = new LinkedHashMap<>();
        a.put("к5", "5287362 от 01.04.2025"); a.put("к6", "УПД 0000101604 от 14.04.2025"); a.put("к10", "3709814.48"); a.put("к15", "зачтено");
        Map<String, Object> b = new LinkedHashMap<>();
        b.put("к5", "5287362 от 01.04.2025"); b.put("к6", "УПД 0000118359 от 18.07.2025"); b.put("к10", "4614647.28"); b.put("к15", "зачтено");
        List<Map<String, Object>> data = new ArrayList<>(List.of(a, b));
        String lines = "X | Спецификация 5287362 от 01.04.2025 | УПД № 0000101604 от 14.04.2025 Отчет | 15.04.2025 | Да | 3709814,28\n"
                + "X | Спецификация 5287362 от 01.04.2025 | УПД № 0000101604 от 18.07.2025  Отчет о выполненных работах к ЗНЗО № 100000037040 от 18.07.2025 | 15.07.2025 | Да | 4614647,28";
        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(data, rules, lines);
        assertEquals(2, out.size());
        assertEquals("УПД 0000118359 от 18.07.2025", out.get(1).get("к6"));
    }
}
