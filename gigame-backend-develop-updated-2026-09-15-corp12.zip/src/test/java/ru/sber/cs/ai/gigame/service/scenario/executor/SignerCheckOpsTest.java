package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.service.scenario.executor.SignerCheckOps.Person;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты сверки подписантов: ФИО из преамбулы (родительный падеж) против расшифровок подписей.
 */
class SignerCheckOpsTest {

    /** Преамбула и подписи договора комплекта 2 письма Комягина (ООО «Фабрика мебели МТМ»). */
    private static final String CONTRACT = "ДОГОВОР № 50005802429\nПубличное акционерное общество «Сбербанк России», ПАО Сбербанк, именуемое в дальнейшем "
            + "«Заказчик», в лице Директора СЦ «Снабжение» ОСЦ «Москва» ДСЦ Ларионова Евгения Алексеевича, действующего на основании Доверенности, с "
            + "одной стороны, и Общество с ограниченной ответственностью «Фабрика мебели МТМ», именуемое в дальнейшем «Поставщик», в лице Генерального "
            + "директора Щербаковой Елены Олеговны, действующего на основании Устава\n…\nОт Поставщика:\nГенеральный директор ООО «Фабрика мебели МТМ»\n"
            + "____________________ Е.О. Щербакова\nМ.П.\nОт Заказчика:\n______________________ Е.А. Ларионов\nКонтакты: Бакулин А. В.";

    private static ScenarioRunDoc contract(String text) {
        ScenarioRunDoc d = new ScenarioRunDoc("Договор.pdf", text);
        d.setDocClass("договор");
        return d;
    }

    @Test
    void matchesGenitivePreambleWithSignatures() {
        String report = SignerCheckOps.check(Map.of(), List.of(contract(CONTRACT)));

        assertTrue(report.contains("- Ларионова Е.А. (преамбула): СОВПАДАЕТ — подпись «Е.А. Ларионов»"), report);
        assertTrue(report.contains("- Щербаковой Е.О. (преамбула): СОВПАДАЕТ — подпись «Е.О. Щербакова»"), report);
        assertTrue(report.endsWith("{\"подписантов\": 2, \"расхождений\": 0, \"подпись_не_найдена\": 0}"), report);
    }

    @Test
    void reportsDifferentInitialsAndMissingSignature() {
        String text = CONTRACT.replace("Е.О. Щербакова", "Новикова Е.В.").replace("Е.А. Ларионов", "Е.С. Ларионов");

        String report = SignerCheckOps.check(Map.of(), List.of(contract(text)));

        assertTrue(report.contains("Ларионова Е.А. (преамбула): РАСХОЖДЕНИЕ — в подписи другие инициалы: Е.С. Ларионов"), report);
        assertTrue(report.contains("Щербаковой Е.О. (преамбула): ПОДПИСЬ НЕ НАЙДЕНА"), report);
        assertTrue(report.endsWith("{\"подписантов\": 2, \"расхождений\": 1, \"подпись_не_найдена\": 1}"), report);
    }

    @Test
    void parsesPeopleAndComparesSurnameStems() {
        assertEquals(List.of(new Person("Мохова", 'М', 'А')), SignerCheckOps.preamble("ИП, в лице \nМохова Михаила Александровича – [должность]"));
        assertEquals(List.of(new Person("Мохов", 'М', 'А'), new Person("Новикова", 'Е', 'В')),
                SignerCheckOps.signatures("/ М.А. Мохов/ и Новикова Е.В./"));
        assertTrue(SignerCheckOps.sameSurname("Щербаковой", "Щербакова"));
        assertTrue(SignerCheckOps.sameSurname("Ларионова", "Ларионов"));
        assertFalse(SignerCheckOps.sameSurname("Иванова", "Петров"));
        assertFalse(SignerCheckOps.sameSurname("Ли", "Ли"));
    }

    @Test
    void reportsWhenPreambleHasNoNames() {
        ScenarioRunDoc other = new ScenarioRunDoc("ТЗ.docx", CONTRACT);
        other.setDocClass("техническое_задание");

        String report = SignerCheckOps.check(Map.of(), List.of(contract("Договор без преамбулы, в лице ________"), other));

        assertTrue(report.contains("ФИО подписантов в преамбуле («в лице …») не найдены"), report);
        assertFalse(report.contains("ТЗ.docx"), report);
    }
}
