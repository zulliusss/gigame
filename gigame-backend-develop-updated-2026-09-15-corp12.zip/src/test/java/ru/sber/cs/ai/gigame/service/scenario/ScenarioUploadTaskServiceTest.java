package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты фоновой обработки загруженных документов (асинхронный режим загрузки).
 */
@ExtendWith(MockitoExtension.class)
class ScenarioUploadTaskServiceTest {

    @Mock
    private ScenarioService scenarioService;
    @Mock
    private DocsTextCacheService docsTextCacheService;

    @InjectMocks
    private ScenarioUploadTaskService service;

    private static List<ScenarioService.RawFile> rawFiles() {
        return List.of(new ScenarioService.RawFile("файл.txt", "текст".getBytes()));
    }

    /**
     * Дожидается выхода задачи из processing (короткий поллинг вместо sleep).
     */
    @SuppressWarnings("java:S2925") //"Thread.sleep" should not be used in tests
    private Map<String, Object> awaitFinished(UUID scenarioId) throws InterruptedException {
        for (int i = 0; i < 200; i++) {
            Map<String, Object> status = service.status(scenarioId);
            if (!ScenarioUploadTaskService.STATUS_PROCESSING.equals(status.get("status"))) {
                return status;
            }
            Thread.sleep(25);
        }
        return service.status(scenarioId);
    }

    @Test
    void start_parsesFilesInBackground_andCachesDocuments() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(scenarioId)).thenReturn(List.of());

        service.start(scenarioId, rawFiles(), false);
        Map<String, Object> status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.get("status"));
        assertEquals(1, status.get("documents"));
        assertFalse(service.isProcessing(scenarioId));
        verify(docsTextCacheService).clearCache(scenarioId);
        verify(docsTextCacheService).appendDocumentTexts(scenarioId,
                List.of("текст"), List.of("файл.txt"), List.of());
    }

    @Test
    void start_appendMode_doesNotClearCache() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenReturn(List.of(new DocumentText("файл.txt", "текст")));
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(scenarioId))
                .thenReturn(List.of("уже загруженный"));

        service.start(scenarioId, rawFiles(), true);
        Map<String, Object> status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.get("status"));
        assertEquals(2, status.get("documents"));
        verify(docsTextCacheService, never()).clearCache(scenarioId);
    }

    @Test
    void start_parsingError_marksTaskFailedWithMessage() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        when(scenarioService.parseFiles(anyList(), any()))
                .thenThrow(new FileException("Архив пуст или повреждён: битый.zip"));

        service.start(scenarioId, rawFiles(), false);
        Map<String, Object> status = awaitFinished(scenarioId);

        assertEquals(ScenarioUploadTaskService.STATUS_FAILED, status.get("status"));
        assertTrue(String.valueOf(status.get("error")).contains("битый.zip"));
        assertFalse(service.isProcessing(scenarioId));
    }

    @Test
    void start_whileProcessing_throwsFileException() throws InterruptedException {
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch releaseParsing = new CountDownLatch(1);
        lenient().when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            releaseParsing.await(5, TimeUnit.SECONDS);
            return List.of();
        });

        service.start(scenarioId, rawFiles(), false);
        assertTrue(service.isProcessing(scenarioId));
        var rawFiles = rawFiles();
        assertThrows(FileException.class, () -> service.start(scenarioId, rawFiles, false));
        releaseParsing.countDown();
        awaitFinished(scenarioId);
    }

    @Test
    void status_whileProcessing_reportsParsedCountAndOcrFiles() throws InterruptedException {
        // пока идёт разбор, статус показывает ход: сколько документов разобрано и какие сканы распознаются
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch releaseParsing = new CountDownLatch(1);
        lenient().when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            List<org.springframework.http.codec.ServerSentEvent<Map<String, Object>>> events = inv.getArgument(1);
            events.add(org.springframework.http.codec.ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_ocr", "file", "скан.pdf")).build());
            events.add(org.springframework.http.codec.ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_parsed", "file", "акт.pdf", "chars", 100)).build());
            releaseParsing.await(5, TimeUnit.SECONDS);
            return List.of();
        });

        service.start(scenarioId, rawFiles(), false);
        Map<String, Object> status = null;
        for (int i = 0; i < 100 && (status == null || !Integer.valueOf(1).equals(status.get("parsed"))); i++) {
            Thread.sleep(20);
            status = service.status(scenarioId);
        }
        assertEquals(1, status.get("parsed"));
        assertEquals(List.of("скан.pdf"), status.get("ocr"));
        assertTrue(String.valueOf(status.get("message")).startsWith("разобрано 1 из 1; распознаются сканы"), String.valueOf(status.get("message")));
        releaseParsing.countDown();
        assertEquals("", awaitFinished(scenarioId).get("message"));
    }

    @Test
    void status_withoutTask_returnsNone() {
        Map<String, Object> status = service.status(UUID.randomUUID());
        assertEquals(ScenarioUploadTaskService.STATUS_NONE, status.get("status"));
    }

    @Test
    void start_marksScenarioUploading_untilTaskFinishes() throws InterruptedException {
        // пока идёт разбор партии, кэш сценария помечен занятым (не вычищается по TTL), опрос статуса продлевает записи
        UUID scenarioId = UUID.randomUUID();
        CountDownLatch release = new CountDownLatch(1);
        when(scenarioService.parseFiles(anyList(), any())).thenAnswer(inv -> {
            release.await(5, TimeUnit.SECONDS);
            return List.of(new DocumentText("файл.txt", "текст"));
        });
        when(scenarioService.getMaxDocumentsPerRun()).thenReturn(500);
        when(docsTextCacheService.getCachedDocumentTexts(scenarioId)).thenReturn(List.of());

        service.start(scenarioId, rawFiles(), true);
        verify(docsTextCacheService).markUploading(scenarioId);
        verify(docsTextCacheService, never()).unmarkUploading(scenarioId);
        service.status(scenarioId);
        verify(docsTextCacheService).touch(scenarioId);

        release.countDown();
        Map<String, Object> status = awaitFinished(scenarioId);
        assertEquals(ScenarioUploadTaskService.STATUS_DONE, status.get("status"));
        verify(docsTextCacheService).unmarkUploading(scenarioId);
    }
}
