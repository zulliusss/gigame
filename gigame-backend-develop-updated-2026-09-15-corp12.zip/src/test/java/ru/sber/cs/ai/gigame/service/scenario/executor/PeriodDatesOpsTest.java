package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Тесты операции «даты_из_периода»: календарные даты периода опыта из формулировки и даты подачи заявок.
 */
class PeriodDatesOpsTest {

    private static final String QUAL = "Период опыта участника по квалификационным требованиям";
    private static final String METHOD = "Период опыта по методике оценки";
    private static final String START = "Дата начала срока подачи заявок";
    private static final String END = "Дата окончания срока подачи заявок";

    private static Map<String, Object> row(String criterion, String value) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("критерий", criterion);
        m.put("значение", value);
        m.put("источник", "модель");
        return m;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> at(List<Object> rows, int i) {
        return (Map<String, Object>) rows.get(i);
    }

    private static List<Object> rows(String qualWording, String qualDates, String methodWording, String methodDates) {
        List<Object> rows = new ArrayList<>();
        rows.add(row(START, "17.09.2025"));
        rows.add(row(END, "24.09.2025 18-00 (время московское)"));
        rows.add(row(QUAL, qualWording));
        rows.add(row(QUAL + " — календарные даты", qualDates));
        rows.add(row(METHOD, methodWording));
        rows.add(row(METHOD + " — календарные даты", methodDates));
        return rows;
    }

    @Test
    void replacesModelDatesBySubmissionStartMinusTerm() {
        // ЗП 8100286906: модель перенесла даты из примера промпта — «с 08.04.2025 по 08.10.2025»
        List<Object> rows = rows("за последние 3 (три) года до даты публикации документации", "с 08.04.2023 по 08.04.2026",
                "за последние 6 (шесть) месяцев до даты публикации закупочной процедуры", "с 08.04.2025 по 08.10.2025");

        assertEquals(2, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 17.09.2022 по 17.09.2025", at(rows, 3).get("значение"));
        assertEquals("с 17.03.2025 по 17.09.2025", at(rows, 5).get("значение"));
        assertEquals("расчёт кодом по строке «" + METHOD + "»: 6 (шесть) месяцев до даты начала срока подачи заявок (17.09.2025)",
                at(rows, 5).get("источник"));
        assertEquals(PeriodMonthsOps.CALCULATED, at(rows, 5).get("достоверность"));
    }

    @Test
    void countsFromSubmissionEndWhenWordingSaysSo() {
        List<Object> rows = rows("нет", "нет",
                "акты подписаны не ранее 12 (двенадцати) месяцев до даты окончания срока подачи заявок", "?");

        assertEquals(1, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 24.09.2024 по 24.09.2025", at(rows, 5).get("значение"));
        assertEquals("нет", at(rows, 3).get("значение"));
    }

    @Test
    void leavesExplicitOrUnnumberedPeriodsAndMissingBaseDate() {
        List<Object> rows = rows("с 01.01.2021 по 09.09.2024", "с 01.01.2021 по 09.09.2024",
                "не указано в документации, требуется решение закупщика", "не указано в документации, требуется решение закупщика");

        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 01.01.2021 по 09.09.2024", at(rows, 3).get("значение"));
        assertNull(at(rows, 5).get("достоверность"));

        List<Object> noStart = rows("за последние 2 года до даты публикации", "?", "нет", "нет");
        noStart.remove(0);
        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), noStart));
        assertEquals("?", at(noStart, 2).get("значение"));
    }

    @Test
    void ignoresAbsurdTermsAndDigitsInsideLongNumbers() {
        List<Object> rows = rows("за последние 300 лет до даты публикации", "?",
                "опыт по договору № 1234 месяца до даты публикации", "?");

        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("?", at(rows, 3).get("значение"));
        assertEquals("?", at(rows, 5).get("значение"));
    }
}
