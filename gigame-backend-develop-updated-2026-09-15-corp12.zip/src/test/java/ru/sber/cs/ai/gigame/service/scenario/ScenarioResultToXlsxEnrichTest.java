package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Тесты кодовой выверки чисел по эталону и слоя записи поверх исходной формы.
 */
class ScenarioResultToXlsxEnrichTest {

    private static final String CHECK_RULES =
            "{\"сверка_чисел\": {\"из_узла\": \"Суммы\", \"колонки\": [\"к9\"]}}";

    private static final String UNIQUE_KEY_RULES =
            "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                    + "\"ключ_регекс\": \"УПД\\\\s*№?\\\\s*0*(\\\\d{5,10})\", "
                    + "\"ключ_регекс_данных\": \"0*(\\\\d{5,10})\", \"ключ_данных\": \"к6\", "
                    + "\"колонка_исходной\": \"к0\", \"ключ_уникален\": \"true\"}}";

    private static Map<String, Object> row(String key, Object value) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(key, value);
        return map;
    }

    @Test
    void restoresLostDigitFromSingleReference() {
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к9", "194539,52")));

        ScenarioResultToXlsx.fixNumbersAgainstReference(data, CHECK_RULES,
                Set.of("1945390.52"));

        assertEquals("1945390.52", data.get(0).get("к9"));
    }

    @Test
    void keepsValueWhenSeveralCandidates() {
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к9", "194539,52")));

        ScenarioResultToXlsx.fixNumbersAgainstReference(data, CHECK_RULES,
                Set.of("1945390.52", "1945439.52"));

        assertEquals("194539,52", data.get(0).get("к9"));
    }

    @Test
    void canonicalMatchIsNotTouched() {
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к9", "3845539,4")));

        ScenarioResultToXlsx.fixNumbersAgainstReference(data, CHECK_RULES,
                Set.of("3845539.40"));

        assertEquals("3845539,4", data.get(0).get("к9"));
    }

    @Test
    void enrichKeepsEveryFormLineAndStubsUnmatched() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"(5\\\\d{6})\", \"ключ_данных\": \"к5\", "
                + "\"колонка_исходной\": \"к0\", \"заглушки\": {\"к9\": \"Нет данных\"}}}";
        List<Map<String, Object>> data = new ArrayList<>();
        Map<String, Object> matched = new LinkedHashMap<>();
        matched.put("к5", "5350904 (этап 1)");
        matched.put("к9", "6747168.30");
        data.add(matched);
        String formLines = "Спецификация 5350904 от 04.06.2025\nСпецификация 5311130 от 25.04.2025";

        List<Map<String, Object>> out =
                ScenarioResultToXlsx.enrichAgainstForm(data, rules, formLines);

        assertEquals(2, out.size());
        assertEquals("6747168.30", out.get(0).get("к9"));
        assertEquals("Нет данных", out.get(1).get("к9"));
        assertEquals("Спецификация 5311130 от 25.04.2025", out.get(1).get("к0"));
    }

    @Test
    void enrichAppendsDataRowsMissingInForm() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"(5\\\\d{6})\", \"ключ_данных\": \"к5\", "
                + "\"колонка_исходной\": \"к0\"}}";
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к5", "5242489")));

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(
                data, rules, "Спецификация 5311130 от 25.04.2025");

        assertEquals(2, out.size());
        assertEquals("нет в исходной форме", out.get(1).get("к0"));
    }

    @Test
    void enrichExpandsSourceLineIntoColumnsWithHeaderRow() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"(5\\\\d{6})\", \"ключ_данных\": \"к5\", "
                + "\"колонка_исходной\": \"к0\", \"развернуть_исходную\": \"true\", "
                + "\"разделитель\": \"|\"}}";
        List<Map<String, Object>> data = new ArrayList<>();
        String formLines = "Компания | Договор | Спецификация\n"
                + "ООО Ромашка | № 12 от 01.01.2025 | Спецификация 5350904";

        List<Map<String, Object>> out =
                ScenarioResultToXlsx.enrichAgainstForm(data, rules, formLines);

        // первая строка — шапка исходной формы, развёрнутая по колонкам
        assertEquals("Компания", out.get(0).get("к0_01"));
        assertEquals("Договор", out.get(0).get("к0_02"));
        // строка данных развёрнута в те же динамические колонки, к0 удалена
        assertEquals("ООО Ромашка", out.get(1).get("к0_01"));
        assertEquals("Спецификация 5350904", out.get(1).get("к0_03"));
        assertEquals(null, out.get(1).get("к0"));
    }

    @Test
    void enrichKeepsUnkeyedFormLines() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"(5\\\\d{6})\", \"ключ_данных\": \"к5\", "
                + "\"колонка_исходной\": \"к0\"}}";
        String formLines = """
                Строка без реквизитов: акт б/н
                Спецификация 5350904 от 04.06.2025
                Примечание: суммы включают НДС
                """;

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(
                new ArrayList<>(), rules, formLines);

        // все три строки формы сохранены на своих местах
        assertEquals(3, out.size());
        assertEquals("Строка без реквизитов: акт б/н", out.get(0).get("к0"));
        assertEquals("Спецификация 5350904 от 04.06.2025", out.get(1).get("к0"));
        assertEquals("Примечание: суммы включают НДС", out.get(2).get("к0"));
    }

    @Test
    void enrichMergesAgreeingDuplicateKeyRows() {
        List<Map<String, Object>> data = new ArrayList<>();
        Map<String, Object> full = new LinkedHashMap<>();
        full.put("к6", "УПД № 0000100275 от 08.04.2025");
        full.put("к8", "1234567.89");
        full.put("к10", "нет данных");
        data.add(full);
        Map<String, Object> duplicate = new LinkedHashMap<>();
        duplicate.put("к6", "УПД № 0000100275 от 08.04.2025");
        duplicate.put("к10", "зачтено");
        data.add(duplicate);

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(
                data, UNIQUE_KEY_RULES, "УПД № 0000100275 от 08.04.2025");

        // одна строка формы, дубль не породил строку «нет в исходной форме»
        assertEquals(1, out.size());
        // заполненное поле не перетёрто, заглушечное — дозаполнено из дубля
        assertEquals("1234567.89", out.get(0).get("к8"));
        assertEquals("зачтено", out.get(0).get("к10"));
    }

    @Test
    void enrichKeepsConflictingRowsWithReusedKeyNumber() {
        List<Map<String, Object>> data = new ArrayList<>();
        Map<String, Object> first = new LinkedHashMap<>();
        first.put("к6", "УПД № 0000101604 от 14.04.2025");
        first.put("к8", "100.00");
        data.add(first);
        Map<String, Object> second = new LinkedHashMap<>();
        second.put("к6", "УПД № 0000101604 от 18.07.2025");
        second.put("к8", "200.00");
        data.add(second);
        String formLines = "УПД № 0000101604 от 14.04.2025\nУПД № 0000101604 от 18.07.2025";

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(
                data, UNIQUE_KEY_RULES, formLines);

        // переиспользованный номер — разные документы: каждой строке формы своя запись
        assertEquals(2, out.size());
        assertEquals("100.00", out.get(0).get("к8"));
        assertEquals("200.00", out.get(1).get("к8"));
    }

    @Test
    void enrichFallsBackToSpecificationKeyWhenNoUpdInFormLine() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"УПД\\s*№?\\s*0*(\\d{5,10})\", "
                + "\"ключ_регекс_данных\": \"0*(\\d{5,10})\", \"ключ_данных\": \"к6\", "
                + "\"ключ_регекс_запас\": \"(?<!\\d)№\\s*(5\\d{6})(?!\\d)\", "
                + "\"ключ_данных_запас\": \"к5\", "
                + "\"ключ_регекс_данных_запас\": \"(?<!\\d)(5\\d{6})(?!\\d)\", "
                + "\"колонка_исходной\": \"к0\"}}";
        List<Map<String, Object>> data = new ArrayList<>();
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("к5", "№ 5219366 от 29.01.2025");
        row.put("к6", "УПД № 604 от 31.03.2025");
        row.put("к8", "1883796.48");
        data.add(row);
        String formLine = "ООО ТОТ | ПАО Сбербанк | № 4622976 от 30.05.2023 г. | № 5219366 от 29.01.2025 | № 604 от 31.03.2025";

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(data, rules, formLine);

        // строка формы получила данные по спецификации, хвоста «нет в исходной форме» нет
        assertEquals(2, out.size());
        assertEquals("1883796.48", out.get(1).get("к8"));
    }

    @Test
    void dynamicColumnsTakeTitlesFromDonorHeaderLine() {
        String rules = "{\"колонки\": [{\"ключ_префикс\": \"к0_\", \"заголовок_префикс\": \"Ф-\", "
                + "\"заголовки\": [\"Из списка\"]}], "
                + "\"обогащение_формы\": {\"из_узла\": \"Форма\", \"ключ_регекс\": \"(5\\\\d{6})\", "
                + "\"ключ_данных\": \"к5\", \"колонка_исходной\": \"к0\", "
                + "\"развернуть_исходную\": \"true\", \"разделитель\": \"|\"}}";
        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(
                new ArrayList<>(), rules, "ООО Ромашка | 5350904", "Наименование компании | Реквизиты спецификации");

        // первая строка — шапка с меткой, развёрнутая по колонкам
        assertEquals("да", out.get(0).get(ScenarioResultToXlsx.HEADER_MARK));
        assertEquals("Наименование компании", out.get(0).get("к0_01"));
        ScenarioResultToXlsx.XlsxTemplate template = ScenarioResultToXlsx.XlsxTemplate.parse(rules);
        List<ScenarioResultToXlsx.XlsxTemplate.XlsxColumn> columns =
                template.expandColumns(out.subList(1, out.size()), out.get(0));
        // шапка-донор приоритетнее списка «заголовки»
        assertEquals("Наименование компании", columns.get(0).title());
        assertEquals("Реквизиты спецификации", columns.get(1).title());
    }

    @Test
    void dynamicColumnsTakeTitlesFromConfiguredList() {
        String rules = "{\"колонки\": [{\"ключ_префикс\": \"к0_\", \"заголовок_префикс\": \"Ф-\", "
                + "\"заголовки\": [\"Наименование компании\", \"\"]}]}";
        ScenarioResultToXlsx.XlsxTemplate template = ScenarioResultToXlsx.XlsxTemplate.parse(rules);
        List<Map<String, Object>> data = new ArrayList<>();
        Map<String, Object> line = new LinkedHashMap<>();
        line.put("к0_01", "ООО Ромашка");
        line.put("к0_02", "№ 12 от 01.01.2025");
        line.put("к0_03", "Спецификация 5350904");
        data.add(line);

        List<ScenarioResultToXlsx.XlsxTemplate.XlsxColumn> columns =
                template.expandColumns(data);

        // подпись из списка «заголовки», при пустом или отсутствующем элементе — техническая
        assertEquals(3, columns.size());
        assertEquals("Наименование компании", columns.get(0).title());
        assertEquals("Ф-02", columns.get(1).title());
        assertEquals("Ф-03", columns.get(2).title());
    }

    @Test
    void enrichMatchesByAmountAndDateWhenActNumberIsWrong() {
        // участник написал в форме номер заказа вместо номера УПД: пара находится по сумме и дате акта
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"УПД\\\\s*№?\\\\s*0*(\\\\d{3,10})\", \"ключ_регекс_данных\": \"0*(\\\\d{3,10})\", "
                + "\"ключ_данных\": \"к6\", \"колонка_исходной\": \"к0\", "
                + "\"запас_сумма_дата\": {\"поле_суммы\": \"к10\", \"поле_даты\": \"к6\"}, "
                + "\"заглушки\": {\"к15\": \"документы не найдены\"}}}";
        Map<String, Object> real = new LinkedHashMap<>();
        real.put("к6", "УПД 0000151748 от 02.12.2025");
        real.put("к10", "950074.44");
        real.put("к15", "зачтено");
        List<Map<String, Object>> data = new ArrayList<>(List.of(real));
        String formLines = "ООО Ромашка | УПД № 100000049520 от 02.12.2025 | 17.12.2025 | 950 074,44";

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(data, rules, formLines);

        assertEquals(1, out.size());
        assertEquals("зачтено", out.get(0).get("к15"));
        assertEquals("УПД 0000151748 от 02.12.2025", out.get(0).get("к6"));
    }

    @Test
    void enrichDropsDataRowsMissingInFormWhenConfigured() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"(5\\\\d{6})\", \"ключ_данных\": \"к5\", "
                + "\"колонка_исходной\": \"к0\", \"лишние_данные\": \"убрать\"}}";
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к5", "5242489"), row("к5", "5311130")));

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(
                data, rules, "Спецификация 5311130 от 25.04.2025");

        assertEquals(1, out.size());
        assertEquals("5311130", out.get(0).get("к5"));
    }

    @Test
    void enrichMatchesByExactSourceLineBeforeKeys() {
        // строки без номера УПД/спецификации (акты «№1 от даты») сопоставляются точно по исходной строке формы
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"УПД\\\\s*№?\\\\s*0*(\\\\d{5,10})\", \"ключ_регекс_данных\": \"0*(\\\\d{5,10})\", "
                + "\"ключ_данных\": \"к6\", \"ключ_строка\": \"исходная_строка\", \"колонка_исходной\": \"к0\", "
                + "\"заглушки\": {\"к15\": \"документы не найдены\"}, \"лишние_данные\": \"убрать\"}}";
        String line1 = "ООО | Спецификация № 5497573\u00A0 от 31.10.2025 | Акт №1 выполненных работ от 28.02.2025 | 2495000";
        String line2 = "ООО | Акт №2 выполненных работ от 30.06.2025 | 9980000";
        // в данных строка нормализована (неразрывный пробел → пробел), в форме — исходная: ключ всё равно совпадает
        Map<String, Object> first = new LinkedHashMap<>(Map.of("к6", "Акт №1 выполненных работ от 28.02.2025",
                "к15", "заказчик вне рейтинга", "исходная_строка", line1.replace('\u00A0', ' ')));
        Map<String, Object> second = new LinkedHashMap<>(Map.of("к6", "Акт №2 выполненных работ от 30.06.2025",
                "к15", "акт не в периоде", "исходная_строка", line2));
        List<Map<String, Object>> data = new ArrayList<>(List.of(second, first));

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(data, rules, line1 + "\n" + line2);

        assertEquals(2, out.size());
        assertEquals("заказчик вне рейтинга", out.get(0).get("к15"));
        assertEquals("акт не в периоде", out.get(1).get("к15"));
        assertEquals(null, out.get(0).get("исходная_строка"));
        assertEquals(line1, out.get(0).get("к0"));
    }
}
