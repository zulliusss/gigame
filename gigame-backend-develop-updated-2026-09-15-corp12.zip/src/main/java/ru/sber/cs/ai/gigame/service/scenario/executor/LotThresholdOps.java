package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «рубли_из_процента» узла «Трансформация»: порог сопоставимого опыта
 * в рублях считается кодом из процента от НМЦД лота.
 * <p>
 * В таблице Раздела 2 ячейка «100% от НМЦД» бывает объединена по строкам
 * нескольких лотов — при разборе docx она достаётся только первому лоту, и
 * модель в цикле по лотам то восстанавливает порог из общего текста, то пишет
 * «Нет». Если в секции лота строка «(процент)» содержит «N% …», а строка
 * «(в рублях)» пуста, «Нет» или «не извлечено», значение считается как
 * N% × «НМЦД лота №K» из общего блока (либо единственной строки «НМЦД» без
 * номера лота). Строки, где рубли уже указаны, не трогаются.
 * <pre>
 * {"оп": "рубли_из_процента", "секция_шаблон": "^ЛОТ\\s*№\\s*(\\d+)",
 *  "процент": "Минимальный объём сопоставимого опыта (процент)",
 *  "рубли": "Минимальный объём сопоставимого опыта (в рублях)",
 *  "нмцд_шаблон": "^НМЦД(?:\\s+лота\\s*№?\\s*(\\d+))?\\s*$"}
 * </pre>
 */
final class LotThresholdOps {

    /** Секция лота по умолчанию: группа 1 — номер лота. */
    static final String DEFAULT_SECTION = "^ЛОТ\\s*№\\s*(\\d+)";
    /** Критерий процента по умолчанию. */
    static final String DEFAULT_PERCENT = "Минимальный объём сопоставимого опыта (процент)";
    /** Критерий рублей по умолчанию. */
    static final String DEFAULT_RUBLES = "Минимальный объём сопоставимого опыта (в рублях)";
    /** Критерий НМЦД общего блока по умолчанию: группа 1 — номер лота (может отсутствовать). */
    static final String DEFAULT_NMCD = "^НМЦД(?:\\s+лота\\s*№?\\s*(\\d+))?\\s*$";
    /** Пометка достоверности рассчитанной строки. */
    static final String CALCULATED = "рассчитано кодом";
    private static final Pattern PERCENT = Pattern.compile("(\\d{1,3}(?:[.,]\\d+)?)\\s*%");
    private static final Pattern AMOUNT = Pattern.compile("(\\d[\\d\\s\\u00A0]*)(?:[.,](\\d{1,2}))?");
    private static final Pattern DIGIT = Pattern.compile("\\d");
    private static final BigDecimal HUNDRED = new BigDecimal(100);
    private static final char KEY_SEPARATOR = '\u0001';

    private LotThresholdOps() {
    }

    /**
     * Рассчитывает рубли из процента по секциям лотов; строки правятся на месте.
     *
     * @param op   параметры операции
     * @param rows строки критериев (объекты с полями «критерий», «значение», «секция»)
     * @return число рассчитанных строк
     */
    static int rublesFromPercent(Map<String, Object> op, List<Object> rows) {
        Pattern section = compile(op, "секция_шаблон", DEFAULT_SECTION);
        Pattern nmcd = compile(op, "нмцд_шаблон", DEFAULT_NMCD);
        String percentName = String.valueOf(op.getOrDefault("процент", DEFAULT_PERCENT)).strip();
        String rublesName = String.valueOf(op.getOrDefault("рубли", DEFAULT_RUBLES)).strip();
        Map<String, Map<String, Object>> nmcdByLot = nmcdByLot(rows, nmcd);
        Map<String, List<Map<String, Object>>> sections = sectionsByLot(rows, section);
        int done = 0;
        for (Map.Entry<String, List<Map<String, Object>>> e : sections.entrySet()) {
            Map<String, Object> nmcdRow = nmcdByLot.get(lotOf(e.getKey()));
            if (nmcdRow == null && nmcdByLot.size() == 1) {
                nmcdRow = nmcdByLot.values().iterator().next();
            }
            if (nmcdRow != null && fill(e.getValue(), e.getKey(), nmcdRow, percentName, rublesName)) {
                done++;
            }
        }
        return done;
    }

    private static Pattern compile(Map<String, Object> op, String key, String fallback) {
        return Pattern.compile(String.valueOf(op.getOrDefault(key, fallback)), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    }

    /** Строки НМЦД общего блока по номеру лота (пустой ключ — НМЦД без номера лота). */
    @SuppressWarnings("unchecked")
    private static Map<String, Map<String, Object>> nmcdByLot(List<Object> rows, Pattern nmcd) {
        Map<String, Map<String, Object>> byLot = new LinkedHashMap<>();
        for (Object o : rows) {
            if (!(o instanceof Map<?, ?> m)) {
                continue;
            }
            Matcher matcher = nmcd.matcher(text(m.get("критерий")));
            if (matcher.find() && parseAmount(text(m.get("значение"))) != null) {
                String lot = matcher.groupCount() >= 1 && matcher.group(1) != null ? matcher.group(1) : "";
                byLot.putIfAbsent(lot, (Map<String, Object>) m);
            }
        }
        return byLot;
    }

    /** Строки секций лотов, сгруппированные по «номер лота + имя секции». */
    @SuppressWarnings("unchecked")
    private static Map<String, List<Map<String, Object>>> sectionsByLot(List<Object> rows, Pattern section) {
        Map<String, List<Map<String, Object>>> result = new LinkedHashMap<>();
        for (Object o : rows) {
            if (!(o instanceof Map<?, ?> m)) {
                continue;
            }
            String name = text(m.get("секция"));
            Matcher matcher = section.matcher(name);
            if (matcher.find()) {
                String lot = matcher.groupCount() >= 1 && matcher.group(1) != null ? matcher.group(1) : "";
                result.computeIfAbsent(lot + KEY_SEPARATOR + name, k -> new ArrayList<>()).add((Map<String, Object>) m);
            }
        }
        return result;
    }

    /** Номер лота из ключа секции («номер + разделитель + имя секции»). */
    private static String lotOf(String sectionKey) {
        return sectionKey.substring(0, sectionKey.indexOf(KEY_SEPARATOR));
    }

    /** Заполняет строку рублей секции, если процент задан, а рубли пусты. */
    private static boolean fill(List<Map<String, Object>> section, String lotKey, Map<String, Object> nmcdRow,
                                String percentName, String rublesName) {
        Map<String, Object> percentRow = find(section, percentName);
        Map<String, Object> rublesRow = find(section, rublesName);
        if (percentRow == null || rublesRow == null || DIGIT.matcher(text(rublesRow.get("значение"))).find()) {
            return false;
        }
        String percentText = text(percentRow.get("значение"));
        Matcher pm = PERCENT.matcher(percentText);
        if (!pm.find() || percentText.toLowerCase(Locale.ROOT).contains("договор")) {
            return false;
        }
        BigDecimal nmcd = parseAmount(text(nmcdRow.get("значение")));
        BigDecimal percent = new BigDecimal(pm.group(1).replace(',', '.'));
        BigDecimal rubles = nmcd.multiply(percent).divide(HUNDRED, 2, RoundingMode.HALF_UP);
        String lot = lotOf(lotKey);
        rublesRow.put("значение", rubles.toPlainString().replace('.', ',') + " руб.");
        rublesRow.put("источник", "расчёт кодом: " + pm.group(0).replace(" ", "") + " от НМЦД лота"
                + (lot.isEmpty() ? "" : " №" + lot) + " (" + text(nmcdRow.get("источник")) + ")");
        rublesRow.put("достоверность", CALCULATED);
        return true;
    }

    private static Map<String, Object> find(List<Map<String, Object>> section, String criterion) {
        for (Map<String, Object> row : section) {
            if (criterion.equalsIgnoreCase(text(row.get("критерий")).strip())) {
                return row;
            }
        }
        return null;
    }

    /** Сумма из записи вида «51 052 924,00 руб.»; {@code null}, если чисел нет. */
    static BigDecimal parseAmount(String raw) {
        Matcher m = AMOUNT.matcher(raw);
        if (!m.find()) {
            return null;
        }
        String whole = m.group(1).replaceAll("[\\s\\u00A0]", "");
        String frac = m.group(2) == null ? "00" : (m.group(2) + "0").substring(0, 2);
        return new BigDecimal(whole + "." + frac);
    }

    private static String text(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
