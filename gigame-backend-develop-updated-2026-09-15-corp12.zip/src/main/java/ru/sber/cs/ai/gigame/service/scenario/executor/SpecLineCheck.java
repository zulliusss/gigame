package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Проверка одной строки характеристики из таблицы требований по тексту позиции в договоре.
 * <p>
 * Порядок: дословное вхождение (без учёта пробелов, переносов, регистра и знаков препинания) →
 * все слова и числа строки по порядку с небольшими разрывами (номер страницы, обрыв колонки PDF) →
 * числовой порог «не менее / не более N»: в договоре после названия характеристики берётся число
 * и сравнивается с порогом. Иначе строка считается не найденной — её смысл проверяет модель.
 */
final class SpecLineCheck {

    /** Наибольший разрыв (в нормализованных символах) между соседними словами строки в договоре. */
    static final int MAX_GAP = 80;
    private static final Pattern CONDITION = Pattern.compile("не\\s+(менее|ниже|меньше|более|выше|больше)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern NUMBER = Pattern.compile("(\\d{1,3}(?:[ \\u00A0]\\d{3})+|\\d+)(?:[.,](\\d+))?\\s*(тыс)?", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Сколько символов исходного текста после названия характеристики просматривается в поисках значения. */
    private static final int VALUE_WINDOW = 120;

    private SpecLineCheck() {
    }

    /** Итог проверки строки. */
    enum Status {
        EXACT, GAPPED, THRESHOLD_OK, THRESHOLD_FAIL, MISSING
    }

    /** Итог проверки: статус и пояснение (пороги или слова, которых нет в договоре). */
    record LineResult(Status status, String detail) {
    }

    /** Участок нормализованного текста договора [from, to). */
    record Block(int from, int to) {
    }

    /**
     * Проверяет строку характеристики по участкам договора, относящимся к позиции.
     *
     * @param line     строка характеристики из таблицы требований
     * @param contract нормализованный текст договора
     * @param blocks   участки договора, относящиеся к позиции
     * @return итог проверки
     */
    static LineResult check(String line, NormalizedText contract, List<Block> blocks) {
        String norm = NormalizedText.normalize(line);
        List<String> tokens = NormalizedText.tokens(line);
        for (Block b : blocks) {
            if (contract.norm().substring(b.from(), b.to()).contains(norm)) {
                return new LineResult(Status.EXACT, "");
            }
        }
        for (Block b : blocks) {
            if (sequenceEnd(contract.norm(), tokens, b) >= 0) {
                return new LineResult(Status.GAPPED, "");
            }
        }
        LineResult threshold = threshold(line, contract, blocks);
        return threshold != null ? threshold : new LineResult(Status.MISSING, missingWords(tokens, contract, blocks));
    }

    /**
     * Конец последовательного вхождения слов в участке (с разрывами не больше {@link #MAX_GAP}).
     *
     * @param norm   нормализованный текст
     * @param tokens слова по порядку
     * @param block  участок поиска
     * @return позиция после последнего слова либо -1
     */
    static int sequenceEnd(String norm, List<String> tokens, Block block) {
        if (tokens.isEmpty()) {
            return -1;
        }
        int start = norm.indexOf(tokens.get(0), block.from());
        while (start >= 0 && start < block.to()) {
            int end = followFrom(norm, tokens, start + tokens.get(0).length(), block.to());
            if (end >= 0) {
                return end;
            }
            start = norm.indexOf(tokens.get(0), start + 1);
        }
        return -1;
    }

    private static int followFrom(String norm, List<String> tokens, int pos, int limit) {
        int cursor = pos;
        for (int i = 1; i < tokens.size(); i++) {
            int at = norm.indexOf(tokens.get(i), cursor);
            if (at < 0 || at - cursor > MAX_GAP || at + tokens.get(i).length() > limit) {
                return -1;
            }
            cursor = at + tokens.get(i).length();
        }
        return cursor;
    }

    private static LineResult threshold(String line, NormalizedText contract, List<Block> blocks) {
        Matcher cm = CONDITION.matcher(line);
        if (!cm.find()) {
            return null;
        }
        Double required = number(line.substring(cm.end()));
        List<String> label = NormalizedText.tokens(line.substring(0, cm.start()));
        if (required == null || label.isEmpty()) {
            return null;
        }
        boolean minimum = isMinimum(cm.group(1));
        for (Block b : blocks) {
            int end = sequenceEnd(contract.norm(), label, b);
            if (end >= 0) {
                return compare(contract.snippet(end, end + VALUE_WINDOW, VALUE_WINDOW), required, minimum);
            }
        }
        return null;
    }

    private static LineResult compare(String contractValue, double required, boolean minimum) {
        Matcher cm = CONDITION.matcher(contractValue);
        boolean conditioned = cm.find() && cm.start() < 3;
        String valueText = conditioned ? contractValue.substring(cm.end()) : contractValue;
        Double actual = number(valueText);
        if (actual == null || conditioned && isMinimum(cm.group(1)) != minimum) {
            return null;
        }
        boolean ok = minimum ? actual >= required : actual <= required;
        String detail = "требование " + (minimum ? "не менее " : "не более ") + format(required) + ", в договоре «" + contractValue.strip() + "»";
        return new LineResult(ok ? Status.THRESHOLD_OK : Status.THRESHOLD_FAIL, detail);
    }

    private static boolean isMinimum(String word) {
        String w = word.toLowerCase(Locale.ROOT);
        return w.startsWith("мен") || w.startsWith("ниж");
    }

    /**
     * Первое число строки с учётом разрядных пробелов, дробной части и множителя «тыс.».
     *
     * @param text строка
     * @return число либо {@code null}
     */
    static Double number(String text) {
        Matcher m = NUMBER.matcher(text);
        if (!m.find()) {
            return null;
        }
        String whole = m.group(1).replaceAll("[ \\u00A0]", "");
        double value = Double.parseDouble(m.group(2) == null ? whole : whole + "." + m.group(2));
        return m.group(3) == null ? value : value * 1000;
    }

    private static String format(double value) {
        return value == Math.rint(value) ? String.valueOf((long) value) : String.valueOf(value);
    }

    private static String missingWords(List<String> tokens, NormalizedText contract, List<Block> blocks) {
        List<String> missing = new ArrayList<>();
        for (String token : tokens) {
            if (blocks.stream().noneMatch(b -> contract.norm().substring(b.from(), b.to()).contains(token))) {
                missing.add(token);
            }
        }
        return missing.isEmpty() ? "слова есть, но не подряд" : "нет в тексте позиции: " + String.join(", ", missing);
    }
}
