package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.service.scenario.executor.PriceCheck.Verdict;

/**
 * Операция «сверить_цену_и_сроки» узла «Трансформация»: по JSON узлов «Условия договора» и «Данные протокола»
 * код сверяет цену (валюта, условие «не более», см. {@link PriceCheck}) и оценивает риск выхода срока
 * поставки за срок действия договора (см. {@link DeliveryTermCheck}).
 * <p>
 * Лот протокола выбирается по ИНН победителя, затем по номеру лота договора, затем по ближайшей цене.
 * <pre>
 * {"оп": "сверить_цену_и_сроки"}
 * </pre>
 */
final class PriceTermOps {

    private PriceTermOps() {
    }

    /**
     * Отчёт по цене и срокам.
     *
     * @param text выходы предыдущих узлов (JSON договора и протокола)
     * @return отчёт с итоговым JSON
     */
    static String check(String text) {
        JsonNode contract = JsonBlocks.byDocumentType(text, "договор");
        JsonNode protocol = JsonBlocks.byDocumentType(text, "протокол");
        StringBuilder sb = new StringBuilder("ЦЕНА И СРОКИ (код)\n");
        if (contract == null) {
            return sb.append("JSON условий договора не найден — проверка не выполнена\n{\"цена\": \"НЕТ ДАННЫХ\", \"риск_сроков\": \"НЕ ОЦЕНИВАЕТСЯ\"}").toString();
        }
        JsonNode lot = selectLot(protocol, contract);
        Verdict price = PriceCheck.check(contract, lot);
        Verdict term = DeliveryTermCheck.check(contract, protocol);
        sb.append("Цена").append(lot == null ? "" : " (лот " + lot.path("номер").asText("?") + ")").append(": ")
                .append(price.status()).append(" — ").append(price.text()).append('\n');
        sb.append("Срок поставки и срок действия договора: ").append(term.status()).append(" — ").append(term.text()).append('\n');
        return sb.append("{\"цена\": \"").append(price.status()).append("\", \"риск_сроков\": \"").append(term.status()).append("\"}").toString();
    }

    /**
     * Лот протокола, к которому относится договор.
     *
     * @param protocol JSON протокола
     * @param contract JSON договора
     * @return лот либо {@code null}
     */
    static JsonNode selectLot(JsonNode protocol, JsonNode contract) {
        JsonNode lots = protocol == null ? null : protocol.path("лоты");
        if (lots == null || !lots.isArray() || lots.isEmpty()) {
            return null;
        }
        if (lots.size() == 1) {
            return lots.get(0);
        }
        JsonNode byInn = byField(lots, "ИНН_победителя", digits(contract.path("ИНН_поставщика").asText("")));
        if (byInn != null) {
            return byInn;
        }
        JsonNode byNumber = byField(lots, "номер", digits(contract.path("лот").asText("")));
        return byNumber != null ? byNumber : closestPrice(lots, PriceCheck.amount(contract.path("сумма")));
    }

    private static JsonNode byField(JsonNode lots, String field, String value) {
        if (value.isEmpty()) {
            return null;
        }
        for (JsonNode lot : lots) {
            if (value.equals(digits(lot.path(field).asText("")))) {
                return lot;
            }
        }
        return null;
    }

    private static JsonNode closestPrice(JsonNode lots, Double sum) {
        JsonNode best = lots.get(0);
        double bestDiff = Double.MAX_VALUE;
        for (JsonNode lot : lots) {
            Double price = PriceCheck.amount(lot.path("цена_победителя"));
            if (sum != null && price != null && Math.abs(price - sum) < bestDiff) {
                bestDiff = Math.abs(price - sum);
                best = lot;
            }
        }
        return best;
    }

    private static String digits(String text) {
        return text.replaceAll("\\D", "");
    }
}
