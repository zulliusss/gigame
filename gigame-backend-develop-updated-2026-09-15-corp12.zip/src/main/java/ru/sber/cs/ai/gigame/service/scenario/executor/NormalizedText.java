package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Текст документа, приведённый к виду для сравнения: только буквы и цифры в нижнем регистре, «ё» → «е».
 * <p>
 * Переносы строк, номера страниц PDF, пробелы внутри чисел («50 000»), тире и кавычки не мешают
 * поиску фразы. Для каждого символа нормализованной строки хранится позиция в исходном тексте,
 * чтобы показать найденный фрагмент как в документе.
 */
final class NormalizedText {

    private static final Pattern TOKEN = Pattern.compile("[\\p{L}\\p{N}]+");

    private final String raw;
    private final String norm;
    private final int[] rawIndex;

    private NormalizedText(String raw, String norm, int[] rawIndex) {
        this.raw = raw;
        this.norm = norm;
        this.rawIndex = rawIndex;
    }

    /**
     * Нормализует текст с сохранением соответствия позиций.
     *
     * @param raw исходный текст
     * @return нормализованный текст
     */
    static NormalizedText of(String raw) {
        String source = raw == null ? "" : raw;
        StringBuilder sb = new StringBuilder(source.length());
        int[] index = new int[source.length()];
        for (int i = 0; i < source.length(); i++) {
            char c = source.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                index[sb.length()] = i;
                sb.append(fold(c));
            }
        }
        int[] trimmed = new int[sb.length()];
        System.arraycopy(index, 0, trimmed, 0, sb.length());
        return new NormalizedText(source, sb.toString(), trimmed);
    }

    /**
     * Нормализованная форма строки (без соответствия позиций).
     *
     * @param text строка
     * @return только буквы и цифры в нижнем регистре
     */
    static String normalize(String text) {
        return of(text).norm;
    }

    /**
     * Слова и числа строки в нормализованном виде по порядку.
     *
     * @param text строка
     * @return токены
     */
    static List<String> tokens(String text) {
        List<String> result = new ArrayList<>();
        Matcher m = TOKEN.matcher(text == null ? "" : text);
        while (m.find()) {
            result.add(normalize(m.group()));
        }
        return result;
    }

    private static char fold(char c) {
        char lower = String.valueOf(c).toLowerCase(Locale.ROOT).charAt(0);
        return lower == 'ё' ? 'е' : lower;
    }

    String norm() {
        return norm;
    }

    String raw() {
        return raw;
    }

    /**
     * Позиция в исходном тексте для позиции нормализованной строки (конец строки — длина исходного текста).
     *
     * @param normPos позиция в нормализованной строке
     * @return позиция в исходном тексте
     */
    int rawPos(int normPos) {
        if (normPos >= rawIndex.length) {
            return raw.length();
        }
        return rawIndex[Math.max(0, normPos)];
    }

    /**
     * Фрагмент исходного текста между позициями нормализованной строки, пробелы схлопнуты.
     *
     * @param normFrom начало (включительно)
     * @param normTo   конец (исключительно)
     * @param max      предел длины фрагмента
     * @return фрагмент
     */
    String snippet(int normFrom, int normTo, int max) {
        int from = rawPos(normFrom);
        int to = Math.max(from, rawPos(normTo));
        String text = raw.substring(from, to).replaceAll("\\s+", " ").strip();
        return text.length() <= max ? text : text.substring(0, max) + "…";
    }
}
