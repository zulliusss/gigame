package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Утилитарный класс для генерации XLSX-файлов из JSON-данных.
 * <p>
 * Преобразует массив JSON-объектов в таблицу Excel, где ключи объектов становятся колонками,
 * а каждый объект — отдельной строкой.
 */
@Component
public class ScenarioResultToXlsx {

    private static final Logger LOG = LoggerFactory.getLogger(ScenarioResultToXlsx.class);
    private static final String MARKDOWN_FENCE = "```";

    /**
     * Метка строки-шапки исходной формы: её значения — подписи развёрнутых
     * колонок, а не данные (см. {@link XlsxTemplate#expandColumns}).
     */
    static final String HEADER_MARK = "_шапка";

    /** Числовая строка с десятичной точкой: суммы вида 986724.24 (целые не трогаем — номера, ИНН). */
    private static final Pattern DECIMAL_STRING = Pattern.compile("-?\\d+\\.\\d+");

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private ScenarioResultToXlsx() {
        // утилитарный класс
    }

    public static ResponseEntity<Resource> generateXlsx(UUID runId, ScenarioRunDetailResponse runDetail) {
        var stepsSize = runDetail.steps().size();
        if (stepsSize >= 2) {
            var secondToLastStep = runDetail.steps().get(stepsSize - 2);
            var resource = new ByteArrayResource(jsonToXlsx(secondToLastStep.outputData().result()));
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"result_" + runId.toString().substring(0, 8) + ".xlsx\"")
                    .body(resource);
        }
        return null;
    }

    /**
     * Генерирует XLSX-файл из JSON-строки и возвращает его как {@link ResponseEntity}.
     *
     * @param jsonData JSON-строка с данными для экспорта
     * @return ResponseEntity с XLSX-файлом
     */
    public static byte[] jsonToXlsx(String jsonData) {
        return jsonToXlsx(jsonData, null);
    }

    /**
     * Генерирует XLSX по данным и (опционально) шаблону формы из конфига output-узла.
     * <p>
     * Шаблон — JSON в {@code data.rules} узла:
     * <pre>
     * {"лист": "Данные",
     *  "колонки": [{"ключ": "исполнитель", "заголовок": "Наименование…", "группа": "Основные данные"}, …]}
     * </pre>
     * При наличии непустого массива {@code колонки} порядок и состав колонок фиксируются:
     * значение ячейки берётся из строки данных по {@code ключ} (нет ключа — пустая ячейка),
     * лишние ключи данных игнорируются. Если хотя бы у одной колонки задана {@code группа},
     * строится двухуровневая шапка (группы объединяются по соседним одинаковым значениям).
     * Без шаблона колонки формируются динамически из ключей JSON (прежнее поведение).
     *
     * @param jsonData  JSON-строка с данными (массив объектов или объект)
     * @param rulesJson конфиг шаблона из output-узла (может быть null/пустым/"[]")
     * @return содержимое XLSX-файла
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson) {
        return jsonToXlsx(jsonData, rulesJson, null);
    }

    /**
     * Генерация с кодовой выверкой чисел: числа в колонках из конфига
     * {@code "сверка_чисел": {"колонки": ["к8"]}} проверяются на членство в
     * {@code referenceNumbers} (эталон, извлечённый кодом из документов);
     * искажённое моделью значение заменяется единственным подходящим эталоном.
     * Деньги, прошедшие через LLM, теряют разряды — эталон из кода надёжнее.
     *
     * @param referenceNumbers эталонные числа в записи с точкой (может быть null)
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson, Set<String> referenceNumbers) {
        return jsonToXlsx(jsonData, rulesJson, referenceNumbers, null);
    }

    /**
     * Генерация со слоем записи ПОВЕРХ исходной формы участника: конфиг
     * {@code "обогащение_формы"} (см. {@link #enrichAgainstForm}) сопоставляет
     * строки данных со строками исходной таблицы по ключу; несопоставленные
     * строки формы попадают в выход с заглушками, а не теряются.
     *
     * @param enrichmentLines строки исходной формы из узла-донора (может быть null)
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson, Set<String> referenceNumbers,
                                    String enrichmentLines) {
        return jsonToXlsx(jsonData, rulesJson, referenceNumbers, enrichmentLines, null);
    }

    /**
     * То же, с шапкой исходной формы из отдельного узла-донора
     * ({@code "шапка_из_узла"}): её ячейки становятся подписями развёрнутых
     * колонок исходной формы.
     *
     * @param jsonData         JSON-строка с данными
     * @param rulesJson        конфиг выходного узла
     * @param referenceNumbers эталонные числа (может быть null)
     * @param enrichmentLines  строки исходной формы (может быть null)
     * @param headerLine       строка-шапка исходной формы (может быть null)
     * @return содержимое XLSX-файла
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson, Set<String> referenceNumbers,
                                    String enrichmentLines, String headerLine) {
        try {
            // Извлекаем только JSON-часть (в {} или []) из строки
            String cleanJson = extractJson(jsonData);

            // Парсим JSON — ожидаем массив объектов
            List<Map<String, Object>> dataList = parseJsonToList(cleanJson);
            fixNumbersAgainstReference(dataList, rulesJson, referenceNumbers);
            dataList = enrichAgainstForm(dataList, rulesJson, enrichmentLines, headerLine);

            XlsxTemplate template = XlsxTemplate.parse(rulesJson);
            if (dataList.isEmpty()) {
                if (template != null) {
                    // пустой результат при заданном шаблоне — файл с одной шапкой,
                    // а не ошибка узла (пример: нет ни одного требования к продукции)
                    return createTemplatedXlsx(template, dataList, rulesJson);
                }
                throw new FileException("Нет данных для экспорта");
            }

            if (template != null) {
                return createTemplatedXlsx(template, dataList, rulesJson);
            }

            // Собираем все уникальные ключи (колонки) в порядке появления
            Set<String> allKeys = new LinkedHashSet<>();
            for (Map<String, Object> item : dataList) {
                allKeys.addAll(item.keySet());
            }

            // Создаем workbook и обрабатываем данные
            return createXlsx(allKeys, dataList);
        } catch (Exception e) {
            throw new FileException("Ошибка при генерации XLSX-файла", e);
        }
    }

    /**
     * Выверка чисел по эталону из кода. Для каждого ключа из
     * {@code "сверка_чисел".колонки}: значение, отсутствующее в эталонном
     * множестве, заменяется эталоном, из цифр которого значение получается
     * удалением от 1 до 3 цифр (модель отбрасывает разряды при переписывании) —
     * только при ЕДИНСТВЕННОМ кандидате, иначе значение не трогается.
     */
    @SuppressWarnings("unchecked")
    static void fixNumbersAgainstReference(List<Map<String, Object>> dataList,
                                           String rulesJson, Set<String> referenceNumbers) {
        if (referenceNumbers == null || referenceNumbers.isEmpty()
                || rulesJson == null || rulesJson.isBlank() || dataList == null) {
            return;
        }
        List<String> keys = checkColumns(rulesJson);
        if (keys.isEmpty()) {
            return;
        }
        Map<String, String> refDigits = new LinkedHashMap<>();
        Set<String> canonRefs = new LinkedHashSet<>();
        for (String ref : referenceNumbers) {
            refDigits.put(ref, ref.replaceAll("\\D", ""));
            canonRefs.add(canonical(ref));
        }
        for (Map<String, Object> row : dataList) {
            for (String key : keys) {
                fixRowValue(row, key, referenceNumbers, refDigits, canonRefs);
            }
        }
    }

    /**
     * Колонки для сверки из rules ({@code "сверка_чисел": {"колонки": [...]}}).
     *
     * @param rulesJson правила выходного узла
     * @return список ключей колонок или {@code null}, если сверка не настроена
     */
    @SuppressWarnings("unchecked")
    private static List<String> checkColumns(String rulesJson) {
        try {
            Map<String, Object> rules = objectMapper.readValue(rulesJson, new TypeReference<>() { });
            Object check = rules.get("сверка_чисел");
            if (!(check instanceof Map<?, ?> checkMap)
                    || !(((Map<String, Object>) checkMap).get("колонки") instanceof List<?> cols)) {
                return List.of();
            }
            return cols.stream().map(String::valueOf).toList();
        } catch (JsonProcessingException e) {
            return List.of();
        }
    }

    /**
     * Канонизирует числовую запись: у дробной части срезаются хвостовые нули
     * («1945390.20» → «1945390.2») — они маскируют потерю разряда.
     *
     * @param value число в записи с точкой
     * @return канонизированная запись
     */
    private static String canonical(String value) {
        if (!value.contains(".")) {
            return value;
        }
        int end = value.length();
        while (end > 0 && value.charAt(end - 1) == '0') {
            end--;
        }
        if (end > 0 && value.charAt(end - 1) == '.') {
            end--;
        }
        return value.substring(0, end);
    }

    /**
     * Чинит одно значение строки: если оно отсутствует среди эталонов и по цифрам
     * восстанавливается до единственного эталона (потеря 1-3 разрядов), значение
     * заменяется этим эталоном.
     *
     * @param row              строка данных
     * @param key              ключ проверяемой колонки
     * @param referenceNumbers эталонные числа
     * @param refDigits        эталон → только его цифры
     * @param canonRefs        канонизированные эталоны
     */
    private static void fixRowValue(Map<String, Object> row, String key,
                                    Set<String> referenceNumbers,
                                    Map<String, String> refDigits, Set<String> canonRefs) {
        Object raw = row.get(key);
        if (raw == null) {
            return;
        }
        String value = String.valueOf(raw).replace(" ", "").replace(",", ".");
        if (!value.matches("\\d+(\\.\\d+)?")) {
            return;
        }
        String canon = canonical(value);
        // канонизированное совпадение («3845539.4» и эталон «3845539.40» —
        // одно число, разница только в формате) — значение верное, не трогаем
        if (referenceNumbers.contains(value) || canonRefs.contains(canon)) {
            return;
        }
        String candidate = singleCandidate(canon, refDigits);
        if (candidate != null) {
            LOG.info("[{}] Сверка чисел: {} -> {} (колонка {})", CurrentUserHolder.getCurrentUser(), value, candidate, key);
            row.put(key, candidate);
        }
    }

    /**
     * Единственный эталон, из цифр которого значение получается удалением
     * от 1 до 3 цифр; при нескольких кандидатах — {@code null} (не трогаем).
     *
     * @param canon     канонизированное значение
     * @param refDigits эталон → только его цифры
     * @return эталон-кандидат или {@code null}
     */
    private static String singleCandidate(String canon, Map<String, String> refDigits) {
        String valueDigits = canon.replaceAll("\\D", "");
        String candidate = null;
        for (Map.Entry<String, String> ref : refDigits.entrySet()) {
            int missing = ref.getValue().length() - valueDigits.length();
            // missing == 0: те же цифры, сдвинута запятая («3845539.4» vs
            // «384553.94») — чиним только между дробными записями, чтобы
            // сумма не совпала с целым эталоном (номером спецификации)
            boolean incompatible = (missing == 0 && (!canon.contains(".") || !ref.getKey().contains(".")))
                    || missing < 0 || missing > 3 || !isSubsequence(valueDigits, ref.getValue());
            if (incompatible) {
                continue;
            }
            if (candidate != null) {
                return null; // неоднозначно — не трогаем
            }
            candidate = ref.getKey();
        }
        return candidate;
    }

    /**
     * Слой записи поверх исходной формы участника. Конфиг в rules:
     * <pre>
     * "обогащение_формы": {
     *   "из_узла": "<метка узла со строками исходной формы>",
     *   "ключ_регекс": "(5\\d{6})",     — как извлечь ключ из строки формы
     *   "ключ_данных": "к5",             — где ключ в строках данных
     *   "колонка_исходной": "к0",        — ключ колонки с исходной строкой формы
     *   "заглушки": {"к9": "0", "к10": "Нет данных"}
     * }
     * </pre>
     * Выход упорядочен ПО ИСХОДНОЙ ФОРМЕ: каждая её строка даёт строку выхода
     * (сопоставленную с данными по ключу или заглушку); строки данных, не
     * нашедшие пары в форме, добавляются в конец. Ничего не затирается.
     */
    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> enrichAgainstForm(List<Map<String, Object>> dataList,
                                                       String rulesJson, String enrichmentLines) {
        return enrichAgainstForm(dataList, rulesJson, enrichmentLines, null);
    }

    /**
     * То же, с шапкой исходной формы: строка-шапка (из узла-донора
     * {@code "шапка_из_узла"}) добавляется первой строкой выхода с меткой
     * {@link #HEADER_MARK}; шаблон берёт из неё подписи развёрнутых колонок
     * и не выводит её как данные. Ключи сопоставления — см. {@link EnrichKeys}.
     *
     * @param dataList        строки данных
     * @param rulesJson       конфиг выходного узла
     * @param enrichmentLines строки исходной формы
     * @param headerLine      строка-шапка исходной формы или {@code null}
     * @return строки выхода поверх исходной формы
     */
    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> enrichAgainstForm(List<Map<String, Object>> dataList,
                                                       String rulesJson, String enrichmentLines,
                                                       String headerLine) {
        if (enrichmentLines == null || enrichmentLines.isBlank()
                || rulesJson == null || rulesJson.isBlank()) {
            return dataList;
        }
        Map<String, Object> cfg = enrichConfig(rulesJson);
        EnrichKeys keys = cfg == null ? null : EnrichKeys.parse(cfg);
        if (keys == null) {
            return dataList;
        }
        String sourceColumn = String.valueOf(cfg.getOrDefault("колонка_исходной", "к0"));
        boolean uniqueKey = Boolean.parseBoolean(String.valueOf(
                cfg.getOrDefault("ключ_уникален", "false")));
        Map<String, Object> stubs = cfg.get("заглушки") instanceof Map<?, ?> stubMap
                ? (Map<String, Object>) stubMap : Map.of();

        List<Map<String, Object>> unkeyed = new ArrayList<>();
        Map<String, Map<String, Object>> byLine = new LinkedHashMap<>();
        Map<String, ArrayDeque<Map<String, Object>>> byKey =
                groupRowsByKey(splitByLine(dataList, cfg.get("ключ_строка"), byLine), keys, uniqueKey, unkeyed);
        List<Map<String, Object>> out = new ArrayList<>();
        if (headerLine != null && !headerLine.isBlank()) {
            Map<String, Object> headerRow = new LinkedHashMap<>();
            headerRow.put(HEADER_MARK, "да");
            headerRow.put(sourceColumn, headerLine.trim());
            out.add(headerRow);
        }
        AmountDateKey amountDate = AmountDateKey.parse(cfg);
        out.addAll(overlayFormLines(enrichmentLines, keys, byKey, sourceColumn, stubs, amountDate, unkeyed, byLine));
        if (!"убрать".equalsIgnoreCase(String.valueOf(cfg.getOrDefault("лишние_данные", "в_конец")))) {
            appendUnmatched(out, byKey, sourceColumn, unkeyed);
        } else {
            LOG.info("[{}] Обогащение формы: строки данных без пары в форме убраны ({} + {})",
                    CurrentUserHolder.getCurrentUser(), byKey.values().stream().mapToInt(ArrayDeque::size).sum(), unkeyed.size());
        }
        if (out.isEmpty()) {
            return dataList;
        }
        expandSourceColumn(out, cfg, sourceColumn);
        return out;
    }

    /**
     * Строки данных, несущие исходную строку формы (поле {@code "ключ_строка"},
     * заполняется кодом строк Формы 3), сопоставляются с формой точно по этой
     * строке и в раскладку по ключам не попадают; остальные возвращаются.
     *
     * @param dataList  строки данных
     * @param lineField имя поля с исходной строкой или {@code null}
     * @param byLine    приёмник: исходная строка → запись
     * @return строки без исходной строки
     */
    private static List<Map<String, Object>> splitByLine(List<Map<String, Object>> dataList, Object lineField,
                                                         Map<String, Map<String, Object>> byLine) {
        if (lineField == null) {
            return dataList;
        }
        String field = String.valueOf(lineField);
        List<Map<String, Object>> rest = new ArrayList<>();
        for (Map<String, Object> row : dataList) {
            String line = lineKey(String.valueOf(row.getOrDefault(field, "")));
            if (line.isEmpty() || byLine.containsKey(line)) {
                rest.add(row);
            } else {
                Map<String, Object> copy = new LinkedHashMap<>(row);
                copy.remove(field);
                byLine.put(line, copy);
            }
        }
        return rest;
    }

    /** Ключ исходной строки: неразрывные и повторные пробелы не различаются. */
    private static String lineKey(String line) {
        return line.replace('\u00A0', ' ').replaceAll("\\s+", " ").strip();
    }

    /**
     * Раскладывает строки данных по ключу (очередь на ключ — актов может быть
     * несколько на одну спецификацию); строки без ключа собираются в
     * {@code unkeyed}. При {@code uniqueKey} повтор ключа не плодит запись:
     * дубль сливается с уже накопленной записью того же ключа.
     *
     * @param dataList  строки данных
     * @param keys      ключи сопоставления (основной и запасной)
     * @param uniqueKey сливать ли повторы ключа вместо накопления очереди
     * @param unkeyed   приёмник строк без ключа
     * @return строки данных по ключу в порядке появления
     */
    private static Map<String, ArrayDeque<Map<String, Object>>> groupRowsByKey(
            List<Map<String, Object>> dataList, EnrichKeys keys,
            boolean uniqueKey, List<Map<String, Object>> unkeyed) {
        Map<String, ArrayDeque<Map<String, Object>>> byKey = new LinkedHashMap<>();
        int mergedDuplicates = 0;
        for (Map<String, Object> row : dataList) {
            String key = keys.ofRow(row);
            if (key == null) {
                unkeyed.add(row);
                continue;
            }
            ArrayDeque<Map<String, Object>> queue = byKey.computeIfAbsent(key, k -> new ArrayDeque<>());
            if (uniqueKey && !queue.isEmpty() && mergeable(queue.peekLast(), row)) {
                mergeRow(queue.peekLast(), row);
                mergedDuplicates++;
            } else {
                queue.add(row);
            }
        }
        if (mergedDuplicates > 0) {
            LOG.info("Обогащение формы: слито дублей ключа {}", mergedDuplicates);
        }
        return byKey;
    }

    /**
     * Можно ли слить запись-дубль с накопленной записью того же ключа: у
     * общих ключей с содержательными значениями с обеих сторон значения
     * обязаны совпадать. Противоречие (разные даты в реквизите, разные
     * суммы) означает переиспользованный номер — это РАЗНЫЕ документы,
     * сливать их нельзя.
     *
     * @param target накопленная запись ключа
     * @param extra  запись-дубль того же ключа
     * @return {@code true}, если записи не противоречат друг другу
     */
    private static boolean mergeable(Map<String, Object> target, Map<String, Object> extra) {
        for (Map.Entry<String, Object> e : extra.entrySet()) {
            String incoming = String.valueOf(e.getValue()).strip();
            String current = String.valueOf(target.getOrDefault(e.getKey(), "")).strip();
            if (meaningful(incoming) && meaningful(current) && !incoming.equals(current)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Содержательность значения.
     *
     * @param value значение после {@code strip()}
     * @return {@code true}, если значение не пусто и не заглушка
     */
    private static boolean meaningful(String value) {
        return !value.isEmpty() && !"null".equals(value) && !"0".equals(value)
                && !"нет данных".equalsIgnoreCase(value);
    }

    /**
     * Дозаполнение записи данными дубля: пустые и заглушечные значения
     * («нет данных», «0», пусто) заменяются содержательными из второй записи
     * того же ключа; заполненные поля не перетираются.
     *
     * @param target накопленная запись ключа
     * @param extra  запись-дубль того же ключа
     */
    private static void mergeRow(Map<String, Object> target, Map<String, Object> extra) {
        for (Map.Entry<String, Object> e : extra.entrySet()) {
            String incoming = String.valueOf(e.getValue()).strip();
            String current = String.valueOf(target.getOrDefault(e.getKey(), "")).strip();
            if (meaningful(incoming) && !meaningful(current)) {
                target.put(e.getKey(), e.getValue());
            }
        }
    }

    /**
     * Разворачивает склеенную исходную строку формы («поле | поле | …») в
     * отдельные динамические колонки {@code к0_01…} — вместо нечитаемой
     * километровой ячейки лист получает исходные колонки формы участника.
     * Включается конфигом {@code "развернуть_исходную": true} (+ опционально
     * {@code "разделитель"}). Шапка формы (первая строка без ключа) уже
     * сохранена первой строкой выхода с меткой {@link #HEADER_MARK} — из неё
     * шаблон берёт подписи исходных колонок.
     */
    private static void expandSourceColumn(List<Map<String, Object>> rows, Map<String, Object> cfg,
                                           String sourceColumn) {
        if (!Boolean.parseBoolean(String.valueOf(cfg.getOrDefault("развернуть_исходную", "false")))) {
            return;
        }
        String sep = String.valueOf(cfg.getOrDefault("разделитель", "|"));
        for (Map<String, Object> row : rows) {
            Object raw = row.remove(sourceColumn);
            if (raw == null) {
                continue;
            }
            String[] parts = String.valueOf(raw).split(Pattern.quote(sep), -1);
            for (int i = 0; i < parts.length; i++) {
                row.put(sourceColumn + "_" + String.format(Locale.ROOT, "%02d", i + 1),
                        parts[i].strip());
            }
        }
    }

    /**
     * Конфиг обогащения из rules ({@code "обогащение_формы": {...}}).
     *
     * @param rulesJson правила выходного узла
     * @return конфиг или {@code null}, если обогащение не настроено
     */
    @SuppressWarnings("unchecked")
    private static Map<String, Object> enrichConfig(String rulesJson) {
        try {
            Map<String, Object> rules = objectMapper.readValue(rulesJson, new TypeReference<>() { });
            return rules.get("обогащение_формы") instanceof Map<?, ?> raw
                    ? (Map<String, Object>) raw : null;
        } catch (JsonProcessingException e) {
            return Map.of();
        }
    }

    /**
     * Ключи сопоставления строки формы и записи данных. Основной ключ
     * ({@code ключ_регекс} по строке формы, {@code ключ_регекс_данных} по полю
     * {@code ключ_данных}) и запасной ({@code ключ_регекс_запас} по строке,
     * {@code ключ_регекс_данных_запас} по полю {@code ключ_данных_запас}) —
     * например УПД, а если реквизита УПД нет, то спецификация. Ключ —
     * первая непустая группа совпадения (шаблон может содержать альтернативы).
     *
     * @param lineMain          основной шаблон по строке формы
     * @param lineFallback      запасной шаблон по строке формы (может быть null)
     * @param dataField         поле данных с основным ключом
     * @param dataMain          основной шаблон по полю данных
     * @param dataFallbackField поле данных с запасным ключом
     * @param dataFallback      запасной шаблон по полю данных (может быть null)
     */
    record EnrichKeys(Pattern lineMain, Pattern lineFallback, String dataField, Pattern dataMain,
                      String dataFallbackField, Pattern dataFallback) {

        /**
         * Ключи из конфига обогащения.
         *
         * @param cfg конфиг "обогащение_формы"
         * @return ключи или {@code null}, если шаблон не компилируется
         */
        static EnrichKeys parse(Map<String, Object> cfg) {
            try {
                String main = String.valueOf(cfg.getOrDefault("ключ_регекс", "(\\d{7})"));
                Pattern lineMain = Pattern.compile(main);
                Pattern dataMain = Pattern.compile(String.valueOf(
                        cfg.getOrDefault("ключ_регекс_данных", main)));
                Pattern lineFallback = optionalPattern(cfg.get("ключ_регекс_запас"));
                Pattern dataFallback = optionalPattern(
                        cfg.getOrDefault("ключ_регекс_данных_запас", cfg.get("ключ_регекс_запас")));
                String dataField = String.valueOf(cfg.getOrDefault("ключ_данных", "к5"));
                String dataFallbackField = String.valueOf(
                        cfg.getOrDefault("ключ_данных_запас", dataField));
                return new EnrichKeys(lineMain, lineFallback, dataField, dataMain,
                        dataFallbackField, dataFallback);
            } catch (Exception e) {
                return null;
            }
        }

        private static Pattern optionalPattern(Object raw) {
            return raw == null || String.valueOf(raw).isBlank()
                    ? null : Pattern.compile(String.valueOf(raw));
        }

        /**
         * Ключ строки исходной формы.
         *
         * @param line строка формы
         * @return ключ или {@code null}
         */
        String ofLine(String line) {
            String key = firstGroup(lineMain, line);
            return key != null ? key : firstGroup(lineFallback, line);
        }

        /**
         * Ключ записи данных.
         *
         * @param row запись данных
         * @return ключ или {@code null}
         */
        String ofRow(Map<String, Object> row) {
            String key = firstGroup(dataMain, String.valueOf(row.getOrDefault(dataField, "")));
            return key != null ? key
                    : firstGroup(dataFallback, String.valueOf(row.getOrDefault(dataFallbackField, "")));
        }

        private static String firstGroup(Pattern pattern, String text) {
            if (pattern == null) {
                return null;
            }
            Matcher m = pattern.matcher(text);
            if (!m.find()) {
                return null;
            }
            for (int i = 1; i <= m.groupCount(); i++) {
                if (m.group(i) != null && !m.group(i).isEmpty()) {
                    return m.group(i);
                }
            }
            return m.groupCount() == 0 ? m.group() : null;
        }
    }

    /**
     * Строит выход ПО СТРОКАМ ИСХОДНОЙ ФОРМЫ: каждая строка формы даёт строку
     * выхода — сопоставленную с данными по ключу, заглушку либо строку без
     * ключа как есть.
     *
     * @param enrichmentLines строки исходной формы
     * @param keys            ключи сопоставления (основной и запасной)
     * @param byKey           строки данных по ключу (очереди)
     * @param sourceColumn    ключ колонки исходной строки формы
     * @param stubs           значения-заглушки для несопоставленных строк
     * @return строки выхода в порядке исходной формы
     */
    private static List<Map<String, Object>> overlayFormLines(
            String enrichmentLines, EnrichKeys keys,
            Map<String, ArrayDeque<Map<String, Object>>> byKey,
            String sourceColumn, Map<String, Object> stubs,
            AmountDateKey amountDate, List<Map<String, Object>> unkeyed,
            Map<String, Map<String, Object>> byLine) {
        List<Map<String, Object>> out = new ArrayList<>();
        int stubbed = 0;
        int matched = 0;
        for (String line : enrichmentLines.split("\\r?\\n")) {
            if (line.isBlank()) {
                continue;
            }
            String key = keys.ofLine(line);
            Map<String, Object> row = new LinkedHashMap<>();
            Map<String, Object> exact = byLine.remove(lineKey(line));
            ArrayDeque<Map<String, Object>> queue = key == null ? null : byKey.get(key);
            Map<String, Object> byAmount = exact != null || queue != null && !queue.isEmpty() ? null
                    : amountDate == null ? null : amountDate.take(line, byKey, unkeyed);
            if (exact != null) {
                row.putAll(exact);
                matched++;
            } else if (queue != null && !queue.isEmpty()) {
                row.putAll(queue.poll());
                matched++;
            } else if (byAmount != null) {
                // номер акта в форме неверный (например, номер заказа вместо номера УПД) —
                // строка найдена по сумме и дате акта
                row.putAll(byAmount);
                matched++;
            } else if (key != null) {
                row.put(keys.dataField(), key);
                stubs.forEach(row::put);
                stubbed++;
            }
            // строка формы без ключа (примечание, строка без реквизитов) — тоже
            // сохраняется: выход обязан содержать ВСЕ строки исходной формы
            row.put(sourceColumn, line.trim());
            out.add(row);
        }
        LOG.info("[{}] Обогащение формы: сопоставлено {}, заглушек {}", CurrentUserHolder.getCurrentUser(), matched, stubbed);
        return out;
    }

    /**
     * Добавляет в конец выхода строки данных, не нашедшие пары в форме,
     * и строки без ключа.
     *
     * @param out          строки выхода
     * @param byKey        остатки строк данных по ключу
     * @param sourceColumn ключ колонки исходной строки формы
     * @param unkeyed      строки данных без ключа
     */
    /**
     * Запасное сопоставление строки формы с записью данных по сумме и дате
     * акта (конфиг {@code "запас_сумма_дата": {"поле_суммы": "к10", "поле_даты": "к6"}}):
     * участники нередко пишут в форме номер заказа вместо номера УПД, а сумма
     * и дата документа совпадают с реальным УПД. Берётся первая свободная
     * запись, у которой сумма равна одной из сумм строки формы и одна из дат
     * строки формы совпадает с датой в поле даты записи.
     */
    record AmountDateKey(String amountField, String dateField) {
        private static final Pattern AMOUNT = Pattern.compile("(?<![\\d,.])(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?![\\d])");
        private static final Pattern DATE = Pattern.compile("(?<!\\d)(\\d{2}\\.\\d{2}\\.\\d{4})(?!\\d)");

        @SuppressWarnings("unchecked")
        static AmountDateKey parse(Map<String, Object> cfg) {
            if (!(cfg.get("запас_сумма_дата") instanceof Map<?, ?> raw)) {
                return null;
            }
            Map<String, Object> m = (Map<String, Object>) raw;
            return new AmountDateKey(String.valueOf(m.getOrDefault("поле_суммы", "к10")),
                    String.valueOf(m.getOrDefault("поле_даты", "к6")));
        }

        /** Снимает из очередей подходящую запись; {@code null}, если нет. */
        Map<String, Object> take(String line, Map<String, ArrayDeque<Map<String, Object>>> byKey,
                                 List<Map<String, Object>> unkeyed) {
            Set<String> amounts = amounts(line);
            Set<String> dates = dates(line);
            if (amounts.isEmpty() || dates.isEmpty()) {
                return null;
            }
            for (ArrayDeque<Map<String, Object>> queue : byKey.values()) {
                for (Iterator<Map<String, Object>> it = queue.iterator(); it.hasNext(); ) {
                    Map<String, Object> row = it.next();
                    if (fits(row, amounts, dates)) {
                        it.remove();
                        return row;
                    }
                }
            }
            for (Iterator<Map<String, Object>> it = unkeyed.iterator(); it.hasNext(); ) {
                Map<String, Object> row = it.next();
                if (fits(row, amounts, dates)) {
                    it.remove();
                    return row;
                }
            }
            return null;
        }

        private boolean fits(Map<String, Object> row, Set<String> amounts, Set<String> dates) {
            Set<String> rowAmounts = amounts(String.valueOf(row.getOrDefault(amountField, "")));
            Set<String> rowDates = dates(String.valueOf(row.getOrDefault(dateField, "")));
            return !Collections.disjoint(rowAmounts, amounts) && !Collections.disjoint(rowDates, dates);
        }

        private static Set<String> amounts(String text) {
            Set<String> out = new LinkedHashSet<>();
            Matcher m = AMOUNT.matcher(text);
            while (m.find()) {
                out.add(m.group(1).replace(" ", "") + "." + m.group(2));
            }
            return out;
        }

        private static Set<String> dates(String text) {
            Set<String> out = new LinkedHashSet<>();
            Matcher m = DATE.matcher(text);
            while (m.find()) {
                out.add(m.group(1));
            }
            return out;
        }
    }

    private static void appendUnmatched(List<Map<String, Object>> out,
                                        Map<String, ArrayDeque<Map<String, Object>>> byKey,
                                        String sourceColumn, List<Map<String, Object>> unkeyed) {
        int outside = 0;
        for (ArrayDeque<Map<String, Object>> queue : byKey.values()) {
            for (Map<String, Object> r : queue) {
                Map<String, Object> row = new LinkedHashMap<>(r);
                row.put(sourceColumn, "нет в исходной форме");
                out.add(row);
                outside++;
            }
        }
        out.addAll(unkeyed);
        LOG.info("[{}] Обогащение формы: вне формы {}, без ключа {}", CurrentUserHolder.getCurrentUser(), outside, unkeyed.size());
    }

    /** {@code true}, если {@code sub} — подпоследовательность {@code full} (порядок цифр сохранён). */
    private static boolean isSubsequence(String sub, String full) {
        int i = 0;
        for (int j = 0; j < full.length() && i < sub.length(); j++) {
            if (sub.charAt(i) == full.charAt(j)) {
                i++;
            }
        }
        return i == sub.length();
    }

    /** Шаблон формы таблицы из конфига output-узла. */
    record XlsxTemplate(String sheetName, List<XlsxColumn> columns, boolean highlightSections) {

        /**
         * Колонка шаблона. Обычная колонка задаётся ключом; ДИНАМИЧЕСКАЯ —
         * префиксом ключа ({@code "ключ_префикс"}): она разворачивается в
         * отдельную колонку на КАЖДЫЙ фактический ключ данных с этим префиксом
         * (заголовок = "заголовок_префикс" + суффикс ключа). Так форма получает
         * по колонке на каждую технологию закупки, сколько бы их ни было.
         */
        record XlsxColumn(String key, String title, String group, String keyPrefix,
                          Map<String, String> highlight, List<String> headerTitles) {
            @SuppressWarnings("unused")
            XlsxColumn(String key, String title, String group) {
                this(key, title, group, "", Map.of(), List.of());
            }
            @SuppressWarnings("unused")
            XlsxColumn(String key, String title, String group, String keyPrefix) {
                this(key, title, group, keyPrefix, Map.of(), List.of());
            }
            XlsxColumn(String key, String title, String group, String keyPrefix,
                       Map<String, String> highlight) {
                this(key, title, group, keyPrefix, highlight, List.of());
            }

            boolean isDynamic() {
                return !keyPrefix.isBlank();
            }

            /** @return имя цвета подсветки для значения ячейки или {@code null} */
            String highlightColor(Object value) {
                if (highlight.isEmpty() || value == null) {
                    return null;
                }
                String text = value.toString().strip();
                for (Map.Entry<String, String> entry : highlight.entrySet()) {
                    if (entry.getKey().equalsIgnoreCase(text)) {
                        return entry.getValue();
                    }
                }
                return null;
            }
        }

        /** @return шаблон или {@code null}, если rules не содержит непустой массив "колонки" */
        static XlsxTemplate parse(String rulesJson) {
            if (rulesJson == null || rulesJson.isBlank() || rulesJson.trim().startsWith("[")) {
                return null;
            }
            try {
                Map<String, Object> rules = objectMapper.readValue(rulesJson, new TypeReference<>() {
                });
                List<XlsxColumn> columns = parseColumns(rules.get("колонки"));
                if (columns.isEmpty()) {
                    return null;
                }
                String sheet = stringOrEmpty(rules.get("лист"));
                boolean highlight = Boolean.parseBoolean(stringOrEmpty(rules.get("выделять_секции")));
                return new XlsxTemplate(sheet.isBlank() ? "Данные" : sheet, columns, highlight);
            } catch (JsonProcessingException e) {
                // rules другого узла/формата (например, calc) — работаем без шаблона
                return null;
            }
        }

        /**
         * Разворачивает динамические колонки по фактическим ключам данных:
         * для колонки с "ключ_префикс" создаётся по колонке на каждый
         * уникальный ключ с этим префиксом (в порядке появления в данных).
         *
         * @param dataList строки данных
         * @return список только конкретных колонок
         */
        List<XlsxColumn> expandColumns(List<Map<String, Object>> dataList) {
            return expandColumns(dataList, null);
        }

        /**
         * То же, с шапкой исходной формы: подпись динамической колонки — из
         * шапки (значение по ключу колонки), затем из списка «заголовки»,
         * затем техническая «заголовок_префикс + суффикс».
         *
         * @param dataList  строки данных
         * @param headerRow строка-шапка исходной формы или {@code null}
         * @return список только конкретных колонок
         */
        List<XlsxColumn> expandColumns(List<Map<String, Object>> dataList,
                                       Map<String, Object> headerRow) {
            List<XlsxColumn> expanded = new ArrayList<>();
            List<Map<String, Object>> keySource = new ArrayList<>();
            if (headerRow != null) {
                keySource.add(headerRow);
            }
            keySource.addAll(dataList);
            for (XlsxColumn column : columns) {
                if (!column.isDynamic()) {
                    expanded.add(column);
                    continue;
                }
                for (String key : matchedKeys(column, keySource)) {
                    String suffix = key.substring(column.keyPrefix().length());
                    String custom = headerRow == null ? ""
                            : String.valueOf(headerRow.getOrDefault(key, "")).strip();
                    String title = custom.isEmpty() || "null".equals(custom)
                            ? dynamicTitle(column, suffix) : custom;
                    expanded.add(new XlsxColumn(key, title, column.group(), "", column.highlight()));
                }
            }
            return expanded;
        }

        /**
         * Ключи данных с префиксом динамической колонки.
         *
         * @param column   динамическая колонка
         * @param dataList строки данных
         * @return ключи в порядке появления
         */
        private static Set<String> matchedKeys(XlsxColumn column,
                                               List<Map<String, Object>> dataList) {
            Set<String> matched = new LinkedHashSet<>();
            for (Map<String, Object> item : dataList) {
                for (String key : item.keySet()) {
                    if (key.startsWith(column.keyPrefix())) {
                        matched.add(key);
                    }
                }
            }
            return matched;
        }

        /**
         * Подпись динамической колонки: по порядковому суффиксу из списка
         * {@code "заголовки"} префикс-колонки (оригинальные названия колонок
         * исходной формы), иначе техническая «заголовок_префикс + суффикс».
         *
         * @param column динамическая колонка
         * @param suffix суффикс ключа после префикса
         * @return подпись колонки
         */
        private static String dynamicTitle(XlsxColumn column, String suffix) {
            try {
                int index = Integer.parseInt(suffix);
                if (index >= 1 && index <= column.headerTitles().size()) {
                    String custom = column.headerTitles().get(index - 1).strip();
                    if (!custom.isEmpty()) {
                        return custom;
                    }
                }
            } catch (NumberFormatException e) {
                LOG.trace("Нечисловой суффикс динамической колонки: {}", suffix);
            }
            return column.title() + suffix;
        }

        /** Разбирает значение ключа "колонки"; невалидные элементы пропускаются. */
        private static List<XlsxColumn> parseColumns(Object columnsRaw) {
            if (!(columnsRaw instanceof List<?> columnsList)) {
                return List.of();
            }
            List<XlsxColumn> columns = new ArrayList<>();
            for (Object item : columnsList) {
                XlsxColumn column = parseColumn(item);
                if (column != null) {
                    columns.add(column);
                }
            }
            return columns;
        }

        /** @return колонка (обычная или динамическая) или {@code null}, если элемент невалиден */
        @SuppressWarnings("unchecked")
        private static XlsxColumn parseColumn(Object item) {
            if (!(item instanceof Map<?, ?> col)) {
                return null;
            }
            Map<String, Object> colMap = (Map<String, Object>) col;
            String key = stringOrEmpty(colMap.get("ключ"));
            if (key.isBlank()) {
                return parsePrefixColumn(item);
            }
            String title = stringOrEmpty(colMap.get("заголовок"));
            return new XlsxColumn(key, title.isBlank() ? key : title,
                    stringOrEmpty(colMap.get("группа")), "", parseHighlight(colMap.get("подсветка")));
        }

        /** Разбирает карту подсветки «значение → цвет» из ключа "подсветка". */
        private static Map<String, String> parseHighlight(Object raw) {
            if (!(raw instanceof Map<?, ?> map)) {
                return Map.of();
            }
            Map<String, String> highlight = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (entry.getKey() != null && entry.getValue() != null) {
                    highlight.put(entry.getKey().toString(), entry.getValue().toString());
                }
            }
            return highlight;
        }

        /** @return динамическая колонка или {@code null}, если нет "ключ_префикс" */
        @SuppressWarnings("unchecked")
        private static XlsxColumn parsePrefixColumn(Object item) {
            if (!(item instanceof Map<?, ?> col)) {
                return null;
            }
            Map<String, Object> colMap = (Map<String, Object>) col;
            String keyPrefix = stringOrEmpty(colMap.get("ключ_префикс"));
            if (keyPrefix.isBlank()) {
                return null;
            }
            // префикс заголовка не стрипится: хвостовой пробел («Технология: ») значим
            Object titleRaw = colMap.get("заголовок_префикс");
            String titlePrefix = titleRaw == null ? "" : titleRaw.toString();
            return new XlsxColumn("", titlePrefix, stringOrEmpty(colMap.get("группа")),
                    keyPrefix, parseHighlight(colMap.get("подсветка")),
                    parseHeaderTitles(colMap.get("заголовки")));
        }

        /**
         * Список оригинальных названий колонок исходной формы из ключа
         * {@code "заголовки"} префикс-колонки (по порядку суффиксов 01, 02…).
         *
         * @param raw значение ключа "заголовки"
         * @return названия колонок или пустой список
         */
        private static List<String> parseHeaderTitles(Object raw) {
            if (!(raw instanceof List<?> list)) {
                return List.of();
            }
            List<String> titles = new ArrayList<>();
            for (Object item : list) {
                titles.add(item == null ? "" : item.toString());
            }
            return titles;
        }

        private static String stringOrEmpty(Object value) {
            return value == null ? "" : value.toString().strip();
        }

        boolean hasGroups() {
            return columns.stream().anyMatch(c -> !c.group().isBlank());
        }
    }

    /**
     * Конфиг блочной вёрстки листа (ключ {@code "блоки"} в rules): строки,
     * у которых значение колонки {@code ключ} входит в {@code верх}/{@code низ},
     * выносятся из таблицы в блоки над и под ней (текст берётся из колонки
     * {@code текст}); {@code заголовок_верх}/{@code заголовок_низ} — названия блоков.
     */
    record BlockConfig(String key, Set<String> top, Set<String> bottom, String textKey,
                       String topTitle, String bottomTitle, String levelColumn, String numberColumn) {

        /** Порядок уровней в сводке. */
        private static final List<String> LEVEL_ORDER =
                List.of("КРИТИЧЕСКИЙ", "ВЫСОКИЙ", "СРЕДНИЙ", "НИЗКИЙ", "ИНФО");

        BlockConfig(String key, Set<String> top, Set<String> bottom, String textKey,
                    String topTitle, String bottomTitle) {
            this(key, top, bottom, textKey, topTitle, bottomTitle, "", "");
        }

        /**
         * Строка сводки уровней риска, посчитанная кодом по строкам таблицы
         * (конфиг {@code "сводка_уровней": {"колонка": "з4", "номер": "з1"}}):
         * «ВЫСОКИЙ — №1, №7 (итого 2); …». Модель считает уровни ненадёжно —
         * теряет строки и придумывает отсутствующие уровни; код — нет.
         *
         * @param tableRows строки таблицы
         * @return строка для нижнего блока или {@code null}, если сводка не настроена
         */
        Map<String, Object> levelSummaryRow(List<Map<String, Object>> tableRows) {
            if (levelColumn.isBlank() || bottom.isEmpty()) {
                return null;
            }
            Map<String, List<String>> byLevel = new LinkedHashMap<>();
            for (Map<String, Object> row : tableRows) {
                String level = String.valueOf(row.getOrDefault(levelColumn, "")).strip().toUpperCase();
                if (level.isEmpty() || "NULL".equals(level)) {
                    continue;
                }
                String number = numberColumn.isBlank() ? ""
                        : String.valueOf(row.getOrDefault(numberColumn, "")).strip();
                byLevel.computeIfAbsent(level, k -> new ArrayList<>()).add(number);
            }
            List<String> parts = new ArrayList<>();
            List<String> order = new ArrayList<>(LEVEL_ORDER);
            byLevel.keySet().stream().filter(l -> !order.contains(l)).forEach(order::add);
            for (String level : order) {
                List<String> numbers = byLevel.get(level);
                if (numbers == null) {
                    continue;
                }
                String list = numbers.stream().filter(s -> !s.isEmpty() && !"null".equals(s))
                        .map(s -> "№" + s).reduce((a, b) -> a + ", " + b).orElse("");
                parts.add(level + (list.isEmpty() ? "" : " — " + list) + " (итого " + numbers.size() + ")");
            }
            Map<String, Object> row = new LinkedHashMap<>();
            row.put(key, bottom.iterator().next());
            row.put(textKey, "Сводка по уровням риска (посчитано программно по таблице): "
                    + (parts.isEmpty() ? "строк с уровнем риска нет" : String.join("; ", parts)));
            return row;
        }

        /** @return конфиг или {@code null}, если rules не содержит валидный ключ "блоки" */
        @SuppressWarnings("unchecked")
        static BlockConfig parse(String rulesJson) {
            if (rulesJson == null || rulesJson.isBlank()) {
                return null;
            }
            Map<String, Object> rules;
            try {
                rules = objectMapper.readValue(rulesJson, new TypeReference<>() { });
            } catch (JsonProcessingException e) {
                return null;
            }
            if (!(rules.get("блоки") instanceof Map<?, ?> raw)) {
                return null;
            }
            Map<String, Object> cfg = (Map<String, Object>) raw;
            String key = String.valueOf(cfg.getOrDefault("ключ", "")).strip();
            String textKey = String.valueOf(cfg.getOrDefault("текст", "")).strip();
            if (key.isBlank() || textKey.isBlank()) {
                return null;
            }
            String levelColumn = "";
            String numberColumn = "";
            if (cfg.get("сводка_уровней") instanceof Map<?, ?> summary) {
                Object column = summary.get("колонка");
                Object number = summary.get("номер");
                levelColumn = column == null ? "" : String.valueOf(column).strip();
                numberColumn = number == null ? "" : String.valueOf(number).strip();
            }
            return new BlockConfig(key, parseValues(cfg.get("верх")), parseValues(cfg.get("низ")),
                    textKey, String.valueOf(cfg.getOrDefault("заголовок_верх", "")).strip(),
                    String.valueOf(cfg.getOrDefault("заголовок_низ", "")).strip(),
                    levelColumn, numberColumn);
        }

        private static Set<String> parseValues(Object raw) {
            Set<String> values = new LinkedHashSet<>();
            if (raw instanceof List<?> list) {
                for (Object item : list) {
                    if (item != null && !String.valueOf(item).isBlank()) {
                        values.add(String.valueOf(item).strip());
                    }
                }
            }
            return values;
        }

        /** @return строки, у которых значение колонки {@code key} входит в {@code markers} */
        List<Map<String, Object>> select(List<Map<String, Object>> dataList, Set<String> markers) {
            return dataList.stream()
                    .filter(row -> markers.contains(String.valueOf(row.get(key)).strip()))
                    .toList();
        }

        /** @return строки таблицы — всё, что не попало ни в верхний, ни в нижний блок */
        List<Map<String, Object>> tableRows(List<Map<String, Object>> dataList) {
            return dataList.stream()
                    .filter(row -> {
                        String value = String.valueOf(row.get(key)).strip();
                        return !top.contains(value) && !bottom.contains(value);
                    })
                    .toList();
        }
    }

    /**
     * Создаёт XLSX с фиксированной формой: порядок колонок из шаблона,
     * опциональная двухуровневая шапка (строка групп + строка заголовков).
     * Конфиг {@code "блоки"} выносит служебные строки (паспорт закупки,
     * выводы) из таблицы в отдельные блоки над и под ней.
     */
    private static byte[] createTemplatedXlsx(XlsxTemplate template, List<Map<String, Object>> dataList,
                                              String rulesJson) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet(template.sheetName());

            // шапка исходной формы (метка HEADER_MARK) — подписи колонок, не данные
            Map<String, Object> headerRow = null;
            if (!dataList.isEmpty() && dataList.get(0).containsKey(HEADER_MARK)) {
                headerRow = dataList.get(0);
                dataList = new ArrayList<>(dataList.subList(1, dataList.size()));
            }
            List<XlsxTemplate.XlsxColumn> columns = template.expandColumns(dataList, headerRow);
            XlsxTemplate resolved = new XlsxTemplate(template.sheetName(), columns,
                    template.highlightSections());

            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);

            BlockConfig blocks = BlockConfig.parse(rulesJson);
            List<Map<String, Object>> tableRows = dataList;
            int rowNum = 0;
            if (blocks != null) {
                BlockContext context = new BlockContext(sheet, blocks, columns.size(),
                        headerStyle, dataStyle);
                tableRows = blocks.tableRows(dataList);
                rowNum = writeBlockRows(context, blocks.select(dataList, blocks.top()),
                        blocks.topTitle(), 0);
            }
            int headerRows = createTemplateHeader(sheet, resolved, headerStyle, rowNum);
            populateDataRows(sheet, resolved, tableRows, headerRows, headerStyle, dataStyle);
            if (blocks != null) {
                BlockContext context = new BlockContext(sheet, blocks, columns.size(),
                        headerStyle, dataStyle);
                List<Map<String, Object>> bottomRows = new ArrayList<>();
                Map<String, Object> summary = blocks.levelSummaryRow(tableRows);
                if (summary != null) {
                    bottomRows.add(summary);
                }
                bottomRows.addAll(blocks.select(dataList, blocks.bottom()));
                writeBlockRows(context, bottomRows, blocks.bottomTitle(), headerRows + tableRows.size() + 1);
            }

            autoResizeColumns(sheet, columns);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            throw new FileException("Ошибка создания Excel файла ", e);
        }
    }

    /**
     * Контекст блока служебных строк: лист, конфиг блоков, ширина таблицы и стили.
     * Вынесен в record, чтобы не перегружать сигнатуру {@link #writeBlockRows}.
     */
    private record BlockContext(Sheet sheet, BlockConfig blocks, int width,
                                CellStyle headerStyle, CellStyle dataStyle) {
    }

    /**
     * Пишет блок служебных строк (паспорт/выводы): строка-заголовок блока и по
     * строке на запись — текст из колонки {@code текст}, объединённый на всю
     * ширину таблицы.
     *
     * @return номер строки после блока (с одной пустой строкой-отступом)
     */
    private static int writeBlockRows(BlockContext ctx, List<Map<String, Object>> rows,
                                      String title, int startRow) {
        if (rows.isEmpty()) {
            return startRow;
        }
        Sheet sheet = ctx.sheet();
        int width = ctx.width();
        int rowNum = startRow;
        if (!title.isBlank()) {
            Row titleRow = sheet.createRow(rowNum++);
            Cell cell = titleRow.createCell(0);
            cell.setCellValue(title);
            cell.setCellStyle(ctx.headerStyle());
            mergeRowAcross(sheet, titleRow.getRowNum(), width);
        }
        for (Map<String, Object> item : rows) {
            Row row = sheet.createRow(rowNum++);
            Cell cell = row.createCell(0);
            Object value = item.get(ctx.blocks().textKey());
            cell.setCellValue(value == null ? "" : String.valueOf(value));
            cell.setCellStyle(ctx.dataStyle());
            mergeRowAcross(sheet, row.getRowNum(), width);
        }
        return rowNum + 1;
    }

    /** Объединяет ячейки строки от первой колонки до {@code width - 1}. */
    private static void mergeRowAcross(Sheet sheet, int rowNum, int width) {
        if (width > 1) {
            sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, width - 1));
        }
    }

    /**
     * Авто-ширина для всех колонок листа.
     */
    private static void autoResizeColumns(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns) {
        for (int i = 0; i < columns.size(); i++) {
            sheet.autoSizeColumn(i);
        }
    }

    /**
     * Заполняет строки данными: для каждой строки создаёт ячейки по колонкам шаблона,
     * применяет стиль секции (если включена подсветка секций)
     * и подсветку значений по конфигу.
     */
    private static void populateDataRows(Sheet sheet, XlsxTemplate template,
                                         List<Map<String, Object>> dataList,
                                         int startRow,
                                         CellStyle headerStyle, CellStyle dataStyle) {
        List<XlsxTemplate.XlsxColumn> columns = template.columns();
        Map<String, CellStyle> highlightStyles = new LinkedHashMap<>();
        int rowNum = startRow;

        for (Map<String, Object> item : dataList) {
            Row row = sheet.createRow(rowNum++);
            boolean section = template.highlightSections() && isSectionRow(columns, item);
            populateRow(row, columns, item, section, headerStyle, dataStyle, highlightStyles);
        }
    }

    /**
     * Заполняет одну строку данными: проходит по колонкам, записывает значения,
     * применяет стиль (секция / обычная) и опциональную цветовую подсветку.
     */
    private static void populateRow(Row row, List<XlsxTemplate.XlsxColumn> columns,
                                    Map<String, Object> item,
                                    boolean section,
                                    CellStyle headerStyle, CellStyle dataStyle,
                                    Map<String, CellStyle> highlightStyles) {
        CellStyle defaultStyle = section ? headerStyle : dataStyle;

        for (int i = 0; i < columns.size(); i++) {
            Cell cell = row.createCell(i);
            Object value = item.get(columns.get(i).key());
            setCellSmart(cell, value);
            cell.setCellStyle(resolveCellStyle(cell, columns.get(i), value, defaultStyle, highlightStyles));
        }
    }

    /**
     * Определяет стиль ячейки: базовый стиль + цветовая подсветка, если есть совпадение.
     */
    private static CellStyle resolveCellStyle(Cell cell, XlsxTemplate.XlsxColumn column,
                                              Object value,
                                              CellStyle defaultStyle,
                                              Map<String, CellStyle> highlightStyles) {
        String colorName = column.highlightColor(value);
        if (colorName == null) {
            return defaultStyle;
        }
        CellStyle colored = highlightStyle(cell.getSheet().getWorkbook(), highlightStyles, colorName);
        return colored == null ? defaultStyle : colored;
    }

    /**
     * Строка-секция: значение есть только в первой колонке (заголовок раздела
     * внутри таблицы, например «Квалификационные требования»).
     *
     * @param columns колонки таблицы
     * @param item    строка данных
     * @return {@code true}, если строка — заголовок секции
     */
    private static boolean isSectionRow(List<XlsxTemplate.XlsxColumn> columns, Map<String, Object> item) {
        if (columns.size() < 2) {
            return false;
        }
        Object first = item.get(columns.get(0).key());
        if (first == null || first.toString().isBlank()) {
            return false;
        }
        for (int i = 1; i < columns.size(); i++) {
            Object value = item.get(columns.get(i).key());
            if (value != null && !value.toString().isBlank()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Строит шапку по шаблону: при наличии групп — двухуровневую
     * (строка групп с объединением соседних одинаковых + строка заголовков).
     *
     * @return количество строк шапки
     */
    private static int createTemplateHeader(Sheet sheet, XlsxTemplate template, CellStyle headerStyle,
                                            int startRow) {
        List<XlsxTemplate.XlsxColumn> columns = template.columns();
        boolean twoLevel = template.hasGroups();
        if (twoLevel) {
            createGroupRow(sheet, columns, headerStyle, startRow);
        }
        Row headerRow = sheet.createRow(startRow + (twoLevel ? 1 : 0));
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns.get(i).title());
            cell.setCellStyle(headerStyle);
        }
        return startRow + (twoLevel ? 2 : 1);
    }

    /** Строка групп с объединением соседних колонок одинаковой непустой группы. */
    private static void createGroupRow(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns,
                                       CellStyle headerStyle, int startRow) {
        Row groupRow = sheet.createRow(startRow);
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = groupRow.createCell(i);
            cell.setCellValue(columns.get(i).group());
            cell.setCellStyle(headerStyle);
        }
        mergeAdjacentGroups(sheet, columns, startRow);
    }

    /** Объединяет в строке групп соседние колонки с одинаковой непустой группой. */
    private static void mergeAdjacentGroups(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns,
                                            int groupRow) {
        int start = 0;
        for (int i = 1; i <= columns.size(); i++) {
            boolean sameGroup = i < columns.size()
                    && !columns.get(i).group().isBlank()
                    && columns.get(i).group().equals(columns.get(start).group());
            if (!sameGroup) {
                if (i - start > 1 && !columns.get(start).group().isBlank()) {
                    sheet.addMergedRegion(new CellRangeAddress(groupRow, groupRow, start, i - 1));
                }
                start = i;
            }
        }
    }

    /**
     * Создает XLSX-ресурс из собранных данных.
     * Вынесено в отдельный метод для избежания вложенных try блоков.
     *
     * @param allKeys  набор уникальных ключей-колонок
     * @param dataList список данных для экспорта
     * @return ResponseEntity с XLSX-файлом
     */
    private static byte[] createXlsx(Set<String> allKeys, List<Map<String, Object>> dataList) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Данные");

            // Стили
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);

            // Заголовки — все ключи как колонки
            Row headerRow = sheet.createRow(0);
            int colIndex = 0;
            for (String key : allKeys) {
                Cell cell = headerRow.createCell(colIndex++);
                cell.setCellValue(key);
                cell.setCellStyle(headerStyle);
            }

            // Заполняем данные — каждая строка = один объект
            int rowNum = 1;
            for (Map<String, Object> item : dataList) {
                Row row = sheet.createRow(rowNum++);
                colIndex = 0;
                for (String key : allKeys) {
                    Cell cell = row.createCell(colIndex++);
                    setCellSmart(cell, item.get(key));
                    cell.setCellStyle(dataStyle);
                }
            }

            // Автоширина колонок
            for (int i = 0; i < allKeys.size(); i++) {
                sheet.autoSizeColumn(i);
            }

            // Записываем в байтовый массив
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);

            return outputStream.toByteArray();

        } catch (IOException e) {
            throw new FileException("Ошибка создания Excel файла ", e);
        }
    }

    /**
     * Парсит JSON-строку в список Map. Поддерживает как массив объектов, так и одиночный объект.
     */
    private static List<Map<String, Object>> parseJsonToList(String json) {
        String trimmed = json.trim();
        if (!trimmed.startsWith("[") && !trimmed.startsWith("{")) {
            throw new FileException("Неверный формат JSON: ожидается объект или массив");
        }
        try {
            // Массив объектов парсим как есть
            if (trimmed.startsWith("[")) {
                return objectMapper.readValue(json, new TypeReference<>() {
                });
            }
            // Одиночный объект оборачиваем в список
            Map<String, Object> singleObject = objectMapper.readValue(json, new TypeReference<>() {
            });
            return Collections.singletonList(singleObject);
        } catch (JsonProcessingException e) {
            throw new FileException("Неверный формат JSON: ожидается объект или массив");
        }
    }

    /**
     * Записывает значение в ячейку с сохранением числового типа: числа и строки
     * вида 986724.24 становятся ЧИСЛОВЫМИ ячейками (Excel показывает их по локали
     * пользователя — с запятой в русской — и они участвуют в формулах и аналитике),
     * остальное — текстом. Целочисленные строки остаются текстом: это обычно
     * номера договоров и ИНН, а не величины.
     *
     * @param cell  ячейка
     * @param value значение (может быть {@code null})
     */
    private static void setCellSmart(Cell cell, Object value) {
        if (value instanceof Number number) {
            cell.setCellValue(number.doubleValue());
            return;
        }
        if (value instanceof String str && DECIMAL_STRING.matcher(str.strip()).matches()) {
            cell.setCellValue(Double.parseDouble(str.strip()));
            return;
        }
        cell.setCellValue(formatValue(value));
    }

    /**
     * Форматирует значение для записи в ячейку.
     * Массивы и объекты преобразуются в JSON-строку.
     */
    private static String formatValue(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String str) {
            return str;
        }
        if (value instanceof Boolean) {
            return value.toString();
        }
        if (value instanceof Number number) {
            // Double.toString даёт научную запись (1.21377795E7) — в ячейке нужно 12137779.5
            return new java.math.BigDecimal(number.toString()).stripTrailingZeros().toPlainString();
        }
        if (value instanceof List || value instanceof Map) {
            try {
                return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(value);
            } catch (Exception e) {
                return value.toString();
            }
        }
        return value.toString();
    }

    /**
     * Извлекает JSON-объект или массив из строки, отбрасывая лишний текст.
     * Видимость package-private: используется и накоплением результата
     * ({@link ScenarioOutputSupportService}).
     */
    static String extractJson(String raw) {
        if (raw == null || raw.isBlank()) {
            return "[]";
        }

        // Сначала пробуем убрать markdown-блоки ```json ... ``` или ``` ... ```
        String sanitized = stripMarkdownFence(raw.trim());
        sanitized = sanitized.replace("\n", "").replace("\r", "");
        // Извлекаем первый JSON-объект или массив
        return firstJsonBlock(sanitized);
    }

    /**
     * Содержимое markdown-блока ```json ... ``` (или ``` ... ```), если он есть.
     * Закрывающая тройка учитывается только в самом конце строки; без неё
     * берётся всё после открывающей. Без блока строка возвращается как есть.
     */
    private static String stripMarkdownFence(String text) {
        int fence = text.indexOf(MARKDOWN_FENCE);
        if (fence < 0) {
            return text;
        }
        int start = fence + MARKDOWN_FENCE.length();
        if (text.startsWith("json", start)) {
            start += 4;
        }
        int end = text.length();
        if (text.endsWith(MARKDOWN_FENCE) && end - MARKDOWN_FENCE.length() >= start) {
            end -= MARKDOWN_FENCE.length();
        }
        return text.substring(start, end).trim();
    }

    /** Первый сбалансированный JSON-объект или массив в строке; "[]", если его нет. */
    private static String firstJsonBlock(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '{' || c == '[') {
                int end = JsonCalcUtils.balancedEnd(text, i);
                if (end >= 0) {
                    return text.substring(i, end + 1);
                }
            }
        }
        return "[]";
    }

    /**
     * Создает стиль для заголовков таблицы.
     */
    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        style.setFont(font);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    /**
     * Создает стиль для ячеек с данными.
     */
    private static CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setWrapText(true);
        return style;
    }

    /**
     * Стиль данных с цветной заливкой (подсветка вердиктов: «Соответствует» —
     * зелёным, «Не соответствует» — красным и т.п.). Стили кэшируются по имени
     * цвета — Excel ограничивает число уникальных стилей в книге.
     *
     * @param workbook  книга
     * @param cache     кэш стилей по имени цвета
     * @param colorName имя цвета из конфига («зелёный», «красный», «жёлтый»)
     * @return стиль с заливкой либо {@code null}, если цвет неизвестен
     */
    private static CellStyle highlightStyle(Workbook workbook, Map<String, CellStyle> cache, String colorName) {
        String normalized = colorName.toLowerCase(Locale.ROOT).replace('ё', 'е');
        IndexedColors color = switch (normalized) {
            case "зеленый", "green" -> IndexedColors.LIGHT_GREEN;
            case "красный", "red" -> IndexedColors.ROSE;
            case "желтый", "yellow" -> IndexedColors.LIGHT_YELLOW;
            default -> null;
        };
        if (color == null) {
            return null;
        }
        return cache.computeIfAbsent(normalized, name -> {
            CellStyle style = createDataStyle(workbook);
            style.setFillForegroundColor(color.getIndex());
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            return style;
        });
    }
}