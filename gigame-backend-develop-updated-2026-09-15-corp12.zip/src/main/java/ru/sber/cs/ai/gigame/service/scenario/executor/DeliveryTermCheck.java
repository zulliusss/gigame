package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.service.scenario.executor.PriceCheck.Verdict;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Риск выхода срока поставки (оказания услуг) за срок действия договора.
 * <p>
 * Начало отсчёта — дата договора, а если она не заполнена («__.__.2026») — дата протокола. Окончание
 * поставки — дата «до …» или начало + N календарных / рабочих дней (выходные пропускаются, праздники не
 * учитываются) / месяцев. Окончание договора — дата «до …» или начало + N месяцев. Если поставка
 * заканчивается позже договора — «РИСК». Срок, отсчитываемый от иного события (утверждение заказа,
 * согласование чертежей), считается от даты начала условно — это отмечается в пояснении.
 */
final class DeliveryTermCheck {

    private static final Pattern DATE = Pattern.compile("(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern SIGNING = Pattern.compile("подписан|заключен|вступлен|не\\s+указан", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Срок поставки больше (в единицах) — ошибка извлечения, риск не считается. */
    private static final int MAX_DAYS = 3650;
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private DeliveryTermCheck() {
    }

    /**
     * Оценка риска.
     *
     * @param contract JSON условий договора
     * @param protocol JSON протокола (может быть {@code null})
     * @return итог: «РИСК», «НЕТ РИСКА» или «НЕ ОЦЕНИВАЕТСЯ» с пояснением
     */
    static Verdict check(JsonNode contract, JsonNode protocol) {
        LocalDate contractDate = date(contract.path("дата_договора").asText(""));
        LocalDate start = contractDate != null ? contractDate : protocol == null ? null : date(protocol.path("дата_протокола").asText(""));
        if (start == null) {
            return new Verdict("НЕ ОЦЕНИВАЕТСЯ", "нет даты договора и даты протокола");
        }
        String startText = format(start) + (contractDate != null ? " (дата договора)" : " (дата протокола — дата договора не заполнена)");
        LocalDate deliveryEnd = deliveryEnd(contract, start);
        LocalDate termEnd = termEnd(contract, start);
        if (deliveryEnd == null || termEnd == null) {
            return new Verdict("НЕ ОЦЕНИВАЕТСЯ", deliveryEnd == null ? "срок поставки не задан датой или числом дней"
                    : "срок действия договора не ограничен датой или числом месяцев");
        }
        String text = "начало отсчёта " + startText + "; поставка до " + format(deliveryEnd) + "; договор действует до " + format(termEnd) + eventNote(contract);
        if (deliveryEnd.isAfter(termEnd)) {
            return new Verdict("РИСК", text + " — поставка может завершиться на " + ChronoUnit.DAYS.between(termEnd, deliveryEnd)
                    + " дн. позже окончания срока действия договора");
        }
        return new Verdict("НЕТ РИСКА", text);
    }

    private static LocalDate deliveryEnd(JsonNode contract, LocalDate start) {
        LocalDate until = date(contract.path("срок_поставки_до").asText(""));
        if (until != null) {
            return until;
        }
        Double count = PriceCheck.amount(contract.path("срок_поставки_число"));
        if (count == null || count <= 0 || count > MAX_DAYS) {
            return null;
        }
        String unit = contract.path("срок_поставки_единица").asText("").toLowerCase(Locale.ROOT);
        long n = Math.round(count);
        if (unit.contains("месяц")) {
            return start.plusMonths(n);
        }
        return unit.contains("рабоч") ? plusWorkingDays(start, n) : start.plusDays(n);
    }

    private static LocalDate termEnd(JsonNode contract, LocalDate start) {
        LocalDate until = date(contract.path("срок_действия_до").asText(""));
        if (until != null) {
            return until;
        }
        Double months = PriceCheck.amount(contract.path("срок_действия_месяцев"));
        return months == null || months <= 0 ? null : start.plusMonths(Math.round(months));
    }

    private static String eventNote(JsonNode contract) {
        String event = contract.path("срок_поставки_отсчёт").asText("").strip();
        if (event.isEmpty() || SIGNING.matcher(event).find()) {
            return "";
        }
        return "; срок поставки отсчитывается от события «" + event + "» — от даты начала посчитан условно";
    }

    /**
     * Дата через N рабочих дней (суббота и воскресенье пропускаются, праздники не учитываются).
     *
     * @param start начало
     * @param days  число рабочих дней
     * @return дата окончания
     */
    static LocalDate plusWorkingDays(LocalDate start, long days) {
        LocalDate d = start;
        long left = days;
        while (left > 0) {
            d = d.plusDays(1);
            if (d.getDayOfWeek() != DayOfWeek.SATURDAY && d.getDayOfWeek() != DayOfWeek.SUNDAY) {
                left--;
            }
        }
        return d;
    }

    private static LocalDate date(String text) {
        Matcher m = DATE.matcher(text);
        if (!m.find()) {
            return null;
        }
        try {
            return LocalDate.parse(m.group(1), FORMAT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    private static String format(LocalDate date) {
        return date.format(FORMAT);
    }
}
