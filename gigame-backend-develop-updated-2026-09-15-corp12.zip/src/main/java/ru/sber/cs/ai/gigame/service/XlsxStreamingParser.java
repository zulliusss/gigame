package ru.sber.cs.ai.gigame.service;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.util.XMLHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Потоковый (SAX) разбор XLSX в текст того же формата, что даёт DOM-парсер
 * {@code DocumentService.parseWorkbook}: строки листа — ячейки через " | "
 * (пустые сохраняются), при нескольких листах каждый предваряется строкой
 * "=== Лист: [название] ===", между листами пустая строка, для формул берётся
 * сохранённое в файле значение.
 * <p>
 * DOM-модель XSSF на книге в 8 МБ (37 тысяч строк по 47 колонок — финансовая
 * структура банка) требовала больше 3 ГБ кучи и падала с OutOfMemoryError ещё
 * при загрузке файла. Потоковый разбор держит в памяти только текущую строку.
 */
final class XlsxStreamingParser {

    private static final String SHEET_HEADER = "=== Лист: ";
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    private XlsxStreamingParser() {
    }

    /**
     * Текст книги.
     *
     * @param inputStream поток XLSX
     * @param maxSheets   максимум листов (остальные пропускаются)
     * @param maxRows     максимум строк суммарно по всем листам (остальные пропускаются с пометкой)
     * @return текст в формате DOM-парсера
     * @throws IOException если книга не читается
     */
    static String parse(InputStream inputStream, int maxSheets, int maxRows) throws IOException {
        List<List<String>> sheets = new ArrayList<>();
        List<String> names = new ArrayList<>();
        try (OPCPackage pkg = OPCPackage.open(inputStream)) {
            XSSFReader reader = new XSSFReader(pkg);
            StylesTable styles = reader.getStylesTable();
            ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(pkg);
            XSSFReader.SheetIterator sheetIterator = (XSSFReader.SheetIterator) reader.getSheetsData();
            RowCollector collector = new RowCollector(maxRows);
            while (sheetIterator.hasNext() && sheets.size() < maxSheets) {
                sheets.add(readSheet(sheetIterator.next(), styles, strings, collector));
                names.add(sheetIterator.getSheetName());
            }
        } catch (OpenXML4JException | SAXException | ParserConfigurationException e) {
            throw new IOException("XLSX не разобран: " + e.getMessage(), e);
        }
        return assemble(sheets, names);
    }

    private static List<String> readSheet(InputStream sheet, StylesTable styles, ReadOnlySharedStringsTable strings,
                                          RowCollector collector) throws IOException, SAXException, ParserConfigurationException {
        try (sheet) {
            collector.startSheet();
            XMLReader xmlReader = XMLHelper.newXMLReader();
            xmlReader.setContentHandler(new XSSFSheetXMLHandler(styles, null, strings, collector, new RussianDateFormatter(), false));
            xmlReader.parse(new InputSource(sheet));
            return collector.rows();
        }
    }

    private static String assemble(List<List<String>> sheets, List<String> names) {
        StringBuilder out = new StringBuilder();
        for (int s = 0; s < sheets.size(); s++) {
            if (sheets.size() > 1) {
                out.append(SHEET_HEADER).append(names.get(s)).append(" ===\n");
            }
            for (String row : sheets.get(s)) {
                out.append(row).append('\n');
            }
            // пустая строка между листами (как в DOM-парсере: пустой элемент + join по \n)
            out.append('\n');
        }
        return out.length() == 0 ? "" : out.substring(0, out.length() - 1);
    }

    /** Даты — «дд.мм.гггг» (стандартный форматтер даёт «7/1/20», нечитаемо для русских документов). */
    private static final class RussianDateFormatter extends DataFormatter {
        @Override
        public String formatRawCellContents(double value, int formatIndex, String formatString, boolean use1904Windowing) {
            if (DateUtil.isADateFormat(formatIndex, formatString) && DateUtil.isValidExcelDate(value)) {
                LocalDateTime date = DateUtil.getLocalDateTime(value, use1904Windowing);
                return date.toLocalTime().equals(LocalTime.MIDNIGHT) ? date.toLocalDate().format(DATE) : date.format(DATE_TIME);
            }
            return super.formatRawCellContents(value, formatIndex, formatString, use1904Windowing);
        }
    }

    /** Собирает строки листа: ячейки по индексу колонки, пропуски — пустые ячейки. */
    private static final class RowCollector implements XSSFSheetXMLHandler.SheetContentsHandler {
        private final int maxRows;
        private int totalRows;
        private boolean truncated;
        private List<String> rows = new ArrayList<>();
        private List<String> cells = new ArrayList<>();

        RowCollector(int maxRows) {
            this.maxRows = maxRows;
        }

        void startSheet() {
            rows = new ArrayList<>();
        }

        List<String> rows() {
            return rows;
        }

        @Override
        public void startRow(int rowNum) {
            cells = new ArrayList<>();
        }

        @Override
        public void endRow(int rowNum) {
            if (totalRows >= maxRows) {
                if (!truncated) {
                    rows.add("[...обрезано: больше " + maxRows + " строк]");
                    truncated = true;
                }
                return;
            }
            totalRows++;
            rows.add(String.join(" | ", cells));
        }

        @Override
        public void cell(String cellReference, String formattedValue, XSSFComment comment) {
            int col = cellReference == null ? cells.size() : new CellReference(cellReference).getCol();
            while (cells.size() < col) {
                cells.add("");
            }
            String value = formattedValue == null ? "" : formattedValue.replaceAll("[\r\n]+", " ").strip();
            if (col < cells.size()) {
                cells.set(col, value);
            } else {
                cells.add(value);
            }
        }
    }
}
