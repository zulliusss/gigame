package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Block;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecTableParser.SpecPosition;

import java.util.ArrayList;
import java.util.List;

/**
 * Участки текста договора, относящиеся к позиции: от каждого вхождения наименования позиции (включительно — строка
 * характеристики может начинаться с наименования) до ближайшего
 * вхождения наименования другой позиции (или не дальше заданного предела).
 * <p>
 * В договоре наименование встречается несколько раз (таблица цен, таблица характеристик) — участков
 * будет несколько; строка характеристики засчитывается, если найдена в любом из них.
 */
final class SpecBlocks {

    private SpecBlocks() {
    }

    /**
     * Участки позиции в договоре.
     *
     * @param text      нормализованный текст договора
     * @param position  позиция
     * @param all       все позиции таблицы (их наименования ограничивают участки)
     * @param minSplit  наименования короче не ограничивают участки
     * @param maxBlock  предел длины участка
     * @return участки; пусто, если наименование в договоре не найдено
     */
    static List<Block> of(NormalizedText text, SpecPosition position, List<SpecPosition> all, int minSplit, int maxBlock) {
        String norm = text.norm();
        String name = NormalizedText.normalize(position.name());
        List<Block> blocks = new ArrayList<>();
        if (name.isEmpty()) {
            return blocks;
        }
        for (int at = norm.indexOf(name); at >= 0; at = norm.indexOf(name, at + name.length())) {
            int afterName = at + name.length();
            int to = Math.min(norm.length(), Math.min(afterName + maxBlock, nextBoundary(norm, all, afterName, minSplit)));
            blocks.add(new Block(at, to));
        }
        return blocks;
    }

    private static int nextBoundary(String norm, List<SpecPosition> all, int from, int minSplit) {
        int boundary = norm.length();
        for (SpecPosition other : all) {
            String otherName = NormalizedText.normalize(other.name());
            if (otherName.length() < minSplit) {
                continue;
            }
            int at = norm.indexOf(otherName, from);
            if (at >= 0 && at < boundary) {
                boundary = at;
            }
        }
        return boundary;
    }
}
