package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.function.FunctionToolCallback;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * Инструменты агентского режима узла «Обработка»: модель сама читает
 * документы вызовами функций, вместо вставки полных текстов в промпт.
 * Это снимает лимиты размера запроса и позволяет модели работать
 * по простому заданию пользователя (намерению) без ручного промпт-инжиниринга.
 * <p>
 * Ограничение числа обращений защищает от зацикливания: после исчерпания
 * лимита инструменты просят модель сформировать финальный ответ.
 */
public class AgentDocumentTools {

    /**
     * Размер фрагмента документа за одно чтение (символов): ответ инструмента — одно сообщение
     * GigaChat не больше 4096 токенов (русский текст ≈ 2,5–4 символа на токен; 12000 символов давали
     * HTTP 413 «Tokens limit exceeded for index 0» на комплектах с большими документами).
     */
    static final int READ_CHUNK = 7000;
    /** Максимум найденных вхождений поиска за один вызов. */
    static final int SEARCH_MAX_HITS = 10;
    /** Контекст вокруг найденного вхождения (символов в обе стороны); 10 × 600 символов — в лимит одного сообщения. */
    static final int SEARCH_CONTEXT = 300;
    /**
     * Максимум функций в запросе с длинным заданием. Экспериментально (13.09.2026, дамп Комплекта 6 —
     * 261 файл, задание 28 тыс. токенов): с 7 и более функциями GigaChat отвечает HTTP 413 «Tokens limit
     * exceeded for index 0», с шестью то же задание проходит; размер системного промпта и описаний
     * функций на это не влияют, короткое задание проходит и с 11 функциями.
     */
    static final int MAX_TOOLS_FOR_LONG_TASK = 6;
    /** Ядро инструментов компактного набора (в порядке приоритета). */
    static final List<String> CORE_TOOLS = List.of("search_documents", "read_document", "locate_quote",
            "extract_regex", "note_thought", "write_file");
    /** Лимит обращений к инструментам за одно выполнение узла. */
    static final int MAX_TOOL_CALLS = 40;
    /** Сколько подряд идущих чтений одного документа допускается. */
    static final int MAX_SEQUENTIAL_READS = 3;
    /** Лимит записей рассуждений (не входит в MAX_TOOL_CALLS — мысли дёшевы). */
    static final int MAX_THOUGHTS = 15;
    /** Лимит символов одного наблюдения в сводке. */
    static final int OBSERVATION_LIMIT = 2500;
    /** Лимит символов всей сводки наблюдений. */
    static final int OBSERVATIONS_TOTAL_LIMIT = 40000;
    /** ReWOO-предвыборка: вхождений на запрос, символов контекста, общий лимит. */
    static final int REWOO_TOP = 3;
    static final int REWOO_CONTEXT = 400;
    static final int REWOO_TOTAL_LIMIT = 18000;

    private static final String REPEAT_MESSAGE =
            "Этот запрос уже выполнялся — результат был выше в разговоре. "
                    + "Не повторяй одинаковые вызовы: попробуй ДРУГОЕ ключевое слово "
                    + "(короче, синоним, часть слова) или переходи к финальному ответу.";

    private static final String LIMIT_MESSAGE =
            "Лимит обращений к инструментам исчерпан — сформируй финальный ответ "
                    + "по уже прочитанным данным, недостающее пометь как 'не указано'.";

    /** Сколько пустых поисков подряд допускается до принудительной смены стратегии. */
    static final int FRUITLESS_STREAK_LIMIT = 3;
    /** Лимит размера рабочего файла (write_file). */
    static final int WRITE_MAX_CHARS = 60000;

    private static final String CHANGE_STRATEGY_MESSAGE =
            "Поиск перефразировками исчерпан — новые формулировки не помогут. "
                    + "Смени стратегию: прочитай подходящий документ целиком (read_document); "
                    + "ищи конкретные ожидаемые ЗНАЧЕНИЯ (названия, числа, имена), а не "
                    + "формулировки пунктов плана; если данных в документах действительно "
                    + "нет — зафиксируй в тетради «не указано» и переходи к следующему пункту.";

    /** Ключ сообщения об ошибке в результатах инструментов. */
    private static final String ERROR_KEY = "error";

    /** Документ узла: имя файла и полный текст. */
    public record DocEntry(String filename, String text) {
    }

    /** Запрос чтения фрагмента документа. */
    public record ReadRequest(String name, Integer offset) {
    }

    /**
     * Запрос поиска по документам.
     *
     * @param query искомый текст
     * @param docs  необязательный фильтр: искать только в документах, чьи
     *              имена содержат любую из подстрок (экономит контекст на
     *              больших комплектах)
     */
    public record SearchRequest(String query, List<String> docs) {

        public SearchRequest(String query) {
            this(query, null);
        }
    }

    /** Запрос поиска по базе знаний. */
    /** Исполнитель кодовой операции над документами прогона (имя, параметры, вход → результат). */
    @FunctionalInterface
    public interface OperationRunner {
        String run(String operation, Map<String, Object> params, String input);
    }

    /** check_amounts: суммы рядом с меткой по всем документам. */
    public record AmountsRequest(String label) {
    }

    /** check_percentages / check_dates: необязательный фильтр документов подстрокой имени. */
    public record DocsRequest(String docs) {
    }

    /** extract_regex: regex по документам (имя — фильтр файлов, all — все совпадения). */
    public record RegexRequest(String pattern, String docs, Boolean all) {
    }

    /** locate_quote: где в документах дословно встречается цитата. */
    public record QuoteRequest(String quote, String docs) {
    }

    /** Запрос текста нормы по реквизиту (kb_article). */
    public record ArticleRequest(String requisite) {
    }

    public record KbSearchRequest(String query) {
    }

    /** Запись рассуждения (think-tool): явный Thought из ReAct. */
    public record ThoughtRequest(String thought) {
    }

    /** Запись рабочего файла прогона (конспект/таблица для следующих узлов). */
    public record WriteRequest(String name, String content) {
    }

    private final Map<String, String> docsByName = new LinkedHashMap<>();
    private final AtomicInteger calls = new AtomicInteger();
    private final Function<String, List<String>> kbSearch;
    private final List<String> callLog = new ArrayList<>();
    /** Уже выполненные вызовы: повтор не возвращает данные заново (защита от петли). */
    private final java.util.Set<String> seenCalls = new java.util.HashSet<>();
    /** Собранные наблюдения — для добивающего вызова при пустом финале. */
    private final StringBuilder observations = new StringBuilder();
    /** Счётчик записанных рассуждений (think-tool). */
    private final AtomicInteger thoughts = new AtomicInteger();
    /** Запросы, не нашедшие ничего: их расширения отклоняются без поиска. */
    private final List<String> fruitlessQueries = new ArrayList<>();
    /** Пустые поиски подряд: серия — сигнал сменить стратегию. */
    private int fruitlessStreak;
    /** Живая трассировка действий агента (лог прогона в UI); по умолчанию — тишина. */
    private Consumer<String> progress = s -> {
    };
    /** Остановка прогона пользователем: любой вызов инструмента сворачивает работу. */
    private BooleanSupplier runCancelled = () -> false;
    /** Имена рабочих файлов (write_file) — исключаются из цитатной валидации. */
    private final java.util.Set<String> workNoteNames = new java.util.HashSet<>();
    /**
     * Фрагменты базы знаний, выданные search_knowledge_base: участвуют в
     * цитатной валидации тетради наравне с документами комплекта — иначе
     * норма, процитированная агентом из базы, отклонялась как «цитата не
     * найдена» (проверка шла только по документам закупки) и в заключение
     * уходило «норма в базе не найдена».
     */
    private final Map<String, String> kbChunksByName = new LinkedHashMap<>();
    /** Структурный индекс нормативки (kb_article); строится лениво при первом вызове. */
    private Supplier<NormIndex> normIndexSupplier;
    private NormIndex normIndex;
    /** Кодовые проверки документов (сверка сумм, процентов, дат, regex, цитаты). */
    private OperationRunner operationRunner;
    /** Приёмник записи рабочих файлов в прогон; null — запись выключена. */
    private java.util.function.BinaryOperator<String> writeSink;

    /**
     * @param docs     документы, доступные агенту
     * @param kbSearch поиск по базе знаний (null — БЗ не настроена)
     */
    public AgentDocumentTools(List<DocEntry> docs, Function<String, List<String>> kbSearch) {
        for (DocEntry doc : docs) {
            docsByName.put(doc.filename(), doc.text());
        }
        this.kbSearch = kbSearch;
    }

    /** Подключает кодовые проверки документов — инструменты check_amounts, check_percentages, check_dates, extract_regex, locate_quote. */
    public void setOperationRunner(OperationRunner runner) {
        this.operationRunner = runner;
    }

    /** Подключает структурный индекс нормативки — инструмент kb_article. */
    public void setNormIndex(Supplier<NormIndex> supplier) {
        this.normIndexSupplier = supplier;
    }

    /** Помечает документ рабочим файлом (не источник цитат). */
    public void markWorkNote(String filename) {
        workNoteNames.add(filename);
    }

    /**
     * Включает инструмент write_file: функция (имя, текст) → ошибка или null,
     * сохраняющая рабочий файл в документы прогона.
     */
    public void setWriteSink(java.util.function.BinaryOperator<String> sink) {
        this.writeSink = sink;
    }

    /** Подключает живую трассировку (каждый вызов инструмента — строка в лог прогона). */
    public void setProgress(Consumer<String> consumer) {
        this.progress = consumer;
    }

    public void setRunCancelled(BooleanSupplier supplier) {
        this.runCancelled = supplier;
    }

    private void trace(String message) {
        try {
            progress.accept(message);
        } catch (Exception ignored) {
            // трассировка не должна ломать выполнение
        }
    }

    /**
     * Набор инструментов для передачи модели.
     *
     * @return колбэки инструментов
     */
    public List<ToolCallback> callbacks() {
        // list_documents не является инструментом: у функции без параметров
        // GigaChat отклоняет схему (422 «Field 'properties' is missing»),
        // а список документов дешевле передать сразу в системном промпте.
        List<ToolCallback> tools = new ArrayList<>();
        tools.add(FunctionToolCallback
                .builder("search_documents", this::searchDocuments)
                .description("Регистронезависимый поиск подстроки. Возвращает вхождения "
                        + "с контекстом и позицией. Ищи короткие ключевые слова. "
                        + "Необязательное поле docs — список подстрок имён документов: "
                        + "поиск только в них (используй, когда знаешь, где искать).")
                .inputType(SearchRequest.class)
                .build());
        tools.add(FunctionToolCallback
                .builder("read_document", this::readDocument)
                .description("Читает фрагмент документа: name — имя из list_documents, "
                        + "offset — позиция начала (0 — с начала; для продолжения используй "
                        + "next_offset из предыдущего ответа).")
                .inputType(ReadRequest.class)
                .build());
        addKnowledgeBaseTools(tools);
        addDomainTools(tools);
        tools.add(FunctionToolCallback
                .builder("note_thought", this::noteThought)
                .description("Запиши короткое рассуждение: что уже выяснено, чего не "
                        + "хватает, какой пункт плана делаешь следующим. Используй "
                        + "перед сменой пункта плана — это помогает не терять нить.")
                .inputType(ThoughtRequest.class)
                .build());
        if (writeSink != null) {
            tools.add(FunctionToolCallback
                    .builder("write_file", this::writeFile)
                    .description("Сохрани РАБОЧИЙ файл прогона (конспект, "
                            + "промежуточную таблицу): name — короткое имя, content — "
                            + "текст. Файл увидят агенты следующих узлов сценария. "
                            + "Рабочие файлы НЕ являются источниками цитат.")
                    .inputType(WriteRequest.class)
                    .build());
        }
        return tools;
    }

    /**
     * Компактный набор — не больше {@link #MAX_TOOLS_FOR_LONG_TASK} инструментов ядра
     * ({@link #CORE_TOOLS}); кодовые сверки и база знаний отключаются. Используется при
     * HTTP 413 «index 0» на длинном задании (Форма 3 по комплекту из сотен файлов).
     *
     * @return колбэки ядра в порядке приоритета
     */
    public List<ToolCallback> compactCallbacks() {
        List<ToolCallback> all = callbacks();
        List<ToolCallback> core = new ArrayList<>();
        for (String name : CORE_TOOLS) {
            all.stream().filter(t -> name.equals(t.getToolDefinition().name())).findFirst().ifPresent(core::add);
        }
        return core.size() > MAX_TOOLS_FOR_LONG_TASK ? new ArrayList<>(core.subList(0, MAX_TOOLS_FOR_LONG_TASK)) : core;
    }

    Map<String, Object> writeFile(WriteRequest request) {
        String name = request.name() == null ? "" : request.name().strip();
        String content = request.content() == null ? "" : request.content();
        if (overLimit("write_file: " + name + " (" + content.length() + " симв)")) {
            return Map.of(ERROR_KEY, LIMIT_MESSAGE);
        }
        if (name.isBlank() || content.isBlank()) {
            return Map.of(ERROR_KEY, "Нужны непустые name и content.");
        }
        if (name.length() > 100 || content.length() > WRITE_MAX_CHARS) {
            return Map.of(ERROR_KEY, "Слишком длинно: имя до 100, текст до "
                    + WRITE_MAX_CHARS + " символов.");
        }
        String error = writeSink.apply(name, content);
        if (error != null) {
            return Map.of(ERROR_KEY, error);
        }
        docsByName.put(name, content);
        workNoteNames.add(name);
        trace("🗒 записан рабочий файл «" + name + "» (" + content.length() + " симв)");
        return Map.of("ok", true,
                "note", "Файл сохранён и будет доступен следующим узлам сценария.");
    }

    Map<String, Object> noteThought(ThoughtRequest request) {
        String thought = request.thought() == null ? "" : request.thought().strip();
        callLog.add("мысль: " + thought);
        trace("💭 " + thought);
        if (thoughts.incrementAndGet() > MAX_THOUGHTS) {
            return Map.of(ERROR_KEY, "Достаточно рассуждений — действуй или дай финальный ответ.");
        }
        return Map.of("ok", true, "note", "Записано. Продолжай работу по плану.");
    }

    /** Сколько обращений к инструментам сделала модель. */
    public int callCount() {
        return calls.get();
    }

    /** Журнал обращений (для деталей шага в UI). */
    public List<String> callLog() {
        return callLog;
    }

    /** Сводка собранных наблюдений (обрезанная) — контекст добивающего вызова. */
    public String observationsSummary() {
        return observations.toString();
    }

    private void remember(String header, Object result) {
        if (observations.length() >= OBSERVATIONS_TOTAL_LIMIT) {
            return;
        }
        String entry = header + " -> "
                + java.util.Objects.toString(result, "");
        if (entry.length() > OBSERVATION_LIMIT) {
            entry = entry.substring(0, OBSERVATION_LIMIT) + "…";
        }
        observations.append(entry).append("\n\n");
    }

    private boolean overLimit(String logEntry) {
        callLog.add(logEntry);
        // остановка прогона: инструменты «исчерпаны» — модель сворачивает работу
        if (runCancelled.getAsBoolean()) {
            return true;
        }
        return calls.incrementAndGet() > MAX_TOOL_CALLS;
    }

    /**
     * Повторный вызов с теми же аргументами не возвращает данные заново —
     * модели, зациклившейся на одном запросе, отвечаем инструкцией сменить
     * запрос. Это рвёт петлю и не раздувает контекст дубликатами
     * (наблюдался узел, повторивший один поиск 4 раза и раздувший
     * контекст до безответного состояния).
     *
     * @param key нормализованный ключ вызова
     * @return {@code true}, если такой вызов уже выполнялся
     */
    private boolean isRepeat(String key) {
        return !seenCalls.add(key.toLowerCase(Locale.ROOT).strip());
    }

    /**
     * Детектор «листания»: последние {@code MAX_SEQUENTIAL_READS} записей
     * журнала — чтения того же документа.
     *
     * @param name имя документа текущего чтения
     * @return {@code true}, если пора остановить сплошное чтение
     */
    private boolean isSequentialReadBinge(String name) {
        int n = callLog.size();
        if (n < MAX_SEQUENTIAL_READS + 1) {
            return false;
        }
        for (int i = n - MAX_SEQUENTIAL_READS - 1; i < n - 1; i++) {
            if (!callLog.get(i).startsWith("read_document: " + name + " ")) {
                return false;
            }
        }
        return true;
    }

    /**
     * ReWOO-предвыборка: пакетное исполнение спланированных поисков БЕЗ участия
     * модели (round-trip'ов нет). Результаты компактны (top-{@code REWOO_TOP}
     * вхождений, контекст {@code REWOO_CONTEXT}) и подкладываются в задание —
     * основной цикл добирает точечно, а не ищет всё с нуля.
     *
     * @param queries спланированные запросы: текст (+ опциональный фильтр docs)
     * @return компактная сводка результатов для промпта
     */
    public String prefetch(List<SearchRequest> queries) {
        StringBuilder sb = new StringBuilder();
        for (SearchRequest query : queries) {
            if (sb.length() > REWOO_TOTAL_LIMIT) {
                break;
            }
            appendQueryResult(sb, query);
        }
        remember("предвыборка по плану", sb.length() + " символов");
        return sb.toString();
    }

    /** Добавляет в сводку результат одного поискового запроса: найденные цитаты. */
    private void appendQueryResult(StringBuilder sb, SearchRequest query) {
        List<Map<String, Object>> hits = searchHits(query);
        sb.append("• «").append(query.query()).append("»: ");
        if (hits.isEmpty()) {
            sb.append("не найдено\n");
            return;
        }
        sb.append('\n');
        for (int i = 0; i < Math.min(REWOO_TOP, hits.size()); i++) {
            var hit = hits.get(i);
            sb.append("  [").append(hit.get("name")).append("] …")
                    .append(truncateContext(hit)).append("…\n");
        }
    }

    /** Ищет по запросу; если пусто — по самому длинному слову запроса. */
    private List<Map<String, Object>> searchHits(SearchRequest query) {
        String raw = String.valueOf(query.query());
        Map<String, String> scope = scopeDocs(query.docs());
        List<Map<String, Object>> hits = findHits(raw.toLowerCase(Locale.ROOT), scope);
        if (hits.isEmpty()) {
            String word = longestWord(raw);
            if (word != null) {
                hits = findHits(word.toLowerCase(Locale.ROOT), scope);
            }
        }
        return hits;
    }

    /** Текст цитаты с обрезкой до {@link #REWOO_CONTEXT} и схлопнутыми переносами. */
    private String truncateContext(Map<String, Object> hit) {
        String context = String.valueOf(hit.get("context"));
        if (context.length() > REWOO_CONTEXT) {
            context = context.substring(0, REWOO_CONTEXT) + "…";
        }
        return context.replace('\n', ' ');
    }

    /**
     * Документы узла для цитатной валидации: имя — текст. Рабочие файлы
     * (write_file) ИСКЛЮЧЕНЫ — цитата из собственного конспекта агента не
     * является подтверждением (анти-самоподтверждение).
     */
    public Map<String, String> docsSnapshot() {
        Map<String, String> snapshot = new LinkedHashMap<>(docsByName);
        snapshot.keySet().removeAll(workNoteNames);
        snapshot.putAll(kbChunksByName);
        return java.util.Collections.unmodifiableMap(snapshot);
    }

    /** Перечень документов для системного промпта: «имя (N символов)». */
    public List<String> documentSummary() {
        List<String> list = new ArrayList<>();
        for (var entry : docsByName.entrySet()) {
            list.add(entry.getKey() + " (" + entry.getValue().length() + " символов)");
        }
        return list;
    }

    Map<String, Object> readDocument(ReadRequest request) {
        String name = request.name() == null ? "" : request.name();
        if (overLimit("read_document: " + name + " @" + request.offset())) {
            return Map.of(ERROR_KEY, LIMIT_MESSAGE);
        }
        String text = findDoc(name);
        if (text == null) {
            return Map.of(ERROR_KEY, "Документ не найден: " + name
                    + ". Возьми точное имя из перечня документов.");
        }
        int offset = request.offset() == null ? 0 : Math.max(0, request.offset());
        // анти-листание (сплошное чтение сжигает контекст: наблюдалось 11
        // подряд чтений одного файла) СМЯГЧЕНО: вместо голого запрета сразу
        // отдаётся ХВОСТ документа — итоговые строки («Всего к оплате»,
        // «Итого») живут в конце, и жёсткий обрыв листания терял хвостовые
        // суммы актов (кейс Хилько, акт 2431 «не указано»)
        if (isSequentialReadBinge(name) && text.length() > READ_CHUNK
                && offset < text.length() - READ_CHUNK) {
            int tailOffset = text.length() - READ_CHUNK;
            isRepeat("read:" + name + ":" + tailOffset);
            Map<String, Object> tail = new HashMap<>();
            tail.put("warning", "Ты читаешь этот документ подряд — вот сразу его КОНЕЦ "
                    + "(итоговые строки обычно там). Дальше используй search_documents "
                    + "по коротким ключевым словам.");
            tail.put("name", name);
            tail.put("fragment", text.substring(tailOffset));
            tail.put("total_chars", text.length());
            remember("чтение '" + name + "' @" + tailOffset + " (хвост)", tail.get("fragment"));
            trace("📖 листание прервано — отдаю конец «" + name + "»");
            return tail;
        }
        if (isRepeat("read:" + name + ":" + offset)) {
            return Map.of(ERROR_KEY, REPEAT_MESSAGE);
        }
        if (offset >= text.length()) {
            return Map.of(ERROR_KEY, "Смещение за концом документа",
                    "total_chars", text.length());
        }
        int end = Math.min(text.length(), offset + READ_CHUNK);
        Map<String, Object> result = new HashMap<>();
        result.put("name", name);
        result.put("fragment", text.substring(offset, end));
        result.put("total_chars", text.length());
        if (end < text.length()) {
            result.put("next_offset", end);
        }
        remember("чтение '" + name + "' @" + offset, result.get("fragment"));
        trace("📖 читаю «" + name + "» с позиции " + offset);
        return result;
    }

    Map<String, Object> searchDocuments(SearchRequest request) {
        String query = request.query() == null ? "" : request.query().strip();
        if (overLimit("search_documents: " + query)) {
            return Map.of(ERROR_KEY, LIMIT_MESSAGE);
        }
        if (query.isEmpty()) {
            return Map.of(ERROR_KEY, "Пустой поисковый запрос");
        }
        if (isRepeat("search:" + query + ":" + request.docs())) {
            return Map.of(ERROR_KEY, REPEAT_MESSAGE);
        }
        String norm = query.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").strip();
        if (isFruitlessRephrase(norm)) {
            trace("⏭ «" + query + "» — расширение бесплодного запроса, отклонено без поиска");
            return Map.of(ERROR_KEY, CHANGE_STRATEGY_MESSAGE);
        }
        Map<String, String> scope = scopeDocs(request.docs());
        Map<String, Object> numeric = numericSearch(query, scope);
        if (!numeric.isEmpty()) {
            return numeric;
        }
        List<Map<String, Object>> hits = findHits(query.toLowerCase(Locale.ROOT), scope);
        if (!hits.isEmpty()) {
            fruitlessStreak = 0;
            remember("поиск '" + query + "'", hits);
            trace("🔎 «" + query + "» → " + hits.size() + " вхождений");
            return Map.of("hits", hits);
        }
        // длинная фраза не совпала дословно («дата начала подачи» vs «дата начала
        // срока подачи») — фолбэк: поиск по самому длинному слову фразы
        String word = longestWord(query);
        if (word != null) {
            hits = findHits(word.toLowerCase(Locale.ROOT), scope);
            if (!hits.isEmpty()) {
                fruitlessStreak = 0;
                remember("поиск '" + query + "' (по слову '" + word + "')", hits);
                trace("🔎 «" + query + "» → фраза не найдена, по слову «" + word + "»: "
                        + hits.size() + " вхождений");
                return Map.of("hits", hits,
                        "note", "Точная фраза не найдена; показаны вхождения слова '" + word + "'.");
            }
        }
        return emptySearchResult(query, norm, scope);
    }

    /**
     * Числовой запрос: в документах суммы записаны с пробелами-разделителями
     * («1 808 920,00»), а модели ищут нормализованное «1808920» — дословный
     * поиск давал ложное «не найдено» (критик клеймил верную сумму выдумкой).
     *
     * @return результат числового поиска или пустая карта — искать как текст
     */
    private Map<String, Object> numericSearch(String query, Map<String, String> scope) {
        String digits = query.replaceAll("[\\s.,]", "");
        if (!digits.matches("\\d{4,}")) {
            return Map.of();
        }
        List<Map<String, Object>> numericHits = findNumericHits(digits, scope);
        if (numericHits.isEmpty()) {
            return Map.of();
        }
        fruitlessStreak = 0;
        remember("поиск числа '" + query + "'", numericHits);
        trace("🔎 число «" + query + "» → " + numericHits.size() + " вхождений");
        return Map.of("hits", numericHits,
                "note", "Число найдено с учётом пробелов-разделителей в документе.");
    }

    /**
     * Расширение бесплодного запроса: модель, упёршись в «ничего не найдено»,
     * наращивает ту же формулировку словами («… к ней к ней»), обходя
     * дедупликацию точных повторов (наблюдалась петля из 15+ пустых поисков
     * подряд). Новый запрос, содержащий уже провалившийся целиком, отклоняется
     * без поиска; УКОРАЧИВАНИЕ запроса — легитимное уточнение, не блокируется.
     */
    private boolean isFruitlessRephrase(String norm) {
        for (String failed : fruitlessQueries) {
            if (norm.length() > failed.length() && norm.contains(failed)) {
                return true;
            }
        }
        return false;
    }

    /** Пустой результат: запрос запоминается как бесплодный, серия — смена стратегии. */
    private Map<String, Object> emptySearchResult(String query, String norm,
                                                  Map<String, String> scope) {
        fruitlessQueries.add(norm);
        fruitlessStreak++;
        trace("🔎 «" + query + "» → ничего не найдено");
        if (fruitlessStreak >= FRUITLESS_STREAK_LIMIT) {
            return Map.of("hits", List.of(), "note", CHANGE_STRATEGY_MESSAGE);
        }
        return Map.of("hits", List.of(),
                "note", "Ничего не найдено. Попробуй другое ключевое слово или его часть"
                        + (scope.size() < docsByName.size() ? ", либо поищи без фильтра docs" : "")
                        + ".");
    }

    /** Область поиска: документы, чьи имена содержат любую из подстрок фильтра. */
    private Map<String, String> scopeDocs(List<String> docs) {
        if (docs == null || docs.isEmpty()) {
            return docsByName;
        }
        Map<String, String> scoped = new LinkedHashMap<>();
        for (var entry : docsByName.entrySet()) {
            String lower = entry.getKey().toLowerCase(Locale.ROOT);
            for (String filter : docs) {
                if (filter != null && !filter.isBlank()
                        && lower.contains(filter.toLowerCase(Locale.ROOT).strip())) {
                    scoped.put(entry.getKey(), entry.getValue());
                    break;
                }
            }
        }
        // фильтр никого не поймал — ищем по всем (лучше шум, чем пустота)
        return scoped.isEmpty() ? docsByName : scoped;
    }

    /**
     * Поиск числа с допуском пробелов-разделителей между цифрами
     * («1808920» находит «1 808 920,00»).
     *
     * @param digits цифры искомого числа
     * @return вхождения с контекстом
     */
    private List<Map<String, Object>> findNumericHits(String digits, Map<String, String> scope) {
        // между цифрами допустимы пробелы (разряды) и точка/запятая (копейки):
        // запрос «1808920.00» находит в документе «1 808 920,00»
        StringBuilder regex = new StringBuilder("(?<!\\d)");
        for (int i = 0; i < digits.length(); i++) {
            if (i > 0) {
                regex.append("[\\s\\u00A0.,]*");
            }
            regex.append(digits.charAt(i));
        }
        var pattern = Pattern.compile(regex.toString());
        List<Map<String, Object>> hits = new ArrayList<>();
        for (var entry : scope.entrySet()) {
            var matcher = pattern.matcher(entry.getValue());
            while (matcher.find() && hits.size() < SEARCH_MAX_HITS) {
                int start = Math.max(0, matcher.start() - SEARCH_CONTEXT);
                int end = Math.min(entry.getValue().length(), matcher.end() + SEARCH_CONTEXT);
                hits.add(Map.of("name", entry.getKey(), "position", matcher.start(),
                        "context", entry.getValue().substring(start, end)));
            }
            if (hits.size() >= SEARCH_MAX_HITS) {
                break;
            }
        }
        return hits;
    }

    private List<Map<String, Object>> findHits(String needle, Map<String, String> scope) {
        List<Map<String, Object>> hits = new ArrayList<>();
        for (var entry : scope.entrySet()) {
            collectHits(hits, entry.getKey(), entry.getValue(), needle);
            if (hits.size() >= SEARCH_MAX_HITS) {
                break;
            }
        }
        return hits;
    }

    /** Самое длинное слово фразы (минимум 4 символа), null — фраза из одного слова. */
    private static String longestWord(String query) {
        String[] words = query.split("[\\s,;:.!?()«»\"]+");
        if (words.length < 2) {
            return null;
        }
        String best = null;
        for (String word : words) {
            if (word.length() >= 4 && (best == null || word.length() > best.length())) {
                best = word;
            }
        }
        return best;
    }

    private void collectHits(List<Map<String, Object>> hits, String name, String text, String needle) {
        String lower = text.toLowerCase(Locale.ROOT);
        int from = 0;
        while (hits.size() < SEARCH_MAX_HITS) {
            int pos = lower.indexOf(needle, from);
            if (pos < 0) {
                return;
            }
            int start = Math.max(0, pos - SEARCH_CONTEXT);
            int end = Math.min(text.length(), pos + needle.length() + SEARCH_CONTEXT);
            hits.add(Map.of("name", name, "position", pos,
                    "context", text.substring(start, end)));
            // соседние вхождения в том же контексте не дублируются
            from = pos + Math.max(needle.length(), SEARCH_CONTEXT);
        }
    }

    Map<String, Object> searchKnowledgeBase(KbSearchRequest request) {
        String query = request.query() == null ? "" : request.query().strip();
        if (overLimit("search_knowledge_base: " + query)) {
            return Map.of(ERROR_KEY, LIMIT_MESSAGE);
        }
        if (query.isEmpty()) {
            return Map.of(ERROR_KEY, "Пустой поисковый запрос");
        }
        List<String> chunks = kbSearch.apply(query);
        trace("📚 база знаний «" + query + "» → "
                + (chunks == null ? 0 : chunks.size()) + " фрагментов");
        if (chunks == null || chunks.isEmpty()) {
            return Map.of("chunks", List.of(),
                    "note", "В базе знаний ничего не найдено — не выдумывай данные.");
        }
        rememberKbChunks(query, chunks);
        return Map.of("chunks", chunks);
    }

    /** Инструменты базы знаний: точный текст нормы по реквизиту и семантический поиск. */
    private void addKnowledgeBaseTools(List<ToolCallback> tools) {
        if (normIndexSupplier != null) {
            tools.add(FunctionToolCallback
                    .builder("kb_article", this::kbArticle)
                    .description("Точный текст нормы из базы знаний по реквизиту, без семантического поиска: "
                            + "requisite — «п. 2, 4 ч. 1 ст. 3 223-ФЗ», «ч. 17–21 ст. 3.2 223-ФЗ», «ст. 164 НК РФ», "
                            + "«п. 14(3) ПП 1352», «Положение 2348-3 разд. 5», «ТС 4620-3 разд. 4» (несколько — через «;»). "
                            + "Возвращает текст именно этой части/пунктов статьи. Для реквизитов из подсказок используй "
                            + "его, а не search_knowledge_base.")
                    .inputType(ArticleRequest.class)
                    .build());
        }
        if (kbSearch != null) {
            tools.add(FunctionToolCallback
                    .builder("search_knowledge_base", this::searchKnowledgeBase)
                    .description("Семантический поиск по подключённой базе знаний. "
                            + "Возвращает релевантные фрагменты по текстовому запросу.")
                    .inputType(KbSearchRequest.class)
                    .build());
        }
    }

    /** Доменные инструменты: детерминированные проверки документов, те же, что операции узла «Трансформация». */
    private void addDomainTools(List<ToolCallback> tools) {
        if (operationRunner == null) {
            return;
        }
        tools.add(FunctionToolCallback.builder("check_amounts", this::checkAmounts)
                .description("Кодовая сверка сумм: все суммы рядом с меткой (label — regex, например «НМЦД?», "
                        + "«обеспечени[ея]», «аванс») по всем документам с указанием, где какая встречается. "
                        + "Используй вместо ручного поиска чисел.")
                .inputType(AmountsRequest.class).build());
        tools.add(FunctionToolCallback.builder("check_percentages", this::checkPercentages)
                .description("Кодовая проверка процентов: сопоставляет «N % от НМЦД/цены» с указанной рядом суммой "
                        + "и сообщает расхождения. docs — необязательный фильтр по подстроке имени документа.")
                .inputType(DocsRequest.class).build());
        tools.add(FunctionToolCallback.builder("check_dates", this::checkDates)
                .description("Кодовая сверка дат: даты подписания договора против начала оказания услуг, "
                        + "сроки в документах. docs — необязательный фильтр по подстроке имени документа.")
                .inputType(DocsRequest.class).build());
        tools.add(FunctionToolCallback.builder("extract_regex", this::extractRegex)
                .description("Извлечение значения regex-ом из документов: pattern — Java-regex с группой 1, "
                        + "docs — regex имени файла (предпочтительные документы), all — вернуть все совпадения.")
                .inputType(RegexRequest.class).build());
        tools.add(FunctionToolCallback.builder("locate_quote", this::locateQuote)
                .description("Проверка цитаты кодом: есть ли дословно (с допуском по пробелам и переносам) "
                        + "в документах, в каком файле. Используй перед тем, как ссылаться на цитату.")
                .inputType(QuoteRequest.class).build());
    }

    Map<String, Object> checkAmounts(AmountsRequest r) {
        String label = r.label() == null || r.label().isBlank() ? "НМЦД?" : r.label().strip();
        return runDomain("check_amounts", "сверить_суммы", Map.of("метка", label), "");
    }

    Map<String, Object> checkPercentages(DocsRequest r) {
        return runDomain("check_percentages", "проверить_проценты", docsParam(r.docs()), "");
    }

    Map<String, Object> checkDates(DocsRequest r) {
        return runDomain("check_dates", "сверить_даты", docsParam(r.docs()), "");
    }

    Map<String, Object> extractRegex(RegexRequest r) {
        if (r.pattern() == null || r.pattern().isBlank()) {
            return Map.of(ERROR_KEY, "Пустой шаблон");
        }
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("шаблон", r.pattern());
        params.put("группа", "1");
        if (r.docs() != null && !r.docs().isBlank()) {
            params.put("имя", r.docs());
        }
        if (Boolean.TRUE.equals(r.all())) {
            params.put("все", "true");
        }
        return runDomain("extract_regex", "извлечь_из_документов", params, "");
    }

    Map<String, Object> locateQuote(QuoteRequest r) {
        if (r.quote() == null || r.quote().isBlank()) {
            return Map.of(ERROR_KEY, "Пустая цитата");
        }
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("поле", "цитата");
        if (r.docs() != null && !r.docs().isBlank()) {
            params.put("документы", r.docs());
        }
        String input = "[{\"цитата\": " + quoteJson(r.quote()) + "}]";
        return runDomain("locate_quote", "проверить_цитаты", params, input);
    }

    private static Map<String, Object> docsParam(String docs) {
        return docs == null || docs.isBlank() ? Map.of() : Map.of("документы", docs.strip());
    }

    private static String quoteJson(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ") + "\"";
    }

    private Map<String, Object> runDomain(String tool, String operation, Map<String, Object> params, String input) {
        if (overLimit(tool + ": " + params)) {
            return Map.of(ERROR_KEY, LIMIT_MESSAGE);
        }
        String result = operationRunner.run(operation, params, input);
        trace("🧮 " + tool + " → " + StringUtils.abbreviate(result.replace('\n', ' '), 120));
        return Map.of("результат", StringUtils.abbreviate(result, OBSERVATION_LIMIT));
    }

    Map<String, Object> kbArticle(ArticleRequest request) {
        String requisite = request.requisite() == null ? "" : request.requisite().strip();
        if (overLimit("kb_article: " + requisite)) {
            return Map.of(ERROR_KEY, LIMIT_MESSAGE);
        }
        if (requisite.isEmpty()) {
            return Map.of(ERROR_KEY, "Пустой реквизит");
        }
        if (normIndex == null) {
            normIndex = normIndexSupplier.get();
        }
        List<NormIndex.Hit> hits = normIndex.resolve(requisite);
        trace("📖 норма «" + StringUtils.abbreviate(requisite, 60) + "» → " + hits.size() + " фрагментов");
        if (hits.isEmpty()) {
            return Map.of("нормы", List.of(), "note", "Реквизит не распознан или акта нет в базе — используй search_knowledge_base.");
        }
        List<Map<String, Object>> out = new ArrayList<>();
        for (NormIndex.Hit hit : hits) {
            kbChunksByName.put("база знаний: " + hit.document(), hit.text());
            out.add(Map.of("реквизит", hit.requisite(), "документ", hit.document(), "текст", hit.text(),
                    "часть_найдена", hit.partFound()));
        }
        return Map.of("нормы", out);
    }

    /** Фрагменты базы — в корпус валидации под именем «база знаний: <запрос> #N». */
    private void rememberKbChunks(String query, List<String> chunks) {
        int index = 0;
        for (String chunk : chunks) {
            if (chunk != null && !chunk.isBlank()) {
                kbChunksByName.put("база знаний: " + StringUtils.abbreviate(query, 60) + " #" + (++index), chunk);
            }
        }
    }

    /** Точное имя, иначе единственное совпадение по подстроке (модели сокращают пути). */
    private String findDoc(String name) {
        String exact = docsByName.get(name);
        if (exact != null) {
            return exact;
        }
        String needle = name.toLowerCase(Locale.ROOT);
        List<String> matches = docsByName.keySet().stream()
                .filter(k -> k.toLowerCase(Locale.ROOT).contains(needle))
                .toList();
        return matches.size() == 1 ? docsByName.get(matches.get(0)) : null;
    }
}
