package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.List;

/**
 * JSON-объекты верхнего уровня, встречающиеся в тексте ответов моделей (в том числе внутри блоков ```json).
 */
final class JsonBlocks {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private JsonBlocks() {
    }

    /**
     * Все разбираемые JSON-объекты текста по порядку.
     *
     * @param text текст
     * @return объекты
     */
    static List<JsonNode> objects(String text) {
        List<JsonNode> result = new ArrayList<>();
        String source = text == null ? "" : text;
        int start = source.indexOf('{');
        while (start >= 0) {
            int end = closingBrace(source, start);
            JsonNode node = end > start ? parse(source.substring(start, end + 1)) : null;
            if (node != null && node.isObject()) {
                result.add(node);
                start = source.indexOf('{', end + 1);
            } else {
                start = source.indexOf('{', start + 1);
            }
        }
        return result;
    }

    /**
     * Объект с заданным значением поля «тип_документа».
     *
     * @param text текст
     * @param type тип документа
     * @return объект либо {@code null}
     */
    static JsonNode byDocumentType(String text, String type) {
        for (JsonNode node : objects(text)) {
            if (type.equalsIgnoreCase(node.path("тип_документа").asText("").strip())) {
                return node;
            }
        }
        return null;
    }

    private static int closingBrace(String text, int start) {
        int depth = 0;
        boolean inString = false;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                inString = c != '"' || text.charAt(i - 1) == '\\';
            } else if (c == '"') {
                inString = true;
            } else if (c == '{' || c == '}') {
                depth += c == '{' ? 1 : -1;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    private static JsonNode parse(String candidate) {
        try {
            return MAPPER.readTree(candidate);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
