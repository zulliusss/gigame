package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Block;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.LineResult;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Status;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecTableParser.SpecPosition;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Операция «сверить_характеристики» узла «Трансформация»: характеристики продукции из таблицы
 * извещения / документации / ТЗ сверяются с текстом договора кодом, построчно и по позициям.
 * <p>
 * Модель сворачивала все требования документа в одну строку и теряла позиции (из 16 позиций
 * мебели проверялись две) и хвосты фраз («прозрачное закаленное стекло. Снизу матовое.» → ложное
 * «НАРУШЕНИЕ»). Код берёт только таблицу характеристик (ГОСТ, сертификаты и упаковка вне таблицы
 * не сверяются), находит каждую позицию в договоре по наименованию и проверяет каждую строку
 * (см. {@link SpecLineCheck}). Модели остаются только строки, не найденные дословно.
 * <pre>
 * {"оп": "сверить_характеристики", "классы_требований": "документация|техническое_задание",
 *  "класс_договора": "договор", "колонка_наименования": "наименован", "колонка_характеристик": "характеристик|описание"}
 * </pre>
 */
final class SpecCheckOps {

    /** Участок позиции в договоре не длиннее (нормализованных символов). */
    static final int MAX_BLOCK = 6000;
    /** Наименование позиции короче (нормализованных символов) не режет договор на участки: «Стол» есть в «Столешнице». */
    private static final int MIN_NAME_FOR_SPLIT = 8;
    private static final int SNIPPET = 500;
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    private SpecCheckOps() {
    }

    /**
     * Сверка характеристик по документам прогона.
     *
     * @param op   параметры операции
     * @param docs документы прогона с классами
     * @return отчёт: сводка, строки без дословного совпадения с текстом позиции в договоре, итоговый JSON
     */
    static String check(Map<String, Object> op, Collection<ScenarioRunDoc> docs) {
        Pattern reqClass = Pattern.compile("^(?:" + op.getOrDefault("классы_требований", "документация|техническое_задание") + ")$", FLAGS);
        Pattern contractClass = Pattern.compile("^(?:" + op.getOrDefault("класс_договора", "договор") + ")$", FLAGS);
        Pattern nameCol = Pattern.compile(String.valueOf(op.getOrDefault("колонка_наименования", "наименован")), FLAGS);
        Pattern specCol = Pattern.compile(String.valueOf(op.getOrDefault("колонка_характеристик", "характеристик|описание")), FLAGS);
        List<SpecPosition> positions = new ArrayList<>();
        List<ScenarioRunDoc> contracts = new ArrayList<>();
        for (ScenarioRunDoc doc : docs) {
            if (matches(reqClass, doc)) {
                positions.addAll(SpecTableParser.parse(doc.getText(), doc.getFilename(), nameCol, specCol));
            } else if (matches(contractClass, doc)) {
                contracts.add(doc);
            }
        }
        StringBuilder sb = new StringBuilder("СВЕРКА ХАРАКТЕРИСТИК (код)\n");
        if (positions.isEmpty() || contracts.isEmpty()) {
            return sb.append(positions.isEmpty() ? "ТАБЛИЦА ХАРАКТЕРИСТИК НЕ НАЙДЕНА в документации и ТЗ — характеристики сверяет модель по извлечённым требованиям\n"
                    : "ДОГОВОР НЕ ПРИЛОЖЕН — характеристики не сверяются\n")
                    .append("{\"таблица_найдена\": ").append(!positions.isEmpty()).append(", \"не_найдено\": 0, \"порог_нарушен\": 0}").toString();
        }
        sb.append("Требования: ").append(sources(positions)).append(" — позиций ").append(positions.size())
                .append(", характеристик ").append(positions.stream().mapToInt(p -> p.lines().size()).sum()).append('\n');
        for (ScenarioRunDoc contract : contracts) {
            checkContract(sb, positions, contract);
        }
        return sb.toString();
    }

    private static boolean matches(Pattern cls, ScenarioRunDoc doc) {
        return !doc.isWorkNote() && doc.getDocClass() != null && cls.matcher(doc.getDocClass().strip()).matches();
    }

    private static String sources(List<SpecPosition> positions) {
        return positions.stream().map(p -> "«" + p.source() + "»").distinct().reduce((a, b) -> a + ", " + b).orElse("");
    }

    private static void checkContract(StringBuilder sb, List<SpecPosition> positions, ScenarioRunDoc contract) {
        NormalizedText text = NormalizedText.of(contract.getText());
        Map<Status, Integer> counts = new EnumMap<>(Status.class);
        StringBuilder issues = new StringBuilder();
        List<String> unlocated = new ArrayList<>();
        for (SpecPosition position : positions) {
            List<Block> blocks = SpecBlocks.of(text, position, positions, MIN_NAME_FOR_SPLIT, MAX_BLOCK);
            if (blocks.isEmpty()) {
                unlocated.add("«" + position.name() + "»");
                blocks = List.of(new Block(0, text.norm().length()));
            }
            checkPosition(issues, counts, position, text, blocks);
        }
        sb.append("Договор «").append(contract.getFilename()).append("»: совпали дословно ").append(count(counts, Status.EXACT))
                .append(", совпали с переносами строк ").append(count(counts, Status.GAPPED))
                .append(", порог выполнен ").append(count(counts, Status.THRESHOLD_OK))
                .append(", порог нарушен ").append(count(counts, Status.THRESHOLD_FAIL))
                .append(", не найдены ").append(count(counts, Status.MISSING)).append('\n');
        if (!unlocated.isEmpty()) {
            sb.append("ПОЗИЦИИ НЕ НАЙДЕНЫ В ДОГОВОРЕ ПО НАИМЕНОВАНИЮ (характеристики искались по всему договору): ")
                    .append(String.join("; ", unlocated)).append('\n');
        }
        sb.append(issues.length() == 0 ? "Все характеристики найдены в договоре.\n" : issues.toString());
        sb.append("{\"договор\": \"").append(contract.getFilename().replace("\"", "'")).append("\", \"таблица_найдена\": true, \"не_найдено\": ")
                .append(count(counts, Status.MISSING)).append(", \"порог_нарушен\": ").append(count(counts, Status.THRESHOLD_FAIL))
                .append(", \"позиций_не_найдено\": ").append(unlocated.size()).append("}\n");
    }

    private static void checkPosition(StringBuilder issues, Map<Status, Integer> counts, SpecPosition position, NormalizedText text, List<Block> blocks) {
        boolean snippetShown = false;
        for (String line : position.lines()) {
            LineResult result = SpecLineCheck.check(line, text, blocks);
            counts.merge(result.status(), 1, Integer::sum);
            if (result.status() != Status.MISSING && result.status() != Status.THRESHOLD_FAIL) {
                continue;
            }
            String label = result.status() == Status.MISSING ? "НЕ НАЙДЕНО ДОСЛОВНО" : "ПОРОГ НАРУШЕН";
            issues.append("- ").append(label).append(" | позиция ").append(position.number()).append(" «").append(position.name())
                    .append("» | «").append(line).append("» | ").append(result.detail()).append('\n');
            if (!snippetShown) {
                Block widest = blocks.stream().max((a, b) -> Integer.compare(a.to() - a.from(), b.to() - b.from())).orElse(blocks.get(0));
                issues.append("  текст позиции в договоре: «").append(text.snippet(widest.from(), widest.to(), SNIPPET)).append("»\n");
                snippetShown = true;
            }
        }
    }

    private static int count(Map<Status, Integer> counts, Status status) {
        return counts.getOrDefault(status, 0);
    }
}
