package ru.sber.cs.ai.gigame;

import com.fasterxml.jackson.core.StreamReadConstraints;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication()
@EnableAsync
@EnableScheduling
public class Application {

    /**
     * Верхняя граница длины одной JSON-строки при чтении (Jackson по умолчанию —
     * 20 млн символов). Выход узла «Вход» с текстом большой книги Excel
     * (финансовая структура банка — 26 млн символов) хранится в JSONB шага
     * прогона и при чтении обратно падал с «Could not deserialize string to
     * java type: java.util.Map». 200 млн символов — с запасом под файлы
     * до лимита размера документа.
     */
    static final int MAX_JSON_STRING_LENGTH = 200_000_000;

    static {
        // должно выполниться до создания первого JsonFactory (Spring, Hibernate)
        StreamReadConstraints.overrideDefaultStreamReadConstraints(
                StreamReadConstraints.builder().maxStringLength(MAX_JSON_STRING_LENGTH).build());
    }

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
