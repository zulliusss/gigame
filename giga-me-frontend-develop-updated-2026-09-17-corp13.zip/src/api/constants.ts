export const BASE_URL = '/proto/backend/giga-me/api';

export const MODELS = ['GigaChat-3-Ultra', 'GigaChat-3-Lightning-preview'];
