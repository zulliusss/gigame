import {BASE_URL} from './constants';

/**
 * Ошибка HTTP-запроса к бэкенду: код ответа и человеко-читаемое сообщение
 * (ErrorResponse.message бэкенда, либо описание ответа шлюза без JSON).
 */
export class ApiError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

/**
 * Текст ошибки по телу неуспешного ответа: JSON ErrorResponse → message/error;
 * HTML или иной не-JSON (страница шлюза SOWA/SynGX) → «Шлюз вернул N».
 */
export function errorMessageFromBody(status: number, statusText: string, body: string): string {
  const text = (body || '').trim();
  if (!text) {
    return `Ошибка ${status}${statusText ? ` ${statusText}` : ''}`;
  }
  if (text.startsWith('<')) {
    return `Шлюз вернул ${status} без JSON`;
  }
  try {
    const parsed = JSON.parse(text) as { message?: unknown; error?: unknown };
    if (parsed && typeof parsed === 'object') {
      const message =
        (typeof parsed.message === 'string' && parsed.message) ||
        (typeof parsed.error === 'string' && parsed.error) ||
        '';
      if (message) return message;
    }
    return `Ошибка ${status}${statusText ? ` ${statusText}` : ''}`;
  } catch {
    return `Шлюз вернул ${status} без JSON`;
  }
}

/** Ошибка из неуспешного ответа fetch (тело читается один раз). */
export async function apiErrorFromResponse(res: Response): Promise<ApiError> {
  let body = '';
  try {
    body = await res.text();
  } catch {
    // тело недоступно — остаётся только код
  }
  return new ApiError(res.status, errorMessageFromBody(res.status, res.statusText, body));
}

export async function fetchApi<T>(
  path: string,
  options?: RequestInit,
): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...options?.headers },
  });
  if (!res.ok) {
    throw await apiErrorFromResponse(res);
  }
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  return text ? (JSON.parse(text) as T) : (undefined as T);
}
