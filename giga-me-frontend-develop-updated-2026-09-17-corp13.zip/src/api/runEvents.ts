/**
 * Классификация кадров WebSocket прогона сценария (контракт corp15,
 * ScenarioWebSocketHandler): без зависимостей от браузера — проверяется в node.
 *
 * Бэкенд шлёт `{type, data}`: STATUS с run_id при приёме, терминальные STATUS
 * COMPLETED/FAILED (FAILED с data.error при отказе в запуске, с data.result при
 * завершении с ошибками узлов); прочие ошибки команды — кадр `{session_id, error}`
 * без type. Признака done в кадрах нет.
 */

export type RunEvent = Record<string, unknown>;

/**
 * Синтетический кадр фронта: сокет оборвался во время активного прогона, а
 * слежение по REST (runPolling.ts) невозможно — прогон не найден, отказ, сбои, лимит времени.
 */
export const CONNECTION_LOST_TYPE = 'CONNECTION_LOST';
export const CONNECTION_LOST_MESSAGE =
  'Соединение потеряно; прогон продолжается на сервере — откройте «Подробный отчёт»';

/** Кадр ошибки команды без type: `{session_id, error}`. */
export function runEventError(event: RunEvent): string | null {
  if (!event || event.type) return null;
  const error = event.error;
  return typeof error === 'string' && error ? error : null;
}

/** Статус из data терминального STATUS (COMPLETED/FAILED), иначе null. */
export function terminalRunStatus(event: RunEvent): 'COMPLETED' | 'FAILED' | null {
  if (!event || event.type !== 'STATUS') return null;
  const data = (event.data ?? {}) as Record<string, unknown>;
  const status = typeof data.status === 'string' ? data.status.toUpperCase() : '';
  return status === 'COMPLETED' || status === 'FAILED' ? status : null;
}

/** Кадр завершает поток прогона: терминальный STATUS, кадр ошибки без type, done. */
export function isTerminalRunEvent(event: RunEvent): boolean {
  if (!event) return false;
  if (event.done === true) return true;
  if (terminalRunStatus(event)) return true;
  if (runEventError(event)) return true;
  return event.type === CONNECTION_LOST_TYPE;
}
