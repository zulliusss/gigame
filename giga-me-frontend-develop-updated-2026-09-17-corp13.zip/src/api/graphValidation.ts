/**
 * Проверка графа сценария перед сохранением и запуском — то, что бэкенд не
 * проверяет при PUT, но на чём падает прогон (corp15, ScenarioExecutorIfNode /
 * ScenarioExecutorSwitchNode, ExpressionResolver):
 *  - рёбра из узла If только с метками true/false (без метки IfNode падал с NPE);
 *  - рёбра из Switch только с метками правил (или классов строгой классификации
 *    предшествующего Цикла) либо веткой по умолчанию;
 *  - названия узлов не пустые и не повторяются: выражения ${...} ссылаются на
 *    узел по названию без учёта регистра.
 * Без зависимостей от браузера — проверяется в node.
 */

export interface GraphNodeLike {
  id: string;
  type?: string;
  data?: Record<string, unknown>;
}

export interface GraphEdgeLike {
  id: string;
  source: string;
  target: string;
  data?: Record<string, unknown>;
}

/** Первое найденное нарушение: текст для тоста и нарушитель для выделения. */
export interface GraphIssue {
  message: string;
  nodeId?: string;
  edgeId?: string;
}

/** Метки ветки «истина» узла If (ScenarioExecutorIfNode.TRUE_LABELS). */
const IF_TRUE_LABELS = ['true', 'да', 'истина', 'yes'];
/** Метки ветки «ложь»: бэкенд считает ложью всё, что не истина, панель предлагает false. */
const IF_FALSE_LABELS = ['false', 'нет', 'ложь', 'no'];
/** Ветка по умолчанию Switch (ScenarioExecutorSwitchNode.defaultLabelSet). */
const SWITCH_DEFAULT_LABELS = ['default', 'else', 'прочее', 'другое', 'иначе', '*'];

/** Узлы без названия: заметка в выполнении не участвует. */
const UNLABELED_TYPES = ['note'];

function nodeLabel(node: GraphNodeLike): string {
  const raw = node.data?.label;
  return typeof raw === 'string' ? raw.trim() : '';
}

function edgeLabel(edge: GraphEdgeLike): string {
  const raw = edge.data?.label;
  return typeof raw === 'string' ? raw.trim() : '';
}

function describe(node: GraphNodeLike): string {
  const label = nodeLabel(node);
  return label ? `«${label}»` : `(${node.id}, ${node.type ?? '?'})`;
}

/** Метки правил Switch: поле label, иначе value (как parseRules/matchText бэкенда). */
export function switchRuleLabels(rules: unknown): string[] {
  let parsed: unknown = rules;
  if (typeof rules === 'string') {
    try {
      parsed = JSON.parse(rules || '[]');
    } catch {
      return [];
    }
  }
  if (!Array.isArray(parsed)) return [];
  return parsed
    .map((r) => {
      if (!r || typeof r !== 'object') return '';
      const rule = r as { label?: unknown; value?: unknown };
      const label = typeof rule.label === 'string' ? rule.label.trim() : '';
      const value = typeof rule.value === 'string' ? rule.value.trim() : '';
      return label || value;
    })
    .filter(Boolean);
}

/** Классы строгой классификации Цикла-предшественника (ветки Switch получают документы по классу). */
function predecessorClasses(
  node: GraphNodeLike,
  nodes: GraphNodeLike[],
  edges: GraphEdgeLike[],
): string[] {
  const classes: string[] = [];
  for (const e of edges) {
    if (e.target !== node.id) continue;
    const pred = nodes.find((n) => n.id === e.source);
    if (!pred || pred.type !== 'loop') continue;
    if (String(pred.data?.classify_strict ?? '') !== 'true') continue;
    const raw = typeof pred.data?.classes === 'string' ? pred.data.classes : '';
    classes.push(...raw.split(',').map((c) => c.trim()).filter(Boolean));
  }
  return classes;
}

export function validateGraph(nodes: GraphNodeLike[], edges: GraphEdgeLike[]): GraphIssue | null {
  // Названия узлов: пустые и повторяющиеся (без учёта регистра)
  const seen = new Map<string, GraphNodeLike>();
  for (const node of nodes) {
    if (UNLABELED_TYPES.includes(node.type ?? '')) continue;
    const label = nodeLabel(node);
    if (!label) {
      return {
        message: `Узел ${describe(node)} без названия — задайте название в панели настройки`,
        nodeId: node.id,
      };
    }
    const key = label.toLowerCase();
    const dup = seen.get(key);
    if (dup) {
      return {
        message: `Название «${label}» повторяется у узлов ${dup.id} и ${node.id} — выражения \${...} ссылаются на узел по названию`,
        nodeId: node.id,
      };
    }
    seen.set(key, node);
  }

  // Метки рёбер из узлов ветвления
  for (const node of nodes) {
    if (node.type !== 'if_node' && node.type !== 'switch') continue;
    const outgoing = edges.filter((e) => e.source === node.id);
    if (node.type === 'if_node') {
      for (const edge of outgoing) {
        const label = edgeLabel(edge).toLowerCase();
        if (!IF_TRUE_LABELS.includes(label) && !IF_FALSE_LABELS.includes(label)) {
          return {
            message: `Ребро из узла If ${describe(node)} должно иметь метку true или false` +
              (label ? ` (сейчас «${edgeLabel(edge)}»)` : ' (метка не задана)'),
            edgeId: edge.id,
          };
        }
      }
      continue;
    }
    const allowed = [
      ...switchRuleLabels(node.data?.rules),
      ...predecessorClasses(node, nodes, edges),
    ];
    for (const edge of outgoing) {
      const label = edgeLabel(edge);
      if (!label) {
        return {
          message: `Ребро из узла Switch ${describe(node)} без метки — выберите ветку правила или ветку по умолчанию`,
          edgeId: edge.id,
        };
      }
      if (SWITCH_DEFAULT_LABELS.includes(label.toLowerCase())) continue;
      // правил ещё нет (или они не разбираются) — проверить метку не по чему
      if (allowed.length === 0) continue;
      if (!allowed.includes(label)) {
        return {
          message: `Метка «${label}» ребра из узла Switch ${describe(node)} не совпадает ни с одним правилом (${allowed.join(', ')})`,
          edgeId: edge.id,
        };
      }
    }
  }
  return null;
}
