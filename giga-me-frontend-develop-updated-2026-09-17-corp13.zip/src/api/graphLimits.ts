/**
 * Приведение графа сценария к лимитам статической OpenAPI-спецификации
 * (openapi/gigame.yaml), по которой корп. шлюз SOWA проверяет тела
 * POST/PUT /api/scenarios: PositionDto x/y в [-4096, 4096], MeasuredDto
 * width/height в [0, 1000], data.temperature — строка ^[0-9.,]{0,8}$,
 * без значений null (nullable шлюз не учитывает). Нарушение любого узла
 * отклоняет сохранение целиком.
 */

const POSITION_LIMIT = 4096;
const POSITION_SPAN = POSITION_LIMIT * 2;
const MEASURED_MAX = 1000;
const TEMPERATURE_MAX = 2;
const TEMPERATURE_PATTERN = /^[0-9.]{1,8}$/;

type JsonObject = Record<string, unknown>;

/** Общий сдвиг графа по осям, сохраняющий взаимное расположение узлов. */
interface Offset {
  dx: number;
  dy: number;
}

function isObject(value: unknown): value is JsonObject {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value);
}

function clampNumber(value: unknown, min: number, max: number): unknown {
  return isFiniteNumber(value) ? Math.min(max, Math.max(min, value)) : value;
}

/** Копия объекта без ключей со значением null. */
function withoutNulls(value: JsonObject): JsonObject {
  return Object.fromEntries(Object.entries(value).filter(([, v]) => v !== null));
}

/**
 * Температура узла: пусто — значение сервера; иначе число 0..2 в обычной
 * десятичной записи (без минуса и экспоненты), не длиннее 8 символов.
 * Запятая приводится к точке (её понимают и шлюз, и бэкенд). Корректно
 * набранное значение (например «0.» или «0.0» в процессе ввода «0.05»)
 * возвращается как есть, чтобы не сбивать ввод в поле.
 */
export function normalizeTemperature(raw: string): string {
  const value = raw.trim().replace(/,/g, '.');
  if (value === '') return '';
  const n = Number(value);
  if (!Number.isFinite(n)) return '';
  if (n >= 0 && n <= TEMPERATURE_MAX && TEMPERATURE_PATTERN.test(value)) return value;
  return String(Math.round(Math.min(TEMPERATURE_MAX, Math.max(0, n)) * 100) / 100);
}

/**
 * Сдвиг по оси, возвращающий граф в [-4096, 4096] целиком. Если размах
 * больше 8192, граф центрируется: за границей остаётся наименьшая часть
 * поровну с обеих сторон, её координаты зажимаются поштучно.
 */
function axisOffset(values: number[]): number {
  if (values.length === 0) return 0;
  const min = Math.min(...values);
  const max = Math.max(...values);
  if (max - min > POSITION_SPAN) return -(max + min) / 2;
  if (max > POSITION_LIMIT) return POSITION_LIMIT - max;
  if (min < -POSITION_LIMIT) return -POSITION_LIMIT - min;
  return 0;
}

function coordinatesOf(nodes: unknown[], axis: 'x' | 'y'): number[] {
  return nodes
    .map((node) => (isObject(node) && isObject(node.position) ? node.position[axis] : undefined))
    .filter(isFiniteNumber);
}

function graphOffset(nodes: unknown[]): Offset {
  return { dx: axisOffset(coordinatesOf(nodes, 'x')), dy: axisOffset(coordinatesOf(nodes, 'y')) };
}

/** Координата после общего сдвига, зажатая в диапазон; нечисловая (в том числе null) — 0. */
function limitCoordinate(value: unknown, offset: number): number {
  return isFiniteNumber(value) ? Math.min(POSITION_LIMIT, Math.max(-POSITION_LIMIT, value + offset)) : 0;
}

function limitPosition(position: JsonObject, offset: Offset): JsonObject {
  return { ...position, x: limitCoordinate(position.x, offset.dx), y: limitCoordinate(position.y, offset.dy) };
}

function limitMeasured(measured: JsonObject): JsonObject {
  const result = withoutNulls(measured);
  for (const key of ['width', 'height']) {
    if (key in result) result[key] = clampNumber(result[key], 0, MEASURED_MAX);
  }
  return result;
}

/**
 * Температура для отправки: как в поле ввода, но без точки на конце —
 * «1.» сервер понимает как 1, а поле после перезагрузки показало бы
 * «по умолчанию».
 */
function temperatureForRequest(raw: string): string {
  const value = normalizeTemperature(raw);
  return value.endsWith('.') ? value.slice(0, -1) : value;
}

function limitNodeData(data: JsonObject): JsonObject {
  const result = withoutNulls(data);
  const temperature = result.temperature;
  if (typeof temperature === 'string' || typeof temperature === 'number') {
    result.temperature = temperatureForRequest(String(temperature));
  }
  return result;
}

function limitNode(node: unknown, offset: Offset): unknown {
  if (!isObject(node)) return node;
  const result = withoutNulls(node);
  // узел без координат (position отсутствует или null в импортированном JSON) получает 0,0
  result.position = limitPosition(isObject(result.position) ? result.position : {}, offset);
  if (isObject(result.measured)) result.measured = limitMeasured(result.measured);
  if (isObject(result.data)) result.data = limitNodeData(result.data);
  return result;
}

function limitEdge(edge: unknown): unknown {
  if (!isObject(edge)) return edge;
  const result = withoutNulls(edge);
  if (isObject(result.data)) result.data = withoutNulls(result.data);
  return result;
}

/**
 * Копия графа для отправки на сервер: граф, вышедший за ±4096, сдвигается
 * целиком (поштучный зажим — только при размахе больше 8192), размеры узлов
 * зажаты, температура нормализована, ключи со значением null убраны.
 * Граф в редакторе (стор) не меняется.
 */
export function limitGraphForGateway(graph: unknown): unknown {
  if (!isObject(graph) || !Array.isArray(graph.nodes)) return graph;
  const offset = graphOffset(graph.nodes);
  const nodes = graph.nodes.map((node) => limitNode(node, offset));
  const edges = Array.isArray(graph.edges) ? graph.edges.map(limitEdge) : graph.edges;
  return { ...graph, nodes, edges };
}
