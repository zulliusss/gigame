// import { BASE_URL } from "./constants";

export interface StreamEvent {
    conversation_id?: string;
    content?: string;
    usage?: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
    document_ids?: string[];
    sources?: { document_id?: string; document_name?: string; snippet?: string }[];
    done?: boolean;
    error?: string;
    // Исходящие поля (клиент -> сервер)
    action?: 'send' | 'regenerate' | 'edit';
    message_id?: string;
  }

  export type StreamEventCallback = (event: StreamEvent) => void;
  
  class WebSocketClient {
    private ws: WebSocket | null = null;
    private url: string;
    private reconnectDelay: number = 1000;
    private maxReconnectDelay: number = 30000;
    private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    private isManualClose: boolean = false;
    private messageQueue: StreamEvent[] = [];
  
    private onMessageCallback: StreamEventCallback | null = null;
    private onOpenCallback: (() => void) | null = null;
    private onCloseCallback: (() => void) | null = null;
    private onErrorCallback: ((error: Event) => void) | null = null;
    // Автопереподключение: для чата — да; для прогона сценария — нет: новый пустой
    // сокет не привязан к серверному потоку прогона, а команда run в очереди
    // ушла бы повторно и запустила бы второй прогон
    private autoReconnect: boolean;
  
    constructor(url: string, autoReconnect: boolean = true) {
      // Convert relative URL to absolute WebSocket URL
      if (url.startsWith('/')) {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        this.url = `${protocol}//${window.location.host}${url}`;
      } else {
        this.url = url;
      }
      this.autoReconnect = autoReconnect;
    }
  
    public connect(): void {
      this.isManualClose = false;
      if (this.reconnectTimer) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = null;
      }
      // прежний сокет закрывается без обработчиков: иначе его onclose
      // запланировал бы переподключение и вызвал onClose нового прогона
      this.detachAndClose();
      this.ws = new WebSocket(this.url);
  
      this.ws.onopen = () => {
        console.log('WebSocket connected');
        // после успешного соединения задержка повторов начинается заново
        this.reconnectDelay = 1000;
        this.onOpenCallback?.();
        // Send queued messages after connection is established
        if (this.messageQueue.length > 0) {
          console.log(`Sending ${this.messageQueue.length} queued messages`);
          this.messageQueue.forEach(msg => this.sendInternal(msg));
          this.messageQueue = [];
        }
      };
  
      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data) as StreamEvent;
          this.onMessageCallback?.(data);
        } catch (e) {
          console.warn('WebSocket parse error:', event.data, e);
        }
      };
  
      this.ws.onclose = () => {
        console.log('WebSocket disconnected');
        this.onCloseCallback?.();
        if (this.autoReconnect && !this.isManualClose && this.reconnectTimer === null) {
          this.scheduleReconnect();
        }
        // Clear queue on close to prevent sending to closed socket
        this.messageQueue = [];
      };
  
      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        this.onErrorCallback?.(error);
      };
    }
  
    /** Закрывает текущий сокет, сняв его обработчики (без onclose/onerror наружу). */
    private detachAndClose(): void {
      const old = this.ws;
      if (!old) return;
      this.ws = null;
      old.onopen = null;
      old.onmessage = null;
      old.onclose = null;
      old.onerror = null;
      try {
        old.close();
      } catch {
        // сокет уже закрыт
      }
    }
  
    private sendInternal(event: StreamEvent): void {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify(event));
      }
    }
  
    public disconnect(): void {
      this.isManualClose = true;
      if (this.reconnectTimer) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = null;
      }
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }
    }
  
    public send(event: StreamEvent): void {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify(event));
      } else {
        // Only queue if we haven't manually closed
        if (!this.isManualClose) {
          this.messageQueue.push(event);
        }
      }
    }
  
    public setOnMessage(callback: StreamEventCallback | null): void {
      this.onMessageCallback = callback;
    }
  
    public setOnOpen(callback: (() => void) | null): void {
      this.onOpenCallback = callback;
    }
  
    public setOnClose(callback: (() => void) | null): void {
      this.onCloseCallback = callback;
    }
  
    public setOnError(callback: ((error: Event) => void) | null): void {
      this.onErrorCallback = callback;
    }
  
    private scheduleReconnect(): void {
      this.reconnectTimer = setTimeout(() => {
        if (!this.isManualClose) {
          console.log(`Reconnecting to ${this.url}...`);
          this.connect();
        }
        this.reconnectTimer = null;
      }, this.reconnectDelay);

      // Increase delay exponentially up to max
      this.reconnectDelay = Math.min(this.reconnectDelay * 2, this.maxReconnectDelay);
    }

    public isConnected(): boolean {
      return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
    }

    public getWs(): WebSocket | null {
      return this.ws;
    }
  }
  
  // Create a singleton WebSocket client for chat
  let chatWebSocket: WebSocketClient | null = null;
  
  export function getWebSocketClient(): WebSocketClient {
    if (!chatWebSocket) {
      // Use relative URL to leverage Vite proxy for /ws
      chatWebSocket = new WebSocketClient('/proto/backend/giga-me' + '/ws/chat');
    }
    return chatWebSocket;
  }
  
  // Create a singleton WebSocket client for scenario runs
  let scenarioWebSocket: WebSocketClient | null = null;
  
  export function getScenarioWebSocketClient(): WebSocketClient {
    if (!scenarioWebSocket) {
      // Use relative URL to leverage Vite proxy for /ws
      scenarioWebSocket = new WebSocketClient('/proto/backend/giga-me' + '/ws/scenario', false);
    }
    return scenarioWebSocket;
  }
  
  export function closeScenarioWebSocket(): void {
    if (scenarioWebSocket) {
      scenarioWebSocket.disconnect();
      scenarioWebSocket = null;
    }
  }
  
  export function closeWebSocket(): void {
    if (chatWebSocket) {
      chatWebSocket.disconnect();
      chatWebSocket = null;
    }
  }