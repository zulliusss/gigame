import { fetchApi } from './client';

// Ключи ответов — snake_case, как в схемах AgentLessonResponseDto/AgentPlan/AgentQuestion
// спецификации шлюза SOWA; поля со значением null сервер в JSON не включает.

/** Урок агента: правило из прошлых прогонов. */
export interface AgentLesson {
  id: string;
  scenario_id?: string | null;
  user_id?: string | null;
  lesson: string;
  source: 'user' | 'reviser' | 'auto' | 'system';
  approved: boolean;
  created_at?: string;
  updated_at?: string;
}

/** План из памяти планов (проверенный чек-лист задания). */
export interface AgentPlan {
  id: string;
  scenario_id?: string | null;
  task_hash?: string;
  task_preview?: string | null;
  plan: string;
  uses: number;
  created_at?: string;
  updated_at?: string;
}

/** Вопрос агента пользователю (асинхронный HITL). */
export interface AgentQuestion {
  id: string;
  run_id: string;
  scenario_id?: string | null;
  node_label?: string | null;
  question: string;
  answer?: string | null;
  answered_at?: string | null;
  created_at?: string;
}

/** maxLength текста урока и ответа на вопрос в схемах запросов спецификации. */
export const AGENT_TEXT_MAX_LENGTH = 4000;

export function getAgentLessons(scenarioId?: string): Promise<AgentLesson[]> {
  const query = scenarioId ? `?scenario_id=${scenarioId}` : '';
  return fetchApi(`/agent/lessons${query}`);
}

export function addAgentLesson(lesson: string, scenarioId?: string): Promise<AgentLesson> {
  return fetchApi('/agent/lessons', {
    method: 'POST',
    body: JSON.stringify({ lesson, scenario_id: scenarioId ?? '' }),
  });
}

export function updateAgentLesson(id: string, lesson: string): Promise<AgentLesson> {
  return fetchApi(`/agent/lessons/${id}`, { method: 'PUT', body: JSON.stringify({ lesson }) });
}

export function deleteAgentLesson(id: string): Promise<void> {
  return fetchApi(`/agent/lessons/${id}`, { method: 'DELETE' });
}

export function approveAgentLesson(id: string): Promise<AgentLesson> {
  return fetchApi(`/agent/lessons/${id}/approve`, { method: 'POST' });
}

export function compressAgentLessons(scenarioId: string): Promise<AgentLesson[]> {
  return fetchApi('/agent/lessons/compress', {
    method: 'POST',
    body: JSON.stringify({ scenario_id: scenarioId }),
  });
}

export function getAgentPlans(scenarioId: string): Promise<AgentPlan[]> {
  return fetchApi(`/agent/plans?scenario_id=${scenarioId}`);
}

export function deleteAgentPlan(id: string): Promise<void> {
  return fetchApi(`/agent/plans/${id}`, { method: 'DELETE' });
}

export function extractAgentLessons(runId: string): Promise<AgentLesson[]> {
  return fetchApi('/agent/lessons/extract', {
    method: 'POST',
    body: JSON.stringify({ run_id: runId }),
  });
}

export function getAgentQuestions(runId: string): Promise<AgentQuestion[]> {
  return fetchApi(`/agent/questions?run_id=${runId}`);
}

export function answerAgentQuestion(id: string, answer: string): Promise<AgentQuestion> {
  return fetchApi(`/agent/questions/${id}/answer`, {
    method: 'POST',
    body: JSON.stringify({ answer }),
  });
}
