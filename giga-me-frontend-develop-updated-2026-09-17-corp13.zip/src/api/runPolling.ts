/**
 * Слежение за прогоном сценария по REST после обрыва WebSocket: прокси корп-контура
 * (SynGX) закрывает сокет через 300 с общей длительности соединения, а прогон на
 * сервере продолжается. Ответы GET /scenarios/runs/{runId} и GET /scenarios/{id}/runs
 * переводятся в кадры того же вида, что шлёт ScenarioWebSocketHandler (STATUS,
 * NODE_STATUS, STEP_COMPLETE, FILE_OUTPUT), — раннер обрабатывает их теми же ветками.
 * Без зависимостей от браузера — проверяется в node (tests/runPolling.test.mjs):
 * запросы, пауза и часы цикла слежения подставляются вызывающим кодом (scenarios.ts).
 *
 * Контракт corp18: статусы прогона и шагов в нижнем регистре (running/completed/failed),
 * result прогона — строка; null-поля бэкенд опускает; шагов не больше 100 (первые 99 и
 * последний), на один узел их может быть несколько, порядок started_at asc; меток узлов
 * в шагах нет — они берутся из графа сценария. Журнал агента, итерации циклов и ветки
 * If/Switch в REST не сохраняются. Пошагового режима после обрыва нет: закрытие сессии
 * вызывает ScenarioEngine.cleanupRun — пауза отпускается, режим выключается.
 */

// расширение .ts в пути: модуль импортируется в node без сборки
import { CONNECTION_LOST_TYPE, type RunEvent } from './runEvents.ts';
import type { GraphNodeLike } from './graphValidation';

/** Период опроса статуса прогона (лёгкий список) и предел паузы при сбоях сети/шлюза. */
export const RUN_POLL_INTERVAL_MS = 10_000;
export const RUN_POLL_MAX_DELAY_MS = 60_000;
/**
 * Детальная ручка тяжёлая (до 6 МБ без сжатия): детали — сразу после обрыва, затем раз
 * в 30 с; ответ без новых кадров удваивает период до 120 с, новые кадры возвращают 30 с.
 * Итоговый статус в списке — детали сразу; статус из списка неизвестен — раз в 30 с.
 */
export const RUN_POLL_DETAIL_INTERVAL_MS = 30_000;
export const RUN_POLL_DETAIL_MAX_INTERVAL_MS = 120_000;
/** Предел слежения: дольше прогоны на контуре не идут, опрос не должен жить вечно. */
export const RUN_POLL_MAX_DURATION_MS = 8 * 60 * 60 * 1000;
/** Сбои запросов подряд дольше этого — слежение прекращается; строка о сбоях повторяется раз в 3 мин. */
export const RUN_POLL_MAX_FAILURE_MS = 10 * 60 * 1000;
export const RUN_POLL_FAILURE_NOTICE_MS = 3 * 60 * 1000;
/** Сколько раз подряд терпеть страницу шлюза вместо JSON (истёкшая сессия, заглушка шлюза). */
export const RUN_POLL_PAGE_ATTEMPTS = 3;
/** Сколько раз пробовать загрузить граф сценария, прежде чем следить без него. */
export const RUN_POLL_GRAPH_ATTEMPTS = 3;
/** Запас на расхождение часов клиента и сервера при поиске прогона без run_id. */
export const RUN_PICK_CLOCK_SKEW_MS = 30_000;
/** Поиск прогона без run_id: сколько успешных запросов списка ждать и предел по времени (со сбоями). */
export const RUN_PICK_ATTEMPTS = 3;
export const RUN_PICK_MAX_MS = 3 * 60 * 1000;
/** Прогон без единого начатого узла дольше этого (от отправки run) — строка в журнал. */
export const RUN_NO_STEPS_NOTICE_MS = 5 * 60 * 1000;

/** Синтетический кадр фронта: строка журнала о слежении по REST (переход, сбои, восстановление). */
export const RUN_POLL_NOTICE_TYPE = 'RUN_POLL_NOTICE';

export const RUN_POLL_START_MESSAGE =
  'Соединение с сервером прервано (на корп-контуре прокси закрывает его через 5 мин) — прогон продолжается на сервере; состояние обновляется запросами: статус раз в 10 с, шаги — раз в 30–120 с';
export const RUN_POLL_SILENT_SOCKET_MESSAGE =
  'Соединение с сервером молчит, а прогон на сервере уже завершён (соединение оборвалось без уведомления) — итог получен запросом';
export const RUN_POLL_STEP_MODE_MESSAGE =
  'Пошаговый режим: при обрыве соединения сервер снимает паузу и отключает пошаговый режим — прогон идёт до конца без остановок';
export const RUN_POLL_RECOVERED_MESSAGE = 'Запросы состояния прогона снова проходят';
export const RUN_POLL_TIMEOUT_MESSAGE =
  'Слежение за прогоном остановлено: 8 ч без итогового статуса — откройте «Подробный отчёт»';
export const RUN_NOT_FOUND_MESSAGE =
  'Соединение потеряно до получения номера прогона, и на сервере прогон не найден — проверьте список прогонов сценария и при необходимости запустите заново';
export const RUN_PICK_AMBIGUOUS_MESSAGE =
  'Соединение потеряно до получения номера прогона, а после запуска у сценария несколько новых прогонов — свой не определить: проверьте список прогонов сценария';
/** Причина FAILED без упавшего шага и без итога: остановка между узлами, прогон-сирота после рестарта. */
export const RUN_FAILED_WITHOUT_NODE_ERROR =
  'Сервер завершил прогон без сохранённой ошибки узла (остановка или перезапуск сервиса)';
/** Причины сбоя запроса вместо текста ошибок браузера (TypeError fetch, SyntaxError JSON.parse). */
export const RUN_POLL_NETWORK_REASON = 'сеть или шлюз недоступны';
export const RUN_POLL_PAGE_REASON = 'шлюз вернул страницу вместо JSON';

/** Куда смотреть после остановки слежения: без run_id «Подробный отчёт» недоступен. */
function reportHint(runId: string | null): string {
  return runId ? 'откройте «Подробный отчёт»' : 'проверьте список прогонов сценария';
}

export function runPollRetryMessage(reason: string): string {
  return `Сбой запроса состояния прогона (${reason}) — повторяю с паузой до ${RUN_POLL_MAX_DELAY_MS / 1000} с`;
}

export function runPollRejectedMessage(reason: string, runId: string | null): string {
  return `Соединение потеряно, а запрос состояния прогона отклонён (${reason}) — ${reportHint(runId)}`;
}

export function runPollGaveUpMessage(reason: string, runId: string | null): string {
  return `Соединение потеряно, а запросы состояния прогона не проходят (${reason}) — прогон мог продолжиться на сервере: ${reportHint(runId)}`;
}

export function runPollPageMessage(reason: string, runId: string | null): string {
  return `Соединение потеряно, а шлюз вместо данных о прогоне отвечает страницей (${reason}) — возможно, истекла сессия: обновите страницу и ${reportHint(runId)}`;
}

export function runPollNoGraphMessage(reason: string): string {
  return `Граф сценария не загрузился (${reason}) — метки узлов по данным прогона, без «шаг N из M»`;
}

export function runNoStepsMessage(minutes: number): string {
  return `Прогон ${minutes} мин не начал ни одного узла: ждёт очереди сервера или не запустился — при необходимости остановите его крестиком и запустите заново`;
}

/** Превью данных шага, как в кадре STEP_COMPLETE (ScenarioEventEmission.PREVIEW_*). */
const PREVIEW_DOCS = 1000;
const PREVIEW_PREV = 1000;
const PREVIEW_PROMPT = 2000;
const PREVIEW_RESULT = 3000;
const PREVIEW_SUFFIX = '… [показано начало; полные данные — в отчёте прогона]';

/** Шаг прогона из GET /scenarios/runs/{runId}. */
export interface PolledRunStep {
  id?: string;
  node_id?: string;
  node_type?: string;
  status?: string;
  input_data?: { documents_text?: string; previous_output?: string } | null;
  output_data?: { result?: string; error?: string } | null;
  prompt_used?: string | null;
  tokens_used?: number | null;
}

/** Ответ GET /scenarios/runs/{runId}: result — строка (прежний вид `{output}` тоже принимается). */
export interface PolledRunDetail {
  id?: string;
  status?: string;
  result?: string | { output?: string } | null;
  steps?: PolledRunStep[] | null;
}

/** Элемент ответа GET /scenarios/{id}/runs. */
export interface PolledRunSummary {
  id?: string;
  status?: string;
  started_at?: string | null;
}

/** Ответ GET /scenarios/{id}: нужен только граф (метки, порядок узлов, режимы выходов). */
interface PolledScenario {
  graph_data?: { nodes?: GraphNodeLike[] | null } | null;
}

/**
 * Что фронт уже показал по прогону: кадры WS до обрыва и прошлые опросы. Кадры
 * опроса выдаются только по изменениям, иначе журнал и список файлов задвоятся.
 */
export interface RunFollowState {
  /** Последний статус узла в нижнем регистре (running/completed/failed). */
  nodeStatuses: Map<string, string>;
  /** Метки узлов из кадров WS — если узла нет в графе. */
  nodeLabels: Map<string, string>;
  /** Шаги, по которым уже был STEP_COMPLETE. */
  stepIds: Set<string>;
  /** Узлы, по которым уже был FILE_OUTPUT. */
  fileNodeIds: Set<string>;
  /** Узел последнего STEP_PAUSED сокета: после обрыва паузы нет — бейдж возвращается к статусу узла. */
  pausedNodeId: string | null;
}

export function createRunFollowState(): RunFollowState {
  return {
    nodeStatuses: new Map(),
    nodeLabels: new Map(),
    stepIds: new Set(),
    fileNodeIds: new Set(),
    pausedNodeId: null,
  };
}

/** Учёт кадра WS до обрыва: статусы узлов, показанные шаги, пауза и файловые выходы. */
export function trackRunEvent(state: RunFollowState, event: RunEvent): void {
  if (!event) return;
  const data = (event.data ?? {}) as Record<string, unknown>;
  const nodeId = typeof data.node_id === 'string' ? data.node_id : '';
  if (!nodeId) return;
  if (typeof data.node_label === 'string' && data.node_label) {
    state.nodeLabels.set(nodeId, data.node_label);
  }
  if (event.type === 'NODE_STATUS' && typeof data.status === 'string') {
    state.nodeStatuses.set(nodeId, data.status.toLowerCase());
  } else if (event.type === 'STEP_COMPLETE' && typeof data.step_id === 'string') {
    state.stepIds.add(data.step_id);
  } else if (event.type === 'STEP_PAUSED') {
    state.pausedNodeId = nodeId;
  } else if (event.type === 'FILE_OUTPUT') {
    state.fileNodeIds.add(nodeId);
  }
}

function lower(value: unknown): string {
  return typeof value === 'string' ? value.toLowerCase() : '';
}

/** Прогон завершён: completed или failed (running — ещё идёт; иных статусов бэкенд не пишет). */
export function isTerminalRunStatus(status: unknown): boolean {
  const value = lower(status);
  return value === 'completed' || value === 'failed';
}

/** Статус прогона из списка GET /scenarios/{id}/runs; null — прогона в списке нет. */
export function runStatusInList(
  runs: readonly PolledRunSummary[] | null | undefined,
  runId: string,
): string | null {
  if (!Array.isArray(runs)) return null;
  const run = runs.find((r) => r && r.id === runId);
  return run ? lower(run.status) : null;
}

/** Время ISO бэкенда (UTC, до микросекунд) в мс: дробная часть приводится к 3 знакам для любого браузера. */
function parseServerTime(value: unknown): number {
  if (typeof value !== 'string' || !value) return NaN;
  return Date.parse(value.replace(/\.(\d+)/, (_, fraction: string) => `.${(fraction + '00').slice(0, 3)}`));
}

/**
 * Прогоны, которые могут быть нашим, если run_id не пришёл до обрыва: начатые не раньше
 * отправки команды run (с небольшим запасом на расхождение часов), по возрастанию начала.
 * Один — наш; ни одного — прогона нет; несколько — не угадываем (вторая вкладка, повторный запуск).
 */
export function runCandidatesAfterDisconnect(
  runs: readonly PolledRunSummary[] | null | undefined,
  sentAtMs: number,
  skewMs: number = RUN_PICK_CLOCK_SKEW_MS,
): string[] {
  if (!Array.isArray(runs)) return [];
  const found: { id: string; startedAt: number }[] = [];
  for (const run of runs) {
    if (!run || typeof run.id !== 'string' || !run.id) continue;
    const startedAt = parseServerTime(run.started_at);
    if (!Number.isFinite(startedAt) || startedAt < sentAtMs - skewMs) continue;
    found.push({ id: run.id, startedAt });
  }
  return found.sort((a, b) => a.startedAt - b.startedAt).map((r) => r.id);
}

/** Пауза до следующего опроса: 10 с, при сбоях подряд — вдвое больше, не дольше 60 с. */
export function nextPollDelay(failures: number): number {
  if (failures <= 0) return RUN_POLL_INTERVAL_MS;
  return Math.min(RUN_POLL_INTERVAL_MS * 2 ** Math.min(failures, 10), RUN_POLL_MAX_DELAY_MS);
}

/** Сбой запроса опроса: fatal — отказ бэкенда, page — страница шлюза вместо JSON, retry — повтор. */
export interface PollFailure {
  kind: 'fatal' | 'page' | 'retry';
  reason: string;
}

/**
 * Разбор сбоя запроса. 4xx бэкенда с JSON (нет доступа, прогон не найден, сессия истекла)
 * повтором не исправить. Страница шлюза вместо JSON — 4xx без JSON («Шлюз вернул N без
 * JSON», errorMessageFromBody) или 200 с HTML (SyntaxError разбора) — повторяется несколько
 * раз. Сеть, 5xx и 408/425/429 — повторяются. Причина — по-русски, без текста ошибок браузера.
 */
export function classifyPollError(error: unknown): PollFailure {
  const status = (error as { status?: unknown } | null)?.status;
  const message = error instanceof Error ? error.message : String(error);
  if (typeof status === 'number') {
    const clientError = status >= 400 && status < 500 && status !== 408 && status !== 425 && status !== 429;
    if (!clientError) return { kind: 'retry', reason: message };
    return { kind: message.startsWith('Шлюз вернул') ? 'page' : 'fatal', reason: message };
  }
  if (error instanceof SyntaxError) return { kind: 'page', reason: RUN_POLL_PAGE_REASON };
  if (error instanceof TypeError) return { kind: 'retry', reason: RUN_POLL_NETWORK_REASON };
  return { kind: 'retry', reason: message };
}

/** Итог прогона строкой: бэкенд отдаёт строку, прежний тип фронта — `{output}`. */
export function runResultText(result: PolledRunDetail['result']): string {
  if (typeof result === 'string') return result;
  if (result && typeof result === 'object' && typeof result.output === 'string') return result.output;
  return '';
}

function preview(value: unknown, limit: number): string | undefined {
  if (typeof value !== 'string') return undefined;
  return value.length <= limit ? value : value.slice(0, limit) + PREVIEW_SUFFIX;
}

/** Имя и MIME файлового выхода — как ScenarioEventEmission.emitFileOutputEvent. */
export function fileOutputOf(
  node: GraphNodeLike | undefined,
  stepNodeType?: string,
): { filename: string; mime_type: string } | null {
  if ((stepNodeType || node?.type) !== 'output') return null;
  const label = node?.data?.label;
  const rawMode = node?.data?.mode;
  // метка «Excel» принудительно даёт xlsx; режим не задан — на сервере «all», файла нет
  const mode = label === 'Excel' ? 'excel' : typeof rawMode === 'string' ? rawMode : '';
  switch (mode.toUpperCase()) {
    case 'EXCEL':
      return {
        filename: 'result.xlsx',
        mime_type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      };
    case 'TEXT_FILE':
    case 'TEXT':
      return { filename: 'result.txt', mime_type: 'text/plain' };
    default:
      return null;
  }
}

/**
 * Кадры по ответу детальной ручки — только то, чего фронт ещё не показал: NODE_STATUS
 * по последнему шагу узла при смене статуса, FILE_OUTPUT (file_ready) по завершённому
 * файловому выходу, STEP_COMPLETE по новому завершённому шагу; в конце — STATUS
 * COMPLETED/FAILED, если прогон завершён. «Шаг N из M» и метки берутся из графа сценария
 * (узлы-заметки сервер из прогона убирает). state обновляется.
 */
export function runEventsFromDetail(
  detail: PolledRunDetail | null | undefined,
  graph: readonly GraphNodeLike[] | null | undefined,
  state: RunFollowState,
  runId: string,
): RunEvent[] {
  const events: RunEvent[] = [];
  if (!detail) return events;

  const positions = new Map<string, { node: GraphNodeLike; step: number }>();
  const workNodes = (graph ?? []).filter((n) => n && n.type !== 'note');
  workNodes.forEach((node, i) => positions.set(node.id, { node, step: i + 1 }));
  const total = workNodes.length;
  const labelOf = (nodeId: string, stepNodeType?: string): string => {
    const node = positions.get(nodeId)?.node;
    const graphLabel = node?.data?.label;
    if (typeof graphLabel === 'string' && graphLabel) return graphLabel;
    // без метки в графе сервер (ScenarioRunNode.getLabel) называет узел его типом
    return state.nodeLabels.get(nodeId) || node?.type || stepNodeType || nodeId;
  };

  const runStatus = lower(detail.status);
  const runFailed = runStatus === 'failed';
  const steps = Array.isArray(detail.steps)
    ? detail.steps.filter((s) => s && typeof s.node_id === 'string' && s.node_id)
    : [];
  const lastStepOfNode = new Map<string, number>();
  steps.forEach((s, i) => lastStepOfNode.set(s.node_id as string, i));
  let failedStep = false;

  steps.forEach((step, i) => {
    const nodeId = step.node_id as string;
    let status = lower(step.status);
    let error = step.output_data?.error;
    if (status === 'running' && isTerminalRunStatus(runStatus)) {
      // прогон завершён, а шаг так и остался running (рестарт сервиса: failOrphanedRunningRuns
      // меняет статус прогона, но не шагов) — узел не «выполняется»
      if (!runFailed) return;
      status = 'failed';
      error = RUN_FAILED_WITHOUT_NODE_ERROR;
    }
    if (status === 'failed') failedStep = true;
    const position = positions.get(nodeId);
    const label = labelOf(nodeId, step.node_type);
    const nodeType = step.node_type || position?.node.type;

    if (
      lastStepOfNode.get(nodeId) === i &&
      (status === 'running' || status === 'completed' || status === 'failed') &&
      state.nodeStatuses.get(nodeId) !== status
    ) {
      state.nodeStatuses.set(nodeId, status);
      const data: Record<string, unknown> = {
        node_id: nodeId,
        node_label: label,
        node_type: nodeType,
        status: status.toUpperCase(),
      };
      if (position) {
        data.step = position.step;
        data.total = total;
      }
      if (status === 'failed' && typeof error === 'string' && error) data.error = error;
      events.push({ type: 'NODE_STATUS', data });
    }

    if (status !== 'completed') return;

    if (!state.fileNodeIds.has(nodeId)) {
      const file = fileOutputOf(position?.node, step.node_type);
      if (file) {
        state.fileNodeIds.add(nodeId);
        events.push({
          type: 'FILE_OUTPUT',
          data: { node_id: nodeId, node_label: label, ...file, file_ready: true },
        });
      }
    }

    if (typeof step.id === 'string' && step.id && !state.stepIds.has(step.id)) {
      state.stepIds.add(step.id);
      const input: NonNullable<PolledRunStep['input_data']> = step.input_data ?? {};
      const output: NonNullable<PolledRunStep['output_data']> = step.output_data ?? {};
      events.push({
        type: 'STEP_COMPLETE',
        data: {
          step_id: step.id,
          node_id: nodeId,
          node_label: label,
          node_type: nodeType,
          input_data: {
            documents_text: preview(input.documents_text, PREVIEW_DOCS),
            previous_output: preview(input.previous_output, PREVIEW_PREV),
          },
          output_data: {
            result: preview(output.result, PREVIEW_RESULT),
            error: output.error,
          },
          prompt_used: preview(step.prompt_used, PREVIEW_PROMPT) ?? null,
          step_index: position?.step,
          total_steps: position ? total : undefined,
          tokens_used: step.tokens_used ?? null,
        },
      });
    }
  });

  if (isTerminalRunStatus(runStatus)) {
    const data: Record<string, unknown> = { run_id: runId, status: runStatus.toUpperCase() };
    const result = runResultText(detail.result);
    if (result) data.result = result;
    // при FAILED с упавшим шагом причина уже в баннере (NODE_STATUS FAILED), как и по сокету
    if (runFailed && !result && !failedStep) {
      data.error = RUN_FAILED_WITHOUT_NODE_ERROR;
    }
    events.push({ type: 'STATUS', data });
  }
  return events;
}

/** Что отслеживать: прогон сценария и то, что о нём уже известно по сокету. */
export interface RunFollowTarget {
  scenarioId: string;
  /** run_id из кадров сокета; null — не успел прийти до обрыва. */
  runId: string | null;
  /** Момент отправки команды run (Date.now()) — поиск прогона без run_id. */
  runSentAt: number;
  /** Прогон запущен в пошаговом режиме: раннеру уходит кадр о снятой паузе. */
  stepMode: boolean;
  state: RunFollowState;
  /** Первая строка журнала; по умолчанию — об обрыве соединения. */
  startNotice?: string;
}

/** Запросы, пауза и прерывание цикла слежения: в браузере — fetchApi и AbortSignal, в node — заглушки. */
export interface RunFollowDeps {
  /** GET по пути API (без BASE_URL) — разобранный JSON; ошибка HTTP несёт числовой status (ApiError). */
  getJson: (path: string) => Promise<unknown>;
  /** Пауза между опросами; при прерывании — отказ. */
  sleep: (ms: number) => Promise<void>;
  /** Бросает ошибку прерывания, если панель закрыта. */
  throwIfAborted: () => void;
  /** Часы (подменяются в проверках). */
  now?: () => number;
}

/**
 * Слежение за прогоном по REST после обрыва сокета: сначала кадр-уведомление, затем
 * опрос до итогового STATUS. Статус — лёгким списком прогонов раз в 10 с (при сбоях пауза
 * растёт до 60 с), детали — сразу, затем раз в 30–120 с и после итогового статуса. Граф
 * и список необязательны: без графа — метки по данным прогона, без списка при известном
 * run_id — статус из деталей. Прогон без run_id ищется по списку не дольше 3 мин.
 * CONNECTION_LOST (раннер предлагает «Подробный отчёт»): отказ 4xx бэкенда, страница шлюза
 * вместо JSON 3 раза подряд, сбои подряд 10 мин, прогон без run_id не найден или не
 * определён однозначно, 8 ч без итога. Сокет не переоткрывается и команда run не
 * повторяется: это делает вызывающий код.
 */
export async function* followRunByRest(
  target: RunFollowTarget,
  deps: RunFollowDeps,
): AsyncGenerator<RunEvent> {
  const now = deps.now ?? Date.now;
  const { scenarioId, runSentAt, state } = target;
  const notice = (message: string, extra?: Record<string, unknown>): RunEvent => ({
    type: RUN_POLL_NOTICE_TYPE,
    data: { message, ...extra },
  });
  const lost = (message: string, id: string | null): RunEvent => ({
    type: CONNECTION_LOST_TYPE,
    error: message,
    data: { run_id: id ?? undefined },
  });
  const startedAt = now();
  const deadline = startedAt + RUN_POLL_MAX_DURATION_MS;
  let runId = target.runId;
  let graph: GraphNodeLike[] | null = null;
  let graphFailures = 0;
  let misses = 0;
  let failures = 0;
  let pageFailures = 0;
  let failureSince: number | null = null;
  let failureNoticeAt = 0;
  let lastReason = '';
  let detailAt: number | null = null;
  let detailInterval = RUN_POLL_DETAIL_INTERVAL_MS;
  let noStepsNoticed = false;

  yield notice(target.startNotice ?? RUN_POLL_START_MESSAGE);
  if (target.stepMode) {
    // закрытие сессии на сервере (cleanupRun) отпускает паузу и выключает пошаговый режим:
    // раннер снимает «⏸ Пауза» и возвращает бейдж приостановленного узла
    const pausedNodeId = state.pausedNodeId;
    yield notice(RUN_POLL_STEP_MODE_MESSAGE, {
      step_mode_off: true,
      node_id: pausedNodeId ?? undefined,
      status: pausedNodeId ? state.nodeStatuses.get(pausedNodeId) : undefined,
    });
  }

  for (;;) {
    deps.throwIfAborted();
    if (now() > deadline) {
      yield lost(RUN_POLL_TIMEOUT_MESSAGE, runId);
      return;
    }
    // кадры копятся и выдаются после запросов: частичный успех (найден run_id,
    // а детали не пришли) не теряется при сбое следующего запроса
    const events: RunEvent[] = [];
    let finished = false;
    let failure: PollFailure | null = null;
    let answered = false;

    // метки, «шаг N из M» и режимы файловых выходов — из сохранённого графа, который
    // выполняет сервер (в редакторе могут быть несохранённые правки)
    let graphError: PollFailure | null = null;
    if (graph === null) {
      try {
        const scenario = (await deps.getJson(`/scenarios/${scenarioId}`)) as PolledScenario | null;
        const nodes = scenario?.graph_data?.nodes;
        graph = Array.isArray(nodes) ? nodes : [];
        answered = true;
      } catch (error) {
        // прерванный запрос (панель закрыта) — не сбой опроса
        deps.throwIfAborted();
        graphError = classifyPollError(error);
      }
    }

    let runs: PolledRunSummary[] | null = null;
    let listAnswered = false;
    try {
      runs = (await deps.getJson(`/scenarios/${scenarioId}/runs`)) as PolledRunSummary[] | null;
      listAnswered = true;
      answered = true;
    } catch (error) {
      deps.throwIfAborted();
      // при известном run_id список лишь экономит трафик: статус берётся из деталей
      if (!runId) failure = classifyPollError(error);
    }

    // граф необязателен: отказ или 3 сбоя только графа (список при этом ответил) — слежение
    // без него; при общем сбое сети граф не списывается, а запрашивается снова
    if (graph === null && graphError && (graphError.kind === 'fatal' || (listAnswered && ++graphFailures >= RUN_POLL_GRAPH_ATTEMPTS))) {
      graph = [];
      events.push(notice(runPollNoGraphMessage(graphError.reason)));
    }

    if (!runId && listAnswered) {
      // STATUS с run_id не успел прийти до обрыва
      const candidates = runCandidatesAfterDisconnect(runs, runSentAt);
      if (candidates.length === 1) {
        runId = candidates[0];
        // run_id в раннер: остановка прогона крестиком, «Подробный отчёт»
        events.push({ type: 'STATUS', data: { run_id: runId, status: 'RUNNING' } });
      } else if (candidates.length > 1) {
        events.push(lost(RUN_PICK_AMBIGUOUS_MESSAGE, null));
        finished = true;
      } else if (++misses >= RUN_PICK_ATTEMPTS) {
        events.push(lost(RUN_NOT_FOUND_MESSAGE, null));
        finished = true;
      }
    }

    if (runId && !finished) {
      const listStatus = listAnswered ? runStatusInList(runs, runId) : null;
      const listTerminal = isTerminalRunStatus(listStatus);
      // статус из списка неизвестен — детали раз в 30 с без удлинения: итог виден только по ним
      const interval = listStatus === null ? RUN_POLL_DETAIL_INTERVAL_MS : detailInterval;
      const due = detailAt === null || listTerminal || now() - detailAt >= interval;
      // сбой только графа — детали ждут его повтора (метки и «шаг N из M» выдаются один раз), кроме итога
      const waitGraph = graph === null && listAnswered && !listTerminal;
      if (due && !waitGraph) {
        try {
          const detail = (await deps.getJson(`/scenarios/runs/${runId}`)) as PolledRunDetail | null;
          detailAt = now();
          answered = true;
          const fresh = runEventsFromDetail(detail, graph, state, runId);
          // ответ без новых кадров — период деталей вдвое длиннее (до 120 с), новые кадры — снова 30 с
          detailInterval =
            fresh.length > 0
              ? RUN_POLL_DETAIL_INTERVAL_MS
              : Math.min(detailInterval * 2, RUN_POLL_DETAIL_MAX_INTERVAL_MS);
          events.push(...fresh);
          finished = isTerminalRunStatus(detail?.status);
          const steps = detail?.steps;
          const noSteps = !Array.isArray(steps) || steps.length === 0;
          if (!finished && noSteps && !noStepsNoticed && now() - runSentAt >= RUN_NO_STEPS_NOTICE_MS) {
            // прогон-сирота (строка создана, поток не подписан) или долгая очередь пула
            noStepsNoticed = true;
            events.push(notice(runNoStepsMessage(Math.floor((now() - runSentAt) / 60_000))));
          }
        } catch (error) {
          deps.throwIfAborted();
          failure = classifyPollError(error);
        }
      }
    }

    // без run_id прогон не остановить крестиком и не открыть отчёт — поиск не дольше 3 мин
    const pickExpired = !runId && !finished && now() - startedAt >= RUN_PICK_MAX_MS;
    if (failure) {
      lastReason = failure.reason;
      if (failure.kind === 'fatal') {
        events.push(lost(runPollRejectedMessage(failure.reason, runId), runId));
        finished = true;
      } else {
        failures++;
        failureSince ??= now();
        pageFailures = failure.kind === 'page' ? pageFailures + 1 : 0;
        if (pageFailures >= RUN_POLL_PAGE_ATTEMPTS) {
          events.push(lost(runPollPageMessage(failure.reason, runId), runId));
          finished = true;
        } else if (now() - failureSince >= RUN_POLL_MAX_FAILURE_MS) {
          events.push(lost(runPollGaveUpMessage(failure.reason, runId), runId));
          finished = true;
        } else if (!pickExpired && (failures === 1 || now() - failureNoticeAt >= RUN_POLL_FAILURE_NOTICE_MS)) {
          // в журнал — первый сбой серии и далее раз в 3 мин, иначе долгий простой шлюза заливает журнал
          failureNoticeAt = now();
          events.push(notice(runPollRetryMessage(failure.reason)));
        }
      }
    } else if (answered) {
      if (failures > 0) events.unshift(notice(RUN_POLL_RECOVERED_MESSAGE));
      failures = 0;
      pageFailures = 0;
      failureSince = null;
    }
    if (pickExpired && !finished) {
      events.push(lost(failures > 0 ? runPollGaveUpMessage(lastReason, null) : RUN_NOT_FOUND_MESSAGE, null));
      finished = true;
    }

    for (const event of events) {
      yield event;
    }
    if (finished) return;
    await deps.sleep(nextPollDelay(failures));
  }
}
