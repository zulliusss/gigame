import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Markdown } from "@/components/ui/markdown";
import { useScenarioStore } from "@/stores/scenarioStore";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { getKnowledgeBases } from "@/api/knowledge-bases";
import { MODELS } from "@/api/constants";
import { normalizeTemperature } from "@/api/graphLimits";
import { ExpressionTextarea, ExpressionHints } from "./ExpressionTextarea";
import { toast } from "@/components/ui/toast";

const TYPE_CONFIG: Record<string, { label: string; color: string }> = {
  input: { label: "Вход", color: "bg-[#21a038]" },
  output: { label: "Выход", color: "bg-[#21a038]" },
  processing: { label: "Обработка", color: "bg-[#7b1fa2]" },
  loop: { label: "Цикл", color: "bg-[#00897b]" },
  switch: { label: "Switch", color: "bg-[#ff6f00]" },
  if_node: { label: "If", color: "bg-[#0277bd]" },
  calc: { label: "Расчёт", color: "bg-[#c2185b]" },
  aggregate: { label: "Агрегация", color: "bg-[#00695c]" },
  transform: { label: "Трансформация", color: "bg-[#5d4037]" },
  subscenario: { label: "Под-сценарий", color: "bg-[#455a64]" },
  control: { label: "Контроль", color: "bg-[#b71c1c]" },
  wait: { label: "Пауза", color: "bg-[#607d8b]" },
  note: { label: "Заметка", color: "bg-[#f9a825]" },
};

const ON_ERROR_TYPES = ["processing", "loop", "calc", "aggregate", "transform", "subscenario"];

export function NodeConfigPanel() {
  const {
    nodes,
    edges,
    selectedNodeId,
    selectedEdgeId,
    updateNodeData,
    deleteNode,
    selectNode,
  } = useScenarioStore();
  const [showPreview, setShowPreview] = useState(false);

  // ── Edge config mode ─────────────────────────────────────────────────
  const selectedEdge = edges.find((e) => e.id === selectedEdgeId);

  // ── Node config mode ─────────────────────────────────────────────────
  const node = nodes.find((n) => n.id === selectedNodeId);
  const isProcessing = node?.type === "processing";

  // ⚠️ Hooks MUST be called before any early return (Rules of Hooks).
  const { data: knowledgeBases = [] } = useQuery({
    queryKey: ["knowledge-bases"],
    queryFn: () => getKnowledgeBases(),
    enabled: isProcessing,
  });

  if (selectedEdge) {
    return <EdgeConfigPanel edge={selectedEdge} />;
  }

  // For Switch: find classes from predecessor Loop (classify_strict)
  const predecessorClasses = (() => {
    if (!node || node.type !== "switch") return null;
    const inEdge = edges.find((e) => e.target === node.id);
    if (!inEdge) return null;
    const predNode = nodes.find((n) => n.id === inEdge.source);
    if (!predNode || predNode.type !== "loop") return null;
    const predData = predNode.data as Record<string, string>;
    if (predData.classify_strict !== "true") return null;
    const classes = predData.classes || "";
    return classes
      .split(",")
      .map((c: string) => c.trim())
      .filter(Boolean);
  })();

  if (!node) {
    return (
      <div className="w-full h-full bg-card border-l border-border p-5 flex flex-col items-center justify-center text-center">
        <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center mb-3">
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            className="text-muted-foreground"
          >
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
          </svg>
        </div>
        <p className="text-sm text-muted-foreground">
          Выберите ноду
          <br />
          для настройки
        </p>
      </div>
    );
  }

  const data = node.data as Record<string, string>;
  const isIO = node.type === "input" || node.type === "output";
  const config = TYPE_CONFIG[node.type || ""] || TYPE_CONFIG.processing;

  return (
    <div className="w-full h-full bg-card border-l border-border p-5 space-y-5 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${config.color}`} />
          <h3 className="text-sm font-semibold">{config.label}</h3>
        </div>
        <button
          onClick={() => selectNode(null)}
          className="w-6 h-6 rounded-lg hover:bg-accent flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
      </div>

      {/* Name */}
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1.5">
          Название
        </label>
        <Input
          value={data.label || ""}
          onChange={(e) => updateNodeData(node.id, { label: e.target.value })}
          placeholder={config.label}
          className="rounded-xl"
        />
      </div>

      {!isIO && node.type !== "switch" && node.type !== "if_node" && node.type !== "calc"
        && node.type !== "aggregate" && node.type !== "transform" && node.type !== "subscenario"
        && node.type !== "control" && node.type !== "wait" && node.type !== "note" && (
        <>
          {/* Prompt — only for processing, loop */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-muted-foreground">
                Промпт
              </label>
              {data.prompt && (
                <button
                  onClick={() => setShowPreview(!showPreview)}
                  className="text-[10px] text-[#1976d2] hover:underline"
                >
                  {showPreview ? "Редактор" : "Превью"}
                </button>
              )}
            </div>
            {showPreview ? (
              <div className="min-h-[140px] rounded-xl border border-border bg-background p-3 overflow-y-auto">
                <Markdown className="text-sm">{data.prompt || ""}</Markdown>
              </div>
            ) : (
              <ExpressionTextarea
                value={data.prompt || ""}
                onChange={(prompt) => updateNodeData(node.id, { prompt })}
                placeholder="Инструкции для GigaChat..."
                nodes={nodes}
                edges={edges}
                currentNodeId={node.id}
                className="rounded-xl text-sm"
              />
            )}
            <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
              Выражения: <code className="bg-accent px-1 rounded">{"{{output:Метка узла}}"}</code> —
              выход узла, <code className="bg-accent px-1 rounded">{"{{json:Метка:путь.к.полю}}"}</code> —
              поле из JSON в выходе. <span className="text-green-700">Зелёное</span> — узел-предшественник
              найден, <span className="text-red-700">красное</span> — метка не найдена в графе.
              При использовании выражений автоблок «Результаты предыдущих шагов» не добавляется.
            </p>
          </div>

          {/* Настройки LLM для узла */}
          <div className="border border-border rounded-xl p-3 bg-accent/30 space-y-2">
            <span className="text-xs font-medium text-foreground block">⚙️ Настройки GigaChat для узла</span>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-muted-foreground w-24 shrink-0">Модель</span>
              <select
                value={data.model || ""}
                onChange={(e) => updateNodeData(node.id, { model: e.target.value })}
                className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
              >
                <option value="">По умолчанию (сервер)</option>
                {MODELS.map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-muted-foreground w-24 shrink-0">Температура</span>
              <input
                type="number"
                step="0.05"
                min="0"
                max="2"
                value={data.temperature || ""}
                placeholder="по умолчанию"
                onChange={(e) => updateNodeData(node.id, { temperature: normalizeTemperature(e.target.value) })}
                className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
              />
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed">
              Низкая температура (0.01–0.2) — воспроизводимые расчёты и извлечение;
              выше (0.5–1) — творческие формулировки. Пусто — значения из конфигурации сервера.
            </p>
          </div>

          {node.type === "processing" && (
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1.5 flex items-center gap-1.5">
                <svg
                  width="12"
                  height="12"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#21a038"
                  strokeWidth="2"
                >
                  <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                  <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                </svg>
                База знаний (RAG)
              </label>
              <select
                value={data.knowledge_base_id || ""}
                onChange={(e) =>
                  updateNodeData(node.id, { knowledge_base_id: e.target.value })
                }
                className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-[#21a038]"
              >
                <option value="">Не использовать</option>
                {knowledgeBases.map((kb) => (
                  <option key={kb.id} value={kb.id}>
                    {kb.name}
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                {data.knowledge_base_id
                  ? "GigaChat получит релевантные фрагменты из базы знаний как дополнительный контекст (similarity search по результату предыдущего шага)."
                  : knowledgeBases.length === 0
                  ? "Нет доступных баз знаний. Создайте базу в разделе «Базы знаний»."
                  : "Выберите базу, чтобы узел автоматически подмешивал релевантные фрагменты в контекст."}
              </p>
            </div>
          )}

          {node.type === "processing" && (
            <div>
              <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                Обработка документов
              </label>
              <select
                value={
                  ["group", "agent", "agent_review", "agent_group"].includes(data.mode || "")
                    ? data.mode
                    : ""
                }
                onChange={(e) => updateNodeData(node.id, { mode: e.target.value })}
                className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground"
              >
                <option value="">По одному (отдельный запрос на документ)</option>
                <option value="group">Группами (один запрос на группу документов)</option>
                <option value="agent">Агент (простое задание — модель сама читает документы)</option>
                <option value="agent_review">
                  Агент-ревизор (сверка входных данных с документами)
                </option>
                <option value="agent_group">
                  Агент по группам (агентский конвейер на каждую группу)
                </option>
              </select>
              {data.mode === "agent_group" && (
                <>
                  <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                    Документы группируются по ключу из имени файла (первая скобочная
                    группа регэкспа), и на каждую группу запускается отдельный агент
                    с общим заданием. Документы без совпадения (извещение, договор)
                    добавляются каждой группе как общий контекст. Сценарий не зависит
                    от числа сущностей: заявок/договоров может быть сколько угодно.
                  </p>
                  <Input
                    value={data.value || ""}
                    onChange={(e) => updateNodeData(node.id, { value: e.target.value })}
                    placeholder="(?iu)заявк\D{0,4}(\d+)"
                    className="rounded-xl mt-1.5 font-mono text-xs"
                  />
                </>
              )}
              {data.mode === "agent_review" && (
                <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                  Для проверяющих узлов (критик, сверка отчёта с документами):
                  агент строит план и работает инструментами как обычно, но финал —
                  отчёт сверки («совпадает» / «расхождение»), без рабочей тетради
                  и цитатной валидации: вердикты проверки — не выписки, дословных
                  цитат для них в документах нет.
                </p>
              )}
              {data.mode === "agent" && (
                <>
                  <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                    В поле «Промпт» опишите задание простыми словами — что найти и в
                    каком виде вернуть результат. Агент сам построит план, просмотрит
                    документы инструментами, подтвердит значения цитатами (цитаты
                    проверяются автоматически) и соберёт ответ. Учитывает уроки со
                    страницы «Память агента»; спорные места станут вопросами в
                    карточке прогона. Тексты документов не вставляются в запрос —
                    большие комплекты не упираются в лимиты.
                  </p>
                  {(data.prompt || "").trim() && (
                    <button
                      onClick={async () => {
                        try {
                          const { createPrompt } = await import("@/api/prompts");
                          await createPrompt({
                            title: `Задание агента: ${data.label || node.id}`.slice(0, 255),
                            description: "Проверенное задание агентского узла",
                            text: data.prompt || "",
                          });
                          toast("Задание сохранено в базу промптов", "success");
                        } catch {
                          toast("Не удалось сохранить в базу промптов", "error");
                        }
                      }}
                      className="text-[11px] text-[#21a038] hover:underline mt-1.5"
                      title="Библиотека навыков: удачное задание станет доступно всем в базе промптов"
                    >
                      Сохранить задание в базу промптов
                    </button>
                  )}
                </>
              )}
              {data.mode === "group" && (
                <>
                  <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                    Документы группируются по ключу из имени/пути файла (первая
                    скобочная группа регэкспа). Все документы группы попадают в один
                    запрос с именами файлов — GigaChat может сверять их между собой
                    (договор ↔ спецификация ↔ акт). ZIP-архивы при загрузке
                    распаковываются, путь внутри архива сохраняется в имени.
                  </p>
                  <Input
                    value={data.value || ""}
                    onChange={(e) => updateNodeData(node.id, { value: e.target.value })}
                    placeholder="(?iu)(?:договор|contract)\s*[№#]?\s*(\d{5,})"
                    className="rounded-xl mt-1.5 font-mono text-xs"
                  />
                  <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                    Пусто — регэксп по умолчанию (номер договора из пути «Договор NNN» /
                    «Contract #NNN»). Документ без совпадения образует отдельную группу.
                  </p>
                </>
              )}
              <label className="text-xs font-medium text-muted-foreground block mb-1.5 mt-3">
                Контракт выхода (JSON, опционально)
              </label>
              <textarea
                value={data.rules || ""}
                onChange={(e) => updateNodeData(node.id, { rules: e.target.value })}
                placeholder={'{"контракт": {"тип": "json_массив", "обязательные_ключи": ["сумма"], "мин_элементов": 1}}'}
                rows={2}
                className="w-full text-[11px] font-mono bg-background border border-border rounded-xl px-2.5 py-2 text-foreground resize-y"
              />
              <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                Выход узла проверяется кодом; при нарушении модель получает один
                запрос на исправление с текстом ошибки, повторное нарушение
                завершает узел ошибкой (действует on_error).
              </p>
            </div>
          )}

          {node.type === "loop" && (
            <>
              <div>
                <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                  Итерация
                </label>
                <select
                  value={data.mode === "list" ? "list" : "documents"}
                  onChange={(e) =>
                    updateNodeData(node.id, { mode: e.target.value === "list" ? "list" : "" })
                  }
                  className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground"
                >
                  <option value="documents">По документам узла</option>
                  <option value="list">По элементам входа (список)</option>
                </select>
                {data.mode === "list" && (
                  <>
                    <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
                      Элементы: JSON-массив в конце входа либо текст, разрезанный по разделителю.
                    </p>
                    <Input
                      value={data.value || ""}
                      onChange={(e) => updateNodeData(node.id, { value: e.target.value })}
                      placeholder="Разделитель (по умолчанию ---)"
                      className="rounded-xl mt-1.5"
                    />
                  </>
                )}
              </div>
              <div className="border border-border rounded-xl p-3 bg-accent/30">
                <label className="flex items-center gap-2 cursor-pointer text-xs select-none">
                  <input
                    type="checkbox"
                    checked={data.classify_strict === "true"}
                    onChange={(e) =>
                      updateNodeData(node.id, {
                        classify_strict: e.target.checked ? "true" : "false",
                      })
                    }
                    className="w-3.5 h-3.5 rounded accent-[#00897b]"
                  />
                  <span className="font-medium text-foreground">
                    🏷️ Строгая классификация
                  </span>
                </label>
                <p className="text-[10px] text-muted-foreground mt-1.5 leading-relaxed">
                  GigaChat вернёт ТОЛЬКО название класса (одно слово). Промпт
                  ноды используется как подсказка для классификации.
                  Оригинальный текст каждого документа сохранится для следующего
                  узла Switch — он отфильтрует документы по классу и передаст
                  только нужные в каждую ветку.
                </p>
              </div>
              {data.classify_strict === "true" && (
                <div>
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">
                    Возможные классы
                  </label>
                  <Input
                    value={data.classes || ""}
                    onChange={(e) =>
                      updateNodeData(node.id, { classes: e.target.value })
                    }
                    placeholder="ПЗ, КП, ПРИКАЗ"
                    className="rounded-xl"
                  />
                  <p className="text-[10px] text-muted-foreground mt-1">
                    Эти же названия используйте в правилах Switch и метках рёбер
                  </p>
                </div>
              )}
            </>
          )}
        </>
      )}

      {/* Switch — visual rules editor, no prompt */}
      {node.type === "switch" && (
        <SwitchRulesEditor
          rules={data.rules || "[]"}
          onChange={(rules) => updateNodeData(node.id, { rules })}
          suggestedClasses={predecessorClasses}
        />
      )}

      {/* Calc — формулы расчёта, без промпта и без GigaChat */}
      {node.type === "calc" && (
        <CalcConfigEditor
          rules={data.rules || ""}
          onChange={(rules) => updateNodeData(node.id, { rules })}
        />
      )}

      {/* Aggregate — детерминированное суммирование, без GigaChat */}
      {node.type === "aggregate" && (
        <AggregateConfigEditor
          rules={data.rules || ""}
          onChange={(rules) => updateNodeData(node.id, { rules })}
        />
      )}

      {/* Transform — операции над текстом без GigaChat */}
      {node.type === "transform" && (
        <TransformConfigEditor
          rules={data.rules || ""}
          onChange={(rules) => updateNodeData(node.id, { rules })}
        />
      )}

      {/* Subscenario — выбор вызываемого сценария */}
      {node.type === "subscenario" && (
        <SubscenarioSelector
          value={data.value || ""}
          currentScenarioId={undefined}
          onChange={(value) => updateNodeData(node.id, { value })}
        />
      )}

      {/* Control — условие, которое обязано выполняться */}
      {node.type === "control" && (
        <>
          <p className="text-[10px] text-muted-foreground leading-relaxed -mt-2">
            Проверяет входные данные. Если условие НЕ выполнено — сценарий
            останавливается с вашим сообщением. Без GigaChat.
          </p>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Поле / строка (необяз.)
            </label>
            <Input
              value={data.field || ""}
              onChange={(e) => updateNodeData(node.id, { field: e.target.value })}
              placeholder="Сумма весов, НМЦД, статус..."
              className="rounded-xl"
            />
            <ExpressionHints text={data.field || ""} nodes={nodes} edges={edges} currentNodeId={node.id} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Условие (должно выполняться)
            </label>
            <select
              value={data.operator || "contains"}
              onChange={(e) => updateNodeData(node.id, { operator: e.target.value })}
              className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground"
            >
              <option value="contains">содержит</option>
              <option value="not_contains">не содержит</option>
              <option value="equals">равно</option>
              <option value="greater_than">больше чем</option>
              <option value="less_than">меньше чем</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Значение
            </label>
            <Input
              value={data.value || ""}
              onChange={(e) => updateNodeData(node.id, { value: e.target.value })}
              placeholder="ДОПУЩЕН, 100, 2..."
              className="rounded-xl"
            />
            <ExpressionHints text={data.value || ""} nodes={nodes} edges={edges} currentNodeId={node.id} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Сообщение при нарушении
            </label>
            <Textarea
              value={data.prompt || ""}
              onChange={(e) => updateNodeData(node.id, { prompt: e.target.value })}
              placeholder="Сумма весов критериев не равна 100% — проверьте методику"
              className="min-h-[60px] rounded-xl text-sm"
            />
          </div>
        </>
      )}

      {/* Note — заметка на канве, в выполнении не участвует */}
      {node.type === "note" && (
        <div>
          <label className="text-xs font-medium text-muted-foreground block mb-1.5">
            Текст заметки
          </label>
          <Textarea
            value={data.prompt || ""}
            onChange={(e) => updateNodeData(node.id, { prompt: e.target.value })}
            placeholder="Пояснение к этой части сценария: зачем узлы, какие правила, на что обратить внимание..."
            className="min-h-[140px] rounded-xl text-sm"
          />
          <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
            Заметка видна только на канве — в выполнении сценария не участвует,
            рёбрами не соединяется. «Название» выше — необязательный заголовок стикера.
          </p>
        </div>
      )}

      {/* Wait — пауза */}
      {node.type === "wait" && (
        <div>
          <label className="text-xs font-medium text-muted-foreground block mb-1.5">
            Длительность паузы, секунд (0–300)
          </label>
          <Input
            type="number"
            min="0"
            max="300"
            value={data.value || ""}
            onChange={(e) => updateNodeData(node.id, { value: e.target.value })}
            placeholder="10"
            className="rounded-xl"
          />
          <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
            Вход передаётся дальше без изменений. Полезно для разведения
            LLM-вызовов по времени при лимитах API.
          </p>
        </div>
      )}

      {/* Поведение при ошибке — для узлов, которые могут упасть */}
      {ON_ERROR_TYPES.includes(node.type || "") && (
        <div>
          <label className="text-xs font-medium text-muted-foreground block mb-1.5">
            При ошибке узла
          </label>
          <select
            value={data.on_error || ""}
            onChange={(e) => updateNodeData(node.id, { on_error: e.target.value })}
            className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground"
          >
            <option value="">Остановить сценарий (по умолчанию)</option>
            <option value="continue">Продолжить (ошибка станет результатом узла)</option>
            <option value="branch">Ветка «ошибка» (пометьте ребро меткой «ошибка»)</option>
          </select>
          {data.on_error === "branch" && (
            <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
              При сбое выполнятся только рёбра с меткой «ошибка», обычные ветки
              пропустятся. При успехе — наоборот.
            </p>
          )}
        </div>
      )}

      {/* If — no prompt, condition editor */}
      {node.type === "if_node" && (
        <>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Поле (необяз.)
            </label>
            <Input
              value={data.field || ""}
              onChange={(e) =>
                updateNodeData(node.id, { field: e.target.value })
              }
              placeholder="ТИП, НМЦД, статус..."
              className="rounded-xl"
            />
            <ExpressionHints text={data.field || ""} nodes={nodes} edges={edges} currentNodeId={node.id} />
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Оператор
            </label>
            <select
              value={data.operator || "contains"}
              onChange={(e) =>
                updateNodeData(node.id, { operator: e.target.value })
              }
              className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground"
            >
              <option value="contains">содержит</option>
              <option value="not_contains">не содержит</option>
              <option value="equals">равно</option>
              <option value="greater_than">больше чем</option>
              <option value="less_than">меньше чем</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Значение
            </label>
            <Input
              value={data.value || ""}
              onChange={(e) =>
                updateNodeData(node.id, { value: e.target.value })
              }
              placeholder="КП, 1000000, ошибка..."
              className="rounded-xl"
            />
            <ExpressionHints text={data.value || ""} nodes={nodes} edges={edges} currentNodeId={node.id} />
          </div>
          <p className="text-[10px] text-muted-foreground">
            Рёбра: «true»/«да» и «false»/«нет». Без GigaChat.
          </p>
        </>
      )}

      {node.type === "output" && (
        <>
          <div>
            <label className="text-xs font-medium text-muted-foreground block mb-1.5">
              Отображение результата
            </label>
            <select
              value={data.mode || "text"}
              onChange={(e) =>
                updateNodeData(node.id, { mode: e.target.value })
              }
              className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground"
            >
              <option value="text">Текст</option>
              <option value="excel">Excel</option>
            </select>
          </div>
          {data.mode === "excel" && (
            <XlsxTemplateEditor
              rules={data.rules || ""}
              onChange={(rules) => updateNodeData(node.id, { rules })}
            />
          )}
        </>
      )}

      <Button
        variant="outline"
        size="sm"
        className="w-full rounded-xl text-destructive hover:bg-red-50 border-red-200"
        onClick={() => deleteNode(node.id)}
      >
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="mr-1.5"
        >
          <polyline points="3 6 5 6 21 6" />
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        </svg>
        Удалить ноду
      </Button>
    </div>
  );
}

// ── Edge Config Panel ───────────────────────────────────────────────────

function EdgeConfigPanel({ edge }: { edge: import('@xyflow/react').Edge }) {
  const { updateEdgeData, deleteEdge, selectEdge, nodes } = useScenarioStore();
  const sourceNode = nodes.find((n) => n.id === edge.source);
  const edgeData = (edge.data || {}) as Record<string, string>;
  const label = edgeData.label || '';

  // For switch → pick from rules
  const switchLabels = (() => {
    if (sourceNode?.type !== 'switch') return null;
    const data = sourceNode.data as Record<string, string>;
    try {
      const rules = JSON.parse(data.rules || '[]') as Array<{ label: string }>;
      return rules.map((r) => r.label).filter(Boolean);
    } catch {
      return null;
    }
  })();

  const isIfNode = sourceNode?.type === 'if_node';

  return (
    <div className="w-full h-full bg-card border-l border-border p-5 space-y-5 overflow-y-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#e53935]" />
          <h3 className="text-sm font-semibold">Ребро{sourceNode ? `: ${sourceNode.data?.label || sourceNode.type}` : ''}</h3>
        </div>
        <button
          onClick={() => selectEdge(null)}
          className="w-6 h-6 rounded-lg hover:bg-accent flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
      </div>

      {/* Label editor */}
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1.5">
          {isIfNode ? 'Ветка условия' : switchLabels ? 'Ветка маршрутизации' : 'Метка ребра'}
        </label>
        {isIfNode ? (
          <select
            value={label}
            onChange={(e) => updateEdgeData(edge.id, { label: e.target.value })}
            className="w-full text-sm bg-background border border-border rounded-xl px-3 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-[#e53935]"
          >
            <option value="" disabled>Выберите ветку…</option>
            <option value="true">true (да)</option>
            <option value="false">false (нет)</option>
          </select>
        ) : switchLabels && switchLabels.length > 0 ? (
          <select
            value={label}
            onChange={(e) => updateEdgeData(edge.id, { label: e.target.value })}
            className="w-full text-sm bg-background border border-border rounded-xl px-3 py-2 text-foreground focus:outline-none focus:ring-1 focus:ring-[#e53935]"
          >
            <option value="" disabled>Выберите ветку…</option>
            {switchLabels.map((l) => (
              <option key={l} value={l}>{l}</option>
            ))}
          </select>
        ) : (
          <Input
            value={label}
            onChange={(e) => updateEdgeData(edge.id, { label: e.target.value })}
            placeholder="Введите название ветки…"
            className="rounded-xl"
          />
        )}
        <p className="text-[10px] text-muted-foreground mt-1">
          {isIfNode
            ? 'Результат условия: true (да) → выполняется, false (нет) → пропускается.'
            : switchLabels
              ? 'Выберите одну из веток, описанных в правилах Switch.'
              : 'Произвольная метка для ребра.'}
        </p>
      </div>

      {/* Edge info */}
      <div className="bg-accent/30 rounded-xl p-3 space-y-2 text-xs text-muted-foreground">
        <div className="flex justify-between">
          <span>От:</span>
          <span className="font-medium text-foreground">{String(sourceNode?.data?.label || sourceNode?.type || edge.source)}</span>
        </div>
        <div className="flex justify-between">
          <span>К:</span>
          <span className="font-medium text-foreground">{String(nodes.find((n) => n.id === edge.target)?.data?.label || edge.target)}</span>
        </div>
      </div>

      <Button
        variant="outline"
        size="sm"
        className="w-full rounded-xl text-destructive hover:bg-red-50 border-red-200"
        onClick={() => {
          deleteEdge(edge.id);
          selectEdge(null);
        }}
      >
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="mr-1.5"
        >
          <polyline points="3 6 5 6 21 6" />
          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        </svg>
        Удалить ребро
      </Button>
    </div>
  );
}

// ── Transform Node Config Editor ────────────────────────────────────────

interface TransformOp {
  оп: string;
  [key: string]: string | number | boolean | undefined;
}

const TRANSFORM_OPS: Array<{ value: string; label: string; fields: Array<{ key: string; label: string; placeholder?: string }> }> = [
  { value: "извлечь_regex", label: "Извлечь по regex",
    fields: [{ key: "шаблон", label: "шаблон", placeholder: "№\\s*(\\d+)" }, { key: "группа", label: "группа", placeholder: "0" }] },
  { value: "заменить", label: "Заменить",
    fields: [{ key: "найти", label: "найти" }, { key: "на", label: "заменить на" }] },
  { value: "оставить_строки", label: "Оставить строки с…",
    fields: [{ key: "шаблон", label: "regex" }] },
  { value: "удалить_строки", label: "Удалить строки с…",
    fields: [{ key: "шаблон", label: "regex" }] },
  { value: "json_поле", label: "Поле из JSON",
    fields: [{ key: "путь", label: "путь", placeholder: "участники[0].название" }] },
  { value: "слить_json_массивы", label: "Слить JSON-массивы (результаты групп)",
    fields: [] },
  { value: "взять_символы", label: "Взять символы",
    fields: [{ key: "от", label: "от", placeholder: "0" }, { key: "до", label: "до", placeholder: "1000" }] },
  { value: "первые_строки", label: "Первые N строк",
    fields: [{ key: "n", label: "N", placeholder: "10" }] },
  { value: "последние_строки", label: "Последние N строк",
    fields: [{ key: "n", label: "N", placeholder: "10" }] },
  { value: "уникальные_строки", label: "Уникальные строки", fields: [] },
  { value: "извлечь_из_документов", label: "Извлечь из документов (regex по файлам)",
    fields: [{ key: "имя", label: "имя файла (regex)", placeholder: "ПЗ|[Пп]ояснительн" },
      { key: "шаблон", label: "шаблон", placeholder: "Способ закупки[\\s:|]*([^\\n|]{4,120})" },
      { key: "группа", label: "группа", placeholder: "1" }, { key: "строго", label: "только по имени (true)" },
      { key: "все", label: "все совпадения (true)" }, { key: "разделитель", label: "разделитель", placeholder: "; " }] },
  { value: "проверить_цитаты", label: "Проверить цитаты по документам (код)",
    fields: [{ key: "поле", label: "поле", placeholder: "цитата" }, { key: "мин_длина", label: "мин. длина", placeholder: "12" },
      { key: "документы", label: "файлы (regex)", placeholder: "^(?!КП_)" }] },
  { value: "удалить_объекты", label: "Удалить объекты JSON по regex",
    fields: [{ key: "поле", label: "поле", placeholder: "достоверность" }, { key: "шаблон", label: "regex", placeholder: "НЕ НАЙДЕНА|коротка" },
      { key: "и_поле", label: "и поле (необяз.)", placeholder: "з4" }, { key: "и_шаблон", label: "и regex", placeholder: "^(ВЫСОКИЙ|СРЕДНИЙ|НИЗКИЙ)$" }] },
  { value: "установить_поле", label: "Установить поле JSON по условию",
    fields: [{ key: "поле", label: "поле", placeholder: "з4" }, { key: "значение", label: "значение", placeholder: "ПАСПОРТ" },
      { key: "значение_из_узла", label: "+ выход узла", placeholder: "Способ закупки" }, { key: "кроме_значений", label: "кроме (regex)", placeholder: "^не найдено" },
      { key: "если_поле", label: "если поле", placeholder: "з2" }, { key: "шаблон", label: "regex", placeholder: "^Способ закупки:" }] },
  { value: "сверить_суммы", label: "Сверить суммы по метке (код)",
    fields: [{ key: "метка", label: "метка (regex)", placeholder: "НМЦД?|начальн[а-я]+ максимальн[а-я]+" }, { key: "окно", label: "окно, символов", placeholder: "120" }] },
  { value: "проверить_проценты", label: "Проверить проценты от базы (код)",
    fields: [{ key: "база_метка", label: "метка базы (regex)" }, { key: "допуск", label: "допуск", placeholder: "0.3" }, { key: "формат", label: "формат", placeholder: "json_находки" }] },
  { value: "сверить_даты", label: "Сверить даты договора и услуг (код)",
    fields: [{ key: "минимум_дней", label: "минимум дней", placeholder: "15" }, { key: "формат", label: "формат", placeholder: "json_находки" }] },
  { value: "реестр_документов", label: "Форма 3: реестр документов (код)", fields: [] },
  { value: "строки_формы3", label: "Форма 3: строки формы (код)",
    fields: [{ key: "критерии_из_узла", label: "критерии из узла", placeholder: "Критерии (текст)" },
      { key: "заказчики_в_рейтинге", label: "заказчики в рейтинге (regex)", placeholder: "Сбербанк|ВТБ|Газпромбанк" }] },
];

function TransformConfigEditor({
  rules,
  onChange,
}: {
  rules: string;
  onChange: (v: string) => void;
}) {
  let ops: TransformOp[] = [];
  try {
    const parsed = JSON.parse(rules);
    ops = Array.isArray(parsed?.операции) ? parsed.операции : [];
  } catch {
    ops = [];
  }
  const update = (next: TransformOp[]) => onChange(JSON.stringify({ операции: next }));

  return (
    <div className="space-y-3">
      <label className="text-xs font-medium text-muted-foreground block">
        Операции над текстом
      </label>
      <p className="text-[10px] text-muted-foreground -mt-1 leading-relaxed">
        Применяются по цепочке к документам узла (если подключены) или к результатам
        предыдущих узлов. Детерминированно, без GigaChat.
      </p>
      {ops.map((op, i) => {
        // Незнакомая операция (новее фронта) не подменяется на regex: показываем её как есть,
        // редактируемы только строковые параметры, вложенные объекты сохраняются нетронутыми
        const known = TRANSFORM_OPS.find((t) => t.value === op.оп);
        const def = known || {
          value: op.оп,
          label: `${op.оп} (операция движка)`,
          fields: Object.keys(op)
            .filter((k) => k !== "оп" && (typeof op[k] === "string" || typeof op[k] === "number" || typeof op[k] === "boolean"))
            .map((k) => ({ key: k, label: k, placeholder: undefined as string | undefined })),
        };
        return (
          <div key={i} className="border border-border rounded-xl p-2.5 space-y-1.5 bg-accent/20">
            <div className="flex items-center gap-1.5">
              <select
                value={op.оп}
                onChange={(e) => {
                  const copy = [...ops];
                  copy[i] = { оп: e.target.value };
                  update(copy);
                }}
                className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
              >
                {!known && <option value={op.оп}>{def.label}</option>}
                {TRANSFORM_OPS.map((t) => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
              <button
                onClick={() => update(ops.filter((_, x) => x !== i))}
                className="p-1 rounded hover:bg-background hover:text-destructive shrink-0"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>
            {def.fields.map((f) => (
              <div key={f.key} className="flex items-center gap-1.5">
                <span className="text-[10px] text-muted-foreground w-20 shrink-0">{f.label}</span>
                <input
                  value={String(op[f.key] ?? "")}
                  placeholder={f.placeholder}
                  onChange={(e) => {
                    const copy = [...ops];
                    copy[i] = { ...copy[i], [f.key]: e.target.value };
                    update(copy);
                  }}
                  className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none font-mono"
                />
              </div>
            ))}
          </div>
        );
      })}
      <button
        onClick={() => update([...ops, { оп: "извлечь_regex" }])}
        className="w-full text-xs border border-dashed border-border rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
      >
        + Добавить операцию
      </button>
    </div>
  );
}

// ── XLSX Template Editor (output-узел, mode=excel) ──────────────────────

interface XlsxColumn {
  ключ: string;
  заголовок: string;
  группа?: string;
}

function XlsxTemplateEditor({
  rules,
  onChange,
}: {
  rules: string;
  onChange: (v: string) => void;
}) {
  let sheet = "";
  let columns: XlsxColumn[] = [];
  try {
    const parsed = JSON.parse(rules);
    if (parsed && !Array.isArray(parsed)) {
      sheet = typeof parsed.лист === "string" ? parsed.лист : "";
      columns = Array.isArray(parsed.колонки) ? parsed.колонки : [];
    }
  } catch {
    columns = [];
  }
  const update = (nextColumns: XlsxColumn[], nextSheet = sheet) => {
    if (nextColumns.length === 0 && !nextSheet) {
      onChange("");
      return;
    }
    onChange(JSON.stringify({
      ...(nextSheet ? { лист: nextSheet } : {}),
      колонки: nextColumns,
    }));
  };
  const move = (i: number, delta: number) => {
    const j = i + delta;
    if (j < 0 || j >= columns.length) return;
    const copy = [...columns];
    [copy[i], copy[j]] = [copy[j], copy[i]];
    update(copy);
  };

  return (
    <div className="space-y-3">
      <label className="text-xs font-medium text-muted-foreground block">
        Шаблон формы таблицы
      </label>
      <p className="text-[10px] text-muted-foreground -mt-1 leading-relaxed">
        Без шаблона колонки формируются из ключей JSON, который вернул GigaChat.
        С шаблоном порядок и состав колонок фиксированы: «ключ» — имя поля в JSON,
        «заголовок» — текст шапки, «группа» — верхний уровень двухуровневой шапки
        (соседние колонки одной группы объединяются).
      </p>
      {columns.map((col, i) => (
        <div key={i} className="border border-border rounded-xl p-2.5 space-y-1.5 bg-accent/20">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground shrink-0">№{i + 1}</span>
            <button onClick={() => move(i, -1)} disabled={i === 0}
              className="p-1 rounded hover:bg-background disabled:opacity-30 shrink-0" title="Выше">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="18 15 12 9 6 15" /></svg>
            </button>
            <button onClick={() => move(i, 1)} disabled={i === columns.length - 1}
              className="p-1 rounded hover:bg-background disabled:opacity-30 shrink-0" title="Ниже">
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9" /></svg>
            </button>
            <div className="flex-1" />
            <button
              onClick={() => update(columns.filter((_, x) => x !== i))}
              className="p-1 rounded hover:bg-background hover:text-destructive shrink-0"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
          {([
            { key: "ключ", label: "ключ JSON", placeholder: "сумма_зачтено", mono: true },
            { key: "заголовок", label: "заголовок", placeholder: "Сумма зачтённого опыта, руб." },
            { key: "группа", label: "группа (необяз.)", placeholder: "Квалификация" },
          ] as const).map((f) => (
            <div key={f.key} className="flex items-center gap-1.5">
              <span className="text-[10px] text-muted-foreground w-24 shrink-0">{f.label}</span>
              <input
                value={String(col[f.key] ?? "")}
                placeholder={f.placeholder}
                onChange={(e) => {
                  const copy = [...columns];
                  copy[i] = { ...copy[i], [f.key]: e.target.value };
                  update(copy);
                }}
                className={`flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none ${"mono" in f && f.mono ? "font-mono" : ""}`}
              />
            </div>
          ))}
        </div>
      ))}
      <button
        onClick={() => update([...columns, { ключ: "", заголовок: "" }])}
        className="w-full text-xs border border-dashed border-border rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
      >
        + Добавить колонку
      </button>
      {columns.length > 0 && (
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground w-24 shrink-0">имя листа</span>
          <input
            value={sheet}
            placeholder="Данные"
            onChange={(e) => update(columns, e.target.value)}
            className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
          />
        </div>
      )}
    </div>
  );
}

// ── Aggregate Node Config Editor ────────────────────────────────────────

const AGGREGATE_OPERATORS = [
  { value: "greater_or_equal", label: "сумма ≥ порога" },
  { value: "greater_than", label: "сумма > порога" },
  { value: "less_or_equal", label: "сумма ≤ порога" },
  { value: "less_than", label: "сумма < порога" },
  { value: "equals", label: "сумма = порогу" },
];

function AggregateConfigEditor({
  rules,
  onChange,
}: {
  rules: string;
  onChange: (v: string) => void;
}) {
  interface AggregateConfig {
    суммировать?: string;
    группировать_по?: string;
    фильтр?: { поле?: string; равно?: string };
    порог?: { значение?: string | number; оператор?: string; метка?: string };
  }
  let cfg: AggregateConfig = {};
  try {
    const parsed = JSON.parse(rules);
    if (parsed && !Array.isArray(parsed)) cfg = parsed;
  } catch {
    cfg = {};
  }
  const update = (patch: Partial<AggregateConfig>) => {
    const next: AggregateConfig = { ...cfg, ...patch };
    // подчищаем пустые необязательные секции
    if (next.фильтр && !next.фильтр.поле && !next.фильтр.равно) delete next.фильтр;
    if (next.порог && (next.порог.значение === "" || next.порог.значение == null)) delete next.порог;
    if (!next.группировать_по) delete next.группировать_по;
    onChange(JSON.stringify(next));
  };

  return (
    <div className="space-y-3">
      <p className="text-[10px] text-muted-foreground leading-relaxed -mt-2">
        Суммирует числовое поле по строкам JSON-массива из предыдущего узла.
        Детерминированно, без GigaChat. Результат — суммы по группам, итог и
        вердикт по порогу (+ JSON-блок для следующих узлов).
      </p>
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1.5">
          Поле суммирования (ключ JSON)
        </label>
        <Input
          value={cfg.суммировать || ""}
          onChange={(e) => update({ суммировать: e.target.value })}
          placeholder="сумма_зачтено"
          className="rounded-xl font-mono text-xs"
        />
      </div>
      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1.5">
          Группировать по полю (необяз.)
        </label>
        <Input
          value={cfg.группировать_по || ""}
          onChange={(e) => update({ группировать_по: e.target.value })}
          placeholder="договор"
          className="rounded-xl font-mono text-xs"
        />
      </div>
      <div className="border border-border rounded-xl p-3 bg-accent/30 space-y-2">
        <span className="text-xs font-medium text-foreground block">Фильтр строк (необяз.)</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground w-14 shrink-0">поле</span>
          <input
            value={cfg.фильтр?.поле || ""}
            placeholder="зачтено"
            onChange={(e) => update({ фильтр: { ...cfg.фильтр, поле: e.target.value } })}
            className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none font-mono"
          />
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground w-14 shrink-0">равно</span>
          <input
            value={cfg.фильтр?.равно || ""}
            placeholder="да"
            onChange={(e) => update({ фильтр: { ...cfg.фильтр, равно: e.target.value } })}
            className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
          />
        </div>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          В сумму входят только строки, где поле равно значению (без учёта регистра).
        </p>
      </div>
      <div className="border border-border rounded-xl p-3 bg-accent/30 space-y-2">
        <span className="text-xs font-medium text-foreground block">Порог (необяз.)</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground w-14 shrink-0">значение</span>
          <input
            value={String(cfg.порог?.значение ?? "")}
            placeholder="255732113"
            onChange={(e) => update({ порог: { ...cfg.порог, значение: e.target.value } })}
            className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none font-mono"
          />
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground w-14 shrink-0">условие</span>
          <select
            value={cfg.порог?.оператор || "greater_or_equal"}
            onChange={(e) => update({ порог: { ...cfg.порог, оператор: e.target.value } })}
            className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
          >
            {AGGREGATE_OPERATORS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] text-muted-foreground w-14 shrink-0">метка</span>
          <input
            value={cfg.порог?.метка || ""}
            placeholder="50% НМЦ лота 1"
            onChange={(e) => update({ порог: { ...cfg.порог, метка: e.target.value } })}
            className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
          />
        </div>
        <p className="text-[10px] text-muted-foreground leading-relaxed">
          Итоговая сумма сравнивается с порогом → вердикт СООТВЕТСТВУЕТ / НЕ СООТВЕТСТВУЕТ.
        </p>
      </div>
    </div>
  );
}

// ── Subscenario Selector ────────────────────────────────────────────────

function SubscenarioSelector({
  value,
  currentScenarioId,
  onChange,
}: {
  value: string;
  currentScenarioId?: string;
  onChange: (v: string) => void;
}) {
  const { data: scenarios = [] } = useQuery({
    queryKey: ["scenarios"],
    queryFn: () => import("@/api/scenarios").then((m) => m.getScenarios()),
  });
  return (
    <div>
      <label className="text-xs font-medium text-muted-foreground block mb-1.5">
        Вызываемый сценарий
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full text-xs bg-background border border-border rounded-xl px-2.5 py-2 text-foreground"
      >
        <option value="">Выберите сценарий…</option>
        {scenarios
          .filter((s) => s.id !== currentScenarioId)
          .map((s) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
      </select>
      <p className="text-[10px] text-muted-foreground mt-1 leading-relaxed">
        Документы этого узла (или его вход) станут входными документами под-сценария;
        результат под-сценария — выходом узла. Максимальная вложенность — 2.
      </p>
    </div>
  );
}

// ── Calc Node Config Editor (формулы в стиле Excel) ─────────────────────

interface CalcFormula {
  имя: string;
  формула: string;
}

interface CalcConfig {
  формулы: CalcFormula[];
  фильтр: string;
  сортировка: string[];
}

function CalcConfigEditor({
  rules,
  onChange,
}: {
  rules: string;
  onChange: (v: string) => void;
}) {
  let config: CalcConfig;
  try {
    const parsed = JSON.parse(rules);
    config = {
      формулы: Array.isArray(parsed?.формулы) ? parsed.формулы : [],
      фильтр: typeof parsed?.фильтр === "string" ? parsed.фильтр : "",
      сортировка: Array.isArray(parsed?.сортировка)
        ? parsed.сортировка
        : typeof parsed?.сортировка === "string" && parsed.сортировка
          ? [parsed.сортировка]
          : [],
    };
  } catch {
    config = { формулы: [], фильтр: "", сортировка: [] };
  }

  const update = (next: CalcConfig) => {
    const out: Record<string, unknown> = { формулы: next.формулы };
    if (next.фильтр.trim()) out.фильтр = next.фильтр;
    if (next.сортировка.length) out.сортировка = next.сортировка;
    onChange(JSON.stringify(out));
  };

  const updateFormula = (i: number, patch: Partial<CalcFormula>) => {
    const формулы = [...config.формулы];
    формулы[i] = { ...формулы[i], ...patch };
    update({ ...config, формулы });
  };

  const problems: string[] = [];
  if (config.формулы.length === 0) problems.push("не задано ни одной формулы");
  if (config.формулы.some((f) => !f.имя?.trim()))
    problems.push("у формулы не заполнено имя показателя");
  if (config.формулы.some((f) => !f.формула?.trim()))
    problems.push("не заполнено выражение формулы");

  return (
    <div className="space-y-3">
      <label className="text-xs font-medium text-muted-foreground block">
        Формулы расчёта
      </label>
      <p className="text-[10px] text-muted-foreground -mt-1 leading-relaxed">
        Считается кодом, без GigaChat. Данные — из JSON предыдущего узла (блок
        «ДАННЫЕ ДЛЯ РАСЧЁТА»): плоские числа или таблица (массив объектов —
        формулы применяются к каждой строке, как в Excel). Операции: + − × ÷,
        скобки, сравнения (&lt; &gt; = &lt;&gt;). Функции: ЕСЛИ(усл; да; нет),
        МИН, МАКС, СУММ, СРЗНАЧ, ОКРУГЛ(x; знаков), ЗНАЧ(имя; по_умолчанию),
        СОДЕРЖИТ, И, ИЛИ, НЕ. МИН(цена) по имени колонки — агрегат по всем
        строкам. Пробел в имени пишите подчёркиванием: цена_за_единицу.
        Результат формулы доступен следующим формулам по её имени.
      </p>

      {config.формулы.map((f, i) => (
        <div key={i} className="border border-border rounded-xl p-2.5 space-y-2 bg-accent/20">
          <div className="flex items-center gap-1.5">
            <input
              value={f.имя || ""}
              onChange={(e) => updateFormula(i, { имя: e.target.value })}
              placeholder="Имя показателя"
              className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none focus:ring-1 focus:ring-[#c2185b]"
            />
            <button
              onClick={() =>
                update({ ...config, формулы: config.формулы.filter((_, x) => x !== i) })
              }
              className="p-1 rounded hover:bg-background hover:text-destructive shrink-0"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>
          <input
            value={f.формула || ""}
            onChange={(e) => updateFormula(i, { формула: e.target.value })}
            placeholder="например: МИН(цена) / цена или ЕСЛИ(срок <= 10; 1; 0.5)"
            className="w-full text-xs font-mono bg-background border border-border rounded-lg px-2 py-1.5 outline-none focus:ring-1 focus:ring-[#c2185b]"
          />
        </div>
      ))}
      <button
        onClick={() =>
          update({ ...config, формулы: [...config.формулы, { имя: "", формула: "" }] })
        }
        className="w-full text-xs border border-dashed border-border rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
      >
        + Добавить формулу
      </button>

      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1">
          Фильтр строк (необязательно)
        </label>
        <input
          value={config.фильтр}
          onChange={(e) => update({ ...config, фильтр: e.target.value })}
          placeholder={'например: статус <> "ОТКЛОНЁН"'}
          className="w-full text-xs font-mono bg-background border border-border rounded-xl px-2.5 py-2 outline-none focus:ring-1 focus:ring-[#c2185b]"
        />
        <p className="text-[10px] text-muted-foreground mt-1">
          Условие отбора строк таблицы; исключённые строки не участвуют в агрегатах.
        </p>
      </div>

      <div>
        <label className="text-xs font-medium text-muted-foreground block mb-1">
          Сортировка (необязательно)
        </label>
        <input
          value={config.сортировка.join(", ")}
          onChange={(e) =>
            update({
              ...config,
              сортировка: e.target.value
                .split(",")
                .map((s) => s.trim())
                .filter(Boolean),
            })
          }
          placeholder="например: -Итог, цена"
          className="w-full text-xs font-mono bg-background border border-border rounded-xl px-2.5 py-2 outline-none focus:ring-1 focus:ring-[#c2185b]"
        />
        <p className="text-[10px] text-muted-foreground mt-1">
          Имена колонок или формул через запятую; «-» перед именем — по убыванию.
          Первая строка результата — лучшая по заданной сортировке.
        </p>
      </div>

      {problems.length > 0 ? (
        <div className="text-[10px] text-[#e53935] bg-red-50 border border-red-200 rounded-xl px-3 py-2 space-y-0.5">
          {problems.map((p, i) => (
            <div key={i}>⚠️ {p}</div>
          ))}
        </div>
      ) : (
        <div className="text-[10px] text-[#21a038] bg-green-50 border border-green-200 rounded-xl px-3 py-2">
          ✓ Формулы заданы: {config.формулы.length} шт.
        </div>
      )}
    </div>
  );
}

// ── Visual Switch Rules Editor ──────────────────────────────────────────

interface SwitchRule {
  value: string;
  operator: string;
  label: string;
}

const OPERATORS = [
  { value: "contains", label: "содержит" },
  { value: "equals", label: "равно" },
  { value: "startswith", label: "начинается с" },
];

function SwitchRulesEditor({
  rules,
  onChange,
  suggestedClasses,
}: {
  rules: string;
  onChange: (v: string) => void;
  suggestedClasses?: string[] | null;
}) {
  let parsed: SwitchRule[] = [];
  try {
    parsed = JSON.parse(rules);
  } catch {
    parsed = [];
  }

  const update = (newRules: SwitchRule[]) => {
    onChange(JSON.stringify(newRules));
  };

  const addRule = (cls?: string) => {
    update([
      ...parsed,
      { value: cls || "", operator: "contains", label: cls || "" },
    ]);
  };

  const removeRule = (i: number) => {
    update(parsed.filter((_, idx) => idx !== i));
  };

  const updateRule = (i: number, field: keyof SwitchRule, val: string) => {
    const copy = [...parsed];
    copy[i] = { ...copy[i], [field]: val };
    if (
      field === "value" &&
      (!copy[i].label || copy[i].label === parsed[i].value)
    ) {
      copy[i].label = val;
    }
    update(copy);
  };

  // Auto-populate rules from predecessor Loop classes
  const usedValues = new Set(parsed.map((r) => r.value));
  const missingClasses =
    suggestedClasses?.filter((c) => !usedValues.has(c)) || [];

  return (
    <div className="space-y-3">
      <label className="text-xs font-medium text-muted-foreground block">
        Правила маршрутизации
      </label>
      <p className="text-[10px] text-muted-foreground -mt-1">
        {suggestedClasses
          ? "Классы подтянуты из узла классификации. Метка ребра определяет ветку."
          : "Каждое правило проверяет текст предыдущего узла. Метка ребра определяет ветку."}{" "}
        Без GigaChat.
      </p>

      {missingClasses.length > 0 && (
        <button
          onClick={() => {
            const newRules = [...parsed];
            for (const cls of missingClasses) {
              newRules.push({ value: cls, operator: "contains", label: cls });
            }
            update(newRules);
          }}
          className="w-full text-xs bg-[#ff6f00]/10 text-[#ff6f00] border border-[#ff6f00]/30 rounded-xl px-3 py-2 hover:bg-[#ff6f00]/20 transition-colors"
        >
          Добавить классы: {missingClasses.join(", ")}
        </button>
      )}

      {parsed.map((rule, i) => (
        <div
          key={i}
          className="flex items-center gap-1.5 bg-accent/30 rounded-xl p-2"
        >
          <div className="flex-1 space-y-1.5">
            <div className="flex gap-1.5">
              <input
                value={rule.value}
                onChange={(e) => updateRule(i, "value", e.target.value)}
                placeholder="Значение"
                className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none focus:ring-1 focus:ring-[#ff6f00]"
              />
              <select
                value={rule.operator}
                onChange={(e) => updateRule(i, "operator", e.target.value)}
                className="text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none"
              >
                {OPERATORS.map((op) => (
                  <option key={op.value} value={op.value}>
                    {op.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                → ветка:
              </span>
              <input
                value={rule.label}
                onChange={(e) => updateRule(i, "label", e.target.value)}
                placeholder="Метка ребра"
                className="flex-1 text-xs bg-background border border-border rounded-lg px-2 py-1.5 outline-none focus:ring-1 focus:ring-[#ff6f00]"
              />
            </div>
          </div>
          <button
            onClick={() => removeRule(i)}
            className="p-1 rounded hover:bg-background hover:text-destructive shrink-0"
          >
            <svg
              width="12"
              height="12"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      ))}

      <button
        onClick={() => addRule()}
        className="w-full text-xs border border-dashed border-border rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
      >
        + Добавить правило
      </button>
    </div>
  );
}
