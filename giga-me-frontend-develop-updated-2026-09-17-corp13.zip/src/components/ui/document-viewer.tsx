import { useEffect, useMemo, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getDocument } from '@/api/documents';

interface DocumentViewerProps {
  documentId: string;
  /** Фрагмент, который нужно подсветить и показать (сниппет источника RAG) */
  snippet?: string | null;
  onClose: () => void;
}

/**
 * Модальный просмотр документа-источника: имя файла, извлечённый текст,
 * подсветка и автопрокрутка к сниппету, по которому пришёл RAG-ответ.
 */
export function DocumentViewer({ documentId, snippet, onClose }: DocumentViewerProps) {
  const markRef = useRef<HTMLElement>(null);

  const { data: doc, isLoading, isError } = useQuery({
    queryKey: ['document', documentId],
    queryFn: () => getDocument(documentId),
  });

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  // Разбиение текста на [до, совпадение, после] по сниппету
  const partsData = useMemo(() => {
    const text = doc?.extracted_text || '';
    if (!text) return null;
    const needle = (snippet || '').slice(0, 120).trim();
    if (needle.length >= 20) {
      const idx = text.indexOf(needle);
      if (idx >= 0) {
        return {
          before: text.slice(0, idx),
          match: text.slice(idx, idx + needle.length),
          after: text.slice(idx + needle.length),
          beyondShown: false,
        };
      }
    }
    // сервер отдаёт не больше 500 000 символов текста (лимит шлюза) и дописывает пометку об усечении
    const beyondShown = needle.length >= 20 && text.includes('…[текст документа усечён до');
    return { before: text, match: '', after: '', beyondShown };
  }, [doc?.extracted_text, snippet]);

  useEffect(() => {
    if (partsData?.match && markRef.current) {
      markRef.current.scrollIntoView({ block: 'center' });
    }
  }, [partsData]);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/40 flex items-center justify-center p-6"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-card rounded-2xl shadow-xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 border-b border-border">
          <div className="flex items-center gap-2 min-w-0">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#21a038" strokeWidth="2" className="flex-shrink-0">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
            </svg>
            <span className="text-sm font-medium truncate" title={doc?.filename}>
              {doc?.filename || 'Документ'}
            </span>
            {doc?.size_bytes != null && (
              <span className="text-[11px] text-muted-foreground flex-shrink-0">
                {(doc.size_bytes / 1024).toFixed(0)} КБ
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent"
            title="Закрыть (Esc)"
            aria-label="Закрыть"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {isLoading && (
            <div className="text-sm text-muted-foreground">Загрузка документа...</div>
          )}
          {isError && (
            <div className="text-sm text-destructive">
              Не удалось загрузить документ (нет доступа или документ удалён)
            </div>
          )}
          {partsData?.beyondShown && (
            <div className="text-xs text-muted-foreground mb-2">
              Цитируемый фрагмент находится за пределами показанной части документа (показаны первые 500 000 символов).
            </div>
          )}
          {partsData && (
            <pre className="whitespace-pre-wrap text-xs leading-relaxed font-sans text-foreground">
              {partsData.before}
              {partsData.match && (
                <mark ref={markRef} className="bg-[#21a038]/25 rounded px-0.5">
                  {partsData.match}
                </mark>
              )}
              {partsData.after}
            </pre>
          )}
          {doc && !doc.extracted_text && (
            <div className="text-sm text-muted-foreground">Текст документа пуст</div>
          )}
        </div>
      </div>
    </div>
  );
}
