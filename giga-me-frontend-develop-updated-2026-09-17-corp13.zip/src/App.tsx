import { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate, useParams } from "react-router-dom";
import { MutationCache, QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppLayout } from "@/components/layout/AppLayout";
import { ChatPage } from "@/pages/ChatPage";
import { KnowledgeBasePage } from "@/pages/KnowledgeBasePage";
import { ScenariosPage } from "@/pages/ScenariosPage";
import { ScenarioEditorPage } from "@/pages/ScenarioEditorPage";
import { ScenarioRunPage } from "@/pages/ScenarioRunPage";
import { PromptsPage } from "@/pages/PromptsPage";
import { AgentMemoryPage } from "@/pages/AgentMemoryPage";
import { closeScenarioWebSocket, closeWebSocket } from "@/api/websocket";
import { ApiError } from "@/api/client";
import { toast } from "@/components/ui/toast";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      // повтор только при ошибках сервера/сети: 403/404/422 повторять бессмысленно
      retry: (failureCount, error) =>
        failureCount < 1 && (!(error instanceof ApiError) || error.status >= 500),
    },
  },
  // Мутации без собственного onError (память агента, промпты, ответы агенту)
  // раньше молча падали — теперь причина показывается тостом
  mutationCache: new MutationCache({
    onError: (error, _variables, _context, mutation) => {
      if (mutation.options.onError) return;
      toast(
        `Не удалось выполнить действие: ${error instanceof Error ? error.message : String(error)}`,
        "error"
      );
    },
  }),
});

// key по scenarioId: переход между сценариями перемонтирует редактор —
// иначе под URL сценария B оставался граф и название сценария A
function ScenarioEditorRoute() {
  const { scenarioId } = useParams<{ scenarioId: string }>();
  return <ScenarioEditorPage key={scenarioId} />;
}

export const App = ({ basename }: { basename?: string }) => {
  useEffect(() => {
    // Close WebSocket when app unmounts
    return () => {
      closeWebSocket();
      closeScenarioWebSocket();
    };
  }, []);

  return (
    <ErrorBoundary homeHref={basename || "/"}>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter basename={basename}>
          <Routes>
            <Route element={<AppLayout />}>
              <Route path="/" element={<Navigate to="/chat" replace />} />
              <Route path="/chat" element={<ChatPage />} />
              <Route path="/chat/:conversationId" element={<ChatPage />} />
              <Route path="/knowledge-bases" element={<KnowledgeBasePage />} />
              <Route
                path="/knowledge-bases/:kbId"
                element={<KnowledgeBasePage />}
              />
              <Route path="/scenarios" element={<ScenariosPage />} />
              <Route path="/prompts" element={<PromptsPage />} />
              <Route path="/agent-memory" element={<AgentMemoryPage />} />
              <Route
                path="/scenarios/:scenarioId/edit"
                element={<ScenarioEditorRoute />}
              />
              <Route
                path="/scenarios/:scenarioId/runs/:runId"
                element={<ScenarioRunPage />}
              />
              <Route path="*" element={<Navigate to="/chat" replace />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};
