import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  addAgentLesson,
  approveAgentLesson,
  compressAgentLessons,
  deleteAgentLesson,
  deleteAgentPlan,
  getAgentLessons,
  getAgentPlans,
  updateAgentLesson,
  AGENT_TEXT_MAX_LENGTH,
  type AgentLesson,
} from '@/api/agentMemory';
import { getScenarios } from '@/api/scenarios';
import { toast } from '@/components/ui/toast';

const SOURCE_LABEL: Record<string, string> = {
  user: 'пользователь',
  reviser: 'ревизор',
  auto: 'сжатие',
  system: 'системный',
};

/**
 * Память агента: уроки (частные для сценария и общие), планы.
 * Память прозрачна: всё видно, редактируемо и удаляемо — это защита от
 * «отравления» выученными ошибками. Ответы на вопросы агента из карточек
 * прогонов тоже попадают сюда.
 */
export function AgentMemoryPage() {
  const queryClient = useQueryClient();
  const [scenarioId, setScenarioId] = useState<string>('');
  const [newLesson, setNewLesson] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');

  const { data: scenarios } = useQuery({ queryKey: ['scenarios'], queryFn: getScenarios });
  const { data: lessons } = useQuery({
    queryKey: ['agent-lessons', scenarioId],
    queryFn: () => getAgentLessons(scenarioId || undefined),
  });
  const { data: plans } = useQuery({
    queryKey: ['agent-plans', scenarioId],
    queryFn: () => (scenarioId ? getAgentPlans(scenarioId) : Promise.resolve([])),
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ['agent-lessons'] });
    queryClient.invalidateQueries({ queryKey: ['agent-plans'] });
  };

  const addMut = useMutation({
    mutationFn: () => addAgentLesson(newLesson, scenarioId || undefined),
    onSuccess: () => {
      setNewLesson('');
      invalidate();
      toast('Урок сохранён', 'success');
    },
  });
  const saveMut = useMutation({
    mutationFn: () => updateAgentLesson(editingId!, editingText),
    onSuccess: () => {
      setEditingId(null);
      invalidate();
    },
  });
  const deleteMut = useMutation({ mutationFn: deleteAgentLesson, onSuccess: invalidate });
  const approveMut = useMutation({ mutationFn: approveAgentLesson, onSuccess: invalidate });
  const deletePlanMut = useMutation({ mutationFn: deleteAgentPlan, onSuccess: invalidate });
  const compressMut = useMutation({
    mutationFn: () => compressAgentLessons(scenarioId),
    onSuccess: (compressed) => {
      invalidate();
      toast(`Уроки сжаты: осталось ${compressed.length}`, 'success');
    },
    onError: () => toast('Сжатие не удалось (нужно ≥3 уроков)', 'error'),
  });

  return (
    <div className="flex flex-col h-full p-8 overflow-y-auto">
      <div className="w-full max-w-4xl mx-auto">
        <h1 className="text-xl font-semibold text-foreground mb-2">Память</h1>
        <p className="text-sm text-muted-foreground mb-4">
          Три слоя: <b>системные</b> уроки поставляются с релизом и действуют для всех
          (менять нельзя); <b>ваши общие</b> действуют на ваши запуски во всех сценариях;
          <b> уроки сценария</b> едут вместе со сценарием к любому запускающему —
          изменять их может только автор сценария.
        </p>

        <select
          value={scenarioId}
          onChange={(e) => setScenarioId(e.target.value)}
          className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background mb-4"
        >
          <option value="">Общие уроки (для всех сценариев)</option>
          {(scenarios ?? []).map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>

        <div className="flex gap-2 mb-4">
          <input
            value={newLesson}
            maxLength={AGENT_TEXT_MAX_LENGTH}
            onChange={(e) => setNewLesson(e.target.value)}
            placeholder={
              scenarioId
                ? 'Новый урок для сценария (например: сумма акта — это «Итого» с НДС)'
                : 'Новый общий урок (начнёт применяться после одобрения)'
            }
            className="flex-1 text-sm border border-border rounded-lg px-3 py-2 bg-background"
          />
          <button
            onClick={() => addMut.mutate()}
            disabled={addMut.isPending || !newLesson.trim()}
            className="text-sm px-3 py-1.5 rounded-lg bg-[#21a038] text-white disabled:opacity-50"
          >
            Добавить
          </button>
          {scenarioId && (lessons ?? []).length >= 3 && (
            <button
              onClick={() => compressMut.mutate()}
              disabled={compressMut.isPending}
              title="Рефлексия: дистиллировать уроки в не более 7 общих правил"
              className="text-sm px-3 py-1.5 rounded-lg border border-border hover:bg-accent disabled:opacity-50"
            >
              {compressMut.isPending ? 'Сжимаю…' : 'Сжать уроки'}
            </button>
          )}
        </div>

        <div className="space-y-2 mb-8">
          {(lessons ?? []).map((l: AgentLesson) => (
            <div key={l.id} className="border border-border rounded-xl p-3 bg-card">
              {editingId === l.id ? (
                <div className="flex gap-2">
                  <input
                    value={editingText}
                    maxLength={AGENT_TEXT_MAX_LENGTH}
                    onChange={(e) => setEditingText(e.target.value)}
                    className="flex-1 text-sm border border-border rounded-lg px-2 py-1 bg-background"
                  />
                  <button onClick={() => saveMut.mutate()} className="text-xs text-[#21a038]">
                    Сохранить
                  </button>
                  <button onClick={() => setEditingId(null)} className="text-xs">
                    Отмена
                  </button>
                </div>
              ) : (
                <>
                  <div className="text-sm text-foreground">{l.lesson}</div>
                  <div className="flex items-center gap-3 mt-1.5 text-[11px] text-muted-foreground">
                    <span
                      className={l.source === 'system' ? 'text-sky-600 font-medium' : ''}
                    >
                      {l.source === 'system'
                        ? '🛡 системный (поставляется релизом)'
                        : `источник: ${SOURCE_LABEL[l.source] ?? l.source}`}
                    </span>
                    {l.source !== 'system' && !l.approved && (
                      <span className="text-amber-500">ждёт одобрения — не применяется</span>
                    )}
                    {l.source !== 'system' && !l.approved && (
                      <button
                        onClick={() => approveMut.mutate(l.id)}
                        className="text-[#21a038] hover:underline"
                      >
                        Одобрить
                      </button>
                    )}
                    {l.source !== 'system' && (
                      <>
                        <button
                          onClick={() => {
                            setEditingId(l.id);
                            setEditingText(l.lesson.slice(0, AGENT_TEXT_MAX_LENGTH));
                          }}
                          className="hover:underline"
                        >
                          Изменить
                        </button>
                        <button
                          onClick={() => {
                            if (confirm('Удалить урок?')) deleteMut.mutate(l.id);
                          }}
                          className="text-red-500/80 hover:underline"
                        >
                          Удалить
                        </button>
                      </>
                    )}
                  </div>
                </>
              )}
            </div>
          ))}
          {(lessons ?? []).length === 0 && (
            <div className="text-sm text-muted-foreground text-center py-6">
              Уроков пока нет — они появятся из ваших ответов на вопросы агента или
              добавьте правило вручную
            </div>
          )}
        </div>

        {scenarioId && (plans ?? []).length > 0 && (
          <>
            <h2 className="text-sm font-semibold text-foreground mb-2">
              Память планов (проверенные чек-листы заданий)
            </h2>
            <div className="space-y-2">
              {(plans ?? []).map((p) => (
                <div key={p.id} className="border border-border rounded-xl p-3 bg-card">
                  <div className="text-xs text-muted-foreground mb-1">
                    {p.task_preview ?? 'задание'} · переиспользован: {p.uses}
                  </div>
                  <pre className="text-xs text-foreground/80 whitespace-pre-wrap">
                    {(() => {
                      try {
                        return (JSON.parse(p.plan) as string[])
                          .map((item, i) => `${i + 1}. ${item}`)
                          .join('\n');
                      } catch {
                        return p.plan;
                      }
                    })()}
                  </pre>
                  <button
                    onClick={() => {
                      if (confirm('Удалить план?')) deletePlanMut.mutate(p.id);
                    }}
                    className="text-[11px] text-red-500/80 hover:underline mt-1"
                  >
                    Удалить план
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
