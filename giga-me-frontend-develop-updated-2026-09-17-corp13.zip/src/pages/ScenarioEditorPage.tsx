import { useEffect, useCallback, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  ReactFlow,
  Background,
  Controls,
  type Node,
  type Edge,
  type Connection,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import {
  getScenario,
  getScenarios,
  updateScenario,
  createScenario,
  getScenarioVersions,
  restoreScenarioVersion,
} from '@/api/scenarios';
import { validateGraph } from '@/api/graphValidation';
import { useScenarioStore, confirmLeaveEditor } from '@/stores/scenarioStore';
import { nodeTypes } from '@/components/scenario/ScenarioNode';
import { edgeTypes } from '@/components/scenario/LabeledEdge';
import { NodePalette } from '@/components/scenario/NodePalette';
import { NodeConfigPanel } from '@/components/scenario/NodeConfigPanel';
import { ScenarioRunner } from '@/components/scenario/ScenarioRunner';
import { ResizablePanel } from '@/components/scenario/ResizablePanel';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/toast';

/**
 * Снимок редактируемого состояния для признака «есть несохранённые правки»:
 * только то, что уходит в PUT (служебные поля React Flow — measured, selected,
 * dragging — не учитываются, иначе клик по узлу делал бы сценарий «грязным»).
 */
function serializeEditorState(name: string, nodes: Node[], edges: Edge[]): string {
  return JSON.stringify({
    name,
    nodes: nodes.map((n) => ({ id: n.id, type: n.type, position: n.position, data: n.data })),
    edges: edges.map((e) => ({
      id: e.id,
      source: e.source,
      target: e.target,
      sourceHandle: e.sourceHandle,
      targetHandle: e.targetHandle,
      data: e.data,
    })),
  });
}

function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : 'неизвестная ошибка';
}

export function ScenarioEditorPage() {
  const { scenarioId } = useParams<{ scenarioId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  // null — название не правили: показывается значение с сервера (в т.ч. после
  // переименования в сайдбаре); строка — локальная правка до сохранения
  const [nameEdit, setNameEdit] = useState<string | null>(null);
  const [showRunner, setShowRunner] = useState(false);
  const nodeIdCounter = useRef(0);
  // граф этого сценария уже загружен в стор: повторные ответы GET (refetch
  // после переименования) не должны затирать правки на канвасе
  const loadedRef = useRef(false);
  // снимок сохранённого состояния для признака несохранённых правок
  const baselineRef = useRef<string | null>(null);

  const {
    nodes,
    edges,
    setNodes,
    setEdges,
    onNodesChange,
    onEdgesChange,
    onConnect: storeOnConnect,
    selectNode,
    selectEdge,
    addNode,
    execStatuses,
    editorDirty,
    setEditorDirty,
    focusElement,
  } = useScenarioStore();

  // When connecting from a branching node (Switch/If), auto‑select the edge
  // so the config panel can offer the label picker.
  const handleConnect = useCallback(
    (connection: Connection) => {
      const sourceNode = nodes.find((n) => n.id === connection.source);

      // Plain connect first
      storeOnConnect(connection);

      // Auto‑select the newly created edge so the user sees the label picker
      if (sourceNode && (sourceNode.type === 'if_node' || sourceNode.type === 'switch')) {
        const newEdge = useScenarioStore.getState().edges.find(
          (e) => e.source === connection.source && e.target === connection.target,
        );
        if (newEdge) selectEdge(newEdge.id);
        else selectNode(sourceNode.id);
      }
    },
    [nodes, storeOnConnect, selectEdge, selectNode],
  );

  const { data: scenario, error: loadError } = useQuery({
    queryKey: ['scenario', scenarioId],
    queryFn: () => getScenario(scenarioId!),
    enabled: !!scenarioId,
  });

  // is_owner есть только в списке (ScenarioResponse), в детальной ручке — нет:
  // кнопки владельца скрываются по списку сценариев
  const { data: scenarios } = useQuery({ queryKey: ['scenarios'], queryFn: getScenarios });
  const isOwner = scenarios?.find((s) => s.id === scenarioId)?.is_owner !== false;

  // загруженный сценарий совпадает с URL — только тогда можно сохранять
  const loaded = !!scenario && scenario.id === scenarioId;
  const name = nameEdit ?? scenario?.name ?? '';

  // Стор глобальный: при смене сценария в одной вкладке граф и статусы
  // прогона прежнего сценария сбрасываются на входе и выходе
  useEffect(() => {
    const reset = () => {
      const store = useScenarioStore.getState();
      store.setNodes([]);
      store.setEdges([]);
      store.selectNode(null);
      store.resetExecStatuses();
      store.setEditorDirty(false);
    };
    loadedRef.current = false;
    baselineRef.current = null;
    reset();
    return reset;
  }, [scenarioId]);

  // Признак несохранённых правок — в стор: его читают сайдбар и раннер перед
  // уходом со страницы (объявлен раньше загрузки графа, чтобы не мигать true)
  useEffect(() => {
    if (baselineRef.current === null) return;
    setEditorDirty(serializeEditorState(name, nodes, edges) !== baselineRef.current);
  }, [name, nodes, edges, setEditorDirty]);

  useEffect(() => {
    if (!scenario || scenario.id !== scenarioId || loadedRef.current) return;
    loadedRef.current = true;
    const gd = scenario.graph_data || { nodes: [], edges: [] };
    const loadedNodes = gd.nodes || [];
    const loadedEdges = gd.edges || [];
    setNodes(loadedNodes);
    setEdges(loadedEdges);
    const maxId = loadedNodes.reduce((max: number, n: Node) => {
      const num = parseInt(n.id.split('_').pop() || '0');
      return num > max ? num : max;
    }, 0);
    nodeIdCounter.current = maxId + 1;
    baselineRef.current = serializeEditorState(scenario.name, loadedNodes, loadedEdges);
    setEditorDirty(false);
  }, [scenario, scenarioId, setNodes, setEdges, setEditorDirty]);

  // Закрытие вкладки / перезагрузка с несохранёнными правками
  useEffect(() => {
    if (!editorDirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [editorDirty]);

  const saveMutation = useMutation({
    mutationFn: () =>
      updateScenario(scenarioId!, {
        name,
        graph_data: { nodes, edges },
      }),
    onSuccess: () => {
      baselineRef.current = serializeEditorState(name, nodes, edges);
      setEditorDirty(false);
      queryClient.invalidateQueries({ queryKey: ['scenarios'] });
      toast('Сценарий сохранён', 'success');
    },
    onError: (err) => toast(`Ошибка сохранения: ${errorMessage(err)}`, 'error'),
  });

  const handleSave = () => {
    if (!loaded || saveMutation.isPending) return;
    const issue = validateGraph(nodes, edges);
    if (issue) {
      focusElement(issue.nodeId, issue.edgeId);
      toast(issue.message, 'error');
      return;
    }
    saveMutation.mutate();
  };

  const handleAddNode = useCallback(
    (type: string) => {
      const id = `node_${nodeIdCounter.current++}`;
      const node: Node = {
        id,
        type,
        position: { x: 250 + Math.random() * 100, y: 100 + nodes.length * 120 },
        data: { label: '', prompt: '' },
      };
      addNode(node);
    },
    [addNode, nodes.length],
  );

  const handleNodeClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      selectNode(node.id);
    },
    [selectNode],
  );

  const handleEdgeClick = useCallback(
    (_: React.MouseEvent, edge: Edge) => {
      selectEdge(edge.id);
    },
    [selectEdge],
  );

  // Сценарий не открылся (403/404/500, шлюз): текст причины вместо пустого канваса
  if (loadError) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-3 p-8 text-center">
        <h2 className="text-lg font-semibold">Не удалось открыть сценарий</h2>
        <p className="text-sm text-muted-foreground max-w-md">{errorMessage(loadError)}</p>
        <Button size="sm" variant="outline" className="rounded-xl" onClick={() => navigate('/scenarios')}>
          К списку сценариев
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Top bar */}
      <div className="bg-card border-b border-border px-5 py-2.5 flex items-center gap-3 shadow-sm">
        <button
          onClick={() => {
            if (!confirmLeaveEditor()) return;
            navigate('/scenarios');
          }}
          className="w-8 h-8 rounded-xl hover:bg-accent flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <Input
          value={name}
          onChange={(e) => setNameEdit(e.target.value)}
          className="w-64 rounded-xl font-medium"
          placeholder="Название сценария"
        />
        <div className="flex-1" />
        {isOwner && (
          <Button
            size="sm"
            variant="outline"
            className="rounded-xl"
            title="Описание сценария (видно всем в списке общих)"
            onClick={async () => {
              if (!scenarioId) return;
              try {
                const detail = await getScenario(scenarioId);
                const next = window.prompt('Описание сценария:', detail.description ?? '');
                if (next === null) return;
                await updateScenario(scenarioId, { description: next });
                queryClient.invalidateQueries({ queryKey: ['scenarios'] });
                toast('Описание сохранено', 'success');
              } catch (err) {
                toast(`Не удалось сохранить описание: ${errorMessage(err)}`, 'error');
              }
            }}
          >
            Описание
          </Button>
        )}
        {isOwner && (
          <Button
            size="sm"
            variant="outline"
            className="rounded-xl"
            title="Общий сценарий виден и доступен всем пользователям на странице «Сценарии»"
            onClick={async () => {
              if (!scenarioId) return;
              try {
                const detail = await getScenario(scenarioId);
                const isShared = (detail as { shared?: boolean }).shared === true;
                const question = isShared
                  ? 'Сделать сценарий снова личным?'
                  : 'Сделать сценарий общим? Он станет виден всем пользователям.';
                if (!window.confirm(question)) return;
                let description: string | undefined;
                if (!isShared && !detail.description?.trim()) {
                  const entered = window.prompt(
                    'У общего сценария должно быть описание — по нему коллеги поймут, ' +
                      'что делает сценарий и для каких документов подходит:',
                    '',
                  );
                  if (entered === null || !entered.trim()) {
                    toast('Общий доступ не включён: нужно описание', 'error');
                    return;
                  }
                  description = entered.trim();
                }
                await updateScenario(scenarioId, { shared: !isShared, description });
                queryClient.invalidateQueries({ queryKey: ['scenarios'] });
                toast(isShared ? 'Сценарий снова личный' : 'Сценарий стал общим', 'success');
              } catch (err) {
                toast(`Не удалось изменить общий доступ: ${errorMessage(err)}`, 'error');
              }
            }}
          >
            Общий доступ
          </Button>
        )}
        <VersionsMenu scenarioId={scenarioId} canRestore={isOwner} />
        <Button
          size="sm"
          variant="outline"
          className="rounded-xl"
          title="Скачать сценарий JSON-файлом"
          onClick={async () => {
            if (!scenarioId) return;
            try {
              const detail = await getScenario(scenarioId);
              const payload = {
                name: detail.name,
                description: detail.description,
                graph_data: detail.graph_data,
              };
              const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `${detail.name || 'scenario'}.json`;
              a.click();
              URL.revokeObjectURL(url);
            } catch (err) {
              toast(`Не удалось экспортировать сценарий: ${errorMessage(err)}`, 'error');
            }
          }}
        >
          Экспорт
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="rounded-xl"
          title="Создать сценарий из JSON-файла"
          onClick={() => document.getElementById('scenario-import-input')?.click()}
        >
          Импорт
        </Button>
        <input
          id="scenario-import-input"
          type="file"
          accept="application/json"
          className="hidden"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (!file) return;
            // ошибка разбора файла и ошибка API — разные причины, разные сообщения
            let parsed: { name?: string; description?: string; graph_data?: { nodes?: unknown } };
            try {
              parsed = JSON.parse(await file.text());
            } catch {
              toast('Не удалось разобрать JSON-файл', 'error');
              return;
            }
            if (!parsed.graph_data?.nodes) {
              toast('В файле нет graph_data — это не экспорт сценария', 'error');
              return;
            }
            if (!confirmLeaveEditor()) return;
            try {
              const created = await createScenario(
                (parsed.name || file.name.replace(/\.json$/i, '')) + ' (импорт)',
                parsed.description || '',
                parsed.graph_data,
              );
              toast('Сценарий импортирован', 'success');
              queryClient.invalidateQueries({ queryKey: ['scenarios'] });
              navigate(`/scenarios/${created.id}/edit`);
            } catch (err) {
              toast(`Не удалось импортировать сценарий: ${errorMessage(err)}`, 'error');
            }
          }}
        />
        <Button
          size="sm"
          className="rounded-xl"
          onClick={handleSave}
          disabled={saveMutation.isPending || !loaded}
          title={loaded ? (editorDirty ? 'Есть несохранённые изменения' : undefined) : 'Сценарий ещё не загружен'}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mr-1.5">
            <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>
          </svg>
          {saveMutation.isPending ? 'Сохранение...' : editorDirty ? 'Сохранить *' : 'Сохранить'}
        </Button>
        <Button
          size="sm"
          variant={showRunner ? 'outline' : 'default'}
          className={`rounded-xl ${!showRunner ? 'bg-[#00897b] hover:bg-[#00796b]' : ''}`}
          onClick={() => setShowRunner(!showRunner)}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" className="mr-1.5">
            <polygon points="5 3 19 12 5 21 5 3"/>
          </svg>
          {showRunner ? 'Редактор' : 'Запустить'}
        </Button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Node palette */}
        <NodePalette onAdd={handleAddNode} />

        {/* Canvas */}
        <div className="flex-1 bg-[#f7fbf7]">
          <ReactFlow
            nodes={nodes.map((n) => ({
              ...n,
              data: { ...n.data, execStatus: execStatuses[n.id] },
            }))}
            edges={edges.map((e) => e.data?.label ? { ...e, type: 'labeled' } : e)}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={handleConnect}
            onNodeClick={handleNodeClick}
            onEdgeClick={handleEdgeClick}
            onPaneClick={() => {
              selectNode(null);
              selectEdge(null);
            }}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            fitView
            deleteKeyCode="Delete"
            defaultEdgeOptions={{
              style: { stroke: '#21a038', strokeWidth: 2 },
              type: 'smoothstep',
            }}
          >
            <Background color="#d4e5d6" gap={20} size={1} />
            <Controls
              className="!bg-white !border-border !rounded-xl !shadow-md"
            />
          </ReactFlow>
        </div>

        {/* Config panel or runner — resizable; key: ширина читается из своего ключа localStorage,
            а не перетекает из панели настройки в раннер и обратно */}
        <ResizablePanel
          key={showRunner ? 'runner' : 'config'}
          storageKey={showRunner ? 'scenario-runner-width' : 'scenario-config-width'}
          defaultWidth={showRunner ? 360 : 320}
          minWidth={260}
          maxWidth={800}
        >
          {showRunner ? (
            <ScenarioRunner
              scenarioId={scenarioId!}
              onClose={() => setShowRunner(false)}
            />
          ) : (
            <NodeConfigPanel />
          )}
        </ResizablePanel>
      </div>
    </div>
  );
}

// ── Версии сценария: список сохранений и восстановление ─────────────────

function VersionsMenu({ scenarioId, canRestore }: { scenarioId?: string; canRestore: boolean }) {
  const [open, setOpen] = useState(false);
  const { data: versions = [], refetch } = useQuery({
    queryKey: ['scenario-versions', scenarioId],
    queryFn: () => getScenarioVersions(scenarioId!),
    enabled: !!scenarioId && open,
  });

  if (!scenarioId) return null;

  return (
    <div className="relative">
      <Button
        size="sm"
        variant="outline"
        className="rounded-xl"
        onClick={() => setOpen(!open)}
        title="История сохранений сценария"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mr-1.5">
          <circle cx="12" cy="12" r="9" />
          <polyline points="12 7 12 12 15 15" />
        </svg>
        Версии
      </Button>
      {open && (
        <div className="absolute right-0 top-10 z-50 w-72 bg-card border border-border rounded-xl shadow-lg p-2 max-h-80 overflow-y-auto">
          {versions.length === 0 ? (
            <p className="text-xs text-muted-foreground p-2">
              Версий пока нет — снапшот создаётся при каждом сохранении сценария.
            </p>
          ) : (
            versions.map((v) => (
              <div
                key={v.version_no}
                className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-lg hover:bg-accent text-xs"
              >
                <div className="min-w-0">
                  <div className="font-medium truncate">
                    v{v.version_no} — {v.name || 'без названия'}
                  </div>
                  <div className="text-muted-foreground text-[10px]">
                    {new Date(v.created_at).toLocaleString('ru-RU')}
                  </div>
                </div>
                {canRestore && (
                  <button
                    className="text-[#1976d2] hover:underline shrink-0"
                    onClick={async () => {
                      if (!confirm(`Восстановить версию v${v.version_no}? Текущее состояние сохранится как новая версия.`)) return;
                      try {
                        await restoreScenarioVersion(scenarioId, v.version_no);
                      } catch (err) {
                        toast(`Не удалось восстановить версию: ${errorMessage(err)}`, 'error');
                        return;
                      }
                      toast('Версия восстановлена', 'success');
                      await refetch();
                      // граф на сервере заменён — несохранённые правки редактора больше не актуальны
                      useScenarioStore.getState().setEditorDirty(false);
                      window.location.reload();
                    }}
                  >
                    восстановить
                  </button>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
