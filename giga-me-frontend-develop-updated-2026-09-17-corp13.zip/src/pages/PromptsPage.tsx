import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  createPrompt,
  deletePrompt,
  getPrompts,
  ratePrompt,
  updatePrompt,
  usePromptText,
  type Prompt,
} from '@/api/prompts';
import { MODELS } from '@/api/constants';

/**
 * База промптов: проверенные формулировки с рейтингами и счётчиком
 * использований. «Использовать» копирует текст в буфер обмена и
 * увеличивает счётчик. Свои промпты можно изменять и удалять.
 */
export function PromptsPage() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [text, setText] = useState('');
  const [model, setModel] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const { data: prompts } = useQuery({ queryKey: ['prompts'], queryFn: getPrompts });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ['prompts'] });

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setText('');
    setModel('');
    setEditingId(null);
    setShowForm(false);
  };

  const saveMut = useMutation({
    mutationFn: () =>
      editingId
        ? updatePrompt(editingId, { title, description, text, model })
        : createPrompt({ title, description: description || undefined, text, model: model || undefined }),
    onSuccess: () => {
      resetForm();
      invalidate();
    },
  });
  const rateMut = useMutation({
    mutationFn: ({ id, rating }: { id: string; rating: number }) => ratePrompt(id, rating),
    onSuccess: invalidate,
  });
  const deleteMut = useMutation({ mutationFn: deletePrompt, onSuccess: invalidate });
  const useMut = useMutation({
    mutationFn: usePromptText,
    onSuccess: async (result, id) => {
      try {
        await navigator.clipboard.writeText(result.text);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
      } catch {
        // буфер недоступен — текст всё равно виден в карточке
      }
      invalidate();
    },
  });

  const startEdit = (p: Prompt) => {
    setEditingId(p.id);
    setTitle(p.title);
    setDescription(p.description ?? '');
    setText(p.text);
    setModel((p.model ?? '').slice(0, 64));
    setShowForm(true);
  };

  const query = search.trim().toLowerCase();
  const visible = (prompts ?? []).filter(
    (p) =>
      !query ||
      p.title.toLowerCase().includes(query) ||
      (p.description ?? '').toLowerCase().includes(query) ||
      (p.model ?? '').toLowerCase().includes(query) ||
      p.text.toLowerCase().includes(query),
  );

  return (
    <div className="flex flex-col h-full p-8 overflow-y-auto">
      <div className="w-full max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-2">
          <h1 className="text-xl font-semibold text-foreground">База промптов</h1>
          <button
            onClick={() => (showForm ? resetForm() : setShowForm(true))}
            className="text-sm px-3 py-1.5 rounded-lg bg-[#21a038] text-white hover:bg-[#1c8a30]"
          >
            {showForm ? 'Отмена' : '+ Промпт'}
          </button>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Проверенные формулировки, которые надёжно решают задачи. «Использовать» копирует текст в
          буфер и отмечает применение.
        </p>

        {showForm && (
          <div className="border border-border rounded-xl p-4 mb-4 bg-card space-y-2">
            {editingId && (
              <div className="text-xs font-semibold text-[#21a038]">Изменение промпта</div>
            )}
            <input
              value={title}
              maxLength={255}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Название (например: Извлечение сумм из УПД)"
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background"
            />
            <input
              value={description}
              maxLength={1024}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Для какой задачи и в чём особенность (опционально)"
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background"
            />
            <input
              value={model}
              maxLength={64}
              onChange={(e) => setModel(e.target.value)}
              list="prompt-model-suggestions"
              placeholder="Модель, на которой промпт проверен (пусто — любая)"
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background"
            />
            <datalist id="prompt-model-suggestions">
              {MODELS.map((m) => (
                <option key={m} value={m} />
              ))}
            </datalist>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Текст промпта"
              rows={6}
              className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background font-mono"
            />
            <button
              onClick={() => saveMut.mutate()}
              disabled={saveMut.isPending || !title.trim() || !text.trim()}
              className="text-sm px-3 py-1.5 rounded-lg bg-[#21a038] text-white disabled:opacity-50"
            >
              {editingId ? 'Сохранить изменения' : 'Сохранить'}
            </button>
          </div>
        )}

        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Поиск по названию, описанию, модели и тексту…"
          className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background mb-4"
        />

        <div className="space-y-3">
          {visible.map((p: Prompt) => (
            <div key={p.id} className="border border-border rounded-xl p-4 bg-card">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-foreground">
                    {p.title}
                    {p.is_owner && (
                      <span className="ml-2 text-[10px] font-normal text-[#21a038] border border-[#21a038]/40 rounded px-1">
                        мой
                      </span>
                    )}
                    {p.model && (
                      <span
                        title="Модель, на которой промпт проверен"
                        className="ml-2 text-[10px] font-normal text-sky-600 border border-sky-500/40 rounded px-1"
                      >
                        {p.model}
                      </span>
                    )}
                  </div>
                  {p.description && (
                    <div className="text-xs text-muted-foreground mt-0.5">{p.description}</div>
                  )}
                </div>
                <div className="flex items-center gap-2 flex-shrink-0 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => rateMut.mutate({ id: p.id, rating: star })}
                        className={`text-sm leading-none ${
                          (p.rating_avg ?? 0) >= star - 0.25
                            ? 'text-yellow-500'
                            : 'text-muted-foreground/40'
                        } hover:scale-125 transition-transform`}
                        title={p.my_rating ? `Ваша оценка: ${p.my_rating}` : 'Оценить'}
                      >
                        ★
                      </button>
                    ))}
                  </span>
                  <span>
                    {p.rating_avg != null ? p.rating_avg.toFixed(1) : '—'} ({p.rating_count})
                    {p.my_rating != null && (
                      <span className="text-[#21a038]">{` · ваша: ${p.my_rating}`}</span>
                    )}
                  </span>
                  <span title="Использований">⚡ {p.usage_count}</span>
                </div>
              </div>
              <pre className="text-xs text-foreground/80 bg-accent/40 rounded-lg p-3 mt-2 whitespace-pre-wrap max-h-40 overflow-y-auto">
                {p.text}
              </pre>
              <div className="flex items-center gap-3 mt-2 text-xs">
                <button
                  onClick={() => useMut.mutate(p.id)}
                  className="text-[#21a038] hover:underline"
                >
                  {copiedId === p.id ? '✓ Скопировано' : 'Использовать (копировать)'}
                </button>
                {p.is_owner && (
                  <>
                    <button onClick={() => startEdit(p)} className="hover:underline">
                      Изменить
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Удалить промпт «${p.title}»?`)) deleteMut.mutate(p.id);
                      }}
                      className="text-red-500/80 hover:underline"
                    >
                      Удалить
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
          {visible.length === 0 && (
            <div className="text-sm text-muted-foreground text-center py-8">
              {query ? 'Ничего не найдено' : 'Промптов пока нет — добавьте первый'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
