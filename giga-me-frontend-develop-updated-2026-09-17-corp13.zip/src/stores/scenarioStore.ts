import { create } from 'zustand';
import {
  type Node,
  type Edge,
  type OnNodesChange,
  type OnEdgesChange,
  type OnConnect,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
} from '@xyflow/react';

export type ExecStatus = 'pending' | 'running' | 'completed' | 'failed' | 'skipped' | 'paused';

interface ScenarioState {
  nodes: Node[];
  edges: Edge[];
  selectedNodeId: string | null;
  selectedEdgeId: string | null;
  /** Execution status per node ID, updated live by ScenarioRunner */
  execStatuses: Record<string, ExecStatus>;
  setNodes: (nodes: Node[]) => void;
  setEdges: (edges: Edge[]) => void;
  onNodesChange: OnNodesChange;
  onEdgesChange: OnEdgesChange;
  onConnect: OnConnect;
  selectNode: (id: string | null) => void;
  selectEdge: (id: string | null) => void;
  addNode: (node: Node) => void;
  updateNodeData: (id: string, data: Record<string, string>) => void;
  updateEdgeData: (id: string, data: Record<string, string>) => void;
  deleteNode: (id: string) => void;
  deleteEdge: (id: string) => void;
  setExecStatus: (nodeId: string, status: ExecStatus) => void;
  resetExecStatuses: () => void;
  /** Несохранённые правки редактора: подтверждение при уходе со страницы */
  editorDirty: boolean;
  setEditorDirty: (dirty: boolean) => void;
  /** Выделить нарушителя проверки графа: рамка на канвасе и панель настройки */
  focusElement: (nodeId?: string, edgeId?: string) => void;
}

export const useScenarioStore = create<ScenarioState>((set, get) => ({
  nodes: [],
  edges: [],
  selectedNodeId: null,
  selectedEdgeId: null,
  execStatuses: {},

  setNodes: (nodes) => set({ nodes }),
  setEdges: (edges) => set({ edges }),

  onNodesChange: (changes) =>
    set({ nodes: applyNodeChanges(changes, get().nodes) }),

  onEdgesChange: (changes) =>
    set({ edges: applyEdgeChanges(changes, get().edges) }),

  onConnect: (connection) =>
    set({ edges: addEdge(connection, get().edges) }),

  selectNode: (id) =>
    set({ selectedNodeId: id, selectedEdgeId: null }),

  selectEdge: (id) =>
    set({ selectedEdgeId: id, selectedNodeId: null }),

  addNode: (node) => set({ nodes: [...get().nodes, node] }),

  updateNodeData: (id, data) =>
    set({
      nodes: get().nodes.map((n) =>
        n.id === id ? { ...n, data: { ...n.data, ...data } } : n,
      ),
    }),

  updateEdgeData: (id, data) =>
    set({
      edges: get().edges.map((e) =>
        e.id === id ? { ...e, data: { ...e.data, ...data } } : e,
      ),
    }),

  deleteNode: (id) =>
    set({
      nodes: get().nodes.filter((n) => n.id !== id),
      edges: get().edges.filter((e) => e.source !== id && e.target !== id),
      selectedNodeId: get().selectedNodeId === id ? null : get().selectedNodeId,
    }),

  deleteEdge: (id) =>
    set({
      edges: get().edges.filter((e) => e.id !== id),
      selectedEdgeId: get().selectedEdgeId === id ? null : get().selectedEdgeId,
    }),

  setExecStatus: (nodeId, status) =>
    set({ execStatuses: { ...get().execStatuses, [nodeId]: status } }),

  resetExecStatuses: () => set({ execStatuses: {} }),

  editorDirty: false,
  setEditorDirty: (dirty) => {
    if (get().editorDirty !== dirty) set({ editorDirty: dirty });
  },

  focusElement: (nodeId, edgeId) =>
    set({
      nodes: get().nodes.map((n) => ({ ...n, selected: n.id === nodeId })),
      edges: get().edges.map((e) => ({ ...e, selected: e.id === edgeId })),
      selectedNodeId: nodeId ?? null,
      selectedEdgeId: edgeId ?? null,
    }),
}));

/**
 * Уход из редактора с несохранёнными правками — только после подтверждения
 * (BrowserRouter без data router: useBlocker недоступен, поэтому проверка
 * вызывается перед navigate в сайдбаре и кнопках редактора).
 */
export function confirmLeaveEditor(): boolean {
  if (!useScenarioStore.getState().editorDirty) return true;
  return window.confirm('Есть несохранённые изменения сценария. Уйти без сохранения?');
}
