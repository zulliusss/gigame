// Проверки runScenario (src/api/scenarios.ts) целиком: обрыв сокета, слежение по REST,
// гонки и жизненный цикл. Поддельные WebSocket/fetch и mock-часы (tests/runScenarioHarness.mjs),
// модель раннера повторяет ветки ScenarioRunner.tsx.
// Запуск из корня фронта: node --test tests/runScenario.test.mjs (node >= 22.18 / 23.6)

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';

import {
  FakeWS,
  advance,
  consume,
  flush,
  installFetch,
  installGlobals,
  makeRunnerModel,
} from './runScenarioHarness.mjs';

installGlobals();

const { runScenario } = await import('../src/api/scenarios.ts');
const runEvents = await import('../src/api/runEvents.ts');
const polling = await import('../src/api/runPolling.ts');

const { CONNECTION_LOST_TYPE, runEventError, terminalRunStatus } = runEvents;
const {
  RUN_NOT_FOUND_MESSAGE,
  RUN_PICK_AMBIGUOUS_MESSAGE,
  RUN_POLL_NOTICE_TYPE,
  RUN_POLL_SILENT_SOCKET_MESSAGE,
  RUN_POLL_STEP_MODE_MESSAGE,
  RUN_POLL_NETWORK_REASON,
  runPollGaveUpMessage,
} = polling;

const SCENARIO = 'a3c32c70-47b0-42cf-823a-03a92c63b196';
const RUN = '8373366a-7835-43d2-a541-c2402cbbdfdb';
const PREV = '11111111-1111-4111-8111-111111111111';
const OTHER = '22222222-2222-4222-8222-222222222222';
const T0 = Date.parse('2026-09-17T10:27:48.000Z');

const iso = (ms) => new Date(ms).toISOString().replace('Z', '123Z');
const GRAPH = [
  { id: 'v0', type: 'input', data: { label: 'Вход' } },
  { id: 'a1', type: 'processing', data: { label: 'Агент' } },
  { id: 'v7', type: 'output', data: { label: 'Выход', mode: 'excel' } },
];
const step = (id, nodeId, status, extra = {}) => ({
  id,
  node_id: nodeId,
  node_type: { v0: 'input', a1: 'processing', v7: 'output' }[nodeId],
  status,
  ...extra,
});
const ok = (body) => ({ status: 200, body });
const newModel = () => makeRunnerModel({ runEventError, terminalRunStatus, CONNECTION_LOST_TYPE, RUN_POLL_NOTICE_TYPE });
const SCN = `/scenarios/${SCENARIO}`;
const RUNS = `/scenarios/${SCENARIO}/runs`;
const detailPath = (id) => `/scenarios/runs/${id}`;
const graphRoute = () => ok({ id: SCENARIO, graph_data: { nodes: GRAPH, edges: [] } });
const count = (calls, path) => calls.filter((c) => c.path === path).length;

/** Поток прогона завершился за прокрученное mock-время: иначе проверка падает, а не зависает. */
async function ended(consumer) {
  await flush(30);
  assert.ok(consumer.done, 'поток событий прогона завершился');
  await consumer.promise;
}

/** Запуск: сокет открыт, команда run ушла. */
async function start(t, { stepMode = false, routes = {} } = {}) {
  t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: T0 });
  FakeWS.instances = [];
  const calls = installFetch(routes);
  const controller = new AbortController();
  const model = newModel();
  const consumer = consume(runScenario(SCENARIO, [], stepMode, controller.signal), model, controller.signal);
  await advance(t.mock.timers, 60, 10);
  const ws = FakeWS.instances[0];
  assert.ok(ws, 'сокет создан');
  assert.equal(ws.sent.length, 1, 'команда run отправлена');
  return { calls, controller, model, consumer, ws, sentAt: Date.now() };
}

describe('гонки сокета и опроса', () => {
  test('терминальный STATUS пришёл одновременно с обрывом — один итог, опроса нет', async (t) => {
    const { calls, model, consumer, ws } = await start(t);
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED', result: 'итог' } });
    ws.proxyDrop();
    await advance(t.mock.timers, 120_000, 500);
    await ended(consumer);
    assert.equal(consumer.error, null);
    assert.equal(model.ui.terminal, 1);
    assert.equal(model.ui.phase, 'done');
    assert.equal(calls.length, 0, 'REST не опрашивается');
    assert.equal(FakeWS.instances.length, 1);
  });

  test('обрыв после run_id — одна команда run, сокет не переоткрыт, итог по REST, опрос прекращён', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: (n) => ok([{ id: RUN, status: n < 2 ? 'running' : 'completed', started_at: iso(T0) }]),
        [detailPath(RUN)]: (n) =>
          ok(
            n === 0
              ? { id: RUN, status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'running')] }
              : {
                  id: RUN,
                  status: 'completed',
                  result: 'итог',
                  steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed'), step('s2', 'v7', 'completed')],
                },
          ),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.serverFrame({ type: 'NODE_STATUS', data: { node_id: 'v0', node_label: 'Вход', status: 'RUNNING', step: 1, total: 3 } });
    ws.serverFrame({ type: 'NODE_STATUS', data: { node_id: 'v0', node_label: 'Вход', status: 'COMPLETED', step: 1, total: 3 } });
    ws.serverFrame({ type: 'STEP_COMPLETE', data: { node_id: 'v0', step_id: 's0' } });
    ws.serverFrame({ type: 'NODE_STATUS', data: { node_id: 'a1', node_label: 'Агент', status: 'RUNNING', step: 2, total: 3 } });
    ws.proxyDrop();
    await advance(t.mock.timers, 60_000, 500);
    await ended(consumer);
    assert.equal(consumer.error, null);
    assert.equal(model.ui.phase, 'done');
    assert.equal(model.ui.terminal, 1);
    assert.deepEqual([...model.ui.exec.entries()], [['v0', 'completed'], ['a1', 'completed'], ['v7', 'completed']]);
    assert.deepEqual(model.ui.history, ['s0', 's1', 's2'], 'шаги не задвоены');
    assert.deepEqual(model.ui.files, ['v7']);
    assert.equal(FakeWS.instances.length, 1, 'сокет не переоткрыт');
    assert.equal(ws.sent.length, 1, 'run не повторён');
    const before = calls.length;
    await advance(t.mock.timers, 10 * 60_000, 1000);
    assert.equal(calls.length, before, 'после итога запросов нет');
  });

  test('закрытие панели во время паузы опроса — ни одного запроса после abort', async (t) => {
    const { calls, controller, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ok([{ id: RUN, status: 'running', started_at: iso(T0) }]),
        [detailPath(RUN)]: () => ok({ id: RUN, status: 'running', steps: [step('s1', 'a1', 'running')] }),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.proxyDrop();
    await advance(t.mock.timers, 25_000, 500);
    const before = calls.length;
    assert.ok(before >= 4);
    controller.abort();
    await flush(30);
    await advance(t.mock.timers, 30 * 60_000, 5000);
    await ended(consumer);
    assert.equal(calls.length, before, 'таймер опроса не пережил abort');
    assert.ok(consumer.done);
  });

  test('закрытие панели во время медленного запроса деталей — без строки о сбое, без повторов', async (t) => {
    const { calls, controller, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ok([{ id: RUN, status: 'running', started_at: iso(T0) }]),
        // тяжёлый ответ идёт 20 с
        [detailPath(RUN)]: () => new Promise((resolve) => setTimeout(() => resolve(ok({ id: RUN, status: 'completed', steps: [] })), 20_000)),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.proxyDrop();
    await advance(t.mock.timers, 3_000, 100);
    assert.equal(count(calls, detailPath(RUN)), 1);
    controller.abort();
    await flush(30);
    await advance(t.mock.timers, 10 * 60_000, 5000);
    await ended(consumer);
    assert.equal(consumer.error?.name, 'AbortError');
    assert.equal(model.ui.log.filter((l) => l.includes('Сбой')).length, 0);
    assert.equal(model.ui.terminal, 0, 'итог после закрытия не применён');
    assert.equal(calls.length, 3);
  });

  test('потребитель прекратил чтение (return) — генератор не опрашивает дальше', async (t) => {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: T0 });
    FakeWS.instances = [];
    const calls = installFetch({
      [SCN]: graphRoute,
      [RUNS]: () => ok([{ id: RUN, status: 'running', started_at: iso(T0) }]),
      [detailPath(RUN)]: () => ok({ id: RUN, status: 'running', steps: [step('s1', 'a1', 'running')] }),
    });
    const gen = runScenario(SCENARIO, [], false, new AbortController().signal);
    const first = gen.next();
    await advance(t.mock.timers, 60, 10);
    const ws = FakeWS.instances[0];
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    await advance(t.mock.timers, 30, 10);
    assert.equal((await first).value.type, 'STATUS');
    ws.proxyDrop();
    const second = gen.next();
    await advance(t.mock.timers, 2_000, 100);
    assert.equal((await second).value.type, RUN_POLL_NOTICE_TYPE);
    await gen.return(undefined);
    const before = calls.length;
    await advance(t.mock.timers, 5 * 60_000, 1000);
    assert.equal(calls.length, before);
  });

  test('обрыв во время загрузки (до run) и второй обрыв после run — одна команда run на все сокеты, после run сокет не переоткрыт', async (t) => {
    t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: T0 });
    FakeWS.instances = [];
    const calls = installFetch({
      [`/scenarios/${SCENARIO}/upload`]: () => ok({ status: 'accepted' }),
      [`/scenarios/${SCENARIO}/upload-status`]: (n) =>
        ok(n < 3 ? { status: 'processing', files: 1, documents: 0 } : { status: 'done', files: 1, documents: 1 }),
      [SCN]: graphRoute,
      [RUNS]: () => ok([{ id: RUN, status: 'completed', started_at: iso(T0) }]),
      [detailPath(RUN)]: () => ok({ id: RUN, status: 'completed', result: 'итог', steps: [step('s2', 'v7', 'completed')] }),
    });
    const controller = new AbortController();
    const model = newModel();
    const file = new File(['документ'], 'doc.txt', { type: 'text/plain' });
    const consumer = consume(runScenario(SCENARIO, [file], false, controller.signal), model, controller.signal);
    await advance(t.mock.timers, 100, 10);
    const ws1 = FakeWS.instances[0];
    ws1.proxyDrop(); // прокси закрыл сокет, пока идёт разбор загрузки
    await advance(t.mock.timers, 12_000, 50);
    const ws2 = FakeWS.instances[1];
    assert.ok(ws2, 'перед run сокет переоткрыт');
    assert.equal(ws1.sent.length, 0);
    assert.equal(ws2.sent.length, 1);
    ws2.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws2.proxyDrop();
    await advance(t.mock.timers, 30_000, 500);
    await ended(consumer);
    assert.equal(consumer.error, null);
    assert.equal(model.ui.phase, 'done');
    assert.equal(FakeWS.instances.length, 2, 'после команды run сокет не переоткрывался');
    assert.equal(FakeWS.instances.reduce((n, ws) => n + ws.sent.length, 0), 1, 'команда run ушла один раз');
    assert.ok(calls.some((c) => c.path === RUNS));
  });

  test('401 бэкенда на опросе — CONNECTION_LOST с причиной, дальше запросов нет', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ({ status: 401, body: { message: 'Сессия истекла' } }),
        [detailPath(RUN)]: () => ({ status: 401, body: { message: 'Сессия истекла' } }),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.proxyDrop();
    await advance(t.mock.timers, 30_000, 500);
    await ended(consumer);
    assert.equal(model.ui.phase, 'error');
    assert.match(model.ui.errorText, /Сессия истекла/);
    const before = calls.length;
    await advance(t.mock.timers, 10 * 60_000, 5000);
    assert.equal(calls.length, before);
  });
});

describe('пошаговый режим после обрыва: сервер (cleanupRun) снимает паузу и режим', () => {
  test('«⏸ Пауза» снимается сразу после обрыва, бейдж узла — его статус; детали не на каждом опросе', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      stepMode: true,
      routes: {
        [SCN]: graphRoute,
        [RUNS]: (n) => ok([{ id: RUN, status: n < 30 ? 'running' : 'completed', started_at: iso(T0) }]),
        // сервер после cleanupRun: пауза отпущена сразу, агент идёт 5 минут, затем выход и итог
        [detailPath(RUN)]: () => {
          const t1 = Date.now() - T0;
          return ok(
            t1 < 150_000
              ? { id: RUN, status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'running')] }
              : t1 < 300_000
                ? { id: RUN, status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed'), step('s2', 'v7', 'running')] }
                : {
                    id: RUN,
                    status: 'completed',
                    result: 'итог',
                    steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed'), step('s2', 'v7', 'completed')],
                  },
          );
        },
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.serverFrame({ type: 'NODE_STATUS', data: { node_id: 'v0', node_label: 'Вход', status: 'RUNNING', step: 1, total: 3 } });
    ws.serverFrame({ type: 'NODE_STATUS', data: { node_id: 'v0', node_label: 'Вход', status: 'COMPLETED', step: 1, total: 3 } });
    ws.serverFrame({ type: 'STEP_COMPLETE', data: { node_id: 'v0', step_id: 's0' } });
    ws.serverFrame({ type: 'STEP_PAUSED', data: { node_id: 'v0', node_label: 'Вход', node_type: 'input', total_steps: 3 } });
    await advance(t.mock.timers, 100, 10);
    assert.equal(model.ui.phase, 'paused');
    assert.equal(model.ui.exec.get('v0'), 'paused');

    // прокси рвёт сокет, пока пользователь смотрит на паузу
    ws.proxyDrop();
    await advance(t.mock.timers, 2_000, 100);
    assert.equal(model.ui.phase, 'running', 'кнопки «Далее/До конца» скрыты');
    assert.equal(model.ui.exec.get('v0'), 'completed');
    assert.ok(model.ui.log.includes(`🔌 ${RUN_POLL_STEP_MODE_MESSAGE}`));

    await advance(t.mock.timers, 6 * 60_000, 1000);
    await ended(consumer);
    assert.deepEqual(model.ui.phases.slice(model.ui.phases.indexOf('paused')), ['paused', 'running', 'done']);
    assert.deepEqual([...model.ui.exec.entries()], [['v0', 'completed'], ['a1', 'completed'], ['v7', 'completed']]);
    const lists = count(calls, RUNS);
    const details = count(calls, detailPath(RUN));
    assert.ok(lists >= 30);
    assert.ok(details <= lists / 3 + 1, `детали ${details} на ${lists} опросов списка`);
    assert.equal(consumer.events.filter((e) => e.type === 'STEP_PAUSED').length, 1, 'только пауза сокета');
  });
});

describe('поиск прогона, если run_id не пришёл до обрыва', () => {
  test('команда run не дошла (обрыв в полёте), в списке прошлый прогон минуту назад — не выдаётся за свой', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ok([{ id: PREV, status: 'completed', started_at: iso(T0 - 60_000) }]),
        [detailPath(PREV)]: () => ok({ id: PREV, status: 'completed', result: 'итог ПРЕДЫДУЩЕГО прогона', steps: [] }),
      },
    });
    ws.proxyDrop(); // STATUS с run_id не успел прийти
    await advance(t.mock.timers, 60_000, 500);
    await ended(consumer);
    assert.equal(model.ui.runId, null);
    assert.equal(model.ui.phase, 'error');
    assert.equal(model.ui.errorText, RUN_NOT_FOUND_MESSAGE);
    assert.equal(model.ui.result, null);
    assert.equal(count(calls, detailPath(PREV)), 0);
  });

  test('два прогона после отправки run (свой и другой вкладки) — не угадывать, чужой прогон крестиком не остановить', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        // первый запрос списка сразу после обрыва упал на шлюзе; к повтору в списке оба прогона
        [RUNS]: (n) =>
          n === 0
            ? { status: 502, body: '<html>Bad Gateway</html>' }
            : ok([
                { id: OTHER, status: 'running', started_at: iso(T0 + 5_000) },
                { id: RUN, status: 'running', started_at: iso(T0 + 300) },
              ]),
      },
    });
    ws.proxyDrop();
    await advance(t.mock.timers, 60_000, 500);
    await ended(consumer);
    assert.equal(model.ui.runId, null);
    assert.equal(model.ui.phase, 'error');
    assert.equal(model.ui.errorText, RUN_PICK_AMBIGUOUS_MESSAGE);
    assert.ok(!calls.some((c) => c.path.startsWith('/scenarios/runs/')));
  });

  test('run_id не пришёл, список недоступен (сеть) — не дольше ~3 мин, затем CONNECTION_LOST с причиной по-русски', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => new TypeError('Failed to fetch'),
      },
    });
    ws.proxyDrop();
    await advance(t.mock.timers, 5 * 60_000, 1000);
    await ended(consumer);
    assert.equal(model.ui.phase, 'error');
    assert.equal(model.ui.errorText, runPollGaveUpMessage(RUN_POLL_NETWORK_REASON, null));
    const lastCall = calls.at(-1).at - T0;
    assert.ok(lastCall <= 4 * 60_000, String(lastCall));
    const before = calls.length;
    await advance(t.mock.timers, 30 * 60_000, 10_000);
    assert.equal(calls.length, before);
  });
});

describe('прогон-сирота и необязательные запросы', () => {
  test('прогон running без шагов (поток не подписан) — через 5 мин строка в журнал, крестик может остановить (run_id есть)', async (t) => {
    const { model, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ok([{ id: RUN, status: 'running', started_at: iso(T0 + 50) }]),
        [detailPath(RUN)]: () => ok({ id: RUN, status: 'running', steps: [] }),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.proxyDrop();
    await advance(t.mock.timers, 8 * 60_000, 5000);
    assert.equal(model.ui.phase, 'running');
    assert.equal(model.ui.runId, RUN);
    assert.equal(model.ui.log.filter((l) => l.includes('не начал ни одного узла')).length, 1);
    t.mock.timers.reset();
  });

  test('run_id известен, список прогонов стабильно не проходит (5xx/HTML шлюза) — итог из деталей', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ({ status: 502, body: '<html>Bad Gateway</html>' }),
        [detailPath(RUN)]: () => ok({ id: RUN, status: 'completed', result: 'итог', steps: [step('s2', 'v7', 'completed')] }),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.proxyDrop();
    await advance(t.mock.timers, 5_000, 500);
    await ended(consumer);
    assert.equal(model.ui.phase, 'done');
    assert.equal(model.ui.result, 'итог');
    assert.equal(count(calls, detailPath(RUN)), 1);
  });

  test('GET /scenarios/{id} 403 (владелец снял «общий») — итог своего прогона показан', async (t) => {
    const { model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: () => ({ status: 403, body: { message: 'illegal userId' } }),
        [RUNS]: () => ok([{ id: RUN, status: 'completed', started_at: iso(T0) }]),
        [detailPath(RUN)]: () => ok({ id: RUN, status: 'completed', result: 'итог', steps: [step('s2', 'v7', 'completed')] }),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.proxyDrop();
    await advance(t.mock.timers, 5_000, 500);
    await ended(consumer);
    assert.equal(model.ui.phase, 'done');
    assert.equal(model.ui.result, 'итог');
    assert.ok(model.ui.log.some((l) => l.includes('Граф сценария не загрузился (illegal userId)')));
  });
});

describe('полуоткрытый сокет (обрыв без события close)', () => {
  test('3 мин тишины, прогон на сервере завершён — сокет закрывается, итог по REST, run не повторён', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ok([{ id: RUN, status: 'completed', started_at: iso(T0) }]),
        [detailPath(RUN)]: () => ok({ id: RUN, status: 'completed', result: 'итог', steps: [step('s2', 'v7', 'completed')] }),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    // кадров больше нет, onclose не приходит
    await advance(t.mock.timers, 2 * 60_000, 5000);
    assert.equal(calls.length, 0, 'до 3 мин тишины — без запросов');
    await advance(t.mock.timers, 2 * 60_000, 1000);
    await ended(consumer);
    assert.equal(model.ui.phase, 'done');
    assert.equal(model.ui.result, 'итог');
    assert.ok(model.ui.log.includes(`🔌 ${RUN_POLL_SILENT_SOCKET_MESSAGE}`));
    assert.equal(ws.readyState, FakeWS.CLOSED, 'сокет закрыт');
    assert.equal(FakeWS.instances.length, 1);
    assert.equal(ws.sent.length, 1);
  });

  test('пошаговый режим, сокет замолчал после паузы, прогон завершён — без строки о снятой паузе, итог по REST', async (t) => {
    const { model, consumer, ws } = await start(t, {
      stepMode: true,
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ok([{ id: RUN, status: 'failed', started_at: iso(T0) }]),
        [detailPath(RUN)]: () => ok({ id: RUN, status: 'failed', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'failed', { output_data: { error: 'Пауза шага истекла' } })] }),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    ws.serverFrame({ type: 'NODE_STATUS', data: { node_id: 'v0', node_label: 'Вход', status: 'COMPLETED', step: 1, total: 3 } });
    ws.serverFrame({ type: 'STEP_COMPLETE', data: { node_id: 'v0', step_id: 's0' } });
    ws.serverFrame({ type: 'STEP_PAUSED', data: { node_id: 'v0', node_label: 'Вход' } });
    await advance(t.mock.timers, 4 * 60_000, 1000);
    await ended(consumer);
    assert.equal(model.ui.phase, 'error');
    assert.equal(model.ui.errorText, null);
    assert.equal(model.ui.exec.get('a1'), 'failed');
    assert.ok(!model.ui.log.some((l) => l.includes(RUN_POLL_STEP_MODE_MESSAGE)));
    assert.ok(model.ui.log.includes(`🔌 ${RUN_POLL_SILENT_SOCKET_MESSAGE}`));
  });

  test('сокет молчит, но прогон ещё идёт — проверка списком раз в 3 мин, детали не запрашиваются, сокет не закрыт', async (t) => {
    const { calls, model, consumer, ws } = await start(t, {
      routes: {
        [SCN]: graphRoute,
        [RUNS]: () => ok([{ id: RUN, status: 'running', started_at: iso(T0) }]),
      },
    });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    await advance(t.mock.timers, 10 * 60_000, 5000);
    assert.equal(consumer.done, false);
    assert.equal(model.ui.phase, 'running');
    const lists = count(calls, RUNS);
    assert.ok(lists >= 2 && lists <= 3, String(lists));
    assert.equal(calls.length, lists, 'только лёгкий список');
    // кадр пришёл — сокет живой, итог по сокету как обычно
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED', result: 'итог' } });
    await advance(t.mock.timers, 1_000, 100);
    await ended(consumer);
    assert.equal(model.ui.phase, 'done');
    assert.equal(model.ui.terminal, 1);
  });

  test('живой сокет с кадрами — ни одного REST-запроса', async (t) => {
    const { calls, model, consumer, ws } = await start(t, { routes: { [RUNS]: () => ok([]) } });
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    for (let i = 0; i < 12; i++) {
      await advance(t.mock.timers, 60_000, 5000);
      ws.serverFrame({ type: 'PROCESSING_PROGRESS', data: { run_id: RUN, node_id: 'a1', detail: `шаг ${i}` } });
    }
    ws.serverFrame({ type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED' } });
    await advance(t.mock.timers, 1_000, 100);
    await ended(consumer);
    assert.equal(model.ui.phase, 'done');
    assert.equal(calls.length, 0);
  });
});
