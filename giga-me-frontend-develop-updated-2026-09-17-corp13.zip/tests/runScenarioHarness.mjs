// Обвязка для проверки runScenario (src/api/scenarios.ts) в node: поддельные WebSocket,
// fetch и часы (node:test mock.timers). Используется tests/runScenario.test.mjs.

import { registerHooks } from 'node:module';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

// импорты без расширения внутри src/api ('./client', './runEvents') → .ts
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (
      (specifier.startsWith('./') || specifier.startsWith('../')) &&
      !/\.[a-z]+$/i.test(specifier) &&
      context.parentURL &&
      context.parentURL.includes('/src/')
    ) {
      const url = new URL(specifier + '.ts', context.parentURL);
      if (existsSync(fileURLToPath(url))) return nextResolve(url.href, context);
    }
    return nextResolve(specifier, context);
  },
});

export const realSetImmediate = setImmediate;

/** Поддельный WebSocket: open — асинхронно (реальный setImmediate), close — тоже. */
export class FakeWS {
  static CONNECTING = 0;
  static OPEN = 1;
  static CLOSING = 2;
  static CLOSED = 3;
  static instances = [];

  constructor(url) {
    this.url = url;
    this.readyState = FakeWS.CONNECTING;
    this.sent = [];
    this.onopen = null;
    this.onmessage = null;
    this.onclose = null;
    this.onerror = null;
    FakeWS.instances.push(this);
    realSetImmediate(() => {
      if (this.readyState !== FakeWS.CONNECTING) return;
      this.readyState = FakeWS.OPEN;
      this.onopen?.({});
    });
  }

  send(data) {
    if (this.readyState !== FakeWS.OPEN) throw new Error('send on non-open socket');
    this.sent.push(JSON.parse(data));
  }

  close() {
    if (this.readyState >= FakeWS.CLOSING) return;
    this.readyState = FakeWS.CLOSING;
    realSetImmediate(() => {
      this.readyState = FakeWS.CLOSED;
      this.onclose?.({ code: 1000 });
    });
  }

  /** Кадр от сервера. */
  serverFrame(obj) {
    this.onmessage?.({ data: JSON.stringify(obj) });
  }

  /** Прокси закрыл соединение (без close-кадра). */
  proxyDrop() {
    this.readyState = FakeWS.CLOSED;
    this.onclose?.({ code: 1006 });
  }
}

export function installGlobals() {
  globalThis.WebSocket = FakeWS;
  globalThis.window = { location: { protocol: 'http:', host: 'localhost' } };
  // консоль реализации не засоряет вывод теста
  console.log = () => {};
  console.error = () => {};
}

export const BASE = '/proto/backend/giga-me/api';

/**
 * Поддельный fetch: routes — путь API (без BASE) → функция (n, opts) → {status, body} | Error.
 * Все вызовы пишутся в calls (путь и время по mock-часам).
 */
export function installFetch(routes) {
  const calls = [];
  globalThis.fetch = async (url, opts = {}) => {
    const path = String(url).replace(BASE, '');
    const base = path.split('?')[0];
    calls.push({ path: base, method: opts.method ?? 'GET', at: Date.now(), aborted: !!opts.signal?.aborted });
    if (opts.signal?.aborted) {
      throw new DOMException('The user aborted a request.', 'AbortError');
    }
    const route = routes[base];
    if (!route) {
      return fakeResponse(404, JSON.stringify({ message: `нет маршрута ${base}` }));
    }
    const n = calls.filter((c) => c.path === base).length - 1;
    let answer = route(n, opts);
    if (answer && typeof answer.then === 'function') {
      // медленный ответ: прерывается сигналом, как настоящий fetch
      answer = await new Promise((resolve, reject) => {
        opts.signal?.addEventListener('abort', () => reject(new DOMException('The user aborted a request.', 'AbortError')), {
          once: true,
        });
        answer.then(resolve, reject);
      });
    }
    if (answer instanceof Error) throw answer;
    return fakeResponse(answer.status ?? 200, typeof answer.body === 'string' ? answer.body : JSON.stringify(answer.body));
  };
  return calls;
}

function fakeResponse(status, body) {
  return {
    ok: status >= 200 && status < 300,
    status,
    statusText: '',
    text: async () => body,
    json: async () => JSON.parse(body),
    blob: async () => body,
    clone() {
      return fakeResponse(status, body);
    },
  };
}

/** Прогон микрозадач и реальных setImmediate (fetch/ws-заглушки). */
export async function flush(rounds = 12) {
  for (let i = 0; i < rounds; i++) {
    await new Promise((r) => realSetImmediate(r));
  }
}

/** Сдвиг mock-часов шагами с прокачкой промисов между шагами. */
export async function advance(mockTimers, ms, step = 10) {
  let left = ms;
  while (left > 0) {
    const d = Math.min(step, left);
    mockTimers.tick(d);
    left -= d;
    await flush(4);
  }
}

/**
 * Модель переходов ScenarioRunner.tsx (ветки цикла for await): фаза, runId, бейджи,
 * журнал, итог, файлы, история шагов, число терминальных кадров.
 */
export function makeRunnerModel({ runEventError, terminalRunStatus, CONNECTION_LOST_TYPE, RUN_POLL_NOTICE_TYPE }) {
  const ui = {
    phase: 'running',
    runId: null,
    errorText: null,
    log: [],
    exec: new Map(),
    result: null,
    files: [],
    history: [],
    terminal: 0,
    phases: [],
  };
  const setPhase = (p) => {
    ui.phase = p;
    ui.phases.push(p);
  };
  function apply(ev) {
    const data = ev.data ?? {};
    const commandError = runEventError(ev);
    if (commandError) {
      ui.terminal++;
      setPhase('error');
      ui.errorText = commandError;
      return;
    }
    if (ev.type === RUN_POLL_NOTICE_TYPE) {
      ui.log.push(`🔌 ${String(data.message ?? '')}`);
      if (data.step_mode_off) {
        if (ui.phase === 'paused') setPhase('running');
        if (data.node_id && data.status) ui.exec.set(data.node_id, data.status);
      }
      return;
    }
    if (ev.type === CONNECTION_LOST_TYPE) {
      ui.terminal++;
      if (data.run_id) ui.runId = data.run_id;
      setPhase('error');
      ui.errorText = String(ev.error ?? 'Соединение потеряно');
      return;
    }
    if (ev.type === 'STATUS') {
      if (data.run_id) ui.runId = data.run_id;
      const s = terminalRunStatus(ev);
      if (s === 'COMPLETED') {
        ui.terminal++;
        setPhase('done');
        if (data.result) ui.result = data.result;
      } else if (s === 'FAILED') {
        ui.terminal++;
        setPhase('error');
        if (data.result) ui.result = data.result;
        if (data.error) ui.errorText = data.error;
      }
    }
    if (ev.type === 'NODE_STATUS') {
      ui.exec.set(data.node_id, String(data.status).toLowerCase());
      ui.log.push(`${String(data.status)} ${data.node_label}`);
    }
    if (ev.type === 'STEP_COMPLETE') ui.history.push(data.step_id);
    if (ev.type === 'STEP_PAUSED') {
      setPhase('paused');
      ui.exec.set(data.node_id, 'paused');
    }
    if (ev.type === 'FILE_OUTPUT') ui.files.push(data.node_id);
  }
  return { ui, apply, setPhase };
}

/** Потребитель генератора как в ScenarioRunner: break при прерывании. */
export function consume(generator, model, signal) {
  const events = [];
  const state = { done: false, error: null, events };
  state.promise = (async () => {
    try {
      for await (const ev of generator) {
        if (signal?.aborted) break;
        events.push(ev);
        model?.apply(ev);
      }
    } catch (e) {
      state.error = e;
    } finally {
      state.done = true;
    }
  })();
  return state;
}
