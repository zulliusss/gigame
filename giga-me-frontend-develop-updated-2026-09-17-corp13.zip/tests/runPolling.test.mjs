// Проверки слежения за прогоном по REST после обрыва WebSocket (src/api/runPolling.ts).
// Без тест-раннера и зависимостей: node >= 22.18 / 23.6 снимает типы с .ts сам.
// Запуск из корня фронта: node --test tests/runPolling.test.mjs

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';

import {
  RUN_FAILED_WITHOUT_NODE_ERROR,
  RUN_NOT_FOUND_MESSAGE,
  RUN_NO_STEPS_NOTICE_MS,
  RUN_PICK_AMBIGUOUS_MESSAGE,
  RUN_PICK_ATTEMPTS,
  RUN_PICK_MAX_MS,
  RUN_POLL_DETAIL_INTERVAL_MS,
  RUN_POLL_DETAIL_MAX_INTERVAL_MS,
  RUN_POLL_GRAPH_ATTEMPTS,
  RUN_POLL_INTERVAL_MS,
  RUN_POLL_MAX_DURATION_MS,
  RUN_POLL_MAX_FAILURE_MS,
  RUN_POLL_NETWORK_REASON,
  RUN_POLL_NOTICE_TYPE,
  RUN_POLL_PAGE_ATTEMPTS,
  RUN_POLL_PAGE_REASON,
  RUN_POLL_RECOVERED_MESSAGE,
  RUN_POLL_START_MESSAGE,
  RUN_POLL_STEP_MODE_MESSAGE,
  RUN_POLL_TIMEOUT_MESSAGE,
  classifyPollError,
  createRunFollowState,
  fileOutputOf,
  followRunByRest,
  isTerminalRunStatus,
  nextPollDelay,
  runCandidatesAfterDisconnect,
  runEventsFromDetail,
  runNoStepsMessage,
  runPollGaveUpMessage,
  runPollNoGraphMessage,
  runPollPageMessage,
  runPollRejectedMessage,
  runPollRetryMessage,
  runResultText,
  runStatusInList,
  trackRunEvent,
} from '../src/api/runPolling.ts';
import {
  CONNECTION_LOST_TYPE,
  isTerminalRunEvent,
  runEventError,
  terminalRunStatus,
} from '../src/api/runEvents.ts';

const SCENARIO = 'a3c32c70-47b0-42cf-823a-03a92c63b196';
const RUN = '8373366a-7835-43d2-a541-c2402cbbdfdb';
const T0 = Date.parse('2026-09-17T10:59:30.000Z');

/** Время как у бэкенда: UTC с микросекундами. */
const iso = (ms) => new Date(ms).toISOString().replace('Z', '678Z');

const GRAPH = [
  { id: 'v0', type: 'input', data: { label: 'Вход' } },
  { id: 'n1', type: 'note', data: { label: 'Заметка' } },
  { id: 'a1', type: 'processing', data: { label: 'Агент' } },
  { id: 'h6', type: 'output', data: { label: 'Текст', mode: 'text' } },
  { id: 'v7', type: 'output', data: { label: 'Выход', mode: 'excel' } },
];

const step = (id, nodeId, status, extra = {}) => ({
  id,
  node_id: nodeId,
  node_type: { v0: 'input', a1: 'processing', h6: 'output', v7: 'output' }[nodeId] ?? 'processing',
  status,
  started_at: iso(T0),
  ...extra,
});

const types = (events) => events.map((e) => e.type);
const byType = (events, type) => events.filter((e) => e.type === type);
/** Ошибка HTTP как ApiError клиента: код и сообщение. */
const http = (status, message = `код ${status}`) => Object.assign(new Error(message), { status });

describe('runEventsFromDetail: ответ GET /scenarios/runs/{id} → кадры как по сокету', () => {
  test('идущий прогон: NODE_STATUS по шагам, метки и «шаг N из M» из графа без заметок, без STATUS', () => {
    const state = createRunFollowState();
    const events = runEventsFromDetail(
      {
        id: RUN,
        status: 'running',
        steps: [
          step('s0', 'v0', 'completed', { output_data: { result: 'документы' }, tokens_used: 0 }),
          step('s1', 'a1', 'running'),
        ],
      },
      GRAPH,
      state,
      RUN,
    );
    assert.deepEqual(types(events), ['NODE_STATUS', 'STEP_COMPLETE', 'NODE_STATUS']);
    assert.deepEqual(events[0].data, {
      node_id: 'v0',
      node_label: 'Вход',
      node_type: 'input',
      status: 'COMPLETED',
      step: 1,
      total: 4,
    });
    assert.deepEqual(events[2].data, {
      node_id: 'a1',
      node_label: 'Агент',
      node_type: 'processing',
      status: 'RUNNING',
      step: 2,
      total: 4,
    });
    assert.equal(terminalRunStatus(events[2]), null);
    assert.equal(state.nodeStatuses.get('a1'), 'running');
  });

  test('повторный опрос без изменений не даёт кадров; смена статуса — один NODE_STATUS', () => {
    const state = createRunFollowState();
    const running = { status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'running')] };
    runEventsFromDetail(running, GRAPH, state, RUN);
    assert.deepEqual(runEventsFromDetail(running, GRAPH, state, RUN), []);

    const done = {
      status: 'running',
      steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed', { tokens_used: 64941 })],
    };
    const events = runEventsFromDetail(done, GRAPH, state, RUN);
    assert.deepEqual(types(events), ['NODE_STATUS', 'STEP_COMPLETE']);
    assert.equal(events[0].data.status, 'COMPLETED');
    assert.equal(events[1].data.tokens_used, 64941);
  });

  test('несколько шагов одного узла: статус узла — по последнему шагу', () => {
    const state = createRunFollowState();
    const events = runEventsFromDetail(
      {
        status: 'running',
        steps: [step('s1', 'a1', 'failed', { output_data: { error: 'сбой' } }), step('s2', 'a1', 'running')],
      },
      GRAPH,
      state,
      RUN,
    );
    const statuses = byType(events, 'NODE_STATUS');
    assert.equal(statuses.length, 1);
    assert.equal(statuses[0].data.status, 'RUNNING');
  });

  test('кадры сокета до обрыва не повторяются: NODE_STATUS, STEP_COMPLETE, FILE_OUTPUT', () => {
    const state = createRunFollowState();
    trackRunEvent(state, { type: 'NODE_STATUS', data: { node_id: 'v7', node_label: 'Выход', status: 'RUNNING' } });
    trackRunEvent(state, {
      type: 'FILE_OUTPUT',
      data: { node_id: 'v7', node_label: 'Выход', filename: 'result.xlsx', file_ready: true },
    });
    trackRunEvent(state, { type: 'NODE_STATUS', data: { node_id: 'v7', node_label: 'Выход', status: 'COMPLETED' } });
    trackRunEvent(state, { type: 'STEP_COMPLETE', data: { node_id: 'v7', step_id: 's7' } });
    trackRunEvent(state, { type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    const events = runEventsFromDetail(
      { status: 'running', steps: [step('s7', 'v7', 'completed')] },
      GRAPH,
      state,
      RUN,
    );
    assert.deepEqual(events, []);
  });

  test('метка: граф, иначе метка из кадра сокета, иначе тип узла (как ScenarioRunNode.getLabel); шаг вне графа — без step/total', () => {
    const state = createRunFollowState();
    trackRunEvent(state, { type: 'NODE_STATUS', data: { node_id: 'x1', node_label: 'Из сокета', status: 'RUNNING' } });
    const events = runEventsFromDetail(
      {
        status: 'running',
        steps: [step('s1', 'x1', 'completed'), step('s2', 'x2', 'completed', { node_type: 'loop' }), step('s3', 'x3', 'running', { node_type: undefined })],
      },
      GRAPH,
      state,
      RUN,
    );
    const statuses = byType(events, 'NODE_STATUS');
    assert.equal(statuses[0].data.node_label, 'Из сокета');
    assert.equal(statuses[0].data.step, undefined);
    assert.equal(statuses[1].data.node_label, 'loop');
    assert.equal(byType(events, 'STEP_COMPLETE')[1].data.node_label, 'loop');
    // ни метки, ни типа — id узла
    assert.equal(statuses[2].data.node_label, 'x3');
    // граф не загрузился — кадры всё равно идут
    assert.equal(runEventsFromDetail({ status: 'running', steps: [step('s4', 'a1', 'running')] }, null, state, RUN).length, 1);
  });

  test('узел графа с пустой меткой называется типом из графа, как в журнале по сокету (АЗК v3: input/loop/switch/output)', () => {
    const graph = [
      { id: 'node_1', type: 'input', data: { label: '' } },
      { id: 'node_2', type: 'loop', data: {} },
      { id: 'node_3', type: 'switch' },
      { id: 'node_9', type: 'output', data: { label: '', mode: 'all' } },
    ];
    const events = runEventsFromDetail(
      {
        status: 'completed',
        steps: [
          step('s1', 'node_1', 'completed', { node_type: 'input' }),
          step('s2', 'node_2', 'completed', { node_type: 'loop' }),
          step('s3', 'node_3', 'completed', { node_type: 'switch' }),
          step('s9', 'node_9', 'completed', { node_type: 'output' }),
        ],
      },
      graph,
      createRunFollowState(),
      RUN,
    );
    assert.deepEqual(
      byType(events, 'NODE_STATUS').map((e) => [e.data.node_label, e.data.step, e.data.total]),
      [
        ['input', 1, 4],
        ['loop', 2, 4],
        ['switch', 3, 4],
        ['output', 4, 4],
      ],
    );
  });

  test('STEP_COMPLETE: превью данных шага как в кадре сокета, шаг и число шагов из графа', () => {
    const state = createRunFollowState();
    const long = 'я'.repeat(200_098);
    const [, complete] = runEventsFromDetail(
      {
        status: 'running',
        steps: [
          step('s1', 'a1', 'completed', {
            input_data: { documents_text: long, previous_output: 'коротко' },
            output_data: { result: long },
            prompt_used: long,
            tokens_used: 412061,
          }),
        ],
      },
      GRAPH,
      state,
      RUN,
    );
    assert.equal(complete.type, 'STEP_COMPLETE');
    const data = complete.data;
    assert.equal(data.step_id, 's1');
    assert.equal(data.node_label, 'Агент');
    assert.equal(data.node_type, 'processing');
    assert.equal(data.step_index, 2);
    assert.equal(data.total_steps, 4);
    assert.equal(data.tokens_used, 412061);
    assert.equal(data.input_data.previous_output, 'коротко');
    assert.ok(data.input_data.documents_text.startsWith('я'.repeat(1000) + '…'));
    assert.ok(data.output_data.result.startsWith('я'.repeat(3000) + '…'));
    assert.ok(data.prompt_used.startsWith('я'.repeat(2000) + '…'));
    assert.ok(data.output_data.result.length < 3100);
  });

  test('упавший шаг: NODE_STATUS FAILED с ошибкой, STEP_COMPLETE нет (как по сокету)', () => {
    const state = createRunFollowState();
    const events = runEventsFromDetail(
      {
        status: 'running',
        steps: [step('s1', 'a1', 'failed', { output_data: { error: 'Вычислительный узел: во входных данных не найден JSON…' } })],
      },
      GRAPH,
      state,
      RUN,
    );
    assert.deepEqual(types(events), ['NODE_STATUS']);
    assert.equal(events[0].data.status, 'FAILED');
    assert.equal(events[0].data.error, 'Вычислительный узел: во входных данных не найден JSON…');
  });

  test('пошаговый режим после обрыва не распознаётся: прогон на «паузе» по шагам — без STEP_PAUSED', () => {
    const state = createRunFollowState();
    const paused = { status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed')] };
    const all = [
      ...runEventsFromDetail(paused, GRAPH, state, RUN),
      ...runEventsFromDetail(paused, GRAPH, state, RUN),
      ...runEventsFromDetail(paused, GRAPH, state, RUN),
    ];
    assert.equal(byType(all, 'STEP_PAUSED').length, 0);
  });
});

describe('файловые выходы (FILE_OUTPUT с file_ready)', () => {
  test('имя и MIME по режиму узла, как ScenarioEventEmission', () => {
    const xlsx = { filename: 'result.xlsx', mime_type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
    const txt = { filename: 'result.txt', mime_type: 'text/plain' };
    assert.deepEqual(fileOutputOf({ id: 'o', type: 'output', data: { mode: 'excel' } }), xlsx);
    assert.deepEqual(fileOutputOf({ id: 'o', type: 'output', data: { mode: 'EXCEL' } }), xlsx);
    assert.deepEqual(fileOutputOf({ id: 'o', type: 'output', data: { mode: 'text' } }), txt);
    assert.deepEqual(fileOutputOf({ id: 'o', type: 'output', data: { mode: 'text_file' } }), txt);
    assert.deepEqual(fileOutputOf({ id: 'o', type: 'output', data: { label: 'Excel' } }), xlsx);
    assert.equal(fileOutputOf({ id: 'o', type: 'output', data: { label: 'Протокол' } }), null);
    assert.equal(fileOutputOf({ id: 'o', type: 'output', data: { mode: 'all' } }), null);
    assert.equal(fileOutputOf({ id: 'o', type: 'processing', data: { mode: 'excel' } }), null);
    assert.equal(fileOutputOf(undefined, 'output'), null);
  });

  test('только завершённый выход, один раз на узел', () => {
    const state = createRunFollowState();
    const running = runEventsFromDetail({ status: 'running', steps: [step('s6', 'h6', 'running')] }, GRAPH, state, RUN);
    assert.equal(byType(running, 'FILE_OUTPUT').length, 0);

    const detail = {
      status: 'running',
      steps: [step('s6', 'h6', 'completed'), step('s7', 'v7', 'completed'), step('s8', 'v7', 'completed')],
    };
    const files = byType(runEventsFromDetail(detail, GRAPH, state, RUN), 'FILE_OUTPUT');
    assert.deepEqual(
      files.map((e) => e.data),
      [
        { node_id: 'h6', node_label: 'Текст', filename: 'result.txt', mime_type: 'text/plain', file_ready: true },
        {
          node_id: 'v7',
          node_label: 'Выход',
          filename: 'result.xlsx',
          mime_type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
          file_ready: true,
        },
      ],
    );
    assert.equal(byType(runEventsFromDetail(detail, GRAPH, state, RUN), 'FILE_OUTPUT').length, 0);
  });
});

describe('итоговый статус прогона', () => {
  test('completed: STATUS COMPLETED с итогом-строкой — раннер видит терминальный кадр', () => {
    const events = runEventsFromDetail(
      { status: 'completed', result: 'итог прогона', steps: [step('s7', 'v7', 'completed')] },
      GRAPH,
      createRunFollowState(),
      RUN,
    );
    const status = events.at(-1);
    assert.deepEqual(status, { type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED', result: 'итог прогона' } });
    assert.equal(terminalRunStatus(status), 'COMPLETED');
    assert.equal(isTerminalRunEvent(status), true);
    assert.equal(runEventError(status), null);
  });

  test('completed без итога (ни один выход не выполнен): STATUS без result', () => {
    const events = runEventsFromDetail({ status: 'completed', result: '', steps: [] }, GRAPH, createRunFollowState(), RUN);
    assert.deepEqual(events, [{ type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED' } }]);
  });

  test('failed с упавшим шагом: причина в NODE_STATUS, STATUS FAILED без error (как finishFailedRun)', () => {
    const events = runEventsFromDetail(
      {
        status: 'failed',
        steps: [step('s1', 'a1', 'failed', { output_data: { error: 'Прогон остановлен пользователем' } })],
      },
      GRAPH,
      createRunFollowState(),
      RUN,
    );
    assert.deepEqual(types(events), ['NODE_STATUS', 'STATUS']);
    assert.equal(events[0].data.error, 'Прогон остановлен пользователем');
    assert.deepEqual(events[1].data, { run_id: RUN, status: 'FAILED' });
    assert.equal(terminalRunStatus(events[1]), 'FAILED');
  });

  test('failed с итогом (on_error=continue): итог передаётся', () => {
    const events = runEventsFromDetail(
      {
        status: 'failed',
        result: '=== РЕЗУЛЬТАТ ОТ "Протокол" ===',
        steps: [step('s1', 'a1', 'failed', { output_data: { error: 'сбой' } }), step('s2', 'h6', 'completed')],
      },
      GRAPH,
      createRunFollowState(),
      RUN,
    );
    assert.deepEqual(events.at(-1).data, { run_id: RUN, status: 'FAILED', result: '=== РЕЗУЛЬТАТ ОТ "Протокол" ===' });
  });

  test('failed без упавшего шага и без итога: причина для баннера — с заглавной буквы', () => {
    const events = runEventsFromDetail({ status: 'failed', steps: [step('s0', 'v0', 'completed')] }, GRAPH, createRunFollowState(), RUN);
    assert.equal(events.at(-1).data.error, RUN_FAILED_WITHOUT_NODE_ERROR);
    assert.match(RUN_FAILED_WITHOUT_NODE_ERROR, /^Сервер/);
  });

  test('прогон failed при рестарте, последний шаг остался running: узел FAILED с причиной, а не «выполняется»', () => {
    const state = createRunFollowState();
    // по сокету до обрыва агент был начат
    trackRunEvent(state, { type: 'NODE_STATUS', data: { node_id: 'a1', node_label: 'Агент', status: 'RUNNING' } });
    const events = runEventsFromDetail(
      { status: 'failed', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'running')] },
      GRAPH,
      state,
      RUN,
    );
    const statuses = byType(events, 'NODE_STATUS');
    assert.deepEqual(
      statuses.map((e) => [e.data.node_id, e.data.status, e.data.error]),
      [
        ['v0', 'COMPLETED', undefined],
        ['a1', 'FAILED', RUN_FAILED_WITHOUT_NODE_ERROR],
      ],
    );
    assert.ok(!statuses.some((e) => e.data.status === 'RUNNING'));
    // причина — в баннере от узла, STATUS FAILED без повтора
    assert.deepEqual(events.at(-1), { type: 'STATUS', data: { run_id: RUN, status: 'FAILED' } });
    assert.equal(state.nodeStatuses.get('a1'), 'failed');
  });

  test('прогон completed с шагом running (не бывает, но не «выполняется»): кадра по такому узлу нет', () => {
    const events = runEventsFromDetail(
      { status: 'completed', result: 'итог', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'running')] },
      GRAPH,
      createRunFollowState(),
      RUN,
    );
    assert.deepEqual(byType(events, 'NODE_STATUS').map((e) => e.data.node_id), ['v0']);
  });

  test('итог прежнего вида {output} тоже принимается', () => {
    assert.equal(runResultText('строка'), 'строка');
    assert.equal(runResultText({ output: 'объект' }), 'объект');
    assert.equal(runResultText(null), '');
    assert.equal(runResultText(undefined), '');
    const events = runEventsFromDetail({ status: 'COMPLETED', result: { output: 'объект' } }, GRAPH, createRunFollowState(), RUN);
    assert.equal(events.at(-1).data.result, 'объект');
  });

  test('isTerminalRunStatus и runStatusInList', () => {
    assert.equal(isTerminalRunStatus('completed'), true);
    assert.equal(isTerminalRunStatus('FAILED'), true);
    assert.equal(isTerminalRunStatus('running'), false);
    assert.equal(isTerminalRunStatus('pending'), false);
    assert.equal(isTerminalRunStatus(undefined), false);
    const runs = [
      { id: 'r1', status: 'running' },
      { id: 'r2', status: 'Completed' },
    ];
    assert.equal(runStatusInList(runs, 'r2'), 'completed');
    assert.equal(runStatusInList(runs, 'r3'), null);
    assert.equal(runStatusInList(undefined, 'r1'), null);
  });

  test('пустой ответ не роняет разбор', () => {
    assert.deepEqual(runEventsFromDetail(null, GRAPH, createRunFollowState(), RUN), []);
    assert.deepEqual(runEventsFromDetail({ status: 'running', steps: null }, GRAPH, createRunFollowState(), RUN), []);
  });
});

describe('поиск прогона, если run_id не пришёл до обрыва', () => {
  test('кандидаты — начатые не раньше отправки run с запасом 30 с на часы, по возрастанию начала', () => {
    const runs = [
      { id: 'other-tab', status: 'running', started_at: iso(T0 + 5_000) },
      { id: 'mine', status: 'running', started_at: iso(T0 + 300) },
      { id: 'skew', status: 'running', started_at: iso(T0 - 20_000) },
      { id: 'prev', status: 'completed', started_at: iso(T0 - 60_000) },
    ];
    assert.deepEqual(runCandidatesAfterDisconnect(runs, T0), ['skew', 'mine', 'other-tab']);
    // прогон, начатый минуту назад (прошлый запуск), — не кандидат
    assert.deepEqual(runCandidatesAfterDisconnect([runs[3]], T0), []);
    assert.deepEqual(runCandidatesAfterDisconnect([runs[3], runs[1]], T0), ['mine']);
  });

  test('время бэкенда с микросекундами и без дробной части; мусор пропускается', () => {
    assert.deepEqual(runCandidatesAfterDisconnect([{ id: 'a', started_at: '2026-09-17T10:59:31.13968Z' }], T0), ['a']);
    assert.deepEqual(runCandidatesAfterDisconnect([{ id: 'b', started_at: '2026-09-17T10:59:31Z' }], T0), ['b']);
    assert.deepEqual(runCandidatesAfterDisconnect([{ id: 'c', started_at: '2026-09-17T10:59:31.1Z' }], T0), ['c']);
    assert.deepEqual(
      runCandidatesAfterDisconnect([null, { id: '' }, { id: 'd' }, { id: 'e', started_at: 'вчера' }, { started_at: iso(T0) }], T0),
      [],
    );
    assert.deepEqual(runCandidatesAfterDisconnect(undefined, T0), []);
    assert.deepEqual(runCandidatesAfterDisconnect({}, T0), []);
  });
});

describe('паузы и ошибки опроса', () => {
  test('пауза 10 с, при сбоях подряд — 20, 40, затем 60 с', () => {
    assert.deepEqual([0, 1, 2, 3, 4, 50].map(nextPollDelay), [10_000, 20_000, 40_000, 60_000, 60_000, 60_000]);
  });

  test('разбор сбоя: 4xx бэкенда — отказ; страница шлюза — page; сеть, 5xx, 408/425/429 — повтор; причины по-русски', () => {
    for (const status of [400, 401, 403, 404, 422]) {
      assert.deepEqual(classifyPollError(http(status, 'illegal userId')), { kind: 'fatal', reason: 'illegal userId' }, String(status));
    }
    for (const status of [408, 425, 429, 500, 502, 503, 504]) {
      assert.equal(classifyPollError(http(status)).kind, 'retry', String(status));
    }
    assert.deepEqual(classifyPollError(http(403, 'Шлюз вернул 403 без JSON')), { kind: 'page', reason: 'Шлюз вернул 403 без JSON' });
    assert.deepEqual(classifyPollError(new TypeError('Failed to fetch')), { kind: 'retry', reason: RUN_POLL_NETWORK_REASON });
    assert.deepEqual(
      classifyPollError(new SyntaxError('Unexpected token \'<\', "<html>" is not valid JSON')),
      { kind: 'page', reason: RUN_POLL_PAGE_REASON },
    );
    assert.equal(classifyPollError(null).kind, 'retry');
  });
});

/**
 * Заглушки запросов и часов для цикла слежения: ответы по пути — очередь, последний
 * повторяется; Error в очереди — отказ запроса; функция — ответ по часам. Пауза сдвигает часы.
 */
function harness(script, { runId = RUN, runSentAt = T0, stepMode = false, state = createRunFollowState() } = {}) {
  let clock = T0 + 5000;
  const calls = [];
  const timeline = [];
  const sleeps = [];
  const ctl = { aborted: false, abortOnCall: -1 };
  const queues = new Map(Object.entries(script).map(([path, list]) => [path, Array.isArray(list) ? [...list] : list]));
  const abortError = () => Object.assign(new Error('Прогон прерван'), { name: 'AbortError' });
  const deps = {
    getJson: async (path) => {
      calls.push(path);
      timeline.push([path, clock - T0 - 5000]);
      if (calls.length === ctl.abortOnCall) {
        ctl.aborted = true;
        throw new TypeError('The user aborted a request.');
      }
      const queue = queues.get(path);
      if (!queue) throw http(404, `нет ответа для ${path}`);
      const answer = typeof queue === 'function' ? queue(clock - T0 - 5000) : queue.length > 1 ? queue.shift() : queue[0];
      if (answer instanceof Error) throw answer;
      return structuredClone(answer);
    },
    sleep: async (ms) => {
      sleeps.push(ms);
      clock += ms;
    },
    throwIfAborted: () => {
      if (ctl.aborted) throw abortError();
    },
    now: () => clock,
  };
  const generator = followRunByRest({ scenarioId: SCENARIO, runId, runSentAt, stepMode, state }, deps);
  return { generator, calls, timeline, sleeps, ctl, state };
}

async function collect(generator, limit = 10_000) {
  const events = [];
  for await (const event of generator) {
    events.push(event);
    if (events.length > limit) throw new Error('слишком много кадров');
  }
  return events;
}

const SCENARIO_PATH = `/scenarios/${SCENARIO}`;
const RUNS_PATH = `/scenarios/${SCENARIO}/runs`;
const DETAIL_PATH = `/scenarios/runs/${RUN}`;
const scenarioResponse = { id: SCENARIO, graph_data: { nodes: GRAPH, edges: [] } };
const listOf = (status) => [{ id: RUN, scenario_id: SCENARIO, status, started_at: iso(T0 + 100) }];
const notices = (events) => byType(events, RUN_POLL_NOTICE_TYPE).map((e) => e.data.message);
const count = (calls, path) => calls.filter((p) => p === path).length;

describe('followRunByRest: цикл слежения после обрыва', () => {
  test('известный run_id: уведомление, детали сразу, статус списком, итог — деталями; кадры сокета не повторяются', async () => {
    const state = createRunFollowState();
    // до обрыва по сокету: вход выполнен, агент начат
    trackRunEvent(state, { type: 'NODE_STATUS', data: { node_id: 'v0', node_label: 'Вход', status: 'COMPLETED' } });
    trackRunEvent(state, { type: 'STEP_COMPLETE', data: { node_id: 'v0', step_id: 's0' } });
    trackRunEvent(state, { type: 'NODE_STATUS', data: { node_id: 'a1', node_label: 'Агент', status: 'RUNNING' } });
    const running = { id: RUN, status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'running')] };
    const final = {
      id: RUN,
      status: 'completed',
      result: 'итог',
      steps: [
        step('s0', 'v0', 'completed'),
        step('s1', 'a1', 'completed', { tokens_used: 100 }),
        step('s2', 'v7', 'completed'),
      ],
    };
    const { generator, calls, sleeps } = harness(
      {
        [SCENARIO_PATH]: [scenarioResponse],
        [RUNS_PATH]: [listOf('running'), listOf('running'), listOf('completed')],
        [DETAIL_PATH]: [running, final],
      },
      { state },
    );
    const events = await collect(generator);

    assert.deepEqual(notices(events), [RUN_POLL_START_MESSAGE]);
    assert.deepEqual(types(events), [
      RUN_POLL_NOTICE_TYPE,
      'NODE_STATUS',
      'STEP_COMPLETE',
      'NODE_STATUS',
      'FILE_OUTPUT',
      'STEP_COMPLETE',
      'STATUS',
    ]);
    assert.deepEqual(
      byType(events, 'NODE_STATUS').map((e) => [e.data.node_id, e.data.status, e.data.step, e.data.total]),
      [
        ['a1', 'COMPLETED', 2, 4],
        ['v7', 'COMPLETED', 4, 4],
      ],
    );
    assert.equal(byType(events, 'FILE_OUTPUT')[0].data.filename, 'result.xlsx');
    assert.deepEqual(events.at(-1), { type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED', result: 'итог' } });
    // граф — один раз; детали — сразу и после итогового статуса в списке; команды run нет
    assert.deepEqual(calls, [SCENARIO_PATH, RUNS_PATH, DETAIL_PATH, RUNS_PATH, RUNS_PATH, DETAIL_PATH]);
    assert.deepEqual(sleeps, [RUN_POLL_INTERVAL_MS, RUN_POLL_INTERVAL_MS]);
  });

  test('детали без изменений — период удваивается 30 → 60 → 120 с; новые кадры возвращают 30 с; итог — детали сразу', async () => {
    const agent = { status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'running')] };
    const output = { status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed'), step('s2', 'v7', 'running')] };
    const done = { status: 'completed', result: 'итог', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed'), step('s2', 'v7', 'completed')] };
    // агент идёт до 400 с, выход — до 455 с, итог в списке с 455 с
    const detailAt = (t) => (t < 400_000 ? agent : t < 455_000 ? output : done);
    const { generator, timeline } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: (t) => listOf(t < 455_000 ? 'running' : 'completed'),
      [DETAIL_PATH]: detailAt,
    });
    const events = await collect(generator);
    assert.equal(events.at(-1).data.status, 'COMPLETED');
    const detailTimes = timeline.filter(([p]) => p === DETAIL_PATH).map(([, t]) => t / 1000);
    // 0 — кадры; 30 — без изменений (→60); 90 — без изменений (→120); 210, 330 — без изменений;
    // 450 — выход начат (→30); итог в списке на 460 — детали сразу
    assert.deepEqual(detailTimes, [0, 30, 90, 210, 330, 450, 460]);
    assert.equal(RUN_POLL_DETAIL_MAX_INTERVAL_MS, 120_000);
    // список — каждые 10 с
    assert.equal(timeline.filter(([p]) => p === RUNS_PATH).length, 47);
  });

  test('run_id известен, список прогонов стабильно не проходит (5xx шлюза, лимит SOWA) — статус и итог из деталей раз в 30 с', async () => {
    const { generator, timeline } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [http(502, 'Шлюз вернул 502 без JSON')],
      [DETAIL_PATH]: (t) => (t < 100_000 ? { status: 'running', steps: [step('s1', 'a1', 'running')] } : { status: 'completed', result: 'итог', steps: [step('s1', 'a1', 'completed')] }),
    });
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), { type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED', result: 'итог' } });
    const detailTimes = timeline.filter(([p]) => p === DETAIL_PATH).map(([, t]) => t / 1000);
    assert.deepEqual(detailTimes, [0, 30, 60, 90, 120]);
    // сбой списка при известном run_id — не сбой слежения: в журнале только начало
    assert.deepEqual(notices(events), [RUN_POLL_START_MESSAGE]);
  });

  test('run_id не пришёл: прогон находится по списку, раннеру уходит STATUS RUNNING с run_id', async () => {
    const { generator, calls } = harness(
      {
        [SCENARIO_PATH]: [scenarioResponse],
        [RUNS_PATH]: [
          [
            { id: RUN, status: 'running', started_at: iso(T0 + 200) },
            { id: 'old-run', status: 'failed', started_at: iso(T0 - 3 * 60_000) },
          ],
          [
            { id: RUN, status: 'failed', started_at: iso(T0 + 200) },
            { id: 'old-run', status: 'failed', started_at: iso(T0 - 3 * 60_000) },
          ],
        ],
        [DETAIL_PATH]: [
          { status: 'running', steps: [] },
          { status: 'failed', steps: [step('s1', 'a1', 'failed', { output_data: { error: 'Прогон остановлен пользователем' } })] },
        ],
      },
      { runId: null },
    );
    const events = await collect(generator);
    assert.deepEqual(events[1], { type: 'STATUS', data: { run_id: RUN, status: 'RUNNING' } });
    assert.deepEqual(types(events).slice(2), ['NODE_STATUS', 'STATUS']);
    assert.equal(events.at(-1).data.status, 'FAILED');
    assert.ok(!calls.includes('/scenarios/runs/old-run'));
  });

  test('run_id не пришёл, в списке только прошлый прогон (минуту назад) — не выдаётся за свой: «прогон не найден» за 3 списка', async () => {
    const { generator, calls, sleeps } = harness(
      {
        [SCENARIO_PATH]: [scenarioResponse],
        [RUNS_PATH]: [[{ id: 'prev-run', status: 'completed', started_at: iso(T0 - 60_000) }]],
        '/scenarios/runs/prev-run': [{ status: 'completed', result: 'итог прошлого прогона', steps: [] }],
      },
      { runId: null },
    );
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), { type: CONNECTION_LOST_TYPE, error: RUN_NOT_FOUND_MESSAGE, data: { run_id: undefined } });
    assert.equal(byType(events, 'STATUS').length, 0);
    assert.equal(isTerminalRunEvent(events.at(-1)), true);
    assert.equal(runEventError(events.at(-1)), null);
    assert.equal(count(calls, RUNS_PATH), RUN_PICK_ATTEMPTS);
    assert.equal(count(calls, '/scenarios/runs/prev-run'), 0);
    assert.equal(sleeps.length, RUN_PICK_ATTEMPTS - 1);
  });

  test('run_id не пришёл, после отправки run два новых прогона (вторая вкладка) — не угадывать: CONNECTION_LOST без run_id', async () => {
    const { generator, calls } = harness(
      {
        [SCENARIO_PATH]: [scenarioResponse],
        [RUNS_PATH]: [
          [
            { id: 'other-tab', status: 'running', started_at: iso(T0 + 5_000) },
            { id: RUN, status: 'running', started_at: iso(T0 + 300) },
          ],
        ],
      },
      { runId: null },
    );
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), { type: CONNECTION_LOST_TYPE, error: RUN_PICK_AMBIGUOUS_MESSAGE, data: { run_id: undefined } });
    assert.equal(byType(events, 'STATUS').length, 0);
    assert.ok(!calls.some((p) => p.startsWith('/scenarios/runs/')));
  });

  test('run_id не пришёл, список недоступен — не дольше 3 мин: CONNECTION_LOST без run_id с причиной по-русски', async () => {
    const { generator, sleeps } = harness(
      { [SCENARIO_PATH]: [scenarioResponse], [RUNS_PATH]: [new TypeError('Failed to fetch')] },
      { runId: null },
    );
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), {
      type: CONNECTION_LOST_TYPE,
      error: runPollGaveUpMessage(RUN_POLL_NETWORK_REASON, null),
      data: { run_id: undefined },
    });
    const waited = sleeps.reduce((a, b) => a + b, 0);
    assert.ok(waited >= RUN_PICK_MAX_MS && waited <= RUN_PICK_MAX_MS + 60_000, String(waited));
    assert.deepEqual(notices(events), [RUN_POLL_START_MESSAGE, runPollRetryMessage(RUN_POLL_NETWORK_REASON)]);
    assert.ok(!JSON.stringify(events).includes('Failed to fetch'));
  });

  test('сбои деталей: пауза растёт до 60 с, в журнал — первый сбой и восстановление', async () => {
    const network = new TypeError('Failed to fetch');
    const gateway = http(502, 'Шлюз вернул 502 без JSON');
    const { generator, sleeps } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [listOf('running')],
      [DETAIL_PATH]: [network, gateway, network, network, { status: 'completed', result: 'итог', steps: [] }],
    });
    const events = await collect(generator);
    assert.deepEqual(sleeps, [20_000, 40_000, 60_000, 60_000]);
    assert.deepEqual(notices(events), [
      RUN_POLL_START_MESSAGE,
      runPollRetryMessage(RUN_POLL_NETWORK_REASON),
      RUN_POLL_RECOVERED_MESSAGE,
    ]);
    assert.equal(events.at(-1).data.status, 'COMPLETED');
  });

  test('сбои подряд: строка о сбое раз в 3 мин, через 10 мин — CONNECTION_LOST с run_id («Подробный отчёт»)', async () => {
    const { generator, sleeps } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [http(504, 'Шлюз вернул 504 без JSON')],
      [DETAIL_PATH]: [http(504, 'Шлюз вернул 504 без JSON')],
    });
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), {
      type: CONNECTION_LOST_TYPE,
      error: runPollGaveUpMessage('Шлюз вернул 504 без JSON', RUN),
      data: { run_id: RUN },
    });
    const waited = sleeps.reduce((a, b) => a + b, 0);
    assert.ok(waited >= RUN_POLL_MAX_FAILURE_MS && waited <= RUN_POLL_MAX_FAILURE_MS + 60_000, String(waited));
    const retries = notices(events).filter((m) => m === runPollRetryMessage('Шлюз вернул 504 без JSON'));
    assert.ok(retries.length >= 3 && retries.length <= 5, String(retries.length));
  });

  test('200 со страницей вместо JSON (истёкшая сессия SSO) 3 раза подряд — CONNECTION_LOST с подсказкой обновить страницу', async () => {
    const page = new SyntaxError('Unexpected token \'<\', "<html>blocked</html>" is not valid JSON');
    const { generator, sleeps } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [page],
      [DETAIL_PATH]: [page],
    });
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), {
      type: CONNECTION_LOST_TYPE,
      error: runPollPageMessage(RUN_POLL_PAGE_REASON, RUN),
      data: { run_id: RUN },
    });
    assert.equal(sleeps.length, RUN_POLL_PAGE_ATTEMPTS - 1);
    assert.ok(!JSON.stringify(events).includes('Unexpected token'));
  });

  test('HTML-отказ шлюза 403 повторяется: второй запрос прошёл — слежение продолжается', async () => {
    const { generator } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [listOf('running'), listOf('completed')],
      [DETAIL_PATH]: [http(403, 'Шлюз вернул 403 без JSON'), { status: 'completed', result: 'итог', steps: [] }],
    });
    const events = await collect(generator);
    assert.equal(events.at(-1).data.status, 'COMPLETED');
    assert.equal(byType(events, CONNECTION_LOST_TYPE).length, 0);
  });

  test('отказ 4xx бэкенда (чужой прогон, сессия) — CONNECTION_LOST с причиной, опрос прекращается', async () => {
    const { generator, sleeps } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [listOf('running')],
      [DETAIL_PATH]: [http(403, 'illegal userId')],
    });
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), {
      type: CONNECTION_LOST_TYPE,
      error: runPollRejectedMessage('illegal userId', RUN),
      data: { run_id: RUN },
    });
    assert.deepEqual(sleeps, []);
  });

  test('граф 403 (владелец снял «общий») — слежение без графа: метки по данным прогона, итог показан', async () => {
    const { generator, calls } = harness({
      [SCENARIO_PATH]: [http(403, 'illegal userId')],
      [RUNS_PATH]: [listOf('completed')],
      [DETAIL_PATH]: [{ status: 'completed', result: 'итог', steps: [step('s1', 'a1', 'completed'), step('s2', 'v7', 'completed')] }],
    });
    const events = await collect(generator);
    assert.deepEqual(notices(events), [RUN_POLL_START_MESSAGE, runPollNoGraphMessage('illegal userId')]);
    assert.deepEqual(byType(events, 'NODE_STATUS').map((e) => e.data.node_label), ['processing', 'output']);
    assert.deepEqual(events.at(-1), { type: 'STATUS', data: { run_id: RUN, status: 'COMPLETED', result: 'итог' } });
    assert.equal(count(calls, SCENARIO_PATH), 1);
  });

  test('сбой только графа: детали ждут 3 попытки графа, затем слежение без него', async () => {
    const graphDown = http(502, 'Шлюз вернул 502 без JSON');
    const { generator, timeline } = harness({
      [SCENARIO_PATH]: [graphDown],
      [RUNS_PATH]: [listOf('running')],
      [DETAIL_PATH]: [{ status: 'running', steps: [step('s1', 'a1', 'running')] }],
    });
    const events = [];
    for await (const event of generator) {
      events.push(event);
      if (event.type === 'NODE_STATUS') break;
    }
    assert.equal(timeline.filter(([p]) => p === SCENARIO_PATH).length, RUN_POLL_GRAPH_ATTEMPTS);
    assert.deepEqual(timeline.find(([p]) => p === DETAIL_PATH), [DETAIL_PATH, 20_000]);
    assert.deepEqual(notices(events), [RUN_POLL_START_MESSAGE, runPollNoGraphMessage('Шлюз вернул 502 без JSON')]);
  });

  test('общий сбой сети: граф не списывается, а загружается после восстановления', async () => {
    const network = new TypeError('Failed to fetch');
    const { generator } = harness({
      [SCENARIO_PATH]: [network, network, network, network, scenarioResponse],
      [RUNS_PATH]: [network, network, network, network, listOf('running'), listOf('completed')],
      [DETAIL_PATH]: [network, network, network, network, { status: 'completed', result: 'итог', steps: [step('s1', 'a1', 'completed')] }],
    });
    const events = await collect(generator);
    assert.ok(!notices(events).some((m) => m.startsWith('Граф сценария')));
    assert.deepEqual(byType(events, 'NODE_STATUS').map((e) => [e.data.node_label, e.data.step]), [['Агент', 2]]);
    assert.equal(events.at(-1).data.status, 'COMPLETED');
  });

  test('прогон без единого начатого узла 5 мин от отправки run — одна строка в журнал (очередь или прогон-сирота)', async () => {
    const { generator } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: (t) => listOf(t < 15 * 60_000 ? 'running' : 'completed'),
      [DETAIL_PATH]: (t) => (t < 15 * 60_000 ? { status: 'running' } : { status: 'completed', result: 'итог', steps: [] }),
    });
    const events = await collect(generator);
    const stuck = notices(events).filter((m) => m.startsWith('Прогон '));
    assert.equal(stuck.length, 1);
    assert.match(stuck[0], /^Прогон [5-7] мин не начал ни одного узла/);
    assert.equal(RUN_NO_STEPS_NOTICE_MS, 5 * 60_000);
    assert.equal(runNoStepsMessage(5), stuck[0].replace(/\d+/, '5'));
    assert.equal(events.at(-1).data.status, 'COMPLETED');
  });

  test('8 ч без итогового статуса — CONNECTION_LOST о лимите слежения; детали редко', async () => {
    const { generator, calls } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [listOf('running')],
      [DETAIL_PATH]: [{ status: 'running', steps: [step('s1', 'a1', 'running')] }],
    });
    const events = await collect(generator);
    assert.deepEqual(events.at(-1), { type: CONNECTION_LOST_TYPE, error: RUN_POLL_TIMEOUT_MESSAGE, data: { run_id: RUN } });
    const lists = count(calls, RUNS_PATH);
    assert.ok(Math.abs(lists - RUN_POLL_MAX_DURATION_MS / RUN_POLL_INTERVAL_MS) <= 2, String(lists));
    // неизменный ответ — раз в 120 с
    assert.ok(count(calls, DETAIL_PATH) <= RUN_POLL_MAX_DURATION_MS / RUN_POLL_DETAIL_MAX_INTERVAL_MS + 3);
    // живые бейджи: NODE_STATUS агента — один раз за все 8 ч
    assert.equal(byType(events, 'NODE_STATUS').length, 1);
  });

  test('закрытие панели: опрос прерывается ошибкой AbortError без записей о сбое', async () => {
    const { generator, ctl } = harness({
      [SCENARIO_PATH]: [scenarioResponse],
      [RUNS_PATH]: [listOf('running')],
      [DETAIL_PATH]: [{ status: 'running', steps: [] }],
    });
    ctl.abortOnCall = 4; // второй запрос списка
    const seen = [];
    await assert.rejects(
      (async () => {
        for await (const event of generator) seen.push(event);
      })(),
      (error) => error.name === 'AbortError',
    );
    assert.deepEqual(notices(seen), [RUN_POLL_START_MESSAGE]);
    assert.equal(byType(seen, CONNECTION_LOST_TYPE).length, 0);
  });

  test('пошаговый режим: сервер при обрыве снял паузу и режим — кадр для раннера, без STEP_PAUSED, детали с обычным периодом', async () => {
    const state = createRunFollowState();
    // по сокету до обрыва: вход выполнен, пауза после него
    trackRunEvent(state, { type: 'NODE_STATUS', data: { node_id: 'v0', node_label: 'Вход', status: 'COMPLETED' } });
    trackRunEvent(state, { type: 'STEP_COMPLETE', data: { node_id: 'v0', step_id: 's0' } });
    trackRunEvent(state, { type: 'STEP_PAUSED', data: { node_id: 'v0', node_label: 'Вход' } });
    const paused = { status: 'running', steps: [step('s0', 'v0', 'completed'), step('s1', 'a1', 'completed')] };
    const { generator, calls } = harness(
      {
        [SCENARIO_PATH]: [scenarioResponse],
        [RUNS_PATH]: (t) => listOf(t < 300_000 ? 'running' : 'completed'),
        [DETAIL_PATH]: (t) => (t < 300_000 ? paused : { ...paused, status: 'completed', result: 'итог' }),
      },
      { stepMode: true, state },
    );
    const events = await collect(generator);
    assert.deepEqual(events[1], {
      type: RUN_POLL_NOTICE_TYPE,
      data: { message: RUN_POLL_STEP_MODE_MESSAGE, step_mode_off: true, node_id: 'v0', status: 'completed' },
    });
    assert.ok(!RUN_POLL_STEP_MODE_MESSAGE.includes('30 мин'));
    assert.equal(byType(events, 'STEP_PAUSED').length, 0);
    // 30 опросов списка, детали — 0, 30, 90, 210 с и итог
    assert.equal(count(calls, RUNS_PATH), 31);
    assert.equal(count(calls, DETAIL_PATH), 5);
    assert.equal(events.at(-1).data.status, 'COMPLETED');
  });

  test('пошаговый режим без паузы до обрыва: кадр о снятом режиме без узла', async () => {
    const { generator } = harness(
      {
        [SCENARIO_PATH]: [scenarioResponse],
        [RUNS_PATH]: [listOf('completed')],
        [DETAIL_PATH]: [{ status: 'completed', steps: [] }],
      },
      { stepMode: true },
    );
    const events = await collect(generator);
    assert.deepEqual(events[1].data, {
      message: RUN_POLL_STEP_MODE_MESSAGE,
      step_mode_off: true,
      node_id: undefined,
      status: undefined,
    });
  });

  test('тексты журнала и баннера — без обещаний, которых сервер не выполняет', () => {
    assert.ok(!RUN_POLL_START_MESSAGE.includes('прокси —'));
    assert.match(RUN_POLL_START_MESSAGE, /шаги — раз в 30–120 с/);
    assert.match(RUN_NOT_FOUND_MESSAGE, /не найден/);
    assert.ok(!RUN_NOT_FOUND_MESSAGE.includes('продолжается'));
    assert.match(runPollRejectedMessage('x', null), /список прогонов сценария/);
    assert.match(runPollRejectedMessage('x', RUN), /«Подробный отчёт»/);
    assert.equal(RUN_POLL_DETAIL_INTERVAL_MS, 3 * RUN_POLL_INTERVAL_MS);
  });
});
