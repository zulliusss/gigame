// Загрузка партиями при отказе шлюза 403 без JSON (src/api/uploadSplit.ts, corp17).
// Запуск из корня фронта: node --test tests/uploadSplit.test.mjs

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';

import {
  GATEWAY_FORBIDDEN,
  PayloadTooLargeError,
  isGatewayRejection,
  totalBytes,
  uploadAdaptive,
} from '../src/api/uploadSplit.ts';

function files(n, size = 1000) {
  return Array.from({ length: n }, (_, i) => new File([new Uint8Array(size)], `doc${i + 1}.pdf`));
}

/** Шлюз: 403 на любую партию, где есть файл из bad; принятые файлы копятся по порядку. */
function gateway(bad, { forbidAll = false } = {}) {
  const accepted = [];
  const calls = [];
  const send = async (batch, append) => {
    const ok = !(forbidAll || batch.some((f) => bad.includes(f.name)));
    calls.push({ names: batch.map((f) => f.name), append, ok });
    if (!ok) {
      throw new PayloadTooLargeError(totalBytes(batch), GATEWAY_FORBIDDEN);
    }
    accepted.push(...batch.map((f) => f.name));
  };
  return { send, accepted, calls };
}

describe('isGatewayRejection', () => {
  test('403 без JSON — отказ шлюза, 403 с JSON бэкенда — нет', () => {
    assert.equal(isGatewayRejection(403, '<html>403 Forbidden</html>'), true);
    assert.equal(isGatewayRejection(403, '{"statusCode":403,"message":"нет доступа"}'), false);
    assert.equal(isGatewayRejection(502, ''), true);
    assert.equal(isGatewayRejection(400, '<html></html>'), false);
  });
});

describe('uploadAdaptive при 403', () => {
  test('файл, который шлюз не пропускает, пропускается, остальные загружаются', async () => {
    const all = files(64);
    const { send, accepted, calls } = gateway(['doc37.pdf']);
    const log = [];
    await uploadAdaptive(all, send, (m) => log.push(m));
    assert.deepEqual(accepted, all.map((f) => f.name).filter((n) => n !== 'doc37.pdf'));
    assert.equal(calls[0].names.length, 64);
    assert.equal(calls.filter((c) => c.ok && !c.append).length, 1, 'одна замещающая партия');
    assert.ok(log.some((m) => m.includes('«doc37.pdf»') && m.includes('пропущен')));
    assert.ok(log.at(-1).includes('не пропустил 1 файл(ов): «doc37.pdf»'));
  });

  test('первая принятая партия заменяет кэш, остальные — добавляются', async () => {
    const { send, calls } = gateway(['doc1.pdf']);
    await uploadAdaptive(files(4), send, () => {});
    const ok = calls.filter((c) => c.ok);
    assert.equal(ok[0].append, false);
    assert.ok(ok.slice(1).every((c) => c.append));
  });

  test('два плохих файла — оба названы, число попыток конечно', async () => {
    const { send, accepted, calls } = gateway(['doc2.pdf', 'doc9.pdf']);
    const log = [];
    await uploadAdaptive(files(10), send, (m) => log.push(m));
    assert.equal(accepted.length, 8);
    assert.ok(calls.length < 30, `попыток ${calls.length}`);
    assert.ok(log.at(-1).includes('«doc2.pdf», «doc9.pdf»'));
  });

  test('403 на каждый файл — ошибка про сессию, а не молчаливая пустая загрузка', async () => {
    const { send } = gateway([], { forbidAll: true });
    await assert.rejects(uploadAdaptive(files(5), send, () => {}), /на каждый из 5 файл/);
  });

  test('без отказов — одна партия и ни одной записи в журнал', async () => {
    const { send, calls } = gateway([]);
    const log = [];
    await uploadAdaptive(files(20), send, (m) => log.push(m));
    assert.equal(calls.length, 1);
    assert.deepEqual(log, []);
  });
});
