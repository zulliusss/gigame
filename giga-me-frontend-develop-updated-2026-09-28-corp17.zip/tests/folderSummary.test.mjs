// Проверки строки журнала при загрузке папки (src/api/folderSummary.ts).
// Без тест-раннера и зависимостей: node >= 22.18 / 23.6 снимает типы с .ts сам.
// Запуск из корня фронта: node --test tests/folderSummary.test.mjs

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';

import { describeFolderUpload, summarizeFolder } from '../src/api/folderSummary.ts';

function file(relativePath) {
  const f = new File(['x'], relativePath.split('/').pop());
  Object.defineProperty(f, 'webkitRelativePath', { value: relativePath });
  return f;
}

const ROOT = '1. Сбер Договор №4887385 от 27.02.2024';

describe('summarizeFolder', () => {
  test('корневая папка комплекта: имя и число подпапок с файлами', () => {
    const files = [
      file(`${ROOT}/88618_4887385_27.02.2024.pdf`),
      file(`${ROOT}/Заявка № 5228374 от 12.02.2025/0346_25.03.2025.pdf`),
      file(`${ROOT}/Заявка № 5228374 от 12.02.2025/100774_4887385-5228374.pdf`),
      file(`${ROOT}/Заявка № 5231343 от 14.02.2025/0347_25.03.2025.pdf`),
      file(`${ROOT}/Заявка № 5231343 от 14.02.2025/Отчёты/отчёт.pdf`),
    ];
    assert.deepEqual(summarizeFolder(files), { root: ROOT, subfolders: 3 });
  });

  test('выбрана подпапка (окно выбора Windows): видно её имя и ноль подпапок', () => {
    const files = [
      file('Заявка № 5228374 от 12.02.2025/0346_25.03.2025.pdf'),
      file('Заявка № 5228374 от 12.02.2025/100774_4887385-5228374.pdf'),
    ];
    assert.deepEqual(summarizeFolder(files), { root: 'Заявка № 5228374 от 12.02.2025', subfolders: 0 });
  });

  test('файлы без относительного пути (выбраны не папкой)', () => {
    assert.deepEqual(summarizeFolder([new File(['x'], 'акт.pdf')]), { root: '', subfolders: 0 });
  });
});

describe('describeFolderUpload', () => {
  test('строка журнала с именем папки', () => {
    assert.equal(describeFolderUpload({ root: ROOT, subfolders: 30 }, 61),
      `Из папки «${ROOT}» (подпапок: 30) добавлено 61 файл(ов)`);
  });

  test('без имени папки', () => {
    assert.equal(describeFolderUpload({ root: '', subfolders: 0 }, 2), 'Из папки (подпапок: 0) добавлено 2 файл(ов)');
  });
});
