// Какая папка выбрана кнопкой «+ Папка» и сколько в ней подпапок.
//
// Окно выбора папки Windows загружает папку, выделенную в списке: если зайти в папку комплекта, а там выделена первая
// подпапка, загрузится только она (письмо Борисова 25.09.2026: из «1. Сбер Договор №4887385 от 27.02.2024» ушли два
// файла первой подпапки «Заявка № …»). Имя выбранной папки и число подпапок в журнале загрузки делают такую ошибку
// видимой сразу, до запуска.

export interface FolderSummary {
  /** Имя выбранной папки (первый сегмент относительного пути файлов); пусто, если путей нет. */
  root: string;
  /** Число подпапок любой глубины, в которых есть файлы. */
  subfolders: number;
}

function segments(file: File): string[] {
  return (file.webkitRelativePath ?? '').split(/[\\/]/).filter(Boolean);
}

/** Имя выбранной папки и число её подпапок с файлами — по относительным путям файлов («Корень/Заявка 1/акт.pdf»). */
export function summarizeFolder(files: File[]): FolderSummary {
  const dirs = new Set<string>();
  let root = '';
  for (const file of files) {
    const parts = segments(file);
    if (parts.length < 2) {
      continue;
    }
    root = root || parts[0];
    for (let depth = 2; depth < parts.length; depth++) {
      dirs.add(parts.slice(0, depth).join('/'));
    }
  }
  return { root, subfolders: dirs.size };
}

/** Начало строки журнала: «Из папки «1. Сбер Договор …» (подпапок: 30) добавлено 61 файл(ов)». */
export function describeFolderUpload(summary: FolderSummary, added: number): string {
  const name = summary.root ? ` «${summary.root}»` : '';
  return `Из папки${name} (подпапок: ${summary.subfolders}) добавлено ${added} файл(ов)`;
}
