import { ApiError, fetchApi, apiErrorFromResponse, errorMessageFromBody } from './client';
import { BASE_URL} from './constants';
import { getScenarioWebSocketClient, type StreamEvent, type StreamEventCallback } from './websocket';
import {
  INITIAL_BATCH_BYTES,
  PayloadTooLargeError,
  isGatewayRejection,
  totalBytes,
  uploadAdaptive,
} from './uploadSplit';
import { limitGraphForGateway } from './graphLimits';
import { isTerminalRunEvent } from './runEvents';
import {
  RUN_POLL_SILENT_SOCKET_MESSAGE,
  createRunFollowState,
  followRunByRest,
  isTerminalRunStatus,
  runStatusInList,
  trackRunEvent,
  type PolledRunSummary,
} from './runPolling';

/** Дедлайн ожидания открытия WebSocket прогона. */
const WS_CONNECT_TIMEOUT_MS = 15_000;
/** Тишина сокета прогона, после которой прогон проверяется лёгким списком (полуоткрытое соединение). */
const WS_SILENCE_CHECK_MS = 3 * 60 * 1000;
/** Пауза перед повтором отправки партии после сетевого сбоя. */
const UPLOAD_STATUS_RETRY_PAUSE_MS = 3_000;
/**
 * Опрос upload-status: пока счётчик документов растёт — каждые 2 с; без изменений минуту — каждые 10 с,
 * пять минут — каждые 30 с. Многостраничные сканы распознаются постранично (десятки минут на документ),
 * и частый опрос всё это время только кормит счётчики WAF (23.09.2026: после ~500 опросов подряд
 * SOWA стал отвечать 403 без JSON, и загрузка «упала», хотя разбор на сервере шёл).
 */
const UPLOAD_POLL_FAST_MS = 2_000;
const UPLOAD_POLL_SLOW_MS = 10_000;
const UPLOAD_POLL_IDLE_MS = 30_000;
const UPLOAD_POLL_SLOW_AFTER_MS = 60_000;
const UPLOAD_POLL_IDLE_AFTER_MS = 5 * 60 * 1000;
/**
 * Сбой опроса (сеть, 502/403 шлюза, HTML вместо JSON) не роняет загрузку: разбор идёт на сервере
 * независимо от опроса. Повторы — с растущей паузой до 30 с, пока не вышел общий дедлайн партии;
 * подсказка про сессию — если шлюз отвечает 401/403 дольше трёх минут подряд.
 */
const UPLOAD_STATUS_RETRY_MAX_PAUSE_MS = 30_000;
const UPLOAD_STATUS_SESSION_HINT_MS = 3 * 60 * 1000;
/**
 * Дедлайн разбора партии — по отсутствию прогресса, а не по числу файлов: партия из 23 сканов
 * (23.09.2026) разбиралась по 1–5 мин на документ и упёрлась в прежние «2 мин на файл», хотя сервер
 * работал (17 из 23). Прогресс — рост счётчика документов, новое предупреждение или ход OCR по страницам
 * (corp20 отдаёт его в поле error во время processing). Общий предел — на случай зависшего разбора.
 */
const UPLOAD_STALL_MS = 25 * 60 * 1000;
const UPLOAD_HARD_CAP_MS = 8 * 60 * 60 * 1000;

/** Размер партии загрузки, который прошёл шлюз корп-контура (уменьшается после 413, живёт до перезагрузки страницы). */
let gatewayBatchBytes = INITIAL_BATCH_BYTES;

export interface Scenario {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
  /** Общий сценарий: виден и доступен всем пользователям */
  shared?: boolean;
  /** Текущий пользователь — владелец */
  is_owner?: boolean;
  /** Средний рейтинг 1..5 (null — оценок нет) */
  rating_avg?: number | null;
  /** Количество оценок */
  rating_count?: number;
  /** Оценка текущего пользователя */
  my_rating?: number | null;
  /** Количество запусков */
  runs_count?: number;
}

export interface ScenarioDetail extends Scenario {
  graph_data: {
    nodes: ScenarioNode[];
    edges: ScenarioEdge[];
  };
}

export interface ScenarioNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  data: Record<string, string>;
}

export interface ScenarioEdge {
  id: string;
  source: string;
  target: string;
}

// списковый GET /runs больше не возвращает result — полный результат
// только в детальной ручке GET /runs/{id} (экономия трафика через SOWA)
export interface ScenarioRun {
  id: string;
  scenario_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  input_document_ids: string[];
  started_at: string | null;
  completed_at: string | null;
}

export interface ScenarioRunStep {
  id: string;
  node_id: string;
  node_type: string;
  status: string;
  input_data: unknown;
  output_data: unknown;
  prompt_used: string | null;
  tokens_used: number | null;
  started_at: string | null;
  completed_at: string | null;
}

export interface ScenarioRunDetail extends ScenarioRun {
  result: { output: string } | null;
  steps: ScenarioRunStep[];
}

export function getScenarios(): Promise<Scenario[]> {
  return fetchApi('/scenarios');
}

export function getScenario(id: string): Promise<ScenarioDetail> {
  return fetchApi(`/scenarios/${id}`);
}

export function createScenario(
  name: string,
  description?: string,
  graphData?: unknown,
): Promise<Scenario> {
  return fetchApi('/scenarios', {
    method: 'POST',
    body: JSON.stringify({
      name,
      // пустое описание не отправляется: null шлюз может не пропустить, бэкенд трактует отсутствие ключа так же
      ...(description ? { description } : {}),
      graph_data: limitGraphForGateway(graphData || { nodes: [], edges: [] }),
    }),
  });
}

export function updateScenario(
  id: string,
  data: { name?: string; description?: string; graph_data?: unknown; shared?: boolean },
): Promise<Scenario> {
  // позиции/размеры узлов и температура — в пределах схемы шлюза SOWA, иначе PUT отклоняется целиком
  const body = data.graph_data === undefined ? data : { ...data, graph_data: limitGraphForGateway(data.graph_data) };
  return fetchApi(`/scenarios/${id}`, {
    method: 'PUT',
    body: JSON.stringify(body),
  });
}

export function rateScenario(id: string, rating: number): Promise<void> {
  return fetchApi(`/scenarios/${id}/rating`, {
    method: 'POST',
    body: JSON.stringify({ rating }),
  });
}

export function duplicateScenario(id: string): Promise<Scenario> {
  return fetchApi(`/scenarios/${id}/duplicate`, { method: 'POST' });
}

export function deleteScenario(id: string): Promise<void> {
  return fetchApi(`/scenarios/${id}`, { method: 'DELETE' });
}

export function getScenarioRuns(scenarioId: string): Promise<ScenarioRun[]> {
  return fetchApi(`/scenarios/${scenarioId}/runs`);
}

export function getScenarioRun(runId: string): Promise<ScenarioRunDetail> {
  return fetchApi(`/scenarios/runs/${runId}`);
}

export function continueScenarioStep(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/continue`, { method: 'POST' });
}

export interface ScenarioVersionMeta {
  version_no: number;
  name: string;
  created_at: string;
}

export function getScenarioVersions(id: string): Promise<ScenarioVersionMeta[]> {
  return fetchApi(`/scenarios/${id}/versions`);
}

export function restoreScenarioVersion(id: string, versionNo: number): Promise<Scenario> {
  return fetchApi(`/scenarios/${id}/versions/${versionNo}/restore`, { method: 'POST' });
}


/**
 * Возобновление упавшего прогона по WebSocket (команда type=resume):
 * возвращает id нового прогона из первого события. Выполнение идёт на сервере
 * независимо от соединения — после получения id сокет закрывается.
 */
export function resumeScenarioRun(runId: string): Promise<string | null> {
  const client = getScenarioWebSocketClient();
  return new Promise<string | null>((resolve, reject) => {
    let settled = false;
    const finish = (value: string | null, err?: Error) => {
      if (settled) return;
      settled = true;
      client.setOnMessage(null);
      client.disconnect();
      if (err) reject(err);
      else resolve(value);
    };
    client.setOnMessage(((event: Record<string, unknown>) => {
      const data = (event.data ?? {}) as Record<string, unknown>;
      if (typeof data.run_id === 'string') {
        finish(data.run_id);
      } else if (event.error || data.error) {
        finish(null, new Error(String(event.error ?? data.error)));
      }
    }) as StreamEventCallback);
    client.connect();
    // send ставит сообщение в очередь до открытия сокета
    client.send({ type: 'resume', run_id: runId } as unknown as StreamEvent);
    // если id не пришёл — возобновление всё равно могло запуститься; вернём null,
    // вызывающий код предложит обновить список прогонов
    setTimeout(() => finish(null), 30000);
  });
}

export function disableScenarioStepMode(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/disable-step-mode`, { method: 'POST' });
}

/** Остановить выполняющийся прогон: прерывается на границе текущего узла. */
export function cancelScenarioRun(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/cancel`, { method: 'POST' });
}

/**
 * Отмена фонового разбора загруженных файлов (крестик во время загрузки): прерывание запросов
 * браузера бэкенд не останавливает — он дорабатывал принятую партию, и новая загрузка в сценарий
 * упиралась в «обрабатывается». Без активной задачи вызов ничего не делает.
 */
export function cancelScenarioUpload(scenarioId: string): Promise<void> {
  return fetchApi(`/scenarios/${scenarioId}/upload-cancel`, { method: 'POST' });
}

/** Скачать файл файлового выхода: WS-кадр несёт только file_ready, байты — здесь. */
export async function downloadScenarioRunFile(runId: string, nodeId: string): Promise<Blob> {
  const res = await fetch(`${BASE_URL}/scenarios/runs/${runId}/files/${encodeURIComponent(nodeId)}`);
  if (!res.ok) {
    throw await apiErrorFromResponse(res);
  }
  return res.blob();
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/** Ошибка прерывания прогона пользователем (закрытие панели): раннер её не показывает. */
function abortError(): Error {
  const error = new Error('Прогон прерван');
  error.name = 'AbortError';
  return error;
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

/** Ожидание открытия сокета с дедлайном: без него зависший handshake держал фазу «Загрузка» навсегда. */
function waitForConnection(
  client: ReturnType<typeof getScenarioWebSocketClient>,
  timeoutMs: number,
): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    const deadline = Date.now() + timeoutMs;
    const checkConnection = () => {
      const ws = client.getWs();
      if (client.isConnected()) {
        resolve();
      } else if (ws === null || ws.readyState === WebSocket.CLOSING || ws.readyState === WebSocket.CLOSED) {
        reject(new Error('WebSocket connection closed before established'));
      } else if (Date.now() > deadline) {
        reject(new Error(`сервер не открыл соединение за ${Math.round(timeoutMs / 1000)} с`));
      } else {
        setTimeout(checkConnection, 10);
      }
    };
    checkConnection();
  });
}

/** Пауза опроса, прерываемая закрытием панели: размонтированный раннер не ждёт до минуты. */
function sleepUnlessAborted(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) {
      reject(abortError());
      return;
    }
    const onAbort = () => {
      clearTimeout(timer);
      reject(abortError());
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

export async function* runScenario(
  scenarioId: string,
  files: File[],
  stepMode: boolean = false,
  signal?: AbortSignal,
): AsyncGenerator<Record<string, unknown>> {
  const client = getScenarioWebSocketClient();

  let cleanupDone = false;

  // Set up handlers before connecting
  const queue: Record<string, unknown>[] = [];

  const notify = (message: string) => {
    queue.push({ type: 'upload_processing', data: { type: 'upload_processing', message } });
  };

  // Хвосты СТАРОГО прогона (например, отложенная отмена, сработавшая на
  // границе узла) приходят в тот же WS-канал и раньше помечали живой новый
  // прогон «завершился с ошибкой». Фильтр: события до команды run — чужие;
  // после — STATUS с run_id другого прогона отбрасывается.
  let runSent = false;
  let myRunId: string | null = null;
  // Слежение по REST после обрыва: момент отправки run (поиск прогона без
  // run_id) и то, что уже показано по сокету (кадры опроса — только изменения)
  let runSentAt = 0;
  let connectionLost = false;
  const followState = createRunFollowState();
  // Сторож полуоткрытого сокета: время последнего кадра, проверка в полёте, итог проверки
  let lastFrameAt = 0;
  let silenceCheckActive = false;
  let socketSilent = false;

  // Освобождение сокета: терминальный STATUS (COMPLETED/FAILED), кадр ошибки
  // без type, обрыв или ошибка — сокет закрывается, обработчики снимаются.
  // Кадры признака done не несут (ScenarioWebSocketHandler.createStreamEvent),
  // раньше генератор ждал его вечно, а сокеты копились до перезагрузки.
  const finish = () => {
    if (cleanupDone) return;
    cleanupDone = true;
    client.setOnMessage(null);
    client.setOnClose(null);
    client.disconnect();
  };

  const handleMessage = (event: Record<string, unknown>) => {
      console.log("Received message:", event);
    lastFrameAt = Date.now();
    const data = (event.data ?? {}) as Record<string, unknown>;
    if (!runSent) {
      return; // события, пришедшие до нашей команды run — хвост старого прогона
    }
    const evRunId = typeof data.run_id === 'string' ? data.run_id : null;
    if (evRunId && myRunId === null) {
      myRunId = evRunId;
    }
    if (evRunId && myRunId && evRunId !== myRunId) {
      return; // событие другого прогона
    }
    trackRunEvent(followState, event);
    queue.push(event);
    if (isTerminalRunEvent(event)) {
      finish();
    }
  };

  // Обрыв сокета во время активного прогона (прокси корп-контура закрывает
  // соединение через 300 с): сервер продолжает выполнение, поток событий к этому
  // сокету потерян — после выдачи очереди генератор следит за прогоном по REST
  // (followRunByRest); автопереподключение для сценарного клиента отключено:
  // новый сокет к потоку прогона не привязан, а повторный run запустил бы второй прогон
  const handleClose = () => {
    if (cleanupDone || !runSent) return;
    connectionLost = true;
    finish();
  };

  // Соединение умерло без события close (сон ноутбука, смена сети): после команды run
  // клиент ничего не шлёт и обрыв не замечает. После 3 мин без кадров прогон проверяется
  // лёгким списком: завершён на сервере — сокет закрывается, итог добирается по REST;
  // ещё идёт или список не прошёл — следующая проверка через 3 мин
  const checkSilentSocket = () => {
    const runId = myRunId;
    if (silenceCheckActive || cleanupDone || !runId || Date.now() - lastFrameAt < WS_SILENCE_CHECK_MS) return;
    silenceCheckActive = true;
    fetchApi<PolledRunSummary[] | undefined>(`/scenarios/${scenarioId}/runs`, { signal, cache: 'no-store' })
      .then((runs) => {
        if (!cleanupDone && isTerminalRunStatus(runStatusInList(runs, runId))) {
          socketSilent = true;
          connectionLost = true;
          finish();
        }
      })
      .catch(() => undefined)
      .finally(() => {
        silenceCheckActive = false;
        lastFrameAt = Date.now();
      });
  };

  client.setOnMessage(handleMessage as StreamEventCallback);
  client.setOnClose(handleClose);

  // Connect if not already connected
  client.connect();

  try {
    await waitForConnection(client, WS_CONNECT_TIMEOUT_MS);
  } catch (error) {
    console.error('WebSocket connect error:', error);
    client.setOnMessage(null);
    client.setOnClose(null);
    throw new Error(
      `Не удалось подключиться к серверу${error instanceof Error ? `: ${error.message}` : ''}`,
    );
  }

  try {
    // Загрузка идёт параллельно с выдачей событий: ход разбора (upload_processing,
    // upload_warning) попадает в журнал сразу, а не после окончания загрузки —
    // на комплекте сканов (30 минут) журнал раньше молчал до самого конца.
    if (files && files.length > 0) {
      let uploadDone = false;
      let uploadError: unknown = null;
      uploadFiles(scenarioId, files)
        .then(() => {
          queue.push({ type: 'UPLOAD_DONE', count: files.length.toString() });
        })
        .catch((error: unknown) => {
          uploadError = error;
        })
        .finally(() => {
          uploadDone = true;
        });
      while (!uploadDone || queue.length > 0) {
        throwIfAborted(signal);
        if (queue.length > 0) {
          yield queue.shift()!;
        } else {
          await sleep(50);
        }
      }
      if (uploadError) {
        throw uploadError;
      }
    }

    // панель закрыта во время загрузки — команда run не отправляется
    throwIfAborted(signal);

    // сокет мог закрыться за время долгой загрузки (таймаут бездействия
    // шлюза) — переподключаемся до команды run, а не полагаемся на очередь
    if (!client.isConnected()) {
      client.connect();
      await waitForConnection(client, WS_CONNECT_TIMEOUT_MS);
    }

    // Send run request via WebSocket
    runSent = true;
    runSentAt = Date.now();
    lastFrameAt = runSentAt;
    client.send({
      scenario_id: scenarioId,
//       files: formData,
      step_mode: stepMode,
    } as StreamEvent);

    // Yield events as they arrive
    while (!cleanupDone || queue.length > 0) {
      throwIfAborted(signal);
      if (queue.length > 0) {
        yield queue.shift()!;
      } else {
        checkSilentSocket();
        // Wait a bit before checking again
        await sleep(10);
      }
    }

    // сокет оборван прокси — дальше прогон ведётся опросом REST (runPolling.ts):
    // кадры того же вида до итогового STATUS; сокет не переоткрывается, run не повторяется
    if (connectionLost) {
      yield* followRunByRest(
        {
          scenarioId,
          runId: myRunId,
          runSentAt,
          state: followState,
          // молчащий сокет закрыт после итога на сервере: о паузе и 10-секундном опросе не пишем
          stepMode: stepMode && !socketSilent,
          startNotice: socketSilent ? RUN_POLL_SILENT_SOCKET_MESSAGE : undefined,
        },
        {
          // ответы без Cache-Control: промежуточный прокси не должен отдать прежнее состояние
          getJson: (path) => fetchApi<unknown>(path, { signal, cache: 'no-store' }),
          sleep: (ms) => sleepUnlessAborted(ms, signal),
          throwIfAborted: () => throwIfAborted(signal),
        },
      );
    }
  } catch (error) {
    if (!(error instanceof Error && error.name === 'AbortError')) {
      console.error('Stream error:', error);
    }
    finish();
    throw error;
  } finally {
    // Ensure cleanup happens
    try {
      finish();
    } catch {
      // Ignore errors during cleanup
    }
  }
  // Upload files to the server and return document IDs.
  // Асинхронный режим: запрос лишь принимает байты (секунды — шлюзовые
  // таймауты не срабатывают), разбор идёт в фоне, прогресс опрашивается
  // короткими запросами upload-status. Лимиты на ОДИН запрос: у бэкенда —
  // 100 файлов и 100 МБ тела (max-request-size); у прокси корп-контура — свой
  // лимит тела, неизвестный фронту (SynGX отвечает 413, WAF SOWA — страницей 502).
  // Партии до 30 МБ и 100 файлов; на такой отказ партия делится, одиночный ZIP
  // режется на части (uploadSplit.ts), найденный размер запоминается до перезагрузки страницы.
  // Первая партия заменяет кэш документов, последующие уходят с append=true.
  async function uploadFiles(
    scenarioId: string,
    files: File[]
  ): Promise<void> {
    // Незавершённый разбор прошлой партии (долгий OCR, оборванная попытка): бэкенд отвечает 422 «обрабатывается»,
    // не читая тело, а WAF SOWA превращает такой ранний ответ в свою страницу 502 (пром, 23.09.2026) — фронт
    // 422 не видит. Поэтому освобождения ждём ДО первой партии одним запросом upload-status, а не после 422.
    await waitUploadIdle(scenarioId);
    gatewayBatchBytes = await uploadAdaptive(
      files,
      (batch, append) => uploadBatch(scenarioId, batch, append),
      notify,
      gatewayBatchBytes,
    );
  }

  // Прерванная попытка (обрыв сети, отказ шлюза на одной из партий) оставляет
  // фоновый разбор прошлой партии работать — повторный клик «Запустить» ловил
  // 422 «Предыдущая загрузка ещё обрабатывается». Ждём освобождения сами.
  async function waitUploadIdle(scenarioId: string): Promise<void> {
    const deadline = Date.now() + 10 * 60 * 1000;
    while (Date.now() < deadline) {
      throwIfAborted(signal);
      try {
        const statusResponse = await fetch(BASE_URL + `/scenarios/${scenarioId}/upload-status`, { signal });
        if (statusResponse.ok) {
          const status = (await statusResponse.json()) as { status: string };
          if (status.status !== 'processing') {
            return;
          }
          notify('ожидание завершения предыдущей загрузки…');
        }
      } catch (error) {
        // сбой сети/шлюза (в т.ч. HTML вместо JSON) — ждём и опрашиваем снова
        if (signal?.aborted) throw error;
      }
      await sleep(2000);
    }
    throw new Error('Предыдущая загрузка документов не завершилась за 10 минут');
  }

  async function uploadBatch(
    scenarioId: string,
    files: File[],
    append: boolean
  ): Promise<void> {
    const formData = new FormData();
    formData.append('content', ''); // Empty content placeholder
    for (const file of files) {
      formData.append('files', file);
    }

    const query = append ? '?async=true&append=true' : '?async=true';
    const post = () =>
      fetch(BASE_URL + `/scenarios/${scenarioId}/upload${query}`, {
        method: 'POST',
        body: formData,
        signal,
      });
    let response: Response;
    try {
      response = await post();
    } catch (error) {
      // сетевой сбой первой партии: append=false заменяет кэш — повтор безопасен;
      // добавочную партию не повторяем (документы могли уже попасть в кэш)
      if (append || signal?.aborted) throw error;
      notify('сетевой сбой при отправке партии — повтор через 3 с…');
      await sleep(UPLOAD_STATUS_RETRY_PAUSE_MS);
      response = await post();
    }

    if (response.status === 422) {
      const busyText = await response.clone().text();
      if (busyText.includes('обрабатывается')) {
        await waitUploadIdle(scenarioId);
        response = await post();
      }
    }

    if (response.status === 413) {
      // прокси отклонил тело по размеру ещё до бэкенда — кэш не тронут, партию можно переслать частями
      throw new PayloadTooLargeError(totalBytes(files));
    }

    if (!response.ok) {
      // бэкенд кладёт причину (лимит документов, битый архив и т.п.) в тело —
      // без неё пользователь видит голый код и не может понять, что чинить;
      // HTML-страница шлюза вместо JSON — «Шлюз вернул N без JSON»
      let detail = '';
      let text = '';
      try {
        text = await response.text();
        detail = errorMessageFromBody(response.status, response.statusText, text);
      } catch {
        // тело недоступно — остаётся только код
      }
      if (isGatewayRejection(response.status, text)) {
        // WAF SOWA на партию 30 МБ отвечает страницей 502, а не 413 (пром, 23.09.2026): до бэкенда запрос
        // не дошёл, а если дошёл — догрузка отбрасывает дубли; партию можно переслать частями, как при 413
        throw new PayloadTooLargeError(totalBytes(files), response.status);
      }
      throw new Error(
        `Ошибка загрузки (${response.status})${detail ? `: ${detail.slice(0, 300)}` : ''}`
      );
    }

    // Поллинг фоновой задачи разбора до done/failed: сбой одного опроса
    // (сеть, 502 шлюза, HTML вместо JSON) повторяется, дедлайн — по отсутствию прогресса
    const startedAt = Date.now();
    let lastWarnings = 0;
    let lastMessage = '';
    let failures = 0;
    let failingSince = 0;
    let lastProgress = '';
    let lastProgressAt = Date.now();
    for (;;) {
      throwIfAborted(signal);
      const stalled = Date.now() - lastProgressAt;
      if (stalled > UPLOAD_STALL_MS || Date.now() - startedAt > UPLOAD_HARD_CAP_MS) {
        throw new Error(
          `Разбор партии из ${files.length} файл(ов) не продвигается ${Math.round(stalled / 60000)} мин — ` +
            'проверьте состояние загрузки (upload-status) и запустите прогон снова'
        );
      }
      const quiet = Date.now() - lastProgressAt;
      await sleep(
        quiet > UPLOAD_POLL_IDLE_AFTER_MS ? UPLOAD_POLL_IDLE_MS : quiet > UPLOAD_POLL_SLOW_AFTER_MS ? UPLOAD_POLL_SLOW_MS : UPLOAD_POLL_FAST_MS
      );
      // ответ строго по схеме UploadStatusResponse: во время processing documents — разобрано документов партии
      let status: {
        status: string;
        files: number;
        documents: number;
        warnings?: string[];
        error?: string;
      };
      try {
        const statusResponse = await fetch(BASE_URL + `/scenarios/${scenarioId}/upload-status`, { signal });
        if (!statusResponse.ok) {
          throw await apiErrorFromResponse(statusResponse);
        }
        status = await statusResponse.json();
      } catch (error) {
        if (signal?.aborted) throw error;
        failures++;
        if (failingSince === 0) failingSince = Date.now();
        const reason = error instanceof Error ? error.message : String(error);
        const pause = Math.min(UPLOAD_STATUS_RETRY_MAX_PAUSE_MS, UPLOAD_STATUS_RETRY_PAUSE_MS * 2 ** Math.min(failures - 1, 4));
        const denied = error instanceof ApiError && (error.status === 401 || error.status === 403);
        const hint =
          denied && Date.now() - failingSince > UPLOAD_STATUS_SESSION_HINT_MS
            ? ' Шлюз не пускает опрос дольше трёх минут — возможно, истекла сессия: обновите страницу; разбор на сервере продолжается, его состояние покажет upload-status'
            : '';
        notify(`сбой опроса состояния загрузки (${reason}) — повтор ${failures} через ${Math.round(pause / 1000)} с…${hint}`);
        await sleep(pause);
        continue;
      }
      failures = 0;
      failingSince = 0;
      const warnings = status.warnings ?? [];
      // прогресс: документ разобран, новое предупреждение, страница OCR (corp20: текст в error при processing)
      const ocrProgress = status.status === 'processing' ? status.error || '' : '';
      const progress = `${status.documents}|${warnings.length}|${ocrProgress}`;
      if (progress !== lastProgress) {
        lastProgress = progress;
        lastProgressAt = Date.now();
      }
      for (; lastWarnings < warnings.length; lastWarnings++) {
        queue.push({
          type: 'upload_warning',
          data: { type: 'upload_warning', message: warnings[lastWarnings] },
        });
      }
      if (status.status === 'done') {
        return;
      }
      if (status.status === 'failed' || status.status === 'none') {
        throw new Error(`Upload processing error: ${status.error || status.status}`);
      }
      // ход разбора (счётчик разобранных документов) — в журнал только при изменении, иначе журнал заливает;
      // «N из M» не пишем: документов из ZIP бывает больше, чем файлов в партии
      const ocrNote = ocrProgress
        ? `; ${ocrProgress}`
        : '; сканы PDF распознаются через GigaChat постранично — на многостраничном скане счётчик может не меняться десятки минут';
      const message =
        status.documents > 0
          ? `разобрано документов: ${status.documents} (файлов в партии: ${status.files}${ocrNote})`
          : `документы обрабатываются на сервере (${status.files} файл(ов)${ocrProgress ? `; ${ocrProgress}` : ''})`;
      if (message !== lastMessage) {
        lastMessage = message;
        queue.push({
          type: 'upload_processing',
          data: { type: 'upload_processing', files: status.files, parsed: status.documents, message },
        });
      }
    }
  }
}
