# -*- coding: utf-8 -*-
"""Статическая проверка JSON-сценариев GigaMe: ограничения шлюза SOWA и известные грабли движка.
python lint_scenarios.py <папка или файл> [...]"""
import glob
import io
import json
import os
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

NAME_LIMIT = 64            # имя при импорте: name + « (импорт)»
DESCRIPTION_LIMIT = 255
RULES_LIMIT = 10000
IMPORT_SUFFIX = " (импорт)"
CONTRACT_TYPES = {"json_массив"}
DOCLIST_PARENTS = {"input", "if_node", "switch"}


def load(path):
    try:
        return json.load(open(path, encoding="utf-8-sig")), None
    except Exception as e:
        return None, f"файл не разбирается как JSON: {e}"


def rules_of(node):
    raw = (node.get("data") or {}).get("rules")
    if not raw:
        return None, None
    if isinstance(raw, dict):
        return raw, None
    try:
        return json.loads(raw), None
    except Exception as e:
        return None, f"узел {node.get('id')}: правила не разбираются как JSON ({e})"


def check(path):
    problems = []
    scenario, error = load(path)
    if error:
        return [error]
    name = str(scenario.get("name") or "")
    description = str(scenario.get("description") or "")
    if len(name + IMPORT_SUFFIX) > NAME_LIMIT:
        problems.append(f"имя при импорте {len(name + IMPORT_SUFFIX)} знаков, предел {NAME_LIMIT}")
    if len(description) > DESCRIPTION_LIMIT:
        problems.append(f"описание {len(description)} знаков, предел {DESCRIPTION_LIMIT}")
    graph = scenario.get("graph_data") or {}
    nodes = graph.get("nodes") or []
    edges = graph.get("edges") or []
    ids = {n.get("id") for n in nodes}
    by_id = {n.get("id"): n for n in nodes}
    parents = {}
    for edge in edges:
        source, target = edge.get("source"), edge.get("target")
        if source not in ids:
            problems.append(f"ребро {edge.get('id')}: источник «{source}» не найден")
        if target not in ids:
            problems.append(f"ребро {edge.get('id')}: цель «{target}» не найдена")
        parents.setdefault(target, []).append(source)
        if by_id.get(source, {}).get("type") == "if_node" and not (edge.get("data") or {}).get("label"):
            problems.append(f"ребро {edge.get('id')} из условия «{source}» без метки (да/нет)")
    for node in nodes:
        node_id, node_type = node.get("id"), node.get("type")
        data = node.get("data") or {}
        rules, rules_error = rules_of(node)
        if rules_error:
            problems.append(rules_error)
            continue
        raw = data.get("rules")
        if isinstance(raw, str) and len(raw) > RULES_LIMIT:
            problems.append(f"узел {node_id}: правила {len(raw)} знаков, предел шлюза {RULES_LIMIT}")
        if not isinstance(rules, dict):
            continue
        contract = rules.get("контракт")
        if isinstance(contract, dict) and contract.get("тип") not in CONTRACT_TYPES:
            problems.append(f"узел {node_id}: контракт «{contract.get('тип')}» движок не поддерживает")
        if "docList" in rules or rules.get("документы_списком"):
            source_types = {by_id.get(p, {}).get("type") for p in parents.get(node_id, [])}
            if not source_types & DOCLIST_PARENTS:
                problems.append(f"узел {node_id}: docList, но родитель не input/if/switch ({source_types or 'нет'})")
        if rules.get("разметка_документов") is not None and node_type != "output":
            problems.append(f"узел {node_id}: разметка_документов не в выходном узле")
        if node_type == "output" and data.get("mode") == "excel":
            columns = rules.get("колонки")
            if not columns:
                problems.append(f"узел {node_id}: Excel-узел без «колонки»")
    subscenarios = [n for n in nodes if n.get("type") == "subscenario"]
    for node in subscenarios:
        if not (node.get("data") or {}).get("value"):
            problems.append(f"узел {node.get('id')}: подсценарий без id (заполняется перед прогоном)")
    return problems


def main():
    targets = []
    for argument in sys.argv[1:]:
        if os.path.isdir(argument):
            targets += sorted(glob.glob(os.path.join(argument, "**", "*.json"), recursive=True))
        else:
            targets.append(argument)
    bad = 0
    for path in targets:
        if os.sep + "_архив" + os.sep in path or "__pycache__" in path:
            continue
        problems = check(path)
        if problems:
            bad += 1
            print(os.path.relpath(path, targets and os.path.commonpath(targets) or "."))
            for problem in problems:
                print("   •", problem)
    print(f"\nпроверено файлов: {len(targets)}, с замечаниями: {bad}")


if __name__ == "__main__":
    main()
