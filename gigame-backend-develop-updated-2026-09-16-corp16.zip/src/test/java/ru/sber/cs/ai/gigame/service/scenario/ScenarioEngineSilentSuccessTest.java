package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Аудит «тихого успеха» и недетерминизма движка: прогон с упавшим узлом не бывает
 * COMPLETED, вход узла с несколькими родителями собирается в порядке рёбер, итог —
 * первый по графу output-узел, волны планируются в топологическом порядке,
 * под-сценарий без данных — ошибка.
 */
class ScenarioEngineSilentSuccessTest {

    private static final String JSON_A = "[{\"узел\": \"A\"}]";
    private static final String JSON_B = "[{\"узел\": \"B\"}]";

    private final ScenarioRunService runService = mock(ScenarioRunService.class);
    private final ScenarioRunStepService stepService = mock(ScenarioRunStepService.class);
    private final ScenarioRepository scenarioRepository = mock(ScenarioRepository.class);
    private final ScenarioRun run = newRun();
    private final List<Map<String, Object>> events = new CopyOnWriteArrayList<>();
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> eventSink = mock(FluxSink.class);

    // -------------------------------------------------------------------------
    // A1: прогон с ошибкой узла (on_error=continue) завершается FAILED с итогом
    // -------------------------------------------------------------------------

    @Test
    void failedNodeWithContinue_runIsFailedWithPartialResultAndNotice() {
        var graphData = new GraphDataDto(
                List.of(input(), failingNode("x-1", "Анализ", "continue"), output("out-1")),
                List.of(edge("input-1", "x-1"), edge("x-1", "out-1")));
        ScenarioEngine engine = engine(factory(Map.of("x-1", node -> throwing(node, "GigaChat недоступен"))));

        invokeDoExecute(engine, graphData);

        ArgumentCaptor<String> result = ArgumentCaptor.forClass(String.class);
        verify(runService).setScenarioRunStatusFailed(any(ScenarioRun.class), result.capture());
        verify(runService, never()).setScenarioRunStatusCompleted(any(ScenarioRun.class), any());
        assertTrue(result.getValue().startsWith("⚠ В итог вошли ошибки узлов: Анализ"), result.getValue());
        assertTrue(result.getValue().contains(ScenarioEngine.NODE_ERROR_PREFIX + "Анализ»: GigaChat недоступен]"));
        assertTrue(events.stream().anyMatch(e -> "Прогон завершён с ошибками узлов: Анализ — результат неполный"
                .equals(e.get("detail"))), "в журнале нет перечня упавших узлов: " + events);
        var status = events.stream()
                .filter(e -> "status".equals(String.valueOf(e.get("type"))) && ScenarioStatus.FAILED == e.get("status"))
                .findFirst().orElseThrow();
        assertTrue(String.valueOf(status.get("result")).contains("Анализ"), "STATUS FAILED без итога");
    }

    @Test
    void cleanRun_isCompletedWithoutNotice() {
        var graphData = new GraphDataDto(
                List.of(input(), plainNode("a-1", "A"), output("out-1")),
                List.of(edge("input-1", "a-1"), edge("a-1", "out-1")));
        ScenarioEngine engine = engine(factory(Map.of("a-1", node -> contributing(node, JSON_A, 0))));

        invokeDoExecute(engine, graphData);

        ArgumentCaptor<String> result = ArgumentCaptor.forClass(String.class);
        verify(runService).setScenarioRunStatusCompleted(any(ScenarioRun.class), result.capture());
        verify(runService, never()).setScenarioRunStatusFailed(any(ScenarioRun.class), anyString());
        assertTrue(result.getValue().contains(JSON_A));
        assertFalse(result.getValue().contains("⚠"));
        assertTrue(events.stream().noneMatch(e -> "Итог прогона".equals(e.get("node_label"))));
    }

    // -------------------------------------------------------------------------
    // B2: вход узла с несколькими родителями — в порядке рёбер, не завершения
    // -------------------------------------------------------------------------

    @Test
    void twoParentsFinishInReverseOrder_childInputFollowsEdgeOrder() {
        var graphData = new GraphDataDto(
                List.of(input(), plainNode("a-1", "A"), plainNode("b-1", "B"), output("out-1")),
                List.of(edge("input-1", "a-1"), edge("input-1", "b-1"), edge("a-1", "out-1"), edge("b-1", "out-1")));
        // A медленный, B быстрый: B вносит вклад первым, но ребро A→выход идёт раньше
        ScenarioEngine engine = engine(factory(Map.of(
                "a-1", node -> contributing(node, JSON_A, 400),
                "b-1", node -> contributing(node, JSON_B, 0))));
        ReflectionTestUtils.setField(engine, "parallelEnabled", true);
        ReflectionTestUtils.setField(engine, "parallelThreads", 2);

        invokeDoExecute(engine, graphData);

        ArgumentCaptor<String> result = ArgumentCaptor.forClass(String.class);
        verify(runService).setScenarioRunStatusCompleted(any(ScenarioRun.class), result.capture());
        assertTrue(result.getValue().indexOf(JSON_A) < result.getValue().indexOf(JSON_B), result.getValue());
        // Excel-выгрузка берёт первый JSON — от первого по графу родителя
        assertEquals(JSON_A, ScenarioResultToXlsx.extractJson(result.getValue()));
    }

    // -------------------------------------------------------------------------
    // B3: итог — первый по порядку узлов графа выполненный output-узел
    // -------------------------------------------------------------------------

    @Test
    void twoOutputs_finalResultIsFirstOutputInGraphOrder_bothModes() {
        for (boolean parallel : new boolean[]{false, true}) {
            Mockito.reset(runService);
            var graphData = new GraphDataDto(
                    List.of(input(), plainNode("a-1", "A"), output("out-a"), output("out-b")),
                    List.of(edge("input-1", "a-1"), edge("a-1", "out-a"), edge("input-1", "out-b")));
            ScenarioEngine engine = engine(factory(Map.of(
                    "a-1", node -> contributing(node, JSON_A, 0),
                    "input-1", node -> contributing(node, JSON_B, 0))));
            ReflectionTestUtils.setField(engine, "parallelEnabled", parallel);

            invokeDoExecute(engine, graphData);

            ArgumentCaptor<String> result = ArgumentCaptor.forClass(String.class);
            verify(runService).setScenarioRunStatusCompleted(any(ScenarioRun.class), result.capture());
            // out-a раньше в graphData.nodes(), хотя out-b завершается раньше/позже в зависимости от режима
            assertTrue(result.getValue().contains(JSON_A), "parallel=" + parallel + ": " + result.getValue());
            assertFalse(result.getValue().contains(JSON_B), "parallel=" + parallel + ": " + result.getValue());
        }
    }

    @Test
    void outputNotExecuted_resultIsEmptyWithNotice() {
        var graphData = new GraphDataDto(
                List.of(input(), plainNode("a-1", "A"), output("out-1")),
                List.of(edge("input-1", "a-1"), edge("a-1", "out-1")));
        // A не активирует детей — выход не выполняется; чужой выход итог не подменяет
        ScenarioEngine engine = engine(factory(Map.of("a-1", node -> silent(node, "результат A"))));

        invokeDoExecute(engine, graphData);

        verify(runService).setScenarioRunStatusCompleted(any(ScenarioRun.class), Mockito.eq(""));
        assertTrue(events.stream().anyMatch(e -> String.valueOf(e.get("detail")).contains("Ни один узел «Выход» не выполнен")));
    }

    // -------------------------------------------------------------------------
    // B5: планирование волн в топологическом порядке
    // -------------------------------------------------------------------------

    @Test
    void waves_scheduleNodesInTopologicalOrder_evenWhenGraphListsThemReversed() {
        // в JSON узлы перечислены в обратном порядке; параллельных потоков меньше, чем готовых узлов
        var graphData = new GraphDataDto(
                List.of(output("out-1"), plainNode("c-1", "C"), plainNode("b-1", "B"), plainNode("a-1", "A"), input()),
                List.of(edge("input-1", "a-1"), edge("input-1", "b-1"), edge("input-1", "c-1"),
                        edge("a-1", "out-1"), edge("b-1", "out-1"), edge("c-1", "out-1")));
        List<String> order = new CopyOnWriteArrayList<>();
        ScenarioEngine engine = engine(factory(Map.of(
                "a-1", node -> recording(node, order),
                "b-1", node -> recording(node, order),
                "c-1", node -> recording(node, order))));
        ReflectionTestUtils.setField(engine, "parallelEnabled", true);
        ReflectionTestUtils.setField(engine, "parallelThreads", 1);

        invokeDoExecute(engine, graphData);

        // один поток: порядок выполнения = порядок очереди = топологический (готовые — в порядке рёбер),
        // а не порядок перечисления узлов в JSON
        assertEquals(List.of("a-1", "b-1", "c-1"), order);
        var graph = new ScenarioRunGraph(graphData);
        assertEquals(List.of("input-1", "a-1", "b-1", "c-1", "out-1"),
                graph.nodesInTopologicalOrder().stream().map(ScenarioRunNode::getId).toList());
    }

    // -------------------------------------------------------------------------
    // A3: под-сценарий без документов и входа; output под-графа не выполнен
    // -------------------------------------------------------------------------

    @Test
    void subScenario_withoutDocsAndInput_throws() {
        UUID subId = UUID.randomUUID();
        when(scenarioRepository.findById(subId)).thenReturn(Optional.of(subScenario()));
        ScenarioEngine engine = engine(factory(Map.of()));
        ScenarioRunNode parent = subScenarioParent();

        var e = org.junit.jupiter.api.Assertions.assertThrows(ScenarioException.class,
                () -> engine.executeSubScenarioInline(subId.toString(), parent, eventSink));

        assertTrue(e.getMessage().contains("нет ни документов, ни входа"), e.getMessage());
    }

    @Test
    void subScenario_outputNotExecuted_throws() {
        UUID subId = UUID.randomUUID();
        when(scenarioRepository.findById(subId)).thenReturn(Optional.of(subScenario()));
        // input под-сценария не активирует выход
        ScenarioEngine engine = engine(factory(Map.of("input-1", node -> silent(node, "вход"))));
        ScenarioRunNode parent = subScenarioParent();
        parent.getInput().add("текст на входе");

        var e = org.junit.jupiter.api.Assertions.assertThrows(ScenarioException.class,
                () -> engine.executeSubScenarioInline(subId.toString(), parent, eventSink));

        assertTrue(e.getMessage().contains("выходной узел под-сценария не выполнен"), e.getMessage());
    }

    @Test
    void subScenario_outputExecuted_returnsItsResult() {
        UUID subId = UUID.randomUUID();
        when(scenarioRepository.findById(subId)).thenReturn(Optional.of(subScenario()));
        ScenarioEngine engine = engine(factory(Map.of("input-1", node -> contributing(node, JSON_A, 0))));
        ScenarioRunNode parent = subScenarioParent();
        parent.getInput().add("текст на входе");

        String result = engine.executeSubScenarioInline(subId.toString(), parent, eventSink);

        assertTrue(result.contains(JSON_A));
    }

    // -------------------------------------------------------------------------
    // helpers
    // -------------------------------------------------------------------------

    private ScenarioEngine engine(ScenarioExecutorFactory factory) {
        when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class))).thenReturn(run);
        when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any(ScenarioNodeType.class)))
                .thenAnswer(inv -> {
                    var step = new ScenarioRunStep();
                    step.setId(UUID.randomUUID());
                    step.setNodeId(inv.getArgument(1));
                    return step;
                });
        Mockito.doAnswer(inv -> {
            ServerSentEvent<Map<String, Object>> event = inv.getArgument(0);
            events.add(event.data());
            return null;
        }).when(eventSink).next(any());
        return new ScenarioEngine(runService, stepService, factory, mock(DocsTextCacheService.class),
                scenarioRepository, outputSupport());
    }

    /** Мок доп. возможностей output-узла: без «накапливать» результат проходит как есть. */
    private static ScenarioOutputSupportService outputSupport() {
        var support = mock(ScenarioOutputSupportService.class);
        when(support.accumulateIfConfigured(any(), any(), any())).thenAnswer(inv -> inv.getArgument(2));
        return support;
    }

    private void invokeDoExecute(ScenarioEngine engine, GraphDataDto graphData) {
        try {
            var method = ScenarioEngine.class.getDeclaredMethod("doExecute",
                    FluxSink.class, ScenarioRun.class, GraphDataDto.class, DocsTextCacheService.CachedDocuments.class);
            method.setAccessible(true);
            method.invoke(engine, eventSink, run, graphData, DocsTextCacheService.CachedDocuments.EMPTY);
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * Фабрика: узлы из карты — тестовые исполнители, выход — настоящий. Вход без документов
     * прогона детей не активирует (настоящий InputNode на пустом docMap выходит сразу),
     * поэтому по умолчанию входу даётся исполнитель, активирующий детей.
     */
    private static ScenarioExecutorFactory factory(Map<String, Function<ScenarioRunNode, AbstractScenarioExecutor>> custom) {
        var real = new ScenarioExecutorFactory(null, null, null, null, null);
        var factory = mock(ScenarioExecutorFactory.class);
        when(factory.createExecutor(any(ScenarioRunNode.class))).thenAnswer(inv -> {
            ScenarioRunNode node = inv.getArgument(0);
            var maker = custom.get(node.getId());
            if (maker != null) {
                return maker.apply(node);
            }
            return node.getType() == ScenarioNodeType.INPUT_NODE
                    ? recording(node, new CopyOnWriteArrayList<>()) : real.createExecutor(node);
        });
        return factory;
    }

    /** Исполнитель, вносящий вклад во входы детей (как узел обработки) после задержки. */
    private static AbstractScenarioExecutor contributing(ScenarioRunNode runNode, String text, long delayMs) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                sleep(delayMs);
                runNode.getOutput().add(text);
                for (var child : runNode.getChildNodeList()) {
                    child.setSkip(false);
                    child.addInputs(runNode.getId(), List.of("=== РЕЗУЛЬТАТ ОТ \"" + runNode.getLabel() + "\" ===\n" + text));
                }
                return text;
            }
        };
    }

    /** Исполнитель, падающий с ошибкой. */
    private static AbstractScenarioExecutor throwing(ScenarioRunNode runNode, String message) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                throw new ScenarioException(message);
            }
        };
    }

    /** Исполнитель, не активирующий детей. */
    private static AbstractScenarioExecutor silent(ScenarioRunNode runNode, String text) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                return text;
            }
        };
    }

    /** Исполнитель, записывающий порядок запуска и активирующий детей. */
    private static AbstractScenarioExecutor recording(ScenarioRunNode runNode, List<String> order) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                order.add(runNode.getId());
                for (var child : runNode.getChildNodeList()) {
                    child.setSkip(false);
                    child.addInput(runNode.getId(), runNode.getId());
                }
                return runNode.getId();
            }
        };
    }

    private static void sleep(long ms) {
        if (ms <= 0) {
            return;
        }
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static ScenarioRun newRun() {
        var scenarioRun = new ScenarioRun();
        scenarioRun.setId(UUID.randomUUID());
        scenarioRun.setScenarioId(UUID.randomUUID());
        scenarioRun.setStatus("pending");
        return scenarioRun;
    }

    private static Scenario subScenario() {
        var sub = new Scenario();
        sub.setId(UUID.randomUUID());
        sub.setName("sub");
        sub.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(
                List.of(input(), output("out-1")), List.of(edge("input-1", "out-1")))));
        return sub;
    }

    private static ScenarioRunNode subScenarioParent() {
        NodeDto parentDto = NodeDto.builder()
                .id("sub-node")
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Под-сценарий").value(UUID.randomUUID().toString()).build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(input(), parentDto),
                List.of(edge("input-1", "sub-node"))));
        return graph.getNodeMap().get("sub-node");
    }

    private static NodeDto input() {
        return node("input-1", ScenarioNodeType.INPUT_NODE, "Вход", null);
    }

    private static NodeDto output(String id) {
        return node(id, ScenarioNodeType.OUTPUT_NODE, "Выход", null);
    }

    private static NodeDto plainNode(String id, String label) {
        return node(id, ScenarioNodeType.PROCESSING_NODE, label, null);
    }

    private static NodeDto failingNode(String id, String label, String onError) {
        return node(id, ScenarioNodeType.PROCESSING_NODE, label, onError);
    }

    private static NodeDto node(String id, ScenarioNodeType type, String label, String onError) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).prompt("p").onError(onError).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static EdgeDto edge(String source, String target) {
        return new EdgeDto(source + "-" + target, source, target, new EdgeDataDto(null));
    }
}
