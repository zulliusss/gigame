package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRating;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.ScenarioVersion;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRatingRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputViews;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.io.IOException;
import java.io.InputStream;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScenarioServiceTest {

    @Mock
    private ScenarioRepository scenarioRepository;

    @Mock
    private ScenarioRunRepository scenarioRunRepository;

    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;

    @Mock
    private ScenarioVersionRepository scenarioVersionRepository;

    @Mock
    private ScenarioRatingRepository scenarioRatingRepository;

    @Mock
    private DocumentService documentService;

    @Mock
    private ScenarioEngine scenarioEngine;

    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @InjectMocks
    private ScenarioService scenarioService;

    @Captor
    private ArgumentCaptor<Scenario> scenarioCaptor;

    private UUID userId;
    private UUID scenarioId;
    private Scenario scenario;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        scenarioId = UUID.randomUUID();
        scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setUserId(userId.toString());
        scenario.setName("Test Scenario");
        scenario.setDescription("Test description");
        scenario.setCreatedAt(OffsetDateTime.now());
        scenario.setUpdatedAt(OffsetDateTime.now());

        NodeDto node1 = NodeDto.builder()
                .id("node1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Node 1")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto node2 = NodeDto.builder()
                .id("node2")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Node 2")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        EdgeDto edge = new EdgeDto(
                "edge-1",
                "node-1",
                "node-2",
                new EdgeDataDto("edge-1")
        );
        GraphDataDto graphData = new GraphDataDto(
                List.of(node1, node2),
                List.of(edge)
        );
        scenario.setGraphData(GraphDataMapper.fromDto(graphData));
        ReflectionTestUtils.setField(scenarioService, "self", new AtomicReference<>(scenarioService));

    }

    // -------------------------------------------------------------------------
    // Helper methods for creating mock test data
    // -------------------------------------------------------------------------

    private FilePart createMockFilePart(String filename, String content) {
        FilePart mockFile = mock(FilePart.class);
        when(mockFile.filename()).thenReturn(filename);
        byte[] bytes = content.getBytes();
        when(mockFile.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap(bytes)));
        return mockFile;
    }

    // -------------------------------------------------------------------------
    // Tests for getDocumentsText method
    // -------------------------------------------------------------------------

    @Test
    void testGetDocumentsText_withMultipleFiles_success() throws IOException {
        // Given
        FilePart file1 = createMockFilePart("file1.pdf", "PDF content");
        FilePart file2 = createMockFilePart("file2.docx", "DOCX content");

        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("PDF extracted text");
        when(documentService.parseText(any(InputStream.class), eq("docx")))
                .thenReturn("DOCX extracted text");

        List<FilePart> files = List.of(file1, file2);
        List<ServerSentEvent<Map<String, Object>>> uploadEvents = new ArrayList<>();

        // When
        var result = scenarioService.getDocumentsText(files, uploadEvents);

        // Then
        assertNotNull(result);
        assertTrue(result.contains("PDF extracted text"));
        assertTrue(result.contains("DOCX extracted text"));
        // два upload_progress, два upload_parsed (по одному на документ) и upload_done
        assertEquals(5, uploadEvents.size());
        assertEquals(2, uploadEvents.stream().filter(e -> "upload_parsed".equals(e.data().get("type"))).count());
        var lastEventData = uploadEvents.get(4).data();
        assertNotNull(lastEventData);
        assertEquals("upload_done", lastEventData.get("type"));
        assertEquals(2, lastEventData.get("count"));
    }

    @Test
    void testGetDocumentsText_withNullUploadEvents_success() throws IOException {
        // Given
        FilePart file1 = createMockFilePart("file1.txt", "TXT content");

        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenReturn("TXT extracted text");

        List<FilePart> files = List.of(file1);

        // When
        var result = scenarioService.getDocumentsText(files, null);

        // Then
        assertNotNull(result);
        assertEquals("TXT extracted text", result.get(0));
    }

    @Test
    void testGetDocumentsText_withFileParsingError_marksDocumentForManualReview() throws IOException {
        // Given: нечитаемый файл не роняет загрузку — документ получает маркер ручной проверки
        FilePart file = createMockFilePart("file.pdf", "content");

        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenThrow(new RuntimeException("Parse error"));

        List<FilePart> files = List.of(file);
        List<ServerSentEvent<Map<String, Object>>> uploadEvents = new ArrayList<>();

        // When
        List<String> texts = scenarioService.getDocumentsText(files, uploadEvents);

        // Then
        assertEquals(1, texts.size());
        assertTrue(texts.get(0).contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(texts.get(0).contains("file.pdf"));
        assertTrue(uploadEvents.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).contains("не обработан")));
    }

    @Test
    void testGetDocumentsText_withSingleFile_success() throws IOException {
        // Given
        FilePart file = createMockFilePart("single.xlsx", "XLSX content");

        when(documentService.parseText(any(InputStream.class), eq("xlsx")))
                .thenReturn("XLSX extracted text");

        List<FilePart> files = List.of(file);

        // When
        var result = scenarioService.getDocumentsText(files, null);

        // Then
        assertNotNull(result);
        assertEquals("XLSX extracted text", result.get(0));
    }

    // -------------------------------------------------------------------------
    // Tests for extractToDocx method
    // -------------------------------------------------------------------------

    @Test
    void testExtractToDocx_withProcessingOutputNode_generatesDocx() {
        // Given
        UUID runId = UUID.randomUUID();

        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(new ScenarioRun()));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        // When
        ResponseEntity<Resource> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.extractToDocx(runId, true));

        // Then
        assertNotNull(result);
        assertEquals(200, result.getStatusCode().value());
    }

    @Test
    void testExtractToDocx_withProcessingOutputNode_generatesXlsx() {

        // Given
        UUID runId = UUID.randomUUID();

        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(OffsetDateTime.now());

        ScenarioRunStep step1 = new ScenarioRunStep();
        step1.setRunId(runId);
        step1.setNodeId("node1");
        ScenarioRunStep step2 = new ScenarioRunStep();
        step2.setRunId(runId);
        step2.setNodeId("node2");
        List<ScenarioRunStep> stepResponses = List.of(step1, step2);

        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any())).thenReturn(stepResponses);

        // When
        ResponseEntity<Resource> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.extractToDocx(runId, true));

        // Then
        assertNotNull(result);
        assertEquals(200, result.getStatusCode().value());
    }

    @Test
    void testExtractToDocx_withScenarioNotFound_throwsException() {
        // Given
        UUID runId = UUID.randomUUID();

        when(scenarioRunRepository.findById(runId)).thenReturn(Optional.of(new ScenarioRun()));

        // When & Then: 404, а не 500 (IllegalArgumentException не обрабатывался)
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.extractToDocx(runId, true)));
    }

    // -------------------------------------------------------------------------
    // Tests for runScenario method
    // -------------------------------------------------------------------------

    @Test
    void testRunScenario_withStepModeEnabled_success() {
        UUID runId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(OffsetDateTime.now());
        // Given
        when(scenarioRepository.findById(scenarioId))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.save(any())).thenReturn(run);
        when(scenarioEngine.executeScenario(any(), any(), any()))
                .thenReturn(Flux.empty());

        // When
        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.runScenario(scenarioId, true));

        // Then
        assertNotNull(result);
    }

    @Test
    void testRunScenario_withStepModeDisabled_success() {
        // Given
        when(scenarioRepository.findById(scenarioId))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any()))
                .thenReturn(Flux.empty());

        // When
        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.runScenario(scenarioId, false));

        // Then
        assertNotNull(result);
    }

    @Test
    void testRunScenario_withNullStepMode_success() {
        // Given
        when(scenarioRepository.findById(scenarioId))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any()))
                .thenReturn(Flux.empty());

        // When
        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.runScenario(scenarioId, null));

        // Then
        assertNotNull(result);
    }

    @Test
    void testRunScenario_sharedScenarioOfOtherOwner_passesRunningUserToEngine() {
        // Given: общий сценарий владельца запускает другой пользователь — движок ищет документы по запускающему
        scenario.setShared(true);
        when(scenarioRepository.findById(scenarioId))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any()))
                .thenReturn(Flux.empty());

        // When
        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser("RUNNER2",
                () -> scenarioService.runScenario(scenarioId, false));

        // Then: в движок уходит запускающий пользователь, а не владелец сценария
        assertNotNull(result);
        verify(scenarioEngine).executeScenario(any(), any(), eq("RUNNER2"));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRunScenario_withScenarioNotFound_throwsException() {
        // Given
        UUID nonExistentId = UUID.randomUUID();
        when(scenarioRepository.findById(nonExistentId))
                .thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResponseStatusException.class, () ->
                CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.runScenario(nonExistentId, false)));
    }

    /** Граф сценария с узлом «Трансформация», операции которого нет в этой версии бэкенда. */
    private void setGraphWithUnknownOperation() {
        NodeDto transform = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Свод")
                        .rules("{\"операции\": [{\"оп\": \"заменить\"}, {\"оп\": \"свести_риски\"}]}")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        NodeDto input = NodeDto.builder().id("in").type("input").data(NodeDataDto.builder().label("Вход").build()).build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(input, transform),
                List.of(new EdgeDto("e1", "in", "t1", new EdgeDataDto("e1"))))));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRunScenario_withUnknownTransformOperation_rejectedBeforeRunIsCreated() {
        setGraphWithUnknownOperation();
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.runScenario(scenarioId, false)));

        assertEquals("Сценарий использует операции, которых нет в этой версии бэкенда: «свести_риски» в узле «Свод» "
                + "— обновите дистрибутив бэкенда", ex.getMessage());
        // прогон не создан (не остаётся в статусе running), узлы не выполняются
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).executeScenario(any(), any(), any());
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testResumeScenarioRun_withUnknownTransformOperation_rejectedBeforeRunIsCreated() {
        setGraphWithUnknownOperation();
        ScenarioRun oldRun = new ScenarioRun();
        oldRun.setId(UUID.randomUUID());
        oldRun.setScenarioId(scenarioId);
        oldRun.setStatus("failed");
        when(scenarioRunRepository.findById(oldRun.getId())).thenReturn(Optional.of(oldRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.resumeScenarioRun(oldRun.getId())));

        assertTrue(ex.getMessage().contains("«свести_риски» в узле «Свод»"), ex.getMessage());
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).resumeScenario(any(), any(), any(), any());
    }

    /**
     * Граф сценария с узлом «Под-сценарий»: у под-сценария узел «Трансформация» с операцией, которой нет
     * в этой версии бэкенда, и обратная ссылка на запускаемый сценарий (цикл).
     */
    private void setGraphWithSubScenarioUnknownOperation() {
        UUID subId = UUID.randomUUID();
        NodeDto subTransform = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Суммы").rules("{\"операции\": [{\"оп\": \"сверить_всё\"}]}").build())
                .position(new PositionDto(0, 0))
                .build();
        Scenario sub = new Scenario();
        sub.setId(subId);
        sub.setName("Проверка сумм");
        // под-сценарий того же владельца: доступ к нему есть, отказ — только из-за операции
        sub.setUserId(userId.toString());
        sub.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(subTransform, subScenarioNode("back", scenarioId)),
                List.of())));
        NodeDto input = NodeDto.builder().id("in").type("input").data(NodeDataDto.builder().label("Вход").build()).build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(input, subScenarioNode("s1", subId)),
                List.of(new EdgeDto("e1", "in", "s1", new EdgeDataDto("e1"))))));
        when(scenarioRepository.findById(subId)).thenReturn(Optional.of(sub));
    }

    private static NodeDto subScenarioNode(String id, UUID subScenarioId) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Под-сценарий").value(subScenarioId.toString()).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRunScenario_withUnknownOperationInSubScenario_rejectedBeforeRunIsCreated() {
        setGraphWithSubScenarioUnknownOperation();
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.runScenario(scenarioId, false)));

        assertEquals("Сценарий использует операции, которых нет в этой версии бэкенда: «сверить_всё» в узле «Суммы» "
                + "под-сценария «Проверка сумм» — обновите дистрибутив бэкенда", ex.getMessage());
        // обратная ссылка под-сценария на запускаемый сценарий повторно не загружается
        verify(scenarioRepository, times(1)).findById(scenarioId);
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).executeScenario(any(), any(), any());
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testResumeScenarioRun_withUnknownOperationInSubScenario_rejectedBeforeRunIsCreated() {
        setGraphWithSubScenarioUnknownOperation();
        ScenarioRun oldRun = new ScenarioRun();
        oldRun.setId(UUID.randomUUID());
        oldRun.setScenarioId(scenarioId);
        oldRun.setStatus("failed");
        when(scenarioRunRepository.findById(oldRun.getId())).thenReturn(Optional.of(oldRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.resumeScenarioRun(oldRun.getId())));

        assertTrue(ex.getMessage().contains("«сверить_всё» в узле «Суммы» под-сценария «Проверка сумм»"), ex.getMessage());
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).resumeScenario(any(), any(), any(), any());
    }

    // -------------------------------------------------------------------------
    // Доступ к базам знаний и под-сценариям графа при запуске и возобновлении
    // -------------------------------------------------------------------------

    /** Граф сценария с узлом «Обработка», читающим базу знаний по id. */
    private void setGraphWithKnowledgeBase(UUID kbId) {
        NodeDto processing = NodeDto.builder()
                .id("p1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Нормы").knowledgeBaseId(kbId.toString()).build())
                .position(new PositionDto(0, 0))
                .build();
        NodeDto input = NodeDto.builder().id("in").type("input").data(NodeDataDto.builder().label("Вход").build()).build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(input, processing),
                List.of(new EdgeDto("e1", "in", "p1", new EdgeDataDto("e1"))))));
    }

    private static KnowledgeBase knowledgeBase(UUID id, String owner, boolean shared) {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(id);
        kb.setName("Нормативка");
        kb.setUserId(owner);
        kb.setShared(shared);
        return kb;
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRunScenario_withForeignPrivateKnowledgeBase_rejectedBeforeRunIsCreated() {
        UUID kbId = UUID.randomUUID();
        setGraphWithKnowledgeBase(kbId);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(knowledgeBaseRepository.findById(kbId)).thenReturn(Optional.of(knowledgeBase(kbId, "OTHER", false)));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.runScenario(scenarioId, false)));

        assertEquals("База знаний «Нормативка» (" + kbId + ") недоступна пользователю", ex.getMessage());
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).executeScenario(any(), any(), any());
    }

    @Test
    void testRunScenario_withOwnKnowledgeBase_started() {
        UUID kbId = UUID.randomUUID();
        setGraphWithKnowledgeBase(kbId);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(knowledgeBaseRepository.findById(kbId)).thenReturn(Optional.of(knowledgeBase(kbId, userId.toString(), false)));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any())).thenReturn(Flux.empty());

        assertNotNull(CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.runScenario(scenarioId, false)));

        verify(scenarioEngine).executeScenario(any(), any(), eq(userId.toString()));
    }

    @Test
    void testRunScenario_sharedScenarioWithSharedKnowledgeBase_otherUserStarts() {
        UUID kbId = UUID.randomUUID();
        setGraphWithKnowledgeBase(kbId);
        scenario.setShared(true);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(knowledgeBaseRepository.findById(kbId)).thenReturn(Optional.of(knowledgeBase(kbId, userId.toString(), true)));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any())).thenReturn(Flux.empty());

        assertNotNull(CurrentUserHolder.withUser("RUNNER2", () -> scenarioService.runScenario(scenarioId, false)));

        verify(scenarioEngine).executeScenario(any(), any(), eq("RUNNER2"));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRunScenario_sharedScenarioWithOwnerPrivateKnowledgeBase_otherUserRejected() {
        // общий сценарий с личной базой владельца: другой запускающий читал бы чужую базу
        UUID kbId = UUID.randomUUID();
        setGraphWithKnowledgeBase(kbId);
        scenario.setShared(true);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(knowledgeBaseRepository.findById(kbId)).thenReturn(Optional.of(knowledgeBase(kbId, userId.toString(), false)));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser("RUNNER2", () -> scenarioService.runScenario(scenarioId, false)));

        assertTrue(ex.getMessage().contains("недоступна пользователю"), ex.getMessage());
        verify(scenarioRunRepository, never()).save(any());
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRunScenario_withForeignPrivateSubScenario_rejectedBeforeRunIsCreated() {
        UUID subId = UUID.randomUUID();
        Scenario sub = new Scenario();
        sub.setId(subId);
        sub.setName("Чужой");
        sub.setUserId("OTHER");
        sub.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(
                NodeDto.builder().id("in").type("input").data(NodeDataDto.builder().label("Вход").build()).build()), List.of())));
        NodeDto input = NodeDto.builder().id("in").type("input").data(NodeDataDto.builder().label("Вход").build()).build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(input, subScenarioNode("s1", subId)),
                List.of(new EdgeDto("e1", "in", "s1", new EdgeDataDto("e1"))))));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioRepository.findById(subId)).thenReturn(Optional.of(sub));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.runScenario(scenarioId, false)));

        assertEquals("Под-сценарий «Чужой» недоступен пользователю", ex.getMessage());
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).executeScenario(any(), any(), any());
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testResumeScenarioRun_withForeignPrivateKnowledgeBase_rejectedBeforeRunIsCreated() {
        UUID kbId = UUID.randomUUID();
        setGraphWithKnowledgeBase(kbId);
        ScenarioRun oldRun = new ScenarioRun();
        oldRun.setId(UUID.randomUUID());
        oldRun.setScenarioId(scenarioId);
        oldRun.setStatus("failed");
        when(scenarioRunRepository.findById(oldRun.getId())).thenReturn(Optional.of(oldRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(knowledgeBaseRepository.findById(kbId)).thenReturn(Optional.of(knowledgeBase(kbId, "OTHER", false)));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.resumeScenarioRun(oldRun.getId())));

        assertEquals("База знаний «Нормативка» (" + kbId + ") недоступна пользователю", ex.getMessage());
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).resumeScenario(any(), any(), any(), any());
    }

    @Test
    void testResumeScenarioRun_withOwnKnowledgeBase_resumed() {
        UUID kbId = UUID.randomUUID();
        setGraphWithKnowledgeBase(kbId);
        ScenarioRun oldRun = new ScenarioRun();
        oldRun.setId(UUID.randomUUID());
        oldRun.setScenarioId(scenarioId);
        oldRun.setStatus("failed");
        when(scenarioRunRepository.findById(oldRun.getId())).thenReturn(Optional.of(oldRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(knowledgeBaseRepository.findById(kbId)).thenReturn(Optional.of(knowledgeBase(kbId, userId.toString(), false)));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.resumeScenario(any(), any(), any(), any())).thenReturn(Flux.empty());

        assertNotNull(CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.resumeScenarioRun(oldRun.getId())));

        verify(scenarioEngine).resumeScenario(any(), any(), any(), eq(userId.toString()));
    }

    // -------------------------------------------------------------------------
    // Tests for saveScenarioRun method
    // -------------------------------------------------------------------------

    @Test
    void testSaveScenarioRun_success() {
        // Given
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(OffsetDateTime.now());

        ScenarioRun savedRun = new ScenarioRun();
        savedRun.setId(UUID.randomUUID());
        savedRun.setScenarioId(scenarioId);
        savedRun.setStatus("pending");
        savedRun.setStartedAt(OffsetDateTime.now());

        when(scenarioRunRepository.save(any())).thenReturn(savedRun);

        // When
        ScenarioRun result = scenarioService.saveScenarioRun(run);

        // Then
        assertNotNull(result);
        assertNotNull(result.getId());
        assertEquals(scenarioId, result.getScenarioId());
        verify(scenarioRunRepository).save(run);
    }

    @Test
    void testSaveScenarioRun_withMinimalData_success() {
        // Given
        ScenarioRun run = new ScenarioRun();
        // Only scenarioId is set, other fields use defaults

        ScenarioRun savedRun = new ScenarioRun();
        savedRun.setId(UUID.randomUUID());
        savedRun.setScenarioId(scenarioId);

        when(scenarioRunRepository.save(any())).thenReturn(savedRun);

        // When
        ScenarioRun result = scenarioService.saveScenarioRun(run);

        // Then
        assertNotNull(result);
        assertNotNull(result.getId());
    }

    @Test
    void testGetScenarios() {
        var rating = new ScenarioRating();
        rating.setScenarioId(scenario.getId());
        rating.setRating(5);
        when(scenarioRepository.findAllByUserIdOrSharedTrueOrderByUpdatedAtDesc(userId.toString()))
                .thenReturn(List.of(scenario));
        when(scenarioRatingRepository.findByScenarioIdIn(List.of(scenarioId)))
                .thenReturn(List.of(rating));
        List<ScenarioResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarios());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Scenario", result.get(0).name());
    }

    @Test
    void testGetScenario_withExistingScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        ScenarioDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenario(scenarioId));

        assertNotNull(result);
        assertEquals("Test Scenario", result.name());
    }

    @Test
    void testGetScenario_withNonExistingScenario_throwsNotFoundException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.getScenario(uuid)));
    }

    @Test
    void testCreateScenario() {
        GraphDataDto graphData = new GraphDataDto(
                List.of(),
                List.of()
        );

        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "New Scenario", "Description", graphData));

        assertNotNull(result);
        verify(scenarioRepository).save(scenarioCaptor.capture());
        assertEquals("New Scenario", scenarioCaptor.getValue().getName());
        assertEquals("Description", scenarioCaptor.getValue().getDescription());
    }

    @Test
    void testUpdateScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        GraphDataDto graphData = new GraphDataDto(
                List.of(),
                List.of()
        );

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, "Updated Scenario", "Updated description", graphData));

        assertNotNull(result);
        assertEquals("Updated Scenario", scenario.getName());
    }

    @Test
    void testUpdateScenario_withNullGraphData() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, "Updated Scenario", null, null));

        assertNotNull(result);
    }

    @Test
    void testDuplicateScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenAnswer(inv -> {
            Scenario s = inv.getArgument(0);
            s.setId(UUID.randomUUID());
            return s;
        });

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.duplicateScenario(scenarioId));

        assertNotNull(result);
        assertEquals("Test Scenario (копия)", result.name());
    }

    @Test
    void testDeleteScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.deleteScenarioById(scenarioId)).thenReturn(1);

        assertDoesNotThrow(() -> CurrentUserHolder.withUser(userId.toString(),
                () -> {
                    scenarioService.deleteScenario(scenarioId);
                    return null;
                }));

        // одним DELETE-запросом (прогоны и шаги удаляет FK ON DELETE CASCADE), без загрузки сущности с каскадом
        verify(scenarioRepository).deleteScenarioById(scenarioId);
        verify(scenarioRepository, never()).delete(any(Scenario.class));
    }

    @Test
    void testDeleteScenario_foreignUser_deniedWithoutDelete() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("someone-else",
                        () -> {
                            scenarioService.deleteScenario(scenarioId);
                            return null;
                        }));

        verify(scenarioRepository, never()).deleteScenarioById(any());
    }

    @Test
    void testGetScenarioRuns() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenario.getId());
        run.setStatus("completed");
        run.setStartedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(scenario.getId()))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findOwnerRuns(any(), any()))
                .thenReturn(List.of(run));

        List<ScenarioRunResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("completed", result.get(0).status());
    }

    @Test
    void testGetScenarioRun_withSteps() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        run.setStartedAt(OffsetDateTime.now());

        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(run.getId());
        step.setNodeId("node1");
        step.setNodeType("input");
        when(scenarioRepository.findById(any()))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any()))
                .thenReturn(Optional.of(run));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any()))
                .thenReturn(List.of(step));

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(run.getId()));

        assertNotNull(result);
        assertEquals(1, result.steps().size());
    }

    @Test
    void testGetScenarioRun_clipsResultToSchemaLimit() {
        // итог прогона больше maxLength 500000 схемы шлюз блокировал бы вместе со всем отчётом
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        run.setResult("итог ".repeat(120_000));
        when(scenarioRepository.findById(any()))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any()))
                .thenReturn(Optional.of(run));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any()))
                .thenReturn(List.of());

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(run.getId()));

        String clipped = String.valueOf(result.result());
        assertEquals(500_000, clipped.length());
        assertTrue(clipped.startsWith("итог итог"));
        assertEquals(600_000, run.getResult().length());
    }

    @Test
    void testGetScenarioRun_over100Steps_returnsFirst99AndLast() {
        // maxItems steps 100: упавший шаг обычно последний — он остаётся в ответе
        ScenarioRun run = runWithSteps(101);

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(run.getId()));

        assertEquals(100, result.steps().size());
        assertEquals("n98", result.steps().get(98).nodeId());
        assertEquals("n100", result.steps().get(99).nodeId());
    }

    @Test
    void testGetScenarioRun_exactly100Steps_returnedAsIs() {
        ScenarioRun run = runWithSteps(100);

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(run.getId()));

        assertEquals(100, result.steps().size());
        assertEquals("n99", result.steps().get(99).nodeId());
    }

    @Test
    void testExtractToDocx_containsFullResultAndAllSteps() throws IOException {
        // DOCX шлюз по JSON-схеме не проверяет: полный итог, все шаги и полная ошибка шага
        ScenarioRun run = runWithSteps(120);
        // разнородные строки: однообразный текст сжимается так сильно, что POI при чтении считает DOCX zip-бомбой
        StringBuilder sb = new StringBuilder();
        for (int i = 0; sb.length() < 600_000; i++) {
            sb.append("Вердикт ").append(i).append(": ").append(UUID.randomUUID()).append('\n');
        }
        String fullResult = sb.append("ХВОСТ ИТОГА ПРОГОНА").toString();
        run.setResult(fullResult);

        ResponseEntity<Resource> docx = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.extractToDocx(run.getId(), true));

        String text = docxText(docx);
        assertTrue(fullResult.length() > 600_000);
        assertTrue(text.contains("ХВОСТ ИТОГА ПРОГОНА"));
        assertFalse(text.contains("итог усечён"));
        assertTrue(text.contains("Узел: n119"));
        assertTrue(text.contains("Ошибка узла: " + "ю".repeat(1000)));
    }

    private ScenarioRun runWithSteps(int count) {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("failed");
        List<ScenarioRunStep> steps = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            ScenarioRunStep step = new ScenarioRunStep();
            step.setRunId(run.getId());
            step.setNodeId("n" + i);
            step.setNodeType("processing");
            steps.add(step);
        }
        steps.get(count - 1).setOutputData(Map.of("error", "Ошибка узла: " + "ю".repeat(1000)));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any())).thenReturn(steps);
        return run;
    }

    private static String docxText(ResponseEntity<Resource> docx) throws IOException {
        try (InputStream in = docx.getBody().getInputStream(); XWPFDocument document = new XWPFDocument(in)) {
            StringBuilder sb = new StringBuilder();
            document.getParagraphs().forEach(p -> sb.append(p.getText()).append('\n'));
            return sb.toString();
        }
    }

    @Test
    void testGetScenarioRun_withNonExistingRun_throwsException() {
        lenient().when(scenarioRepository.findById(scenario.getId()))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any()))
                .thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        // прогон удалён вместе со сценарием (ON DELETE CASCADE) — 404, а не 500
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.getScenarioRun(uuid)));
    }

    @Test
    void testGetScenarioRun_scenarioDeleted_throwsNotFound() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setUserId(userId.toString());
        when(scenarioRunRepository.findById(run.getId())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.empty());
        var userIdStr = userId.toString();

        NotFoundException e = assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.getScenarioRun(run.getId())));

        assertEquals(404, e.getStatusCode());
        verify(scenarioRunStepRepository, never()).findByRunIdOrderByStartedAtAsc(any());
    }

    // -------------------------------------------------------------------------
    // Edge cases for CRUD operations
    // -------------------------------------------------------------------------

    @Test
    void testCreateScenario_withNullGraphData() {
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "New", "Desc", null));

        assertNotNull(result);
        verify(scenarioRepository).save(scenarioCaptor.capture());
        assertEquals("New", scenarioCaptor.getValue().getName());
        assertEquals("Desc", scenarioCaptor.getValue().getDescription());
    }

    @Test
    void testCreateScenario_withEmptyName() {
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "", "Desc", new GraphDataDto(List.of(), List.of())));

        assertNotNull(result);
    }

    @Test
    void testCreateScenario_withDuplicateName() {
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "Test Scenario", "Desc", new GraphDataDto(List.of(), List.of())));

        assertNotNull(result);
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testUpdateScenario_withNonExistingScenario_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.updateScenario(
                                scenarioId, "Updated", "Updated", new GraphDataDto(List.of(), List.of()))));
    }

    @Test
    void testUpdateScenario_withOnlyNameChange() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, "Only Name", null, null));

        assertNotNull(result);
        assertEquals("Only Name", result.name());
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testDuplicateScenario_withNonExistingScenario_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.duplicateScenario(scenarioId)));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testDeleteScenario_withNonExistingScenario_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> {
                            scenarioService.deleteScenario(scenarioId);
                            return null;
                        }));
    }

    // -------------------------------------------------------------------------
    // Scenario run edge cases
    // -------------------------------------------------------------------------

    @Test
    void testGetScenarioRuns_withEmptyResults() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findOwnerRuns(any(), any()))
                .thenReturn(List.of());

        List<ScenarioRunResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertNotNull(result);
        assertEquals(0, result.size());
    }

    @Test
    void testGetScenarioRuns_withMultipleRuns() {
        ScenarioRun run1 = new ScenarioRun();
        run1.setId(UUID.randomUUID());
        run1.setScenarioId(scenarioId);
        run1.setStatus("completed");
        run1.setStartedAt(OffsetDateTime.now());

        ScenarioRun run2 = new ScenarioRun();
        run2.setId(UUID.randomUUID());
        run2.setScenarioId(scenarioId);
        run2.setStatus("failed");
        run2.setStartedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findOwnerRuns(any(), any()))
                .thenReturn(List.of(run1, run2));

        List<ScenarioRunResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("completed", result.get(0).status());
        assertEquals("failed", result.get(1).status());
    }

    @Test
    void testGetScenarioRuns_withScenarioNotFound_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.getScenarioRuns(scenarioId)));
    }

    @Test
    void testGetScenarioRun_withMultipleSteps() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        run.setStartedAt(OffsetDateTime.now());

        ScenarioRunStep step1 = new ScenarioRunStep();
        step1.setRunId(run.getId());
        step1.setNodeId("node1");
        step1.setNodeType("input");

        ScenarioRunStep step2 = new ScenarioRunStep();
        step2.setRunId(run.getId());
        step2.setNodeId("node2");
        step2.setNodeType("processing");

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any()))
                .thenReturn(List.of(step1, step2));

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(run.getId()));

        assertNotNull(result);
        assertEquals(2, result.steps().size());
        assertEquals("input", result.steps().get(0).nodeType());
        assertEquals("processing", result.steps().get(1).nodeType());
    }

    // -------------------------------------------------------------------------
    // Versioning tests
    // -------------------------------------------------------------------------

    @Test
    @SuppressWarnings("java:S5778")
    void testGetVersions_withScenarioNotFound_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.getVersions(scenarioId)));
    }

    @Test
    void testGetVersions_withMultipleVersions() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdOrderByVersionNoDesc(any()))
                .thenReturn(List.of());

        List<Map<String, Object>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getVersions(scenarioId));

        assertNotNull(result);
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRestoreVersion_withNonExistingVersion_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdAndVersionNo(any(), anyInt()))
                .thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.restoreVersion(scenarioId, 99)));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRestoreVersion_withScenarioNotFound_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.restoreVersion(scenarioId, 1)));
    }

    @Test
    void testRestoreVersion_success() {
        int versionNo = 2;
        String versionName = "v2";
        String versionDescription = "Version 2 description";
        Map<String, Object> versionGraphData = Map.of("nodes", List.of(), "edges", List.of());

        ScenarioVersion version = new ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenarioId);
        version.setVersionNo(versionNo);
        version.setName(versionName);
        version.setDescription(versionDescription);
        version.setGraphData(versionGraphData);
        version.setCreatedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdAndVersionNo(scenarioId, versionNo))
                .thenReturn(Optional.of(version));
        // snapshotVersion: no existing version → next = 1 (it doesn't matter for restore)
        when(scenarioVersionRepository.findFirstByScenarioIdOrderByVersionNoDesc(scenarioId))
                .thenReturn(Optional.empty());
        when(scenarioRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.restoreVersion(
                        scenarioId, versionNo));

        assertNotNull(result);
        assertEquals(versionName, scenario.getName());
        assertEquals(versionDescription, scenario.getDescription());
        assertEquals(versionGraphData, scenario.getGraphData());

        verify(scenarioVersionRepository).save(any(ScenarioVersion.class));
        verify(scenarioRepository).save(scenarioCaptor.capture());
        assertEquals(scenarioId, scenarioCaptor.getValue().getId());
    }

    @Test
    void testRestoreVersion_savesSnapshotBeforeRestore() {
        int versionNo = 1;

        ScenarioVersion version = new ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenarioId);
        version.setVersionNo(versionNo);
        version.setName("v1");
        version.setGraphData(Map.of("key", "data"));

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdAndVersionNo(scenarioId, versionNo))
                .thenReturn(Optional.of(version));
        // snapshotVersion: no existing version → next version = 1
        when(scenarioVersionRepository.findFirstByScenarioIdOrderByVersionNoDesc(scenarioId))
                .thenReturn(Optional.empty());
        when(scenarioRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.restoreVersion(scenarioId, versionNo));

        // restoreVersion calls snapshotVersion internally — verify a snapshot was saved
        verify(scenarioVersionRepository).save(any(ScenarioVersion.class));
    }

    @Test
    void testResumeScenarioRun_withExistingRun_success() {
        ScenarioRun oldRun = new ScenarioRun();
        oldRun.setId(UUID.randomUUID());
        oldRun.setScenarioId(scenarioId);
        oldRun.setStatus("failed");
        oldRun.setStartedAt(OffsetDateTime.now());

        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(oldRun));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioEngine.resumeScenario(any(), any(), any(), any())).thenReturn(Flux.empty());

        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.resumeScenarioRun(
                        oldRun.getId()));

        assertNotNull(result);
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testResumeScenarioRun_withNonExistingRun_throwsException() {
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.empty());
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.resumeScenarioRun(UUID.randomUUID())));
    }

    // -------------------------------------------------------------------------
    // Tests for downloadRunFile (кодовая выверка числами / обогащение формы)
    // -------------------------------------------------------------------------

    private ScenarioRunStep stepWithResult(String nodeId, String result) {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setNodeId(nodeId);
        step.setOutputData(Map.of("result", result));
        return step;
    }

    /**
     * Проекции шагов по узлу: репозиторий отдаёт только шаги запрошенного узла.
     */
    private void stubStepViews(List<ScenarioRunStep> steps) {
        when(scenarioRunStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(any(), any()))
                .thenAnswer(inv -> steps.stream()
                        .filter(s -> s.getNodeId().equals(inv.getArgument(1)))
                        .map(StepOutputViews::of)
                        .toList());
    }

    @Test
    void testDownloadRunFile_excelWithReferenceNumbersAndEnrichment() {
        UUID runId = UUID.randomUUID();
        String donorNodeId = "donor";
        String outNodeId = "out";
        NodeDto donor = NodeDto.builder()
                .id(donorNodeId)
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Извлекатель").build())
                .build();
        String rulesJson = "{\"сверка_чисел\": {\"из_узла\": \"Извлекатель\"},"
                + " \"обогащение_формы\": {\"из_узла\": \"Извлекатель\"}}";
        NodeDto out = NodeDto.builder()
                .id(outNodeId)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Итог").mode("EXCEL")
                        .rules(rulesJson).build())
                .build();
        GraphDataDto graph = new GraphDataDto(List.of(donor, out), List.of());
        scenario.setGraphData(GraphDataMapper.fromDto(graph));

        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        stubStepViews(List.of(
                stepWithResult(donorNodeId, "Сумма 1 234,56 руб. и 5 000,00"),
                stepWithResult(outNodeId, "[{\"исполнитель\":\"ООО Ромашка\",\"сумма\":\"1234.56\"}]")));

        ResponseEntity<Resource> response = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.downloadRunFile(runId, outNodeId));

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertTrue(response.getHeaders().getContentType().toString()
                .contains("spreadsheetml"));
    }

    @Test
    void testDownloadRunFile_excelWithoutConfigUsesDynamicColumns() {
        UUID runId = UUID.randomUUID();
        String outNodeId = "out";
        NodeDto out = NodeDto.builder()
                .id(outNodeId)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Итог").mode("EXCEL")
                        .rules("[]").build())
                .build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(out), List.of())));

        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        stubStepViews(List.of(stepWithResult(outNodeId, "[{\"а\":\"1\",\"б\":\"2\"}]")));

        ResponseEntity<Resource> response = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.downloadRunFile(runId, outNodeId));

        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testDownloadRunFile_textFileMode() {
        UUID runId = UUID.randomUUID();
        String outNodeId = "out";
        NodeDto out = NodeDto.builder()
                .id(outNodeId)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Итог").mode("TEXT_FILE").build())
                .build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(out), List.of())));

        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        stubStepViews(List.of(stepWithResult(outNodeId, "текст результата")));

        ResponseEntity<Resource> response = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.downloadRunFile(runId, outNodeId));

        assertEquals(200, response.getStatusCode().value());
        assertTrue(response.getHeaders().getContentType().toString().contains("text/plain"));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testDownloadRunFile_unknownModeThrowsNotFound() {
        UUID runId = UUID.randomUUID();
        String outNodeId = "out";
        NodeDto out = NodeDto.builder()
                .id(outNodeId)
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Итог").mode("SOMETHING_ELSE").build())
                .build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(out), List.of())));

        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.downloadRunFile(runId, outNodeId)));

        assertEquals(404, ex.getStatusCode().value());
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testDownloadRunFile_nodeNotInGraphThrowsNotFound() {
        UUID runId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        ResponseStatusException ex = assertThrows(ResponseStatusException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.downloadRunFile(runId, "missing")));

        assertEquals(404, ex.getStatusCode().value());
    }

    // -------------------------------------------------------------------------
    // Tests for clip-обрезки полей до лимитов схемы ответа
    // -------------------------------------------------------------------------

    @Test
    void testCreateScenario_truncatesLongNameAndDescription() {
        String longName = "N".repeat(100);
        String longDesc = "D".repeat(300);
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        longName, longDesc, new GraphDataDto(List.of(), List.of())));

        assertNotNull(result);
        verify(scenarioRepository).save(scenarioCaptor.capture());
        // 64-символьный лимит обрезает многоточием: 63 + "…"
        assertEquals(ScenarioService.MAX_NAME_LENGTH, scenarioCaptor.getValue().getName().length());
        assertEquals(ScenarioService.MAX_DESCRIPTION_LENGTH,
                scenarioCaptor.getValue().getDescription().length());
        assertTrue(scenarioCaptor.getValue().getName().endsWith("…"));
    }

    @Test
    void testUpdateScenario_truncatesLongNameWithClip() {
        String longName = "X".repeat(80);
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, longName, null, null));

        assertNotNull(result);
        assertEquals(ScenarioService.MAX_NAME_LENGTH, scenario.getName().length());
        assertTrue(scenario.getName().endsWith("…"));
    }

    @Test
    void testUpdateScenario_setsSharedFlag() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, null, null, null, true));

        assertNotNull(result);
        assertTrue(Boolean.TRUE.equals(scenario.getShared()));
    }

    // -------------------------------------------------------------------------
    // Автор прогона: общий сценарий запускают разные пользователи
    // -------------------------------------------------------------------------

    private ScenarioRun authoredRun(String author) {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        run.setStartedAt(OffsetDateTime.now());
        run.setUserId(author);
        return run;
    }

    @Test
    void testRunScenario_sharedScenario_recordsRunAuthor() {
        scenario.setShared(true);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        ArgumentCaptor<ScenarioRun> runCaptor = ArgumentCaptor.forClass(ScenarioRun.class);
        when(scenarioRunRepository.save(runCaptor.capture())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any())).thenReturn(Flux.empty());

        CurrentUserHolder.withUser("ALICE", () -> scenarioService.runScenario(scenarioId, false));

        assertEquals("ALICE", runCaptor.getValue().getUserId());
    }

    @Test
    void testGetScenarioRuns_sharedScenario_eachUserSeesOnlyOwnRuns() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        ScenarioRun bobRun = authoredRun("BOB");
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findByScenarioIdAndUserIdOrderByStartedAtDesc(scenarioId, "ALICE"))
                .thenReturn(List.of(aliceRun));
        when(scenarioRunRepository.findByScenarioIdAndUserIdOrderByStartedAtDesc(scenarioId, "BOB"))
                .thenReturn(List.of(bobRun));

        List<ScenarioRunResponse> alice = CurrentUserHolder.withUser("ALICE",
                () -> scenarioService.getScenarioRuns(scenarioId));
        List<ScenarioRunResponse> bob = CurrentUserHolder.withUser("BOB",
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertEquals(List.of(aliceRun.getId()), alice.stream().map(ScenarioRunResponse::id).toList());
        assertEquals(List.of(bobRun.getId()), bob.stream().map(ScenarioRunResponse::id).toList());
        verify(scenarioRunRepository, never()).findOwnerRuns(any(), any());
        verify(scenarioRunRepository, never()).findByScenarioIdOrderByStartedAtDesc(any());
    }

    @Test
    void testGetScenarioRuns_owner_seesOwnAndLegacyRuns() {
        String owner = userId.toString();
        ScenarioRun ownRun = authoredRun(owner);
        ScenarioRun legacyRun = authoredRun(null);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findOwnerRuns(scenarioId, owner)).thenReturn(List.of(ownRun, legacyRun));

        List<ScenarioRunResponse> result = CurrentUserHolder.withUser(owner,
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertEquals(List.of(ownRun.getId(), legacyRun.getId()),
                result.stream().map(ScenarioRunResponse::id).toList());
        verify(scenarioRunRepository, never()).findByScenarioIdAndUserIdOrderByStartedAtDesc(any(), any());
    }

    @Test
    void testGetScenarioRun_foreignRun_accessDeniedEvenForScenarioOwner() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = aliceRun.getId();
        String owner = userId.toString();

        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("BOB",
                () -> scenarioService.getScenarioRun(runId)));
        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser(owner,
                () -> scenarioService.getScenarioRun(runId)));
        verify(scenarioRunStepRepository, never()).findByRunIdOrderByStartedAtAsc(any());
    }

    @Test
    void testGetScenarioRun_authorNotScenarioOwner_seesOwnRun() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser("ALICE",
                () -> scenarioService.getScenarioRun(aliceRun.getId()));

        assertEquals(aliceRun.getId(), result.id());
    }

    @Test
    void testGetScenarioRun_legacyRunWithoutAuthor_onlyScenarioOwner() {
        scenario.setShared(true);
        ScenarioRun legacyRun = authoredRun(null);
        when(scenarioRunRepository.findById(legacyRun.getId())).thenReturn(Optional.of(legacyRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = legacyRun.getId();

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(runId));

        assertEquals(runId, result.id());
        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("ALICE",
                () -> scenarioService.getScenarioRun(runId)));
    }

    @Test
    void testExtractToDocx_foreignRun_accessDenied() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = aliceRun.getId();

        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("BOB",
                () -> scenarioService.extractToDocx(runId, true)));
    }

    @Test
    void testExtractToDocx_authorNotScenarioOwner_generatesDocx() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));

        ResponseEntity<Resource> result = CurrentUserHolder.withUser("ALICE",
                () -> scenarioService.extractToDocx(aliceRun.getId(), false));

        assertEquals(200, result.getStatusCode().value());
    }

    @Test
    void testResumeScenarioRun_foreignRun_accessDenied() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        aliceRun.setStatus("failed");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = aliceRun.getId();

        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("BOB",
                () -> scenarioService.resumeScenarioRun(runId)));
        verify(scenarioRunStepRepository, never()).findByRunIdOrderByStartedAtAsc(any());
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).resumeScenario(any(), any(), any(), any());
    }

    @Test
    void testResumeScenarioRun_runningRun_throwsScenarioException() {
        // идущий (в том числе ждущий в очереди) прогон возобновлять нельзя: работа задвоилась бы
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        aliceRun.setStatus("running");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = aliceRun.getId();

        ScenarioException error = assertThrows(ScenarioException.class, () -> CurrentUserHolder.withUser("ALICE",
                () -> scenarioService.resumeScenarioRun(runId)));

        assertTrue(error.getMessage().contains("завершившийся ошибкой"));
        verify(scenarioRunStepRepository, never()).findByRunIdOrderByStartedAtAsc(any());
        verify(scenarioRunRepository, never()).save(any());
        verify(scenarioEngine, never()).resumeScenario(any(), any(), any(), any());
    }

    @Test
    void testResumeScenarioRun_completedRun_throwsScenarioException() {
        // успешный прогон возобновлять тоже нельзя (кнопка есть только у упавших)
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = aliceRun.getId();

        assertThrows(ScenarioException.class, () -> CurrentUserHolder.withUser("ALICE",
                () -> scenarioService.resumeScenarioRun(runId)));
        verify(scenarioEngine, never()).resumeScenario(any(), any(), any(), any());
    }

    @Test
    void testResumeScenarioRun_ownRun_newRunKeepsAuthor() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        aliceRun.setStatus("failed");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        ArgumentCaptor<ScenarioRun> runCaptor = ArgumentCaptor.forClass(ScenarioRun.class);
        when(scenarioRunRepository.save(runCaptor.capture())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.resumeScenario(any(), any(), any(), any())).thenReturn(Flux.empty());

        CurrentUserHolder.withUser("ALICE", () -> scenarioService.resumeScenarioRun(aliceRun.getId()));

        assertEquals("ALICE", runCaptor.getValue().getUserId());
    }

    @Test
    void testDownloadRunFile_foreignRun_accessDenied() {
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = aliceRun.getId();

        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("BOB",
                () -> scenarioService.downloadRunFile(runId, "out")));
        verify(scenarioRunStepRepository, never()).findViewByRunIdAndNodeIdOrderByStartedAtAsc(any(), any());
    }

    @Test
    void testDownloadRunFile_authorNotScenarioOwner_getsFile() {
        NodeDto out = NodeDto.builder()
                .id("out")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Итог").mode("TEXT_FILE").build())
                .build();
        scenario.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(List.of(out), List.of())));
        scenario.setShared(true);
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        stubStepViews(List.of(stepWithResult("out", "итог Алисы")));

        ResponseEntity<Resource> response = CurrentUserHolder.withUser("ALICE",
                () -> scenarioService.downloadRunFile(aliceRun.getId(), "out"));

        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testCheckRunAccess_authorAllowedOthersDenied() {
        ScenarioRun aliceRun = authoredRun("ALICE");
        when(scenarioRunRepository.findById(aliceRun.getId())).thenReturn(Optional.of(aliceRun));
        UUID runId = aliceRun.getId();
        String owner = userId.toString();

        assertDoesNotThrow(() -> CurrentUserHolder.withUser("ALICE", () -> {
            scenarioService.checkRunAccess(runId);
            return null;
        }));
        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser(owner, () -> {
            scenarioService.checkRunAccess(runId);
            return null;
        }));
        // у прогона есть автор — владелец сценария не запрашивается
        verify(scenarioRepository, never()).findById(any());
    }

    @Test
    void testCheckRunAccess_legacyRun_scenarioOwnerOnly() {
        ScenarioRun legacyRun = authoredRun(null);
        when(scenarioRunRepository.findById(legacyRun.getId())).thenReturn(Optional.of(legacyRun));
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        UUID runId = legacyRun.getId();
        String owner = userId.toString();

        assertDoesNotThrow(() -> CurrentUserHolder.withUser(owner, () -> {
            scenarioService.checkRunAccess(runId);
            return null;
        }));
        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("ALICE", () -> {
            scenarioService.checkRunAccess(runId);
            return null;
        }));
    }

    @Test
    void testCheckRunAccess_runNotFound_throwsNotFound() {
        UUID runId = UUID.randomUUID();
        when(scenarioRunRepository.findById(runId)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> CurrentUserHolder.withUser("ALICE", () -> {
            scenarioService.checkRunAccess(runId);
            return null;
        }));
    }

    // -------------------------------------------------------------------------
    // corp15: хранится не больше app.scenario.versions-keep версий сценария
    // -------------------------------------------------------------------------

    @Test
    void testUpdateScenario_keepsOnlyConfiguredNumberOfVersions() {
        ReflectionTestUtils.setField(scenarioService, "versionsKeep", 3);
        ScenarioVersion last = new ScenarioVersion();
        last.setVersionNo(10);
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);
        when(scenarioVersionRepository.findFirstByScenarioIdOrderByVersionNoDesc(scenarioId)).thenReturn(Optional.of(last));

        CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.updateScenario(scenarioId, "Имя", null, null));

        // сохранена версия 11; остаются три последних (9, 10, 11) — версии до 8 включительно удаляются
        verify(scenarioVersionRepository).save(any(ScenarioVersion.class));
        verify(scenarioVersionRepository).deleteOldVersions(scenarioId, 8);
    }

    @Test
    void testUpdateScenario_withFewVersions_doesNotPrune() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.updateScenario(scenarioId, "Имя", null, null));

        verify(scenarioVersionRepository, never()).deleteOldVersions(any(), anyInt());
    }

    @Test
    void testRestoreVersion_prunesOldVersionsAfterSnapshot() {
        ReflectionTestUtils.setField(scenarioService, "versionsKeep", 2);
        ScenarioVersion version = new ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenarioId);
        version.setVersionNo(1);
        version.setName("v1");
        ScenarioVersion last = new ScenarioVersion();
        last.setVersionNo(5);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdAndVersionNo(scenarioId, 1)).thenReturn(Optional.of(version));
        when(scenarioVersionRepository.findFirstByScenarioIdOrderByVersionNoDesc(scenarioId)).thenReturn(Optional.of(last));
        when(scenarioRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        CurrentUserHolder.withUser(userId.toString(), () -> scenarioService.restoreVersion(scenarioId, 1));

        // снимок получил номер 6; остаются 5 и 6 — версии до 4 включительно удаляются
        verify(scenarioVersionRepository).deleteOldVersions(scenarioId, 4);
    }
}
