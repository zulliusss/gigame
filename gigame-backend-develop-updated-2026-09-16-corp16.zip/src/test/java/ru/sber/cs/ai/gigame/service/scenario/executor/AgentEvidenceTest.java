package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты рабочей тетради агента: разбор, план, цитатная валидация,
 * контроль покрытия плана.
 */
class AgentEvidenceTest {

    private static final String NOTEBOOK = """
            Вот результат:
            {"записи": [
              {"пункт": 1, "название": "НМЦ", "значение": "161560083.00",
               "цитата": "НМЦД составляет 161 560 083,00 рублей",
               "документ": "извещение.docx"},
              {"пункт": 2, "название": "Сумма акта", "значение": "999",
               "цитата": "Итого: 999 999,99 рублей",
               "документ": "акт.pdf"},
              {"пункт": 3, "название": "Рейтинги", "значение": "не указано",
               "цитата": "", "документ": ""}
            ]}""";

    @Test
    void parse_extractsEntriesFromSurroundingText() {
        List<AgentEvidence.Entry> entries = AgentEvidence.parse(NOTEBOOK);

        assertEquals(3, entries.size());
        assertEquals(1, entries.get(0).item());
        assertEquals("161560083.00", entries.get(0).value());
    }

    @Test
    void parse_returnsEmptyOnPlainText() {
        assertTrue(AgentEvidence.parse("обычный текст без тетради").isEmpty());
        assertTrue(AgentEvidence.parse("{\"другое\": 1}").isEmpty());
        assertTrue(AgentEvidence.parse(null).isEmpty());
    }

    @Test
    void parsePlan_readsJsonArray() {
        List<String> plan = AgentEvidence.parsePlan(
                "План такой:\n[\"Найти НМЦ\", \"Выписать технологии\"]\nГотово.");

        assertEquals(List.of("Найти НМЦ", "Выписать технологии"), plan);
        assertTrue(AgentEvidence.parsePlan("нет массива").isEmpty());
    }

    @Test
    void parseSearchPlan_readsQueriesWithOptionalDocs() {
        var queries = AgentEvidence.parseSearchPlan(
                "[{\"запрос\": \"НМЦ\", \"документы\": [\"извещение\"]}, "
                        + "{\"запрос\": \"технологии\"}]");

        assertEquals(2, queries.size());
        assertEquals("НМЦ", queries.get(0).query());
        assertEquals(List.of("извещение"), queries.get(0).docs());
        assertNull(queries.get(1).docs());
        assertTrue(AgentEvidence.parseSearchPlan("мусор").isEmpty());
    }

    @Test
    void validate_confirmsQuoteDespiteSpacingAndCase() {
        var entries = AgentEvidence.parse(NOTEBOOK);
        Map<String, String> docs = Map.of(
                "извещение.docx", "… нмцд СОСТАВЛЯЕТ 161 560 083,00 РУБЛЕЙ …",
                "акт.pdf", "совсем другой текст");

        var validated = AgentEvidence.validate(entries, docs);

        assertEquals(AgentEvidence.CONFIRMED, validated.get(0).verdict());
        // цитаты нет в акте — значение аннулируется вердиктом
        assertEquals(AgentEvidence.QUOTE_NOT_FOUND, validated.get(1).verdict());
        // «не указано» без цитаты — легально
        assertEquals(AgentEvidence.CONFIRMED, validated.get(2).verdict());
    }

    @Test
    void validate_flagsMissingDocAndMissingQuote() {
        var entries = List.of(
                new AgentEvidence.Entry(1, "x", "значение", "цитата", "нет-такого.pdf", null),
                new AgentEvidence.Entry(2, "y", "значение", "", "извещение.docx", null));

        var validated = AgentEvidence.validate(entries, Map.of("извещение.docx", "текст"));

        assertEquals(AgentEvidence.DOC_NOT_FOUND, validated.get(0).verdict());
        assertEquals(AgentEvidence.NO_QUOTE, validated.get(1).verdict());
    }

    @Test
    void validate_calculatedValueWithSourceNumbersIsNotAQuestion() {
        // порог = НМЦ × 100% — дословной цитаты нет, но исходные числа в документе есть
        var entries = List.of(new AgentEvidence.Entry(1, "Порог", "161560083",
                "порог = 161 560 083 × 100%", "извещение.docx", null));
        Map<String, String> docs = Map.of("извещение.docx",
                "НМЦД 161 560 083,00 рублей; требуется 100% сопоставимого опыта");

        var validated = AgentEvidence.validate(entries, docs);

        assertEquals(AgentEvidence.CALCULATED, validated.get(0).verdict());
        assertTrue(AgentEvidence.buildQuestions(List.of("Порог"), validated).isEmpty());

        // а с числом, которого в документе нет, — по-прежнему «не найдена»
        var fake = AgentEvidence.validate(List.of(new AgentEvidence.Entry(1, "Порог",
                "999", "расчёт из 999 888 777", "извещение.docx", null)), docs);
        assertEquals(AgentEvidence.QUOTE_NOT_FOUND, fake.get(0).verdict());
    }

    @Test
    void uncoveredItems_reportsMissingPlanPoints() {
        var entries = AgentEvidence.parse(NOTEBOOK);

        Set<Integer> uncovered = AgentEvidence.uncoveredItems(5, entries);

        assertEquals(Set.of(4, 5), uncovered);
    }

    @Test
    void validate_rescuesEntryWithWrongDocName() {
        Map<String, String> docs = Map.of(
                "Акт к заявке 8 №1 от 14.11.2025.pdf", "Итого с НДС: 36 302 330,00 руб.",
                "извещение.docx", "НМЦД 161 560 083,00");

        // дословная цитата, но поле «документ» — не имя файла: спасена, документ исправлен
        var literal = AgentEvidence.validate(List.of(new AgentEvidence.Entry(
                1, "Сумма", "36302330", "Итого с НДС: 36 302 330,00 руб.",
                "Акты заявки №8", null)), docs);
        assertEquals(AgentEvidence.CONFIRMED, literal.get(0).verdict());
        assertEquals("Акт к заявке 8 №1 от 14.11.2025.pdf", literal.get(0).doc());

        // пересказ с числами, найденными в единственном документе — расчётное
        var numeric = AgentEvidence.validate(List.of(new AgentEvidence.Entry(
                1, "Сумма", "36302330", "сумма акта 36302330 рублей",
                "неизвестный.pdf", null)), docs);
        assertEquals(AgentEvidence.CALCULATED, numeric.get(0).verdict());

        // числа, которых нет ни в одном документе, — по-прежнему отклонение
        var missing = AgentEvidence.validate(List.of(new AgentEvidence.Entry(
                1, "Сумма", "99999999", "сумма акта 99999999 рублей",
                "неизвестный.pdf", null)), docs);
        assertEquals(AgentEvidence.DOC_NOT_FOUND, missing.get(0).verdict());
    }

    @Test
    void uncoveredItems_rejectedEntryDoesNotCoverPlanPoint() {
        Map<String, String> docs = Map.of("акт.pdf", "Итого с НДС: 24 965 217,00 руб.");
        var validated = AgentEvidence.validate(List.of(
                new AgentEvidence.Entry(1, "Сумма", "24 965 217,00",
                        "Итого с НДС: 24 965 217,00 руб.", "акт.pdf", null),
                new AgentEvidence.Entry(2, "Технологии", "Java",
                        "пересказ, которого нет в документе", "акт.pdf", null),
                new AgentEvidence.Entry(3, "Акты", "не указано", "", "", null)), docs);

        Set<Integer> uncovered = AgentEvidence.uncoveredItems(3, validated);

        // подтверждённая запись и честное «не указано» закрывают пункты,
        // отклонённая (цитата-пересказ) — нет: пункт уходит в добор
        assertEquals(Set.of(2), uncovered);
    }

    @Test
    void parse_survivesSecondJsonAndBracesInExplanation() {
        String answer = "Промежуточно: {\"черновик\": true}\n" + NOTEBOOK
                + "\nПояснение: см. {п. 3} и {\"итого\": 3}.";

        List<AgentEvidence.Entry> entries = AgentEvidence.parse(answer);

        assertEquals(3, entries.size());
        assertEquals("Сумма акта", entries.get(1).name());
    }

    @Test
    void parsePlan_skipsFootnoteBeforeArray() {
        List<String> plan = AgentEvidence.parsePlan("См. сноску [1].\nПлан:\n[\"Найти НМЦ\", \"Выписать сроки\"]\nГотово [2].");

        assertEquals(List.of("Найти НМЦ", "Выписать сроки"), plan);
        assertEquals(List.of("1", "2"), AgentEvidence.parsePlan("[1, 2]"));
        assertTrue(AgentEvidence.parseSearchPlan("[1] и [\"x\"]").isEmpty());
        assertEquals(1, AgentEvidence.parseSearchPlan("см. [1]\n[{\"запрос\": \"НМЦ\"}]").size());
    }

    @Test
    void toJson_containsVerdicts() {
        var validated = AgentEvidence.validate(AgentEvidence.parse(NOTEBOOK),
                Map.of("извещение.docx", "НМЦД составляет 161 560 083,00 рублей"));

        String json = AgentEvidence.toJson(validated);

        assertTrue(json.contains(AgentEvidence.CONFIRMED));
        assertTrue(json.contains("161560083.00"));
    }
}
