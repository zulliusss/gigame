package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты инструментов агентского режима: список, чтение фрагментами,
 * поиск с контекстом, поиск по БЗ, лимит обращений.
 */
class AgentDocumentToolsTest {

    private static AgentDocumentTools tools(String... nameAndText) {
        var docs = new java.util.ArrayList<AgentDocumentTools.DocEntry>();
        for (int i = 0; i + 1 < nameAndText.length; i += 2) {
            docs.add(new AgentDocumentTools.DocEntry(nameAndText[i], nameAndText[i + 1]));
        }
        return new AgentDocumentTools(docs, null);
    }

    @Test
    void documentSummary_returnsNamesAndSizes() {
        var t = tools("извещение.pdf", "текст извещения", "заявка.docx", "текст заявки участника");

        List<String> summary = t.documentSummary();

        assertEquals(2, summary.size());
        assertEquals("извещение.pdf (" + "текст извещения".length() + " символов)", summary.get(0));
    }

    @Test
    void readDocument_chunksWithNextOffset() {
        String longText = "А".repeat(AgentDocumentTools.READ_CHUNK + 500);
        var t = tools("big.txt", longText);

        Map<String, Object> first = t.readDocument(new AgentDocumentTools.ReadRequest("big.txt", 0));
        assertEquals(AgentDocumentTools.READ_CHUNK, ((String) first.get("fragment")).length());
        assertEquals(AgentDocumentTools.READ_CHUNK, first.get("next_offset"));

        Map<String, Object> second = t.readDocument(
                new AgentDocumentTools.ReadRequest("big.txt", AgentDocumentTools.READ_CHUNK));
        assertEquals(500, ((String) second.get("fragment")).length());
        assertNull(second.get("next_offset"));
    }

    @Test
    void readDocument_findsByNameSubstring() {
        var t = tools("archive.zip/Договор 50003501273/акт.pdf", "содержимое акта");

        Map<String, Object> result = t.readDocument(new AgentDocumentTools.ReadRequest("акт.pdf", 0));

        assertEquals("содержимое акта", result.get("fragment"));
    }

    @Test
    void readDocument_unknownName_returnsError() {
        var t = tools("a.txt", "текст");

        Map<String, Object> result = t.readDocument(new AgentDocumentTools.ReadRequest("нет.txt", 0));

        assertNotNull(result.get("error"));
    }

    @Test
    void searchDocuments_caseInsensitiveWithContext() {
        var t = tools("извещение.pdf",
                "Раздел 5. НМЦД лота составляет 511464226 рублей. Прочее.");

        Map<String, Object> result = t.searchDocuments(new AgentDocumentTools.SearchRequest("нмцд"));

        @SuppressWarnings("unchecked")
        var hits = (List<Map<String, Object>>) result.get("hits");
        assertEquals(1, hits.size());
        assertTrue(((String) hits.get(0).get("context")).contains("511464226"));
    }

    @Test
    void searchDocuments_phraseFallsBackToLongestWord() {
        var t = tools("извещение.pdf",
                "12. Дата начала срока подачи заявок 08.04.2026");

        Map<String, Object> result = t.searchDocuments(
                new AgentDocumentTools.SearchRequest("дата начала подачи заявок"));

        @SuppressWarnings("unchecked")
        var hits = (List<Map<String, Object>>) result.get("hits");
        assertEquals(1, hits.size());
        assertTrue(((String) hits.get(0).get("context")).contains("08.04.2026"));
        assertTrue(((String) result.get("note")).contains("Точная фраза не найдена"));
    }

    @Test
    void searchDocuments_findsNumberWithThousandSeparators() {
        var t = tools("акт.pdf", "Итого: 1 808 920,00 рублей, в том числе НДС");

        Map<String, Object> result = t.searchDocuments(
                new AgentDocumentTools.SearchRequest("1808920.00"));

        @SuppressWarnings("unchecked")
        var hits = (List<Map<String, Object>>) result.get("hits");
        assertEquals(1, hits.size());
        assertTrue(((String) hits.get(0).get("context")).contains("1 808 920"));
    }

    @Test
    void sequentialReads_fourthReturnsDocumentTail() {
        // анти-листание смягчено: вместо запрета отдаётся ХВОСТ документа —
        // итоговые строки («Всего к оплате») живут в конце, жёсткий обрыв
        // терял хвостовые суммы актов (кейс Хилько, акт 2431)
        String longText = "А".repeat(AgentDocumentTools.READ_CHUNK * 6 - 7) + "ИТОГ 42";
        var t = tools("big.docx", longText);
        int offset = 0;
        for (int i = 0; i < AgentDocumentTools.MAX_SEQUENTIAL_READS; i++) {
            Map<String, Object> r = t.readDocument(
                    new AgentDocumentTools.ReadRequest("big.docx", offset));
            assertFalse(r.containsKey("error"));
            offset = (Integer) r.get("next_offset");
        }

        Map<String, Object> fourth = t.readDocument(
                new AgentDocumentTools.ReadRequest("big.docx", offset));

        assertFalse(fourth.containsKey("error"));
        assertTrue(((String) fourth.get("warning")).contains("КОНЕЦ"));
        assertTrue(((String) fourth.get("fragment")).endsWith("ИТОГ 42"));
        // после поиска чтение снова разрешено
        t.searchDocuments(new AgentDocumentTools.SearchRequest("ААА"));
        assertFalse(t.readDocument(new AgentDocumentTools.ReadRequest("big.docx", offset))
                .containsKey("error"));
    }

    @Test
    void repeatedCall_returnsLoopBreakInstruction() {
        var t = tools("извещение.pdf", "НМЦ 161560083 рублей");
        var request = new AgentDocumentTools.SearchRequest("НМЦ");

        assertTrue(t.searchDocuments(request).containsKey("hits"));
        Map<String, Object> repeat = t.searchDocuments(request);

        assertTrue(((String) repeat.get("error")).contains("уже выполнялся"));
        // наблюдение первого вызова сохранено для добивающего вызова
        assertTrue(t.observationsSummary().contains("161560083"));
    }

    @Test
    void searchDocuments_missing_returnsNote() {
        var t = tools("a.txt", "текст");

        Map<String, Object> result = t.searchDocuments(new AgentDocumentTools.SearchRequest("гарантия"));

        assertNotNull(result.get("note"));
    }

    @Test
    void callLimit_exhausted_returnsFinalizeInstruction() {
        var t = tools("a.txt", "текст");
        for (int i = 0; i < AgentDocumentTools.MAX_TOOL_CALLS; i++) {
            // запросы уникальные — дедупликация повторов не срабатывает
            var request = new AgentDocumentTools.SearchRequest("текст" + i);
            assertFalse(((String) t.searchDocuments(request)
                    .getOrDefault("error", "")).contains("финальный ответ"));
        }

        Map<String, Object> over = t.searchDocuments(new AgentDocumentTools.SearchRequest("ещё"));

        assertTrue(((String) over.get("error")).contains("финальный ответ"));
    }

    @Test
    void writeFile_storesWorkingFileExcludedFromValidationSnapshot() {
        var t = tools("акт.pdf", "Итого 100 руб.");
        var stored = new java.util.HashMap<String, String>();
        t.setWriteSink((name, text) -> {
            stored.put(name, text);
            return null;
        });

        Map<String, Object> ok = t.writeFile(
                new AgentDocumentTools.WriteRequest("конспект.md", "суммы: 100"));

        assertTrue((Boolean) ok.get("ok"));
        assertEquals("суммы: 100", stored.get("конспект.md"));
        // файл читается инструментами этого же агента…
        Map<String, Object> read = t.readDocument(
                new AgentDocumentTools.ReadRequest("конспект.md", 0));
        assertEquals("суммы: 100", read.get("fragment"));
        // …но НЕ является источником цитат (анти-самоподтверждение)
        assertFalse(t.docsSnapshot().containsKey("конспект.md"));
        assertTrue(t.docsSnapshot().containsKey("акт.pdf"));

        // ошибка приёмника (занятое имя) возвращается модели
        t.setWriteSink((name, text) -> "Имя занято исходным документом");
        Map<String, Object> err = t.writeFile(
                new AgentDocumentTools.WriteRequest("акт.pdf", "x"));
        assertNotNull(err.get("error"));
    }

    @Test
    void runCancelled_toolCallReturnsFinalizeInstruction() {
        var t = tools("a.txt", "текст");
        t.setRunCancelled(() -> true);

        Map<String, Object> result = t.searchDocuments(new AgentDocumentTools.SearchRequest("текст"));

        assertTrue(((String) result.get("error")).contains("финальный ответ"));
    }

    @Test
    void searchDocuments_fruitlessRephrase_rejectedWithoutSearch() {
        var t = tools("акт.pdf", "Таблица работ: Java, Python");

        // бесплодный запрос запоминается…
        assertNotNull(t.searchDocuments(
                new AgentDocumentTools.SearchRequest("технологии в таблице")).get("note"));
        // …его наращивание словами (обход дедупа) отклоняется без поиска
        Map<String, Object> rejected = t.searchDocuments(
                new AgentDocumentTools.SearchRequest("технологии в таблице работ к ней"));

        assertTrue(((String) rejected.get("error")).contains("Смени стратегию"));
    }

    @Test
    void searchDocuments_shorterQueryAfterFruitless_allowed() {
        var t = tools("акт.pdf", "Работы выполнялись на Java и Python");
        t.searchDocuments(new AgentDocumentTools.SearchRequest("технологии в таблице работ"));

        // укорачивание/смена запроса — легитимное уточнение, не блокируется
        Map<String, Object> ok = t.searchDocuments(new AgentDocumentTools.SearchRequest("Java"));

        assertFalse(ok.containsKey("error"));
        assertFalse(((List<?>) ok.get("hits")).isEmpty());
    }

    @Test
    void searchDocuments_fruitlessStreak_forcesStrategyChange() {
        var t = tools("a.txt", "содержимое документа");
        t.searchDocuments(new AgentDocumentTools.SearchRequest("гарантия"));
        t.searchDocuments(new AgentDocumentTools.SearchRequest("неустойка"));

        // третий пустой подряд — директива сменить стратегию
        Map<String, Object> third = t.searchDocuments(new AgentDocumentTools.SearchRequest("залог"));
        assertTrue(((String) third.get("note")).contains("Смени стратегию"));

        // успешный поиск сбрасывает серию — дальше обычная подсказка
        t.searchDocuments(new AgentDocumentTools.SearchRequest("содержимое"));
        Map<String, Object> afterHit = t.searchDocuments(new AgentDocumentTools.SearchRequest("штраф"));
        assertFalse(((String) afterHit.get("note")).contains("Смени стратегию"));
    }

    @Test
    void searchDocuments_docsFilterLimitsScope() {
        var t = tools("извещение.docx", "НМЦ 100 рублей", "заявка.pdf", "НМЦ 200 рублей");

        Map<String, Object> filtered = t.searchDocuments(
                new AgentDocumentTools.SearchRequest("НМЦ", List.of("заявка")));

        @SuppressWarnings("unchecked")
        var hits = (List<Map<String, Object>>) filtered.get("hits");
        assertEquals(1, hits.size());
        assertEquals("заявка.pdf", hits.get(0).get("name"));

        // фильтр, не поймавший ни одного документа, — поиск по всем
        Map<String, Object> loose = t.searchDocuments(
                new AgentDocumentTools.SearchRequest("рублей", List.of("несуществующий")));
        @SuppressWarnings("unchecked")
        var looseHits = (List<Map<String, Object>>) loose.get("hits");
        assertEquals(2, looseHits.size());
    }

    @Test
    void prefetch_returnsCompactFragmentsWithoutModelCalls() {
        var t = tools("извещение.docx", "Раздел 5. НМЦД составляет 161 560 083,00 рублей.");

        String summary = t.prefetch(List.of(
                new AgentDocumentTools.SearchRequest("НМЦД", null),
                new AgentDocumentTools.SearchRequest("гарантия", null)));

        assertTrue(summary.contains("161 560 083"));
        assertTrue(summary.contains("не найдено"));
        // предвыборка не тратит бюджет обращений модели
        assertEquals(0, t.callCount());
    }

    @Test
    void searchKnowledgeBase_delegatesToSearcher() {
        var t = new AgentDocumentTools(List.of(),
                q -> List.of("фрагмент про " + q));

        Map<String, Object> result = t.searchKnowledgeBase(
                new AgentDocumentTools.KbSearchRequest("реестр заявок"));

        @SuppressWarnings("unchecked")
        var chunks = (List<String>) result.get("chunks");
        assertEquals(List.of("фрагмент про реестр заявок"), chunks);
    }

    @Test
    void callbacks_includeKbToolOnlyWhenConfigured() {
        // поиск + чтение + think-tool; с БЗ добавляется search_knowledge_base
        assertEquals(3, tools("a.txt", "т").callbacks().size());
        assertEquals(4, new AgentDocumentTools(List.of(), q -> List.of()).callbacks().size());
    }

    @Test
    void noteThought_logsAndLimits() {
        var t = tools("a.txt", "т");

        Map<String, Object> first = t.noteThought(
                new AgentDocumentTools.ThoughtRequest("ищу НМЦ в извещении"));

        assertEquals(true, first.get("ok"));
        assertTrue(t.callLog().get(0).contains("ищу НМЦ"));
        for (int i = 0; i < AgentDocumentTools.MAX_THOUGHTS; i++) {
            t.noteThought(new AgentDocumentTools.ThoughtRequest("мысль " + i));
        }
        assertTrue(((String) t.noteThought(new AgentDocumentTools.ThoughtRequest("ещё"))
                .get("error")).contains("Достаточно"));
    }

    @Test
    void kbChunksJoinCitationCorpus() {
        // норма из базы знаний должна проходить цитатную валидацию наравне с документами комплекта
        var t = new AgentDocumentTools(List.of(new AgentDocumentTools.DocEntry("ТЗ.docx", "текст задания")),
                q -> List.of("Статья 3. 1. При закупке заказчики руководствуются принципами: 2) равноправие, справедливость"));
        assertFalse(t.docsSnapshot().keySet().stream().anyMatch(k -> k.startsWith("база знаний")));

        t.searchKnowledgeBase(new AgentDocumentTools.KbSearchRequest("223-ФЗ статья 3 часть 1"));

        var snapshot = t.docsSnapshot();
        assertEquals("текст задания", snapshot.get("ТЗ.docx"));
        assertTrue(snapshot.get("база знаний: 223-ФЗ статья 3 часть 1 #1").contains("равноправие, справедливость"));
        var entries = AgentEvidence.validate(List.of(new AgentEvidence.Entry(1, "норма",
                "п. 2 ч. 1 ст. 3 223-ФЗ", "равноправие, справедливость", "223-ФЗ статья 3", null)), snapshot);
        assertEquals(AgentEvidence.CONFIRMED, entries.get(0).verdict());
    }

    @Test
    void kbArticleReturnsExactPartAndJoinsCorpus() {
        var t = new AgentDocumentTools(List.of(new AgentDocumentTools.DocEntry("ТЗ.docx", "текст")), q -> List.of());
        t.setNormIndex(() -> NormIndex.build(Map.of("223-ФЗ статья 3 Принципы.txt",
                "Статья 3.\n1. Принципы:\n1) открытость;\n2) равноправие, справедливость;\n2. Иное.")));

        Map<String, Object> out = t.kbArticle(new AgentDocumentTools.ArticleRequest("п. 2 ч. 1 ст. 3 223-ФЗ (равноправие)"));

        @SuppressWarnings("unchecked")
        var norms = (List<Map<String, Object>>) out.get("нормы");
        assertEquals(1, norms.size());
        assertTrue(String.valueOf(norms.get(0).get("текст")).contains("2) равноправие, справедливость"));
        assertFalse(String.valueOf(norms.get(0).get("текст")).contains("открытость"));
        assertTrue(t.docsSnapshot().containsKey("база знаний: 223-ФЗ статья 3 Принципы"));
        assertTrue(t.kbArticle(new AgentDocumentTools.ArticleRequest("187-ФЗ")).containsKey("note"));
    }

    @Test
    void domainToolsDelegateToOperations() {
        var t = new AgentDocumentTools(List.of(new AgentDocumentTools.DocEntry("ПЗ.docx", "НМЦД 100 руб.")), null);
        var calls = new java.util.ArrayList<String>();
        t.setOperationRunner((op, params, input) -> {
            calls.add(op + " " + new java.util.TreeMap<>(params) + " " + input);
            return "результат " + op;
        });

        assertEquals("результат сверить_суммы", t.checkAmounts(new AgentDocumentTools.AmountsRequest(null)).get("результат"));
        t.checkPercentages(new AgentDocumentTools.DocsRequest("ПЗ"));
        t.checkDates(new AgentDocumentTools.DocsRequest(null));
        t.extractRegex(new AgentDocumentTools.RegexRequest("Способ закупки\\s*([^\\n]+)", "ПЗ|Извещен", true));
        t.locateQuote(new AgentDocumentTools.QuoteRequest("НМЦД 100 \"руб.\"", null));

        assertEquals("сверить_суммы {метка=НМЦД?} ", calls.get(0));
        assertEquals("проверить_проценты {документы=ПЗ} ", calls.get(1));
        assertEquals("сверить_даты {} ", calls.get(2));
        assertEquals("извлечь_из_документов {все=true, группа=1, имя=ПЗ|Извещен, шаблон=Способ закупки\\s*([^\\n]+)} ", calls.get(3));
        assertEquals("проверить_цитаты {поле=цитата} [{\"цитата\": \"НМЦД 100 \\\"руб.\\\"\"}]", calls.get(4));
        assertTrue(t.callbacks().stream().anyMatch(c -> "locate_quote".equals(c.getToolDefinition().name())));
        assertTrue(t.extractRegex(new AgentDocumentTools.RegexRequest("", null, null)).containsKey("error"));
    }

    @Test
    void compactCallbacksKeepCoreToolsWithinLongTaskLimit() {
        // 7+ функций на длинном задании → HTTP 413 «index 0» у GigaChat: компактный набор — ядро из шести
        var t = new AgentDocumentTools(List.of(new AgentDocumentTools.DocEntry("ТЗ.docx", "текст")), q -> List.of());
        t.setWriteSink((name, text) -> name);
        t.setOperationRunner((op, params, input) -> "ok");
        List<String> full = t.callbacks().stream().map(c -> c.getToolDefinition().name()).toList();
        List<String> compact = t.compactCallbacks().stream().map(c -> c.getToolDefinition().name()).toList();
        assertTrue(full.size() > AgentDocumentTools.MAX_TOOLS_FOR_LONG_TASK, String.valueOf(full));
        assertEquals(AgentDocumentTools.CORE_TOOLS, compact);
        assertFalse(compact.contains("check_amounts") || compact.contains("search_knowledge_base"), String.valueOf(compact));
        // без записи файлов и кодовых операций ядро короче, но состав тот же по порядку
        var bare = new AgentDocumentTools(List.of(), null);
        assertEquals(List.of("search_documents", "read_document", "note_thought"),
                bare.compactCallbacks().stream().map(c -> c.getToolDefinition().name()).toList());
    }

    @Test
    void callLimit_firstExhaustion_tracedOnceAndFlagged() {
        var t = tools("a.txt", "текст");
        var traces = new java.util.ArrayList<String>();
        t.setProgress(traces::add);
        assertFalse(t.isLimitExhausted());
        for (int i = 0; i < AgentDocumentTools.MAX_TOOL_CALLS; i++) {
            t.searchDocuments(new AgentDocumentTools.SearchRequest("текст" + i));
        }
        assertFalse(t.isLimitExhausted());

        t.searchDocuments(new AgentDocumentTools.SearchRequest("ещё"));
        t.searchDocuments(new AgentDocumentTools.SearchRequest("и ещё"));

        assertTrue(t.isLimitExhausted());
        assertEquals(1, traces.stream().filter(m -> m.startsWith("⛔ лимит инструментов исчерпан")).count());
    }

    @Test
    void duplicateDocumentNamesGetSuffixInsteadOfCollapsing() {
        var t = tools("акт.pdf", "акт первый", "акт.pdf", "акт второй", "акт.pdf", "акт третий");

        List<String> summary = t.documentSummary();

        assertEquals(3, summary.size());
        assertTrue(summary.get(1).startsWith("акт.pdf (2) ("));
        assertTrue(summary.get(2).startsWith("акт.pdf (3) ("));
        assertEquals("акт второй", t.readDocument(new AgentDocumentTools.ReadRequest("акт.pdf (2)", 0)).get("fragment"));
        assertEquals("акт первый", t.readDocument(new AgentDocumentTools.ReadRequest("акт.pdf", 0)).get("fragment"));
    }

    @Test
    void writeFileWithSourceDocumentNameGetsSuffix() {
        var t = tools("акт.pdf", "Итого 100 руб.");
        var stored = new java.util.HashMap<String, String>();
        t.setWriteSink((name, text) -> {
            stored.put(name, text);
            return null;
        });

        Map<String, Object> ok = t.writeFile(new AgentDocumentTools.WriteRequest("акт.pdf", "конспект"));

        assertTrue((Boolean) ok.get("ok"));
        assertEquals("конспект", stored.get("акт.pdf (2)"));
        assertTrue(((String) ok.get("note")).contains("«акт.pdf (2)»"));
        // исходный документ не перекрыт и остаётся источником цитат
        assertEquals("Итого 100 руб.", t.docsSnapshot().get("акт.pdf"));
        assertFalse(t.docsSnapshot().containsKey("акт.pdf (2)"));
    }
}
