package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты операции «технологии_из_таблицы»: строки технологий лотов из таблицы Раздела 6.
 */
class LotTechTableOpsTest {

    /** Таблица 1 Раздела 6 документации ЗП с 6 лотами (комплекты 9 и 10 Егоровой), как её отдаёт разбор docx. */
    static final String SECTION6 = "Оmax – максимальная сумма сопоставимых реализованных проектов\nТаблица 1\n"
            + "[ < Номер лота | Технологии для соответствующего лота* >\n< 1 | Python >\n< 2 | Python >\n< 3 | GreenPlum и Python >\n"
            + "< 4 | Python >\n< 5 | Python и ClickHouse >\n< 6 | Python, Hadoop и PL/SQL > ]\n"
            + "* В случае, если в совокупности всех предоставленных проектов отсутствует хотя бы одна из требуемых технологий\n"
            + "[ < № | Роль | Ставка >\n< 1 | Разработчик | 100 > ]";

    private static Map<String, Object> row(String criterion, String value, String section) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("критерий", criterion);
        m.put("значение", value);
        m.put("секция", section);
        return m;
    }

    @SuppressWarnings("unchecked")
    private static String at(List<Object> rows, int i, String field) {
        return String.valueOf(((Map<String, Object>) rows.get(i)).get(field));
    }

    @Test
    void parsesLotTechnologiesTableOnly() {
        Map<String, List<String>> table = LotTechTableOps.parseTable(SECTION6);

        assertEquals(6, table.size());
        assertEquals(List.of("Python"), table.get("1"));
        assertEquals(List.of("GreenPlum", "Python"), table.get("3"));
        assertEquals(List.of("Python", "Hadoop", "PL/SQL"), table.get("6"));
        assertTrue(LotTechTableOps.parseTable("нет таблицы < 1 | Python >").isEmpty());
    }

    @Test
    void replacesLostAndMalformedTechnologyRows() {
        String lot1 = "ЛОТ №1 (Методические требования)";
        String lot3 = "ЛОТ №3 (Методические требования)";
        String lot6 = "ЛОТ №6 (Методические требования)";
        List<Object> rows = new ArrayList<>(List.of(
                row("Количество лотов закупки", "6", "Общая информация по закупке для всех лотов"),
                row("Наличие квалификационных требований", "нет", "ЛОТ №1 (Квалификационные требования)"),
                row("Наличие методики оценки", "Да", lot1),
                row("GreenPlum", "Да", lot3),
                row("Python", "Да", lot3),
                row("Наличие методики оценки", "Да", lot3),
                row("Технология 1", "Python", lot6),
                row("Наличие методики оценки", "Да", lot6)));

        assertEquals(3, LotTechTableOps.apply(rows, SECTION6));

        assertEquals(11, rows.size());
        assertEquals("Технология 1", at(rows, 2, "критерий"));
        assertEquals("Python", at(rows, 2, "значение"));
        assertEquals(lot1, at(rows, 2, "секция"));
        assertEquals(LotTechTableOps.EXTRACTED, at(rows, 2, "достоверность"));
        assertEquals("Наличие методики оценки", at(rows, 3, "критерий"));
        assertEquals("GreenPlum", at(rows, 4, "значение"));
        assertEquals("Технология 2", at(rows, 5, "критерий"));
        assertEquals("Python", at(rows, 5, "значение"));
        assertEquals("Наличие методики оценки", at(rows, 6, "критерий"));
        assertEquals("PL/SQL", at(rows, 9, "значение"));
        assertEquals("Раздел 6, таблица «Технологии для соответствующего лота», строка лота 6", at(rows, 9, "источник"));
    }

    @Test
    void leavesRowsWithoutTableOrSection() {
        List<Object> rows = new ArrayList<>(List.of(row("Технология 1", "Java", "ЛОТ №1 (Методические требования)")));

        assertEquals(0, LotTechTableOps.apply(rows, "Раздел 6 без таблицы технологий"));
        assertEquals("Java", at(rows, 0, "значение"));
        assertEquals(0, LotTechTableOps.apply(new ArrayList<>(), SECTION6));
    }
}
