package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioResultToXlsxTest {

    private static String invokeFormatValue(Object value) throws Exception {
        Method method = ScenarioResultToXlsx.class.getDeclaredMethod("formatValue", Object.class);
        method.setAccessible(true);
        return (String) method.invoke(null, value);
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> invokeParseJsonToList(String json) throws Exception {
        try {
            Method method = ScenarioResultToXlsx.class.getDeclaredMethod("parseJsonToList", String.class);
            method.setAccessible(true);
            return (List<Map<String, Object>>) method.invoke(null, json);
        } catch (java.lang.reflect.InvocationTargetException e) {
            if (e.getCause() instanceof RuntimeException re) {
                throw re;
            }
            throw e;
        }
    }

    @Test
    void testJsonToXlsx_arrayOfObjects_producesWorkbook() {
        byte[] xlsx = ScenarioResultToXlsx.jsonToXlsx("[{\"first \nname\": \"John\"}, {\"first \nname\": \"Jane\"}]");

        assertNotNull(xlsx);
        assertTrue(xlsx.length > 0);
    }

    @Test
    void testJsonToXlsx_nullJson_throwsFileException() {
        FileException exception = assertThrows(FileException.class, () -> ScenarioResultToXlsx.jsonToXlsx(null));

        assertTrue(exception.getMessage().contains("Ошибка при генерации XLSX-файла"));
    }

    @Test
    void testJsonToXlsx_invalidJson_throwsFileException() {
        FileException exception = assertThrows(FileException.class,
                () -> ScenarioResultToXlsx.jsonToXlsx("not a json at all"));

        assertTrue(exception.getMessage().contains("Ошибка при генерации XLSX-файла"));
    }

    // ----- Тесты для formatValue (через рефлексию) -----

    @Test
    void testFormatValue_null_returnsEmptyString() throws Exception {
        assertEquals("", invokeFormatValue(null));
    }

    @Test
    void testFormatValue_string_returnsSameString() throws Exception {
        assertEquals("hello", invokeFormatValue("hello"));
        assertEquals("", invokeFormatValue(""));
        assertEquals("  spaces  ", invokeFormatValue("  spaces  "));
    }

    @Test
    void testFormatValue_boolean_returnsToString() throws Exception {
        assertEquals("true", invokeFormatValue(true));
        assertEquals("false", invokeFormatValue(false));
    }

    @Test
    void testFormatValue_number_returnsToString() throws Exception {
        assertEquals("42", invokeFormatValue(42));
        assertEquals("3.14", invokeFormatValue(3.14));
        assertEquals("0", invokeFormatValue(0));
        assertEquals("-1", invokeFormatValue(-1));
    }

    @Test
    void testFormatValue_list_returnsPrettyJson() throws Exception {
        var list = List.of("a", "b", "c");
        String result = invokeFormatValue(list);
        assertTrue(result.contains("\"a\""));
        assertTrue(result.contains("\"b\""));
        assertTrue(result.contains("\"c\""));
    }

    @Test
    void testFormatValue_map_returnsPrettyJson() throws Exception {
        var map = Map.of("key1", "value1", "key2", 42);
        String result = invokeFormatValue(map);
        assertTrue(result.contains("\"key1\""));
        assertTrue(result.contains("\"value1\""));
        assertTrue(result.contains("\"key2\""));
    }

    @Test
    void testFormatValue_nestedList_returnsPrettyJson() throws Exception {
        var nested = List.of(Map.of("id", 1, "name", "Alice"), Map.of("id", 2, "name", "Bob"));
        String result = invokeFormatValue(nested);
        assertTrue(result.contains("Alice"));
        assertTrue(result.contains("Bob"));
    }

    @Test
    void testFormatValue_customObject_returnsToString() throws Exception {
        Object custom = new Object() {
            @Override
            public String toString() {
                return "customValue";
            }
        };
        assertEquals("customValue", invokeFormatValue(custom));
    }

    // ----- Тесты для parseJsonToList (через рефлексию) -----

    @Test
    void testParseJsonToList_jsonArray_returnsList() throws Exception {
        String json = "[{\"name\": \"John\"}, {\"name\": \"Jane\"}]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(2, result.size());
        assertEquals("John", result.get(0).get("name"));
        assertEquals("Jane", result.get(1).get("name"));
    }

    @Test
    void testParseJsonToList_singleObject_returnsSingletonList() throws Exception {
        String json = "{\"name\": \"John\", \"age\": 30}";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        assertEquals("John", result.get(0).get("name"));
        assertEquals(30, result.get(0).get("age"));
    }

    @Test
    void testParseJsonToList_emptyArray_returnsEmptyList() throws Exception {
        String json = "[]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertTrue(result.isEmpty());
    }

    @Test
    void testParseJsonToList_emptyObject_returnsSingletonList() throws Exception {
        String json = "{}";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        assertTrue(result.get(0).isEmpty());
    }

    @Test
    @SuppressWarnings("unchecked")
    void testParseJsonToList_withNestedObjects() throws Exception {
        String json = "[{\"user\": {\"name\": \"Alice\", \"age\": 25}}]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        Map<String, Object> nestedUser = (Map<String, Object>) result.get(0).get("user");
        assertEquals("Alice", nestedUser.get("name"));
        assertEquals(25, nestedUser.get("age"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void testParseJsonToList_withArrayOfPrimitives() throws Exception {
        String json = "[{\"values\": [1, 2, 3]}]";
        List<Map<String, Object>> result = invokeParseJsonToList(json);
        assertEquals(1, result.size());
        List<Integer> values = (List<Integer>) result.get(0).get("values");
        assertEquals(List.of(1, 2, 3), values);
    }

    @ParameterizedTest
    @ValueSource(strings = {"[{invalid}", "{invalid}", "just plain text"})
    void testParseJsonToList_invalidJson_throwsFileException(String json) {
        FileException exception = assertThrows(FileException.class, () -> invokeParseJsonToList(json));
        assertEquals("Неверный формат JSON: ожидается объект или массив", exception.getMessage());
    }

    @Test
    void extractJsonSkipsBracketsOfFormTextBeforeData() {
        // Комплект 7 Егоровой: выход узла начинается со строк формы участника со скобками в ячейках
        String output = "=== РЕЗУЛЬТАТ ОТ \"Строки исходной формы\" ===\nООО | 1. GTP-10600 [PI4270] [PROD] LLM. Анализ, см. [1]\n"
                + "=== РЕЗУЛЬТАТ ОТ \"Строки формы (код)\" ===\n[ {\"к1\" : \"ООО\", \"к14\" : \"100.00\"} ]";

        assertEquals("[ {\"к1\" : \"ООО\", \"к14\" : \"100.00\"} ]", ScenarioResultToXlsx.extractJson(output));
        assertEquals("[1,5]", ScenarioResultToXlsx.extractJson("числа [1,5] без данных"));
        assertNotNull(ScenarioResultToXlsx.jsonToXlsx(output));
    }
}
