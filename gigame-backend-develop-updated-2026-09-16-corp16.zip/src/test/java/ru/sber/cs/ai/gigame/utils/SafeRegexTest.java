package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.ScenarioException;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Прерываемые регулярные выражения: дедлайн, остановка прогона, прерывание потока,
 * предел длины шаблона, кэш и обычная работа.
 */
class SafeRegexTest {

    /** Катастрофический шаблон: на «aaaa…!» бэктрекинг экспоненциальный. */
    private static final String CATASTROPHIC = "(a+)+$";

    private static final String LONG_INPUT = "a".repeat(200_000) + "!";

    @AfterEach
    void tearDown() {
        SafeRegex.setTimeoutMillis(SafeRegex.DEFAULT_TIMEOUT_MILLIS);
        SafeRegex.clearCancelCheck();
    }

    @Test
    void catastrophicPattern_isStoppedByDeadline() {
        SafeRegex.setTimeoutMillis(300);
        Pattern p = SafeRegex.compile(CATASTROPHIC, 0, "шаблон");
        long start = System.nanoTime();

        ScenarioException e = assertThrows(ScenarioException.class, () -> SafeRegex.find(p, LONG_INPUT));

        long elapsedMillis = (System.nanoTime() - start) / 1_000_000;
        assertTrue(elapsedMillis < 3000, "поиск не прервался по дедлайну: " + elapsedMillis + " мс");
        assertTrue(e.getMessage().contains("превысило 300 мс"), e.getMessage());
        assertTrue(e.getMessage().contains("упростите шаблон"), e.getMessage());
    }

    @Test
    void runCancel_interruptsSearch() throws InterruptedException {
        SafeRegex.setTimeoutMillis(60_000);
        AtomicBoolean cancelled = new AtomicBoolean();
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Thread worker = new Thread(() -> {
            SafeRegex.setCancelCheck(cancelled::get);
            try {
                SafeRegex.find(SafeRegex.compile(CATASTROPHIC, 0, "шаблон"), LONG_INPUT);
            } catch (RuntimeException e) {
                failure.set(e);
            }
        });
        worker.start();
        Thread.sleep(200);
        cancelled.set(true);
        worker.join(5000);

        assertFalse(worker.isAlive(), "поиск не прервался остановкой прогона");
        assertNotNull(failure.get());
        assertEquals(SafeRegex.CANCELLED, failure.get().getMessage());
    }

    @Test
    void threadInterrupt_interruptsSearch() throws InterruptedException {
        SafeRegex.setTimeoutMillis(60_000);
        AtomicReference<Throwable> failure = new AtomicReference<>();
        Thread worker = new Thread(() -> {
            try {
                SafeRegex.find(SafeRegex.compile(CATASTROPHIC, 0, "шаблон"), LONG_INPUT);
            } catch (RuntimeException e) {
                failure.set(e);
            }
        });
        worker.start();
        Thread.sleep(200);
        worker.interrupt();
        worker.join(5000);

        assertFalse(worker.isAlive(), "поиск не прервался прерыванием потока");
        assertNotNull(failure.get());
        assertEquals(SafeRegex.CANCELLED, failure.get().getMessage());
    }

    @Test
    void tooLongPattern_isRejected() {
        String pattern = "a".repeat(SafeRegex.MAX_PATTERN_LENGTH + 1);

        ScenarioException e = assertThrows(ScenarioException.class, () -> SafeRegex.compile(pattern, 0, "имя"));

        assertTrue(e.getMessage().contains("«имя»"), e.getMessage());
        assertTrue(e.getMessage().contains("длиннее 512"), e.getMessage());
    }

    @Test
    void invalidPattern_keepsPatternSyntaxException() {
        assertThrows(PatternSyntaxException.class, () -> SafeRegex.compile("(", 0, "шаблон"));
    }

    @Test
    void ordinaryPatterns_workAsBefore() {
        Pattern p = SafeRegex.compile("№\\s*(\\d+)", Pattern.MULTILINE, "шаблон");
        Matcher m = SafeRegex.matcher(p, "Договор № 12, акт №7");

        assertTrue(m.find());
        assertEquals("12", m.group(1));
        assertTrue(m.find());
        assertEquals("7", m.group(1));
        assertFalse(m.find());
        assertEquals("Договор №X, акт №X", SafeRegex.replaceAll(p, "Договор № 12, акт №7", "№X"));
        assertTrue(SafeRegex.matches(SafeRegex.compile("\\d+", 0, "n"), "123"));
        assertTrue(SafeRegex.find(p, "б".repeat(50_000) + " №5"));
    }

    @Test
    void compile_cachesPatterns() {
        Pattern first = SafeRegex.compile("x+", Pattern.CASE_INSENSITIVE, "a");
        Pattern second = SafeRegex.compile("x+", Pattern.CASE_INSENSITIVE, "b");
        Pattern otherFlags = SafeRegex.compile("x+", 0, "c");

        assertSame(first, second);
        assertTrue(first != otherFlags);
    }

    @Test
    void sharedDeadline_coversSeveralSearches() {
        SafeRegex.setTimeoutMillis(300);
        Pattern p = SafeRegex.compile(CATASTROPHIC, 0, "шаблон");
        long deadline = SafeRegex.deadline();
        long start = System.nanoTime();

        assertThrows(ScenarioException.class, () -> {
            for (int i = 0; i < 100; i++) {
                SafeRegex.matcher(p, LONG_INPUT, deadline).find();
            }
        });

        assertTrue((System.nanoTime() - start) / 1_000_000 < 3000, "общий дедлайн не сработал");
    }
}
