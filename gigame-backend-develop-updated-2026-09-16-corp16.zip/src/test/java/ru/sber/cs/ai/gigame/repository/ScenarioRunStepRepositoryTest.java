package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import ru.sber.cs.ai.gigame.repository.projection.StepOutputView;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class ScenarioRunStepRepositoryTest {

    @Autowired
    private ScenarioRunStepRepository runStepRepository;

    @Autowired
    private ScenarioRepository scenarioRepository;

    @Autowired
    private ScenarioRunRepository scenarioRunRepository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    void testFindById_returnsScenarioRunStep() {
        UUID runId = UUID.randomUUID();
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId("node1");
        step.setNodeType("input");
        runStepRepository.save(step);

        ScenarioRunStep found = runStepRepository.findById(step.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("node1", found.getNodeId());
    }

    @Test
    void testFindByRunIdOrderByStartedAtAsc_returnsSortedSteps() {
        var scenario = new Scenario();
        scenario.setName("Тестовый сценарий");
        scenario.setDescription("Тестовый сценарий");
        scenarioRepository.save(scenario);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("running");
        scenarioRunRepository.save(run);
        ScenarioRunStep step1 = new ScenarioRunStep();
        step1.setRunId(run.getId());
        step1.setNodeId("node1");
        step1.setStartedAt(OffsetDateTime.now().minusSeconds(1));
        runStepRepository.save(step1);

        ScenarioRunStep step2 = new ScenarioRunStep();
        step2.setRunId(run.getId());
        step2.setNodeId("node2");
        step2.setStartedAt(OffsetDateTime.now());
        runStepRepository.save(step2);

        List<ScenarioRunStep> result = runStepRepository.findByRunIdOrderByStartedAtAsc(run.getId());

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("node1", result.get(0).getNodeId());
        assertEquals("node2", result.get(1).getNodeId());
    }

    @Test
    void testFindByRunIdOrderByStartedAtAsc_sameStartedAt_orderedById() {
        var scenario = new Scenario();
        scenario.setName("Сценарий");
        scenarioRepository.save(scenario);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("running");
        scenarioRunRepository.save(run);
        entityManager.flush();
        // одинаковый started_at (копии шагов при возобновлении): вставка в обратном порядке id —
        // вторичный ключ сортировки по id даёт стабильный порядок вместо порядка чтения БД
        OffsetDateTime sameTime = OffsetDateTime.now();
        UUID first = UUID.fromString("00000000-0000-0000-0000-00000000000a");
        UUID second = UUID.fromString("00000000-0000-0000-0000-00000000000b");
        insertStep(second, run.getId(), "node-b", sameTime);
        insertStep(first, run.getId(), "node-a", sameTime);
        entityManager.clear();

        List<ScenarioRunStep> result = runStepRepository.findByRunIdOrderByStartedAtAsc(run.getId());

        assertEquals(List.of("node-a", "node-b"), result.stream().map(ScenarioRunStep::getNodeId).toList());
    }

    private void insertStep(UUID id, UUID runId, String nodeId, OffsetDateTime startedAt) {
        entityManager.getEntityManager().createNativeQuery(
                        "insert into scenario_run_steps (id, run_id, node_id, status, started_at) "
                                + "values (?1, ?2, ?3, 'completed', ?4)")
                .setParameter(1, id)
                .setParameter(2, runId)
                .setParameter(3, nodeId)
                .setParameter(4, startedAt)
                .executeUpdate();
    }

    @Test
    void testFindByRunId_returnsEmptyList_whenNoSteps() {
        List<ScenarioRunStep> result = runStepRepository.findByRunIdOrderByStartedAtAsc(UUID.randomUUID());

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        UUID runId = UUID.randomUUID();
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId("node1");

        ScenarioRunStep saved = runStepRepository.save(step);
        assertNotNull(saved.getId());

        runStepRepository.delete(saved);
        assertFalse(runStepRepository.findById(saved.getId()).isPresent());
    }

    @Test
    void findViewByRunIdAndNodeId_returnsOnlyThatNodeResultWithoutHeavyFields() {
        var scenario = new Scenario();
        scenario.setName("Сценарий");
        scenario.setDescription("Сценарий");
        scenarioRepository.save(scenario);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("completed");
        scenarioRunRepository.save(run);
        ScenarioRunStep donor = new ScenarioRunStep();
        donor.setRunId(run.getId());
        donor.setNodeId("donor");
        donor.setNodeType("transform");
        donor.setStartedAt(OffsetDateTime.now().minusMinutes(2));
        donor.setInputData(Map.of("documents_text", "DOC_1\nsha256:abc", "previous_output", ""));
        donor.setOutputData(Map.of("result", "число 42"));
        donor.setPromptUsed("очень длинный промпт");
        runStepRepository.save(donor);
        ScenarioRunStep out = new ScenarioRunStep();
        out.setRunId(run.getId());
        out.setNodeId("out");
        out.setNodeType("output");
        out.setStartedAt(OffsetDateTime.now().minusMinutes(1));
        out.setOutputData(Map.of("result", "итог"));
        runStepRepository.save(out);

        List<StepOutputView> views = runStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(run.getId(), "donor");
        List<StepOutputView> all = runStepRepository.findViewByRunIdOrderByStartedAtAsc(run.getId());

        assertEquals(1, views.size());
        assertEquals("donor", views.get(0).getNodeId());
        assertEquals("transform", views.get(0).getNodeType());
        assertEquals("число 42", views.get(0).result());
        assertEquals(List.of("donor", "out"), all.stream().map(StepOutputView::getNodeId).toList());
        assertEquals("итог", all.get(1).result());
        assertTrue(runStepRepository.findViewByRunIdAndNodeIdOrderByStartedAtAsc(run.getId(), "нет").isEmpty());
    }
}
