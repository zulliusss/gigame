package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.transaction.PlatformTransactionManager;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.utils.TextSplitter;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doAnswer;

@ExtendWith(MockitoExtension.class)
class DocumentIndexServiceTest {

    @Mock
    private KBDocumentRepository kbDocumentRepository;

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private EmbeddingService embeddingService;

    @Mock
    private TextSplitter textSplitter;

    @Mock
    private GigaChatClient gigaChatClient;

    @Mock
    @SuppressWarnings("unused")
    private PlatformTransactionManager platformTransactionManager;

    @InjectMocks
    private DocumentIndexService documentIndexService;

    @Captor
    private ArgumentCaptor<KBDocument> kbDocumentCaptor;

    private KnowledgeBase kb;
    private UUID docId;

    @BeforeEach
    void setUp() {
        kb = new KnowledgeBase();
        docId = UUID.randomUUID();
        ReflectionTestUtils.setField(textSplitter, "defaultChunkSize", 1000);
        ReflectionTestUtils.setField(textSplitter, "defaultOverlap", 200);
    }

    @Test
    void testIndexDocument() {
        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        List<float[]> embeddings = List.of(new float[1024], new float[1024]);

        when(textSplitter.split(any())).thenReturn(chunks);
        when(gigaChatClient.getEmbeddings(any())).thenReturn(embeddings);
        doNothing().when(embeddingService).storeDocumentChunks(any(), any(), any());

        documentIndexService.indexDocument(docId, "Test document content");

        verify(embeddingService).storeDocumentChunks(docId, chunks, embeddings);
    }

    @Test
    void testIndexDocument_withEmptyChunks() {
        when(textSplitter.split(any())).thenReturn(List.of());

        documentIndexService.indexDocument(docId, "Test");

        verify(embeddingService, never()).storeDocumentChunks(any(), any(), any());
    }

    @Test
    void testReindexDocument() {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        kbDoc.setStatus("processing");

        Document doc = new Document();
        doc.setExtractedText("Test content");

        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        List<float[]> embeddings = List.of(new float[1024], new float[1024]);

        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any()))
                .thenReturn(Optional.of(kbDoc));
        when(documentRepository.findById(any())).thenReturn(Optional.of(doc));
        when(textSplitter.split(any())).thenReturn(chunks);
        when(gigaChatClient.getEmbeddings(any())).thenReturn(embeddings);
        when(kbDocumentRepository.save(any())).thenReturn(kbDoc);
        doNothing().when(embeddingService).deleteKBDocumentChunks(any(), any());
        doNothing().when(embeddingService).storeKBChunks(any(), any(), any(), any());

        KBDocumentResponse result = documentIndexService.reindexDocument(kb.getId(), docId);

        assertNotNull(result);
        verify(embeddingService).deleteKBDocumentChunks(kb.getId(), docId);
    }

    @Test
    void testReindexDocument_withNonExistingKBDocument_throwsNotFoundException() {
        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any()))
                .thenReturn(Optional.empty());
        var kbId = kb.getId();
        assertThrows(NotFoundException.class,
                () -> documentIndexService.reindexDocument(kbId, docId));
    }

    @Test
    void testReindexDocument_withEmptyExtractedText_throwsException() {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setId(UUID.randomUUID());
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);

        Document doc = new Document();
        doc.setExtractedText("");
        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any()))
                .thenReturn(Optional.of(kbDoc));
        when(kbDocumentRepository.save(kbDoc)).thenReturn(kbDoc);
        when(documentRepository.findById(any())).thenReturn(Optional.of(doc));

        KBDocumentResponse result = documentIndexService.reindexDocument(kb.getId(), docId);

        assertNotNull(result);
        assertEquals("error", result.status());
    }

    @Test
    void testIndexDocumentAsync() {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setId(UUID.randomUUID());
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);

        Document doc = new Document();
        doc.setExtractedText("Test content");

        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        List<float[]> embeddings = List.of(new float[1024], new float[1024]);

        when(documentRepository.findById(any())).thenReturn(Optional.of(doc));
        when(textSplitter.split(any())).thenReturn(chunks);
        when(gigaChatClient.getEmbeddings(any())).thenReturn(embeddings);
        when(kbDocumentRepository.findById(any())).thenReturn(Optional.of(kbDoc));
        when(kbDocumentRepository.save(any())).thenReturn(kbDoc);
        doNothing().when(embeddingService).storeKBChunks(any(), any(), any(), any());

        documentIndexService.indexDocumentAsync(kb.getId(), docId, kbDoc.getId());

        verify(embeddingService).storeKBChunks(kb.getId(), docId, chunks, embeddings);
        verify(kbDocumentRepository).save(kbDocumentCaptor.capture());
        assertEquals("ready", kbDocumentCaptor.getValue().getStatus());
        assertEquals(Integer.valueOf(2), kbDocumentCaptor.getValue().getChunkCount());
    }

    @Test
    void testIndexDocumentAsync_withException_updatesStatusToError() {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setId(UUID.randomUUID());
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        kbDoc.setStatus("processing");

        var doc = new Document();
        doc.setId(UUID.randomUUID());
        doc.setExtractedText("Тест");

        when(documentRepository.findById(any())).thenReturn(Optional.of(doc));
        when(textSplitter.split(any())).thenThrow(new RuntimeException("Тестовый вызов RuntimeException"));
        when(kbDocumentRepository.findById(any())).thenReturn(Optional.of(kbDoc));
        when(kbDocumentRepository.save(any())).thenReturn(kbDoc);

        documentIndexService.indexDocumentAsync(kb.getId(), docId, kbDoc.getId());

        verify(kbDocumentRepository).save(kbDocumentCaptor.capture());
        assertEquals("error", kbDocumentCaptor.getValue().getStatus());
        assertNotNull(kbDocumentCaptor.getValue().getErrorMessage());
    }

    // -------------------------------------------------------------------------
    // corp15: эмбеддинги считаются вне транзакции, запись — короткими транзакциями
    // -------------------------------------------------------------------------

    /**
     * Менеджер транзакций без БД: помечает транзакцию активной, чтобы проверять её границы.
     */
    private static final class StubTransactionManager extends AbstractPlatformTransactionManager {
        @Override
        protected Object doGetTransaction() {
            return new Object();
        }

        @Override
        protected void doBegin(Object transaction, TransactionDefinition definition) {
            // транзакция без ресурсов
        }

        @Override
        protected void doCommit(DefaultTransactionStatus status) {
            // транзакция без ресурсов
        }

        @Override
        protected void doRollback(DefaultTransactionStatus status) {
            // транзакция без ресурсов
        }
    }

    private DocumentIndexService serviceWithRealTransactions() {
        return new DocumentIndexService(new StubTransactionManager(), kbDocumentRepository, documentRepository,
                embeddingService, textSplitter, gigaChatClient);
    }

    private KBDocument kbDocument() {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setId(UUID.randomUUID());
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        kbDoc.setStatus("processing");
        return kbDoc;
    }

    @Test
    void indexDocumentAsync_computesEmbeddingsOutsideTransaction_andStoresInside() {
        DocumentIndexService service = serviceWithRealTransactions();
        KBDocument kbDoc = kbDocument();
        Document doc = new Document();
        doc.setExtractedText("Текст");
        List<Boolean> embeddingsInTx = new ArrayList<>();
        List<Boolean> storeInTx = new ArrayList<>();
        when(documentRepository.findById(any())).thenReturn(Optional.of(doc));
        when(textSplitter.split(any())).thenReturn(List.of("Текст"));
        when(gigaChatClient.getEmbeddings(any())).thenAnswer(inv -> {
            embeddingsInTx.add(TransactionSynchronizationManager.isActualTransactionActive());
            return List.of(new float[1024]);
        });
        doAnswer(inv -> {
            storeInTx.add(TransactionSynchronizationManager.isActualTransactionActive());
            return null;
        }).when(embeddingService).storeKBChunks(any(), any(), any(), any());
        when(kbDocumentRepository.findById(any())).thenReturn(Optional.of(kbDoc));
        when(kbDocumentRepository.save(any())).thenReturn(kbDoc);

        service.indexDocumentAsync(kb.getId(), docId, kbDoc.getId());

        assertEquals(List.of(false), embeddingsInTx);
        assertEquals(List.of(true), storeInTx);
        assertEquals("ready", kbDoc.getStatus());
    }

    @Test
    void reindexDocument_embeddingsOutsideTransaction_statusChangesInsideTransactions() {
        DocumentIndexService service = serviceWithRealTransactions();
        KBDocument kbDoc = kbDocument();
        Document doc = new Document();
        doc.setExtractedText("Текст");
        List<Boolean> embeddingsInTx = new ArrayList<>();
        List<Boolean> savesInTx = new ArrayList<>();
        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any())).thenReturn(Optional.of(kbDoc));
        when(documentRepository.findById(any())).thenReturn(Optional.of(doc));
        when(textSplitter.split(any())).thenReturn(List.of("Текст"));
        when(gigaChatClient.getEmbeddings(any())).thenAnswer(inv -> {
            embeddingsInTx.add(TransactionSynchronizationManager.isActualTransactionActive());
            return List.of(new float[1024]);
        });
        when(kbDocumentRepository.save(any())).thenAnswer(inv -> {
            savesInTx.add(TransactionSynchronizationManager.isActualTransactionActive());
            return inv.getArgument(0);
        });

        KBDocumentResponse result = service.reindexDocument(kb.getId(), docId);

        assertEquals("ready", result.status());
        assertEquals(List.of(false), embeddingsInTx);
        // статус processing и статус ready — две отдельные транзакции
        assertEquals(List.of(true, true), savesInTx);
        assertFalse(TransactionSynchronizationManager.isActualTransactionActive());
    }

    @Test
    void reindexDocument_embeddingFailure_marksErrorInSeparateTransaction() {
        DocumentIndexService service = serviceWithRealTransactions();
        KBDocument kbDoc = kbDocument();
        Document doc = new Document();
        doc.setExtractedText("Текст");
        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any())).thenReturn(Optional.of(kbDoc));
        when(documentRepository.findById(any())).thenReturn(Optional.of(doc));
        when(textSplitter.split(any())).thenReturn(List.of("Текст"));
        when(gigaChatClient.getEmbeddings(any())).thenThrow(new IllegalStateException("GigaChat недоступен"));
        when(kbDocumentRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBDocumentResponse result = service.reindexDocument(kb.getId(), docId);

        assertEquals("error", result.status());
        assertTrue(result.errorMessage().contains("GigaChat недоступен"));
        verify(embeddingService, never()).storeKBChunks(any(), any(), any(), any());
    }

    @Test
    void indexDocument_computesEmbeddingsOutsideTransaction() {
        DocumentIndexService service = serviceWithRealTransactions();
        List<Boolean> embeddingsInTx = new ArrayList<>();
        when(textSplitter.split(any())).thenReturn(List.of("a", "b"));
        when(gigaChatClient.getEmbeddings(any())).thenAnswer(inv -> {
            embeddingsInTx.add(TransactionSynchronizationManager.isActualTransactionActive());
            return List.of(new float[1024], new float[1024]);
        });

        service.indexDocument(docId, "Текст");

        assertEquals(List.of(false), embeddingsInTx);
        verify(embeddingService).storeDocumentChunks(any(), any(), any());
    }
}
