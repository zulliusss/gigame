package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

/**
 * Предупреждения операций узла «Трансформация»: заглушки («не найдено», «сверка не выполнена»,
 * пустой результат) уходят в журнал прогона и в блок «=== ПРЕДУПРЕЖДЕНИЯ ===» результата шага,
 * а «json_поле» без поля — ошибка узла.
 */
class ScenarioExecutorTransformNodeWarningsTest {

    private static final String HEADER = ScenarioExecutorTransformNode.WARNINGS_HEADER;

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private static ScenarioRunNode node(String rules, List<ScenarioRunDoc> docs, String... inputs) {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Трансформ").rules(rules).build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("t1");
        for (int i = 0; i < docs.size(); i++) {
            String label = "DOC_" + (i + 1);
            graph.getDocMap().put(label, docs.get(i));
            node.getDocList().add(label);
        }
        for (String in : inputs) {
            node.getInput().add(in);
        }
        return node;
    }

    private static String ops(String op) {
        return "{\"операции\": [" + op + "]}";
    }

    @SuppressWarnings("unchecked")
    private List<String> emittedDetails() {
        ArgumentCaptor<ServerSentEvent<Map<String, Object>>> captor = ArgumentCaptor.forClass(ServerSentEvent.class);
        verify(sink, atLeast(0)).next(captor.capture());
        return captor.getAllValues().stream().map(e -> String.valueOf(e.data().get("detail"))).toList();
    }

    @Test
    void extractFromDocs_notFound_warnsInJournalAndResultButNotInOutputForChildren() {
        var node = node(ops("{\"оп\": \"извлечь_из_документов\", \"имя\": \"ПЗ\", \"шаблон\": \"НМЦ\\\\s*(\\\\d+)\"}"),
                List.of(new ScenarioRunDoc("ПЗ.docx", "текст без чисел")));
        var exec = new ScenarioExecutorTransformNode(node);

        String result = exec.execute(sink);

        assertTrue(result.startsWith("не найдено"));
        assertTrue(result.contains(HEADER));
        assertTrue(result.contains("- операция «извлечь_из_документов»: значение в документах не найдено"));
        // потомкам и выражениям {{output:…}} — результат без блока предупреждений
        assertEquals("не найдено", node.getOutput().get(0));
        assertTrue(emittedDetails().stream()
                .anyMatch(d -> d.startsWith("⚠ операция «извлечь_из_документов»")));
        assertTrue(exec.getPrompt().contains("⚠ операция «извлечь_из_документов»"));
    }

    @Test
    void successfulOperations_emitNoWarnings() {
        var node = node(ops("{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"}"), List.of(), "номер 42");
        var exec = new ScenarioExecutorTransformNode(node);

        String result = exec.execute(sink);

        assertEquals("42", result);
        assertFalse(result.contains(HEADER));
        verify(sink, never()).next(any());
    }

    @Test
    void extractRegex_withoutMatches_warnsAboutEmptyResult() {
        var node = node(ops("{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"}"), List.of(), "без чисел");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("", node.getOutput().get(0));
        assertTrue(result.contains("операция «извлечь_regex»: совпадений шаблона не найдено"));
    }

    @Test
    void jsonField_missingField_failsNode() {
        var node = node(ops("{\"оп\": \"json_поле\", \"путь\": \"нет\"}"), List.of(), "{\"есть\": 1}");
        var exec = new ScenarioExecutorTransformNode(node);

        ScenarioException error = assertThrows(ScenarioException.class, () -> exec.execute(sink));

        assertTrue(error.getMessage().contains("json_поле"));
        assertTrue(error.getMessage().contains("«нет» не найдено"));
    }

    @Test
    void jsonField_withoutJson_failsNode() {
        var node = node(ops("{\"оп\": \"json_поле\", \"путь\": \"a\"}"), List.of(), "просто текст");
        var exec = new ScenarioExecutorTransformNode(node);

        assertThrows(ScenarioException.class, () -> exec.execute(sink));
    }

    @Test
    void jsonField_missingFieldWithEmptyOption_returnsEmptyAndWarns() {
        var node = node(ops("{\"оп\": \"json_поле\", \"путь\": \"нет\", \"пусто_если_нет\": \"true\"}"),
                List.of(), "{\"есть\": 1}");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("", node.getOutput().get(0));
        assertTrue(result.startsWith("\n\n" + HEADER));
        assertTrue(result.contains("операция «json_поле»: поле «нет» не найдено — результат пуст"));
        assertTrue(emittedDetails().stream().anyMatch(d -> d.startsWith("⚠ операция «json_поле»")));
    }

    @Test
    void runOperation_jsonFieldMissing_returnsErrorText() {
        var node = node(ops("{\"оп\": \"уникальные_строки\"}"), List.of(), "x");

        String result = new ScenarioExecutorTransformNode(node).runOperation("json_поле", Map.of("путь", "b"), "{\"a\": 1}");

        assertTrue(result.startsWith("ОШИБКА:"));
    }

    @Test
    void compareAmounts_withoutAmountsNearLabel_warns() {
        var node = node(ops("{\"оп\": \"сверить_суммы\"}"),
                List.of(new ScenarioRunDoc("извещение.docx", "документ без сумм")));

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("операция «сверить_суммы»: упоминаний сумм рядом с меткой не найдено"));
    }

    @Test
    void checkPercentages_withoutBase_warns() {
        var node = node(ops("{\"оп\": \"проверить_проценты\"}"),
                List.of(new ScenarioRunDoc("извещение.docx", "обеспечение 5 % без НМЦ")));

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("операция «проверить_проценты»: базовая сумма (НМЦ) в документах не найдена"));
    }

    @Test
    void compareDates_withoutContractDates_warnsThatNothingWasChecked() {
        var node = node(ops("{\"оп\": \"сверить_даты\"}"),
                List.of(new ScenarioRunDoc("акт.docx", "услуги за период с 01.02.2024")));

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("операция «сверить_даты»: дат заключения договоров в документах не найдено"));
    }

    @Test
    void compareDates_withContractDates_doesNotWarn() {
        var node = node(ops("{\"оп\": \"сверить_даты\"}"),
                List.of(new ScenarioRunDoc("договор.docx", "договор № 1 от 01.03.2024, период услуг с 01.04.2024")));

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertFalse(result.contains(HEADER));
    }

    @Test
    void specCheck_withoutRequirementsTable_warns() {
        ScenarioRunDoc contract = new ScenarioRunDoc("договор.docx", "договор без таблицы");
        contract.setDocClass("договор");
        var node = node(ops("{\"оп\": \"сверить_характеристики\"}"), List.of(contract));

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("операция «сверить_характеристики»: таблица характеристик не найдена"));
    }

    @Test
    void sequence_withoutDonor_warnsAndKeepsInput() {
        var node = node(ops("{\"оп\": \"последовательность\", \"из_узла\": \"Нет такого\"}"), List.of(), "[\"1\"]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("[\"1\"]", node.getOutput().get(0));
        assertTrue(result.contains("операция «последовательность»: узел-донор «Нет такого» не задан или не найден"));
    }

    @Test
    void stripWarnings_removesTrailingBlockOnly() {
        assertEquals("итог", ScenarioExecutorTransformNode.stripWarnings("итог\n\n" + HEADER + "\n- операция «x»: y"));
        assertEquals("итог", ScenarioExecutorTransformNode.stripWarnings("итог"));
        assertNull(ScenarioExecutorTransformNode.stripWarnings(null));
    }
}
