package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.AgentQuestion;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты удаления вопросов агента по удалённым прогонам (чистка по сроку хранения).
 */
@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class AgentQuestionRepositoryTest {

    @Autowired
    private AgentQuestionRepository questionRepository;

    private AgentQuestion question(UUID runId, String text) {
        AgentQuestion question = new AgentQuestion();
        question.setRunId(runId);
        question.setQuestion(text);
        question.setCreatedAt(OffsetDateTime.now());
        return questionRepository.save(question);
    }

    @Test
    void deleteByRunIds_removesOnlyQuestionsOfGivenRuns() {
        UUID run1 = UUID.randomUUID();
        UUID run2 = UUID.randomUUID();
        UUID run3 = UUID.randomUUID();
        question(run1, "вопрос 1");
        question(run1, "вопрос 2");
        question(run2, "вопрос 3");
        question(run3, "вопрос 4");

        questionRepository.deleteByRunIds(List.of(run1, run2));

        assertTrue(questionRepository.findByRunIdOrderByCreatedAtAsc(run1).isEmpty());
        assertTrue(questionRepository.findByRunIdOrderByCreatedAtAsc(run2).isEmpty());
        assertEquals(1, questionRepository.findByRunIdOrderByCreatedAtAsc(run3).size());
    }
}
