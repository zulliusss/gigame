package ru.sber.cs.ai.gigame.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.config.JacksonConfig;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты приведения значений ответов к лимитам статической спецификации.
 */
class SchemaLimitUtilsTest {

    @Test
    void clip_nullAndShortValuesPassUnchanged() {
        assertNull(SchemaLimitUtils.clip(null, 10));
        assertEquals("короткий", SchemaLimitUtils.clip("короткий", 10));
        assertEquals("ровно10симв", SchemaLimitUtils.clip("ровно10симв", 11));
    }

    @Test
    void clip_longValueFitsLimitWithEllipsis() {
        String clipped = SchemaLimitUtils.clip("я".repeat(300), 255);

        assertEquals(255, clipped.length());
        assertTrue(clipped.endsWith(SchemaLimitUtils.ELLIPSIS));
    }

    @Test
    void clip_customMarkerIsIncludedInLimit() {
        String clipped = SchemaLimitUtils.clip("x".repeat(100), 50, "[усечено]");

        assertEquals(50, clipped.length());
        assertTrue(clipped.endsWith("[усечено]"));
    }

    @Test
    void clip_markerLongerThanLimit_cutsWithoutMarker() {
        assertEquals("xxx", SchemaLimitUtils.clip("xxxxxx", 3, "[очень длинная пометка]"));
    }

    @Test
    void clip_doesNotSplitSurrogatePair() {
        // эмодзи — суррогатная пара; граница усечения приходится на её середину
        String value = "ab" + "😀".repeat(10);

        String clipped = SchemaLimitUtils.clip(value, 6);

        assertTrue(clipped.length() <= 6);
        assertFalse(Character.isHighSurrogate(clipped.charAt(clipped.length() - 2)));
        assertEquals("ab😀…", clipped);
    }

    @Test
    void firstItems_keepsFirstElements() {
        List<Integer> items = new ArrayList<>();
        for (int i = 0; i < 1005; i++) {
            items.add(i);
        }

        List<Integer> limited = SchemaLimitUtils.firstItems(items, 1000);

        assertEquals(1000, limited.size());
        assertEquals(0, limited.get(0));
        assertEquals(999, limited.get(999));
        assertNull(SchemaLimitUtils.firstItems(null, 10));
        List<Integer> shortList = List.of(1, 2);
        assertSame(shortList, SchemaLimitUtils.firstItems(shortList, 10));
    }

    @Test
    void firstItemsAndLast_atLimitKeepsAll_overLimitKeepsFirstAndLast() {
        List<Integer> exact = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            exact.add(i);
        }
        List<Integer> over = new ArrayList<>(exact);
        over.add(100);

        assertSame(exact, SchemaLimitUtils.firstItemsAndLast(exact, 100));
        List<Integer> limited = SchemaLimitUtils.firstItemsAndLast(over, 100);
        assertEquals(100, limited.size());
        assertEquals(98, limited.get(98));
        assertEquals(100, limited.get(99));
        assertNull(SchemaLimitUtils.firstItemsAndLast(null, 100));
    }

    @Test
    void safeFilename_replacesForbiddenCharacters() {
        assertEquals("Протокол 12_30 _ итог.pdf", SchemaLimitUtils.safeFilename("Протокол 12:30 | итог.pdf"));
        assertEquals("a_b_c_d_e_f_g_h_i.docx", SchemaLimitUtils.safeFilename("a\\b/c:d*e?f\"g<h>i.docx"));
        assertEquals("договор.pdf", SchemaLimitUtils.safeFilename("договор.pdf"));
        assertNull(SchemaLimitUtils.safeFilename(null));
    }

    @Test
    void safeFilename_longNameClippedTo255KeepingExtension() {
        String safe = SchemaLimitUtils.safeFilename("ж".repeat(300) + ".xlsx");

        assertEquals(SchemaLimitUtils.FILENAME_MAX_LENGTH, safe.length());
        assertTrue(safe.endsWith("….xlsx"));
    }

    @Test
    void safeFilename_longNameWithoutExtensionClippedTo255() {
        String safe = SchemaLimitUtils.safeFilename("имя:" + "ж".repeat(300));

        assertEquals(SchemaLimitUtils.FILENAME_MAX_LENGTH, safe.length());
        assertTrue(safe.startsWith("имя_"));
    }

    @Test
    void clamp_limitsRange() {
        assertEquals(0, SchemaLimitUtils.clamp(-5, 0, 100));
        assertEquals(100, SchemaLimitUtils.clamp(150, 0, 100));
        assertEquals(42, SchemaLimitUtils.clamp(42, 0, 100));
    }

    @Test
    void utcMicros_convertsToUtcAndFitsMaxLength32() throws Exception {
        OffsetDateTime moscowNanos = OffsetDateTime.of(2026, 9, 15, 13, 4, 37, 669_778_312, ZoneOffset.ofHours(3));

        OffsetDateTime normalized = SchemaLimitUtils.utcMicros(moscowNanos);

        assertEquals(ZoneOffset.UTC, normalized.getOffset());
        assertEquals(moscowNanos.toInstant().getEpochSecond(), normalized.toInstant().getEpochSecond());
        assertEquals(669_778_000, normalized.getNano());
        ObjectMapper mapper = new JacksonConfig().objectMapper();
        String json = mapper.writeValueAsString(normalized);
        assertEquals("\"2026-09-15T10:04:37.669778Z\"", json);
        assertTrue(json.length() - 2 <= 32);
        assertNull(SchemaLimitUtils.utcMicros(null));
    }
}
