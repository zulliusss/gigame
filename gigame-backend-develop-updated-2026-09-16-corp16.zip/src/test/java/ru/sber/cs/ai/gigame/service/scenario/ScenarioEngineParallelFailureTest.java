package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Ошибка одного узла параллельной волны не прерывает соседние узлы: они дорабатывают (их ответы GigaChat
 * не превращаются в ложную ошибку «Не удалось выполнить запрос к GigaChat»), и только затем прогон останавливается.
 */
class ScenarioEngineParallelFailureTest {

    /** Узел, ещё ждущий ответа модели, когда соседний падает. */
    private static Object[] slowSibling(AtomicBoolean finished, AtomicBoolean interrupted) {
        try {
            Thread.sleep(300);
            finished.set(true);
        } catch (InterruptedException e) {
            interrupted.set(true);
        }
        return new Object[]{"Данные документации", "ответ модели"};
    }

    @Test
    void failedNodeWaitsForRunningSiblingBeforeStoppingRun() throws Exception {
        ScenarioEngine engine = new ScenarioEngine(Mockito.mock(ScenarioRunService.class), Mockito.mock(ScenarioRunStepService.class),
                Mockito.mock(ScenarioExecutorFactory.class), Mockito.mock(DocsTextCacheService.class),
                Mockito.mock(ScenarioRepository.class), Mockito.mock(ScenarioOutputSupportService.class));
        ExecutorService pool = Executors.newFixedThreadPool(2);
        AtomicBoolean siblingFinished = new AtomicBoolean();
        AtomicBoolean siblingInterrupted = new AtomicBoolean();
        try {
            ExecutorCompletionService<Object[]> ecs = new ExecutorCompletionService<>(pool);
            ecs.submit(() -> slowSibling(siblingFinished, siblingInterrupted));
            ecs.submit(() -> {
                throw new ScenarioException("Узел «Трансформация»: неизвестная операция");
            });
            Method take = ScenarioEngine.class.getDeclaredMethod("takeCompletedOrAwaitOthers", ExecutorCompletionService.class, int.class);
            take.setAccessible(true);

            InvocationTargetException thrown = assertThrows(InvocationTargetException.class, () -> take.invoke(engine, ecs, 2));

            assertEquals("Узел «Трансформация»: неизвестная операция", thrown.getCause().getMessage());
            assertTrue(siblingFinished.get(), "соседний узел должен доработать до остановки прогона");
            assertTrue(!siblingInterrupted.get());
        } finally {
            pool.shutdownNow();
        }
    }
}
