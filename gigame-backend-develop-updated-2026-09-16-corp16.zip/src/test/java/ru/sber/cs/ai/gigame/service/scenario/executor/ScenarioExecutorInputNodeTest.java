package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import org.mockito.ArgumentCaptor;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

class ScenarioExecutorInputNodeTest {

    private ScenarioRunGraph structure;
    private ScenarioRunNode node;

    @BeforeEach
    void setUp() {
        NodeDto dto = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();

        GraphDataDto graphData = new GraphDataDto(
                List.of(dto),
                List.of()
        );
        structure = new ScenarioRunGraph(graphData);
        structure.setRunnerUserId("user-1");
        node = structure.getNodeMap().get("input-1");
    }

    // ----------------------------------------------------------------
    // Basic execution
    // ----------------------------------------------------------------

    @Test
    void testExecute_whenNoDocs_returnsEmptyString() {
        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertNotNull(result);
        assertEquals("", result);
    }

    @Test
    void testExecute_whenSingleDoc_returnsFormattedDocText() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("test.txt", "Hello world"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("<<<DOC_1>>>"));
        assertTrue(result.contains("Hello world"));
        assertTrue(result.contains("<<<END_DOC_1>>>"));
    }

    @Test
    void testExecute_whenMultipleDocs_returnsAllFormattedDocs() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "Content A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "Content B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("<<<DOC_1>>>"));
        assertTrue(result.contains("Content A"));
        assertTrue(result.contains("<<<END_DOC_1>>>"));
        assertTrue(result.contains("<<<DOC_2>>>"));
        assertTrue(result.contains("Content B"));
        assertTrue(result.contains("<<<END_DOC_2>>>"));
    }

    @Test
    void testExecute_docsAreJoinedByDoubleNewline() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        // Both doc blocks are present, separated by double newline
        assertTrue(result.contains("<<<DOC_1>>>\nA\n<<<END_DOC_1>>>"));
        assertTrue(result.contains("<<<DOC_2>>>\nB\n<<<END_DOC_2>>>"));
        // There should be a double newline between the two doc blocks
        long docCount = result.split("<<<END_DOC_").length - 1;
        assertEquals(2, docCount);
    }

    @Test
    void testExecute_docsAreSeparatedBySingleNewlineWithinDoc() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1>>>\nA\n<<<END_DOC_1>>>"));
        assertTrue(result.contains("<<<DOC_2>>>\nB\n<<<END_DOC_2>>>"));
    }

    // ----------------------------------------------------------------
    // Document propagation to child nodes
    // ----------------------------------------------------------------

    @Test
    void testExecute_propagatesDocIdsToChildNodes() {
        NodeDto childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        ScenarioRunNode childNode = ScenarioRunNode.fromDto(1, childDto, structure);
        node.getChildNodeList().add(childNode);

        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "Content A"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        assertTrue(childNode.getDocList().contains("DOC_1"));
    }

    @Test
    void testExecute_propagatesAllDocIdsToAllChildren() {
        NodeDto child1Dto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child1").build())
                .position(new PositionDto(200, 100))
                .build();
        NodeDto child2Dto = NodeDto.builder()
                .id("child-2")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child2").build())
                .position(new PositionDto(200, 200))
                .build();
        ScenarioRunNode child1 = ScenarioRunNode.fromDto(1, child1Dto, structure);
        ScenarioRunNode child2 = ScenarioRunNode.fromDto(2, child2Dto, structure);

        node.getChildNodeList().add(child1);
        node.getChildNodeList().add(child2);

        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "B"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        assertTrue(child1.getDocList().containsAll(List.of("DOC_1", "DOC_2")));
        assertTrue(child2.getDocList().containsAll(List.of("DOC_1", "DOC_2")));
    }

    @Test
    void testExecute_whenNoChildren_noExceptionThrown() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        // should not throw even though there are no children
        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("DOC_1"));
    }

    @Test
    void testExecute_whenNoDocs_doesNotPropagateAnything() {
        NodeDto childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        ScenarioRunNode childNode = ScenarioRunNode.fromDto(1, childDto, structure);
        node.getChildNodeList().add(childNode);

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        assertTrue(childNode.getDocList().isEmpty());
    }

    // ----------------------------------------------------------------
    // Edge cases
    // ----------------------------------------------------------------

    @Test
    void testExecute_workNoteCheckpoint_notPassedAsInputDocument() {
        // возобновлённый прогон: чекпойнт агента уже лежит рабочим файлом до входного узла —
        // он не входной документ (не блок результата и не docList детей)
        NodeDto childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        ScenarioRunNode childNode = ScenarioRunNode.fromDto(1, childDto, structure);
        node.getChildNodeList().add(childNode);
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));
        structure.addWorkingDoc("чекпойнт-agent-1-прерванного-прогона.md", "наблюдения");

        String result = new ScenarioExecutorInputNode(node).execute(null);

        assertEquals("<<<DOC_1>>>\nA\n<<<END_DOC_1>>>", result);
        assertEquals(List.of("DOC_1"), childNode.getDocList());
    }

    @Test
    void testExecute_docWithNoText_returnsEmptyTagContent() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("empty.txt", ""));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1>>>"));
        assertTrue(result.contains("<<<END_DOC_1>>>"));
    }

    @Test
    void testExecute_docWithMultilineText() {
        String multiline = "Line 1\nLine 2\nLine 3";
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("multi.txt", multiline));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1>>>\nLine 1\nLine 2\nLine 3\n<<<END_DOC_1>>>"));
    }

    @Test
    void testExecute_doesNotModifyNodeDocList() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "A"));

        ScenarioExecutorInputNode executor = new ScenarioExecutorInputNode(node);

        executor.execute(null);

        // node's own docList should remain empty (only child docs are modified)
        assertTrue(node.getDocList().isEmpty());
    }

    @Test
    void testExecute_manyDocs_keepsNumericOrderInResultAndChildDocList() {
        // 13 документов: результат и docList ребёнка идут DOC_1..DOC_13, а не в хеш-порядке (DOC_10 раньше DOC_2)
        List<String> texts = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<String> expected = new ArrayList<>();
        for (int i = 1; i <= 13; i++) {
            texts.add("Текст " + i);
            names.add("f" + i + ".txt");
            expected.add("DOC_" + i);
        }
        structure.addDocs(texts, names);
        NodeDto childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        ScenarioRunNode childNode = ScenarioRunNode.fromDto(1, childDto, structure);
        node.getChildNodeList().add(childNode);

        String result = new ScenarioExecutorInputNode(node).execute(null);

        assertEquals(expected, new ArrayList<>(childNode.getDocList()));
        int previous = -1;
        for (String key : expected) {
            int at = result.indexOf("<<<" + key + ">>>");
            assertTrue(at > previous, key + " должен идти после предыдущего документа");
            previous = at;
        }
    }

    // ----------------------------------------------------------------
    // corp15: пустые и маркерные документы — событие в журнал прогона
    // ----------------------------------------------------------------

    @Test
    @SuppressWarnings("unchecked")
    void testExecute_emptyOrMarkerDocs_emitsCountToJournal() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "текст"));
        structure.getDocMap().put("DOC_2", new ScenarioRunDoc("b.txt", "   "));
        structure.getDocMap().put("DOC_3", new ScenarioRunDoc("c.pdf",
                "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «c.pdf» не распознан"));
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);
        ArgumentCaptor<ServerSentEvent<Map<String, Object>>> captor = ArgumentCaptor.forClass(ServerSentEvent.class);

        String result = new ScenarioExecutorInputNode(node).execute(sink);

        verify(sink).next(captor.capture());
        assertEquals("документов 3, из них пустых/маркерных 2", captor.getValue().data().get("detail"));
        assertTrue(result.contains("<<<DOC_3>>>"));
    }

    @Test
    @SuppressWarnings("unchecked")
    void testExecute_allDocsHaveText_emitsNothing() {
        structure.getDocMap().put("DOC_1", new ScenarioRunDoc("a.txt", "текст"));
        FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

        new ScenarioExecutorInputNode(node).execute(sink);

        verify(sink, never()).next(any());
    }

    @Test
    void testIsEmptyOrMarker() {
        assertTrue(ScenarioExecutorInputNode.isEmptyOrMarker(new ScenarioRunDoc("a", "")));
        assertTrue(ScenarioExecutorInputNode.isEmptyOrMarker(new ScenarioRunDoc("a", null)));
        assertTrue(ScenarioExecutorInputNode.isEmptyOrMarker(new ScenarioRunDoc("a", "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] скан")));
        assertTrue(ScenarioExecutorInputNode.isEmptyOrMarker(null));
        assertEquals(false, ScenarioExecutorInputNode.isEmptyOrMarker(new ScenarioRunDoc("a", "текст")));
    }
}
