package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatOptions;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.CopyOnWriteArrayList;

import org.mockito.Mockito;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.retry.NonTransientAiException;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Тесты политики повторов GigaChat: пауза при недоступности вместо остановки шага, отдельный бюджет 429,
 * прежнее правило попыток при выключенном ожидании, честная ошибка при остановке прогона.
 */
class GigaChatRetryPolicyTest {

    private static final RuntimeException CAUSE = new RuntimeException("503 Service Unavailable");

    private static GigaChatRetryPolicy policy(long maxUnavailableWait, int attempts) {
        return new GigaChatRetryPolicy(new GigaChatRetryPolicy.Settings(500, 1000, 3000, 1000, 4000, maxUnavailableWait, attempts));
    }

    @Test
    void unavailableServiceIsWaitedWithDoublingPausesUntilBudget() {
        GigaChatRetryPolicy p = policy(10_000, 3);

        assertEquals(1000, p.next(false, true, CAUSE).delayMillis());
        assertEquals(2000, p.next(false, true, CAUSE).delayMillis());
        GigaChatRetryPolicy.Wait third = p.next(false, true, CAUSE);
        assertEquals(4000, third.delayMillis());
        assertTrue(third.notice().startsWith("GigaChat недоступен — пауза 4 с, шаг продолжится автоматически"), third.notice());
        // четвёртая попытка сверх трёх прежних: ждём, пока укладываемся в бюджет (7 с + 4 с > 10 с — стоп)
        GigaChatException stop = assertThrows(GigaChatException.class, () -> p.next(false, true, CAUSE));
        assertEquals(GigaChatRetryPolicy.FAILED + ": GigaChat недоступен дольше 0 мин — паузы исчерпаны "
                + "(последняя ошибка: 503 Service Unavailable)", stop.getMessage());
    }

    @Test
    void rateLimitHasItsOwnBudgetAndFatalErrorsAreNotRetried() {
        GigaChatRetryPolicy p = policy(10_000, 3);
        p.next(false, true, CAUSE);

        assertEquals(500, p.next(true, false, CAUSE).delayMillis());
        assertEquals(1000, p.next(true, false, CAUSE).delayMillis());
        assertEquals(1000, p.next(true, false, CAUSE).delayMillis());
        GigaChatException rateLimit = assertThrows(GigaChatException.class, () -> p.next(true, false, CAUSE));
        assertEquals(GigaChatRetryPolicy.FAILED + ": превышен лимит запросов (429) — паузы исчерпаны: "
                + "лимит не восстановился за 0 мин ожидания", rateLimit.getMessage());
        GigaChatException fatal = assertThrows(GigaChatException.class, () -> policy(10_000, 3).next(false, false, CAUSE));
        assertTrue(fatal.getMessage().startsWith(GigaChatRetryPolicy.FAILED + ": "), fatal.getMessage());
    }

    @Test
    void zeroWaitKeepsLegacyAttemptLimit() {
        GigaChatRetryPolicy p = policy(0, 2);

        assertEquals(1000, p.next(false, true, CAUSE).delayMillis());
        assertEquals(2000, p.next(false, true, CAUSE).delayMillis());
        String message = assertThrows(GigaChatException.class, () -> p.next(false, true, CAUSE)).getMessage();
        assertEquals(GigaChatRetryPolicy.FAILED + ": GigaChat недоступен — попытки исчерпаны: 2 "
                + "(последняя ошибка: 503 Service Unavailable)", message);
    }

    @Test
    void notRetriedFailureNamesModelFromSupplier() {
        GigaChatRetryPolicy p = new GigaChatRetryPolicy(new GigaChatRetryPolicy.Settings(500, 1000, 3000, 1000, 4000, 10_000, 3),
                () -> "GigaChat-2-Max");
        RuntimeException notFound = new NonTransientAiException("HTTP 404 - {\"status\":404,\"message\":\"No such model\"}");

        GigaChatException fatal = assertThrows(GigaChatException.class, () -> p.next(false, false, notFound));

        assertEquals("Не удалось выполнить запрос к GigaChat: модель «GigaChat-2-Max» недоступна (HTTP 404)", fatal.getMessage());
        assertEquals(notFound, fatal.getCause());
    }

    @Test
    void clientReportsShortReasonOfNotRetriedFailure() {
        ChatModel chatModel = Mockito.mock(ChatModel.class);
        GigaChatClient client = new GigaChatClient(chatModel, Mockito.mock(EmbeddingModel.class));
        when(chatModel.call(any(Prompt.class))).thenThrow(new NonTransientAiException(
                "HTTP 404 - {\"status\":404,\"message\":\"No such model\"}"));

        GigaChatException ex = assertThrows(GigaChatException.class,
                () -> client.chatCompletion(List.of(Map.of("role", "user", "content", "Привет")), "GigaChat-Nope", null));

        assertEquals(GigaChatRetryPolicy.FAILED + ": модель «GigaChat-Nope» недоступна (HTTP 404)", ex.getMessage());
        Mockito.verify(chatModel, Mockito.times(1)).call(any(Prompt.class));
    }

    @Test
    void clientNamesDefaultModelWhenRequestHasNoModel() {
        ChatModel chatModel = Mockito.mock(ChatModel.class);
        GigaChatClient client = new GigaChatClient(chatModel, Mockito.mock(EmbeddingModel.class));
        when(chatModel.getDefaultOptions()).thenReturn(GigaChatOptions.builder().model("GigaChat-2-Max").build());
        when(chatModel.call(any(Prompt.class))).thenThrow(new NonTransientAiException(
                "HTTP 404 - {\"status\":404,\"message\":\"No such model\"}"));

        // запрос без переопределения модели: имя берётся из опций модели по умолчанию
        GigaChatException byDefault = assertThrows(GigaChatException.class,
                () -> client.chatCompletion(List.of(Map.of("role", "user", "content", "Привет"))));
        // модель узла важнее модели по умолчанию
        GigaChatException byNode = assertThrows(GigaChatException.class,
                () -> client.chatCompletion(List.of(Map.of("role", "user", "content", "Привет")), "GigaChat-Nope", null));

        assertEquals(GigaChatRetryPolicy.FAILED + ": модель «GigaChat-2-Max» недоступна (HTTP 404)", byDefault.getMessage());
        assertEquals(GigaChatRetryPolicy.FAILED + ": модель «GigaChat-Nope» недоступна (HTTP 404)", byNode.getMessage());
    }

    @Test
    void clientReportsTokensLimitWithoutRetry() {
        ChatModel chatModel = Mockito.mock(ChatModel.class);
        GigaChatClient client = new GigaChatClient(chatModel, Mockito.mock(EmbeddingModel.class));
        when(chatModel.call(any(Prompt.class))).thenThrow(new NonTransientAiException(
                "HTTP 413 - {\"status\":413,\"message\":\"Tokens limit exceeded for index 1\"}"));

        GigaChatException tooLarge = assertThrows(GigaChatException.class,
                () -> client.chatCompletion(List.of(Map.of("role", "user", "content", "Привет"))));

        assertEquals(GigaChatRetryPolicy.failedMessage(GigaChatFailureReason.TOKENS_LIMIT), tooLarge.getMessage());
        Mockito.verify(chatModel, Mockito.times(1)).call(any(Prompt.class));
    }

    @Test
    void clientReportsInterruptedCallWithoutRunCancel() {
        ChatModel chatModel = Mockito.mock(ChatModel.class);
        GigaChatClient client = new GigaChatClient(chatModel, Mockito.mock(EmbeddingModel.class));
        ReflectionTestUtils.setField(client, "callHardTimeoutSeconds", 30L);
        CountDownLatch never = new CountDownLatch(1);
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            never.await(10, TimeUnit.SECONDS);
            return null;
        });
        // поток узла прерван без остановки прогона: «LLM-вызов прерван» не повторяется, причина — прерывание
        Thread.currentThread().interrupt();
        try {
            GigaChatException interrupted = assertThrows(GigaChatException.class,
                    () -> client.chatCompletion(List.of(Map.of("role", "user", "content", "Привет"))));
            assertEquals(GigaChatRetryPolicy.failedMessage(GigaChatFailureReason.INTERRUPTED), interrupted.getMessage());
        } finally {
            Thread.interrupted();
        }
    }

    @Test
    void clientPausesThroughOutageAndReportsCancelledRunHonestly() {
        ChatModel chatModel = Mockito.mock(ChatModel.class);
        GigaChatClient client = new GigaChatClient(chatModel, Mockito.mock(EmbeddingModel.class));
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 3);
        ReflectionTestUtils.setField(client, "retryDelayMillis", 1);
        ReflectionTestUtils.setField(client, "unavailableMaxWaitMillis", 60_000);
        ReflectionTestUtils.setField(client, "unavailableMaxDelayMillis", 2);
        AtomicInteger calls = new AtomicInteger();
        ChatResponse ok = new ChatResponse(List.of(new Generation(new AssistantMessage("ответ"))));
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            if (calls.incrementAndGet() <= 6) {
                throw new RuntimeException("I/O error: Connection refused");
            }
            return ok;
        });
        List<String> notices = new CopyOnWriteArrayList<>();
        GigaChatClient.setRunWaitNotice(notices::add);
        try {
            // шесть отказов подряд — больше прежних трёх попыток: шаг ждёт и получает ответ
            assertEquals("ответ", client.chatCompletion(List.of(Map.of("role", "user", "content", "Привет"))));
            assertEquals(6, notices.size());
            assertTrue(notices.get(0).startsWith("GigaChat недоступен — пауза"), notices.get(0));

            GigaChatClient.setRunCancelCheck(() -> true);
            calls.set(0);
            GigaChatException cancelled = assertThrows(GigaChatException.class,
                    () -> client.chatCompletion(List.of(Map.of("role", "user", "content", "Привет"))));
            assertEquals(GigaChatClient.CANCELLED, cancelled.getMessage());
        } finally {
            GigaChatClient.clearRunCancelCheck();
            GigaChatClient.clearRunWaitNotice();
        }
    }
}
