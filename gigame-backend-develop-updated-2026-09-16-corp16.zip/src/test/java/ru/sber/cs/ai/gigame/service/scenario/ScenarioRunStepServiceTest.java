package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.TransientDataAccessResourceException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.transaction.CannotCreateTransactionException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class ScenarioRunStepServiceTest {

    @Mock
    private ScenarioRunStepRepository stepRepository;

    @InjectMocks
    private ScenarioRunStepService stepService;

    @Captor
    private ArgumentCaptor<ScenarioRunStep> stepCaptor;

    private UUID runId;
    private UUID stepId;
    private String nodeId;
    private ScenarioRunStep step;

    @BeforeEach
    void setUp() {
        runId = UUID.randomUUID();
        stepId = UUID.randomUUID();
        nodeId = "node-1";

        step = new ScenarioRunStep();
        step.setId(stepId);
        step.setRunId(runId);
    }

    // -------------------------------------------------------------------------
    // setScenarioStepStatusRunning
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioStepStatusRunning() {
        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep result = stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.INPUT_NODE);

        assertNotNull(result);
        assertEquals(step, result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(runId, captured.getRunId());
        assertEquals(nodeId, captured.getNodeId());
        assertEquals(ScenarioNodeType.INPUT_NODE.toString(), captured.getNodeType());
        assertEquals(ScenarioStatus.RUNNING.getValue(), captured.getStatus());
        assertNotNull(captured.getStartedAt());
        assertNull(captured.getCompletedAt());
    }

    @Test
    void testSetScenarioStepStatusRunning_setsCorrectNodeType() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.PROCESSING_NODE);

        verify(stepRepository).save(stepCaptor.capture());
        assertEquals("processing", stepCaptor.getValue().getNodeType());
    }

    // -------------------------------------------------------------------------
    // setScenarioStepStatusCompleted
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioStepStatusCompleted() {
        when(stepRepository.save(any())).thenReturn(step);

        String previousOutput = "Previous result";
        String documentsText = "Document content";
        String output = "Final output";
        String prompt = "System prompt";

        ScenarioRunStep result = stepService.setScenarioStepStatusCompleted(
                step, previousOutput, documentsText, output, prompt);

        assertNotNull(result);
        assertEquals(step, result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(ScenarioStatus.COMPLETED.getValue(), captured.getStatus());
        assertNotNull(captured.getCompletedAt());

        // Check input data
        var inputData = captured.getInputData();
        assertNotNull(inputData);
        assertEquals(documentsText, inputData.get("documents_text"));
        assertEquals(previousOutput, inputData.get("previous_output"));

        // Check output data
        var outputData = captured.getOutputData();
        assertNotNull(outputData);
        assertEquals(output, outputData.get("result"));

        assertEquals(prompt, captured.getPromptUsed());
    }

    @Test
    void testSetScenarioStepStatusCompleted_withEmptyStrings() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusCompleted(step, "", "", "", "");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertEquals(ScenarioStatus.COMPLETED.getValue(), captured.getStatus());
    }

    @Test
    void testSetScenarioStepStatusCompleted_preservesStepId() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusCompleted(step, "prev", "docs", "out", "prompt");

        verify(stepRepository).save(stepCaptor.capture());
        assertEquals(stepId, stepCaptor.getValue().getId());
    }

    // -------------------------------------------------------------------------
    // setScenarioStepStatusFailed
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioStepStatusFailed_withErrorMessage() {
        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep result = stepService.setScenarioStepStatusFailed(step, "Custom error message");

        assertNotNull(result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(ScenarioStatus.FAILED.getValue(), captured.getStatus());
        assertNotNull(captured.getCompletedAt());

        var outputData = captured.getOutputData();
        assertNotNull(outputData);
        assertEquals("Custom error message", outputData.get("error"));
    }

    @Test
    void testSetScenarioStepStatusFailed_withNullMessage() {
        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep result = stepService.setScenarioStepStatusFailed(step, null);

        assertNotNull(result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(ScenarioStatus.FAILED.getValue(), captured.getStatus());
        var outputData = captured.getOutputData();
        assertEquals("Неизвестная ошибка", outputData.get("error"));
    }

    @Test
    void testSetScenarioStepStatusFailed_withEmptyMessage() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusFailed(step, "");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals("", captured.getOutputData().get("error"));
    }

    // -------------------------------------------------------------------------
    // Integration Tests
    // -------------------------------------------------------------------------

    @Test
    void testCompleteStepLifecycle() {
        // Step starts as running
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.INPUT_NODE);

        // Then completes
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusCompleted(step, "prev", "docs", "result", "prompt");

        // Verify two saves occurred
        verify(stepRepository, times(2)).save(stepCaptor.capture());

        // Get all captured steps
        List<ScenarioRunStep> allSteps = stepCaptor.getAllValues();
        assertEquals(2, allSteps.size());

        // First step should be running
        assertEquals(ScenarioStatus.RUNNING.getValue(), allSteps.get(0).getStatus());

        // Second step should be completed
        assertEquals(ScenarioStatus.COMPLETED.getValue(), allSteps.get(1).getStatus());
    }

    @Test
    void testFailedStepLifecycle() {
        // Step starts as running
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.PROCESSING_NODE);

        // Then fails
        when(stepRepository.save(any())).thenReturn(step);
        stepService.setScenarioStepStatusFailed(step, "Processing error");

        // Verify two saves occurred
        verify(stepRepository, times(2)).save(stepCaptor.capture());

        // Get all captured steps
        List<ScenarioRunStep> allSteps = stepCaptor.getAllValues();
        assertEquals(2, allSteps.size());

        // First step should be running
        assertEquals(ScenarioStatus.RUNNING.getValue(), allSteps.get(0).getStatus());

        // Second step should be failed
        assertEquals(ScenarioStatus.FAILED.getValue(), allSteps.get(1).getStatus());
        assertNotNull(allSteps.get(1).getCompletedAt());

        // Check error message in output data
        var outputData = allSteps.get(1).getOutputData();
        assertNotNull(outputData);
        assertEquals("Processing error", outputData.get("error"));
    }

    @Test
    void testMultipleSteps_sameRunId() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusRunning(runId, "node-1", ScenarioNodeType.INPUT_NODE);
        stepService.setScenarioStepStatusRunning(runId, "node-2", ScenarioNodeType.PROCESSING_NODE);

        // Verify save was called twice with argument capture
        verify(stepRepository, times(2)).save(stepCaptor.capture());

        // Both steps should have the same runId
        assertEquals(2, stepCaptor.getAllValues().size());
        for (ScenarioRunStep s : stepCaptor.getAllValues()) {
            assertEquals(runId, s.getRunId());
        }
    }

    @Test
    void testInputDataStructure() {
        when(stepRepository.save(any())).thenReturn(step);

        String documentsText = "Doc 1\nDoc 2";
        String previousOutput = "Previous result";

        stepService.setScenarioStepStatusCompleted(step, previousOutput, documentsText, "output", "prompt");

        verify(stepRepository).save(stepCaptor.capture());
        var inputData = stepCaptor.getValue().getInputData();

        assertTrue(inputData.containsKey("documents_text"));
        assertTrue(inputData.containsKey("previous_output"));
        assertEquals(documentsText, inputData.get("documents_text"));
        assertEquals(previousOutput, inputData.get("previous_output"));
    }

    @Test
    void testOutputDataStructure() {
        when(stepRepository.save(any())).thenReturn(step);

        String output = "Final answer";

        stepService.setScenarioStepStatusCompleted(step, "prev", "docs", output, "prompt");

        verify(stepRepository).save(stepCaptor.capture());
        var outputData = stepCaptor.getValue().getOutputData();

        assertTrue(outputData.containsKey("result"));
        assertEquals(output, outputData.get("result"));
    }

    @Test
    void testErrorDataStructure() {
        when(stepRepository.save(any())).thenReturn(step);

        String errorMsg = "Something went wrong";

        stepService.setScenarioStepStatusFailed(step, errorMsg);

        verify(stepRepository).save(stepCaptor.capture());
        var outputData = stepCaptor.getValue().getOutputData();

        assertTrue(outputData.containsKey("error"));
        assertEquals(errorMsg, outputData.get("error"));
    }

    // -------------------------------------------------------------------------
    // appendOutputData
    // -------------------------------------------------------------------------

    @Test
    void testAppendOutputData_addsNewKeyToExistingMap() {
        when(stepRepository.save(any())).thenReturn(step);

        Map<String, String> existing = new HashMap<>(Map.of("result", "initial"));
        step.setOutputData(existing);

        stepService.appendOutputData(step, "doc_names", "file1.pdf\nfile2.pdf");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertNotNull(captured.getOutputData());
        assertEquals(2, captured.getOutputData().size());
        assertEquals("initial", captured.getOutputData().get("result"));
        assertEquals("file1.pdf\nfile2.pdf", captured.getOutputData().get("doc_names"));
    }

    @Test
    void testAppendOutputData_whenOutputDataIsNull_createsNewMap() {
        when(stepRepository.save(any())).thenReturn(step);

        step.setOutputData(null);

        stepService.appendOutputData(step, "key1", "val1");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertNotNull(captured.getOutputData());
        assertEquals(1, captured.getOutputData().size());
        assertEquals("val1", captured.getOutputData().get("key1"));
    }

    @Test
    void testAppendOutputData_overwritesExistingKey() {
        when(stepRepository.save(any())).thenReturn(step);

        step.setOutputData(new HashMap<>(Map.of("existing_key", "old_value")));

        stepService.appendOutputData(step, "existing_key", "new_value");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertEquals("new_value", captured.getOutputData().get("existing_key"));
    }

    @Test
    void testAppendOutputData_preservesOtherKeys() {
        when(stepRepository.save(any())).thenReturn(step);

        step.setOutputData(new HashMap<>(Map.of(
                "result", "final_answer",
                "doc_names", "test.txt")));

        stepService.appendOutputData(step, "extra_key", "extra_value");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertNotNull(captured.getOutputData());
        assertEquals(3, captured.getOutputData().size());
        assertEquals("final_answer", captured.getOutputData().get("result"));
        assertEquals("test.txt", captured.getOutputData().get("doc_names"));
        assertEquals("extra_value", captured.getOutputData().get("extra_key"));
    }

    @Test
    void testAppendOutputData_persistsToDatabase() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.appendOutputData(step, "key", "value");

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertEquals(1, captured.getOutputData().size());
        assertEquals(Map.of("key", "value"), captured.getOutputData());
    }

    // -------------------------------------------------------------------------
    // copyStepToRun
    // -------------------------------------------------------------------------

    @Test
    void testCopyStepToRun_createsNewStepUnderNewRun() {
        UUID oldRunId = UUID.randomUUID();
        UUID newRunId = UUID.randomUUID();

        ScenarioRunStep oldStep = new ScenarioRunStep();
        oldStep.setId(UUID.randomUUID());
        oldStep.setRunId(oldRunId);
        oldStep.setNodeId("node-1");
        oldStep.setNodeType("output");
        oldStep.setStatus("completed");
        oldStep.setInputData(Map.of("documents_text", "some docs"));
        oldStep.setOutputData(Map.of("result", "final answer"));
        oldStep.setPromptUsed("system prompt");
        oldStep.setTokensUsed(150);

        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep result = stepService.copyStepToRun(newRunId, oldStep);

        assertNotNull(result);
        verify(stepRepository).save(stepCaptor.capture());

        ScenarioRunStep captured = stepCaptor.getValue();
        assertEquals(newRunId, captured.getRunId());
        assertEquals(oldStep.getNodeId(), captured.getNodeId());
        assertEquals(oldStep.getNodeType(), captured.getNodeType());
        assertEquals("completed", captured.getStatus());
        assertEquals(oldStep.getInputData(), captured.getInputData());
        assertEquals(oldStep.getOutputData(), captured.getOutputData());
        assertEquals(oldStep.getPromptUsed(), captured.getPromptUsed());
        assertEquals(oldStep.getTokensUsed(), captured.getTokensUsed());
        assertNotNull(captured.getStartedAt());
        assertNotNull(captured.getCompletedAt());
    }

    @Test
    void testCopyStepToRun_copiesAllFieldsCorrectly() {
        UUID oldRunId = UUID.randomUUID();
        UUID newRunId = UUID.randomUUID();

        Map<String, String> oldInput = new HashMap<>(Map.of("documents_text", "doc content"));
        Map<String, String> oldOutput = new HashMap<>(Map.of("result", "output"));

        ScenarioRunStep oldStep = new ScenarioRunStep();
        oldStep.setRunId(oldRunId);
        oldStep.setNodeId("node-1");
        oldStep.setNodeType("output");
        oldStep.setInputData(oldInput);
        oldStep.setOutputData(oldOutput);
        oldStep.setPromptUsed("test prompt");
        oldStep.setTokensUsed(100);

        when(stepRepository.save(any())).thenReturn(step);

        stepService.copyStepToRun(newRunId, oldStep);

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertEquals(newRunId, captured.getRunId());
        assertEquals(oldStep.getNodeId(), captured.getNodeId());
        assertEquals(oldStep.getNodeType(), captured.getNodeType());
        assertEquals("completed", captured.getStatus());
        assertNotNull(captured.getStartedAt());
        assertNotNull(captured.getCompletedAt());
    }

    @Test
    void testCopyStepToRun_setsBothTimestamps() {
        when(stepRepository.save(any())).thenReturn(step);

        ScenarioRunStep oldStep = new ScenarioRunStep();
        oldStep.setRunId(UUID.randomUUID());
        oldStep.setNodeId("node-1");

        stepService.copyStepToRun(UUID.randomUUID(), oldStep);

        verify(stepRepository).save(stepCaptor.capture());
        ScenarioRunStep captured = stepCaptor.getValue();

        assertNotNull(captured.getStartedAt());
        assertNotNull(captured.getCompletedAt());
    }

    // -------------------------------------------------------------------------
    // corp15: сводка документов, doc_names одним UPDATE, повтор сохранения
    // -------------------------------------------------------------------------

    @Test
    void documentsSummary_containsLabelsAndHashInsteadOfText() {
        String texts = "текст первого\n\nтекст второго";

        String summary = ScenarioRunStepService.documentsSummary(List.of("DOC_1", "DOC_2"), texts);

        assertTrue(summary.startsWith("DOC_1, DOC_2\nsha256:"));
        assertFalse(summary.contains("текст первого"));
        assertEquals(64, summary.substring(summary.indexOf("sha256:") + 7).length());
        assertEquals(summary, ScenarioRunStepService.documentsSummary(List.of("DOC_1", "DOC_2"), texts));
    }

    @Test
    void documentsSummary_withoutDocs_isEmpty() {
        assertEquals("", ScenarioRunStepService.documentsSummary(List.of(), ""));
        assertEquals("", ScenarioRunStepService.documentsSummary(null, null));
    }

    @Test
    void setScenarioStepStatusCompleted_withDocNames_writesResultAndDocNamesInOneSave() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusCompleted(step, "prev", "DOC_1\nsha256:abc", "out", "prompt", 12, "a.pdf\nb.pdf");

        verify(stepRepository, times(1)).save(stepCaptor.capture());
        var outputData = stepCaptor.getValue().getOutputData();
        assertEquals("out", outputData.get("result"));
        assertEquals("a.pdf\nb.pdf", outputData.get("doc_names"));
        assertEquals(12, stepCaptor.getValue().getTokensUsed());
        assertEquals("DOC_1\nsha256:abc", stepCaptor.getValue().getInputData().get("documents_text"));
    }

    @Test
    void setScenarioStepStatusCompleted_withoutDocNames_hasNoDocNamesKey() {
        when(stepRepository.save(any())).thenReturn(step);

        stepService.setScenarioStepStatusCompleted(step, "prev", "", "out", "prompt", null, null);

        verify(stepRepository).save(stepCaptor.capture());
        assertFalse(stepCaptor.getValue().getOutputData().containsKey("doc_names"));
    }

    @Test
    void saveWithRetry_retriesTransientFailureThenSucceeds() {
        stepService.setRetryPauseMs(1);
        when(stepRepository.save(any()))
                .thenThrow(new TransientDataAccessResourceException("пул соединений исчерпан"))
                .thenReturn(step);

        ScenarioRunStep result = stepService.setScenarioStepStatusFailed(step, "ошибка узла");

        assertEquals(step, result);
        verify(stepRepository, times(2)).save(any());
    }

    @Test
    void saveWithRetry_givesUpAfterRetries() {
        stepService.setRetryPauseMs(1);
        when(stepRepository.save(any())).thenThrow(new TransientDataAccessResourceException("нет соединения"));

        assertThrows(TransientDataAccessResourceException.class,
                () -> stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.INPUT_NODE));
        verify(stepRepository, times(ScenarioRunStepService.SAVE_RETRIES + 1)).save(any());
    }

    @Test
    void saveWithRetry_doesNotRetryNonTransientFailure() {
        when(stepRepository.save(any())).thenThrow(new DataIntegrityViolationException("нарушение ограничения"));

        assertThrows(DataIntegrityViolationException.class,
                () -> stepService.setScenarioStepStatusRunning(runId, nodeId, ScenarioNodeType.INPUT_NODE));
        verify(stepRepository, times(1)).save(any());
    }

    @Test
    void isRetryable_coversPoolTimeoutAndTransactionStart() {
        assertTrue(ScenarioRunStepService.isRetryable(new CannotGetJdbcConnectionException("таймаут пула")));
        assertTrue(ScenarioRunStepService.isRetryable(new CannotCreateTransactionException("нет соединения")));
        assertFalse(ScenarioRunStepService.isRetryable(new IllegalStateException("логика")));
    }
}
