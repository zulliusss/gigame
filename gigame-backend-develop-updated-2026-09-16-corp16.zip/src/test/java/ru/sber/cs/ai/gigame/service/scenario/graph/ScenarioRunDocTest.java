package ru.sber.cs.ai.gigame.service.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioRunDocTest {

    @Test
    void testConstructor_withTextAndFilename() {
        var doc = new ScenarioRunDoc("test.txt", "content");
        assertEquals("test.txt", doc.getFilename());
        assertEquals("content", doc.getText());
        assertNull(doc.getDocClass());
    }

    @Test
    void testConstructor_withNullValues() {
        var doc = new ScenarioRunDoc(null, null);
        assertNull(doc.getFilename());
        assertNull(doc.getText());
        assertNull(doc.getDocClass());
    }

    @Test
    void testSetDocClass() {
        var doc = new ScenarioRunDoc("doc.txt", "text");
        assertNull(doc.getDocClass());

        doc.setDocClass("ТЗ");
        assertEquals("ТЗ", doc.getDocClass());

        doc.setDocClass(null);
        assertNull(doc.getDocClass());
    }

    @Test
    void statusIsDetectedFromMarkers() {
        assertEquals(ScenarioRunDoc.STATUS_OK, new ScenarioRunDoc("a.pdf", "Договор № 1").getStatus());
        assertEquals(ScenarioRunDoc.STATUS_OCR, new ScenarioRunDoc("a.pdf",
                "[РАСПОЗНАНО ИЗ СКАНА — суммы перепроверить] Документ «a.pdf»:\nАкт").getStatus());
        assertEquals(ScenarioRunDoc.STATUS_TRUNCATED, new ScenarioRunDoc("a.pdf",
                "[РАСПОЗНАНО ИЗ СКАНА] Документ «a.pdf»:\n--- страница 1 ---\n[страница 1 не распознана: отказ модели]").getStatus());
        assertEquals(ScenarioRunDoc.STATUS_TRUNCATED, new ScenarioRunDoc("a.xlsx", "1 | 2\n[...обрезано: больше 100 строк]").getStatus());
        assertEquals(ScenarioRunDoc.STATUS_TRUNCATED, new ScenarioRunDoc("a.txt",
                "[кодировка не распознана — текст может быть искажён]\nмусор").getStatus());
        assertEquals(ScenarioRunDoc.STATUS_TRUNCATED, new ScenarioRunDoc("a.pdf",
                "текст\n\n[страница 3 без текстового слоя — не распознана]").getStatus());
        var unreadable = new ScenarioRunDoc("скан.pdf", "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «скан.pdf» не распознан: "
                + "PDF без текстового слоя (скан). Автоматический анализ содержимого невозможен — проверьте документ вручную.");
        assertEquals(ScenarioRunDoc.STATUS_UNREADABLE, unreadable.getStatus());
        assertEquals(true, unreadable.isUnreadable());
        assertEquals("PDF без текстового слоя (скан)", ScenarioRunDoc.unreadableReason(unreadable.getText()));
        assertEquals("причина", ScenarioRunDoc.unreadableReason("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Архив «a.zip» не распакован: причина. Документы не попали."));
        assertEquals("", ScenarioRunDoc.unreadableReason("обычный текст"));
        // рабочий файл агента всегда ok — маркеры в конспекте не статус документа
        assertEquals(ScenarioRunDoc.STATUS_OK, new ScenarioRunDoc("конспект.md", "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] заметка", true).getStatus());
    }
}
