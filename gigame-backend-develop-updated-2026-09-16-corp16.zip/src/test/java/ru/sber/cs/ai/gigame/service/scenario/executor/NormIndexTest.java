package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Структурный индекс нормативки: разбор имён файлов базы, поиск части/пункта статьи по реквизиту справочника.
 */
class NormIndexTest {

    private static final String ART3 = """
            Федеральный закон от 18.07.2011 № 223-ФЗ (актуальная редакция)
            Статья 3. Принципы и основные положения закупки товаров, работ, услуг
            1. При закупке товаров, работ, услуг заказчики руководствуются следующими принципами:
            1) информационная открытость закупки;
            2) равноправие, справедливость, отсутствие дискриминации и необоснованных ограничений конкуренции по отношению к участникам закупки;
            3) целевое и экономически эффективное расходование денежных средств;
            4) отсутствие ограничения допуска к участию в закупке путем установления неизмеряемых требований к участникам закупки.
            2. Положением о закупке предусматриваются конкурентные и неконкурентные закупки.
            5 3 . Срок оплаты заказчиком поставленного товара должен составлять не более семи рабочих дней с даты приемки.
            6. Не допускается предъявлять к участникам закупки требования, не предусмотренные документацией.
            """;

    private static final String ART32 = """
            Статья 3 2 . Порядок осуществления конкурентной закупки
            16. Под конкурсом понимается форма торгов.
            17. Заказчик размещает извещение о проведении конкурса не менее чем за пятнадцать дней до даты окончания срока подачи заявок.
            18. Под аукционом понимается форма торгов.
            19. Заказчик размещает извещение о проведении аукциона не менее чем за пятнадцать дней.
            20. Под запросом котировок понимается форма торгов.
            21. При проведении запроса котировок извещение размещается не менее чем за пять рабочих дней.
            22. Под запросом предложений понимается форма торгов.
            """;

    private static final String PP1352 = """
            ПОСТАНОВЛЕНИЕ от 11 декабря 2014 г. № 1352
            14. (Пункт утратил силу)
            14 3 . При осуществлении закупки срок оплаты по договору с субъектом малого и среднего предпринимательства должен составлять не более 7 рабочих дней.
            15. Заказчик вправе.
            """;

    private static NormIndex index() {
        Map<String, String> docs = new LinkedHashMap<>();
        docs.put("223-ФЗ статья 3 Принципы и основные положения закупки товаров, работ, услуг.txt", ART3);
        docs.put("223-ФЗ статья 3 2 . Порядок осуществления конкурентной закупки.txt", ART32);
        docs.put("223-ФЗ статья 4 Информационное обеспечение закупки.txt", "Статья 4.\n10. В документации о конкурентной закупке должны быть указаны:\n9) требования к участникам такой закупки;\n13) критерии оценки;\n11. Изменения.");
        docs.put("135-ФЗ статья 17 Антимонопольные требования к торгам, запросу котировок цен на товары.txt", "Статья 17.\n1. При проведении торгов запрещаются действия.\n2. Иное.");
        docs.put("НК РФ статья 164 Налоговые ставки.txt", "Статья 164. Налоговые ставки\n1. Налогообложение производится по ставке 0 процентов.");
        docs.put("ПП 1352 от 11.12.2014 Об особенностях участия СМСП в закупках.txt", PP1352);
        docs.put("Положение о закупках Сбербанка 2348-3 — разд 5  Требования к Участникам Закупочных процедур.txt", "## 5. Требования к Участникам\n5.1. Участник должен.");
        docs.put("Положение о закупках Сбербанка 2348-3 — прил Приложение 5  Приложение 5.txt", "Приложение 5 текст");
        docs.put("ТС 4620-3 04 - раздел 4. Запреты и ограничения при проведении Закупок.txt", "4. Запреты и ограничения\n4.1 Запрещается.");
        docs.put("ТС 4620-3 08 - раздел 3. УВБ при НМЦД более 50 (пятидесяти) млн руб.;.txt", "3. УВБ при НМЦД более 50 млн");
        docs.put("ТС 4620-3 16 - раздел 3. Положение о закупках ПАО Сбербанк от 04.06.2020 № 2348-3 (в актуа.txt", "3. Положение о закупках ссылка");
        docs.put("Справка об актуальности нормативных актов в сфере закупок 223-ФЗ.txt", "Справка: ПП 2013 утратило силу.");
        return NormIndex.build(docs);
    }

    @Test
    void parsesFileNamesIntoActsAndArticles() {
        assertEquals(12, index().size());
        assertEquals("3.2", NormIndex.parseName("223-ФЗ статья 3 2 . Порядок осуществления", "").article());
        assertEquals("3.1-4", NormIndex.parseName("223-ФЗ статья 3 1-4 . Предоставление национального режима", "").article());
        assertEquals("10", NormIndex.parseName("135-ФЗ ст 10  Запрет на злоупотребление", "").article());
        assertEquals("ПП 301", NormIndex.parseName("Постановление Правительства РФ от 06.03.2022 N 301 (ред. от", "").act());
        assertEquals("прил.5", NormIndex.parseName("Положение о закупках Сбербанка 2348-3 — прил Приложение 5  Приложение 5", "").article());
        assertEquals("13.1", NormIndex.parseName("Положение о закупках Сбербанка 2348-3 — разд 13¹  Порядок проведения Закупки", "").article());
    }

    @Test
    void resolvesPointsInsidePartOfArticle() {
        List<NormIndex.Hit> hits = index().resolve("п. 2, 4 ч. 1 ст. 3 223-ФЗ (равноправие; запрет неизмеряемых требований)");

        assertEquals(1, hits.size());
        NormIndex.Hit hit = hits.get(0);
        assertTrue(hit.partFound());
        assertTrue(hit.document().startsWith("223-ФЗ статья 3 Принципы"));
        assertTrue(hit.text().startsWith("1. При закупке товаров"));
        assertTrue(hit.text().contains("2) равноправие, справедливость"));
        assertTrue(hit.text().contains("4) отсутствие ограничения допуска"));
        assertFalse(hit.text().contains("информационная открытость"));
        assertFalse(hit.text().contains("2. Положением о закупке"));
    }

    @Test
    void resolvesPartRangeAndDottedPartAndPointWithParentheses() {
        NormIndex idx = index();
        NormIndex.Hit range = idx.resolve("ч. 17–21 ст. 3.2 223-ФЗ (минимальные сроки конкурентных закупок)").get(0);
        assertTrue(range.text().startsWith("17. Заказчик размещает"));
        assertTrue(range.text().contains("21. При проведении запроса котировок"));
        assertFalse(range.text().contains("22. Под запросом предложений"));

        NormIndex.Hit dotted = idx.resolve("ч. 5.3 ст. 3 223-ФЗ (оплата не позднее 7 рабочих дней)").get(0);
        assertTrue(dotted.text().startsWith("5 3 . Срок оплаты"));
        assertFalse(dotted.text().contains("6. Не допускается"));

        NormIndex.Hit pp = idx.resolve("п. 14(3) ПП 1352 (срок оплаты СМСП)").get(0);
        assertTrue(pp.partFound());
        assertTrue(pp.text().startsWith("14 3 . При осуществлении закупки"));
        assertFalse(pp.text().contains("15. Заказчик"));
    }

    @Test
    void resolvesSeveralRequisitesCodesPolicySectionsAndSprings() {
        NormIndex idx = index();
        List<NormIndex.Hit> hits = idx.resolve("п. 13, 14 ч. 10 ст. 4 223-ФЗ (критерии); ч. 1 ст. 17 135-ФЗ; ст. 164 НК РФ; "
                + "Положение о закупках 2348-3 разд. 5; ТС 4620-3 разд. 3 (УВБ при НМЦД более 50 млн руб.); Справка об актуальности нормативных актов");

        assertEquals(6, hits.size());
        assertTrue(hits.get(0).text().contains("13) критерии оценки"));
        assertFalse(hits.get(0).text().contains("9) требования"));
        assertEquals("135-ФЗ статья 17 Антимонопольные требования к торгам, запросу котировок цен на товары", hits.get(1).document());
        assertTrue(hits.get(1).text().startsWith("1. При проведении торгов"));
        assertTrue(hits.get(2).document().startsWith("НК РФ статья 164"));
        assertFalse(hits.get(2).partFound());
        assertTrue(hits.get(3).document().contains("разд 5"));
        assertTrue(hits.get(4).document().contains("УВБ при НМЦД"));
        assertTrue(hits.get(5).text().contains("ПП 2013 утратило силу"));
        assertTrue(idx.resolve("187-ФЗ «О безопасности КИИ» — В БАЗЕ ОТСУТСТВУЕТ").isEmpty());
    }

    @Test
    void spravkaIsRecognizedCaseInsensitivelyByBaseName() {
        var docs = new java.util.LinkedHashMap<String, String>();
        docs.put("нормативка.zip/справка об актуальности актов.txt", "Справка: ПП 2013 утратило силу.");
        NormIndex index = NormIndex.build(docs);

        assertEquals(1, index.size());
        assertFalse(index.resolve("Справка об актуальности нормативных актов").isEmpty());
    }
}
