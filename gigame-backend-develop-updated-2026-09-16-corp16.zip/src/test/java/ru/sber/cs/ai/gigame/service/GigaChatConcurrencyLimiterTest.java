package ru.sber.cs.ai.gigame.service;

import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты общего ограничителя одновременных запросов к GigaChat: лимит, честная очередь,
 * отмена и прерывание ожидания, уведомления, освобождение при ошибке, режим без ограничения.
 */
class GigaChatConcurrencyLimiterTest {

    private static final long WAIT_SECONDS = 5;
    private static final long NO_NOTICE = 60_000;

    private final ExecutorService pool = Executors.newCachedThreadPool();

    @AfterEach
    void tearDown() {
        pool.shutdownNow();
    }

    @Test
    void limitsInFlightToMaxWhenMoreThreadsCall() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(2, true, NO_NOTICE);
        CountDownLatch gate = new CountDownLatch(1);
        AtomicInteger current = new AtomicInteger();
        AtomicInteger peak = new AtomicInteger();
        List<Future<String>> futures = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            futures.add(pool.submit(() -> limiter.call(() -> hold(gate, current, peak), null, null)));
        }

        awaitTrue(() -> limiter.inFlight() == 2 && limiter.waiting() == 4 && current.get() == 2);
        assertEquals(2, peak.get());
        gate.countDown();

        for (Future<String> future : futures) {
            assertEquals("ok", future.get(WAIT_SECONDS, TimeUnit.SECONDS));
        }
        assertEquals(2, peak.get());
        assertEquals(0, limiter.inFlight());
        assertEquals(0, limiter.waiting());
    }

    @Test
    void grantsPermitsInArrivalOrder() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, NO_NOTICE);
        CountDownLatch gate = new CountDownLatch(1);
        Future<String> holder = holdPermit(limiter, gate);
        List<Integer> order = new CopyOnWriteArrayList<>();
        List<Future<Boolean>> waiters = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            int number = i;
            waiters.add(pool.submit(() -> limiter.call(() -> order.add(number), null, null)));
            awaitTrue(() -> limiter.waiting() == number);
        }

        gate.countDown();

        assertEquals("held", holder.get(WAIT_SECONDS, TimeUnit.SECONDS));
        for (Future<Boolean> waiter : waiters) {
            assertTrue(waiter.get(WAIT_SECONDS, TimeUnit.SECONDS));
        }
        assertEquals(List.of(1, 2, 3), order);
    }

    @Test
    void cancelledRunLeavesQueueAndNextWaiterProceeds() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, NO_NOTICE);
        CountDownLatch gate = new CountDownLatch(1);
        Future<String> holder = holdPermit(limiter, gate);
        AtomicBoolean cancelled = new AtomicBoolean();
        Future<String> first = pool.submit(() -> limiter.call(() -> "first", cancelled::get, null));
        awaitTrue(() -> limiter.waiting() == 1);
        Future<String> second = pool.submit(() -> limiter.call(() -> "second", null, null));
        awaitTrue(() -> limiter.waiting() == 2);

        cancelled.set(true);

        ExecutionException error = assertThrows(ExecutionException.class, () -> first.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertInstanceOf(GigaChatException.class, error.getCause());
        assertEquals(GigaChatClient.CANCELLED, error.getCause().getMessage());
        assertEquals(1, limiter.waiting());
        assertEquals(1, limiter.inFlight());
        gate.countDown();
        assertEquals("held", holder.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals("second", second.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void interruptedWaitLeavesQueueAndKeepsInterruptFlag() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, NO_NOTICE);
        CountDownLatch gate = new CountDownLatch(1);
        Future<String> holder = holdPermit(limiter, gate);
        List<Thread> waiterThread = new CopyOnWriteArrayList<>();
        Future<String> waiter = pool.submit(() -> {
            waiterThread.add(Thread.currentThread());
            return callRecordingInterrupt(limiter);
        });
        awaitTrue(() -> limiter.waiting() == 1);

        waiterThread.get(0).interrupt();

        assertEquals(GigaChatConcurrencyLimiter.INTERRUPTED + "|interrupted=true", waiter.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(0, limiter.waiting());
        assertEquals(1, limiter.inFlight());
        gate.countDown();
        assertEquals("held", holder.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void noticesLongWaitOnceAndReportsGrant() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, 50);
        CountDownLatch gate = new CountDownLatch(1);
        Future<String> holder = holdPermit(limiter, gate);
        List<String> notices = new CopyOnWriteArrayList<>();
        Future<String> waiter = pool.submit(() -> limiter.call(() -> "done", null, notices::add));
        awaitTrue(() -> notices.size() == 1);
        Thread.sleep(GigaChatConcurrencyLimiter.POLL_MILLIS * 3);
        assertEquals(1, notices.size(), "уведомление об ожидании повторяется на каждом шаге опроса");

        gate.countDown();

        assertEquals("done", waiter.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals("held", holder.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(2, notices.size());
        assertEquals("все 1 потоков GigaChat заняты — шаг ждёт очереди (ожидающих: 1)", notices.get(0));
        assertTrue(notices.get(1).startsWith("очередь к GigaChat пройдена за "), notices.get(1));
    }

    @Test
    void immediateGrantSendsNoNotice() {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, 0);
        List<String> notices = new CopyOnWriteArrayList<>();

        assertEquals("fast", limiter.call(() -> "fast", () -> false, notices::add));

        assertTrue(notices.isEmpty());
    }

    @Test
    void failingNoticeReceiverDoesNotBreakCallOrLeakPermit() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, 10);
        CountDownLatch gate = new CountDownLatch(1);
        Future<String> holder = holdPermit(limiter, gate);
        AtomicInteger attempts = new AtomicInteger();
        Future<String> waiter = pool.submit(() -> limiter.call(() -> "done", null, text -> {
            attempts.incrementAndGet();
            throw new IllegalStateException("журнал недоступен");
        }));
        awaitTrue(() -> attempts.get() == 1);

        gate.countDown();

        assertEquals("done", waiter.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals("held", holder.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(2, attempts.get());
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void releasesPermitWhenCallThrows() {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, NO_NOTICE);

        assertThrows(IllegalStateException.class, () -> limiter.call(() -> {
            throw new IllegalStateException("429 Too Many Requests");
        }, null, null));

        assertEquals(0, limiter.inFlight());
        assertEquals("next", limiter.call(() -> "next", null, null));
    }

    @ParameterizedTest
    @ValueSource(ints = {0, -1})
    void nonPositiveMaxMeansUnlimited(int max) throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(max, true, NO_NOTICE);
        CountDownLatch gate = new CountDownLatch(1);
        AtomicInteger current = new AtomicInteger();
        AtomicInteger peak = new AtomicInteger();
        List<Future<String>> futures = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            futures.add(pool.submit(() -> limiter.callEmbeddings(() -> hold(gate, current, peak), null, null)));
        }

        awaitTrue(() -> current.get() == 10);
        gate.countDown();

        for (Future<String> future : futures) {
            assertEquals("ok", future.get(WAIT_SECONDS, TimeUnit.SECONDS));
        }
        assertEquals(10, peak.get());
        assertEquals(0, limiter.inFlight());
        assertEquals(0, limiter.waiting());
        limiter.acquire(null, null).close();
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void embeddingsBypassQueueWhenFlagOff() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, false, NO_NOTICE);
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);

        assertEquals("emb", limiter.callEmbeddings(() -> "emb", null, null));

        assertEquals(0, limiter.waiting());
        permit.close();
    }

    @Test
    void embeddingsWaitForQueueWhenFlagOn() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, NO_NOTICE);
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);
        Future<String> embeddings = pool.submit(() -> limiter.callEmbeddings(() -> "emb", null, null));
        awaitTrue(() -> limiter.waiting() == 1);
        assertFalse(embeddings.isDone());

        permit.close();

        assertEquals("emb", embeddings.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void nestedCallOnSameThreadDoesNotDeadlock() {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, NO_NOTICE);

        assertEquals("x", limiter.call(() -> limiter.call(() -> "x", null, null), null, null));

        assertEquals(0, limiter.inFlight());
    }

    @Test
    void permitCloseIsIdempotent() {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(2, true, NO_NOTICE);
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);
        assertEquals(1, limiter.inFlight());

        permit.close();
        permit.close();
        GigaChatConcurrencyLimiter.Permit.free().close();

        assertEquals(0, limiter.inFlight());
    }

    @Test
    void defaultsMatchCorporateKey() {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter();

        assertEquals(5, limiter.maxConcurrent());
        assertTrue(limiter.isLimitEmbeddings());
        assertEquals(0, GigaChatConcurrencyLimiter.unlimited().maxConcurrent());
        assertFalse(GigaChatConcurrencyLimiter.unlimited().isLimitEmbeddings());
    }

    @Test
    void metricsShowActiveWaitingAndLimit() throws Exception {
        GigaChatConcurrencyLimiter limiter = new GigaChatConcurrencyLimiter(1, true, NO_NOTICE);
        SimpleMeterRegistry registry = new SimpleMeterRegistry();
        limiter.bindTo(registry);
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);
        Future<String> waiter = pool.submit(() -> limiter.call(() -> "w", null, null));
        awaitTrue(() -> limiter.waiting() == 1);

        assertEquals(1.0, registry.get("gigachat.requests.active").gauge().value());
        assertEquals(1.0, registry.get("gigachat.requests.waiting").gauge().value());
        assertEquals(1.0, registry.get("gigachat.requests.limit").gauge().value());

        permit.close();
        assertEquals("w", waiter.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(0.0, registry.get("gigachat.requests.active").gauge().value());
    }

    private Future<String> holdPermit(GigaChatConcurrencyLimiter limiter, CountDownLatch gate) {
        CountDownLatch taken = new CountDownLatch(1);
        Future<String> holder = pool.submit(() -> limiter.call(() -> {
            taken.countDown();
            awaitLatch(gate);
            return "held";
        }, null, null));
        awaitLatch(taken);
        return holder;
    }

    private static String hold(CountDownLatch gate, AtomicInteger current, AtomicInteger peak) {
        peak.accumulateAndGet(current.incrementAndGet(), Math::max);
        awaitLatch(gate);
        current.decrementAndGet();
        return "ok";
    }

    private static String callRecordingInterrupt(GigaChatConcurrencyLimiter limiter) {
        try {
            return limiter.call(() -> "granted", null, null);
        } catch (GigaChatException e) {
            return e.getMessage() + "|interrupted=" + Thread.currentThread().isInterrupted();
        }
    }

    private static void awaitLatch(CountDownLatch latch) {
        try {
            assertTrue(latch.await(WAIT_SECONDS, TimeUnit.SECONDS), "латч не открылся");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        }
    }

    private static void awaitTrue(BooleanSupplier condition) throws InterruptedException {
        long deadline = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(WAIT_SECONDS);
        while (!condition.getAsBoolean()) {
            assertTrue(System.currentTimeMillis() < deadline, "условие не выполнилось за " + WAIT_SECONDS + " с");
            Thread.sleep(5);
        }
    }
}
