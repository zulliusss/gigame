package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Единый разбор JSON из ответов модели: политики выбора, приоритет блоков ```json,
 * строгий → терпимый → починка десятичной запятой, линейность на оборванном тексте.
 */
class LlmJsonTest {

    private static final String GROUPS = """
            === Группа A ===
            [{"тип": "a", "цитата": "1"}]
            === Группа B ===
            [{"тип": "b", "цитата": "2"}, {"тип": "b2", "цитата": "3"}]
            """;

    @Test
    void numberArray_isNotBrokenByDecimalCommaFix() {
        LlmJson.Parsed block = LlmJson.first("[1,2,3]", LlmJson.ANY).first();

        assertNotNull(block);
        assertTrue(block.strict());
        assertEquals(List.of(1, 2, 3), block.value());
    }

    @Test
    void decimalComma_isFixedOnlyWhenStrictAndTolerantFail() {
        LlmJson.Parsed block = LlmJson.first("{\"сумма\": 1234567,89, \"список\": [1,2,3]}", LlmJson.OBJECT).first();

        assertNotNull(block);
        assertFalse(block.strict());
        assertEquals(1234567.89, block.node().get("сумма").asDouble(), 1e-9);
        assertEquals(3, block.node().get("список").size());
        assertEquals(2, block.node().get("список").get(1).asInt());
    }

    @Test
    void tolerantParse_acceptsTrailingCommaAndComments() {
        LlmJson.Parsed block = LlmJson.first("{'a': 1, /* c */ 'b': [2,],}", LlmJson.OBJECT).first();

        assertNotNull(block);
        assertFalse(block.strict());
        assertEquals("{\"a\":1,\"b\":[2]}", block.json());
    }

    @Test
    void fencedBlock_hasPriorityOverBracketsInProse() {
        String text = "См. [1] и {п. 3}.\n```json\n[{\"x\": 1}]\n```\nи ещё [2]";

        LlmJson.Parsed block = LlmJson.first(text, LlmJson.ANY).first();

        assertNotNull(block);
        assertEquals("[{\"x\": 1}]", block.source());
    }

    @Test
    void firstObjectArray_prefersNonEmptyOverEarlierEmpty() {
        LlmJson.Selection selection = LlmJson.firstObjectArray("выход: [] и данные [{\"a\": 1}]");

        assertEquals("[{\"a\": 1}]", selection.first().source());
        assertEquals("[]", LlmJson.firstObjectArray("выход: [] и текст [x]").first().source());
        assertTrue(LlmJson.firstObjectArray("нет массивов").isEmpty());
    }

    @Test
    void lastObjectArray_skipsUnparseableTail() {
        String text = "Ответ:\n[{\"a\": 1}, {\"a\": 2}]\nПодробности [см. выше] и [1] сноска.";

        LlmJson.Parsed block = LlmJson.select(text, LlmJson.Policy.LAST_OBJECT_ARRAY).first();

        assertNotNull(block);
        assertEquals(2, block.node().size());
        assertEquals("[]", LlmJson.select("пусто: []", LlmJson.Policy.LAST_OBJECT_ARRAY).first().source());
    }

    @Test
    void allArrays_collectsGroupOutputs() {
        List<LlmJson.Parsed> blocks = LlmJson.select(GROUPS, LlmJson.Policy.ALL_ARRAYS).blocks();

        assertEquals(2, blocks.size());
        assertEquals(1, blocks.get(0).node().size());
        assertEquals(2, blocks.get(1).node().size());
    }

    @Test
    void allObjects_areNonOverlapping() {
        List<LlmJson.Parsed> blocks = LlmJson.select("{\"a\": {\"b\": 1}} текст {\"c\": 2} {сломан}",
                LlmJson.Policy.ALL_OBJECTS).blocks();

        assertEquals(2, blocks.size());
        assertEquals("{\"a\": {\"b\": 1}}", blocks.get(0).source());
        assertEquals("{\"c\": 2}", blocks.get(1).source());
    }

    @Test
    void largestAndWholeDocument() {
        String text = "{\"a\": 1} и [{\"b\": 1}, {\"b\": 2}]";

        assertEquals("[{\"b\": 1}, {\"b\": 2}]", LlmJson.select(text, LlmJson.Policy.LARGEST).first().source());
        assertTrue(LlmJson.select(text, LlmJson.Policy.WHOLE_DOCUMENT_ONLY).isEmpty());
        assertEquals("{\"a\": 1}", LlmJson.select("  {\"a\": 1}\n", LlmJson.Policy.WHOLE_DOCUMENT_ONLY).first().source());
        assertEquals("{\"a\": 1}", LlmJson.select("```json\n{\"a\": 1}\n```", LlmJson.Policy.WHOLE_DOCUMENT_ONLY).first().source());
    }

    @Test
    void scalarsAndProse_areNotBlocks() {
        assertNull(LlmJson.first("123 объекта найдено", LlmJson.ANY).first());
        assertNull(LlmJson.first("", LlmJson.ANY).first());
        assertNull(LlmJson.first(null, LlmJson.ANY).first());
        assertTrue(LlmJson.first("{сломан", LlmJson.ANY).isEmpty());
    }

    @Test
    void bracketsInsideUnbalancedQuote_areStillFound() {
        LlmJson.Parsed block = LlmJson.first("Он сказал \"готово. [{\"a\": 1}]", LlmJson.OBJECT_ARRAY).first();

        assertNotNull(block);
        assertEquals("[{\"a\": 1}]", block.source());
    }

    @Test
    void truncatedAnswer_isParsedInLinearTime() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < 20_000; i++) {
            sb.append("{\"номер\": ").append(i).append(", \"текст\": \"значение ").append(i).append("\"},\n");
        }
        sb.append("{\"номер\": 20000, \"текст\": \"оборвано");
        String text = sb.toString();
        long start = System.nanoTime();

        LlmJson.Parsed first = LlmJson.first(text, LlmJson.OBJECT).first();
        LlmJson.Parsed last = LlmJson.last(text, LlmJson.OBJECT).first();
        List<LlmJson.Parsed> all = LlmJson.select(text, LlmJson.Policy.ALL_OBJECTS).blocks();

        long elapsedMillis = (System.nanoTime() - start) / 1_000_000;
        assertEquals(0, first.node().get("номер").asInt());
        assertEquals(19_999, last.node().get("номер").asInt());
        assertEquals(20_000, all.size());
        assertTrue(elapsedMillis < 5000, "разбор оборванного ответа занял " + elapsedMillis + " мс");
    }

    @Test
    void value_isMutableMapAndList() {
        Object value = LlmJson.first("[{\"a\": 1}]", LlmJson.ANY).first().value();

        assertTrue(value instanceof List<?>);
        @SuppressWarnings("unchecked")
        Map<String, Object> row = (Map<String, Object>) ((List<?>) value).get(0);
        row.put("b", "x");
        assertEquals("x", row.get("b"));
    }
}
