package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioOutputSupportService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertFalse;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;

/**
 * Tests for {@link ScenarioExecutorOutputNode}.
 *
 * <p>Base input-concatenation tests use the class-level {@code node} field.
 * Tests requiring {@link ScenarioOutputSupportService} inject a mock context
 * via {@link ScenarioExecutorOutputNode#setRunContext} to verify accumulation
 * and KB-save behaviour.
 */
class ScenarioExecutorOutputNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);
    private ScenarioRunNode node;

    @SuppressWarnings("unchecked")
    private final ScenarioOutputSupportService supportService = mock(ScenarioOutputSupportService.class);
    private final ScenarioRun run = mock(ScenarioRun.class);

    private static NodeDto createNode(String id, ScenarioNodeType type, String label, int x, int y) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).build())
                .position(new PositionDto(x, y))
                .build();
    }

    private static NodeDto createNodeWithMode(String id, ScenarioNodeType type, String label, String mode,
                                              int x, int y) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).mode(mode).build())
                .position(new PositionDto(x, y))
                .build();
    }

    private static NodeDto createNodeWithModeAndRules(String id, ScenarioNodeType type, String label,
                                                      String mode, String rules, int x, int y) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).mode(mode).rules(rules).build())
                .position(new PositionDto(x, y))
                .build();
    }

    @BeforeEach
    void setUp() {
        NodeDto inputNode = createNode("input-1", ScenarioNodeType.INPUT_NODE, "Input", 100, 100);
        NodeDto outputNode = createNode("output-1", ScenarioNodeType.OUTPUT_NODE, "Output", 300, 100);
        EdgeDto edge = new EdgeDto("edge-1", "input-1", "output-1", new EdgeDataDto(null));
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        var graph = new ScenarioRunGraph(graphData);
        graph.setRunnerUserId("user-1");
        node = ScenarioRunNode.fromDto(1, outputNode, graph);
    }

    // ---- base input-concatenation (original tests) ----

    @Test
    void testExecute_withNoInputs_throwsWithoutFileEvent() {
        // пустой вход — ошибка узла, а не «успешный» прогон с пустым итогом и file_ready на пустоту
        ScenarioRunNode testNode = buildNodeWithMode("TEST_EMPTY_1", "Output", "TEXT_FILE");
        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);

        ScenarioException e = assertThrows(ScenarioException.class, () -> executor.execute(sink));

        assertEquals("Выходной узел «Output»: нет данных на входе", e.getMessage());
        assertTrue(testNode.getOutput().isEmpty());
        verifyNoInteractions(sink);
    }

    @Test
    void testExecute_withBlankInputsOnly_throwsWithoutFileEvent() {
        ScenarioRunNode testNode = buildNodeWithMode("TEST_EMPTY_2", "Output", "TEXT_FILE");
        testNode.getInput().addAll(List.of("   ", "", "\n"));
        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.setRunContext(supportService, run);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));

        verifyNoInteractions(sink);
        verifyNoInteractions(supportService);
    }

    @ParameterizedTest
    @MethodSource("inputProvider")
    void testExecute_withSingleInput_returnsInput(String input, String expected) {
        node.getInput().add(input);

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        String result = executor.execute(sink);

        assertNotNull(result);
        assertEquals(expected, result);
    }

    @ParameterizedTest
    @MethodSource("multipleInputProvider")
    void testExecute_withMultipleInputs_returnsJoinedResults(List<String> inputs, String expected) {
        node.getInput().addAll(inputs);

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        String result = executor.execute(sink);

        assertNotNull(result);
        assertEquals(expected, result);
    }

    @Test
    void testExecute_storesOutputInNode() {
        node.getInput().add("Test input");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        executor.execute(sink);

        assertTrue(node.getOutput().contains("Test input"));
    }

    @Test
    void testExecute_multipleInputs_storesAllInNode() {
        node.getInput().addAll(List.of("First", "Second", "Third"));

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        executor.execute(sink);

        assertEquals(3, node.getOutput().size());
        assertTrue(node.getOutput().contains("First"));
        assertTrue(node.getOutput().contains("Second"));
        assertTrue(node.getOutput().contains("Third"));
    }

    static Stream<Arguments> inputProvider() {
        return Stream.of(
                Arguments.arguments("Input result", "Input result"),
                Arguments.arguments("  с пробелами  ", "  с пробелами  "),
                Arguments.arguments("Test text", "Test text")
        );
    }

    static Stream<Arguments> multipleInputProvider() {
        return Stream.of(
                Arguments.arguments(List.of("First result", "Second result"), "First result\n\nSecond result"),
                Arguments.arguments(List.of("A", "B", "C"), "A\n\nB\n\nC"),
                Arguments.arguments(List.of("Result A", "Result B"), "Result A\n\nResult B")
        );
    }

    // ---- SSE event emission ----

    @Test
    void testExecute_withTextMode_emitsFileOutputEvent() {
        ScenarioRunNode testNode = buildNodeWithMode("TEST_MODE_1", "Output", "TEXT_FILE");
        testNode.getInput().add("text content");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.execute(sink);

        verify(sink, times(1)).next(any(ServerSentEvent.class));
    }

    @Test
    void testExecute_withNullMode_emitsNothing() {
        ScenarioRunNode testNode = buildNodeWithMode("TEST_MODE_2", "Output", null);
        testNode.getInput().add("text content");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.execute(sink);

        // When mode is null or "all", emitFileOutputEvent returns early — no sink.next
        verifyNoInteractions(sink);
    }

    @Test
    void testExecute_withExcelMode_emitsFileOutputEvent() {
        // Excel mode triggers XLSX generation which needs valid JSON array
        ScenarioRunNode testNode = buildNodeWithMode("TEST_MODE_3", "Output", "EXCEL");
        testNode.getInput().add("[{\"key\": \"value\"}]");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.execute(sink);

        verify(sink, times(1)).next(any(ServerSentEvent.class));
    }

    @Test
    void testExecute_withExcelLabel_emitsExcelEvent() {
        // label "Excel" triggers special Excel mode even when mode is null
        ScenarioRunNode testNode = buildNodeWithMode("TEST_MODE_4", "Excel", null);
        testNode.getInput().add("[{\"key\": \"value\"}]");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.execute(sink);

        verify(sink, times(1)).next(any(ServerSentEvent.class));
    }

    private ScenarioRunNode buildNodeWithMode(String id, String label, String mode) {
        NodeDto inputNode = createNode("input-1", ScenarioNodeType.INPUT_NODE, "Input", 100, 100);
        NodeDto outputNode = createNodeWithMode(id, ScenarioNodeType.OUTPUT_NODE, label, mode, 300, 100);
        EdgeDto edge = new EdgeDto("edge-1", "input-1", id, new EdgeDataDto(null));
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        var graph = new ScenarioRunGraph(graphData);
        graph.setRunnerUserId("user-1");
        return ScenarioRunNode.fromDto(1, outputNode, graph);
    }

    // ---- setRunContext / accumulation / KB-save ----

    @Test
    void testSetRunContext_injectsSupportAndRun() {
        ScenarioRunNode testNode = buildNodeWithMode("TEST_CTX_1", "Output", "TEXT_FILE");
        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.setRunContext(supportService, run);

        testNode.getInput().add("content");

        // configure mocks — accumulate returns result unchanged (accumulation is off by default)
        when(supportService.accumulateIfConfigured(any(ScenarioRun.class), any(ScenarioRunNode.class), anyString()))
                .thenAnswer(inv -> inv.getArgument(2));

        executor.execute(sink);

        verify(supportService, times(1)).accumulateIfConfigured(eq(run), eq(testNode), anyString());
    }

    @Test
    void testExecute_withRunContext_accumulatesResult() {
        ScenarioRunNode testNode = buildNodeWithMode("TEST_CTX_2", "Output", "TEXT_FILE");
        testNode.getInput().add("current content");

        when(supportService.accumulateIfConfigured(any(ScenarioRun.class), any(ScenarioRunNode.class), anyString()))
                .thenReturn("previous + current merged");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.setRunContext(supportService, run);

        String result = executor.execute(sink);

        assertEquals("previous + current merged", result);
    }

    @Test
    void testExecute_withRunContext_savesToKnowledgeBase() {
        ScenarioRunNode testNode = buildNodeWithModeAndRules("TEST_CTX_3", "Output", "TEXT_FILE",
                "{\"в_базу_знаний\": \"123e4567-e89b-12d3-a456-426614174000\"}");
        testNode.getInput().add("content");

        // accumulate returns result unchanged (no accumulation configured)
        when(supportService.accumulateIfConfigured(any(ScenarioRun.class), any(ScenarioRunNode.class), anyString()))
                .thenAnswer(inv -> inv.getArgument(2));

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.setRunContext(supportService, run);
        executor.execute(sink);

        verify(supportService, times(1))
                .saveToKnowledgeBaseIfConfigured(eq(run), eq(testNode), anyString());
    }

    @Test
    void testExecute_withRunContext_accumulateThenEmitThenSave() {
        ScenarioRunNode testNode = buildNodeWithModeAndRules("TEST_CTX_4", "Output", "TEXT_FILE",
                "{\"в_базу_знаний\": \"123e4567-e89b-12d3-a456-426614174000\"}");
        testNode.getInput().add("content");

        when(supportService.accumulateIfConfigured(any(ScenarioRun.class), any(ScenarioRunNode.class), anyString()))
                .thenReturn("accumulated result");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.setRunContext(supportService, run);

        String result = executor.execute(sink);

        assertEquals("accumulated result", result);
        verify(supportService, times(1)).accumulateIfConfigured(any(), any(), any());
        verify(supportService, times(1)).saveToKnowledgeBaseIfConfigured(any(), any(), any());
        verify(sink, times(1)).next(any(ServerSentEvent.class));
    }

    @Test
    void testExecute_withoutRunContext_ignoresSupport() {
        ScenarioRunNode testNode = buildNodeWithMode("TEST_CTX_5", "Output", "TEXT_FILE");
        testNode.getInput().add("content");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        // NOT calling setRunContext — context is null
        executor.execute(sink);

        // accumulation and KB-save should never be called
        verifyNoInteractions(supportService);
    }

    @Test
    void testExecute_withNullRunContext_doesNotThrow() {
        ScenarioRunNode testNode = buildNodeWithMode("TEST_CTX_6", "Output", "TEXT_FILE");
        testNode.getInput().add("content");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        // setRunContext with null service and null run
        executor.setRunContext(null, null);

        // should not NPE — the null checks in execute() prevent it
        String result = executor.execute(sink);
        assertNotNull(result);
    }

    @Test
    void testExecute_withEmptyRunId_doesNotCrash() {
        ScenarioRunNode testNode = buildNodeWithModeAndRules("TEST_CTX_7", "Output", "TEXT_FILE",
                "{\"в_базу_знаний\": \"00000000-0000-0000-0000-000000000000\"}");
        testNode.getInput().add("data");

        when(run.getScenarioId()).thenReturn(UUID.randomUUID());
        when(run.getId()).thenReturn(UUID.randomUUID());
        when(supportService.accumulateIfConfigured(any(), any(), anyString())).thenReturn("result");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.setRunContext(supportService, run);
        executor.execute(sink);

        // Should not throw — accumulateIfConfigured handles it gracefully
        verify(supportService, times(1)).accumulateIfConfigured(any(), any(), anyString());
    }

    @Test
    void testExecute_inputContainsNewlines_joinsWithDoubleNewline() {
        node.getInput().add("line1");
        node.getInput().add("line2\nwith\nnewlines");

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(node);
        String result = executor.execute(sink);

        assertEquals("line1\n\nline2\nwith\nnewlines", result);
    }

    @Test
    void testExecute_resultUsedForSseAndKbSave() {
        ScenarioRunNode testNode = buildNodeWithModeAndRules("TEST_CTX_8", "Output", "TEXT_FILE",
                "{\"в_базу_знаний\": \"123e4567-e89b-12d3-a456-426614174000\"}");
        testNode.getInput().add("test data");

        when(run.getScenarioId()).thenReturn(UUID.randomUUID());
        when(run.getId()).thenReturn(UUID.randomUUID());
        when(supportService.accumulateIfConfigured(any(), any(), anyString()))
                .thenAnswer(inv -> inv.getArgument(2));

        ScenarioExecutorOutputNode executor = new ScenarioExecutorOutputNode(testNode);
        executor.setRunContext(supportService, run);
        executor.execute(sink);

        // accumulateIfConfigured should receive the joined input as result
        verify(supportService).accumulateIfConfigured(any(), any(), eq("test data"));
        // saveToKnowledgeBaseIfConfigured should receive the accumulated result
        verify(supportService).saveToKnowledgeBaseIfConfigured(any(), any(), eq("test data"));
    }

    private ScenarioRunNode buildNodeWithModeAndRules(String id, String label, String mode, String rules) {
        NodeDto inputNode = createNode("input-1", ScenarioNodeType.INPUT_NODE, "Input", 100, 100);
        NodeDto outputNode = createNodeWithModeAndRules(id, ScenarioNodeType.OUTPUT_NODE, label, mode, rules, 300, 100);
        EdgeDto edge = new EdgeDto("edge-1", "input-1", id, new EdgeDataDto(null));
        GraphDataDto graphData = new GraphDataDto(List.of(inputNode, outputNode), List.of(edge));

        var graph = new ScenarioRunGraph(graphData);
        graph.setRunnerUserId("user-1");
        return ScenarioRunNode.fromDto(1, outputNode, graph);
    }

    // ---- ошибки узлов во входе (on_error=continue/branch) ----

    @Test
    void testExecute_inputWithNodeErrors_resultStartsWithWarningListingNodes() {
        node.getInput().add("=== РЕЗУЛЬТАТ ОТ \"Анализ\" (ОШИБКА) ===\n"
                + ScenarioEngine.NODE_ERROR_PREFIX + "Анализ»: GigaChat недоступен]");
        node.getInput().add("=== РЕЗУЛЬТАТ ОТ \"Сводка\" ===\n[{\"а\": 1}]");
        node.getInput().add(ScenarioEngine.NODE_ERROR_PREFIX + "Расчёт»: нет данных]");

        String result = new ScenarioExecutorOutputNode(node).execute(sink);

        assertTrue(result.startsWith("⚠ В итог вошли ошибки узлов: Анализ, Расчёт\n\n"), result);
        assertTrue(result.contains("[{\"а\": 1}]"));
        // сами входы (для {{output:...}} и последующих узлов) без пометки
        assertEquals(3, node.getOutput().size());
        assertFalse(node.getOutput().get(0).startsWith("⚠"));
    }

    @Test
    void testExecute_inputWithoutNodeErrors_noWarning() {
        node.getInput().add("обычный результат с квадратными скобками [1]");

        String result = new ScenarioExecutorOutputNode(node).execute(sink);

        assertEquals("обычный результат с квадратными скобками [1]", result);
    }
}
