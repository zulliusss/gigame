package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.service.scenario.executor.PriceCheck.Verdict;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты сверки цены (валюта, «не более») и риска выхода срока поставки за срок действия договора.
 */
class PriceTermOpsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static JsonNode json(String text) throws Exception {
        return MAPPER.readTree(text);
    }

    @Test
    void capPriceAcceptsLowerContractPrice() throws Exception {
        // письмо Комягина, п. 6: в ПЗ «не более 100 000,00 руб.», в договоре 99 500,00 руб. — не расхождение
        Verdict ok = PriceCheck.check(json("{\"сумма\": \"99 500,00\", \"валюта\": \"руб.\"}"),
                json("{\"цена_победителя\": 100000, \"валюта\": \"RUB\", \"условие_цены\": \"не более\"}"));
        assertEquals("СООТВЕТСТВУЕТ", ok.status(), ok.text());

        Verdict higher = PriceCheck.check(json("{\"сумма\": 100500}"), json("{\"цена_победителя\": \"100 000,00\", \"условие_цены\": \"не более\"}"));
        assertEquals("РАСХОЖДЕНИЕ", higher.status());
        assertTrue(higher.text().endsWith("выше предельной на 500.00"), higher.text());

        Verdict exact = PriceCheck.check(json("{\"сумма_руб\": \"4398686.34\"}"), json("{\"цена_победителя\": \"4 398 686,34\", \"условие_цены\": \"точная\"}"));
        assertEquals("СОВПАДАЕТ", exact.status());
        assertEquals("РАСХОЖДЕНИЕ", PriceCheck.check(json("{\"сумма\": 99500}"), json("{\"цена_победителя\": 100000}")).status());
    }

    @Test
    void differentCurrenciesAreNotComparedAsNumbers() throws Exception {
        // п. 5: в протоколе сначала цена в долларах
        Verdict unclear = PriceCheck.check(json("{\"сумма\": 950000, \"валюта\": \"RUB\"}"), json("{\"цена_победителя\": 10000, \"валюта\": \"USD\"}"));
        assertEquals("ТРЕБУЕТ УТОЧНЕНИЯ", unclear.status());
        assertTrue(unclear.text().contains("валюты различаются: протокол 10000.00 USD, договор 950000.00 RUB"), unclear.text());

        Verdict rubles = PriceCheck.check(json("{\"сумма\": 950000, \"валюта\": \"RUB\"}"),
                json("{\"цена_победителя\": 10000, \"валюта\": \"USD\", \"цены_все\": \"10 000 USD; 950 000,00 руб.\"}"));
        assertEquals("СОВПАДАЕТ", rubles.status(), rubles.text());
        assertEquals("НЕТ ДАННЫХ", PriceCheck.check(json("{\"сумма\": \"не указано\"}"), json("{\"цена_победителя\": 1}")).status());
        assertEquals("EUR", PriceCheck.currency("евро"));
        assertEquals("KZT", PriceCheck.currency("kzt"));
        assertNull(PriceCheck.amount(json("{}").path("нет")));
    }

    @Test
    void deliveryAfterContractEndIsRisk() throws Exception {
        // п. 7: протокол 01.09.2026, поставка 60 календарных дней, договор действует до 15.10.2026
        JsonNode contract = json("{\"дата_договора\": \"«__» ______ 2026\", \"срок_поставки_число\": 60, \"срок_поставки_единица\": \"календарных дней\", "
                + "\"срок_поставки_отсчёт\": \"с даты подписания договора\", \"срок_действия_до\": \"15.10.2026\"}");
        Verdict risk = DeliveryTermCheck.check(contract, json("{\"дата_протокола\": \"01.09.2026\"}"));

        assertEquals("РИСК", risk.status());
        assertEquals("начало отсчёта 01.09.2026 (дата протокола — дата договора не заполнена); поставка до 31.10.2026; договор действует до 15.10.2026"
                + " — поставка может завершиться на 16 дн. позже окончания срока действия договора", risk.text());
    }

    @Test
    void workingDaysMonthsAndMissingTerm() throws Exception {
        assertEquals(LocalDate.of(2026, 9, 14), DeliveryTermCheck.plusWorkingDays(LocalDate.of(2026, 9, 4), 6));
        JsonNode contract = json("{\"дата_договора\": \"04.09.2026\", \"срок_поставки_число\": \"30\", \"срок_поставки_единица\": \"рабочих дней\", "
                + "\"срок_поставки_отсчёт\": \"с даты согласования чертежей\", \"срок_действия_месяцев\": 12}");
        Verdict none = DeliveryTermCheck.check(contract, null);
        assertEquals("НЕТ РИСКА", none.status());
        assertTrue(none.text().contains("поставка до 16.10.2026; договор действует до 04.09.2027; срок поставки отсчитывается от события «с даты согласования чертежей»"), none.text());

        Verdict open = DeliveryTermCheck.check(json("{\"дата_договора\": \"04.09.2026\", \"срок_поставки_число\": 5, \"срок_действия_до\": \"до полного исполнения\"}"), null);
        assertEquals("НЕ ОЦЕНИВАЕТСЯ", open.status());
        assertEquals("НЕ ОЦЕНИВАЕТСЯ", DeliveryTermCheck.check(json("{}"), null).status());
        assertEquals("НЕ ОЦЕНИВАЕТСЯ", DeliveryTermCheck.check(json("{\"дата_договора\": \"04.09.2026\", \"срок_действия_месяцев\": 12}"), null).status());
        // модель пишет числа строками: «-1» — срок действия не ограничен, а не 1 месяц (ложный РИСК на комплекте 2 письма Комягина)
        Verdict unlimited = DeliveryTermCheck.check(json("{\"дата_договора\": \"04.09.2026\", \"срок_поставки_число\": \"30\", "
                + "\"срок_поставки_единица\": \"рабочих дней\", \"срок_действия_до\": \"не указано\", \"срок_действия_месяцев\": \"-1\"}"), null);
        assertEquals("НЕ ОЦЕНИВАЕТСЯ", unlimited.status(), unlimited.text());
        assertEquals(-1.0, PriceCheck.amount(json("{\"x\": \"-1\"}").path("x")));
    }

    @Test
    void reportReadsModelJsonAndSelectsLotByInn() {
        String text = "=== РЕЗУЛЬТАТ ОТ \"Условия договора\" ===\n```json\n{\"тип_документа\": \"договор\", \"ИНН_поставщика\": \"7724489090\", \"сумма\": \"499999.00\", "
                + "\"валюта\": \"RUB\", \"дата_договора\": \"не указано\", \"срок_поставки_число\": 30, \"срок_поставки_единица\": \"рабочих дней\", "
                + "\"срок_действия_до\": \"не указано\", \"срок_действия_месяцев\": -1}\n```\n"
                + "=== РЕЗУЛЬТАТ ОТ \"Данные протокола\" === {\"тип_документа\": \"протокол\", \"дата_протокола\": \"21.07.2026\", \"лоты\": ["
                + "{\"номер\": 1, \"ИНН_победителя\": \"1111111111\", \"цена_победителя\": 499999}, "
                + "{\"номер\": 2, \"ИНН_победителя\": \"7724489090\", \"цена_победителя\": \"499 999,00\", \"валюта\": \"руб.\", \"условие_цены\": \"точная\"}]}";

        String report = PriceTermOps.check(text);

        assertTrue(report.contains("Цена (лот 2): СОВПАДАЕТ — протокол 499999.00 RUB, договор 499999.00 RUB"), report);
        assertTrue(report.contains("Срок поставки и срок действия договора: НЕ ОЦЕНИВАЕТСЯ — срок действия договора не ограничен"), report);
        assertTrue(report.endsWith("{\"цена\": \"СОВПАДАЕТ\", \"риск_сроков\": \"НЕ ОЦЕНИВАЕТСЯ\"}"), report);
        assertTrue(PriceTermOps.check("нет JSON").contains("JSON условий договора не найден"));
    }

    @Test
    void lotSelectionFallsBackToNumberAndClosestPrice() throws Exception {
        JsonNode protocol = json("{\"лоты\": [{\"номер\": \"1\", \"цена_победителя\": 100}, {\"номер\": \"2\", \"цена_победителя\": 205}, {\"номер\": \"3\", \"цена_победителя\": 300}]}");

        assertEquals("3", PriceTermOps.selectLot(protocol, json("{\"лот\": \"Лот №3\"}")).path("номер").asText());
        assertEquals("2", PriceTermOps.selectLot(protocol, json("{\"сумма\": 199}")).path("номер").asText());
        assertNull(PriceTermOps.selectLot(json("{\"лоты\": []}"), json("{}")));
        assertNull(PriceTermOps.selectLot(null, json("{}")));
        assertEquals(2, JsonBlocks.objects("{\"a\": \"}{\"} текст {\"b\": {\"c\": 1}} {битый").size());
    }

    @Test
    void jsonBlocksFixDecimalCommaInsteadOfSkippingObject() {
        // «"сумма": 1234567,89» раньше делал объект нечитаемым → «JSON условий договора не найден»
        var objects = JsonBlocks.objects("{\"тип_документа\": \"договор\", \"сумма\": 1234567,89, \"список\": [1,2,3]}");

        assertEquals(1, objects.size());
        assertEquals(1234567.89, objects.get(0).get("сумма").asDouble(), 1e-9);
        assertEquals(3, objects.get(0).get("список").size());
        assertEquals("договор", JsonBlocks.byDocumentType("{\"тип_документа\": \"Договор\", \"сумма\": 1,5}", "договор")
                .get("тип_документа").asText().toLowerCase());
    }
}
