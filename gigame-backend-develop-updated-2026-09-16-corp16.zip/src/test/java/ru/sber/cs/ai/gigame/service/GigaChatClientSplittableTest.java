package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.metadata.ChatGenerationMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Деление промпта узла при 422 «context too long»: делится только контекст,
 * инструкция повторяется в каждой части, ответы помечаются «Часть k/N», в
 * журнал прогона уходит уведомление, JSON-массивы частей объединяются;
 * усечённые ответы получают маркер.
 */
@ExtendWith(MockitoExtension.class)
class GigaChatClientSplittableTest {

    private static final String INSTRUCTION = "Извлеки строки актов в JSON-массив.";
    private static final String TOO_LONG = "HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 190108\"}";

    @Mock
    private ChatModel chatModel;
    @Mock
    private EmbeddingModel embeddingModel;

    private GigaChatClient client;
    private final List<String> notices = new ArrayList<>();
    private final List<String> sentTexts = new ArrayList<>();

    @BeforeEach
    void setUp() {
        client = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 1);
        ReflectionTestUtils.setField(client, "retryDelayMillis", 1L);
        ReflectionTestUtils.setField(client, "callHardTimeoutSeconds", 0L);
        GigaChatClient.setRunWaitNotice(notices::add);
    }

    @AfterEach
    void tearDown() {
        GigaChatClient.clearRunWaitNotice();
    }

    private static ChatResponse response(String text, String finishReason) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(text),
                ChatGenerationMetadata.builder().finishReason(finishReason).build())));
    }

    private static String context(int docs) {
        StringBuilder sb = new StringBuilder("Документы:\nГруппа документов: 1");
        for (int i = 1; i <= docs; i++) {
            sb.append("\n\n<<<Документ: акт").append(i).append(".pdf>>>\n")
                    .append("строка акта ".repeat(400)).append("\n<<<КОНЕЦ ДОКУМЕНТА>>>");
        }
        return sb.toString();
    }

    /** Модель: первый запрос — «context too long», далее ответы по очереди; тексты запросов запоминаются. */
    private void modelFailsFirstThenAnswers(String... answers) {
        int[] call = {0};
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            Prompt prompt = inv.getArgument(0);
            String text = ((UserMessage) prompt.getInstructions().get(prompt.getInstructions().size() - 1)).getText();
            sentTexts.add(text);
            if (call[0]++ == 0) {
                throw new RuntimeException(TOO_LONG);
            }
            return response(answers[Math.min(call[0] - 2, answers.length - 1)], "stop");
        });
    }

    @Test
    void splitsContextByDocumentBoundaryRepeatingInstructionAndMarksParts() {
        modelFailsFirstThenAnswers("ответ по акту 1", "ответ по акту 2");

        var result = client.chatCompletionSplittable(INSTRUCTION, context(2), null, null, false);

        assertEquals(3, sentTexts.size());
        // первый запрос — без служебных маркеров
        assertFalse(sentTexts.get(0).contains(GigaChatClient.SPLIT_BOUNDARY));
        assertEquals(INSTRUCTION + "\n\n" + context(2), sentTexts.get(0));
        // обе части начинаются с инструкции и режутся по границе документа
        assertTrue(sentTexts.get(1).startsWith(INSTRUCTION + "\n\nДокументы:"));
        assertTrue(sentTexts.get(1).contains("акт1.pdf"));
        assertFalse(sentTexts.get(1).contains("акт2.pdf"));
        assertTrue(sentTexts.get(2).startsWith(INSTRUCTION + "\n\n<<<Документ: акт2.pdf>>>"));
        assertEquals("=== Часть 1/2 (запрос разделён из-за лимита контекста) ===\nответ по акту 1\n\n"
                + "=== Часть 2/2 (запрос разделён из-за лимита контекста) ===\nответ по акту 2", result.text());
        assertEquals(1, notices.size());
        assertTrue(notices.get(0).contains("разделён на 2 частей"));
    }

    @Test
    void splitHappensThroughPlainChatCompletionWhenPromptCarriesBoundary() {
        // промпт узла собирает AbstractScenarioExecutor.buildPrompt с невидимой границей;
        // узлы зовут обычный chatCompletion — деление срабатывает и там
        modelFailsFirstThenAnswers("часть А", "часть Б");
        String prompt = GigaChatClient.splittableContent(INSTRUCTION, context(2), false);

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", prompt)), null, null);

        assertTrue(text.startsWith("=== Часть 1/2"));
        assertTrue(text.contains("часть А"));
        assertTrue(text.contains("=== Часть 2/2"));
        assertTrue(sentTexts.get(2).startsWith(INSTRUCTION));
    }

    @Test
    void mergesJsonArraysOfPartsForArrayContract() {
        modelFailsFirstThenAnswers("Вот строки:\n[{\"акт\": 1}]", "[{\"акт\": 2}, {\"акт\": 3}]");

        var result = client.chatCompletionSplittable(INSTRUCTION, context(2), null, null, true);

        assertTrue(result.text().startsWith("=== Ответ собран из 2 частей"));
        assertTrue(result.text().contains("JSON-массивы частей объединены"));
        assertEquals(3, PromptSplitter.jsonArray(result.text()).size());
        assertTrue(notices.get(0).contains("JSON-массивы частей объединены"));
        assertFalse(sentTexts.get(1).contains(GigaChatClient.MERGE_ARRAYS_HINT));
    }

    @Test
    void shortContextIsNotSplitAndErrorIsRethrown() {
        when(chatModel.call(any(Prompt.class))).thenThrow(new RuntimeException(TOO_LONG));

        try {
            client.chatCompletionSplittable(INSTRUCTION, "короткий контекст", null, null, false);
        } catch (RuntimeException e) {
            assertTrue(e.getMessage().contains("context too long") || e.getCause() != null);
        }
        assertTrue(notices.isEmpty());
    }

    @Test
    void answerStillTruncatedAfterAllContinuationsGetsMarkerAndNotice() {
        when(chatModel.call(any(Prompt.class))).thenReturn(response("кусок ", "length"));

        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", "вопрос")), null, null);

        assertTrue(text.endsWith("\n" + GigaChatClient.TRUNCATED_MARKER));
        assertEquals("кусок ".repeat(GigaChatClient.MAX_CONTINUATIONS + 1) + "\n" + GigaChatClient.TRUNCATED_MARKER, text);
        assertEquals(1, notices.size());
        assertTrue(notices.get(0).contains("усечён по лимиту длины"));
    }

    @Test
    void agentFinalAnswerWithoutToolCallsIsContinuedWhenCutByLength() {
        when(chatModel.call(any(Prompt.class)))
                .thenReturn(response("[{\"поле\": 1},", "length"))
                .thenReturn(response(" {\"поле\": 2}]", "stop"));
        ToolCallback tool = new ToolCallback() {
            @Override
            public ToolDefinition getToolDefinition() {
                return ToolDefinition.builder().name("noop").description("ничего").inputSchema("{}").build();
            }

            @Override
            public String call(String toolInput) {
                return "{}";
            }
        };

        var result = client.chatCompletionWithTools(List.of(Map.of("role", "user", "content", "задание")),
                List.of(tool), null, null);

        assertEquals("[{\"поле\": 1}, {\"поле\": 2}]", result.text());
        assertTrue(notices.isEmpty());
    }

    @Test
    void attachmentAnswerCutByMaxTokensGetsMarker() {
        when(chatModel.call(any(Prompt.class))).thenReturn(response("страница 1 текст", "length"));

        var result = client.chatCompletionWithFile("выпиши", "page-1.pdf", new byte[]{1}, "application/pdf", null, null, 100);

        assertEquals("страница 1 текст\n" + GigaChatClient.TRUNCATED_MARKER, result.text());
    }

    @Test
    void cutPointPrefersDocumentBoundaryThenParagraphs() {
        String twoDocs = context(2);
        int cut = PromptSplitter.cutPoint(twoDocs);
        assertTrue(twoDocs.startsWith("\n\n<<<Документ: акт2.pdf>>>", cut));

        String paragraphs = "a".repeat(1000) + "\n\n" + "b".repeat(1000);
        assertEquals(1000, PromptSplitter.cutPoint(paragraphs));
        assertEquals(500, PromptSplitter.cutPoint("c".repeat(1000)));
    }

    @Test
    void stripSplitMarkersRemovesInvisibleMarkersOnly() {
        String content = GigaChatClient.splittableContent("инструкция", "контекст", true);
        assertTrue(content.contains(GigaChatClient.SPLIT_BOUNDARY));
        assertTrue(content.endsWith(GigaChatClient.MERGE_ARRAYS_HINT));
        assertEquals("инструкция\n\nконтекст", GigaChatClient.stripSplitMarkers(content));
        assertEquals("инструкция", GigaChatClient.splittableContent("инструкция", "", true));
    }
}
