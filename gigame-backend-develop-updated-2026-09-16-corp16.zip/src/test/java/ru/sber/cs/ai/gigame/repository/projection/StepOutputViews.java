package ru.sber.cs.ai.gigame.repository.projection;

import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import java.util.Map;

/**
 * Проекции шагов для тестов: репозиторий в тестах замокан, проекция строится из шага.
 */
public final class StepOutputViews {

    private StepOutputViews() {
    }

    /**
     * Проекция из шага прогона.
     *
     * @param step шаг
     * @return проекция (nodeId, nodeType, outputData)
     */
    public static StepOutputView of(ScenarioRunStep step) {
        return of(step.getNodeId(), step.getNodeType(), step.getOutputData());
    }

    /**
     * Проекция из полей.
     *
     * @param nodeId     идентификатор узла
     * @param nodeType   тип узла
     * @param outputData выходные данные
     * @return проекция
     */
    public static StepOutputView of(String nodeId, String nodeType, Map<String, String> outputData) {
        return new StepOutputView() {
            @Override
            public String getNodeId() {
                return nodeId;
            }

            @Override
            public String getNodeType() {
                return nodeType;
            }

            @Override
            public Map<String, String> getOutputData() {
                return outputData;
            }
        };
    }
}
