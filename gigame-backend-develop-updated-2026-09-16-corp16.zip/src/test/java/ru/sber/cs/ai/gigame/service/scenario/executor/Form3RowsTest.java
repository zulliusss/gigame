package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты правил зачёта Формы 3: технологии по типам документов, мобильная
 * разработка, только тестирование, рейтинг заказчика, период методики.
 */
class Form3RowsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final String CONTRACT = """
            ДОГОВОР № 4652269 на разработку/модификацию программного обеспечения
            Дата подписания: 05.07.2023
            Исполнитель выполняет работы с использованием технологий Java, Python и методологии DevOps.
            """;

    private static final String REPORT = """
            ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ к ЗНЗО № 100000039435 от 10.06.2025
            Договор № 4652269 от 05.07.2023
            Выполнена разработка сервисов на Go (Golang). Сумма 1063178,54
            """;

    private static final String UPD_WITH_ZNZO = Form3OpsTest.UPD_SIGNED
            + "Наименование: работы по ЗНЗО № 100000039435 от 10.06.2025\n";

    private static final String SPEC_TESTING = """
            Спецификация на оказание услуг № 5374642 к Договору №4652269
            1. Предмет Спецификации: Исполнитель оказывает услуги по функциональному и регрессионному тестированию ППО «Карты».
            Стоимость 1063178,54 Подпись банка 26.06.2025 17:37:40
            """;

    private static final String SPEC_MOBILE = """
            Спецификация на разработку программного обеспечения № 5374642 к Договору №4652269
            1. Предмет Спецификации: Исполнитель выполняет работы по разработке мобильного приложения СберБанк Онлайн (iOS, Android) на Java.
            Стоимость 1063178,54 Подпись банка 26.06.2025 17:37:40
            """;

    private static final String FORM_LINE = "ООО \"Датафьюжн\" | ООО \"Датафьюжн\" | не применимо | нет | ПАО Сбербанк | не применимо"
            + " | ПАО Сбербанк | 4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025"
            + " | 30.06.2025 | да | нет | 2495000 | не применимо | не применимо | Раздел 5";

    private static Map<?, ?> firstRow(String criteria, Form3Ops.Source... sources) throws Exception {
        String registry = Form3Ops.registry(List.of(sources));
        return (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria), List.class).get(0);
    }

    @Test
    void technologiesAreLocatedInContractAndReportLinkedByLongNumber() throws Exception {
        // спецификации нет: договор найден по номеру, отчёт — по общему номеру ЗНЗО с УПД
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", UPD_WITH_ZNZO),
                new Form3Ops.Source("Договор.pdf", CONTRACT), new Form3Ops.Source("Отчет.pdf", REPORT));

        // Java и Python подтверждены договором (к16), Go — отчётом: договор доказателен
        assertEquals("не сопоставлена", row.get("к5"));
        assertEquals("да", row.get("т_Java"));
        assertEquals("да", row.get("т_Go (Golang)"));
        assertEquals("да", row.get("т_Python"));
        assertEquals("да: Java, Python", row.get("к16"));
        assertEquals("нет", row.get("к17"));
        assertEquals("нет", row.get("к18"));
        assertEquals("да: Go (Golang)", row.get("к19"));
        assertEquals("1063178.54", row.get("к14"));
        assertEquals("-", row.get("к15"));
        assertTrue(String.valueOf(row.get("к20")).contains("договор 1, спецификаций 0, отчётов 1"));
    }

    @Test
    void testingOnlySpecificationBlocksCredit() throws Exception {
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_TESTING));

        assertEquals("да", row.get("к13"));
        assertEquals("0", row.get("к14"));
        assertEquals("технология не найдена; только услуги по тестированию", row.get("к15"));
    }

    @Test
    void mobileDevelopmentBlocksCreditUnlessProcurementIsMobile() throws Exception {
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_MOBILE));
        assertEquals("да", row.get("к12"));
        assertEquals("мобильная разработка", row.get("к15"));

        String mobileCriteria = Form3OpsTest.CRITERIA.replace(
                "стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        Map<?, ?> allowed = firstRow(mobileCriteria, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_MOBILE));
        assertEquals("-", allowed.get("к15"));
        assertTrue(String.valueOf(allowed.get("к20")).contains("не стоп-фактор"));

        // мобильная закупка, а в документах строки мобильной разработки нет — не засчитывается
        Map<?, ?> noMobile = firstRow(mobileCriteria, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", Form3OpsTest.SPEC_A));
        assertEquals("нет", noMobile.get("к12"));
        assertEquals("нет мобильной разработки", noMobile.get("к15"));
    }

    @Test
    void customerOutsideRatingAndActOutsidePeriodAreListedAsReasons() throws Exception {
        String upd = Form3OpsTest.UPD_SIGNED.replace("ПАО Сбербанк", "ООО \"Ромашка\"")
                .replace("\" 24 \" июля 2025", "\" 24 \" июля 2024");
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", upd),
                new Form3Ops.Source("Спецификация № 5374642.pdf", Form3OpsTest.SPEC_A));

        // заказчик не в рейтинге — стоп-фактор: остальные проверки не выполняются (прочерк), причина одна
        assertEquals("нет", row.get("к11"));
        assertEquals("-", row.get("к8"));
        assertEquals("-", row.get("к9"));
        assertEquals("-", row.get("т_Java"));
        assertEquals("Заказчик не в рейтинге", row.get("к15"));
        assertEquals("0", row.get("к14"));
    }

    private static List<Map<?, ?>> formRows(String registry, String form) throws Exception {
        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form, Form3FormTest.HEADER),
                List.class);
        return rows.stream().<Map<?, ?>>map(r -> (Map<?, ?>) r).toList();
    }

    @Test
    void formRowWithoutDocumentsGetsVerdictFromFormData() throws Exception {
        // форма первична: акт без документов в комплекте получает периоды, рейтинг и причину, а не пропадает
        Map<?, ?> row = formRows(Form3Ops.registry(List.of()), FORM_LINE).get(0);

        assertEquals("ПАО Сбербанк", row.get("к3"));
        assertEquals("Акт №7 выполненных работ от 30.06.2025", row.get("к6"));
        assertEquals("30.06.2025", row.get("к7"));
        assertEquals("да", row.get("к8"));
        assertEquals("да", row.get("к9"));
        assertEquals("2495000.00", row.get("к10"));
        assertEquals("да", row.get("к11"));
        assertEquals("0", row.get("к14"));
        assertEquals("Подтверждающие документы не найдены; технология не найдена", row.get("к15"));
        assertEquals("нет", row.get("т_Java"));
        assertTrue(String.valueOf(row.get("к20")).contains("заявлено участником в форме, документами не подтверждено: Java"));
        assertEquals(FORM_LINE, row.get("исходная_строка"));
    }

    @Test
    void formRowIsLinkedToAcceptanceActBySpecificationNumberAndDate() throws Exception {
        // акт Сбера без структуры УПД: найден по дате акта из формы и номеру спецификации, технологии — из акта
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("4787401 Акт Э2.docx", Form3ActsTest.SBER_ACT),
                new Form3Ops.Source("4787401 Акт Э1.docx", Form3ActsTest.SBER_ACT.replace("«08» апреля 2025", "«10» января 2025"))));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String line = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                "Договор №4286515 от 09.09.2022 | Спецификация №4787401 от 17.11.2023 | Акт от 08.04.2025 | 08.04.2025")
                .replace("2495000", "1712787");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("Акт от 08.04.2025", row.get("к6"));
        assertEquals("08.04.2025", row.get("к7"));
        assertEquals("1712787.00", row.get("к10"));
        assertEquals("ПАО Сбербанк", row.get("к3"));
        assertEquals("да", row.get("т_Android"));
        assertEquals("да: Android", row.get("к18"));
        assertEquals("-", row.get("к15"));
        assertTrue(String.valueOf(row.get("к20")).contains("акт «4787401 Акт Э2.docx»"));
        assertTrue(String.valueOf(row.get("к20")).contains("штампом ЭДО не подтверждена"));
    }

    @Test
    void exactMatchesAreResolvedBeforeFallbacksAndFormDateDrivesPeriod() throws Exception {
        // два акта одной спецификации: первая строка (по номеру и сумме, дата в форме иная) не должна забирать акт второй строки,
        // который совпадает с ней по дате; у УПД дата периода — заявленная в форме (дата УПД), а не дата приёмки
        String actOctober = Form3ActsTest.SBER_ACT.replace("«08» апреля 2025", "«05» октября 2025").replace("1 712 787,00", "2 729 995,22");
        String actDecember = Form3ActsTest.SBER_ACT.replace("«08» апреля 2025", "«20» декабря 2025");
        String upd = Form3OpsTest.UPD_SIGNED.replace("21.07.2025", "24.03.2025").replace("\" 24 \" июля 2025", "\" 26 \" марта 2025");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Акт Э2.docx", actOctober),
                new Form3Ops.Source("Акт Э3.docx", actDecember), new Form3Ops.Source("upd.pdf", upd)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String base = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо", "Договор №4286515 от 09.09.2022 | Спецификация №4787401 от 17.11.2023");
        String form = base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт от 01.10.2025 | 01.10.2025").replace("2495000", "2729995,22")
                + "\n" + base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт от 20.12.2025 | 20.12.2025").replace("2495000", "1712787")
                + "\n" + base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "УПД 118724 от 24.03.2025 | 24.03.2025").replace("2495000", "1063178,54");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, form, Form3FormTest.HEADER), List.class);

        assertEquals("Акт от 05.10.2025", ((Map<?, ?>) rows.get(0)).get("к6"));
        assertEquals("Акт от 20.12.2025", ((Map<?, ?>) rows.get(1)).get("к6"));
        assertEquals("24.03.2025", ((Map<?, ?>) rows.get(2)).get("к7"));
        assertEquals("нет", ((Map<?, ?>) rows.get(2)).get("к9"));
    }

    @Test
    void partialClaimOfUpdTakesFormAmountWithNote() throws Exception {
        // участник заявляет часть УПД (профильные позиции): сумма формы меньше итога — берётся сумма формы
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("УПД №970 от 23.12.25.pdf",
                Form3OpsTest.UPD_SIGNED.replace("0000118724", "970").replace("21.07.2025", "23.12.2025"))));
        String line = FORM_LINE.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "УПД от 23.12.2025 №970 | 24.07.2025")
                .replace("2495000", "288640");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals("УПД 970 от 23.12.2025", row.get("к6"));
        assertEquals("288640.00", row.get("к10"));
        assertTrue(String.valueOf(row.get("к20")).contains("сумма по форме участника 288640.00 (итог УПД 1063178.54)"));
    }

    @Test
    void scannedActTakesAmountFromFormWithNote() throws Exception {
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf",
                Form3ActsTest.ALFA_ACT_OCR.replace("22 849 905,00", "6 961 205,00"))));
        String line = FORM_LINE.replace("ПАО Сбербанк", "АО «АЛЬФА-БАНК»")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "Договор №АБ-С-ИТ-2020 от 03.02.2020 | Заявка 104 от 15.04.2024 | Акт от 27.04.2024 | 27.04.2024")
                .replace("2495000", "22849905");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals("22849905.00", row.get("к10"));
        assertTrue(String.valueOf(row.get("к20")).contains("в распознанном скане акта не найдена, скан даёт 6961205.00"));
    }

    @Test
    void actRowTakesTechnologiesFromOrderAndAct() throws Exception {
        // заявка упоминает iOS, акт — Android: оба документа доказательны
        String order = "[РАСПОЗНАНО] Документ «Заявка №10 от 08.04.2024.pdf»:\nЗаявка № 10 от 08.04.2024\n"
                + "Бизнес-требования: вывод текста на экране в АМ IOS; разработка на Android";
        String act = "АКТ №1\nсдачи-приемки работ по Заявке №10 от 08.04.2024 к Договору № ШТ-2023 от 21.04.2023\n"
                + "г. Москва 28 июня 2025 г.\nООО «Сентикор», именуемое в дальнейшем «Исполнитель», и АО «АЛЬФА-БАНК», "
                + "именуемое в дальнейшем «Заказчик»\nВыполнены работы: доработка приложения для телефонов на платформе Android\n"
                + "ИТОГО: 48 828 140,00";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка № 10 от 08.04.2024.pdf", order),
                new Form3Ops.Source("АКТ №1 по Заявке №10 от 08.04.24.pdf", act)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | iOS | Раздел 2 | точно" + System.lineSeparator()
                + "Технология 5 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String line = FORM_LINE.replace("ПАО Сбербанк", "АО «АЛЬФА-БАНК»")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "ДОГОВОР № ШТ-2023 от 21 апреля 2023 | Заявка №10 к Договору № ШТ-2023 | АКТ №1 сдачи-приемки работ по Заявке №10 | 28 июня 2025 г.")
                .replace("2495000", "48828140");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("Акт от 28.06.2025 (заявка 10)", row.get("к6"));
        assertEquals("да", row.get("т_iOS"));
        assertEquals("да", row.get("т_Android"));
        assertEquals("да: iOS, Android", row.get("к17"));
        assertEquals("да: Android", row.get("к18"));
        assertEquals("48828140.00", row.get("к10"));
        assertEquals("-", row.get("к15"));
        // мобильность доказана лишь упоминанием платформ — строка помечена для второго мнения агента
        assertEquals("да", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("только по упоминанию платформы"));
    }

    @Test
    void mobileDevelopmentRequiresDeclaredPlatformInForm() throws Exception {
        // заявка 10 Комплекта 3: платформы в тексте есть, но в форме iOS и Android — «Нет» → нет мобильной разработки
        String order = "Заявка № 10 от 08.04.2024\nДоработка мобильного приложения: вывод текста в АМ IOS; разработка на Android";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка № 10 от 08.04.2024.pdf", order)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | iOS | Раздел 2 | точно" + System.lineSeparator()
                + "Технология 5 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String header = Form3FormTest.HEADER.replace("технологии Java", "технологии iOS").replace("технологии Python", "технологии Android");
        String line = FORM_LINE.replace("не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025 | да | нет",
                "Заявка №10 к Договору № ШТ-2023 | АКТ №1 сдачи-приемки работ по Заявке №10 от 30.06.2025 | 30.06.2025 | нет | нет");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, header), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("нет", row.get("к12"));
        assertEquals("нет", row.get("т_iOS"));
        assertTrue(String.valueOf(row.get("к15")).contains("нет мобильной разработки"), String.valueOf(row.get("к15")));
        assertTrue(String.valueOf(row.get("к20")).contains("мобильная разработка по форме не заявлена"));

        List<?> claimed = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria,
                line.replace("| нет | нет", "| нет | да"), header), List.class);
        assertEquals("да", ((Map<?, ?>) claimed.get(0)).get("к12"));
    }

    @Test
    void technologyNotClaimedInFormIsNotCounted() throws Exception {
        // договор строки называет Java и Python, но в форме участник заявил только Java (колонка Python — «нет»)
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Договор.pdf", CONTRACT)));
        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, FORM_LINE, Form3FormTest.HEADER),
                List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("да: Java, Python", row.get("к16"));
        assertEquals("да", row.get("т_Java"));
        assertEquals("нет", row.get("т_Python"));
        assertEquals("Подтверждающие документы не найдены", row.get("к15"));
        assertEquals("да", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("по форме участника не заявлено, не засчитывается: Python"));
    }

    @Test
    void formRowCountedWhenSpecificationConfirmsStageAmount() throws Exception {
        // акта этапа в комплекте нет, но спецификация того же договора содержит сумму этапа — строка засчитывается
        String spec = """
                Спецификация на разработку программного обеспечения № 5374642 к Договору №4652269 от 05.07.2023
                1. Предмет Спецификации: Исполнитель выполняет работы по разработке сервисов на Java
                Этап 2 Стоимость 2495000,00 Подпись банка 26.06.2025 17:37:40
                """;
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Спецификация № 5374642.pdf", spec)));
        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, FORM_LINE, Form3FormTest.HEADER),
                List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("2495000.00", row.get("к14"));
        assertEquals("-", row.get("к15"));
        assertEquals("да", row.get("т_Java"));
        assertEquals("", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("акт/УПД не найден, сумма этапа подтверждена спецификацией"));
    }

    @Test
    void formRowIsLinkedToAlfaOrderAndActByNumber() throws Exception {
        // Альфа-Банк: заявка (заказ) по номеру из формы, акт — по дате и номеру заявки из имени файла скана
        String order = "[РАСПОЗНАНО] Документ «Заявка №104 от 15.04.2024.pdf»:\nЗаявка № 104 от 15.04.2024 на разработку iOS-приложения";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка №104 от 15.04.2024.pdf", order),
                new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf", Form3ActsTest.ALFA_ACT_OCR)));
        String criteria = Form3OpsTest.CRITERIA + "Технология 4 | iOS | Раздел 2 | точно" + System.lineSeparator()
                + "Технология 5 | Android | Раздел 2 | точно" + System.lineSeparator();
        criteria = criteria.replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String line = FORM_LINE.replace("ПАО Сбербанк", "АО \"АЛЬФА-БАНК\"")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "Договор №АБ-С-ИТ-2020 от 03.02.2020 | Заявка 104 от 15.04.2024 | Акт от 27.04.2024 | 27.04.2024")
                .replace("2495000", "22849905");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("Акт от 27.04.2024 (заявка 104)", row.get("к6"));
        assertEquals("заявка 104 от 15.04.2024", row.get("к5"));
        // iOS — из заявки, Android — из акта: заявка и акт равно доказательны
        assertEquals("да", row.get("т_iOS"));
        assertEquals("да", row.get("т_Android"));
        assertEquals("да: iOS", row.get("к17"));
        assertEquals("да: Android", row.get("к18"));
        assertEquals("да", row.get("к12"));
        assertEquals("нет", row.get("к9"));
        assertEquals("Акт не в периоде", row.get("к15"));
    }

    @Test
    void largeCompaniesAreInRatingButSubsidiariesAreNot() throws Exception {
        Map<?, ?> metro = formRows(Form3Ops.registry(List.of()), FORM_LINE.replace("ПАО Сбербанк", "ООО «МЕТРО Кэш энд Керри»")).get(0);
        Map<?, ?> lukoil = formRows(Form3Ops.registry(List.of()), FORM_LINE.replace("ПАО Сбербанк", "ПАО «ЛУКОЙЛ»")).get(0);
        Map<?, ?> subsidiary = formRows(Form3Ops.registry(List.of()), FORM_LINE.replace("ПАО Сбербанк", "ООО «ЛУКОЙЛ-Интер-Кард»")).get(0);

        assertEquals("да", metro.get("к11"));
        assertEquals("да", lukoil.get("к11"));
        assertEquals("нет", subsidiary.get("к11"));
    }

    @Test
    void customerOutsideRatingIsStopFactorForFormRow() throws Exception {
        String line = FORM_LINE.replace("ПАО Сбербанк", "ООО «ЛУКОЙЛ-Интер-Кард»");

        Map<?, ?> row = formRows(Form3Ops.registry(List.of()), line).get(0);

        assertEquals("нет", row.get("к11"));
        assertEquals("-", row.get("к8"));
        assertEquals("-", row.get("к10"));
        assertEquals("-", row.get("к12"));
        assertEquals("-", row.get("т_Python"));
        assertEquals("-", row.get("к19"));
        assertEquals("0", row.get("к14"));
        assertEquals("Заказчик не в рейтинге", row.get("к15"));
    }

    @Test
    void formRowsMatchUpdByNumberThenBySumAndDateAndDropUpdOutsideForm() throws Exception {
        String partial = Form3OpsTest.UPD_SIGNED.replace("0000118724", "0000118725").replace("1063178,54", "500000,00");
        String outside = Form3OpsTest.UPD_SIGNED.replace("0000118724", "0000118726");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("u1.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("u2.pdf", partial), new Form3Ops.Source("u3.pdf", outside),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A)));
        // вторая строка: номер заказа вместо номера УПД, объединённые ячейки пусты — заказчик наследуется
        String form = FORM_LINE.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "УПД № 0000118724 от 21.07.2025 | 24.07.2025")
                .replace("2495000", "1063178,54")
                + "\n |  |  |  |  |  |  |  |  | УПД № 100000049520 от 21.07.2025 | 24.07.2025 | да | нет | 500000,00 |  |  | ";

        List<Map<?, ?>> rows = formRows(registry, form);

        assertEquals(2, rows.size());
        assertEquals("УПД 0000118724 от 21.07.2025", rows.get(0).get("к6"));
        assertEquals("да", rows.get(0).get("т_Java"));
        assertEquals("-", rows.get(0).get("к15"));
        assertEquals("УПД 0000118725 от 21.07.2025", rows.get(1).get("к6"));
        assertEquals("ПАО Сбербанк", rows.get(1).get("к3"));
        assertEquals("500000.00", rows.get(1).get("к10"));
    }

    @Test
    void formHintPicksSpecificationAmongCandidates() throws Exception {
        // сумма этапа совпадает в двух спецификациях; форма участника указывает одну из них — берётся она
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A), new Form3Ops.Source("specB.pdf", Form3OpsTest.SPEC_B)));
        String form = "ООО | Спецификация 5284130 от 28.03.2025 | УПД № 0000118724 от 21.07.2025 | 24.07.2025 | 1063178,54";

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form), List.class).get(0);

        assertEquals("5284130 от 28.03.2025", row.get("к5"));
        assertEquals("нет", row.get("т_Java"));
        assertEquals("да", row.get("т_Python"));
        assertTrue(String.valueOf(row.get("к20")).contains("спецификация выбрана по форме участника"));
    }

    @Test
    void formHintSuppliesSpecificationWhenSumsDoNotMatch() throws Exception {
        // частичный акт: сумма УПД не равна сумме этапа; форма (по сумме и дате УПД) называет спецификацию
        String upd = Form3OpsTest.UPD_SIGNED.replace("1063178,54", "500000,00");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", upd),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A)));
        String form = "ООО | Спецификация 5374642 от 27.06.2025 | УПД № 100000049520 от 21.07.2025 | 24.07.2025 | 500000,00";

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form), List.class).get(0);

        assertEquals("5374642 от 27.06.2025", row.get("к5"));
        assertEquals("да", row.get("т_Java"));
        assertTrue(String.valueOf(row.get("к20")).contains("взята из формы участника"));
    }

    @Test
    void rowsWithoutContractAreNotCountedWhenOptionEnabled() throws Exception {
        // Комплект 8 Егоровой «без договора»: только спецификации и акты — опыт не засчитывается
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_WITH_ZNZO), new Form3Ops.Source("Отчет.pdf", REPORT)));
        String withContract = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_WITH_ZNZO),
                new Form3Ops.Source("Договор.pdf", CONTRACT), new Form3Ops.Source("Отчет.pdf", REPORT)));
        Map<String, Object> option = Map.of("без_договора_не_засчитывать", "true");

        Map<?, ?> denied = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(option, registry, Form3OpsTest.CRITERIA), List.class).get(0);
        Map<?, ?> legacy = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA), List.class).get(0);
        Map<?, ?> counted = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(option, withContract, Form3OpsTest.CRITERIA), List.class).get(0);

        assertEquals("0", denied.get("к14"));
        assertTrue(String.valueOf(denied.get("к15")).startsWith(Form3Rows.REASON_NO_DOCS), String.valueOf(denied.get("к15")));
        assertEquals("да", denied.get("агенту"));
        assertEquals("0", denied.get(Form3Rows.CONTRACTS));
        assertEquals("1063178.54", legacy.get("к14"));
        assertEquals("1063178.54", counted.get("к14"));
        assertEquals("-", counted.get("к15"));
    }

    @Test
    void contractTechnologyDoesNotCountWhenSpecificationNamesOtherRoles() throws Exception {
        // Комплект 9 Егоровой: Python есть только в ставках рамочного договора, спецификация называет «Главный разработчик GreenPlum»
        String pythonOnly = Form3OpsTest.CRITERIA.replace("Технология 1 | Java | Раздел 2 | точно", "Технология 1 | Python | Раздел 2 | точно")
                .replace("Технология 2 | Go (Golang) | Раздел 2 | точно" + System.lineSeparator(), "")
                .replace("Технология 2 | Go (Golang) | Раздел 2 | точно\n", "")
                .replace("Технология 3 | Python | Раздел 2 | точно", "");
        String greenplumSpec = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end)", "Главный разработчик GreenPlum");
        String noRolesSpec = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end) (Москва) 47 22620,82 1063 178,54\n", "");
        String withRoles = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация.pdf", greenplumSpec), new Form3Ops.Source("Договор.pdf", CONTRACT)));
        String withoutRoles = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация.pdf", noRolesSpec), new Form3Ops.Source("Договор.pdf", CONTRACT)));

        Map<?, ?> denied = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), withRoles, pythonOnly), List.class).get(0);
        Map<?, ?> counted = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), withoutRoles, pythonOnly), List.class).get(0);

        assertEquals("0", denied.get("к14"));
        assertTrue(String.valueOf(denied.get("к15")).contains("технология не найдена"), String.valueOf(denied.get("к15")));
        assertEquals("да: Python", denied.get("к16"));
        assertTrue(String.valueOf(denied.get("к20")).contains("спецификация называет роли исполнителей (GreenPlum)"), String.valueOf(denied.get("к20")));
        assertEquals("1063178.54", counted.get("к14"));
        assertEquals("да", counted.get("т_Python"));
    }

    @Test
    void reportOfAnotherSpecificationIsNotLinkedBySum() throws Exception {
        // отчёт чужой спецификации с той же суммой этапа не должен приносить свои технологии
        String foreign = "ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ К Спецификации на модификацию № 5472112 от 09.10.2025 "
                + "к договору № 4652269 Выполнена разработка на JavaScript. Стоимость 1063178,54";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A), new Form3Ops.Source("Отчет.pdf", foreign)));
        String criteria = Form3OpsTest.CRITERIA + "Технология 4 | JavaScript | Раздел 2 | точно" + System.lineSeparator();

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria), List.class).get(0);

        assertEquals("нет", row.get("т_JavaScript"));
        assertTrue(String.valueOf(row.get("к20")).contains("отчётов 0"));
    }
}
