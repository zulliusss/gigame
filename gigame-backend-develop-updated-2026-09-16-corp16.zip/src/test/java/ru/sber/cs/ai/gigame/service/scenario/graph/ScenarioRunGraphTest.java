package ru.sber.cs.ai.gigame.service.scenario.graph;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioRunGraphTest {

    @Test
    void testConstructor_withSingleNodeGraph() {
        // n1 (input) -> n2 (output)
        var n1 = new NodeDto("n1", "input", null, null, null);
        var n2 = new NodeDto("n2", "output", null, null, null);
        var e1 = new EdgeDto("e1", "n1", "n2", null);
        var graphData = new GraphDataDto(List.of(n1, n2), List.of(e1));

        var graph = new ScenarioRunGraph(graphData);

        // startNode = n1 (has no parents)
        assertEquals("n1", graph.getStartNode().getId());
        assertEquals(2, graph.getNodeMap().size());
        assertTrue(graph.getNodeMap().containsKey("n1"));
        assertTrue(graph.getNodeMap().containsKey("n2"));
    }

    @Test
    void testConstructor_withMultipleNodes() {
        // n1 -> n2 -> n3
        var n1 = new NodeDto("n1", "input", null, null, null);
        var n2 = new NodeDto("n2", "processing",
                new NodeDataDto("Label", null, null, null, null, "all", null, null, null, null, null, null, null),
                new PositionDto(100, 100), null);
        var n3 = new NodeDto("n3", "output", null, null, null);
        var e1 = new EdgeDto("e1", "n1", "n2", null);
        var e2 = new EdgeDto("e2", "n2", "n3", null);
        var graphData = new GraphDataDto(List.of(n1, n2, n3), List.of(e1, e2));

        var graph = new ScenarioRunGraph(graphData);

        assertEquals("n1", graph.getStartNode().getId());
        assertEquals(3, graph.getNodeMap().size());

        // Проверяем parent-child связи
        var node1 = graph.getNodeMap().get("n1");
        var node2 = graph.getNodeMap().get("n2");
        var node3 = graph.getNodeMap().get("n3");

        assertTrue(node1.getChildNodeList().contains(node2));
        assertTrue(node2.getChildNodeList().contains(node3));
        assertTrue(node2.getParentNodeList().contains(node1));
        assertTrue(node3.getParentNodeList().contains(node2));
        assertEquals(0, node1.getParentNodeList().size());
        assertEquals(0, node3.getChildNodeList().size());
    }

    @Test
    void testConstructor_startNodeIsFirstWithNoParents() {
        // Важно: startNode - узел без parentNodeList
        // n2 = output, n1 = input (оба без родителей, но startNode должен быть первым без родителей)
        // В этом графе оба узла без родителей, startNode = первый found
        var n1 = new NodeDto("n1", "input", null, null, null);
        var n2 = new NodeDto("n2", "output", null, null, null);
        var graphData = new GraphDataDto(List.of(n1, n2), List.of());

        var graph = new ScenarioRunGraph(graphData);
        assertNotNull(graph.getStartNode());
        assertEquals("n1", graph.getStartNode().getId());
    }

    @Test
    void testConstructor_throwsIfNoStartNode() {
        // Граф с циклической зависимостью (но все имеют родителей)
        // Для этого нужно, чтобы каждый узел имел хотя бы одного родителя
        // В данном случае - n1 -> n1 (сам на себя) - но из-за мапы edge это не сработает нормально
        // просто GraphData без edges - все узлы без parents, но если есть хоть один без родителей - он будет startNode
        // Чтобы бросить - нужно чтобы ВСЕ узлы имели родителей
        // Это возможно только если граф имеет цикл - но в рамках конструктора нет проверки на циклы
        // Так что если нет узлов - бросится
        assertThrows(Exception.class, () -> new ScenarioRunGraph(new GraphDataDto(List.of(), List.of())));
    }

    @Test
    void testConstructor_withEdgeData() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var n2 = new NodeDto("n2", "output", null, null, null);
        var e1 = new EdgeDto("e1", "n1", "n2", null);
        var graphData = new GraphDataDto(List.of(n1, n2), List.of(e1));

        var graph = new ScenarioRunGraph(graphData);

        // Edge map должен содержать пару (n1, n2)
        var edges = graph.getEdgeMap();
        assertEquals(1, edges.size());
    }

    @Test
    void testAddDocs_withMultipleDocuments() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var n2 = new NodeDto("n2", "output", null, null, null);
        var graphData = new GraphDataDto(List.of(n1, n2), List.of());
        var graph = new ScenarioRunGraph(graphData);

        graph.addDocs(
                List.of("doc1 text", "doc2 text"),
                List.of("file1.txt", "file2.txt")
        );

        assertEquals(2, graph.getDocMap().size());
        var doc1 = graph.getDocMap().get("DOC_1");
        var doc2 = graph.getDocMap().get("DOC_2");

        assertNotNull(doc1);
        assertNotNull(doc2);
        assertEquals("doc1 text", doc1.getText());
        assertEquals("file1.txt", doc1.getFilename());
        assertEquals("doc2 text", doc2.getText());
        assertEquals("file2.txt", doc2.getFilename());
    }

    @Test
    void testAddDocs_withNullTexts() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1), List.of());
        var graph = new ScenarioRunGraph(graphData);

        graph.addDocs(null, null);
        assertTrue(graph.getDocMap().isEmpty());
    }

    @Test
    void testAddDocs_withEmptyList() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1), List.of());
        var graph = new ScenarioRunGraph(graphData);

        graph.addDocs(List.of(), List.of());
        assertTrue(graph.getDocMap().isEmpty());
    }

    @Test
    void testPutDoc_keepsExplicitKeysWithoutRenumbering() {
        // возобновление: документы возвращаются под исходными метками в любом порядке и с пропусками
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(n1), List.of()));

        graph.putDoc("DOC_3", "c.pdf", "текст 3");
        graph.putDoc("DOC_1", "a.pdf", "текст 1");

        assertEquals(2, graph.getDocMap().size());
        assertEquals("текст 1", graph.getDocMap().get("DOC_1").getText());
        assertEquals("a.pdf", graph.getDocMap().get("DOC_1").getFilename());
        assertEquals("текст 3", graph.getDocMap().get("DOC_3").getText());
        assertEquals("c.pdf", graph.getDocMap().get("DOC_3").getFilename());
        assertFalse(graph.getDocMap().containsKey("DOC_2"));
        assertFalse(graph.getDocMap().get("DOC_3").isWorkNote());
    }

    @Test
    void testEmbeddingCache_initialized() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1), List.of());
        var graph = new ScenarioRunGraph(graphData);

        assertNotNull(graph.getEmbeddingCache());
        assertTrue(graph.getEmbeddingCache().isEmpty());
    }

    @Test
    void testConstructor_startNodeIsInput_evenIfAnotherRootIsFirstInJson() {
        // n2 (processing) без родителей стоит в JSON раньше входа — стартовый узел всё равно «Вход»
        var n2 = new NodeDto("n2", "processing", null, null, null);
        var n1 = new NodeDto("n1", "input", null, null, null);
        var n3 = new NodeDto("n3", "output", null, null, null);
        var graphData = new GraphDataDto(List.of(n2, n1, n3),
                List.of(new EdgeDto("e1", "n1", "n3", null), new EdgeDto("e2", "n2", "n3", null)));

        var graph = new ScenarioRunGraph(graphData);

        assertEquals("n1", graph.getStartNode().getId());
    }

    @Test
    void testNodeMap_keepsJsonOrder() {
        var ids = List.of("z9", "a1", "m5", "b2");
        var nodes = ids.stream().map(id -> new NodeDto(id, "processing", null, null, null)).toList();

        var graph = new ScenarioRunGraph(new GraphDataDto(nodes, List.of()));

        assertEquals(ids, new ArrayList<>(graph.getNodeMap().keySet()));
        assertEquals("z9", graph.getStartNode().getId());
    }

    @Test
    void testAddDocs_manyDocuments_keepNumericOrder() {
        // 13 документов: HashMap выдавал DOC_10..DOC_13 раньше DOC_2 — порядок обязан быть числовым
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(n1), List.of()));
        List<String> texts = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<String> expectedKeys = new ArrayList<>();
        for (int i = 1; i <= 13; i++) {
            texts.add("текст " + i);
            names.add("файл" + i + ".pdf");
            expectedKeys.add("DOC_" + i);
        }

        graph.addDocs(texts, names);

        assertEquals(expectedKeys, new ArrayList<>(graph.getDocMap().keySet()));
    }

    @Test
    void testPutDoc_keepsInsertionOrder() {
        // возобновление кладёт документы в числовом порядке меток — docMap его сохраняет
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(n1), List.of()));

        graph.putDoc("DOC_1", "a.pdf", "1");
        graph.putDoc("DOC_2", "b.pdf", "2");
        graph.putDoc("DOC_10", "j.pdf", "10");
        graph.putDoc("DOC_12", "l.pdf", "12");

        assertEquals(List.of("DOC_1", "DOC_2", "DOC_10", "DOC_12"), new ArrayList<>(graph.getDocMap().keySet()));
    }

    // ------------------ детерминированный порядок узлов ------------------

    @Test
    void testNodeMap_keepsGraphDataOrder() {
        var n1 = new NodeDto("zeta", "output", null, null, null);
        var n2 = new NodeDto("alpha", "processing", null, null, null);
        var n3 = new NodeDto("mid", "input", null, null, null);
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(n1, n2, n3), List.of(
                new EdgeDto("e1", "mid", "alpha", null), new EdgeDto("e2", "alpha", "zeta", null))));

        assertEquals(List.of("zeta", "alpha", "mid"), List.copyOf(graph.getNodeMap().keySet()));
    }

    @Test
    void testNodesInTopologicalOrder_reversedListing_rootFirstChildrenByEdges() {
        var out = new NodeDto("out", "output", null, null, null);
        var c = new NodeDto("c", "processing", null, null, null);
        var b = new NodeDto("b", "processing", null, null, null);
        var a = new NodeDto("a", "processing", null, null, null);
        var in = new NodeDto("in", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(out, c, b, a, in), List.of(
                new EdgeDto("e1", "in", "a", null), new EdgeDto("e2", "in", "b", null),
                new EdgeDto("e3", "in", "c", null), new EdgeDto("e4", "a", "out", null),
                new EdgeDto("e5", "b", "out", null), new EdgeDto("e6", "c", "out", null)));

        var first = new ScenarioRunGraph(graphData).nodesInTopologicalOrder().stream().map(ScenarioRunNode::getId).toList();
        var second = new ScenarioRunGraph(graphData).nodesInTopologicalOrder().stream().map(ScenarioRunNode::getId).toList();

        assertEquals(List.of("in", "a", "b", "c", "out"), first);
        assertEquals(first, second);
    }

    @Test
    void testConstructor_duplicateNodeId_throws() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var dup = new NodeDto("n1", "output", null, null, null);
        var graphData = new GraphDataDto(List.of(n1, dup), List.of());

        assertThrows(IllegalStateException.class, () -> new ScenarioRunGraph(graphData));
    }

    @Test
    void testAddFailedNode_collectsLabels() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(n1), List.of()));
        assertTrue(graph.getFailedNodeLabels().isEmpty());

        graph.addFailedNode("Анализ");
        graph.addFailedNode("Сводка");

        assertEquals(List.of("Анализ", "Сводка"), List.copyOf(graph.getFailedNodeLabels()));
    }
}
