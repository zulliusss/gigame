package ru.sber.cs.ai.gigame.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.dto.agent.AgentPlanResponseDto;
import ru.sber.cs.ai.gigame.dto.agent.AgentQuestionResponseDto;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.repository.AgentLessonRepository;
import ru.sber.cs.ai.gigame.repository.AgentPlanRepository;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.spy;

/**
 * Тесты памяти агента: уроки (частные/общие), планы (хэш задания),
 * вопросы (ответ превращается в урок), рефлексия-сжатие.
 */
@ExtendWith(MockitoExtension.class)
class AgentMemoryServiceTest {

    @Mock
    private AgentLessonRepository lessonRepository;
    @Mock
    private AgentPlanRepository planRepository;
    @Mock
    private AgentQuestionRepository questionRepository;
    @Mock
    private GigaChatClient gigaChatClient;
    @Mock
    private ScenarioRepository scenarioRepository;

    @InjectMocks
    private AgentMemoryService service;

    @BeforeEach
    void setUpSelfProxy() {
        // @Transactional-методы вызываются через саму-прокси (как в Spring-контексте)
        ReflectionTestUtils.setField(service, "self", new AtomicReference<>(service));
    }

    private static AgentLesson lesson(UUID scenarioId, String text, boolean approved) {
        AgentLesson l = new AgentLesson();
        l.setId(UUID.randomUUID());
        l.setScenarioId(scenarioId);
        l.setLesson(text);
        l.setApproved(approved);
        return l;
    }

    private static AgentLesson generalLesson(String owner, String text) {
        AgentLesson l = lesson(null, text, true);
        l.setUserId(owner);
        return l;
    }

    private static Scenario scenarioOf(String owner, boolean shared) {
        Scenario scenario = new Scenario();
        scenario.setId(UUID.randomUUID());
        scenario.setUserId(owner);
        scenario.setShared(shared);
        return scenario;
    }

    @Test
    void lessonsForScenario_combinesSystemPersonalAndScenarioLayers() {
        UUID sid = UUID.randomUUID();
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(lesson(null, "системный урок", true)));
        when(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc(
                "RUNNER", AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(lesson(null, "личный общий урок", true)));
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid))
                .thenReturn(List.of(lesson(sid, "урок сценария", true)));

        List<String> lessons = service.lessonsForScenario(sid, "RUNNER");

        assertEquals(List.of("системный урок", "личный общий урок", "урок сценария"), lessons);
    }

    @Test
    void lessonsForScenario_anonymousGetsNoPersonalLayer() {
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(lesson(null, "системный урок", true)));

        assertEquals(List.of("системный урок"), service.lessonsForScenario(null, null));
    }

    @Test
    void systemLesson_cannotBeModified() {
        AgentLesson system = lesson(null, "системный", true);
        system.setSource(AgentLesson.SOURCE_SYSTEM);
        when(lessonRepository.findById(system.getId())).thenReturn(Optional.of(system));
        var id = system.getId();
        assertThrows(IllegalArgumentException.class,
                () -> service.updateLesson(id, "правка"));
        assertThrows(IllegalArgumentException.class,
                () -> service.deleteLesson(id));
    }

    @Test
    void addLesson_userLessonsActiveImmediately() {
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));
        UUID sid = UUID.randomUUID();
        var scenario = new Scenario();
        scenario.setUserId("U");
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenario));

        CurrentUserHolder.withUser("U", () -> {
            AgentLessonResponseDto scenarioLesson =
                    service.addLesson(sid, "урок сценария", null);
            // личный общий урок действует только на запуски владельца — активен сразу
            AgentLessonResponseDto personal = service.addLesson(null, "личный общий урок", null);

            assertTrue(scenarioLesson.approved());
            assertTrue(personal.approved());
            assertThrows(IllegalArgumentException.class,
                    () -> service.addLesson(null, " ", null));
            return null;
        });
    }

    @Test
    void planRoundTrip_saveAndFindByNormalizedHash() {
        UUID sid = UUID.randomUUID();
        when(planRepository.findFirstByScenarioIdAndTaskHashOrderByUsesDesc(eq(sid), any()))
                .thenReturn(Optional.empty());
        when(planRepository.save(any(AgentPlan.class))).thenAnswer(inv -> inv.getArgument(0));
        service.savePlan(sid, "Найди  НМЦ\nв извещении", List.of("пункт 1", "пункт 2"));

        // то же задание с другими пробелами/регистром — тот же хэш
        String h1 = AgentMemoryService.taskHash("Найди  НМЦ\nв извещении");
        String h2 = AgentMemoryService.taskHash("найди нмц в извещении");
        assertEquals(h1, h2);

        AgentPlan saved = new AgentPlan();
        saved.setPlan("[\"пункт 1\", \"пункт 2\"]");
        saved.setUses(0);
        when(planRepository.findFirstByScenarioIdAndTaskHashOrderByUsesDesc(sid, h1))
                .thenReturn(Optional.of(saved));

        List<String> found = service.findPlan(sid, "НАЙДИ НМЦ В ИЗВЕЩЕНИИ");

        assertEquals(List.of("пункт 1", "пункт 2"), found);
        assertEquals(1, saved.getUses());
    }

    @Test
    void plans_keyedByScenarioAndTaskHash() {
        // план другого сценария с тем же заданием не переиспользуется и не перепривязывается
        UUID sidA = UUID.randomUUID();
        UUID sidB = UUID.randomUUID();
        String hash = AgentMemoryService.taskHash("задание");
        AgentPlan planA = new AgentPlan();
        planA.setScenarioId(sidA);
        planA.setTaskHash(hash);
        planA.setPlan("[\"пункт A\"]");
        planA.setUses(0);
        when(planRepository.findFirstByScenarioIdAndTaskHashOrderByUsesDesc(sidA, hash)).thenReturn(Optional.of(planA));
        when(planRepository.findFirstByScenarioIdAndTaskHashOrderByUsesDesc(sidB, hash)).thenReturn(Optional.empty());
        when(planRepository.save(any(AgentPlan.class))).thenAnswer(inv -> inv.getArgument(0));

        assertEquals(List.of("пункт A"), service.findPlan(sidA, "задание"));
        assertEquals(List.of(), service.findPlan(sidB, "задание"));
        service.savePlan(sidB, "задание", List.of("пункт B"));

        ArgumentCaptor<AgentPlan> captor = ArgumentCaptor.forClass(AgentPlan.class);
        verify(planRepository, times(2)).save(captor.capture());
        assertEquals(sidB, captor.getValue().getScenarioId());
        assertEquals("[\"пункт B\"]", captor.getValue().getPlan());
        assertEquals(sidA, planA.getScenarioId());
        assertEquals("[\"пункт A\"]", planA.getPlan());
        verify(planRepository, never()).findFirstByTaskHashOrderByUsesDesc(any());
    }

    @Test
    void answerQuestion_savesAnswerAndCreatesScenarioLesson() {
        UUID qid = UUID.randomUUID();
        UUID sid = UUID.randomUUID();
        AgentQuestion question = new AgentQuestion();
        question.setId(qid);
        question.setScenarioId(sid);
        question.setQuestion("Где искать дату публикации?");
        when(questionRepository.findById(qid)).thenReturn(Optional.of(question));
        when(questionRepository.save(any(AgentQuestion.class))).thenAnswer(inv -> inv.getArgument(0));
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));

        CurrentUserHolder.withUser("U", () -> {
            AgentQuestionResponseDto answered = service.answerQuestion(qid,
                    "дата публикации = «дата начала срока подачи заявок»");

            assertNotNull(answered.answeredAt());
            // answered_at в ответе — UTC с микросекундами: не длиннее maxLength 32 при любом поясе JVM
            assertEquals(ZoneOffset.UTC, answered.answeredAt().getOffset());
            assertEquals(0, answered.answeredAt().getNano() % 1000);
            assertEquals("дата публикации = «дата начала срока подачи заявок»", answered.answer());
            verify(lessonRepository).save(any(AgentLesson.class));
            return null;
        });
    }

    @Test
    void answerQuestion_longQuestion_lessonKeepsAnswerAndFitsSchema() {
        UUID qid = UUID.randomUUID();
        UUID sid = UUID.randomUUID();
        AgentQuestion question = new AgentQuestion();
        question.setId(qid);
        question.setScenarioId(sid);
        question.setQuestion("По пункту «Перечень» значение «" + "позиция; ".repeat(600) + "» не подтверждено");
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));
        when(questionRepository.findById(qid)).thenReturn(Optional.of(question));
        when(questionRepository.save(any(AgentQuestion.class))).thenAnswer(inv -> inv.getArgument(0));
        ArgumentCaptor<AgentLesson> lessonCaptor = ArgumentCaptor.forClass(AgentLesson.class);
        when(lessonRepository.save(lessonCaptor.capture())).thenAnswer(inv -> inv.getArgument(0));
        String answer = "ответ ".repeat(450).strip();

        CurrentUserHolder.withUser("U", () -> {
            AgentQuestionResponseDto answered = service.answerQuestion(qid, answer);

            String lesson = lessonCaptor.getValue().getLesson();
            assertTrue(lesson.endsWith(answer));
            assertTrue(lesson.length() <= AgentLessonResponseDto.LESSON_MAX_LENGTH, "length=" + lesson.length());
            assertTrue(answered.question().length() <= AgentQuestionResponseDto.TEXT_MAX_LENGTH);
            return null;
        });
    }

    @Test
    void getPlans_mapsEntitiesToSchemaDto() throws Exception {
        UUID sid = UUID.randomUUID();
        AgentPlan plan = new AgentPlan();
        plan.setId(UUID.randomUUID());
        plan.setScenarioId(sid);
        plan.setTaskHash(AgentMemoryService.taskHash("задание"));
        List<String> items = new ArrayList<>();
        for (int i = 0; i < 12; i++) {
            items.add("пункт " + i + ": " + "длинная формулировка ".repeat(20));
        }
        plan.setPlan(new ObjectMapper().writeValueAsString(items));
        plan.setUses(3);
        plan.setUpdatedAt(OffsetDateTime.of(2026, 9, 15, 13, 5, 26, 884_512_345, ZoneOffset.ofHours(3)));
        when(planRepository.findByScenarioIdOrderByUpdatedAtDesc(sid)).thenReturn(List.of(plan));
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));

        List<AgentPlanResponseDto> plans = CurrentUserHolder.withUser("U", () -> service.getPlans(sid));

        assertEquals(1, plans.size());
        assertEquals(sid, plans.get(0).scenarioId());
        assertEquals(3, plans.get(0).uses());
        assertTrue(plans.get(0).plan().length() <= AgentPlanResponseDto.PLAN_MAX_LENGTH);
        assertTrue(new ObjectMapper().readTree(plans.get(0).plan()).isArray());
        assertEquals(OffsetDateTime.of(2026, 9, 15, 10, 5, 26, 884_512_000, ZoneOffset.UTC),
                plans.get(0).updatedAt());
    }

    @Test
    void getQuestionsByRun_mapsEntitiesToSchemaDto() {
        UUID runId = UUID.randomUUID();
        AgentQuestion question = new AgentQuestion();
        question.setId(UUID.randomUUID());
        question.setRunId(runId);
        question.setNodeLabel("Агент");
        question.setQuestion("Где искать дату публикации?");
        when(questionRepository.findByRunIdOrderByCreatedAtAsc(runId)).thenReturn(List.of(question));

        List<AgentQuestionResponseDto> questions = service.getQuestionsByRun(runId);

        assertEquals(1, questions.size());
        assertEquals(runId, questions.get(0).runId());
        assertEquals("Агент", questions.get(0).nodeLabel());
        assertEquals("Где искать дату публикации?", questions.get(0).question());
    }

    @Test
    void getQuestionRunId_returnsRunOfQuestion() {
        UUID qid = UUID.randomUUID();
        UUID runId = UUID.randomUUID();
        AgentQuestion question = new AgentQuestion();
        question.setId(qid);
        question.setRunId(runId);
        when(questionRepository.findById(qid)).thenReturn(Optional.of(question));

        assertEquals(runId, service.getQuestionRunId(qid));
    }

    @Test
    void getQuestionRunId_unknownQuestion_notFound() {
        UUID qid = UUID.randomUUID();
        when(questionRepository.findById(qid)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> service.getQuestionRunId(qid));
    }

    @Test
    void responseLists_limitedToSchemaMaxItems1000() {
        // maxItems 1000 у списков уроков, планов и вопросов: хвост сверх лимита не отдаётся
        UUID sid = UUID.randomUUID();
        UUID runId = UUID.randomUUID();
        List<AgentLesson> lessons = new ArrayList<>();
        List<AgentPlan> plans = new ArrayList<>();
        List<AgentQuestion> questions = new ArrayList<>();
        for (int i = 0; i <= AgentMemoryService.RESPONSE_MAX_ITEMS; i++) {
            lessons.add(generalLesson("U", "общий урок " + i));
            plans.add(new AgentPlan());
            questions.add(new AgentQuestion());
        }
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of());
        when(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc("U", AgentLesson.SOURCE_SYSTEM))
                .thenReturn(lessons);
        when(planRepository.findByScenarioIdOrderByUpdatedAtDesc(sid)).thenReturn(plans);
        when(questionRepository.findByRunIdOrderByCreatedAtAsc(runId)).thenReturn(questions);
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));

        List<AgentLessonResponseDto> globalLessons = CurrentUserHolder.withUser("U", () -> service.getLessons(null));

        assertEquals(1000, globalLessons.size());
        assertEquals("общий урок 999", globalLessons.get(999).lesson());
        assertEquals(1000, CurrentUserHolder.withUser("U", () -> service.getPlans(sid)).size());
        assertEquals(1000, service.getQuestionsByRun(runId).size());
    }

    @Test
    void responseLists_atLimit1000_returnedWhole() {
        List<AgentLesson> lessons = new ArrayList<>();
        for (int i = 0; i < AgentMemoryService.RESPONSE_MAX_ITEMS; i++) {
            lessons.add(generalLesson("U", "общий урок " + i));
        }
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of());
        when(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc("U", AgentLesson.SOURCE_SYSTEM))
                .thenReturn(lessons);

        assertEquals(1000, CurrentUserHolder.withUser("U", () -> service.getLessons(null)).size());
    }

    @Test
    void answerQuestion_longAnswer_lessonStoredWithinLimitAndShownUnchanged() {
        // урок сохраняется не длиннее 4000: показанный на странице памяти текст совпадает с хранимым
        UUID qid = UUID.randomUUID();
        UUID sid = UUID.randomUUID();
        AgentQuestion question = new AgentQuestion();
        question.setId(qid);
        question.setScenarioId(sid);
        question.setQuestion("в".repeat(1000));
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));
        when(questionRepository.findById(qid)).thenReturn(Optional.of(question));
        when(questionRepository.save(any(AgentQuestion.class))).thenAnswer(inv -> inv.getArgument(0));
        ArgumentCaptor<AgentLesson> lessonCaptor = ArgumentCaptor.forClass(AgentLesson.class);
        when(lessonRepository.save(lessonCaptor.capture())).thenAnswer(inv -> inv.getArgument(0));
        String answer = "о".repeat(3500);

        CurrentUserHolder.withUser("U", () -> service.answerQuestion(qid, answer));

        String stored = lessonCaptor.getValue().getLesson();
        assertTrue(stored.length() <= AgentLessonResponseDto.LESSON_MAX_LENGTH, "length=" + stored.length());
        assertTrue(stored.endsWith(answer));
        assertTrue(stored.startsWith("На вопрос «"));
        assertEquals(stored, AgentLessonResponseDto.from(lessonCaptor.getValue()).lesson());
    }

    @Test
    void lessonFromAnswer_answerAtSchemaLimit_lessonIsAnswerItself() {
        // префикс «Пользователь уточнил: » не помещается — урок равен ответу, ответ не обрезается
        String answer = "о".repeat(4000);

        String lesson = AgentMemoryService.lessonFromAnswer("вопрос", answer);

        assertEquals(answer, lesson);
    }

    @Test
    void lessonFromAnswer_answer3970_endsWithWholeAnswerWithoutQuote() {
        String answer = "о".repeat(3970);

        String lesson = AgentMemoryService.lessonFromAnswer("в".repeat(1000), answer);

        assertEquals("Пользователь уточнил: " + answer, lesson);
        assertTrue(lesson.length() <= AgentLessonResponseDto.LESSON_MAX_LENGTH);
        assertTrue(lesson.endsWith(answer));
    }

    @Test
    void lessonFromAnswer_quoteBudgetBelowMinimum_noQuoteAndNoEmptyQuotes() {
        // бюджет цитаты 1..49 символов: вопрос не цитируется, пустых «» и обрывков нет
        for (int budget = 1; budget < AgentMemoryService.MIN_QUESTION_QUOTE; budget++) {
            String answer = "о".repeat(AgentLessonResponseDto.LESSON_MAX_LENGTH
                    - AgentMemoryService.LESSON_ANSWER_FRAME_LENGTH - budget);

            String lesson = AgentMemoryService.lessonFromAnswer("в".repeat(1000), answer);

            assertEquals("Пользователь уточнил: " + answer, lesson, "budget=" + budget);
            assertFalse(lesson.contains("«"), "budget=" + budget);
        }
    }

    @Test
    void lessonFromAnswer_quoteBudgetAtMinimum_questionQuoted() {
        String answer = "о".repeat(AgentLessonResponseDto.LESSON_MAX_LENGTH
                - AgentMemoryService.LESSON_ANSWER_FRAME_LENGTH - AgentMemoryService.MIN_QUESTION_QUOTE);

        String lesson = AgentMemoryService.lessonFromAnswer("в".repeat(1000), answer);

        assertTrue(lesson.startsWith("На вопрос «в"));
        assertFalse(lesson.contains("«»"));
        assertTrue(lesson.endsWith(answer));
        assertEquals(AgentLessonResponseDto.LESSON_MAX_LENGTH, lesson.length());
    }

    @Test
    void updateLesson_longText_storedWithinSchemaLimit() {
        UUID id = UUID.randomUUID();
        AgentLesson entity = generalLesson("U", "старый урок");
        when(lessonRepository.findById(id)).thenReturn(Optional.of(entity));
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        AgentLessonResponseDto saved = CurrentUserHolder.withUser("U",
                () -> service.updateLesson(id, "  " + "у".repeat(5000) + "  "));

        assertEquals(AgentLessonResponseDto.LESSON_MAX_LENGTH, entity.getLesson().length());
        assertTrue(entity.getLesson().endsWith("…"));
        assertEquals(entity.getLesson(), saved.lesson());
    }

    @Test
    void addLesson_longText_storedWithinSchemaLimit() {
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        AgentLessonResponseDto saved = CurrentUserHolder.withUser("U",
                () -> service.addLesson(null, "у".repeat(5000), AgentLesson.SOURCE_USER));

        assertEquals(AgentLessonResponseDto.LESSON_MAX_LENGTH, saved.lesson().length());
    }

    @Test
    void extractLessonsFromRun_savesUnapprovedReviserCandidates() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"сумма акта — Итого с НДС, не аванс\"]");
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        var saved = service.extractLessonsFromRun(UUID.randomUUID(),
                Map.of("критик", "РАСХОЖДЕНИЕ: сумма акта — взят аванс"));

        assertEquals(1, saved.size());
        assertEquals(AgentLesson.SOURCE_REVISER, saved.get(0).source());
        assertEquals(false, saved.get(0).approved());
    }

    @Test
    void extractLessonsFromRun_filtersGenericAndDuplicateCandidates() {
        UUID sid = UUID.randomUUID();
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Проверяйте соответствие сумм актов документам\", "
                        + "\"Сумма акта — это «Итого» с НДС\", "
                        + "\"дата публикации = дата начала срока подачи заявок\"]");
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid))
                .thenReturn(List.of(lesson(sid, "Сумма акта — это «Итого» с НДС", true)));
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        var saved = service.extractLessonsFromRun(sid, Map.of("критик", "правки"));

        // банальный призыв отсечён, дубликат существующего урока пропущен,
        // конкретное новое правило сохранено
        assertEquals(1, saved.size());
        assertTrue(saved.get(0).lesson().contains("дата публикации"));
    }

    @Test
    void similarLesson_catchesRephrasedDuplicates() {
        // перефраз системного урока — дубликат (наблюдалось: extract вернул
        // системное правило другими словами, и дедуп по вхождению его пропустил)
        assertTrue(AgentMemoryService.similarLesson(
                "Сумма акта — это строка 'Итого' с НДС, а не к оплате за вычетом аванса",
                "Сумма акта или счёта — это «Итого» с НДС; не бери «к оплате за вычетом "
                        + "аванса» и не бери сам аванс."));
        assertFalse(AgentMemoryService.similarLesson(
                "дата публикации = дата начала срока подачи заявок",
                "Сумма акта — это «Итого» с НДС"));
    }

    @Test
    void specificLesson_rejectsGenericAdvice() {
        assertFalse(AgentMemoryService.specificLesson(
                "Обращайте внимание на наличие актов и их содержание"));
        assertFalse(AgentMemoryService.specificLesson(
                "Следите за корректностью расчёта общей суммы опыта"));
        // без цифр/кавычек/соответствия — тоже не урок
        assertFalse(AgentMemoryService.specificLesson(
                "Технологии подтверждаются актами"));
        assertTrue(AgentMemoryService.specificLesson(
                "Сумма акта — это «Итого» с НДС, не аванс"));
        assertTrue(AgentMemoryService.specificLesson(
                "дата публикации = дата начала срока подачи заявок"));
    }

    @Test
    void lessonsForScenario_skipsUnapprovedCandidates() {
        UUID sid = UUID.randomUUID();
        AgentLesson candidate = lesson(sid, "кандидат", true);
        candidate.setApproved(false);
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid))
                .thenReturn(List.of(candidate, lesson(sid, "одобренный", true)));
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                AgentLesson.SOURCE_SYSTEM)).thenReturn(List.of());

        assertEquals(List.of("одобренный"), service.lessonsForScenario(sid, null));
    }

    @Test
    void scenarioMemory_mutationsRequireScenarioAuthor() {
        UUID sid = UUID.randomUUID();
        var scenario = new Scenario();
        scenario.setUserId("AUTHOR");
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenario));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("STRANGER",
                        () -> service.addLesson(sid, "урок", null)));
    }

    @Test
    void compressLessons_replacesWithDistilledRules() {
        UUID sid = UUID.randomUUID();
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid)).thenReturn(List.of(
                lesson(sid, "урок 1", true), lesson(sid, "урок 2", true), lesson(sid, "урок 3", true)));
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"сжатое правило\"]");
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        CurrentUserHolder.withUser("U", () -> {
            List<AgentLessonResponseDto> compressed = service.compressLessons(sid);

            assertEquals(1, compressed.size());
            assertEquals("сжатое правило", compressed.get(0).lesson());
            assertEquals(AgentLesson.SOURCE_AUTO, compressed.get(0).source());
            verify(lessonRepository).deleteAll(anyList());
            return null;
        });
    }

    @Test
    void compressLessons_withoutScenario_compressesOnlyOwnGeneralLessons() {
        // без scenario_id раньше сжимался весь общий пул (IS NULL): системные и чужие уроки стирались
        List<AgentLesson> own = List.of(generalLesson("U", "мой 1"), generalLesson("U", "мой 2"), generalLesson("U", "мой 3"));
        when(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc("U", AgentLesson.SOURCE_SYSTEM))
                .thenReturn(own);
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("[\"сжатое правило\"]");
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        List<AgentLessonResponseDto> compressed = CurrentUserHolder.withUser("U", () -> service.compressLessons(null));

        assertEquals(1, compressed.size());
        assertEquals("U", compressed.get(0).userId());
        assertNull(compressed.get(0).scenarioId());
        verify(lessonRepository).deleteAll(own);
        verify(lessonRepository, never()).findByScenarioIdOrderByCreatedAtDesc(any());
        verify(lessonRepository, never()).findByScenarioIdIsNullOrderByCreatedAtDesc();
    }

    @Test
    void compressLessons_systemLessonsNeverCompressed() {
        UUID sid = UUID.randomUUID();
        AgentLesson system = lesson(sid, "системный", true);
        system.setSource(AgentLesson.SOURCE_SYSTEM);
        List<AgentLesson> users = List.of(lesson(sid, "урок 1", true), lesson(sid, "урок 2", true), lesson(sid, "урок 3", true));
        List<AgentLesson> all = new ArrayList<>(users);
        all.add(system);
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid)).thenReturn(all);
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("[\"сжатое правило\"]");
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        CurrentUserHolder.withUser("U", () -> service.compressLessons(sid));

        verify(lessonRepository).deleteAll(users);
    }

    @Test
    void compressLessons_withoutScenario_tooFewOwnLessons_rejected() {
        when(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc("U", AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(generalLesson("U", "мой 1")));

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser("U", () -> service.compressLessons(null)));
        verify(lessonRepository, never()).deleteAll(anyList());
    }

    @Test
    void generalLesson_updateDeleteApprove_onlyByOwner() {
        AgentLesson foreign = generalLesson("OWNER", "чужой личный урок");
        foreign.setApproved(false);
        when(lessonRepository.findById(foreign.getId())).thenReturn(Optional.of(foreign));
        UUID id = foreign.getId();

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("STRANGER", () -> service.updateLesson(id, "правка")));
        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("STRANGER", () -> {
                    service.deleteLesson(id);
                    return null;
                }));
        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("STRANGER", () -> service.approveLesson(id)));
        assertEquals("чужой личный урок", foreign.getLesson());
        assertFalse(foreign.getApproved());
        verify(lessonRepository, never()).save(any(AgentLesson.class));
        verify(lessonRepository, never()).delete(any(AgentLesson.class));

        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));
        CurrentUserHolder.withUser("OWNER", () -> {
            assertEquals("правка", service.updateLesson(id, "правка").lesson());
            assertTrue(service.approveLesson(id).approved());
            service.deleteLesson(id);
            return null;
        });
        verify(lessonRepository).delete(foreign);
    }

    @Test
    void approveLesson_systemLesson_rejected() {
        AgentLesson system = lesson(null, "системный", true);
        system.setSource(AgentLesson.SOURCE_SYSTEM);
        when(lessonRepository.findById(system.getId())).thenReturn(Optional.of(system));
        UUID id = system.getId();

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser("U", () -> service.approveLesson(id)));
    }

    @Test
    void scenarioMemory_deletedScenario_notFound() {
        // раньше проверка автора молчала для удалённого сценария и урок сохранялся
        UUID sid = UUID.randomUUID();
        when(scenarioRepository.findById(sid)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser("U", () -> service.addLesson(sid, "урок", null)));
        verify(lessonRepository, never()).save(any(AgentLesson.class));
    }

    @Test
    void getLessons_scenarioLessons_requireScenarioAccess() {
        UUID sid = UUID.randomUUID();
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("OWNER", false)));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("STRANGER", () -> service.getLessons(sid)));
        verify(lessonRepository, never()).findByScenarioIdOrderByCreatedAtDesc(any());

        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid)).thenReturn(List.of(lesson(sid, "урок сценария", true)));
        assertEquals(1, CurrentUserHolder.withUser("OWNER", () -> service.getLessons(sid)).size());
    }

    @Test
    void getLessons_sharedScenario_readableByAnyUser() {
        UUID sid = UUID.randomUUID();
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("OWNER", true)));
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid)).thenReturn(List.of(lesson(sid, "урок сценария", true)));

        assertEquals("урок сценария", CurrentUserHolder.withUser("STRANGER", () -> service.getLessons(sid)).get(0).lesson());
    }

    @Test
    void getLessons_deletedScenario_notFound() {
        UUID sid = UUID.randomUUID();
        when(scenarioRepository.findById(sid)).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> CurrentUserHolder.withUser("U", () -> service.getLessons(sid)));
    }

    @Test
    void getLessons_general_returnsSystemAndOwnOnlyNewestFirst() {
        AgentLesson system = generalLesson(null, "системный");
        system.setSource(AgentLesson.SOURCE_SYSTEM);
        system.setCreatedAt(OffsetDateTime.of(2026, 9, 1, 0, 0, 0, 0, ZoneOffset.UTC));
        AgentLesson own = generalLesson("U", "мой");
        own.setCreatedAt(OffsetDateTime.of(2026, 9, 10, 0, 0, 0, 0, ZoneOffset.UTC));
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(system));
        when(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc("U", AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(own));

        List<AgentLessonResponseDto> lessons = CurrentUserHolder.withUser("U", () -> service.getLessons(null));

        // чужие личные уроки не запрашиваются вовсе; порядок — по дате создания, новые первыми
        assertEquals(List.of("мой", "системный"), lessons.stream().map(AgentLessonResponseDto::lesson).toList());
        verify(lessonRepository, never()).findByScenarioIdIsNullOrderByCreatedAtDesc();
    }

    @Test
    void getPlans_requireScenarioAccess() {
        UUID sid = UUID.randomUUID();
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("OWNER", false)));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("STRANGER", () -> service.getPlans(sid)));
        verify(planRepository, never()).findByScenarioIdOrderByUpdatedAtDesc(any());

        when(planRepository.findByScenarioIdOrderByUpdatedAtDesc(sid)).thenReturn(List.of());
        assertEquals(0, CurrentUserHolder.withUser("OWNER", () -> service.getPlans(sid)).size());
    }

    @Test
    void getPlans_sharedScenario_readableByAnyUser() {
        UUID sid = UUID.randomUUID();
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("OWNER", true)));
        when(planRepository.findByScenarioIdOrderByUpdatedAtDesc(sid)).thenReturn(List.of());

        assertEquals(0, CurrentUserHolder.withUser("STRANGER", () -> service.getPlans(sid)).size());
    }

    // -------------------------------------------------------------------------
    // corp15: LLM-вызовы вне транзакции, запись — отдельными транзакциями через self-прокси
    // -------------------------------------------------------------------------

    @Test
    void llmMethods_areNotTransactional_writesAre() throws NoSuchMethodException {
        assertNull(AgentMemoryService.class.getMethod("compressLessons", UUID.class)
                .getAnnotation(Transactional.class));
        assertNull(AgentMemoryService.class.getMethod("extractLessonsFromRun", UUID.class, Map.class)
                .getAnnotation(Transactional.class));
        assertNotNull(AgentMemoryService.class.getMethod("replaceLessons", UUID.class, List.class, List.class)
                .getAnnotation(Transactional.class));
        assertNotNull(AgentMemoryService.class.getMethod("saveLessonCandidates", UUID.class, List.class)
                .getAnnotation(Transactional.class));
    }

    @Test
    void extractLessonsFromRun_callsModelWithoutTransaction_andSavesThroughSelfProxy() {
        AgentMemoryService proxy = spy(service);
        ReflectionTestUtils.setField(service, "self", new AtomicReference<>(proxy));
        UUID sid = UUID.randomUUID();
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenAnswer(inv -> {
            assertFalse(TransactionSynchronizationManager.isActualTransactionActive());
            return "[\"сумма акта — «Итого» с НДС\"]";
        });
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        var saved = service.extractLessonsFromRun(sid, Map.of("критик", "правки"));

        assertEquals(1, saved.size());
        verify(proxy).saveLessonCandidates(eq(sid), anyList());
    }

    @Test
    void compressLessons_callsModelWithoutTransaction_andReplacesThroughSelfProxy() {
        AgentMemoryService proxy = spy(service);
        ReflectionTestUtils.setField(service, "self", new AtomicReference<>(proxy));
        UUID sid = UUID.randomUUID();
        List<AgentLesson> old = List.of(lesson(sid, "урок 1", true), lesson(sid, "урок 2", true), lesson(sid, "урок 3", true));
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenarioOf("U", false)));
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid)).thenReturn(old);
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenAnswer(inv -> {
            assertFalse(TransactionSynchronizationManager.isActualTransactionActive());
            return "[\"сжатое правило\"]";
        });
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        var compressed = CurrentUserHolder.withUser("U", () -> service.compressLessons(sid));

        assertEquals(1, compressed.size());
        verify(proxy).replaceLessons(eq(sid), eq(old), eq(List.of("сжатое правило")));
    }
}
