package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Проверка regex-параметров операций до создания прогона: катастрофический, некорректный и
 * слишком длинный шаблон — отказ запуска с понятным текстом; обычные шаблоны проходят.
 */
class ScenarioRegexValidatorTest {

    /** Вложенные квантификаторы: на длинном повторе «a…a!» движок Java квадратичен (замер — сотни мс на 5 000 символов). */
    private static final String CATASTROPHIC = "(a*)*b";

    private static NodeDto transform(String id, String label, String rules) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label(label).rules(rules).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static GraphDataDto graph(NodeDto... nodes) {
        return new GraphDataDto(List.of(nodes), List.of());
    }

    @Test
    void catastrophicPattern_rejectsRunBeforeItIsCreated() {
        GraphDataDto graph = graph(transform("t1", "Извлечение",
                "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"" + CATASTROPHIC + "\"}]}"));

        ScenarioException e = assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(graph));

        assertTrue(e.getMessage().startsWith(ScenarioRegexValidator.PREFIX), e.getMessage());
        assertTrue(e.getMessage().contains("«шаблон» операции «извлечь_regex» в узле «Извлечение»"), e.getMessage());
        assertTrue(e.getMessage().contains("слишком медленное"), e.getMessage());
        assertTrue(e.getMessage().endsWith(ScenarioRegexValidator.SUFFIX), e.getMessage());
    }

    @Test
    void invalidAndTooLongPatterns_areReported() {
        String tooLong = "a".repeat(600);
        GraphDataDto graph = graph(transform("t1", "Т",
                "{\"операции\": [{\"оп\": \"оставить_строки\", \"шаблон\": \"(\"},"
                        + " {\"оп\": \"удалить_объекты\", \"шаблон\": \"ok\", \"и_шаблон\": \"" + tooLong + "\"}]}"));

        List<String> problems = ScenarioRegexValidator.problemsOf(graph, "");

        assertTrue(problems.get(0).contains("«шаблон» операции «оставить_строки»"), problems.toString());
        assertTrue(problems.get(0).contains("некорректно"), problems.toString());
        assertTrue(problems.get(1).contains("«и_шаблон» операции «удалить_объекты»"), problems.toString());
        assertTrue(problems.get(1).contains("длиннее 512"), problems.toString());
    }

    @Test
    void ordinaryPatterns_pass() {
        GraphDataDto graph = graph(transform("t1", "Т", """
                {"операции": [
                  {"оп": "извлечь_regex", "шаблон": "№\\\\s*(\\\\d+)", "группа": 1},
                  {"оп": "заменить", "найти": "(a+)+$", "на": "x"},
                  {"оп": "сверить_суммы", "метка": "НМЦД?"},
                  {"оп": "слить_json_массивы", "исключить_типы": {"если_не_содержит": "единственн|неконкурентн"}},
                  {"оп": "извлечь_из_документов", "имя": "^ПЗ", "шаблон": "НМЦД[^\\\\d]{0,40}(\\\\d[\\\\d ]+,\\\\d{2})"},
                  {"оп": "уникальные_строки"}
                ]}
                """));

        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(graph));
        assertNull(ScenarioRegexValidator.check("^(ЛОТ\\s*№|Общая информация)"));
    }

    @Test
    void replaceWithRegexFlag_isChecked() {
        GraphDataDto graph = graph(transform("t1", "Т",
                "{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"" + CATASTROPHIC + "\", \"на\": \"\", \"regex\": true}]}"));

        assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(graph));
    }

    @Test
    void subScenarioPatterns_areCheckedToo() {
        UUID subId = UUID.randomUUID();
        Scenario sub = new Scenario();
        sub.setId(subId);
        sub.setName("Вложенный");
        sub.setGraphData(GraphDataMapper.fromDto(graph(transform("s1", "Внутри",
                "{\"операции\": [{\"оп\": \"удалить_строки\", \"шаблон\": \"" + CATASTROPHIC + "\"}]}"))));
        NodeDto subNode = NodeDto.builder()
                .id("sub")
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Под-сценарий").value(subId.toString()).build())
                .position(new PositionDto(0, 0))
                .build();
        GraphDataDto graph = graph(subNode);

        ScenarioException e = assertThrows(ScenarioException.class,
                () -> ScenarioOperationsValidator.validate(graph, UUID.randomUUID(), id -> Optional.of(sub)));

        assertTrue(e.getMessage().contains("в узле «Внутри под-сценария «Вложенный»»"), e.getMessage());
    }
}
