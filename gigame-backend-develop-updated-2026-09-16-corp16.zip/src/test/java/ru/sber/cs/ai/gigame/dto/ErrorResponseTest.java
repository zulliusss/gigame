package ru.sber.cs.ai.gigame.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.config.JacksonConfig;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.ApplicationRuntimeException;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ErrorResponseTest {

    @Test
    void testBuilder_withAllFields() {
        var now = OffsetDateTime.now();
        var details = Map.of("field", "title", "reason", "must not be blank");
        var dto = ErrorResponse.builder()
                .statusCode(400)
                .error("Bad Request")
                .message("Invalid input")
                .timestamp(now)
                .details(details)
                .build();
        assertEquals(400, dto.getStatusCode());
        assertEquals("Bad Request", dto.getError());
        assertEquals("Invalid input", dto.getMessage());
        assertEquals(now, dto.getTimestamp());
        assertEquals(details, dto.getDetails());
    }

    @Test
    void testBuilder_withRequiredOnly() {
        var dto = ErrorResponse.builder()
                .statusCode(500)
                .error("Internal Server Error")
                .message("Something went wrong")
                .timestamp(OffsetDateTime.now())
                .build();
        assertEquals(500, dto.getStatusCode());
        assertEquals("Internal Server Error", dto.getError());
        assertNotNull(dto.getMessage());
        assertNotNull(dto.getTimestamp());
        assertNull(dto.getDetails());
    }

    @Test
    void testOf_createsFromNotFoundException() {
        var ex = new NotFoundException("Not found");
        var dto = ErrorResponse.of(ex);
        assertEquals(404, dto.getStatusCode());
        assertEquals("Not Found", dto.getError());
        assertEquals("Not found", dto.getMessage());
        assertNotNull(dto.getTimestamp());
        assertNull(dto.getDetails());
    }

    @Test
    void testOf_timestampIsUtcMillisAndFitsMaxLength32() throws Exception {
        // на Linux системные часы дают наносекунды, а пояс JVM может быть не UTC — строка вышла бы до 35 символов
        var dto = ErrorResponse.of(new NotFoundException("Not found"));

        assertEquals(ZoneOffset.UTC, dto.getTimestamp().getOffset());
        assertEquals(0, dto.getTimestamp().getNano() % 1_000_000);
        ObjectMapper mapper = new JacksonConfig().objectMapper();
        String timestamp = mapper.readTree(mapper.writeValueAsString(dto)).get("timestamp").asText();
        assertTrue(timestamp.length() <= 32, timestamp);
        assertTrue(timestamp.endsWith("Z"), timestamp);
    }

    @Test
    void testOf_createsFromAccessDeniedException() {
        var ex = new AccessDeniedException("Access denied");
        var dto = ErrorResponse.of(ex);
        assertEquals(403, dto.getStatusCode());
        assertEquals("Forbidden", dto.getError());
        assertEquals("Access denied", dto.getMessage());
        assertNotNull(dto.getTimestamp());
        assertNull(dto.getDetails());
    }

    @Test
    void testOf_createsFromConflictException() {
        var ex = new ApplicationRuntimeException("Conflict", 409) {
        };
        var dto = ErrorResponse.of(ex);
        assertEquals(409, dto.getStatusCode());
        assertEquals("Conflict", dto.getError());
        assertEquals("Conflict", dto.getMessage());
        assertNotNull(dto.getTimestamp());
        assertNull(dto.getDetails());
    }

    @Test
    void testOf_createsFromInternalServerError() {
        var ex = new ApplicationRuntimeException("Internal error", 500) {
        };
        var dto = ErrorResponse.of(ex);
        assertEquals(500, dto.getStatusCode());
        assertEquals("Internal Server Error", dto.getError());
        assertEquals("Internal error", dto.getMessage());
        assertNotNull(dto.getTimestamp());
        assertNull(dto.getDetails());
    }

    @Test
    void testOf_createsFromServiceUnavailableException() {
        var ex = new GigaChatException("Service unavailable");
        var dto = ErrorResponse.of(ex);
        assertEquals(503, dto.getStatusCode());
        assertEquals("Service Unavailable", dto.getError());
        assertEquals("Service unavailable", dto.getMessage());
        assertNotNull(dto.getTimestamp());
        assertNull(dto.getDetails());
    }

    @Test
    void testOf_createsFromUnknownStatusCode() {
        var ex = new ApplicationRuntimeException("Unknown code", 999) {
        };
        var dto = ErrorResponse.of(ex);
        assertEquals(999, dto.getStatusCode());
        assertEquals("Unknown Error", dto.getError());
        assertEquals("Unknown code", dto.getMessage());
        assertNotNull(dto.getTimestamp());
        assertNull(dto.getDetails());
    }

    @Test
    void testGetErrorName_allKnownCodes() {
        var now = OffsetDateTime.now();
        var dto400 = ErrorResponse.builder().statusCode(400).error("Bad Request").message("m").timestamp(now).build();
        assertEquals("Bad Request", dto400.getError());

        var dto403 = ErrorResponse.builder().statusCode(403).error("Forbidden").message("m").timestamp(now).build();
        assertEquals("Forbidden", dto403.getError());

        var dto404 = ErrorResponse.builder().statusCode(404).error("Not Found").message("m").timestamp(now).build();
        assertEquals("Not Found", dto404.getError());

        var dto422 = ErrorResponse.builder().statusCode(422).error("Unprocessable Entity").message("m").timestamp(now).build();
        assertEquals("Unprocessable Entity", dto422.getError());

        var dto500 = ErrorResponse.builder().statusCode(500).error("Internal Server Error").message("m").timestamp(now).build();
        assertEquals("Internal Server Error", dto500.getError());

        var dto503 = ErrorResponse.builder().statusCode(503).error("Service Unavailable").message("m").timestamp(now).build();
        assertEquals("Service Unavailable", dto503.getError());
    }
}