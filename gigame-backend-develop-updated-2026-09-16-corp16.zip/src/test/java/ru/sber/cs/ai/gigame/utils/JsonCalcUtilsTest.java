package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Хелперы разбора JSON: узкая починка десятичной запятой и индекс парных скобок
 * (совпадение со старым посимвольным сканом, линейность на оборванном тексте).
 */
class JsonCalcUtilsTest {

    @Test
    void sanitize_fixesOnlyDecimalCommas() {
        assertEquals("[1,2,3]", JsonCalcUtils.sanitizeDecimalCommas("[1,2,3]"));
        assertEquals("{\"a\": 1234.56}", JsonCalcUtils.sanitizeDecimalCommas("{\"a\": 1234,56}"));
        assertEquals("{\"a\": 5.5, \"b\": 7}", JsonCalcUtils.sanitizeDecimalCommas("{\"a\": 5,5, \"b\": 7}"));
        assertEquals("[1,234,567]", JsonCalcUtils.sanitizeDecimalCommas("[1,234,567]"));
        assertEquals("{\"s\": \"1,5 и 2,5\"}", JsonCalcUtils.sanitizeDecimalCommas("{\"s\": \"1,5 и 2,5\"}"));
        assertEquals("{\"a\": 1,234, \"b\": 1}", JsonCalcUtils.sanitizeDecimalCommas("{\"a\": 1,234, \"b\": 1}"));
    }

    @Test
    void balancedEnd_matchesBrackets() {
        String text = "x {\"a\": [1, {\"b\": \"]}\"}]} y [";

        assertEquals(text.lastIndexOf('}'), JsonCalcUtils.balancedEnd(text, 2));
        assertEquals(text.lastIndexOf(']'), JsonCalcUtils.balancedEnd(text, text.indexOf('[')));
        assertEquals(-1, JsonCalcUtils.balancedEnd(text, text.lastIndexOf('[')));
        assertEquals(-1, JsonCalcUtils.balancedEnd("{\"a\": \"оборвано", 0));
    }

    @Test
    void balancedEnd_equalsPlainScanForEveryBracket() {
        String text = "прим. \"цит [1]\" {\"a\": [1, 2], \"s\": \"[x] {y}\", \"t\": \"без {закрытия\"} хвост [ {\"b\": 1} ] \"незакрытая [\" [2] {";
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '{' || c == '[') {
                assertEquals(JsonCalcUtils.scanBalancedEnd(text, i), JsonCalcUtils.balancedEnd(text, i),
                        "расхождение в позиции " + i);
            }
        }
    }

    @Test
    void balancedEnd_isLinearOnTruncatedText() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < 30_000; i++) {
            sb.append("{\"n\": ").append(i).append("}, ");
        }
        sb.append("{\"n\": \"оборвано");
        String text = sb.toString();
        long start = System.nanoTime();

        int unmatched = 0;
        for (int i = text.indexOf('{'); i >= 0; i = text.indexOf('{', i + 1)) {
            if (JsonCalcUtils.balancedEnd(text, i) < 0) {
                unmatched++;
            }
        }

        long elapsedMillis = (System.nanoTime() - start) / 1_000_000;
        assertEquals(1, unmatched);
        assertEquals(-1, JsonCalcUtils.balancedEnd(text, 0));
        assertTrue(elapsedMillis < 3000, "перебор скобок занял " + elapsedMillis + " мс");
    }
}
