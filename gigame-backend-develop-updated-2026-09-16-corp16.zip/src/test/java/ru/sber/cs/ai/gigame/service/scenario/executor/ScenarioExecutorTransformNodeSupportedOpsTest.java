package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Список поддерживаемых операций узла «Трансформация» не расходится с исполнителем
 * и по нему находятся операции, которых нет в этой версии бэкенда.
 */
class ScenarioExecutorTransformNodeSupportedOpsTest {

    private static final String UNKNOWN = "неизвестная операция";
    private static final Path SOURCE = Path.of("src", "main", "java", "ru", "sber", "cs", "ai", "gigame", "service",
            "scenario", "executor", "ScenarioExecutorTransformNode.java");
    private static final Pattern CASE_LABEL = Pattern.compile("case \"([^\"]+)\" ->");

    private static ScenarioExecutorTransformNode executor() {
        return executor(null);
    }

    private static ScenarioExecutorTransformNode executor(String rules) {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Трансформация").rules(rules).build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        return new ScenarioExecutorTransformNode(graph.getNodeMap().get("t1"));
    }

    @Test
    void everySupportedOperationIsHandledByApply() {
        ScenarioExecutorTransformNode executor = executor();

        for (String operation : ScenarioExecutorTransformNode.SUPPORTED_OPERATIONS) {
            // без параметров операция может завершиться своей ошибкой, но не веткой default
            String result = executor.runOperation(operation, Map.of(), "");
            assertFalse(result.contains(UNKNOWN), operation + ": " + result);
        }
        assertTrue(executor.runOperation("операция_из_будущего", Map.of(), "").contains(UNKNOWN));
    }

    @Test
    void supportedOperationsMatchSwitchLabelsOfApply() throws IOException {
        String source = Files.readString(SOURCE, StandardCharsets.UTF_8);
        int start = source.indexOf("private String apply(");
        int end = source.indexOf("default -> throw new ScenarioException(\"Узел «Трансформация»: неизвестная операция", start);
        assertTrue(start > 0 && end > start, "не найден switch метода apply");
        Set<String> labels = new TreeSet<>();
        Matcher m = CASE_LABEL.matcher(source.substring(start, end));
        while (m.find()) {
            labels.add(m.group(1));
        }

        assertEquals(new TreeSet<>(ScenarioExecutorTransformNode.SUPPORTED_OPERATIONS), labels);
    }

    @Test
    void knownOperationsAreNotReported() {
        String rules = "{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"a\", \"на\": \"b\"}, {\"оп\": \"уникальные_строки\"}]}";

        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations(rules));
    }

    @Test
    void unknownOperationsAreReportedInOrderWithoutDuplicates() {
        String rules = "{\"операции\": [{\"оп\": \"новая_б\"}, {\"оп\": \"заменить\"}, {\"оп\": \"новая_а\"}, {\"оп\": \"новая_б\"}]}";

        assertEquals(List.of("новая_б", "новая_а"), ScenarioExecutorTransformNode.unsupportedOperations(rules));
    }

    @Test
    void emptyOrBrokenRulesAreLeftToExecutor() {
        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations(null));
        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations("  "));
        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations("[]"));
        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations("{\"операции\": [{\"оп\": "));
        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations("{\"другое\": 1}"));
        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations("{\"операции\": {\"оп\": \"новая\"}}"));
        // не объект — исполнитель такой элемент пропускает
        assertEquals(List.of(), ScenarioExecutorTransformNode.unsupportedOperations("{\"операции\": [\"новая\", 5]}"));
    }

    @Test
    void operationWithoutNameIsReportedAsNotSet() {
        String notSet = ScenarioExecutorTransformNode.OPERATION_NOT_SET;

        assertEquals("(не задана)", notSet);
        assertEquals(List.of(notSet), ScenarioExecutorTransformNode.unsupportedOperations(
                "{\"операции\": [{\"шаблон\": \"x\"}, {\"оп\": \"заменить\"}, {\"оп\": null}]}"));
        assertEquals(List.of(notSet, "новая"), ScenarioExecutorTransformNode.unsupportedOperations(
                "{\"операции\": [{\"оп\": null}, {\"оп\": \"новая\"}, {\"оп\": {\"имя\": \"заменить\"}}]}"));
    }

    @Test
    void executorFailsOnOperationWithoutName() {
        // тот же объект без «оп» исполнитель не выполняет — поэтому проверка графа его не пропускает
        ScenarioExecutorTransformNode executor = executor("{\"операции\": [{\"шаблон\": \"x\"}]}");

        ScenarioException ex = assertThrows(ScenarioException.class, () -> executor.execute(null));

        assertTrue(ex.getMessage().contains(UNKNOWN), ex.getMessage());
    }
}
