package ru.sber.cs.ai.gigame.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.wp.usermodel.HeaderFooterType;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.junit.jupiter.api.Test;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTR;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Молчаливые потери при разборе: колонтитулы, сноски и текстовые поля DOCX,
 * формулы и даты бинарного XLS, кодировки TXT, постраничная проверка PDF.
 */
class DocumentServiceParsingLossTest {

    private final DocumentService service = new DocumentService(null, null, null);

    private static byte[] docxWithHeaderFootnoteAndTextbox() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XWPFDocument doc = new XWPFDocument()) {
            XWPFParagraph body = doc.createParagraph();
            body.createRun().setText("Тело договора № 4286515.");
            XWPFRun boxRun = body.createRun();
            boxRun.getCTR().set(CTR.Factory.parse("<w:r xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" "
                    + "xmlns:v=\"urn:schemas-microsoft-com:vml\"><w:pict><v:shape><v:textbox><w:txbxContent><w:p><w:r>"
                    + "<w:t>Штамп: подписано ЭДО</w:t></w:r></w:p></w:txbxContent></v:textbox></v:shape></w:pict></w:r>"));
            doc.createHeader(HeaderFooterType.DEFAULT).createParagraph().createRun().setText("Договор № 4286515 от 09.09.2022");
            doc.createFooter(HeaderFooterType.DEFAULT).createParagraph().createRun().setText("Договор № 4286515 от 09.09.2022");
            doc.createFootnotes();
            doc.createFootnote().createParagraph().createRun().setText("Цены указаны с НДС.");
            doc.write(out);
        }
        return out.toByteArray();
    }

    @Test
    void docxHeadersFootnotesAndTextBoxesAreExtracted() throws Exception {
        String text = service.parseText(new ByteArrayInputStream(docxWithHeaderFootnoteAndTextbox()), "docx");

        assertTrue(text.startsWith("Тело договора № 4286515."), text);
        assertTrue(text.contains("[текстовое поле: Штамп: подписано ЭДО]"), text);
        assertTrue(text.contains(DocumentService.DOCX_HEADERS_BLOCK + "\nДоговор № 4286515 от 09.09.2022"), text);
        // одинаковый верхний и нижний колонтитул даётся один раз
        assertEquals(1, text.split("Договор № 4286515 от 09.09.2022", -1).length - 1, text);
        assertTrue(text.contains(DocumentService.DOCX_FOOTNOTES_BLOCK + "\n[1] Цены указаны с НДС."), text);
    }

    @Test
    void docxWithoutHeadersKeepsPlainBody() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XWPFDocument doc = new XWPFDocument()) {
            doc.createParagraph().createRun().setText("Просто текст");
            doc.write(out);
        }

        assertEquals("Просто текст", service.parseText(new ByteArrayInputStream(out.toByteArray()), "docx"));
    }

    @Test
    void xlsFormulaIsNotRecalculatedAndDatesAreRussian() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (HSSFWorkbook wb = new HSSFWorkbook()) {
            var sheet = wb.createSheet("Форма");
            var row = sheet.createRow(0);
            row.createCell(0).setCellValue(42);
            // функция, которой нет в POI: пересчёт бросал NotImplementedException и ронял весь файл
            var formula = row.createCell(1);
            formula.setCellFormula("MYCORPFUNC(A1)");
            formula.setCellValue(84);
            var date = row.createCell(2);
            date.setCellValue(java.time.LocalDate.of(2020, 7, 1));
            var style = wb.createCellStyle();
            style.setDataFormat(wb.getCreationHelper().createDataFormat().getFormat("m/d/yy"));
            date.setCellStyle(style);
            wb.write(out);
        }

        String text = service.parseText(new ByteArrayInputStream(out.toByteArray()), "xls");

        assertEquals("42 | 84 | 01.07.2020\n", text);
    }

    @Test
    void txtBomIsStrippedAndUtf16IsDetected() throws IOException {
        byte[] utf8Bom = new byte[]{(byte) 0xEF, (byte) 0xBB, (byte) 0xBF};
        byte[] body = "Заявка №104 от 15.04.2024".getBytes(StandardCharsets.UTF_8);
        byte[] withBom = new byte[utf8Bom.length + body.length];
        System.arraycopy(utf8Bom, 0, withBom, 0, 3);
        System.arraycopy(body, 0, withBom, 3, body.length);

        assertEquals("Заявка №104 от 15.04.2024", service.parseText(new ByteArrayInputStream(withBom), "txt"));
        assertEquals("Заявка №104 от 15.04.2024", service.parseText(
                new ByteArrayInputStream("Заявка №104 от 15.04.2024".getBytes(StandardCharsets.UTF_16LE)), "txt"));
        assertEquals("Заявка №104 от 15.04.2024", service.parseText(
                new ByteArrayInputStream("Заявка №104 от 15.04.2024".getBytes(StandardCharsets.UTF_16)), "txt"));
    }

    @Test
    void txtLegacyCodepagesAreChosenByReadableShare() throws IOException {
        String source = "Спецификация № 4787401 к договору";

        assertEquals(source, service.parseText(new ByteArrayInputStream(source.getBytes(Charset.forName("windows-1251"))), "txt"));
        assertEquals(source, service.parseText(new ByteArrayInputStream(source.getBytes(Charset.forName("CP866"))), "txt"));
    }

    @Test
    void txtUnreadableEncodingGetsMarker() throws IOException {
        // байты 0xB0–0xBF: не UTF-8, в CP866 — псевдографика, в windows-1251 — символы вне букв
        byte[] garbage = new byte[64];
        for (int i = 0; i < garbage.length; i++) {
            garbage[i] = (byte) (0xB0 + i % 16);
        }

        String text = service.parseText(new ByteArrayInputStream(garbage), "txt");

        assertTrue(text.startsWith(DocumentService.ENCODING_MARKER + "\n"), text);
        assertTrue(DocumentService.readableShare("Обычный текст, 123 руб.") > 0.9);
    }

    private static byte[] pdf(String... pageTexts) throws IOException {
        try (PDDocument doc = new PDDocument()) {
            for (String text : pageTexts) {
                addPage(doc, text);
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private static void addPage(PDDocument doc, String text) throws IOException {
        PDPage page = new PDPage();
        doc.addPage(page);
        if (text.isEmpty()) {
            return;
        }
        try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
            cs.beginText();
            cs.setFont(new PDType1Font(Standard14Fonts.FontName.HELVETICA), 12);
            cs.newLineAtOffset(50, 700);
            cs.showText(text);
            cs.endText();
        }
    }

    @Test
    void pdfPageTextsAndTextlessPagesFindImagePagesOfMixedDocument() throws IOException {
        String longText = "Document signed and transferred via EDO operator, registration number 12345";
        List<String> pages = service.pdfPageTexts(pdf(longText, "", longText, "", longText));

        assertEquals(5, pages.size());
        assertEquals(List.of(2, 4), service.textlessPages(pages));
        // две страницы-картинки из пяти — не скан, а смешанный документ
        assertFalse(service.isScanPdf(pdf(longText, "", longText, "", longText), longText.repeat(3)));
        assertTrue(service.pdfPageTexts("not a pdf".getBytes()).isEmpty());
    }
}
