package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты разбора актов сдачи-приёмки (Сбер, docx/pdf) и распознанных
 * заявок/актов Альфа-Банка (вид и реквизиты по имени файла).
 */
class Form3ActsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static final String SBER_ACT = """
            АКТ
            сдачи-приёмки работ по
            Спецификации на разработку программного обеспечения № 4787401 от 17.11.2023г.
            к Договору № 4286515 на разработку/модификацию программного обеспечения
            от 09.09.2022 г.
            г. Москва \t\t «08» апреля 2025 г.
            Публичное акционерное общество «Сбербанк России», ПАО Сбербанк, именуемое в дальнейшем «Заказчик», в лице Вице-президента, \
            и Общество с ограниченной ответственностью «Хинт», ООО «Хинт», именуемое в дальнейшем «Исполнитель», в лице директора, \
            заключили настоящий акт о том, что по Спецификации № 4787401 к Договору № 4286515 от «09» сентября 2022 г. \
            Исполнителем переданы, а Заказчиком приняты Результаты работ.
            Общая стоимость работ по Этапу №2 в соответствии со Спецификацией составляет 1 712 787,00 (Один миллион) рублей.
            Следует к оплате по Акту 1 712 787,00 (Один миллион) рублей за период работа с 01.01.2025 по 31.03.2025г.
            1 | Сервис Jazz. Разработка 3D режима конференции для Android | Главный разработчик Android | 69 | 24 823,00 | 1 712 787,00
            """;

    static final String ALFA_ACT_OCR = """
            [РАСПОЗНАНО ИЗ СКАНА — данные извлечены автоматическим распознаванием] Документ «Заявка №104 Акт №б-н от 27.04.24.pdf»:
            Акт сдачи-приемки работ по Заявке № 104 от 15.04.2024 к Договору № АБ-С-ИТ-2020 от 03.02.2020
            ООО «Хинт», именуемое в дальнейшем «Исполнитель», с одной стороны, и АО «АЛЬФА-БАНК», именуемое в дальнейшем «Заказчик»
            Работы по разработке мобильного приложения Android выполнены. Итого с НДС: 22 849 905,00
            Подписи получателя АКЦИОНЕРНОЕ ОБЩЕСТВО "АЛЬФА-БАНК" 14.05.2024 Подпись соответствует файлу документа
            """;

    static final String OCR_ACT = """
            [РАСПОЗНАНО ИЗ СКАНА — суммы рекомендуется перепроверить] Документ «4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf»:
            Тип документа: Акт сдачи-приемки работ
            Реквизиты:
            - Дата акта: "20" декабря 2023 г.
            - Спецификация: №4653728 от 04.07.2023 г.
            - Договор: №4412866 от 01.12.2022 г.
            Стороны:
            - Заказчик: Публичное акционерное общество «Сбербанк России», ПАО Сбербанк
            | 1 | PFMASSETS-5760, [iOS] Сделать возможность оценки недвижимости |
            Суммы:
            - Стоимость этапа №2: 2 729 995,22 рубля
            """;

    @Test
    void sberActIsRecognizedByHeadingAndParsed() {
        assertTrue(Form3Acts.isAct("4787401 Акт Э2.docx", SBER_ACT));
        assertTrue(Form3Acts.isAct("Э2.docx", SBER_ACT));
        assertFalse(Form3Acts.isOrder("4787401 Акт Э2.docx", SBER_ACT));

        Map<String, Object> act = Form3Acts.parseAct("4787401 Акт Э2.docx", SBER_ACT);

        assertEquals("4787401", act.get("спецификация"));
        assertEquals("4286515", act.get("договор"));
        assertEquals("08.04.2025", act.get("дата"));
        assertEquals("1712787.00", act.get("сумма"));
        assertEquals("ПАО Сбербанк", act.get("покупатель"));
        assertEquals("ООО «Хинт»", act.get("продавец"));
        assertEquals(Boolean.TRUE, act.get("подпись_заказчика"));
        assertTrue(String.valueOf(act.get("подпись_примечание")).contains("не подтверждена"));
    }

    @Test
    void alfaFilesAreClassifiedByNameAndDatedFromName() {
        assertTrue(Form3Acts.isAct("Заявка №104 Акт №б-н от 27.04.24.pdf", ALFA_ACT_OCR));
        assertTrue(Form3Acts.isOrder("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка на выполнение работ iOS"));
        assertFalse(Form3Acts.isAct("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка на выполнение работ iOS"));
        assertFalse(Form3Acts.isAct("_ТЗ, кал. план, спецификация, форма акта-1_merge.pdf", "Техническое задание"));

        Map<String, Object> act = Form3Acts.parseAct("Заявка №104 от 15.04.2024 Акт №б-н от 27.04.2024.pdf", ALFA_ACT_OCR);
        assertEquals("104", act.get("заявка"));
        assertEquals("27.04.2024", act.get("дата"));
        assertEquals("22849905.00", act.get("сумма"));
        assertEquals("", act.get("подпись_примечание"));
        assertEquals("АО «АЛЬФА-БАНК»", act.get("покупатель"));
        assertEquals("ООО «Хинт»", act.get("продавец"));

        Map<String, Object> order = Form3Acts.parseOrder("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка iOS");
        assertEquals("104", order.get("номер"));
        assertEquals("15.04.2024", order.get("дата"));
        assertEquals("заявка", order.get("вид"));
    }

    @Test
    void registryPutsActsAndOrdersInPlace() throws Exception {
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("4787401 Акт Э2.docx", SBER_ACT),
                new Form3Ops.Source("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка на Android"),
                new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf", ALFA_ACT_OCR)));
        Map<?, ?> registry = MAPPER.readValue(json, Map.class);

        assertEquals(2, ((List<?>) registry.get("акты")).size());
        assertEquals(1, ((List<?>) registry.get("спецификации")).size());
        assertEquals(0, ((List<?>) registry.get("прочее")).size());
    }

    @Test
    void recognizedActUsesLabelDateNotSpecificationDateFromFileName() {
        assertTrue(Form3Acts.isAct("4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf", OCR_ACT));
        assertTrue(Form3Acts.isAct("скан-без-имени.pdf", OCR_ACT));

        Map<String, Object> act = Form3Acts.parseAct("4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf", OCR_ACT);

        assertEquals("20.12.2023", act.get("дата"));
        assertEquals("4653728", act.get("спецификация"));
        assertEquals("4412866", act.get("договор"));
        assertTrue(((List<?>) act.get("суммы")).contains("2729995.22"));
        assertEquals("", Form3Acts.actNameDate("4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf"));
        assertEquals("27.04.2024", Form3Acts.actNameDate("Заявка №104 от 15.04.2024 Акт №б-н от 27.04.24.pdf"));
        assertEquals("", Form3Acts.actNameDate("АКТ №1 по Заявке №50 от 17.06.25.pdf"));
    }

    @Test
    void recognizedSpecificationAndContractAreClassifiedByTypeLine() throws Exception {
        String spec = "[РАСПОЗНАНО] Документ «3. 4801685.pdf»:\nТип документа: Спецификация\nРеквизиты документа: № 4801685\n"
                + "Основание: Договор № 4412866 от «01» декабря 2022 г.\nГлавный разработчик iOS SB | 114 | 2 550 979,14";
        String contract = "[РАСПОЗНАНО] Документ «Договор.pdf»:\nТип документа: Договор № АБ-С-ИТ-2020 от 03.02.2020\nПредмет: разработка";
        Map<?, ?> registry = MAPPER.readValue(Form3Ops.registry(List.of(new Form3Ops.Source("3. 4801685.pdf", spec),
                new Form3Ops.Source("Договор №АБ-С-ИТ-2020.pdf", contract))), Map.class);

        assertEquals(1, ((List<?>) registry.get("спецификации")).size());
        assertEquals(1, ((List<?>) registry.get("договоры")).size());
        assertEquals("4801685", ((Map<?, ?>) ((List<?>) registry.get("спецификации")).get(0)).get("номер"));
        assertEquals("АБ-С-ИТ-2020", ((Map<?, ?>) ((List<?>) registry.get("договоры")).get(0)).get("номер"));
    }

    @Test
    void contractHeadingsWithPrefixesAreClassified() throws Exception {
        String framework = "Рамочный Договор № 5147758 на разработку/модификацию программного обеспечения\nг. Москва\n"
                + "Аналитик: опыт работы с технологиями Hadoop";
        String numbered = "1 ДОГОВОР № 32514746233 на выполнение работ по разработке алгоритмов для нужд АО «Россельхозбанк»\n"
                + "на базе программного обеспечения СУБД GreenPlum";
        Map<?, ?> registry = MAPPER.readValue(Form3Ops.registry(List.of(new Form3Ops.Source("Договор 5147758.pdf", framework),
                new Form3Ops.Source("Договор №32514746233.pdf", numbered),
                new Form3Ops.Source("ДС № 04.pdf", "Дополнительное соглашение №4 к Договору № ШТ-2023 от 21 апреля 2023"))), Map.class);

        List<?> contracts = (List<?>) registry.get("договоры");
        assertEquals(2, contracts.size());
        assertEquals("5147758", ((Map<?, ?>) contracts.get(0)).get("номер"));
        assertEquals("32514746233", ((Map<?, ?>) contracts.get(1)).get("номер"));
    }

    @Test
    void headingDateIgnoresContractDateInWords() {
        assertEquals("15.11.2023", Form3Acts.headingDate("к Договору от «09» сентября 2022 г.\nг. Москва «15» ноября 2023 г."));
        assertEquals("20.12.2023", Form3Acts.headingDate("г. Москва \nг. \n«-20- » декабря 2023"));
        assertEquals("", Form3Acts.headingDate("без города «15» ноября 2023 г."));
    }

    @Test
    void namesFromArchivesAreMatchedByBaseName() {
        // путь из архива: слово «акт» в имени папки не делает актом любой файл, а «Заявка №…» узнаётся после «/»
        assertFalse(Form3Acts.isAct("Акты 2024.zip/договор.pdf", "Договор № 5 на оказание услуг"));
        assertTrue(Form3Acts.isAct("комплект.zip/Акт №б-н от 27.04.24.pdf", "текст"));
        assertTrue(Form3Acts.isOrder("комплект.zip/Заявки/Заявка №104 от 15.04.2024.pdf", "текст"));
        assertFalse(Form3Acts.isOrder("Заявка №104 от 15.04.2024/договор.pdf", "Договор"));
        assertEquals("104", Form3Acts.parseOrder("комплект.zip/Заявка №104 от 15.04.2024.pdf", "текст").get("номер"));
        assertEquals("15.04.2024", Form3Acts.parseOrder("комплект.zip/Заявка №104 от 15.04.2024.pdf", "текст").get("дата"));
        assertEquals("27.04.2024", Form3Acts.parseAct("Заявки от 01.01.2020/Заявка №104 Акт №б-н от 27.04.24.pdf", "текст").get("дата"));
    }
}
