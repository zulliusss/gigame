package ru.sber.cs.ai.gigame.service;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Потоковый разбор XLSX даёт тот же текст, что DOM-парсер: листы с заголовками,
 * ячейки через " | ", пропуски как пустые ячейки, формулы — значением.
 */
class XlsxStreamingParserTest {

    private static byte[] workbook(boolean twoSheets) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            var sheet = wb.createSheet("1300");
            var row = sheet.createRow(0);
            row.createCell(0).setCellValue("ПАО Сбербанк_10000203");
            row.createCell(2).setCellValue("ВСП_10039053");
            row.createCell(3).setCellValue(10039053);
            row.createCell(4).setCellValue("ВСП\nотделения");
            var formula = sheet.createRow(2);
            formula.createCell(0).setCellValue(5);
            formula.createCell(1).setCellValue(7);
            formula.createCell(2).setCellFormula("A3+B3");
            var dateCell = formula.createCell(3);
            dateCell.setCellValue(java.time.LocalDate.of(2020, 7, 1));
            var dateStyle = wb.createCellStyle();
            dateStyle.setDataFormat(wb.getCreationHelper().createDataFormat().getFormat("m/d/yy"));
            dateCell.setCellStyle(dateStyle);
            wb.getCreationHelper().createFormulaEvaluator().evaluateAll();
            if (twoSheets) {
                wb.createSheet("1600").createRow(0).createCell(0).setCellValue("ВИП ВСП_10312080");
            }
            wb.write(out);
        }
        return out.toByteArray();
    }

    @Test
    void singleSheetRowsKeepEmptyCellsFormulasAndFlattenedText() throws Exception {
        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(workbook(false)), 100, 100_000);

        assertEquals("ПАО Сбербанк_10000203 |  | ВСП_10039053 | 10039053 | ВСП отделения\n5 | 7 | 12 | 01.07.2020\n", text);
    }

    @Test
    void severalSheetsGetHeadersAndBlankLineBetween() throws Exception {
        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(workbook(true)), 100, 100_000);

        assertTrue(text.startsWith("=== Лист: 1300 ===\nПАО Сбербанк_10000203 |  | ВСП_10039053"));
        assertTrue(text.contains("5 | 7 | 12 | 01.07.2020\n\n=== Лист: 1600 ===\nВИП ВСП_10312080\n"));
    }

    @Test
    void rowsBeyondLimitAreDroppedWithMarker() throws Exception {
        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(workbook(true)), 100, 1);

        // маркер обрезки — на каждом затронутом листе, а не только на первом
        assertEquals("=== Лист: 1300 ===\nПАО Сбербанк_10000203 |  | ВСП_10039053 | 10039053 | ВСП отделения\n"
                + "[...обрезано: больше 1 строк]\n\n=== Лист: 1600 ===\n[...обрезано: больше 1 строк]\n", text);
    }

    @Test
    void formulaWithoutCachedValueIsShownAsFormula() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            var row = wb.createSheet("Расчёт").createRow(0);
            row.createCell(0).setCellValue(2);
            // формула без пересчёта (книга из библиотеки без вычисления): сохранённого значения нет
            row.createCell(1).setCellFormula("A1*21");
            wb.write(out);
        }

        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(out.toByteArray()), 100, 100_000);

        assertEquals("2 | =A1*21\n", text);
    }

    @Test
    void sheetsBeyondLimitAreListedInMarker() throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (XSSFWorkbook wb = new XSSFWorkbook()) {
            wb.createSheet("Первый").createRow(0).createCell(0).setCellValue("a");
            wb.createSheet("Второй").createRow(0).createCell(0).setCellValue("b");
            wb.createSheet("Третий").createRow(0).createCell(0).setCellValue("c");
            wb.write(out);
        }

        String text = XlsxStreamingParser.parse(new ByteArrayInputStream(out.toByteArray()), 1, 100_000);

        assertEquals("=== Лист: Первый ===\na\n\n[... листы сверх лимита 1 не разобраны (2): Второй, Третий ...]\n", text);
    }
}
