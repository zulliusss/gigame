package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.reactivestreams.Publisher;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.reactive.socket.HandshakeInfo;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
class ScenarioWebSocketHandlerTest {

    private static final UUID SCENARIO_ID = UUID.fromString("123e4567-e89b-12d3-a456-426614174000");

    private ScenarioWebSocketHandler handler;
    private ScenarioService scenarioService;
    private WebSocketSessionManager sessionManager;
    private ObjectMapper objectMapper;
    private DocsTextCacheService docsTextCacheService;
    private ScenarioUploadTaskService scenarioUploadTaskService;
    private WebSocketSession webSocketSession;

    @BeforeEach
    void setUp() {
        scenarioService = mock(ScenarioService.class);
        ScenarioEngine scenarioEngine = mock(ScenarioEngine.class);
        sessionManager = mock(WebSocketSessionManager.class);
        objectMapper = new ObjectMapper();
        docsTextCacheService = mock(DocsTextCacheService.class);
        scenarioUploadTaskService = mock(ScenarioUploadTaskService.class);

        handler = new ScenarioWebSocketHandler(
                scenarioService,
                scenarioEngine,
                sessionManager,
                objectMapper,
                scenarioUploadTaskService
        );

        // Mock DocsTextCacheService to return empty list instead of null
        when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());

        // Create a mock WebSocketSession
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        headers.put("X-UserId", List.of("test-user-id"));
        when(handshakeInfo.getHeaders()).thenReturn(headers);

        webSocketSession = mock(WebSocketSession.class);
        when(webSocketSession.getId()).thenReturn("test-session-id");
        when(webSocketSession.getHandshakeInfo()).thenReturn(handshakeInfo);
        when(webSocketSession.isOpen()).thenReturn(true);
        when(webSocketSession.textMessage(anyString())).thenReturn(mock(WebSocketMessage.class));
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
    }

    @Test
    void testHandle_addsSession() {
        when(webSocketSession.receive()).thenReturn(Flux.empty());
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);

        handler.handle(webSocketSession).block();

        verify(sessionManager, times(1)).addSession(webSocketSession);
    }

    @Test
    void testHandle_removesSessionOnTerminate() {
        when(webSocketSession.receive()).thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(sessionManager, times(1)).removeSession(webSocketSession);
    }

    @Test
    void testHandle_processesIncomingMessage() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), anyBoolean()))
                .thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(scenarioService, times(1)).runScenario(
                UUID.fromString("123e4567-e89b-12d3-a456-426614174000"),
                true
        );
    }

    @Test
    void testHandle_sendsErrorMessageOnJsonParseError() {
        String invalidPayload = "{ invalid json }";

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(invalidPayload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        handler.handle(webSocketSession).block();

        verify(webSocketSession, times(1)).send(any());
    }

    @Test
    void testHandle_sendsErrorMessageOnSessionClosed() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        // Session not found
        when(sessionManager.getSession("test-session-id")).thenReturn(null);

        handler.handle(webSocketSession).block();
        verify(webSocketSession).receive();
    }

    @Test
    void testHandle_sessionNotFound() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(null);

        handler.handle(webSocketSession).block();

        verify(scenarioService, never()).runScenario(any(), anyBoolean());
    }

    @Test
    void testHandle_emptyDocumentsText() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), anyBoolean()))
                .thenReturn(Flux.empty());
        when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());

        handler.handle(webSocketSession).block();

        verify(scenarioService, times(1)).runScenario(
                any(),
                anyBoolean());
    }

    @Test
    void testHandle_withDocumentsText() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": false
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), anyBoolean()))
                .thenReturn(Flux.empty());
        when(docsTextCacheService.getCachedDocumentTexts(any()))
                .thenReturn(List.of("cached document text"));

        handler.handle(webSocketSession).block();

        verify(scenarioService, times(1)).runScenario(
                any(),
                eq(false)
        );
    }

    @Test
    void testHandle_errorSerialization() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), anyBoolean()))
                .thenReturn(Flux.error(new RuntimeException("Test error")));

        handler.handle(webSocketSession).block();
        verify(scenarioService).runScenario(any(), anyBoolean());
    }

    @Test
    void testHandle_withNullUserIdInHeaders() {
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        // No X-UserId
        when(handshakeInfo.getHeaders()).thenReturn(headers);

        WebSocketSession session = mock(WebSocketSession.class);
        when(session.getId()).thenReturn("test-session-id-2");
        when(session.getHandshakeInfo()).thenReturn(handshakeInfo);
        when(session.isOpen()).thenReturn(true);
        when(session.receive()).thenReturn(Flux.empty());

        handler.handle(session).block();

        verify(sessionManager, times(1)).addSession(session);
    }

    @Test
    void testHandle_createsStreamEvent() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with data
        Map<String, Object> eventData = Map.of("type", "status", "message", "Running");
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(eventData).build();
        when(scenarioService.runScenario(any(), anyBoolean()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();

        // Verify that the message was sent with correct structure
        ArgumentCaptor<Flux<WebSocketMessage>> fluxCaptor = ArgumentCaptor.forClass(Flux.class);
        verify(webSocketSession, times(1)).send(fluxCaptor.capture());

        Flux<?> capturedFlux = fluxCaptor.getValue();
        List<?> messages = capturedFlux.collectList().block();

        assertNotNull(messages);
        assertEquals(1, messages.size());
    }

    @Test
    void testHandle_emptyDataInStreamEvent() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with null data
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(null).build();
        when(scenarioService.runScenario(any(), anyBoolean()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();
        verify(scenarioService).runScenario(any(), anyBoolean());
    }

    @Test
    void testScenarioMessageRecord() throws Exception {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        ScenarioWebSocketHandler.ScenarioMessage message = objectMapper.readValue(
                payload,
                ScenarioWebSocketHandler.ScenarioMessage.class
        );

        assertEquals("123e4567-e89b-12d3-a456-426614174000", message.scenarioId());
        assertTrue(message.stepMode());
    }

    @Test
    void testScenarioMessageRecord_falseStepMode() throws Exception {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": false
                }
                """;

        ScenarioWebSocketHandler.ScenarioMessage message = objectMapper.readValue(
                payload,
                ScenarioWebSocketHandler.ScenarioMessage.class
        );

        assertEquals("123e4567-e89b-12d3-a456-426614174000", message.scenarioId());
        assertFalse(message.stepMode());
    }

    @Test
    void testHandle_ownUploadProcessing_blocksRun() {
        // асинхронная загрузка подключённого пользователя ещё разбирается — прогон не стартует, клиенту ошибка
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(scenarioUploadTaskService.isProcessing(SCENARIO_ID, "test-user-id")).thenReturn(true);

        handler.handle(webSocketSession).block();

        verify(scenarioService, never()).runScenario(any(), anyBoolean());
        verify(webSocketSession, times(1)).send(any());
    }

    @Test
    void testHandle_otherUsersUploadProcessing_doesNotBlockRun() {
        // общий сценарий: идущая загрузка другого пользователя не блокирует запуск подключённого
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(scenarioUploadTaskService.isProcessing(SCENARIO_ID, "other-user")).thenReturn(true);
        when(scenarioService.runScenario(any(), anyBoolean())).thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(scenarioUploadTaskService).isProcessing(SCENARIO_ID, "test-user-id");
        verify(scenarioUploadTaskService, never()).isProcessing(SCENARIO_ID, "other-user");
        verify(scenarioService, times(1)).runScenario(SCENARIO_ID, false);
    }

    @Test
    void testHandle_runsScenarioAsConnectedUser() {
        // документы прогона ищутся по пользователю из CurrentUserHolder — он должен быть подключённым, а не пустым;
        // отдельный пользователь, чтобы не совпасть с устаревшим значением ThreadLocal потока от других тестов
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        headers.put("X-UserId", List.of("RUNNER42"));
        when(handshakeInfo.getHeaders()).thenReturn(headers);
        when(webSocketSession.getHandshakeInfo()).thenReturn(handshakeInfo);
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        AtomicReference<String> userAtRun = new AtomicReference<>();
        when(scenarioService.runScenario(any(), anyBoolean())).thenAnswer(inv -> {
            userAtRun.set(CurrentUserHolder.getCurrentUser());
            return Flux.empty();
        });

        handler.handle(webSocketSession).block();

        assertEquals("RUNNER42", userAtRun.get());
        verify(scenarioUploadTaskService).isProcessing(SCENARIO_ID, "RUNNER42");
    }

    @Test
    void testHandle_withoutUserHeader_checksAnonymousUpload() {
        // без X-UserId в handshake пользователь — «anonymous», как и при HTTP-загрузке без заголовка
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        when(handshakeInfo.getHeaders()).thenReturn(new HttpHeaders());
        when(webSocketSession.getHandshakeInfo()).thenReturn(handshakeInfo);
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(scenarioService.runScenario(any(), anyBoolean())).thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(scenarioUploadTaskService).isProcessing(SCENARIO_ID, "anonymous");
        verify(scenarioService, times(1)).runScenario(SCENARIO_ID, false);
    }

    @Test
    void testHandle_rejectedLaunchSendsStatusFailedWithReason() throws Exception {
        // проверка графа до создания прогона отклонила запуск — клиент получает STATUS FAILED с полным текстом причины
        // (по нему интерфейс выходит из фазы выполнения) и прежнее поле error
        String reason = "Сценарий использует операции, которых нет в этой версии бэкенда: «свести_риски» в узле «Свод» "
                + "— обновите дистрибутив бэкенда";
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(scenarioService.runScenario(any(), anyBoolean())).thenThrow(new ScenarioException(reason));

        JsonNode frame = objectMapper.readTree(sentSingleFrame());

        assertEquals("STATUS", frame.path("type").asText());
        assertEquals("FAILED", frame.path("data").path("status").asText());
        assertEquals(reason, frame.path("data").path("error").asText());
        assertFalse(frame.path("data").has("run_id"), "прогон не создан — run_id в кадре нет");
        assertEquals("Ошибка обработки сообщения: " + reason, frame.path("error").asText());
        assertEquals("test-session-id", frame.path("session_id").asText());
    }

    @Test
    void testHandle_rejectedResumeSendsStatusFailedWithReason() throws Exception {
        // возобновление отклонено той же проверкой: клиент возобновления по-прежнему видит поле error
        String reason = "Сценарий использует операции, которых нет в этой версии бэкенда: «новая» в узле «t1» "
                + "— обновите дистрибутив бэкенда";
        WebSocketMessage message = mock(WebSocketMessage.class);
        when(message.getPayloadAsText()).thenReturn("{\"type\": \"resume\", \"run_id\": \"" + SCENARIO_ID + "\"}");
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(scenarioService.resumeScenarioRun(SCENARIO_ID)).thenThrow(new ScenarioException(reason));

        JsonNode frame = objectMapper.readTree(sentSingleFrame());

        assertEquals("FAILED", frame.path("data").path("status").asText());
        assertEquals(reason, frame.path("data").path("error").asText());
        assertEquals("Ошибка обработки сообщения: " + reason, frame.path("error").asText());
    }

    @Test
    void testHandle_malformedMessageKeepsPlainErrorFrame() throws Exception {
        // ошибка разбора команды — не отказ в запуске: кадр прежнего формата без STATUS
        WebSocketMessage message = mock(WebSocketMessage.class);
        when(message.getPayloadAsText()).thenReturn("{не json");
        when(webSocketSession.receive()).thenReturn(Flux.just(message));

        JsonNode frame = objectMapper.readTree(sentSingleFrame());

        assertTrue(frame.path("error").asText().startsWith("Ошибка обработки сообщения: "), frame.toString());
        assertFalse(frame.has("type"), frame.toString());
    }

    /** Запускает обработчик и возвращает единственный отправленный клиенту кадр. */
    private String sentSingleFrame() {
        ArgumentCaptor<Publisher<WebSocketMessage>> sent = ArgumentCaptor.forClass(Publisher.class);
        handler.handle(webSocketSession).block();
        verify(webSocketSession, times(1)).send(sent.capture());
        Flux.from(sent.getValue()).blockLast();
        ArgumentCaptor<String> frame = ArgumentCaptor.forClass(String.class);
        verify(webSocketSession).textMessage(frame.capture());
        return frame.getValue();
    }

    @Test
    void testHandle_runCommand_isCalledOffFrameThreadWithSessionUser() {
        // блокирующий JPA не должен идти на потоке, принимающем кадры WebSocket (reactor-http-nio),
        // при этом пользователь из X-UserId должен быть виден вызову сервиса
        Scheduler frameThread = Schedulers.newSingle("netty-frame-test");
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message).publishOn(frameThread));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        AtomicReference<String> threadAtRun = new AtomicReference<>();
        AtomicReference<String> userAtRun = new AtomicReference<>();
        when(scenarioService.runScenario(any(), anyBoolean())).thenAnswer(inv -> {
            threadAtRun.set(Thread.currentThread().getName());
            userAtRun.set(CurrentUserHolder.getCurrentUser());
            return Flux.empty();
        });

        handler.handle(webSocketSession).block();
        frameThread.dispose();

        assertEquals("test-user-id", userAtRun.get());
        assertNotNull(threadAtRun.get());
        assertFalse(threadAtRun.get().startsWith("netty-frame-test"),
                "команда прогона выполнена на потоке приёма кадров: " + threadAtRun.get());
    }

    @Test
    void testHandle_commandError_sendsErrorMessageToClient() {
        // ошибка приёма команды вне event loop (например, «возобновить можно только упавший прогон») уходит клиенту
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(scenarioService.runScenario(any(), anyBoolean()))
                .thenThrow(new IllegalStateException("Возобновить можно только прогон, завершившийся ошибкой"));

        handler.handle(webSocketSession).block();

        verify(webSocketSession, times(1)).send(any());
    }

    @Test
    void testHandle_streamEvents_keepUserOfRunThreadAndOrder() {
        // события прогона уходят клиенту в порядке эмиссии, а сериализация кадра не стирает
        // пользователя в потоке прогона (map выполняется в потоке, вызвавшем sink.next)
        WebSocketMessage message = runMessage();
        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        List<String> sent = new CopyOnWriteArrayList<>();
        when(webSocketSession.textMessage(anyString())).thenAnswer(inv -> {
            sent.add(inv.getArgument(0));
            return mock(WebSocketMessage.class);
        });
        when(webSocketSession.send(any())).thenAnswer(inv -> {
            @SuppressWarnings("unchecked")
            Publisher<WebSocketMessage> messages = (Publisher<WebSocketMessage>) inv.getArgument(0);
            return Flux.from(messages).then();
        });
        AtomicReference<String> userAfterFirstEvent = new AtomicReference<>();
        when(scenarioService.runScenario(any(), anyBoolean())).thenReturn(Flux.create(sink -> {
            CurrentUserHolder.setCurrentUser("RUNNER42");
            sink.next(event("status", "первое"));
            userAfterFirstEvent.set(CurrentUserHolder.getCurrentUser());
            sink.next(event("node_status", "второе"));
            sink.next(event("node_status", "третье"));
            CurrentUserHolder.clear();
            sink.complete();
        }));

        handler.handle(webSocketSession).block();

        assertEquals("RUNNER42", userAfterFirstEvent.get(), "сериализация кадра стёрла пользователя потока прогона");
        assertEquals(3, sent.size());
        assertTrue(sent.get(0).contains("первое"));
        assertTrue(sent.get(1).contains("второе"));
        assertTrue(sent.get(2).contains("третье"));
    }

    private static ServerSentEvent<Map<String, Object>> event(String type, String detail) {
        return ServerSentEvent.<Map<String, Object>>builder()
                .data(Map.of("type", type, "detail", detail))
                .build();
    }

    private static WebSocketMessage runMessage() {
        WebSocketMessage message = mock(WebSocketMessage.class);
        when(message.getPayloadAsText()).thenReturn("""
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": false
                }
                """);
        return message;
    }
}
