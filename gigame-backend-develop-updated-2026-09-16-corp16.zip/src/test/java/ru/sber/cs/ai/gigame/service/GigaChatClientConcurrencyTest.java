package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.metadata.ChatGenerationMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.ai.tool.definition.ToolDefinition;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.Disposable;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты GigaChatClient под общим ограничителем запросов: разрешение держится только на время
 * HTTP-попытки (не на паузу повтора), ожидание очереди видно в журнале прогона и прерывается
 * его остановкой, «стрим» чата отпускает разрешение при завершении, ошибке и отмене.
 */
class GigaChatClientConcurrencyTest {

    private static final long WAIT_SECONDS = 5;
    private static final List<Map<String, String>> A = List.of(Map.of("role", "user", "content", "A"));
    private static final List<Map<String, String>> B = List.of(Map.of("role", "user", "content", "B"));

    private final ExecutorService pool = Executors.newCachedThreadPool();
    private ChatModel chatModel;
    private EmbeddingModel embeddingModel;
    private GigaChatClient client;
    private GigaChatConcurrencyLimiter limiter;

    @BeforeEach
    void setUp() {
        chatModel = mock(ChatModel.class);
        embeddingModel = mock(EmbeddingModel.class);
        client = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(client, "textMaxLength", 800);
        ReflectionTestUtils.setField(client, "batchSize", 50);
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 3);
        ReflectionTestUtils.setField(client, "retryDelayMillis", 1);
        ReflectionTestUtils.setField(client, "retryDelay429Millis", 1);
        limiter = new GigaChatConcurrencyLimiter(1, true, 50);
        client.setConcurrencyLimiter(limiter);
    }

    @AfterEach
    void tearDown() {
        pool.shutdownNow();
    }

    @Test
    void permitIsReleasedBeforeRetryPauseAfter429() throws Exception {
        ReflectionTestUtils.setField(client, "retryDelay429Millis", 1500);
        List<String> events = new CopyOnWriteArrayList<>();
        AtomicInteger callsA = new AtomicInteger();
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            String text = inv.getArgument(0, Prompt.class).getInstructions().get(0).getText();
            if ("A".equals(text) && callsA.incrementAndGet() == 1) {
                events.add("A-429");
                throw new RuntimeException("429 Too Many Requests");
            }
            events.add(text);
            return response("ответ " + text);
        });
        Future<String> first = pool.submit(() -> client.chatCompletion(A));
        awaitTrue(() -> events.contains("A-429"));
        awaitTrue(() -> limiter.inFlight() == 0);

        assertEquals("ответ B", client.chatCompletion(B));

        assertEquals("ответ A", first.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(List.of("A-429", "B", "A"), events);
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void permitIsReleasedWhenCallFails() {
        when(chatModel.call(any(Prompt.class))).thenThrow(new RuntimeException("400 Bad Request"));

        assertThrows(GigaChatException.class, () -> client.chatCompletion(A));

        assertEquals(0, limiter.inFlight());
        assertEquals(0, limiter.waiting());
    }

    @Test
    void queueWaitGoesToRunJournal() throws Exception {
        when(chatModel.call(any(Prompt.class))).thenReturn(response("ok"));
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);
        List<String> notices = new CopyOnWriteArrayList<>();
        Future<String> step = pool.submit(() -> completionWithNotice(notices));
        awaitTrue(() -> notices.size() == 1);
        verify(chatModel, never()).call(any(Prompt.class));

        permit.close();

        assertEquals("ok", step.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertTrue(notices.get(0).startsWith("все 1 потоков GigaChat заняты"), notices.get(0));
        assertTrue(notices.get(1).startsWith("очередь к GigaChat пройдена"), notices.get(1));
    }

    @Test
    void runCancelWhileQueuedStopsWithoutCallingModel() throws Exception {
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);
        AtomicBoolean cancelled = new AtomicBoolean();
        Future<String> step = pool.submit(() -> completionWithCancel(cancelled::get));
        awaitTrue(() -> limiter.waiting() == 1);

        cancelled.set(true);

        assertEquals(GigaChatClient.CANCELLED, step.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(0, limiter.waiting());
        verify(chatModel, never()).call(any(Prompt.class));
        permit.close();
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void embeddingsWaitForQueueWhenLimited() throws Exception {
        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddings());
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);
        Future<List<float[]>> vectors = pool.submit(() -> client.getEmbeddings(List.of("текст")));
        awaitTrue(() -> limiter.waiting() == 1);
        verify(embeddingModel, never()).call(any(EmbeddingRequest.class));

        permit.close();

        assertEquals(1, vectors.get(WAIT_SECONDS, TimeUnit.SECONDS).size());
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void embeddingsBypassQueueWhenNotLimited() {
        client.setConcurrencyLimiter(new GigaChatConcurrencyLimiter(1, false, 50));
        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddings());
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);

        assertEquals(1, client.getEmbeddings(List.of("текст")).size());

        permit.close();
    }

    @Test
    void toolLoopWithEmbeddingToolDoesNotDeadlock() throws Exception {
        var toolCall = new AssistantMessage.ToolCall("id1", "function", "kb_search", "{}");
        when(chatModel.call(any(Prompt.class)))
                .thenReturn(new ChatResponse(List.of(new Generation(
                        AssistantMessage.builder().content("").toolCalls(List.of(toolCall)).build()))))
                .thenReturn(response("итог"));
        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(embeddings());
        ToolCallback tool = mock(ToolCallback.class);
        ToolDefinition definition = mock(ToolDefinition.class);
        when(definition.name()).thenReturn("kb_search");
        when(tool.getToolDefinition()).thenReturn(definition);
        when(tool.call(anyString())).thenAnswer(inv -> "{\"vectors\":" + client.getEmbeddings(List.of("запрос")).size() + "}");

        Future<GigaChatClient.ChatResult> result = pool.submit(() -> client.chatCompletionWithTools(A, List.of(tool), null, null));

        assertEquals("итог", result.get(WAIT_SECONDS, TimeUnit.SECONDS).text());
        verify(embeddingModel).call(any(EmbeddingRequest.class));
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void hardTimeoutReleasesPermitForRetry() throws Exception {
        ReflectionTestUtils.setField(client, "callHardTimeoutSeconds", 1L);
        AtomicInteger calls = new AtomicInteger();
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            if (calls.incrementAndGet() == 1) {
                pause(3000);
            }
            return response("после таймаута");
        });

        Future<String> step = pool.submit(() -> client.chatCompletion(A));

        assertEquals("после таймаута", step.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(2, calls.get());
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void streamReleasesPermitOnComplete() {
        when(chatModel.call(any(Prompt.class))).thenReturn(response("поток"));

        GigaChatClient.ChatResult result = client.chatCompletionStreamResult(A, null, null).blockLast(Duration.ofSeconds(WAIT_SECONDS));

        assertEquals("поток", result.text());
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void streamReleasesPermitOnError() {
        when(chatModel.call(any(Prompt.class))).thenThrow(new RuntimeException("400 Bad Request"));

        assertThrows(GigaChatException.class,
                () -> client.chatCompletionStreamResult(A, null, null).blockLast(Duration.ofSeconds(WAIT_SECONDS)));

        assertEquals(0, limiter.inFlight());
    }

    @Test
    void streamCancelDuringCallReleasesPermit() throws Exception {
        ReflectionTestUtils.setField(client, "callHardTimeoutSeconds", 60L);
        CountDownLatch started = new CountDownLatch(1);
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            started.countDown();
            pause(60_000);
            return response("поздно");
        });
        Disposable subscription = client.chatCompletionStreamResult(A, null, null).subscribe();
        assertTrue(started.await(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(1, limiter.inFlight());

        subscription.dispose();

        awaitTrue(() -> limiter.inFlight() == 0);
    }

    @Test
    void streamWaitsForQueueOffSubscriberThreadAndCancelLeavesQueue() throws Exception {
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);

        Disposable subscription = client.chatCompletionStreamResult(A, null, null).subscribe();

        awaitTrue(() -> limiter.waiting() == 1);
        assertFalse(subscription.isDisposed());
        subscription.dispose();
        awaitTrue(() -> limiter.waiting() == 0);
        permit.close();
        verify(chatModel, never()).call(any(Prompt.class));
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void disabledLimiterLetsCallsRunInParallel() throws Exception {
        client.setConcurrencyLimiter(new GigaChatConcurrencyLimiter(0, true, 50));
        CountDownLatch bothInside = new CountDownLatch(2);
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            bothInside.countDown();
            assertTrue(bothInside.await(WAIT_SECONDS, TimeUnit.SECONDS), "вызовы не шли одновременно");
            return response("параллельно");
        });

        Future<String> first = pool.submit(() -> client.chatCompletion(A));
        Future<String> second = pool.submit(() -> client.chatCompletion(B));

        assertEquals("параллельно", first.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals("параллельно", second.get(WAIT_SECONDS, TimeUnit.SECONDS));
    }

    @Test
    void continuationTakesNewPermitSoQueuedCallGoesBetween() throws Exception {
        CountDownLatch release = new CountDownLatch(1);
        List<String> events = new CopyOnWriteArrayList<>();
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> answerChain(inv.getArgument(0, Prompt.class), events, release));
        Future<String> first = pool.submit(() -> client.chatCompletion(A));
        awaitTrue(() -> events.contains("A"));
        Future<String> second = pool.submit(() -> client.chatCompletion(B));
        awaitTrue(() -> limiter.waiting() == 1);

        release.countDown();

        assertEquals("начало-хвост", first.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals("ответ B", second.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(List.of("A", "B", "A-продолжение"), events);
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void splitOnContextTooLongTakesPermitPerPart() throws Exception {
        List<Integer> inFlightDuringCalls = new CopyOnWriteArrayList<>();
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            inFlightDuringCalls.add(limiter.inFlight());
            if (inv.getArgument(0, Prompt.class).getInstructions().get(0).getText().length() > 30_000) {
                throw new RuntimeException("HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 190108\"}");
            }
            return response("часть");
        });
        String document = "строка документа\n".repeat(2_500);

        Future<String> step = pool.submit(() -> client.chatCompletion(List.of(Map.of("role", "user", "content", document))));

        assertEquals("часть\n\nчасть", step.get(WAIT_SECONDS, TimeUnit.SECONDS));
        assertEquals(List.of(1, 1, 1), inFlightDuringCalls);
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void fileRecognitionWaitsForQueue() throws Exception {
        when(chatModel.call(any(Prompt.class))).thenReturn(response("распознано"));
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);
        Future<GigaChatClient.ChatResult> ocr = pool.submit(() -> client.chatCompletionWithFile(
                "распознай", "скан.pdf", new byte[]{1, 2, 3}, "application/pdf", null, null, null));
        awaitTrue(() -> limiter.waiting() == 1);
        verify(chatModel, never()).call(any(Prompt.class));

        permit.close();

        assertEquals("распознано", ocr.get(WAIT_SECONDS, TimeUnit.SECONDS).text());
        assertEquals(0, limiter.inFlight());
    }

    @Test
    void springInjectsConfiguredLimiterIntoClient() {
        contextRunner()
                .withPropertyValues("app.gigachat.max-concurrent=2", "app.gigachat.limit-embeddings=false")
                .run(context -> {
                    GigaChatConcurrencyLimiter bean = context.getBean(GigaChatConcurrencyLimiter.class);
                    assertEquals(2, bean.maxConcurrent());
                    assertFalse(bean.isLimitEmbeddings());
                    assertSame(bean, ReflectionTestUtils.getField(context.getBean(GigaChatClient.class), "concurrencyLimiter"));
                });
    }

    @Test
    void springDefaultsAreFivePermitsWithEmbeddings() {
        contextRunner().run(context -> {
            GigaChatConcurrencyLimiter bean = context.getBean(GigaChatConcurrencyLimiter.class);
            assertEquals(5, bean.maxConcurrent());
            assertTrue(bean.isLimitEmbeddings());
        });
    }

    @Test
    void nullLimiterMeansUnlimited() {
        client.setConcurrencyLimiter(null);
        when(chatModel.call(any(Prompt.class))).thenReturn(response("без лимита"));
        GigaChatConcurrencyLimiter.Permit permit = limiter.acquire(null, null);

        assertEquals("без лимита", client.chatCompletion(A));

        permit.close();
    }

    private String completionWithNotice(List<String> notices) {
        GigaChatClient.setRunWaitNotice(notices::add);
        try {
            return client.chatCompletion(A);
        } finally {
            GigaChatClient.clearRunWaitNotice();
        }
    }

    private String completionWithCancel(BooleanSupplier cancelled) {
        GigaChatClient.setRunCancelCheck(cancelled);
        try {
            return client.chatCompletion(A);
        } catch (GigaChatException e) {
            return e.getMessage();
        } finally {
            GigaChatClient.clearRunCancelCheck();
        }
    }

    private static ApplicationContextRunner contextRunner() {
        return new ApplicationContextRunner()
                .withBean(ChatModel.class, () -> mock(ChatModel.class))
                .withBean(EmbeddingModel.class, () -> mock(EmbeddingModel.class))
                .withBean(GigaChatConcurrencyLimiter.class)
                .withBean(GigaChatClient.class);
    }

    private static ChatResponse answerChain(Prompt prompt, List<String> events, CountDownLatch release) throws InterruptedException {
        List<Message> instructions = prompt.getInstructions();
        if ("B".equals(instructions.get(0).getText())) {
            events.add("B");
            return response("ответ B");
        }
        if (instructions.size() > 1) {
            events.add("A-продолжение");
            return finished("-хвост", "stop");
        }
        events.add("A");
        assertTrue(release.await(WAIT_SECONDS, TimeUnit.SECONDS), "латч не открылся");
        return finished("начало", "length");
    }

    private static ChatResponse finished(String text, String reason) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(text),
                ChatGenerationMetadata.builder().finishReason(reason).build())));
    }

    private static ChatResponse response(String text) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(text))));
    }

    private static EmbeddingResponse embeddings() {
        return new EmbeddingResponse(List.of(new Embedding(new float[1024], 0)));
    }

    private static void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static void awaitTrue(BooleanSupplier condition) throws InterruptedException {
        long deadline = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(WAIT_SECONDS);
        while (!condition.getAsBoolean()) {
            assertTrue(System.currentTimeMillis() < deadline, "условие не выполнилось за " + WAIT_SECONDS + " с");
            Thread.sleep(5);
        }
    }
}
