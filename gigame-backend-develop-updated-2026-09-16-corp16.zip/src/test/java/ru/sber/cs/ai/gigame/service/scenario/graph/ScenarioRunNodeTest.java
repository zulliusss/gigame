package ru.sber.cs.ai.gigame.service.scenario.graph;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;

import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class ScenarioRunNodeTest {

    // ------------------ Constructor ------------------

    @Test
    void testDefaultConstructor() {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(null)
                .position(null)
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals("node1", node.getId());
        assertFalse(node.getCompleted());
        assertTrue(node.getSkip());
        assertTrue(node.getOutput().isEmpty());
        assertTrue(node.getInput().isEmpty());
        assertTrue(node.getDocList().isEmpty());
    }

    // ------------------ fromDto ------------------

    @Test
    void testFromDto_withNullDto() {
        var node = ScenarioRunNode.fromDto(0, null, null);
        assertNull(node);
    }

    @Test
    void testFromDto_withValidDto() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1), List.of());
        var graph = new ScenarioRunGraph(graphData);

        var node = ScenarioRunNode.fromDto(5, n1, graph);
        assertNotNull(node);
        assertEquals("n1", node.getId());
        assertEquals(5, node.getIndex());
        assertEquals(graph, node.getGraph());
        assertEquals(1, node.getTotal());
        assertFalse(node.getCompleted());
        assertTrue(node.getSkip());
    }

    @Test
    void testFromDto_setsFieldsCorrectly() {
        var n1 = new NodeDto("n1", "output", null, null, null);
        var n2 = new NodeDto("n2", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1, n2), List.of());
        var graph = new ScenarioRunGraph(graphData);

        var node = ScenarioRunNode.fromDto(1, n2, graph);
        assertNotNull(node);
        assertEquals("n2", node.getId());
        assertEquals(1, node.getIndex());
        assertEquals(2, node.getTotal());
        assertNotNull(node.getDto());
    }

    // ------------------ getAllDocTexts ------------------

    @Test
    void testGetAllDocTexts_withNoDocs() {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(null)
                .position(null)
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals("", node.getAllDocTexts());
    }

    @Test
    void testGetAllDocTexts_withDocInDocList() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var n2 = new NodeDto("n2", "output", null, null, null);
        var graphData = new GraphDataDto(List.of(n1, n2), List.of());
        var graph = new ScenarioRunGraph(graphData);
        graph.addDocs(List.of("text1"), List.of("file1.txt"));

        var node = graph.getNodeMap().get("n1");
        assertEquals("", node.getAllDocTexts());
    }

    @Test
    void testGetAllDocTexts_withMixedDocs() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1), List.of());
        var graph = new ScenarioRunGraph(graphData);
        graph.addDocs(List.of("text1", "text2"), List.of("file1.txt", "file2.txt"));

        var node = graph.getNodeMap().get("n1");
        assertEquals("", node.getAllDocTexts());
    }

    @Test
    void testGetAllDocTexts_withNullDoc() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1), List.of());
        var graph = new ScenarioRunGraph(graphData);
        var node = graph.getNodeMap().get("n1");
        assertEquals("", node.getAllDocTexts());
    }

    @Test
    void testGetAllDocTexts_withNullDocText() {
        var n1 = new NodeDto("n1", "input", null, null, null);
        var graphData = new GraphDataDto(List.of(n1), List.of());
        var graph = new ScenarioRunGraph(graphData);
        graph.addDocs(null, null);

        var node = graph.getNodeMap().get("n1");
        assertEquals("", node.getAllDocTexts());
    }

    // ------------------ getType ------------------

    @Test
    void testGetType_withNullDto() {
        var node = new ScenarioRunNode(null);
        assertNull(node.getDto());
    }

    @ParameterizedTest
    @MethodSource("provideNodeTypes")
    void testGetType_withKnownTypes(String type, String expectedType) {
        var dto = NodeDto.builder()
                .id("node1")
                .type(type)
                .data(null)
                .position(null)
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expectedType, node.getType().toString());
    }

    private static Stream<Arguments> provideNodeTypes() {
        return Stream.of(
                arguments("input", "input"),
                arguments("output", "output"),
                arguments("loop", "loop"),
                arguments("switch", "switch"),
                arguments("if_node", "if_node"),
                arguments("processing", "processing"),
                arguments("unknown_type", "unknown")
        );
    }

    // ------------------ getLabel ------------------

    @ParameterizedTest
    @MethodSource("provideLabelCases")
    void testGetLabel(String label, String type, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type(type)
                .data(new NodeDataDto(label, null, null, null, null, null, null, null, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getLabel());
    }

    private static Stream<Arguments> provideLabelCases() {
        return Stream.of(
                arguments(null, "input", "input"),
                arguments("", "input", "input"),
                arguments("Custom Label", "input", "Custom Label"),
                arguments("Another Label", "output", "Another Label"),
                arguments("Loop Label", "loop", "Loop Label")
        );
    }

    // ------------------ getMode ------------------

    @ParameterizedTest
    @MethodSource("provideModeCases")
    void testGetMode(String mode, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, null, null, mode, null, null, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getMode());
    }

    private static Stream<Arguments> provideModeCases() {
        return Stream.of(
                arguments(null, "all"),
                arguments("", "all"),
                arguments("all", "all"),
                arguments("first", "first"),
                arguments("last", "last")
        );
    }

    // ------------------ isClassifyStrict ------------------

    @ParameterizedTest
    @MethodSource("provideClassifyStrictCases")
    void testIsClassifyStrict(String classifyStrict, boolean expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, null, classifyStrict, null, null, null, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.isClassifyStrict());
    }

    private static Stream<Arguments> provideClassifyStrictCases() {
        return Stream.of(
                arguments(null, false),
                arguments("", false),
                arguments("true", true),
                arguments("false", false),
                arguments("True", true),
                arguments("False", false)
        );
    }

    // ------------------ getKnowledgeBaseId ------------------

    @ParameterizedTest
    @MethodSource("provideKnowledgeBaseIdCases")
    void testGetKnowledgeBaseId(String knowledgeBaseId, UUID expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, null, null, null, null, null, null, knowledgeBaseId, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getKnowledgeBaseId());
    }

    @Test
    void testGetKnowledgeBaseId_withInvalidUUID() {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, null, null, null, null, null, null, "not-a-uuid", null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertThrows(IllegalArgumentException.class, node::getKnowledgeBaseId);
    }

    private static Stream<Arguments> provideKnowledgeBaseIdCases() {
        var uuid1 = UUID.randomUUID();
        var uuid2 = UUID.randomUUID();
        return Stream.of(
                arguments(null, null),
                arguments("", null),
                arguments(uuid1.toString(), uuid1),
                arguments(uuid2.toString(), uuid2)
        );
    }

    // ------------------ getField ------------------

    @ParameterizedTest
    @MethodSource("provideFieldCases")
    void testGetField(String field, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, null, null, null, field, null, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getField());
    }

    private static Stream<Arguments> provideFieldCases() {
        return Stream.of(
                arguments(null, ""),
                arguments("", ""),
                arguments("Статус", "Статус"),
                arguments("condition", "condition"),
                arguments("field_name", "field_name")
        );
    }

    // ------------------ getOperator ------------------

    @ParameterizedTest
    @MethodSource("provideOperatorCases")
    void testGetOperator(String operator, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, null, null, null, null, operator, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getOperator());
    }

    private static Stream<Arguments> provideOperatorCases() {
        return Stream.of(
                arguments(null, "contains"),
                arguments("", "contains"),
                arguments("contains", "contains"),
                arguments("equals", "equals"),
                arguments("startsWith", "startsWith"),
                arguments("endsWith", "endsWith")
        );
    }

    // ------------------ getValue ------------------

    @ParameterizedTest
    @MethodSource("provideValueCases")
    void testGetValue(String value, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, null, null, null, null, null, value, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getValue());
    }

    private static Stream<Arguments> provideValueCases() {
        return Stream.of(
                arguments(null, ""),
                arguments("", ""),
                arguments("some_value", "some_value"),
                arguments("test", "test"),
                arguments("123", "123")
        );
    }

    // ------------------ getRules ------------------

    @ParameterizedTest
    @MethodSource("provideRulesCases")
    void testGetRules(String rules, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, null, rules, null, null, null, null, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getRules());
    }

    private static Stream<Arguments> provideRulesCases() {
        return Stream.of(
                arguments(null, "[]"),
                arguments("", "[]"),
                arguments("[]", "[]"),
                arguments("[{\"value\":\"ТЗ\",\"operator\":\"contains\",\"label\":\"ТЗ\"}]", "[{\"value\":\"ТЗ\",\"operator\":\"contains\",\"label\":\"ТЗ\"}]")
        );
    }

    // ------------------ getPrompt ------------------

    @ParameterizedTest
    @MethodSource("providePromptCases")
    void testGetPrompt(String prompt, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", prompt, null, null, null, null, null, null, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getPrompt());
    }

    private static Stream<Arguments> providePromptCases() {
        return Stream.of(
                arguments(null, ""),
                arguments("", ""),
                arguments("Ты работаешь с ТЗ", "Ты работаешь с ТЗ"),
                arguments("Custom prompt text", "Custom prompt text")
        );
    }

    // ------------------ getClasses ------------------

    @ParameterizedTest
    @MethodSource("provideClassesCases")
    void testGetClasses(String classes, String expected) {
        var dto = NodeDto.builder()
                .id("node1")
                .type("input")
                .data(new NodeDataDto("Label", null, classes, null, null, null, null, null, null, null, null, null, null))
                .build();

        var node = new ScenarioRunNode(dto);
        assertEquals(expected, node.getClasses());
    }

    private static Stream<Arguments> provideClassesCases() {
        return Stream.of(
                arguments(null, ""),
                arguments("", ""),
                arguments("ТЗ, КП", "ТЗ, КП"),
                arguments("class1, class2", "class1, class2"),
                arguments("A,B,C", "A,B,C")
        );
    }

    // ------------------ addInput: порядок вкладов по рёбрам графа ------------------

    /** Граф: a → c, b → c (ребро от a раньше ребра от b). */
    private static ScenarioRunGraph twoParentsGraph() {
        var a = new NodeDto("a", "processing", null, null, null);
        var b = new NodeDto("b", "processing", null, null, null);
        var c = new NodeDto("c", "output", null, null, null);
        return new ScenarioRunGraph(new GraphDataDto(List.of(a, b, c), List.of(
                new EdgeDto("e1", "a", "c", new EdgeDataDto(null)),
                new EdgeDto("e2", "b", "c", new EdgeDataDto(null)))));
    }

    @Test
    void testAddInput_parentsFinishInReverseOrder_inputFollowsEdgeOrder() {
        var graph = twoParentsGraph();
        var child = graph.getNodeMap().get("c");

        // b завершился первым, a — вторым
        child.addInput("b", "вклад B");
        child.addInputs("a", List.of("вклад A1", "вклад A2"));

        assertEquals(List.of("вклад A1", "вклад A2", "вклад B"), List.copyOf(child.getInput()));
        assertEquals(3, child.getInput().size());
        assertEquals("вклад A1", child.getInput().get(0));
        assertEquals("вклад A1\n\nвклад A2\n\nвклад B", String.join("\n\n", child.getInput()));
    }

    @Test
    void testAddInput_withoutSource_goesAfterParents() {
        var graph = twoParentsGraph();
        var child = graph.getNodeMap().get("c");

        child.getInput().add("ручной вклад");
        child.addInput("b", "вклад B");
        child.getInput().addAll(List.of("ещё ручной"));
        child.addInput("x-неродитель", "вклад чужого узла");
        child.addInput("a", "вклад A");

        assertEquals(List.of("вклад A", "вклад B", "вклад чужого узла", "ручной вклад", "ещё ручной"),
                child.getInput().stream().toList());
    }

    @Test
    void testInput_clearResetsAllContributions() {
        var graph = twoParentsGraph();
        var child = graph.getNodeMap().get("c");
        child.addInput("a", "вклад A");
        child.getInput().add("ручной");

        child.getInput().clear();

        assertTrue(child.getInput().isEmpty());
        assertEquals(0, child.getInput().size());
    }

    @Test
    void testAddInput_concurrentParents_nothingLost() throws Exception {
        var graph = twoParentsGraph();
        var child = graph.getNodeMap().get("c");
        int perParent = 200;
        var start = new CountDownLatch(1);
        ExecutorService pool = Executors.newFixedThreadPool(3);
        try {
            for (String parent : List.of("a", "b")) {
                pool.submit(() -> {
                    start.await();
                    for (int i = 0; i < perParent; i++) {
                        child.addInput(parent, parent + i);
                    }
                    return null;
                });
            }
            pool.submit(() -> {
                start.await();
                for (int i = 0; i < perParent; i++) {
                    child.getInput().add("m" + i);
                }
                return null;
            });
            start.countDown();
            pool.shutdown();
            assertTrue(pool.awaitTermination(10, TimeUnit.SECONDS));
        } finally {
            pool.shutdownNow();
        }

        List<String> input = new ArrayList<>(child.getInput());
        assertEquals(3 * perParent, input.size());
        assertEquals("a0", input.get(0));
        assertEquals("b0", input.get(perParent));
        assertEquals("m0", input.get(2 * perParent));
    }
}
