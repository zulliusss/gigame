package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.PlatformTransactionManager;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты чистки прогонов по сроку хранения.
 */
@ExtendWith(MockitoExtension.class)
class ScenarioRunRetentionServiceTest {

    @Mock
    private ScenarioRunRepository runRepository;
    @Mock
    private AgentQuestionRepository questionRepository;
    @Mock
    private PlatformTransactionManager transactionManager;

    private ScenarioRunRetentionService service;

    @BeforeEach
    void setUp() {
        service = new ScenarioRunRetentionService(transactionManager, runRepository, questionRepository);
    }

    @Test
    void purge_disabledByDefault_deletesNothing() {
        assertEquals(0, service.purgeExpiredRuns(OffsetDateTime.now()));

        verify(runRepository, never()).findExpiredRunIds(any());
        verify(runRepository, never()).deleteAllByIdInBatch(any());
        verify(questionRepository, never()).deleteByRunIds(any());
    }

    @Test
    void purge_deletesExpiredRunsWithQuestionsInBatches() {
        service.setRetentionDays(30);
        List<UUID> ids = Stream.generate(UUID::randomUUID)
                .limit(ScenarioRunRetentionService.BATCH_SIZE + 1)
                .toList();
        OffsetDateTime now = OffsetDateTime.of(2026, 9, 15, 12, 0, 0, 0, ZoneOffset.UTC);
        when(runRepository.findExpiredRunIds(now.minusDays(30))).thenReturn(ids);

        assertEquals(ids.size(), service.purgeExpiredRuns(now));

        List<UUID> firstBatch = ids.subList(0, ScenarioRunRetentionService.BATCH_SIZE);
        List<UUID> secondBatch = ids.subList(ScenarioRunRetentionService.BATCH_SIZE, ids.size());
        verify(questionRepository).deleteByRunIds(firstBatch);
        verify(questionRepository).deleteByRunIds(secondBatch);
        verify(runRepository).deleteAllByIdInBatch(firstBatch);
        verify(runRepository).deleteAllByIdInBatch(secondBatch);
        verify(runRepository, times(2)).deleteAllByIdInBatch(any());
    }

    @Test
    void purge_nothingExpired_deletesNothing() {
        service.setRetentionDays(7);
        when(runRepository.findExpiredRunIds(any())).thenReturn(List.of());

        assertEquals(0, service.purgeExpiredRuns(OffsetDateTime.now()));

        verify(runRepository, never()).deleteAllByIdInBatch(any());
        verify(questionRepository, never()).deleteByRunIds(any());
    }

    @Test
    void scheduledPurge_swallowsDatabaseErrors() {
        service.setRetentionDays(1);
        when(runRepository.findExpiredRunIds(any())).thenThrow(new IllegalStateException("БД недоступна"));

        assertDoesNotThrow(() -> service.purgeExpiredRuns());
    }
}
