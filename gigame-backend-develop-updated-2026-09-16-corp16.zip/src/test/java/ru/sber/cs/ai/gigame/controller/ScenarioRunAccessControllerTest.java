package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.ApplicationErrorHandler;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Управление прогоном (продолжение, отключение пошагового режима, остановка)
 * и вопросы агента по прогону (список и ответ), извлечение уроков из прогона
 * доступны только автору прогона: проверка
 * выполняется с пользователем из заголовка X-UserId до обращения к движку
 * и памяти агента, отказ — 403, неизвестный прогон — 404.
 */
@ExtendWith(SpringExtension.class)
@Import({ScenarioController.class, AgentMemoryController.class, ApplicationErrorHandler.class})
@WebFluxTest(controllers = {ScenarioController.class, AgentMemoryController.class})
// холодный старт контекста на нагруженной машине превышает дефолтные 5с
@AutoConfigureWebTestClient(timeout = "30000")
class ScenarioRunAccessControllerTest {

    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private ScenarioService scenarioService;
    @MockitoBean
    private ScenarioEngine scenarioEngine;
    @MockitoBean
    private DocsTextCacheService docsTextCacheService;
    @MockitoBean
    private ScenarioUploadTaskService scenarioUploadTaskService;
    @MockitoBean
    private AgentMemoryService memoryService;
    @MockitoBean
    private ScenarioRunRepository runRepository;
    @MockitoBean
    private ScenarioRunStepRepository stepRepository;

    private UUID runId;

    @BeforeEach
    void setUp() {
        runId = UUID.randomUUID();
    }

    private void denyRunAccess() {
        doThrow(new AccessDeniedException("illegal userId")).when(scenarioService).checkRunAccess(runId);
    }

    @Test
    void continueRun_authorFromHeader_checkedBeforeEngine() {
        AtomicReference<String> checkedUser = new AtomicReference<>();
        doAnswer(inv -> {
            checkedUser.set(CurrentUserHolder.getCurrentUser());
            return null;
        }).when(scenarioService).checkRunAccess(runId);

        webClient.post()
                .uri("/api/scenarios/runs/{runId}/continue", runId)
                .header("X-UserId", "ALICE")
                .exchange()
                .expectStatus().isOk();

        assertEquals("ALICE", checkedUser.get());
        verify(scenarioEngine).continueStep(runId.toString());
    }

    @Test
    void continueRun_foreignRun_forbidden() {
        denyRunAccess();

        webClient.post()
                .uri("/api/scenarios/runs/{runId}/continue", runId)
                .header("X-UserId", "BOB")
                .exchange()
                .expectStatus().isForbidden();

        verify(scenarioEngine, never()).continueStep(any());
    }

    @Test
    void disableStepMode_foreignRun_forbidden() {
        denyRunAccess();

        webClient.post()
                .uri("/api/scenarios/runs/{runId}/disable-step-mode", runId)
                .header("X-UserId", "BOB")
                .exchange()
                .expectStatus().isForbidden();

        verify(scenarioEngine, never()).disableStepMode(any());
    }

    @Test
    void disableStepMode_author_disablesStepMode() {
        webClient.post()
                .uri("/api/scenarios/runs/{runId}/disable-step-mode", runId)
                .header("X-UserId", "ALICE")
                .exchange()
                .expectStatus().isNoContent();

        verify(scenarioService).checkRunAccess(runId);
        verify(scenarioEngine).disableStepMode(runId.toString());
    }

    @Test
    void cancelRun_foreignRun_forbidden() {
        denyRunAccess();

        webClient.post()
                .uri("/api/scenarios/runs/{runId}/cancel", runId)
                .header("X-UserId", "BOB")
                .exchange()
                .expectStatus().isForbidden();

        verify(scenarioEngine, never()).requestCancel(any());
    }

    @Test
    void cancelRun_runNotInDatabase_notFound() {
        doThrow(new NotFoundException("Запуск сценария не найден: " + runId))
                .when(scenarioService).checkRunAccess(runId);

        webClient.post()
                .uri("/api/scenarios/runs/{runId}/cancel", runId)
                .header("X-UserId", "ALICE")
                .exchange()
                .expectStatus().isNotFound();

        verify(scenarioEngine, never()).requestCancel(any());
    }

    @Test
    void cancelRun_author_requestsEngineCancel() {
        when(scenarioEngine.requestCancel(runId.toString())).thenReturn(true);

        webClient.post()
                .uri("/api/scenarios/runs/{runId}/cancel", runId)
                .header("X-UserId", "ALICE")
                .exchange()
                .expectStatus().isOk();

        verify(scenarioService).checkRunAccess(runId);
        verify(scenarioEngine).requestCancel(runId.toString());
    }

    @Test
    void getQuestions_foreignRun_forbidden() {
        denyRunAccess();

        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/questions")
                        .queryParam("run_id", runId).build())
                .header("X-UserId", "BOB")
                .exchange()
                .expectStatus().isForbidden();

        verify(memoryService, never()).getQuestionsByRun(any());
    }

    @Test
    void getQuestions_author_checkedWithHeaderUser() {
        AtomicReference<String> checkedUser = new AtomicReference<>();
        doAnswer(inv -> {
            checkedUser.set(CurrentUserHolder.getCurrentUser());
            return null;
        }).when(scenarioService).checkRunAccess(runId);
        when(memoryService.getQuestionsByRun(runId)).thenReturn(List.of());

        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/questions")
                        .queryParam("run_id", runId).build())
                .header("X-UserId", "ALICE")
                .exchange()
                .expectStatus().isOk();

        assertEquals("ALICE", checkedUser.get());
        verify(memoryService).getQuestionsByRun(runId);
    }

    @Test
    void extractLessons_foreignRun_forbidden() {
        denyRunAccess();

        webClient.post()
                .uri("/api/agent/lessons/extract")
                .header("X-UserId", "BOB")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"run_id\": \"" + runId + "\"}")
                .exchange()
                .expectStatus().isForbidden();

        // выходы узлов чужого прогона не читаются и не уходят в LLM
        verify(runRepository, never()).findById(any());
        verify(stepRepository, never()).findByRunIdOrderByStartedAtAsc(any());
        verify(memoryService, never()).extractLessonsFromRun(any(), any());
    }

    @Test
    void extractLessons_author_checkedWithHeaderUser() {
        AtomicReference<String> checkedUser = new AtomicReference<>();
        doAnswer(inv -> {
            checkedUser.set(CurrentUserHolder.getCurrentUser());
            return null;
        }).when(scenarioService).checkRunAccess(runId);
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(UUID.randomUUID());
        when(runRepository.findById(runId)).thenReturn(Optional.of(run));
        when(stepRepository.findByRunIdOrderByStartedAtAsc(runId)).thenReturn(List.of());
        when(memoryService.extractLessonsFromRun(run.getScenarioId(), Map.of())).thenReturn(List.of());

        webClient.post()
                .uri("/api/agent/lessons/extract")
                .header("X-UserId", "ALICE")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"run_id\": \"" + runId + "\"}")
                .exchange()
                .expectStatus().isOk();

        assertEquals("ALICE", checkedUser.get());
        verify(memoryService).extractLessonsFromRun(run.getScenarioId(), Map.of());
    }

    @Test
    void answerQuestion_foreignRun_forbidden() {
        UUID questionId = UUID.randomUUID();
        when(memoryService.getQuestionRunId(questionId)).thenReturn(runId);
        denyRunAccess();

        webClient.post()
                .uri("/api/agent/questions/{id}/answer", questionId)
                .header("X-UserId", "OWNER")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"answer\": \"Дата — из штампа ЭП\"}")
                .exchange()
                .expectStatus().isForbidden();

        // ответ не сохраняется, текст вопроса (цитата чужих документов) не возвращается
        verify(memoryService, never()).answerQuestion(any(), any());
    }

    @Test
    void answerQuestion_questionNotFound_notFound() {
        UUID questionId = UUID.randomUUID();
        when(memoryService.getQuestionRunId(questionId))
                .thenThrow(new NotFoundException("Вопрос не найден: " + questionId));

        webClient.post()
                .uri("/api/agent/questions/{id}/answer", questionId)
                .header("X-UserId", "ALICE")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"answer\": \"ответ\"}")
                .exchange()
                .expectStatus().isNotFound();

        verify(scenarioService, never()).checkRunAccess(any());
        verify(memoryService, never()).answerQuestion(any(), any());
    }
}
