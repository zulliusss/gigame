package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AbstractScenarioExecutorTest {

    private ScenarioRunNode node;

    @BeforeEach
    void setUp() {
        NodeDto inputNode = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Input Node")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto processNode = NodeDto.builder()
                .id("process-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Process Node")
                        .prompt("Тестовый промпт")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto outputNode = NodeDto.builder()
                .id("output-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Output Node")
                        .build())
                .position(new PositionDto(100, 100))
                .build();

        EdgeDto edge1 = new EdgeDto("edge-1", "input-1", "process-1", new EdgeDataDto(null));
        EdgeDto edge2 = new EdgeDto("edge-2", "process-1", "output-1", new EdgeDataDto(null));

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, processNode, outputNode),
                List.of(edge1, edge2)
        );

        node = ScenarioRunNode.fromDto(1, processNode, new ScenarioRunGraph(graphData));
    }

    // -------------------------------------------------------------------------
    // getSkipSet tests
    // -------------------------------------------------------------------------

    @Test
    void testGetSkipSet_withNoUnchosenTargets() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);

        var skipSet = executor.getSkipSet(
                // unchosenTargets
                Set.of(),
                // chosenTargets
                Set.of("target-1", "target-2"),
                // successors
                Map.of("source", List.of("target-1", "target-2"))
        );

        assertNotNull(skipSet);
        assertTrue(skipSet.isEmpty());
    }

    @Test
    void testGetSkipSet_withSingleUnchosenTarget() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);

        var skipSet = executor.getSkipSet(
                // unchosenTargets
                Set.of("unchosen"),
                // chosenTargets
                Set.of("chosen"),
                // successors
                Map.of(
                        "unchosen", List.of("descendant1", "descendant2"),
                        "chosen", List.of("target")
                )
        );

        assertNotNull(skipSet);
        // Both descendants of unchosen should be skipped
        assertTrue(skipSet.contains("descendant1"));
        assertTrue(skipSet.contains("descendant2"));
    }

    @Test
    void testGetSkipSet_doesNotSkipDescendantsOfChosen() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);

        var skipSet = executor.getSkipSet(
                // unchosenTargets
                Set.of("unchosen"),
                // chosenTargets
                Set.of("chosen"),
                // successors
                Map.of(
                        "unchosen", List.of("descendant"),
                        "chosen", List.of("descendant")
                )
        );

        assertNotNull(skipSet);
        // Descendant should NOT be skipped because it's reachable from chosen
        assertFalse(skipSet.isEmpty());
        assertTrue(skipSet.contains("unchosen"));
    }

    @Test
    void testGetSkipSet_withComplexGraph() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);

        var skipSet = executor.getSkipSet(
                // unchosenTargets
                Set.of("branch-a"),
                // chosenTargets
                Set.of("branch-b"),
                // successors
                Map.of(
                        "branch-a", List.of("a-child"),
                        "branch-b", List.of("b-child"),
                        "a-child", List.of("a-grandchild"),
                        "b-child", List.of("b-grandchild")
                )
        );

        assertNotNull(skipSet);
        // Only descendants of branch-a that aren't reachable from branch-b should be skipped
        assertTrue(skipSet.contains("a-child"));
        assertTrue(skipSet.contains("a-grandchild"));
        // b-child and b-grandchild should not be skipped
        assertFalse(skipSet.contains("b-child"));
    }

    // -------------------------------------------------------------------------
    // buildPrompt tests
    // -------------------------------------------------------------------------

    @Test
    void testBuildPrompt_withDocumentsOnly() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        ReflectionTestUtils.setField(executor, "docCharLimit", 200000);
        String result = executor.buildPrompt("", "Document content", null, false);

                assertNotNull(result);
        assertTrue(result.contains("Тестовый промпт"));
        assertTrue(result.contains("Document content"));
    }

    @Test
    void testBuildPrompt_withPreviousOutput() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        ReflectionTestUtils.setField(executor, "docCharLimit", 200000);
        executor.prompt = "System prompt";
        String result = executor.buildPrompt("Previous result","Document content", null, false);

        assertNotNull(result);
        assertTrue(result.contains("Previous result"));
        assertTrue(result.contains("Результаты предыдущих шагов"));
    }

    @Test
    void testBuildPrompt_withKbChunks() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        executor.prompt = "System prompt";

        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        String result = executor.buildPrompt("", "docs", chunks, true);

        assertNotNull(result);
        assertTrue(result.contains("Chunk 1"));
        assertTrue(result.contains("Chunk 2"));
        assertTrue(result.contains("Релевантные фрагменты из базы знаний"));
    }

    @Test
    void testBuildPrompt_withRagButNoChunks() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        executor.prompt = "System prompt";

        String result = executor.buildPrompt("", "docs", null, true);

        assertNotNull(result);
        assertTrue(result.contains("⚠️ БАЗА ЗНАНИЙ ПОДКЛЮЧЕНА"));
        assertTrue(result.contains("НЕ НАЙДЕНО"));
    }

    @Test
    void testBuildPrompt_truncatesLongDocuments() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        executor.prompt = "System prompt";

        // Create document longer than MAX_CONTEXT (30000)
        StringBuilder longDoc = new StringBuilder();
        longDoc.append("x".repeat(35000));

        String result = executor.buildPrompt("", longDoc.toString(), null, false);

        assertNotNull(result);
        assertTrue(result.contains("[... документы обрезаны ...]"));
        assertTrue(result.length() < longDoc.length());
    }

    @Test
    void testBuildPrompt_truncatesLongPreviousOutput() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        executor.prompt = "System prompt";

        // Create long previous output
        StringBuilder longPrev = new StringBuilder();
        longPrev.append("y".repeat(35000));
        String result = executor.buildPrompt(longPrev.toString(),"docs", null, false);

        assertNotNull(result);
        assertTrue(result.contains("[... обрезано ...]"));
    }

    @Test
    void testBuildPrompt_withEmptyInputs() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        String result = executor.buildPrompt("", "", null, false);
        assertNotNull(result);
        assertEquals("Тестовый промпт", result);
    }

    @Test
    void testBuildPrompt_withKbChunksAndRagConfigured() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        executor.prompt = "System prompt";
        List<String> chunks = List.of("Relevant chunk");
        String result = executor.buildPrompt("", "docs", chunks, true);

        assertNotNull(result);
        assertTrue(result.contains("Релевантные фрагменты из базы знаний"));
        assertTrue(result.contains("используй их для ответа"));
    }

    // -------------------------------------------------------------------------
    // Helper class for testing
    // -------------------------------------------------------------------------

    private static class TestAbstractScenarioExecutor extends AbstractScenarioExecutor {
        protected TestAbstractScenarioExecutor(ScenarioRunNode node) {
            super(node);
        }
    }

    @Test
    void buildPrompt_putsInvisibleBoundaryBetweenInstructionAndContext_andNotesTruncations() {
        AbstractScenarioExecutor executor = new TestAbstractScenarioExecutor(node);
        ReflectionTestUtils.setField(executor, "docCharLimit", 100);

        String result = executor.buildPrompt("y".repeat(150), "x".repeat(120), null, false);

        // граница «инструкция | контекст» — сразу после промпта узла; модели она не отправляется (клиент вырезает)
        assertTrue(result.startsWith("Тестовый промпт" + GigaChatClient.SPLIT_BOUNDARY + "\n\nДокументы:\n"));
        assertEquals("Тестовый промпт\n\nДокументы:\n" + "x".repeat(100) + "\n\n[... документы обрезаны ...]\n\n"
                + "Результаты предыдущих шагов:\n" + "y".repeat(100) + "\n\n[... обрезано ...]",
                GigaChatClient.stripSplitMarkers(result));
        // обрезки видны не только в промпте: пометки уходят в журнал прогона и в details шага
        assertEquals(List.of("⚠ документ обрезан: 100 из 120 символов", "⚠ результат предыдущих шагов обрезан: 100 из 150 символов"),
                executor.drainTruncationNotes());
        assertTrue(executor.drainTruncationNotes().isEmpty());
        // без контекста маркеров нет
        assertEquals("Тестовый промпт", executor.buildPrompt("", "", null, false));
    }
}
