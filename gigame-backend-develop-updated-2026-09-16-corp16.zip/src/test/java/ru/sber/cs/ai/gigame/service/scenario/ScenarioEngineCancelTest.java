package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioEventType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

/**
 * Остановка прогона прерывает узел, занятый регулярным выражением (последовательный и волновой
 * режимы); Error внутри узла и слишком большой граф завершают прогон статусом FAILED.
 */
class ScenarioEngineCancelTest {

    private static final String USER = "USER1";

    /** Катастрофический шаблон на длинном тексте: без прерывания — навсегда. */
    private static final String CATASTROPHIC = "(a+)+$";

    private static final String LONG_INPUT = "a".repeat(100_000) + "!";

    private final ScenarioRunService runService = Mockito.mock(ScenarioRunService.class);

    private final ScenarioRunStepService stepService = Mockito.mock(ScenarioRunStepService.class);

    private final ScenarioExecutorFactory executorFactory = Mockito.mock(ScenarioExecutorFactory.class);

    private final Map<UUID, Consumer<ScenarioRunNode>> nodeBodies = new ConcurrentHashMap<>();

    private final List<ScenarioEngine> engines = new ArrayList<>();

    @BeforeEach
    void setUp() {
        // остановку должна обеспечить именно отмена прогона, а не таймаут поиска
        SafeRegex.setTimeoutMillis(120_000);
    }

    @AfterEach
    void tearDown() {
        SafeRegex.setTimeoutMillis(SafeRegex.DEFAULT_TIMEOUT_MILLIS);
        engines.forEach(ScenarioEngine::shutdown);
    }

    @Test
    void cancel_interruptsRegexBusyNode_sequentialMode() {
        assertCancelInterruptsRegex(false);
    }

    @Test
    void cancel_interruptsRegexBusyNode_parallelMode() {
        assertCancelInterruptsRegex(true);
    }

    private void assertCancelInterruptsRegex(boolean parallel) {
        ScenarioEngine engine = engine(parallel);
        ScenarioRun run = run();
        CountDownLatch started = new CountDownLatch(1);
        nodeBodies.put(run.getId(), node -> {
            started.countDown();
            SafeRegex.find(SafeRegex.compile(CATASTROPHIC, 0, "шаблон"), LONG_INPUT);
        });
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();

        CountDownLatch done = subscribe(engine.executeScenario(run, twoNodeGraph(), USER), events);
        assertTrue(awaitLatch(started, 30), "узел не начал выполнение");
        long cancelAt = System.nanoTime();
        assertTrue(engine.requestCancel(run.getId().toString()), "остановка не принята");

        assertTrue(awaitLatch(done, 20), "остановленный прогон не завершился");
        long elapsedMillis = (System.nanoTime() - cancelAt) / 1_000_000;
        assertTrue(elapsedMillis < 10_000, "остановка заняла " + elapsedMillis + " мс");
        Map<String, Object> last = events.get(events.size() - 1).data();
        assertEquals(ScenarioEventType.STATUS, last.get("type"));
        assertEquals(ScenarioStatus.FAILED, last.get("status"));
        if (!parallel) {
            // в последовательном режиме узел выполняется в потоке прогона: его ошибка — «Прогон остановлен»,
            // а не ложная ошибка GigaChat; в волновом режиме поток прогона прерывается в ожидании пула,
            // и статус FAILED уходит раньше, чем узел в пуле успевает записать свою ошибку
            assertTrue(events.stream().anyMatch(event -> ScenarioEventType.NODE_STATUS.equals(event.data().get("type"))
                    && String.valueOf(event.data().get("error")).contains("Прогон остановлен пользователем")),
                    "ошибка узла должна быть «Прогон остановлен пользователем», события: " + events);
        }
        Mockito.verify(runService).setScenarioRunStatusFailed(run);
    }

    @Test
    void errorInsideNode_finishesRunAsFailed() {
        ScenarioEngine engine = engine(false);
        ScenarioRun run = run();
        nodeBodies.put(run.getId(), node -> {
            throw new StackOverflowError("формула слишком глубока");
        });
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();

        CountDownLatch done = subscribe(engine.executeScenario(run, twoNodeGraph(), USER), events);

        assertTrue(awaitLatch(done, 30), "прогон с Error не завершился");
        Map<String, Object> last = events.get(events.size() - 1).data();
        assertEquals(ScenarioEventType.STATUS, last.get("type"));
        assertEquals(ScenarioStatus.FAILED, last.get("status"));
        Mockito.verify(runService).setScenarioRunStatusFailed(run);
    }

    @Test
    void tooManyNodes_failsValidation() {
        ScenarioEngine engine = engine(false);
        ScenarioRun run = run();
        List<ServerSentEvent<Map<String, Object>>> events = new CopyOnWriteArrayList<>();

        CountDownLatch done = subscribe(engine.executeScenario(run, chainGraph(ScenarioEngine.MAX_GRAPH_NODES + 1), USER), events);

        assertTrue(awaitLatch(done, 30), "прогон не завершился");
        assertEquals(ScenarioStatus.FAILED, events.get(events.size() - 1).data().get("status"));
        assertTrue(events.stream().noneMatch(event -> ScenarioEventType.NODE_STATUS.equals(event.data().get("type"))),
                "узлы слишком большого графа не выполняются");
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы
    // -------------------------------------------------------------------------

    private ScenarioEngine engine(boolean parallel) {
        Mockito.lenient().when(runService.setScenarioRunStatusRunning(any(ScenarioRun.class)))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusCompleted(any(ScenarioRun.class), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class)))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(runService.setScenarioRunStatusFailed(any(ScenarioRun.class), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(stepService.setScenarioStepStatusRunning(any(UUID.class), anyString(), any()))
                .thenAnswer(inv -> step());
        Mockito.lenient().when(stepService.setScenarioStepStatusCompleted(any(), any(), any(), any(), any(), any(), any()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(stepService.setScenarioStepStatusFailed(any(), anyString()))
                .thenAnswer(inv -> inv.getArgument(0));
        Mockito.lenient().when(executorFactory.createExecutor(any(ScenarioRunNode.class)))
                .thenAnswer(inv -> nodeExecutor(inv.getArgument(0)));
        ScenarioEngine engine = new ScenarioEngine(runService, stepService, executorFactory,
                Mockito.mock(DocsTextCacheService.class), Mockito.mock(ScenarioRepository.class),
                Mockito.mock(ScenarioOutputSupportService.class), 1);
        ReflectionTestUtils.setField(engine, "parallelEnabled", parallel);
        ReflectionTestUtils.setField(engine, "parallelThreads", 2);
        engines.add(engine);
        return engine;
    }

    private AbstractScenarioExecutor nodeExecutor(ScenarioRunNode node) {
        return new AbstractScenarioExecutor(node) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
                Consumer<ScenarioRunNode> body = nodeBodies.get(node.getGraph().getRunId());
                if (body != null && node.getType() == ScenarioNodeType.INPUT_NODE) {
                    body.accept(node);
                }
                for (var next : node.getChildNodeList()) {
                    next.setSkip(false);
                }
                return "результат " + node.getId();
            }

            @Override
            public String getPrompt() {
                return "";
            }
        };
    }

    private static CountDownLatch subscribe(Flux<ServerSentEvent<Map<String, Object>>> flux,
                                            List<ServerSentEvent<Map<String, Object>>> events) {
        CountDownLatch done = new CountDownLatch(1);
        flux.subscribe(events::add, error -> done.countDown(), done::countDown);
        return done;
    }

    private static ScenarioRun run() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(UUID.randomUUID());
        run.setStatus("running");
        return run;
    }

    private static ScenarioRunStep step() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setNodeId("node-1");
        step.setStatus("running");
        return step;
    }

    private static NodeDto node(String id, ScenarioNodeType type) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(id).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static GraphDataDto twoNodeGraph() {
        return new GraphDataDto(List.of(node("node-1", ScenarioNodeType.INPUT_NODE), node("node-2", ScenarioNodeType.OUTPUT_NODE)),
                List.of(new EdgeDto("e1", "node-1", "node-2", new EdgeDataDto(null))));
    }

    /** Цепочка «Вход → Выход … → Выход» из {@code count} узлов. */
    private static GraphDataDto chainGraph(int count) {
        List<NodeDto> nodes = new ArrayList<>();
        List<EdgeDto> edges = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            nodes.add(node("n" + i, i == 1 ? ScenarioNodeType.INPUT_NODE : ScenarioNodeType.OUTPUT_NODE));
            if (i > 1) {
                edges.add(new EdgeDto("e" + i, "n" + (i - 1), "n" + i, new EdgeDataDto(null)));
            }
        }
        return new GraphDataDto(nodes, edges);
    }

    private static boolean awaitLatch(CountDownLatch latch, int seconds) {
        try {
            return latch.await(seconds, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }
}
