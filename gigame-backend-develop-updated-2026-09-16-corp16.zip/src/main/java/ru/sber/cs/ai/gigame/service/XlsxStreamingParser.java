package ru.sber.cs.ai.gigame.service;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.util.XMLHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Потоковый (SAX) разбор XLSX в текст того же формата, что даёт DOM-парсер
 * {@code DocumentService.parseWorkbook}: строки листа — ячейки через " | "
 * (пустые сохраняются), при нескольких листах каждый предваряется строкой
 * "=== Лист: [название] ===", между листами пустая строка, для формул берётся
 * сохранённое в файле значение (без сохранённого значения — «=формула»).
 * Листы сверх лимита и обрезка строк помечаются маркерами на каждом затронутом листе.
 * <p>
 * DOM-модель XSSF на книге в 8 МБ (37 тысяч строк по 47 колонок — финансовая
 * структура банка) требовала больше 3 ГБ кучи и падала с OutOfMemoryError ещё
 * при загрузке файла. Потоковый разбор держит в памяти только текущую строку.
 */
final class XlsxStreamingParser {

    private static final String SHEET_HEADER = "=== Лист: ";
    private static final String NS_SPREADSHEETML = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    private XlsxStreamingParser() {
    }

    /**
     * Текст книги.
     *
     * @param inputStream поток XLSX
     * @param maxSheets   максимум листов (остальные пропускаются с пометкой)
     * @param maxRows     максимум строк суммарно по всем листам (остальные пропускаются с пометкой)
     * @return текст в формате DOM-парсера
     * @throws IOException если книга не читается
     */
    static String parse(InputStream inputStream, int maxSheets, int maxRows) throws IOException {
        List<List<String>> sheets = new ArrayList<>();
        List<String> names = new ArrayList<>();
        List<String> skipped = new ArrayList<>();
        try (OPCPackage pkg = OPCPackage.open(inputStream)) {
            XSSFReader reader = new XSSFReader(pkg);
            StylesTable styles = reader.getStylesTable();
            ReadOnlySharedStringsTable strings = new ReadOnlySharedStringsTable(pkg);
            XSSFReader.SheetIterator sheetIterator = (XSSFReader.SheetIterator) reader.getSheetsData();
            RowCollector collector = new RowCollector(maxRows);
            while (sheetIterator.hasNext() && sheets.size() < maxSheets) {
                sheets.add(readSheet(sheetIterator.next(), styles, strings, collector));
                names.add(sheetIterator.getSheetName());
            }
            skipped.addAll(remainingSheetNames(sheetIterator));
        } catch (OpenXML4JException | SAXException | ParserConfigurationException e) {
            throw new IOException("XLSX не разобран: " + e.getMessage(), e);
        }
        return assemble(sheets, names, skipped, maxSheets);
    }

    /** Имена листов сверх лимита (потоки листов закрываются не читая). */
    private static List<String> remainingSheetNames(XSSFReader.SheetIterator sheetIterator) throws IOException {
        List<String> skipped = new ArrayList<>();
        while (sheetIterator.hasNext()) {
            sheetIterator.next().close();
            skipped.add(sheetIterator.getSheetName());
        }
        return skipped;
    }

    private static List<String> readSheet(InputStream sheet, StylesTable styles, ReadOnlySharedStringsTable strings,
                                          RowCollector collector) throws IOException, SAXException, ParserConfigurationException {
        try (sheet) {
            collector.startSheet();
            XMLReader xmlReader = XMLHelper.newXMLReader();
            var handler = new XSSFSheetXMLHandler(styles, null, strings, collector, new RussianDateFormatter(), false);
            xmlReader.setContentHandler(new FormulaTracker(handler, collector));
            xmlReader.parse(new InputSource(sheet));
            return collector.rows();
        }
    }

    private static String assemble(List<List<String>> sheets, List<String> names, List<String> skipped, int maxSheets) {
        StringBuilder out = new StringBuilder();
        for (int s = 0; s < sheets.size(); s++) {
            if (sheets.size() > 1 || !skipped.isEmpty()) {
                out.append(SHEET_HEADER).append(names.get(s)).append(" ===\n");
            }
            for (String row : sheets.get(s)) {
                out.append(row).append('\n');
            }
            // пустая строка между листами (как в DOM-парсере: пустой элемент + join по \n)
            out.append('\n');
        }
        if (!skipped.isEmpty()) {
            out.append("[... листы сверх лимита ").append(maxSheets).append(" не разобраны (").append(skipped.size())
                    .append("): ").append(String.join(", ", skipped)).append(" ...]\n\n");
        }
        return out.length() == 0 ? "" : out.substring(0, out.length() - 1);
    }

    /**
     * Перехватывает формулу (f) и наличие сохранённого значения (v) каждой ячейки:
     * стандартный обработчик отдаёт ячейку только по закрывающему {@code v}, и
     * ячейка с формулой без сохранённого результата пропадала из строки вовсе —
     * трекер отдаёт её сам как «=формула».
     */
    private static final class FormulaTracker extends DefaultHandler {
        private final XSSFSheetXMLHandler delegate;
        private final RowCollector collector;
        private final StringBuilder formula = new StringBuilder();
        private String cellRef;
        private boolean inFormula;
        private boolean hasValue;

        FormulaTracker(XSSFSheetXMLHandler delegate, RowCollector collector) {
            this.delegate = delegate;
            this.collector = collector;
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if (uri == null || uri.equals(NS_SPREADSHEETML)) {
                if ("c".equals(localName)) {
                    formula.setLength(0);
                    hasValue = false;
                    cellRef = attributes.getValue("r");
                } else if ("f".equals(localName)) {
                    inFormula = true;
                } else if ("v".equals(localName) || "is".equals(localName)) {
                    hasValue = true;
                }
            }
            delegate.startElement(uri, localName, qName, attributes);
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            delegate.endElement(uri, localName, qName);
            if (uri == null || uri.equals(NS_SPREADSHEETML)) {
                if ("f".equals(localName)) {
                    inFormula = false;
                } else if ("c".equals(localName) && !hasValue && !formula.toString().isBlank()) {
                    collector.cell(cellRef, "=" + formula.toString().strip(), null);
                }
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            if (inFormula) {
                formula.append(ch, start, length);
            }
            delegate.characters(ch, start, length);
        }
    }

    /** Собирает строки листа: ячейки по индексу колонки, пропуски — пустые ячейки. */
    private static final class RowCollector implements XSSFSheetXMLHandler.SheetContentsHandler {
        private final int maxRows;
        private int totalRows;
        private boolean truncated;
        private List<String> rows = new ArrayList<>();
        private List<String> cells = new ArrayList<>();

        RowCollector(int maxRows) {
            this.maxRows = maxRows;
        }

        void startSheet() {
            rows = new ArrayList<>();
            truncated = false;
        }

        List<String> rows() {
            return rows;
        }

        @Override
        public void startRow(int rowNum) {
            cells = new ArrayList<>();
        }

        @Override
        public void endRow(int rowNum) {
            if (totalRows >= maxRows) {
                if (!truncated) {
                    rows.add("[...обрезано: больше " + maxRows + " строк]");
                    truncated = true;
                }
                return;
            }
            totalRows++;
            rows.add(String.join(" | ", cells));
        }

        @Override
        public void cell(String cellReference, String formattedValue, XSSFComment comment) {
            int col = cellReference == null ? cells.size() : new CellReference(cellReference).getCol();
            while (cells.size() < col) {
                cells.add("");
            }
            String value = formattedValue == null ? "" : formattedValue.replaceAll("[\r\n]+", " ").strip();
            if (col < cells.size()) {
                cells.set(col, value);
            } else {
                cells.add(value);
            }
        }
    }
}
