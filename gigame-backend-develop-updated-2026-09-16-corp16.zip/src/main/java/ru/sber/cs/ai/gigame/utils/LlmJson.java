package ru.sber.cs.ai.gigame.utils;

import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

/**
 * Единый разбор JSON из ответов модели (и выходов узлов) — вместо расходящихся
 * эвристик узлов.
 * <p>
 * Кандидаты в порядке приоритета: содержимое блоков {@code ```json … ```} (и {@code ``` … ```}),
 * весь текст целиком, затем сбалансированные блоки {@code {…}} / {@code […]} — по индексу
 * скобок одним линейным проходом ({@link JsonCalcUtils.BracketIndex}); сначала скобки вне
 * строковых литералов, при неудаче — внутри них (как прежний посимвольный перебор).
 * Каждый кандидат разбирается строго, затем терпимо (комментарии, висячие запятые,
 * одинарные кавычки), затем с узкой починкой десятичной запятой
 * ({@link JsonCalcUtils#sanitizeDecimalCommas}). Принимаются только объекты и массивы.
 * <p>
 * Политики выбора ({@link Policy}) сохраняют прежнее поведение узлов: первый массив
 * объектов, последний массив объектов, все массивы, самый большой блок, только весь документ.
 */
public final class LlmJson {

    /** Политика выбора блоков. */
    public enum Policy {
        /** Первый разбираемый объект или массив. */
        FIRST,
        /** Первый непустой массив объектов; если таких нет — первый пустой массив. */
        FIRST_OBJECT_ARRAY,
        /** Последний массив, содержащий объекты (или пустой), — перебор с конца. */
        LAST_OBJECT_ARRAY,
        /** Все непересекающиеся массивы объектов (и пустые) по порядку. */
        ALL_ARRAYS,
        /** Все непересекающиеся объекты по порядку. */
        ALL_OBJECTS,
        /** Самый длинный разбираемый блок. */
        LARGEST,
        /** Только весь текст целиком (либо содержимое единственного блока {@code ```json}). */
        WHOLE_DOCUMENT_ONLY
    }

    /** Любой объект или массив. */
    public static final Predicate<JsonNode> ANY = JsonNode::isContainerNode;

    /** JSON-объект. */
    public static final Predicate<JsonNode> OBJECT = JsonNode::isObject;

    /** Любой массив. */
    public static final Predicate<JsonNode> ARRAY = JsonNode::isArray;

    /** Непустой массив, первый элемент которого — объект. */
    public static final Predicate<JsonNode> OBJECT_ARRAY = n -> n.isArray() && !n.isEmpty() && n.get(0).isObject();

    /** Пустой массив. */
    public static final Predicate<JsonNode> EMPTY_ARRAY = n -> n.isArray() && n.isEmpty();

    /** Массив, среди элементов которого есть объект. */
    public static final Predicate<JsonNode> ARRAY_WITH_OBJECTS = n -> n.isArray() && hasObject(n);

    /** Массив без элементов либо только из объектов. */
    public static final Predicate<JsonNode> ARRAY_OF_OBJECTS_OR_EMPTY = n -> n.isArray() && (n.isEmpty() || allObjects(n));

    private static final String FENCE = "```";

    private static final ObjectMapper STRICT = JsonMapper.builder()
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .build();

    private static final ObjectMapper TOLERANT = JsonMapper.builder()
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .enable(JsonReadFeature.ALLOW_JAVA_COMMENTS)
            .enable(JsonReadFeature.ALLOW_YAML_COMMENTS)
            .enable(JsonReadFeature.ALLOW_TRAILING_COMMA)
            .enable(JsonReadFeature.ALLOW_SINGLE_QUOTES)
            .build();

    private LlmJson() {
    }

    /**
     * Разобранный блок.
     *
     * @param node   дерево JSON
     * @param start  начало блока в тексте
     * @param end    конец блока в тексте (исключительно)
     * @param source исходный текст блока
     * @param strict блок разобран строгим парсером (исходный текст — корректный JSON)
     */
    public record Parsed(JsonNode node, int start, int end, String source, boolean strict) {

        /**
         * Текст блока, пригодный для повторного разбора: исходный, если он корректен,
         * иначе сериализованное дерево.
         *
         * @return JSON
         */
        public String json() {
            return strict ? source : node.toString();
        }

        /**
         * Значение блока как {@link java.util.Map} / {@link java.util.List} (изменяемые).
         *
         * @return значение
         */
        public Object value() {
            return toValue(node);
        }
    }

    /**
     * Результат выбора.
     *
     * @param blocks    блоки в порядке политики
     * @param lastError ошибка последнего неразобранного кандидата (null — кандидатов не было или все разобраны)
     */
    public record Selection(List<Parsed> blocks, String lastError) {

        /**
         * Первый блок либо null.
         *
         * @return блок
         */
        public Parsed first() {
            return blocks.isEmpty() ? null : blocks.get(0);
        }

        /**
         * Ни один блок не выбран.
         *
         * @return {@code true}, если блоков нет
         */
        public boolean isEmpty() {
            return blocks.isEmpty();
        }
    }

    /**
     * Выбор блоков по политике.
     *
     * @param text   текст
     * @param policy политика
     * @return результат
     */
    public static Selection select(String text, Policy policy) {
        return switch (policy) {
            case FIRST -> first(text, ANY);
            case FIRST_OBJECT_ARRAY -> firstObjectArray(text);
            case LAST_OBJECT_ARRAY -> last(text, n -> ARRAY_WITH_OBJECTS.test(n) || EMPTY_ARRAY.test(n));
            case ALL_ARRAYS -> all(text, n -> ARRAY_WITH_OBJECTS.test(n) || EMPTY_ARRAY.test(n));
            case ALL_OBJECTS -> all(text, OBJECT);
            case LARGEST -> largest(text, ANY);
            case WHOLE_DOCUMENT_ONLY -> whole(text, ANY);
        };
    }

    /**
     * Первый (по приоритету кандидатов) блок, отвечающий условию.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection first(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        for (List<int[]> group : scan.groupsForward()) {
            for (int[] range : group) {
                Parsed parsed = scan.parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    return new Selection(List.of(parsed), scan.lastError);
                }
            }
        }
        return new Selection(List.of(), scan.lastError);
    }

    /**
     * Последний блок, отвечающий условию: блоки перебираются с конца текста.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection last(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        for (List<int[]> group : scan.groupsBackward()) {
            for (int[] range : group) {
                Parsed parsed = scan.parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    return new Selection(List.of(parsed), scan.lastError);
                }
            }
        }
        return new Selection(List.of(), scan.lastError);
    }

    /**
     * Все непересекающиеся блоки по порядку: принятый блок пропускается целиком
     * (вложенные в него не рассматриваются), непринятый — разбирается изнутри.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат
     */
    public static Selection all(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        for (List<int[]> group : scan.balancedGroups()) {
            List<Parsed> found = new ArrayList<>();
            int consumedTo = 0;
            for (int[] range : group) {
                if (range[0] < consumedTo) {
                    continue;
                }
                Parsed parsed = scan.parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    found.add(parsed);
                    consumedTo = range[1];
                }
            }
            if (!found.isEmpty()) {
                return new Selection(found, scan.lastError);
            }
        }
        return new Selection(List.of(), scan.lastError);
    }

    /**
     * Самый длинный разбираемый блок, отвечающий условию (при равенстве — первый).
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection largest(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        Parsed best = null;
        for (List<int[]> group : scan.groupsForward()) {
            for (int[] range : group) {
                if (best != null && range[1] - range[0] <= best.end() - best.start()) {
                    continue;
                }
                Parsed parsed = scan.parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    best = parsed;
                }
            }
        }
        return new Selection(best == null ? List.of() : List.of(best), scan.lastError);
    }

    /**
     * Только документ целиком: содержимое единственного блока {@code ```json} либо весь текст.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection whole(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        List<int[]> fenced = scan.fencedRanges();
        int[] range = fenced.size() == 1 ? fenced.get(0) : scan.wholeRange();
        Parsed parsed = range == null ? null : scan.parse(range);
        boolean ok = parsed != null && accept.test(parsed.node());
        return new Selection(ok ? List.of(parsed) : List.of(), scan.lastError);
    }

    /**
     * Первый непустой массив объектов; если таких нет — первый пустой массив
     * (пустой «[]» другого узла перед массивом объектов не должен «съедать» строки).
     *
     * @param text текст
     * @return результат (не более одного блока)
     */
    public static Selection firstObjectArray(String text) {
        Selection objects = first(text, OBJECT_ARRAY);
        if (!objects.isEmpty()) {
            return objects;
        }
        Selection empty = first(text, EMPTY_ARRAY);
        return new Selection(empty.blocks(), objects.lastError() == null ? empty.lastError() : objects.lastError());
    }

    /**
     * Дерево как значение: {@link java.util.LinkedHashMap} / {@link java.util.ArrayList}
     * (изменяемые), числа — Integer/Long/Double/BigInteger.
     *
     * @param node дерево
     * @return значение
     */
    public static Object toValue(JsonNode node) {
        return STRICT.convertValue(node, Object.class);
    }

    private static boolean hasObject(JsonNode array) {
        for (JsonNode item : array) {
            if (item.isObject()) {
                return true;
            }
        }
        return false;
    }

    private static boolean allObjects(JsonNode array) {
        for (JsonNode item : array) {
            if (!item.isObject()) {
                return false;
            }
        }
        return true;
    }

    /** Кандидаты одного текста и их разбор. */
    private static final class Scan {

        private final String text;
        private final JsonCalcUtils.BracketIndex index;
        private String lastError;

        Scan(String text) {
            this.text = text == null ? "" : text;
            this.index = JsonCalcUtils.indexOf(this.text);
        }

        /** Группы кандидатов по приоритету: блоки ```, весь текст, скобки вне литералов, скобки внутри. */
        List<List<int[]>> groupsForward() {
            List<List<int[]>> groups = new ArrayList<>();
            groups.add(fencedRanges());
            int[] whole = wholeRange();
            groups.add(whole == null ? List.of() : List.of(whole));
            groups.addAll(balancedGroups());
            return groups;
        }

        /** То же с конца: блоки ``` и сбалансированные блоки в обратном порядке (весь текст — крайний блок). */
        List<List<int[]>> groupsBackward() {
            List<List<int[]>> groups = new ArrayList<>();
            groups.add(reversed(fencedRanges()));
            for (List<int[]> group : balancedGroups()) {
                groups.add(reversed(group));
            }
            return groups;
        }

        /** Сбалансированные блоки: сначала по скобкам вне строковых литералов, затем внутри них. */
        List<List<int[]>> balancedGroups() {
            List<Integer> outside = index.opensOutsideLiterals();
            List<int[]> first = ranges(outside);
            List<int[]> second = ranges(index.opensInsideLiterals());
            List<List<int[]>> groups = new ArrayList<>();
            groups.add(first);
            groups.add(second);
            return groups;
        }

        List<int[]> fencedRanges() {
            List<int[]> ranges = new ArrayList<>();
            int at = text.indexOf(FENCE);
            while (at >= 0) {
                int start = at + FENCE.length();
                while (start < text.length() && Character.isLetter(text.charAt(start))) {
                    start++;
                }
                int close = text.indexOf(FENCE, start);
                int end = close < 0 ? text.length() : close;
                int[] trimmed = trimmed(start, end);
                if (trimmed != null) {
                    ranges.add(trimmed);
                }
                at = close < 0 ? -1 : text.indexOf(FENCE, close + FENCE.length());
            }
            return ranges;
        }

        int[] wholeRange() {
            return trimmed(0, text.length());
        }

        private int[] trimmed(int from, int to) {
            int start = from;
            int end = to;
            while (start < end && Character.isWhitespace(text.charAt(start))) {
                start++;
            }
            while (end > start && Character.isWhitespace(text.charAt(end - 1))) {
                end--;
            }
            return start < end ? new int[]{start, end} : null;
        }

        private List<int[]> ranges(List<Integer> opens) {
            List<int[]> ranges = new ArrayList<>();
            for (int open : opens) {
                int close = index.matchOf(open);
                if (close > open) {
                    ranges.add(new int[]{open, close + 1});
                }
            }
            return ranges;
        }

        private static List<int[]> reversed(List<int[]> ranges) {
            List<int[]> copy = new ArrayList<>(ranges);
            Collections.reverse(copy);
            return copy;
        }

        /** Разбор кандидата: строго, терпимо, с починкой десятичной запятой; null — не разобран. */
        Parsed parse(int[] range) {
            String source = text.substring(range[0], range[1]);
            char c = source.charAt(0);
            if (c != '{' && c != '[') {
                return null;
            }
            JsonNode node = read(STRICT, source);
            if (node != null) {
                return new Parsed(node, range[0], range[1], source, true);
            }
            node = read(TOLERANT, source);
            if (node == null) {
                node = read(TOLERANT, JsonCalcUtils.sanitizeDecimalCommas(source));
            }
            return node == null ? null : new Parsed(node, range[0], range[1], source, false);
        }

        private JsonNode read(ObjectMapper mapper, String source) {
            try {
                JsonNode node = mapper.readTree(source);
                return node != null && node.isContainerNode() ? node : null;
            } catch (Exception e) {
                lastError = e.getMessage();
                return null;
            }
        }
    }
}
