package ru.sber.cs.ai.gigame.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Распознавание PDF-сканов через файловое хранилище GigaChat.
 * <p>
 * PDF без текстового слоя загружается в хранилище GigaChat вложением к запросу
 * «выпиши содержимое» — модель распознаёт скан и возвращает текст, который
 * дальше идёт по обычному конвейеру сценария (группировка, проверки, суммы).
 * Файл после распознавания удаляется из хранилища.
 * <p>
 * Многостраничный скан распознаётся постранично ({@code app.document.ocr-per-page},
 * по умолчанию включено): на весь документ модель отвечает пересказом
 * (шестистраничная заявка — 2,5 тыс. знаков, состав работ потерян), а на
 * одну страницу — переписывает её полностью (8,4 тыс. знаков на тот же
 * документ). Страницы с текстовым слоем (штамп ЭДО) не распознаются, а
 * берутся как есть; свыше {@code app.document.ocr-max-pages} страниц остаток
 * помечается нераспознанным. Многостраничный документ, распознанный целиком
 * (постраничный режим выключен или PDF не разбирается PDFBox), помечается
 * отдельным префиксом {@link #OCR_WHOLE_PREFIX} — это пересказ.
 * <p>
 * Отказ модели («предоставьте документ») не принимается за текст: после запасного
 * промпта страница получает маркер {@link #PAGE_REFUSED_MARKER}, документ целиком —
 * маркер ручной проверки {@link #DOC_REFUSED_PREFIX}.
 * <p>
 * Выключено по умолчанию: {@code app.document.ocr-via-gigachat=true}
 * (env {@code OCR_VIA_GIGACHAT}) включает. Результат помечается префиксом
 * {@link #OCR_PREFIX} — суммы из скана в итоговой форме стоит перепроверять.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ScanOcrService {

    /** Префикс распознанного текста — виден конвейеру и в итоговой форме. */
    public static final String OCR_PREFIX = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены "
            + "автоматическим распознаванием, суммы рекомендуется перепроверить]";

    /** Префикс многостраничного скана, распознанного целиком: модель пересказывает, строки таблиц могут быть потеряны. */
    public static final String OCR_WHOLE_PREFIX = "[РАСПОЗНАНО ИЗ СКАНА ЦЕЛИКОМ — пересказ модели, "
            + "строки таблиц и суммы могли быть потеряны, документ рекомендуется проверить вручную]";

    /** Начало маркера документа, который модель отказалась распознавать. */
    public static final String DOC_REFUSED_PREFIX = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «";

    /** Маркер страницы, распознать которую модель отказалась (номер страницы — в тексте). */
    static final String PAGE_REFUSED_MARKER = "не распознана: отказ модели]";

    /** Маркер обрыва ответа модели по лимиту токенов (ставит {@link GigaChatClient#chatCompletionWithFile}). */
    static final String TRUNCATED_MARKER = GigaChatClient.TRUNCATED_MARKER;

    /**
     * Формулировка «выпиши содержимое» вместо «перепиши дословно текст вложения»:
     * на просьбу дословной переписки вложения GigaChat отвечает шаблонным отказом,
     * хотя файл обработан и находится в контексте (проверено экспериментально).
     */
    private static final String OCR_PROMPT = """
            Это отсканированный финансовый документ. Выпиши максимально полно его \
            содержимое в текстовом виде: тип и реквизиты документа (номера, даты), \
            стороны (исполнитель, заказчик, ИНН), основание (договор, спецификация), \
            таблицу работ построчно (колонки через « | »), все суммы, включая ИТОГО \
            с НДС. Нечитаемые фрагменты помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя.""";

    /** Постраничный запрос: одна страница переписывается полностью, без пересказа. */
    private static final String PAGE_PROMPT = """
            Это страница отсканированного финансового документа. Выпиши максимально полно \
            и дословно весь текст страницы: заголовки, реквизиты (номера, даты), стороны, \
            таблицы построчно (колонки через « | »), все суммы. Нечитаемые фрагменты \
            помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя и не сокращай.""";

    /** Отказ модели переписать страницу — повтор с промптом «выпиши содержимое» (на него отказов нет). */
    private static final Pattern REFUSAL = Pattern.compile(
            "невозможно сформировать|Из предоставленного контекста|предоставьте полн|не могу выполнить|не содержит текст"
                    + "|не является отсканированным", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Маркер нераспознанной страницы: «[страница N не распознана: отказ модели]». */
    private static final Pattern PAGE_REFUSED = Pattern.compile("\\[страница (\\d+) " + Pattern.quote(PAGE_REFUSED_MARKER));
    private static final int REFUSAL_WINDOW = 400;
    private static final double OCR_TEMPERATURE = 0.01;
    private static final String PDF = "application/pdf";

    private final GigaChatClient gigaChatClient;

    @Value("${app.document.ocr-via-gigachat:false}")
    private boolean enabled;

    /** Модель для распознавания (пусто — глобальная модель по умолчанию). */
    @Value("${app.document.ocr-model:}")
    private String ocrModel;

    /** Лимит токенов ответа — страница либо документ целиком. */
    @Value("${app.document.ocr-max-tokens:8000}")
    private int ocrMaxTokens = 8000;

    /** Постраничное распознавание многостраничных сканов. */
    @Value("${app.document.ocr-per-page:true}")
    private boolean ocrPerPage = true;

    /** Максимум распознаваемых страниц одного документа. */
    @Value("${app.document.ocr-max-pages:40}")
    private int ocrMaxPages = 40;

    /** Порог текстового слоя страницы: короче — страница-картинка, распознаётся. */
    @Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars = 40;

    /**
     * Одновременных запросов распознавания к GigaChat. Пул разбора документов —
     * 4 потока, и четыре параллельных OCR упирались в лимит запросов корп-ключа
     * (429 с паузами 30–300 с: 16 сканов Комплекта 4 шли 31 минуту вместо ~10).
     */
    @Value("${app.document.ocr-parallelism:1}")
    private int ocrParallelism = 1;

    private Semaphore ocrSlots;

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Распознаёт PDF-скан через GigaChat: постранично для многостраничного
     * документа, целиком для одностраничного.
     *
     * @param filename имя файла (для хранилища и префикса)
     * @param content  содержимое PDF
     * @return распознанный текст с префиксом {@link #OCR_PREFIX} (либо
     *         {@link #OCR_WHOLE_PREFIX} для многостраничного документа, распознанного целиком;
     *         маркер {@link #DOC_REFUSED_PREFIX} при отказе модели)
     */
    public String recognize(String filename, byte[] content) {
        log.info("OCR скана через GigaChat: {} ({} КБ)", filename, content.length / 1024);
        int total = pageCount(content);
        List<String> pages = ocrPerPage && total > 1 ? recognizePages(filename, content) : List.of();
        if (!pages.isEmpty()) {
            return OCR_PREFIX + " Документ «" + filename + "»:\n" + String.join("\n\n", pages);
        }
        String text = ask(OCR_PROMPT, filename, content);
        if (isRefusal(text)) {
            // одностраничный документ: отказ модели повторяется запасным промптом, как и страница
            log.info("OCR «{}»: отказ модели на документе целиком, повтор с запасным промптом", filename);
            text = ask(PAGE_PROMPT, filename, content);
        }
        if (isRefusal(text)) {
            log.warn("OCR «{}»: модель отказалась распознавать документ и после запасного промпта", filename);
            return DOC_REFUSED_PREFIX + filename + "» не распознан: модель отказалась распознавать скан. "
                    + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
        }
        String head = (total == 1 ? OCR_PREFIX : OCR_WHOLE_PREFIX) + " Документ «" + filename + "»:\n";
        return head + text;
    }

    /** Число страниц PDF; -1, если PDFBox не разбирает файл. */
    private static int pageCount(byte[] content) {
        try (PDDocument doc = Loader.loadPDF(content)) {
            return doc.getNumberOfPages();
        } catch (IOException e) {
            return -1;
        }
    }

    /**
     * Постраничное распознавание: страницы с текстовым слоем берутся как есть,
     * остальные распознаются по одной; сбой одной страницы не роняет документ.
     *
     * @return тексты страниц с маркерами «--- страница N ---»; пусто, если документ
     *         не разбирается PDFBox (тогда — распознавание целиком)
     */
    private List<String> recognizePages(String filename, byte[] content) {
        List<String> parts = new ArrayList<>();
        try (PDDocument doc = Loader.loadPDF(content)) {
            int total = doc.getNumberOfPages();
            PDFTextStripper stripper = new PDFTextStripper();
            for (int page = 1; page <= Math.min(total, ocrMaxPages); page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);
                String layer = stripper.getText(doc).strip();
                if (layer.length() >= minParsedChars) {
                    parts.add("--- страница " + page + " (текстовый слой) ---\n" + layer);
                    continue;
                }
                parts.add("--- страница " + page + " ---\n" + recognizePage(filename, doc, page));
            }
            if (total > ocrMaxPages) {
                parts.add("[страницы " + (ocrMaxPages + 1) + "–" + total + " не распознаны: превышен лимит страниц OCR "
                        + ocrMaxPages + "]");
            }
            log.info("OCR «{}»: страниц {}, распознано постранично {}", filename, total, Math.min(total, ocrMaxPages));
        } catch (IOException e) {
            log.warn("OCR «{}»: PDF не разбирается постранично ({}) — распознаётся целиком", filename, e.getMessage());
            return List.of();
        }
        return parts;
    }

    private String recognizePage(String filename, PDDocument doc, int page) {
        try (PDDocument single = new PDDocument()) {
            single.importPage(doc.getPage(page - 1));
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            single.save(out);
            String text = ask(PAGE_PROMPT, "page-" + page + ".pdf", out.toByteArray());
            if (isRefusal(text)) {
                log.info("OCR «{}»: страница {} — отказ модели, повтор с запасным промптом", filename, page);
                text = ask(OCR_PROMPT, "page-" + page + ".pdf", out.toByteArray());
            }
            if (isRefusal(text)) {
                log.warn("OCR «{}»: страница {} — отказ модели и после запасного промпта", filename, page);
                return "[страница " + page + " " + PAGE_REFUSED_MARKER;
            }
            return text;
        } catch (IOException e) {
            log.warn("OCR «{}»: страница {} не выделена ({})", filename, page, e.getMessage());
            return "[страница " + page + " не распознана: " + e.getMessage() + "]";
        }
    }

    /** Отказ модели (вместо текста — просьба предоставить документ) в начале ответа. */
    static boolean isRefusal(String text) {
        String head = text == null ? "" : text.substring(0, Math.min(text.length(), REFUSAL_WINDOW));
        return REFUSAL.matcher(head).find();
    }

    /**
     * Текст предупреждения загрузки по результату распознавания: отказ модели,
     * распознавание целиком (пересказ), нераспознанные страницы, обрыв ответа
     * либо обычное «распознан — проверьте суммы».
     *
     * @param recognized результат {@link #recognize(String, byte[])}
     * @return текст для upload_warning
     */
    public static String uploadWarning(String recognized) {
        if (recognized.startsWith(DOC_REFUSED_PREFIX)) {
            return "PDF-скан не распознан: модель отказалась распознавать документ — требуется ручная проверка";
        }
        List<String> notes = new ArrayList<>();
        if (recognized.startsWith(OCR_WHOLE_PREFIX)) {
            notes.add("многостраничный скан распознан целиком (пересказ) — строки таблиц могли быть потеряны");
        }
        List<String> refused = new ArrayList<>();
        Matcher m = PAGE_REFUSED.matcher(recognized);
        while (m.find()) {
            refused.add(m.group(1));
        }
        if (!refused.isEmpty()) {
            notes.add("страницы " + String.join(", ", refused) + " не распознаны: отказ модели");
        }
        if (recognized.contains(TRUNCATED_MARKER)) {
            notes.add("ответ модели оборван по лимиту длины — часть текста не распознана");
        }
        String base = "PDF-скан распознан через GigaChat — проверьте суммы";
        return notes.isEmpty() ? base : base + "; " + String.join("; ", notes);
    }

    /** Запрос к GigaChat под ограничителем одновременных распознаваний. */
    private String ask(String prompt, String filename, byte[] content) {
        Semaphore slots = slots();
        slots.acquireUninterruptibly();
        try {
            var result = gigaChatClient.chatCompletionWithFile(prompt, filename, content, PDF,
                    ocrModel == null || ocrModel.isBlank() ? null : ocrModel, OCR_TEMPERATURE, ocrMaxTokens);
            return result.text();
        } finally {
            slots.release();
        }
    }

    /** Ограничитель создаётся лениво: поле {@code ocrParallelism} заполняется после конструктора. */
    private synchronized Semaphore slots() {
        if (ocrSlots == null) {
            ocrSlots = new Semaphore(Math.max(1, ocrParallelism));
        }
        return ocrSlots;
    }
}
