package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitLoopProgressEvent;

@Slf4j
public class ScenarioExecutorLoopNode extends AbstractScenarioExecutor {
    private static final String PROMPT_STRICT_CLASSIFY = "Определи тип документа. Верни СТРОГО ОДНУ ФРАЗУ — название класса из списка: ";
    private static final String PROMPT_CLASSIFICATION_HINT = "\nПодсказка для классификации:\n";
    private static final String PROMPT_INSTRUCTION_SUFFIX = "\nНе пиши пояснений, не повторяй задание, не добавляй знаков препинания.\n\nДокумент:\n";
    /** Местозаполнитель текста документа/элемента в шаблоне промпта, сохраняемом в шаг прогона. */
    static final String DOC_PLACEHOLDER = "[текст документа — на каждой итерации подставляется свой]";
    /** Предел элементов цикла по списку по умолчанию (настройка {@code app.scenario.loop-max-items}). */
    public static final int DEFAULT_MAX_ITEMS = 1000;
    private final GigaChatClient gigaChatClient;
    private int delayBetweenIterations;
    private int maxItems = DEFAULT_MAX_ITEMS;
    /**
     * Лимиты текста документа для классификации: начало (шапка/титул) + конец (подписи).
     * Полный текст для определения типа не нужен и расходует токены на больших документах.
     */
    private int classifyHeadChars = 5000;
    private int classifyTailChars = 2000;

    @SuppressWarnings("unused")
    protected ScenarioExecutorLoopNode(ScenarioRunNode node) {
        super(node);
        this.gigaChatClient = null;
        this.delayBetweenIterations = 1000;
    }

    protected ScenarioExecutorLoopNode(ScenarioRunNode node,
                                       GigaChatClient gigaChatClient) {
        super(node);
        this.gigaChatClient = gigaChatClient;
        this.delayBetweenIterations = 1000;
    }

    /**
     * Sets configuration value from Spring properties.
     * Called by ScenarioExecutorFactory after bean creation.
     */
    protected void setDelayBetweenIterations(int delayBetweenIterations) {
        this.delayBetweenIterations = delayBetweenIterations;
    }

    /**
     * Sets configuration values from Spring properties.
     * Called by ScenarioExecutorFactory after bean creation.
     */
    protected void setClassifyLimits(int pClassifyHeadChars, int pClassifyTailChars) {
        this.classifyHeadChars = pClassifyHeadChars;
        this.classifyTailChars = pClassifyTailChars;
    }

    /**
     * Ставит предел элементов цикла по списку (настройка {@code app.scenario.loop-max-items}).
     *
     * @param limit предел (меньше 1 — значение по умолчанию)
     */
    protected void setMaxItems(int limit) {
        this.maxItems = limit < 1 ? DEFAULT_MAX_ITEMS : limit;
    }

    private void delayBetweenIterations() {
        try {
            Mono.delay(Duration.ofMillis(delayBetweenIterations), Schedulers.boundedElastic()).block();
        } catch (Exception e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Выполняет узел цикла (Loop).
     * <p>
     * Обрабатывает каждый документ отдельно. Два режима работы:
     * <ul>
     *   <li>classify_strict=true — строгая классификация: возвращает одно слово — класс документа</li>
     *   <li>classify_strict=false — анализ: полный промпт для свободного ответа</li>
     * </ul>
     *
     * @param sink поток SSE-событий
     * @return объединённый результат по всем документам
     */
    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] LoopNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        if ("list".equals(node.getMode())) {
            return executeOverList(sink);
        }
        var docs = node.getDocList();
        boolean classifyStrict = node.isClassifyStrict();
        String classesHint = node.getClasses();
        List<String> loopResults = new ArrayList<>();
        for (int i = 0; i < docs.size(); i++) {
            // остановка прогона проверяется перед каждой итерацией, а не только на границе узла
            node.getGraph().checkNotCancelled();
            if (classifyStrict) {
                loopResults.addAll(analyzeWithClassifyStrict(sink, classesHint, i));
            } else {
                loopResults.addAll(analyzeFull(sink, i));
            }

            // Задержка между итерациями (кроме последней)
            if (i < docs.size() - 1) {
                delayBetweenIterations();
            }
        }
        if (docs.isEmpty()) {
            loopResults.addAll(analyzeSimple(sink));
        }
        node.getOutput().addAll(loopResults);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.addInputs(node.getId(), input);
        }
        return String.join("\n\n", loopResults);
    }

    private List<String> analyzeFull(FluxSink<ServerSentEvent<Map<String, Object>>> sink, int i) {
        log.info("[{}] analyzeFull, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        // Режим анализа: полный промпт, свободный ответ
        List<String> results = new ArrayList<>();
        var docId = node.getDocList().get(i);
        var doc = node.getGraph().getDocMap().get(docId);
        // Результаты предыдущих узлов (node.getInput()) включаются в контекст каждой итерации,
        // чтобы цикл мог обрабатывать документы с опорой на выход предшественника (например, эталон).
        var contextInput = String.join("\n\n", node.getInput());
        var analyzePrompt = buildPrompt(contextInput, doc.getText(), List.of(), false);
        assert gigaChatClient != null;
        String result = gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content", analyzePrompt)
        ), node.getModel(), node.getTemperature());
        if (prompt.isEmpty()) {
            // в шаг — шаблон промпта один раз, а не промпт с полным текстом каждого документа
            rememberPromptTemplate(buildPrompt(contextInput, DOC_PLACEHOLDER, List.of(), false));
        }
        results.add("Документ " + docId + ":\n" + result);
        emitLoopProgressEvent(sink,
                node,
                i + 1,
                node.getDocList().size(),
                docId + " - " + doc.getFilename());
        return results;
    }

    private List<String> analyzeSimple(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> results = new ArrayList<>();
        var inputList = node.getInput();
        if (!inputList.isEmpty()) {
            var analyzePrompt = buildPrompt("", inputList.get(0), List.of(), false);
            assert gigaChatClient != null;
            String result = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", analyzePrompt)
            ), node.getModel(), node.getTemperature());
            prompt = analyzePrompt;
            results.add(result);
            emitLoopProgressEvent(sink, node, 1, 1, "");
        }
        return results;
    }

    private List<String> analyzeWithClassifyStrict(FluxSink<ServerSentEvent<Map<String, Object>>> sink, String classesHint, int i) {
        log.info("[{}] analyzeWithClassifyStrict, node='{}' (id={}), classesHint={}",
                currentUser(), node.getLabel(), node.getId(), classesHint);
        // Строгая классификация: однословное название класса
        // Если пользователь предоставил промпт, использовать его как контекст/инструкцию
        List<String> results = new ArrayList<>();
        var docId = node.getDocList().get(i);
        var doc = node.getGraph().getDocMap().get(docId);
        String userPrompt = node.getPrompt();
        StringBuilder sb = new StringBuilder();
        sb.append(PROMPT_STRICT_CLASSIFY).append(classesHint).append(".\n");
        if (!userPrompt.isBlank()) {
            sb.append(PROMPT_CLASSIFICATION_HINT).append(userPrompt).append("\n");
        }
        sb.append(PROMPT_INSTRUCTION_SUFFIX);
        String head = sb.toString();
        var analyzePrompt = head + truncateForClassification(doc.getText());

        assert gigaChatClient != null;
        String clsRaw = gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content", analyzePrompt)
        ), node.getModel(), node.getTemperature());
        // в шаг — шаблон промпта один раз, без текста документа
        rememberPromptTemplate(head + DOC_PLACEHOLDER);
        var cls = extractDocClass(classesHint, clsRaw);
        results.add("<<<" + docId + "|CLASS:" + cls + ">>>\n" +
                doc.getText() + "\n<<<END_" + docId + ">>>");
        emitLoopProgressEvent(sink,
                node,
                i + 1,
                node.getDocList().size(),
                docId + " - " + doc.getFilename() + " -> классифицирован как \"" + cls + "\"");
        doc.setDocClass(cls);
        return results;
    }

    /**
     * Режим «по списку»: итерация по элементам входа, а не по документам.
     * <p>
     * Элементы: если вход — JSON-массив, его элементы; иначе вход режется
     * по разделителю из поля value узла (по умолчанию «---»). Каждый элемент
     * обрабатывается промптом узла отдельно, с контекстом результатов
     * предыдущих узлов. Пустой вход или пустой массив — 0 итераций без
     * обращения к LLM: результат «элементов нет» и предупреждение в журнал прогона.
     *
     * @param sink поток SSE-событий
     * @return объединённый результат по всем элементам
     */
    private String executeOverList(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        String inputAll = String.join("\n\n", node.getInput());
        List<String> items = splitItems(inputAll);
        if (items.isEmpty()) {
            return finishEmptyList(sink);
        }
        if (items.size() > maxItems) {
            throw new ScenarioException("Цикл по списку «" + node.getLabel() + "»: элементов " + items.size()
                    + " больше предела " + maxItems + " (app.scenario.loop-max-items) — сузьте список");
        }
        List<String> loopResults = new ArrayList<>();
        var contextInput = String.join("\n\n", node.getInput());
        for (int i = 0; i < items.size(); i++) {
            // остановка прогона проверяется перед каждой итерацией, а не только на границе узла
            node.getGraph().checkNotCancelled();
            var analyzePrompt = buildPrompt(contextInput, "Элемент " + (i + 1) + ":\n" + items.get(i),
                    List.of(), false);
            assert gigaChatClient != null;
            String result = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", analyzePrompt)
            ), node.getModel(), node.getTemperature());
            if (prompt.isEmpty()) {
                // в шаг — шаблон промпта один раз, а не промпт с контекстом на каждый элемент
                rememberPromptTemplate(buildPrompt(contextInput, "Элемент N:\n" + DOC_PLACEHOLDER, List.of(), false));
            }
            loopResults.add("Элемент " + (i + 1) + ":\n" + result);
            emitLoopProgressEvent(sink, node, i + 1, items.size(),
                    "элемент " + (i + 1) + " из " + items.size());
            if (i < items.size() - 1) {
                delayBetweenIterations();
            }
        }
        node.getOutput().addAll(loopResults);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.addInputs(node.getId(), input);
        }
        return String.join("\n\n", loopResults);
    }

    /**
     * Режим «по списку» без элементов: LLM не вызывается, детям уходит
     * результат «элементов нет», в журнал прогона — предупреждение.
     *
     * @param sink поток SSE-событий
     * @return результат узла
     */
    private String finishEmptyList(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.warn("[{}] LoopNode «{}» (id={}): режим «по списку» — вход пуст, итераций 0",
                currentUser(), node.getLabel(), node.getId());
        emitLoopProgressEvent(sink, node, 0, 0,
                "⚠ вход пуст — элементов нет, итераций 0, LLM не вызывался");
        prompt = "[цикл по списку: вход пуст — элементов нет, LLM не вызывался]";
        String result = "элементов нет";
        node.getOutput().add(result);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return result;
    }

    /**
     * Запоминает шаблон промпта итерации для шага прогона один раз: полный промпт
     * каждой итерации (с текстом документа или элемента) множил объём prompt_used
     * на число документов комплекта.
     *
     * @param template промпт итерации с местозаполнителем вместо текста документа
     */
    private void rememberPromptTemplate(String template) {
        if (prompt == null || prompt.isEmpty()) {
            prompt = template;
        }
    }

    /** Элемент списка как JSON-строка (объект/массив); при сбое сериализации — toString. */
    private static String toJsonItem(Object o) {
        try {
            return new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(o);
        } catch (Exception e) {
            return String.valueOf(o);
        }
    }

    /**
     * Разбивает вход на элементы: JSON-массив в конце входа либо разделитель.
     * Пустой вход и пустой JSON-массив дают пустой список (0 итераций).
     */
    private List<String> splitItems(String inputAll) {
        if (inputAll.isBlank()) {
            return new ArrayList<>();
        }
        Object json = null;
        try {
            String probe = ExpressionResolver.extractJsonPathFromText(inputAll, "");
            // extractJsonPathFromText с пустым путём вернёт весь корень строкой
            if (probe.startsWith("[")) {
                json = new ObjectMapper().readValue(probe, List.class);
            }
        } catch (Exception ignored) {
            // не JSON — разберём по разделителю
        }
        List<String> items = new ArrayList<>();
        if (json instanceof List<?> list) {
            // пустой массив «[]» — ноль элементов, а не один элемент-строка «[]» для LLM
            for (Object o : list) {
                // объекты и вложенные массивы — как JSON, а не Map.toString() «{ключ=значение}»
                items.add(o instanceof String s ? s : toJsonItem(o));
            }
            return items;
        }
        String delimiter = node.getValue() == null || node.getValue().isBlank() ? "---" : node.getValue();
        for (String part : inputAll.split(Pattern.quote(delimiter))) {
            if (!part.trim().isEmpty()) {
                items.add(part.trim());
            }
        }
        if (items.isEmpty()) {
            items.add(inputAll);
        }
        return items;
    }

    /**
     * Урезает текст документа для классификации: начало (титул, шапка) и конец (подписи).
     * Тип документа определяется по этим фрагментам; полный текст не нужен.
     *
     * @param text полный текст документа
     * @return урезанный текст либо исходный, если он короче лимитов
     */
    private String truncateForClassification(String text) {
        if (text == null || text.length() <= classifyHeadChars + classifyTailChars) {
            return text;
        }
        return text.substring(0, classifyHeadChars)
                + "\n\n[... середина документа пропущена для классификации ...]\n\n"
                + text.substring(text.length() - classifyTailChars);
    }

    /**
     * Класс документа из ответа модели: точное равенство ответа классу (без регистра,
     * краевых пробелов и знаков препинания); иначе самый длинный класс, входящий в ответ
     * по границам слов и не под отрицанием «не»; иначе «UNKNOWN». Прежний поиск первой
     * подстроки давал «договор» на ответ «не договор» и «акт» на «Контракт».
     *
     * @param classesHint классы через запятую
     * @param clsRaw      ответ модели
     * @return класс документа
     */
    static String extractDocClass(String classesHint, String clsRaw) {
        if (clsRaw == null || clsRaw.isBlank()) {
            return "UNKNOWN";
        }
        List<String> classes = hintClasses(classesHint);
        if (classes.isEmpty()) {
            // прежнее поведение при пустом списке классов: пустой класс
            return "";
        }
        String answer = normalizeAnswer(clsRaw);
        for (String cls : classes) {
            if (cls.toLowerCase(Locale.ROOT).equals(answer)) {
                return cls;
            }
        }
        String best = null;
        for (String cls : classes) {
            if ((best == null || cls.length() > best.length()) && WordMatch.containsWord(clsRaw, cls)) {
                best = cls;
            }
        }
        return best == null ? "UNKNOWN" : best;
    }

    private static List<String> hintClasses(String classesHint) {
        List<String> classes = new ArrayList<>();
        for (String hintClass : classesHint.split(",")) {
            if (!hintClass.isBlank()) {
                classes.add(hintClass.strip());
            }
        }
        return classes;
    }

    private static String normalizeAnswer(String raw) {
        return raw.strip().toLowerCase(Locale.ROOT).replaceAll("^[\\p{Punct}«»\\s]+|[\\p{Punct}«»\\s]+$", "");
    }
}
