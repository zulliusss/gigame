package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Разбор таблицы характеристик продукции из текста документа (извещение, документация, техническое задание).
 * <p>
 * Таблицы docx приходят в тексте строками «&lt; ячейка | ячейка | … &gt;», ячейки могут быть многострочными.
 * Таблица характеристик — та, у которой в шапке есть колонка наименования и колонка характеристик
 * («№ п/п | Наименование продукции | Характеристики», «Наименование ТМЦ | Описание, технические и
 * функциональные характеристики»). Каждая строка таблицы — позиция: наименование и перечень строк характеристик.
 * Требования вне таблицы (ГОСТ, сертификаты, упаковка) в сверку не попадают.
 */
final class SpecTableParser {

    private static final Pattern ROW = Pattern.compile("^[\\[\\s]*< (.*?) >[\\s\\]]*$", Pattern.MULTILINE | Pattern.DOTALL);
    private static final Pattern CELL_SEPARATOR = Pattern.compile(" \\| ");
    private static final Pattern GAP = Pattern.compile("[\\s\\[\\]]*");
    /** Строки характеристик короче (в нормализованном виде) — не характеристики, а обрывки. */
    private static final int MIN_LINE_CHARS = 4;
    /** Ячейка шапки длиннее — это строка с данными, а не заголовок. */
    private static final int MAX_HEADER_CHARS = 160;

    private SpecTableParser() {
    }

    /** Позиция таблицы: номер, наименование, строки характеристик и документ-источник. */
    record SpecPosition(String number, String name, List<String> lines, String source) {
    }

    /** Колонки шапки: наименование и характеристики. */
    private record Header(int nameCol, int specCol) {
    }

    /**
     * Позиции всех таблиц характеристик документа.
     *
     * @param text     текст документа
     * @param source   имя файла-источника
     * @param nameCol  шаблон заголовка колонки наименования
     * @param specCol  шаблон заголовка колонки характеристик
     * @return позиции по порядку
     */
    static List<SpecPosition> parse(String text, String source, Pattern nameCol, Pattern specCol) {
        List<SpecPosition> positions = new ArrayList<>();
        Matcher m = ROW.matcher(text == null ? "" : text);
        Header header = null;
        int previousEnd = -1;
        while (m.find()) {
            boolean contiguous = previousEnd >= 0 && GAP.matcher(text.substring(previousEnd, m.start())).matches();
            List<String> cells = List.of(CELL_SEPARATOR.split(m.group(1), -1));
            Header found = header(cells, nameCol, specCol);
            if (found != null) {
                header = found;
            } else if (header != null && contiguous) {
                addPosition(positions, cells, header, source);
            } else {
                header = null;
            }
            previousEnd = m.end();
        }
        return positions;
    }

    private static Header header(List<String> cells, Pattern nameCol, Pattern specCol) {
        int name = -1;
        int spec = -1;
        for (int i = 0; i < cells.size(); i++) {
            String cell = cells.get(i);
            if (cell.length() > MAX_HEADER_CHARS) {
                return null;
            }
            if (spec < 0 && SafeRegex.find(specCol, cell)) {
                spec = i;
            } else if (name < 0 && SafeRegex.find(nameCol, cell)) {
                name = i;
            }
        }
        return name >= 0 && spec >= 0 ? new Header(name, spec) : null;
    }

    private static void addPosition(List<SpecPosition> positions, List<String> cells, Header header, String source) {
        if (cells.size() <= Math.max(header.nameCol(), header.specCol())) {
            return;
        }
        String name = cells.get(header.nameCol()).replaceAll("\\s+", " ").strip();
        List<String> lines = new ArrayList<>();
        for (String line : cells.get(header.specCol()).split("\\R")) {
            if (NormalizedText.normalize(line).length() >= MIN_LINE_CHARS) {
                lines.add(line.strip());
            }
        }
        if (NormalizedText.normalize(name).length() >= MIN_LINE_CHARS && !lines.isEmpty()) {
            String number = header.nameCol() > 0 ? cells.get(0).strip() : String.valueOf(positions.size() + 1);
            positions.add(new SpecPosition(number, name, lines, source));
        }
    }
}
