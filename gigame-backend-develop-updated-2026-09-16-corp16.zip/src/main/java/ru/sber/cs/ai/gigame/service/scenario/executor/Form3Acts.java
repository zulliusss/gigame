package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Акты сдачи-приёмки и заявки (заказы) комплекта — документы без структуры
 * УПД: акт Сбера «АКТ сдачи-приёмки работ по Спецификации № … от …»
 * (docx/pdf), распознанные сканы актов и заявок Альфа-Банка
 * («Заявка №104 Акт №б-н от 27.04.24.pdf», «Заявка №104 от 15.04.2024.pdf»).
 * Вид документа определяется по имени файла и началу текста, реквизиты —
 * по тексту, а при нечитаемом скане — по имени файла.
 */
final class Form3Acts {

    static final String KIND_ACT = "акт";
    static final String KIND_ORDER = "заявка";
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern OCR_PREFIX = Pattern.compile("^\\[РАСПОЗНАНО[^\\n]*\\n?");
    /** Начало распознанного текста: GigaChat выписывает «Тип документа: …» первой строкой. */
    static final String TYPE_LINE = "^\\W*(?:Тип документа:\\s*)?";
    private static final Pattern ACT_HEAD = Pattern.compile(
            TYPE_LINE + "АКТ(?![А-Яа-яЁёA-Za-z])[\\s\\S]{0,120}?(?:сдачи-при[её]мки|выполненных работ)", FLAGS);
    /**
     * Дата акта в имени файла: «Акт №б-н от dd.mm.yy(yy)», но не дата спецификации, договора или
     * заявки после «Акт … к спец. … от …» / «Акт №1 по Заявке №50 от …» (там дата заявки).
     */
    private static final Pattern ACT_NAME_DATE = Pattern.compile(
            "Акт(?:(?!спец|догов|ДС|заявк)[^\\n])*?от\\s*(\\d{2}\\.\\d{2}\\.)(\\d{4}|\\d{2})(?!\\d)", FLAGS);
    private static final Pattern DATE_LABEL = Pattern.compile("Дата\\s+(?:акта|подписания|документа)[^\\n\\d«\"]{0,30}", FLAGS);
    private static final Pattern NUM_DATE = Pattern.compile("(?<!\\d)(\\d{2}\\.\\d{2}\\.\\d{4})(?!\\d)");
    private static final Pattern ACT_NAME = Pattern.compile("(?<![А-Яа-яЁёA-Za-z])акт(?![А-Яа-яЁёA-Za-z])", FLAGS);
    private static final Pattern ORDER_NAME = Pattern.compile("^\\W*Заявк[аи]\\s*№?\\s*(\\d{1,6})\\s+от\\s+\\d{2}\\.\\d{2}\\.\\d{2,4}", FLAGS);
    private static final Pattern ORDER_HEAD = Pattern.compile(TYPE_LINE + "Заявк[аи]\\s*№?\\s*(\\d{1,6})(?!\\d)", FLAGS);
    static final Pattern ORDER_REF = Pattern.compile("Заявк[а-яё]*\\s*№?\\s*(\\d{1,6})(?!\\d)", FLAGS);
    private static final Pattern NAME_DATE = Pattern.compile("от\\s*(\\d{2}\\.\\d{2}\\.)(\\d{4}|\\d{2})(?!\\d)");
    static final Pattern WORD_DATE = Pattern.compile(
            "[«\"]?\\s*-?(\\d{1,2})\\s*-?\\s*[»\"]?\\s*(января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)"
                    + "\\s*(\\d{4})", FLAGS);
    private static final Pattern CITY = Pattern.compile("г\\.\\s*[А-ЯЁ][а-яё\\-]+");
    private static final Pattern PAYABLE = Pattern.compile("к\\s+оплате[^\\d\\n]{0,60}?(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?!\\d)", FLAGS);
    private static final Pattern TOTAL = Pattern.compile("(?:составляет|Итого|Всего)[^\\d\\n]{0,60}?(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?!\\d)", FLAGS);
    private static final Pattern CUSTOMER = Pattern.compile(
            "(?:^|[,\\n])\\s*([^,\\n]{2,80}?)\\s*,\\s*именуем\\S*\\s+в\\s+дальнейшем\\s+[«\"]Заказчик", FLAGS | Pattern.MULTILINE);
    private static final Pattern EXECUTOR = Pattern.compile(
            "(?:^|[,\\n])\\s*([^,\\n]{2,80}?)\\s*,\\s*именуем\\S*\\s+в\\s+дальнейшем\\s+[«\"](?:Исполнитель|Подрядчик)",
            FLAGS | Pattern.MULTILINE);
    private static final Pattern SIGNED = Pattern.compile("Подпись соответствует|Электронная подпись|Документ подписан", FLAGS);
    private static final int CITY_WINDOW = 80;
    /** Номер договора в реквизитах акта/заявки: «Договор: №4412866», «к Договору № АБ-С-ИТ-2020». */
    private static final Pattern CONTRACT_LOOSE = Pattern.compile("Договор[а-яё]*\\s*:?\\s*№?\\s*(\\d{5,12})(?!\\d)", FLAGS);

    private Form3Acts() {
    }

    /** Текст без служебной строки OCR («[РАСПОЗНАНО …] Документ «…»:»). */
    static String body(String text) {
        return OCR_PREFIX.matcher(text).replaceFirst("");
    }

    /**
     * Базовое имя файла (после последнего «/»): документы из архивов приходят с
     * путём «архив.zip/папка/файл.pdf», и слово «акт» в имени папки или архива
     * делало актом любой файл внутри, а якорь «^Заявка №…» не срабатывал вовсе.
     *
     * @param name имя документа, возможно с путём
     * @return имя файла без пути
     */
    static String baseName(String name) {
        return name == null ? "" : name.substring(name.lastIndexOf('/') + 1);
    }

    /**
     * Акт сдачи-приёмки: по началу текста («АКТ сдачи-приёмки …») либо по слову «Акт» в базовом имени файла.
     * Маркерный документ (ручная проверка) актом не считается — иначе в реестр шёл акт с пустой суммой.
     */
    static boolean isAct(String name, String text) {
        if (ScenarioRunDoc.isUnreadable(text)) {
            return false;
        }
        return ACT_HEAD.matcher(body(text)).find() || ACT_NAME.matcher(baseName(name)).find();
    }

    /** Заявка (заказ) к рамочному договору: «Заявка №N от дата» в базовом имени файла или в начале текста. */
    static boolean isOrder(String name, String text) {
        if (ScenarioRunDoc.isUnreadable(text)) {
            return false;
        }
        return ORDER_NAME.matcher(baseName(name)).find() || ORDER_HEAD.matcher(body(text)).find();
    }

    /**
     * Реквизиты акта: спецификация/заявка, договор, дата (из имени файла,
     * иначе по дате после «г. Москва» в шапке), сумма к оплате, стороны.
     *
     * @param name имя файла
     * @param text текст (распознанный или извлечённый)
     * @return карта полей акта
     */
    static Map<String, Object> parseAct(String name, String text) {
        String body = body(text);
        Map<String, Object> act = new LinkedHashMap<>();
        act.put("файл", name);
        act.put("вид", KIND_ACT);
        act.put("скан", OCR_PREFIX.matcher(text).find());
        act.put("спецификация", Form3Ops.firstGroup(Form3Ops.SPEC_REF, body));
        String order = Form3Ops.firstGroup(ORDER_REF, baseName(name));
        act.put("заявка", order.isEmpty() ? Form3Ops.firstGroup(ORDER_REF, body) : order);
        act.put("договор", contractNumber(body));
        String date = actNameDate(baseName(name));
        if (date.isEmpty()) {
            date = labelDate(body);
        }
        act.put("дата", date.isEmpty() ? headingDate(body) : date);
        act.put("сумма", payable(body));
        act.put("суммы", Form3Ops.amounts(body));
        act.put("покупатель", party(CUSTOMER, body));
        act.put("продавец", party(EXECUTOR, body));
        act.put("подпись_заказчика", true);
        act.put("подпись_примечание", SIGNED.matcher(text).find() ? ""
                : "подпись заказчика на акте штампом ЭДО не подтверждена");
        act.put("текст", Form3Ops.limit(body));
        return act;
    }

    /**
     * Реквизиты заявки (заказа): номер, договор, дата, суммы; в реестре
     * заявки лежат вместе со спецификациями (поле {@code "вид"} = «заявка»).
     */
    static Map<String, Object> parseOrder(String name, String text) {
        String body = body(text);
        Map<String, Object> order = new LinkedHashMap<>();
        order.put("файл", name);
        order.put("вид", KIND_ORDER);
        String number = Form3Ops.firstGroup(ORDER_REF, baseName(name));
        order.put("номер", number.isEmpty() ? Form3Ops.firstGroup(ORDER_REF, body) : number);
        order.put("договор", contractNumber(body));
        order.put("дата", nameDate(baseName(name), false));
        order.put("суммы", Form3Ops.amounts(body));
        order.put("текст", Form3Ops.limit(body));
        return order;
    }

    /** Номер договора: числовой, иначе буквенно-цифровой после «№». */
    static String contractNumber(String text) {
        String number = Form3Ops.firstGroup(CONTRACT_LOOSE, text);
        return number.isEmpty() ? Form3Ops.firstGroup(Form3Ops.CONTRACT_ALNUM, text) : number;
    }

    /** Сторона акта без союза перед названием («…, и АО «АЛЬФА-БАНК», именуемое …»). */
    private static String party(Pattern pattern, String text) {
        return Form3Ops.firstGroup(pattern, text).replaceFirst("^(?:и|а также)\\s+", "").strip();
    }

    /** Все даты словами («28 июня 2024») в виде dd.MM.yyyy. */
    static List<String> wordDates(String text) {
        List<String> out = new java.util.ArrayList<>();
        Matcher m = WORD_DATE.matcher(text);
        while (m.find()) {
            out.add(String.format("%02d.%s.%s", Integer.parseInt(m.group(1)),
                    Form3Ops.MONTHS.get(m.group(2).toLowerCase(Locale.ROOT)), m.group(3)));
        }
        return out;
    }

    /** Дата акта из имени файла («Заявка №104 Акт №б-н от 27.04.24»), двузначный год → 20yy. */
    static String actNameDate(String name) {
        Matcher m = ACT_NAME_DATE.matcher(name);
        if (!m.find()) {
            return "";
        }
        return m.group(1) + (m.group(2).length() == 2 ? "20" + m.group(2) : m.group(2));
    }

    /** Дата после подписи «Дата акта: …» в распознанном тексте (словами или числом). */
    static String labelDate(String text) {
        Matcher label = DATE_LABEL.matcher(text);
        if (!label.find()) {
            return "";
        }
        Matcher words = WORD_DATE.matcher(text);
        if (words.find(label.end()) && words.start() - label.end() <= CITY_WINDOW) {
            return String.format("%02d.%s.%s", Integer.parseInt(words.group(1)),
                    Form3Ops.MONTHS.get(words.group(2).toLowerCase(Locale.ROOT)), words.group(3));
        }
        Matcher num = NUM_DATE.matcher(text);
        return num.find(label.end()) && num.start() - label.end() <= CITY_WINDOW ? num.group(1) : "";
    }

    /** Дата «от dd.mm.yyyy» из имени файла (двузначный год → 20yy); для акта берётся последняя, для заявки первая. */
    static String nameDate(String name, boolean last) {
        String found = "";
        Matcher m = NAME_DATE.matcher(name);
        while (m.find()) {
            String year = m.group(2).length() == 2 ? "20" + m.group(2) : m.group(2);
            found = m.group(1) + year;
            if (!last) {
                break;
            }
        }
        return found;
    }

    /** Дата подписания из шапки акта: «г. Москва … «08» апреля 2024 г.». */
    static String headingDate(String text) {
        Matcher city = CITY.matcher(text);
        int from = city.find() ? city.end() : -1;
        if (from < 0) {
            return "";
        }
        Matcher m = WORD_DATE.matcher(text);
        if (!m.find(from) || m.start() - from > CITY_WINDOW) {
            return "";
        }
        return String.format("%02d.%s.%s", Integer.parseInt(m.group(1)),
                Form3Ops.MONTHS.get(m.group(2).toLowerCase(Locale.ROOT)), m.group(3));
    }

    /** Сумма акта: «к оплате …», иначе первая «составляет/Итого/Всего …». */
    static String payable(String text) {
        for (Pattern p : List.of(PAYABLE, TOTAL)) {
            Matcher m = p.matcher(text);
            if (m.find()) {
                return m.group(1).replace(" ", "") + "." + m.group(2);
            }
        }
        return "";
    }
}
