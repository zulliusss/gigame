package ru.sber.cs.ai.gigame.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

import java.util.List;

/**
 * Деление контекста промпта при ответе GigaChat «context too long» и сборка
 * ответов частей: точка разреза выбирается по границам документов, страниц и
 * абзацев (а не посреди строки), ответы частей помечаются заголовками
 * {@link #partHeader(int, int)}, JSON-массивы частей объединяются в один.
 */
final class PromptSplitter {

    /** Границы разреза по убыванию приоритета: документ группы, страница OCR, абзац, строка. */
    private static final List<String> BOUNDARIES = List.of("\n\n<<<Документ:", "\n--- страница", "\n\n", "\n");
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private PromptSplitter() {
    }

    /**
     * Заголовок части ответа при делении запроса.
     *
     * @param part  номер части (с 1)
     * @param total число частей
     * @return строка-разделитель
     */
    static String partHeader(int part, int total) {
        return "=== Часть " + part + "/" + total + " (запрос разделён из-за лимита контекста) ===";
    }

    /**
     * Позиция разреза контекста пополам: ближайшая к середине граница из
     * {@link #BOUNDARIES} в средней половине текста, иначе середина.
     *
     * @param context делимый контекст
     * @return индекс начала второй части
     */
    static int cutPoint(String context) {
        int mid = context.length() / 2;
        int low = context.length() / 4;
        int high = context.length() - low;
        for (String boundary : BOUNDARIES) {
            int before = context.lastIndexOf(boundary, mid);
            int after = context.indexOf(boundary, mid);
            int best = -1;
            if (before >= low && (after < 0 || mid - before <= after - mid)) {
                best = before;
            } else if (after >= 0 && after <= high) {
                best = after;
            }
            if (best > 0) {
                // граница остаётся в начале второй части (разделитель документа/страницы не теряется)
                return best;
            }
        }
        return mid;
    }

    /**
     * Первый JSON-массив ответа (по сбалансированным скобкам) либо {@code null}.
     *
     * @param text текст ответа модели
     * @return массив или {@code null}, если массива нет или он не разбирается
     */
    static ArrayNode jsonArray(String text) {
        if (text == null) {
            return null;
        }
        int start = text.indexOf('[');
        while (start >= 0) {
            int end = balancedEnd(text, start);
            if (end > start) {
                try {
                    JsonNode node = MAPPER.readTree(text.substring(start, end + 1));
                    if (node.isArray()) {
                        return (ArrayNode) node;
                    }
                } catch (Exception e) {
                    // не JSON — пробуем следующую открывающую скобку
                }
            }
            start = text.indexOf('[', start + 1);
        }
        return null;
    }

    /** Индекс закрывающей скобки для массива, открытого в {@code start}, с учётом строк; -1, если не сбалансирован. */
    private static int balancedEnd(String text, int start) {
        int depth = 0;
        boolean inString = false;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (c == '\\') {
                    i++;
                } else if (c == '"') {
                    inString = false;
                }
            } else if (c == '"') {
                inString = true;
            } else if (c == '[' || c == '{') {
                depth++;
            } else if (c == ']' || c == '}') {
                depth--;
                if (depth == 0) {
                    return i;
                }
            }
        }
        return -1;
    }

    /**
     * Объединяет JSON-массивы ответов частей в один; если хотя бы одна часть
     * массива не содержит — {@code null} (части склеиваются текстом с заголовками).
     *
     * @param parts тексты ответов частей
     * @return JSON объединённого массива либо {@code null}
     */
    static String mergeJsonArrays(List<String> parts) {
        ArrayNode merged = MAPPER.createArrayNode();
        for (String part : parts) {
            ArrayNode array = jsonArray(part);
            if (array == null) {
                return null;
            }
            merged.addAll(array);
        }
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(merged);
        } catch (Exception e) {
            return null;
        }
    }
}
