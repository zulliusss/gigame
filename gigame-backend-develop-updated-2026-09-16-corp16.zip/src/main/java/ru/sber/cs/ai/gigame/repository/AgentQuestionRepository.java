package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import ru.sber.cs.ai.gigame.model.AgentQuestion;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

public interface AgentQuestionRepository extends JpaRepository<AgentQuestion, UUID> {

    List<AgentQuestion> findByRunIdOrderByCreatedAtAsc(UUID runId);

    List<AgentQuestion> findByScenarioIdAndAnsweredAtIsNullOrderByCreatedAtDesc(UUID scenarioId);

    /**
     * Удаляет вопросы агента по удалённым запускам (внешнего ключа на scenario_runs нет —
     * иначе после чистки по сроку хранения оставались бы сироты).
     *
     * @param runIds идентификаторы удаляемых запусков
     */
    @Modifying
    @Query("delete from AgentQuestion q where q.runId in :runIds")
    void deleteByRunIds(@Param("runIds") Collection<UUID> runIds);
}
