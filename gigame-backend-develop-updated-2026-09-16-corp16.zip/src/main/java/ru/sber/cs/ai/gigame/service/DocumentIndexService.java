package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.TextSplitter;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Индексация документов: разбиение на фрагменты, эмбеддинги, запись в pgvector.
 * <p>
 * Эмбеддинги считаются ВНЕ транзакции: вызовы GigaChat ждут в очереди лимитера и
 * длятся минутами, а соединение БД из пула Hikari на это время удерживаться не должно
 * (иначе пул исчерпывается и падают прогоны). Транзакции короткие: смена статуса на
 * processing, запись фрагментов + ready, запись ошибки.
 */
@Service
@Slf4j
public class DocumentIndexService {
    private static final int EMBEDDING_BATCH = 50;
    private static final String STATUS_PROCESSING = "processing";
    private static final String STATUS_READY = "ready";
    private static final String STATUS_ERROR = "error";

    private final TransactionTemplate transactionTemplate;
    private final KBDocumentRepository kbDocumentRepository;
    private final DocumentRepository documentRepository;
    private final EmbeddingService embeddingService;
    private final TextSplitter textSplitter;
    private final GigaChatClient gigaChatClient;

    public DocumentIndexService(PlatformTransactionManager transactionManager, KBDocumentRepository kbDocumentRepository, DocumentRepository documentRepository, EmbeddingService embeddingService, TextSplitter textSplitter, GigaChatClient gigaChatClient) {
        this.kbDocumentRepository = kbDocumentRepository;
        this.documentRepository = documentRepository;
        this.embeddingService = embeddingService;
        this.textSplitter = textSplitter;
        this.gigaChatClient = gigaChatClient;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    /**
     * Разбивает текст на фрагменты, вычисляет векторные эмбеддинги и сохраняет их.
     * <p>
     * Фрагменты сохраняются в векторное хранилище с использованием pgvector.
     * эмбеддинги вычисляются пакетами по 50 фрагментов (ограничение GigaChat API),
     * вне транзакции; запись фрагментов — своей короткой транзакцией.
     *
     * @param documentId UUID документа
     * @param text       полный извлечённый текст
     */
    public void indexDocument(UUID documentId, String text) {
        log.info("[{}] indexDocument, documentId={}", CurrentUserHolder.getCurrentUser(), documentId);
        List<String> chunks = textSplitter.split(text);
        if (chunks.isEmpty()) {
            return;
        }
        List<float[]> allEmbeddings = computeEmbeddings(chunks);
        embeddingService.storeDocumentChunks(documentId, chunks, allEmbeddings);
        log.info("[{}] Проиндексирован документ {}: {} фрагментов", CurrentUserHolder.getCurrentUser(), documentId, chunks.size());
    }

    /**
     * Переиндексирует документ в базе знаний: удаляет старые фрагменты,
     * заново вычисляет эмбеддинги и обновляет статус.
     * Выбрасывает исключение, если запись KBDocument не найдена.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @return обновлённый KBDocumentResponse
     */
    public KBDocumentResponse reindexDocument(UUID kbId, UUID documentId) {
        log.info("[{}] reindexDocument, kbId={}, documentId={}", CurrentUserHolder.getCurrentUser(), kbId, documentId);
        // транзакция 1: старые фрагменты удалены, статус processing
        KBDocument kbDoc = transactionTemplate.execute(status -> {
            KBDocument found = kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(kbId, documentId)
                    .orElseThrow(() -> new NotFoundException(
                            "Документ базы знаний не найден: kbId=" + kbId + " docId=" + documentId));
            embeddingService.deleteKBDocumentChunks(kbId, documentId);
            found.setStatus(STATUS_PROCESSING);
            found.setErrorMessage(null);
            return kbDocumentRepository.save(found);
        });
        KBDocument saved;
        try {
            // эмбеддинги — вне транзакции
            List<String> chunks = loadChunks(documentId);
            List<float[]> allEmbeddings = computeEmbeddings(chunks);
            // транзакция 2: фрагменты записаны, статус ready
            saved = transactionTemplate.execute(status -> markReady(kbId, documentId, kbDoc, chunks, allEmbeddings));
            log.info("[{}] Переиндексирован документ {} в KB {}: {} фрагментов", CurrentUserHolder.getCurrentUser(), documentId, kbId, chunks.size());
        } catch (Exception e) {
            log.error("[{}] Переиндексация не удалась для документа {} в KB {}", CurrentUserHolder.getCurrentUser(), documentId, kbId, e);
            // транзакция 3: статус error
            saved = transactionTemplate.execute(status -> markError(kbDoc, e.getMessage()));
        }
        return KBMapper.toKBDocumentResponse(saved);
    }

    /**
     * Асинхронно разбивает, вычисляет эмбеддинги и сохраняет текст документа
     * как векторные данные базы знаний.
     * <p>
     * Выполняется на отдельном потоке (@Async). Эмбеддинги — вне транзакции;
     * запись фрагментов со статусом ready и запись ошибки — короткими транзакциями.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @param kbDocId    UUID записи KBDocument
     */
    @Async
    public void indexDocumentAsync(UUID kbId, UUID documentId, UUID kbDocId) {
        log.info("[{}] indexDocumentAsync, kbId={}, documentId={}, kbDocId={}",
                CurrentUserHolder.getCurrentUser(), kbId, documentId, kbDocId);
        try {
            List<String> chunks = loadChunks(documentId);
            List<float[]> allEmbeddings = computeEmbeddings(chunks);
            transactionTemplate.execute(status -> {
                KBDocument kbDoc = kbDocumentRepository.findById(kbDocId)
                        .orElseThrow(() -> new IllegalStateException("KBDocument не найден: " + kbDocId));
                return markReady(kbId, documentId, kbDoc, chunks, allEmbeddings);
            });
            log.info("Проиндексирован документ {} в KB {}: {} фрагментов", documentId, kbId, chunks.size());
        } catch (Exception e) {
            log.error("Не удалось проиндексировать документ {} в KB {}", documentId, kbId, e);
            transactionTemplate.execute(status -> {
                kbDocumentRepository.findById(kbDocId).ifPresent(kbDoc -> markError(kbDoc, e.getMessage()));
                return null;
            });
        }
    }

    /**
     * Фрагменты извлечённого текста документа (чтение без транзакции).
     *
     * @param documentId UUID документа
     * @return непустой список фрагментов
     * @throws NotFoundException     документ не найден
     * @throws IllegalStateException текст пуст или не дал фрагментов
     */
    private List<String> loadChunks(UUID documentId) {
        Document doc = documentRepository.findById(documentId)
                .orElseThrow(() -> new NotFoundException("Документ не найден: " + documentId));
        if (doc.getExtractedText() == null || doc.getExtractedText().isBlank()) {
            throw new IllegalStateException("Документ не содержит извлечённого текста");
        }
        List<String> chunks = textSplitter.split(doc.getExtractedText());
        if (chunks.isEmpty()) {
            throw new IllegalStateException("Документ не дал фрагментов");
        }
        return chunks;
    }

    /**
     * Эмбеддинги фрагментов пакетами по 50 (ограничение GigaChat API) — вне транзакции.
     *
     * @param chunks фрагменты
     * @return эмбеддинги в порядке фрагментов
     */
    private List<float[]> computeEmbeddings(List<String> chunks) {
        List<float[]> allEmbeddings = new ArrayList<>();
        for (int i = 0; i < chunks.size(); i += EMBEDDING_BATCH) {
            List<String> batch = chunks.subList(i, Math.min(i + EMBEDDING_BATCH, chunks.size()));
            allEmbeddings.addAll(gigaChatClient.getEmbeddings(batch));
        }
        return allEmbeddings;
    }

    /** Внутри транзакции: запись фрагментов базы знаний и статус ready. */
    private KBDocument markReady(UUID kbId, UUID documentId, KBDocument kbDoc,
                                 List<String> chunks, List<float[]> embeddings) {
        embeddingService.storeKBChunks(kbId, documentId, chunks, embeddings);
        kbDoc.setChunkCount(chunks.size());
        kbDoc.setStatus(STATUS_READY);
        return kbDocumentRepository.save(kbDoc);
    }

    /** Внутри транзакции: статус error с текстом причины. */
    private KBDocument markError(KBDocument kbDoc, String message) {
        kbDoc.setStatus(STATUS_ERROR);
        kbDoc.setErrorMessage(message);
        return kbDocumentRepository.save(kbDoc);
    }
}
