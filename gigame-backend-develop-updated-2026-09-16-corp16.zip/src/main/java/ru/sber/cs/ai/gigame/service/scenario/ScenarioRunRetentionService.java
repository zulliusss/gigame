package ru.sber.cs.ai.gigame.service.scenario;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Срок хранения прогонов сценариев. Раз в сутки удаляет прогоны старше
 * {@code app.scenario.run-retention-days} дней (0 — выключено) вместе с шагами
 * (ON DELETE CASCADE) и вопросами агента (внешнего ключа нет — чистятся явно).
 * Выполняющиеся прогоны и последний успешно завершённый прогон каждой пары
 * «сценарий + пользователь» не удаляются: на последнем держится нарастающий итог
 * output-узла («накапливать»).
 */
@Slf4j
@Service
public class ScenarioRunRetentionService {

    /** Размер пачки удаляемых прогонов в одной транзакции. */
    static final int BATCH_SIZE = 200;

    private final ScenarioRunRepository runRepository;
    private final AgentQuestionRepository questionRepository;
    private final TransactionTemplate transactionTemplate;

    /** Срок хранения прогонов в днях; 0 и меньше — чистка выключена. */
    @Value("${app.scenario.run-retention-days:0}")
    private int retentionDays;

    public ScenarioRunRetentionService(PlatformTransactionManager transactionManager,
                                       ScenarioRunRepository runRepository,
                                       AgentQuestionRepository questionRepository) {
        this.runRepository = runRepository;
        this.questionRepository = questionRepository;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    /**
     * Плановая чистка: через 10 минут после старта и далее раз в сутки.
     */
    @Scheduled(initialDelayString = "${app.scenario.run-retention-initial-delay-ms:600000}",
            fixedDelayString = "${app.scenario.run-retention-interval-ms:86400000}")
    public void purgeExpiredRuns() {
        try {
            purgeExpiredRuns(OffsetDateTime.now());
        } catch (Exception e) {
            log.warn("Чистка прогонов по сроку хранения не выполнена: {}", e.getMessage());
        }
    }

    /**
     * Удаляет прогоны старше срока хранения относительно указанного момента.
     *
     * @param now текущий момент
     * @return число удалённых прогонов
     */
    int purgeExpiredRuns(OffsetDateTime now) {
        if (retentionDays <= 0) {
            return 0;
        }
        OffsetDateTime cutoff = now.minusDays(retentionDays);
        List<UUID> expired = runRepository.findExpiredRunIds(cutoff);
        if (expired.isEmpty()) {
            log.info("Чистка прогонов: устаревших прогонов (старше {} дн.) нет", retentionDays);
            return 0;
        }
        for (int from = 0; from < expired.size(); from += BATCH_SIZE) {
            List<UUID> batch = expired.subList(from, Math.min(from + BATCH_SIZE, expired.size()));
            transactionTemplate.execute(status -> {
                questionRepository.deleteByRunIds(batch);
                runRepository.deleteAllByIdInBatch(batch);
                return null;
            });
        }
        log.info("Чистка прогонов: удалено {} прогонов старше {} дн. (до {})", expired.size(), retentionDays, cutoff);
        return expired.size();
    }

    void setRetentionDays(int retentionDays) {
        this.retentionDays = retentionDays;
    }
}
