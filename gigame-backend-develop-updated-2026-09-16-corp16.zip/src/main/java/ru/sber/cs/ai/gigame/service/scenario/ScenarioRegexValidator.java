package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorTransformNode;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Проверка regex-параметров операций узлов «Трансформация» до создания прогона: каждый шаблон
 * компилируется и прогоняется на синтетической строке в {@value #PROBE_CHARS} символов с
 * дедлайном {@value #PROBE_MILLIS} мс. Катастрофический или некорректный шаблон — отказ запуска
 * с понятным текстом, а не поток пула прогонов, занятый навсегда.
 */
public final class ScenarioRegexValidator {

    /** Длина синтетической строки пробы. */
    static final int PROBE_CHARS = 5000;

    /** Дедлайн пробы одного шаблона, мс. */
    static final long PROBE_MILLIS = 200;

    /** Начало текста ошибки; дальше — проблемы через «; ». */
    static final String PREFIX = "Сценарий содержит небезопасные регулярные выражения: ";

    /** Окончание текста ошибки. */
    static final String SUFFIX = " — упростите шаблоны";
    private static final int SHORT_PATTERN = 80;

    private static final int FLAGS = Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    /** Regex-параметры операций (вложенные — через точку). */
    private static final Map<String, List<String>> REGEX_FIELDS = Map.ofEntries(
            Map.entry("извлечь_regex", List.of("шаблон")),
            Map.entry("заменить", List.of("найти")),
            Map.entry("оставить_строки", List.of("шаблон")),
            Map.entry("удалить_строки", List.of("шаблон")),
            Map.entry("слить_json_массивы", List.of("дедуп_регекс", "исключить_типы.если_не_содержит")),
            Map.entry("проверить_цитаты", List.of("документы")),
            Map.entry("удалить_объекты", List.of("шаблон", "и_шаблон")),
            Map.entry("установить_поле", List.of("шаблон", "кроме_значений")),
            Map.entry("секция_из_заголовков", List.of("шаблон_заголовка")),
            Map.entry("последовательность", List.of("шаблон")),
            Map.entry("прикрепить_по_номеру", List.of("шаблон")),
            Map.entry("дополнить_строки", List.of("секция_шаблон")),
            Map.entry("проверить_секции", List.of("шаблон_секции")),
            Map.entry("рубли_из_процента", List.of("секция_шаблон", "нмцд_шаблон")),
            Map.entry("сверить_характеристики",
                    List.of("классы_требований", "класс_договора", "колонка_наименования", "колонка_характеристик")),
            Map.entry("сверить_подписантов", List.of("класс_договора")),
            Map.entry("строки_формы3", List.of("заказчики_в_рейтинге")),
            Map.entry("сверить_суммы", List.of("метка")),
            Map.entry("проверить_проценты", List.of("база_метка")),
            Map.entry("извлечь_из_документов", List.of("имя", "шаблон")));

    /** Синтетическая строка: буквы, цифры, пробелы, знаки, переводы строк и «!» в конце. */
    private static final String PROBE = buildProbe();

    private ScenarioRegexValidator() {
    }

    /**
     * Проблемы regex-параметров узлов «Трансформация» графа.
     *
     * @param graphData граф (null и узлы без данных пропускаются)
     * @param where     уточнение места (например, « под-сценария «X»») либо пустая строка
     * @return описания проблем в порядке узлов
     */
    public static List<String> problemsOf(GraphDataDto graphData, String where) {
        List<String> problems = new ArrayList<>();
        if (graphData == null || graphData.nodes() == null) {
            return problems;
        }
        for (NodeDto node : graphData.nodes()) {
            if (node == null || node.data() == null || !ScenarioNodeType.TRANSFORM_NODE.toString().equals(node.type())) {
                continue;
            }
            for (JsonNode op : ScenarioExecutorTransformNode.operationsOf(node.data().rules())) {
                problems.addAll(operationProblems(op, label(node) + where));
            }
        }
        return problems;
    }

    /**
     * Бросает исключение, если проблемы есть.
     *
     * @param problems проблемы
     * @throws ScenarioException если список не пуст
     */
    public static void throwIfAny(List<String> problems) {
        if (!problems.isEmpty()) {
            throw new ScenarioException(PREFIX + String.join("; ", problems) + SUFFIX);
        }
    }

    /**
     * Проверяет один шаблон: длина, компиляция, проба на синтетической строке.
     *
     * @param regex шаблон
     * @return описание проблемы либо null, если шаблон в порядке
     */
    static String check(String regex) {
        if (regex.length() > SafeRegex.MAX_PATTERN_LENGTH) {
            return "длиннее " + SafeRegex.MAX_PATTERN_LENGTH + " символов (" + regex.length() + ")";
        }
        Pattern pattern;
        try {
            pattern = Pattern.compile(regex, FLAGS);
        } catch (PatternSyntaxException e) {
            return "некорректно: " + e.getDescription();
        }
        try {
            Matcher m = SafeRegex.matcher(pattern, PROBE, SafeRegex.deadlineAfter(PROBE_MILLIS));
            while (m.find()) {
                // все совпадения: проверяется время полного прохода
                continue;
            }
            return null;
        } catch (ScenarioException e) {
            return "слишком медленное (не уложилось в " + PROBE_MILLIS + " мс на тестовой строке из "
                    + PROBE_CHARS + " символов)";
        } catch (StackOverflowError e) {
            // например «(a|a?)+$» на длинном повторе: рекурсия движка regex переполняет стек
            return "переполняет стек на тестовой строке из " + PROBE_CHARS + " символов";
        }
    }

    private static List<String> operationProblems(JsonNode op, String where) {
        List<String> problems = new ArrayList<>();
        String name = op.path("оп").asText("");
        List<String> fields = REGEX_FIELDS.getOrDefault(name, List.of());
        boolean plainReplace = "заменить".equals(name) && !"true".equalsIgnoreCase(op.path("regex").asText("false"));
        for (String field : fields) {
            JsonNode value = valueAt(op, field);
            if (plainReplace || !value.isTextual() || value.asText().isBlank()) {
                continue;
            }
            String reason = check(value.asText());
            if (reason != null) {
                problems.add("«" + field + "» операции «" + name + "» в узле «" + where + "»: " + reason
                        + " — шаблон «" + shortPattern(value.asText()) + "»");
            }
        }
        return problems;
    }

    /** Шаблон для сообщения об отказе: длинный обрезается до 80 символов. */
    private static String shortPattern(String regex) {
        return regex.length() <= SHORT_PATTERN ? regex : regex.substring(0, SHORT_PATTERN) + "…";
    }

    private static JsonNode valueAt(JsonNode op, String path) {
        JsonNode current = op;
        for (String token : path.split("\\.")) {
            current = current.path(token);
        }
        return current;
    }

    private static String label(NodeDto node) {
        String label = node.data().label();
        return label == null || label.isBlank() ? node.id() : label;
    }

    /**
     * Синтетическая строка: длинный повтор одной буквы, длинный повтор цифры и короткие слова,
     * каждый блок обрывается символом, который «ломает» совпадение, — на таких хвостах
     * вложенные квантификаторы вроде {@code (a+)+$}, {@code (\w+\s?)*$}, {@code (\S+\s*)+x}
     * не укладываются в {@value #PROBE_MILLIS} мс (замер: движок Java на них квадратичен,
     * на коротких повторах ускорений не видно).
     */
    private static String buildProbe() {
        StringBuilder sb = new StringBuilder(PROBE_CHARS + 64);
        sb.append("a".repeat(4000)).append("! ").append("1".repeat(600)).append("!\n");
        String words = "x y ".repeat(40) + "!\n" + "абвг abcd 1234 56,78 (x) [y] a-b {z}\n";
        while (sb.length() < PROBE_CHARS - 1) {
            sb.append(words);
        }
        sb.setLength(PROBE_CHARS - 1);
        return sb.append('!').toString();
    }
}
