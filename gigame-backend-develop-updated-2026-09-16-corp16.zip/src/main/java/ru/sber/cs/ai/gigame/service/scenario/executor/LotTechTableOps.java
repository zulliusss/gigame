package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «технологии_из_таблицы» узла «Трансформация»: строки «Технология N» методических секций лотов
 * берутся кодом из таблицы Раздела 6 «Номер лота | Технологии для соответствующего лота».
 * <p>
 * В цикле по лотам модель теряла технологии (ЗП с 6 лотами, комплекты 9 и 10 Егоровой: у лотов 1, 2, 4, 6
 * выводила голое «Python» вне таблицы критериев — строка отбрасывалась; у лота 3 писала «GreenPlum | Да»;
 * у лота 6 пропускала Hadoop и PL/SQL). Если таблица найдена, в секции «ЛОТ №K (Методические требования)»
 * прежние строки «Технология …» и строки с названием технологии вместо критерия удаляются, а в начало секции
 * ставятся «Технология 1…n» из строки лота K таблицы. Лоты без строки в таблице и документация без таблицы
 * не трогаются.
 * <pre>
 * {"оп": "технологии_из_таблицы", "текст_из_узла": "Раздел 6 (методика оценки)"}
 * </pre>
 */
final class LotTechTableOps {

    /** Пометка достоверности строк, записанных кодом. */
    static final String EXTRACTED = "из таблицы кодом";
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern ROW = Pattern.compile("^[\\s\\[]*<\\s*(.*?)\\s*>[\\s\\]]*$", Pattern.MULTILINE);
    private static final Pattern LOT_HEADER = Pattern.compile("лот", FLAGS);
    private static final Pattern TECH_HEADER = Pattern.compile("технолог", FLAGS);
    private static final Pattern LOT_NUMBER = Pattern.compile("^(?:лот\\s*№?\\s*)?0*(\\d{1,3})$", FLAGS);
    private static final Pattern SPLIT = Pattern.compile("\\s*(?:,|;|\\s[иИ]\\s)\\s*");
    private static final Pattern METHOD_SECTION = Pattern.compile("^ЛОТ\\s*№\\s*0*(\\d+)\\s*\\(Методическ", FLAGS);
    private static final String SOURCE = "Раздел 6, таблица «Технологии для соответствующего лота», строка лота ";

    private LotTechTableOps() {
    }

    /**
     * Технологии лотов из таблицы текста раздела.
     *
     * @param sectionText текст Раздела 6 (строки таблиц «&lt; ячейка | ячейка &gt;»)
     * @return номер лота → технологии по порядку; пусто, если таблицы нет
     */
    static Map<String, List<String>> parseTable(String sectionText) {
        Map<String, List<String>> lots = new LinkedHashMap<>();
        Matcher m = ROW.matcher(sectionText == null ? "" : sectionText);
        boolean inTable = false;
        int lastEnd = -1;
        while (m.find()) {
            String[] cells = m.group(1).split("\\s*\\|\\s*");
            boolean contiguous = lastEnd >= 0 && sectionText.substring(lastEnd, m.start()).isBlank();
            if (cells.length == 2 && LOT_HEADER.matcher(cells[0]).find() && TECH_HEADER.matcher(cells[1]).find()) {
                inTable = true;
            } else if (inTable && contiguous && cells.length == 2 && LOT_NUMBER.matcher(cells[0].strip()).matches()) {
                Matcher lot = LOT_NUMBER.matcher(cells[0].strip());
                lots.put(lot.matches() ? lot.group(1) : cells[0].strip(), technologies(cells[1]));
            } else {
                inTable = false;
            }
            lastEnd = m.end();
        }
        return lots;
    }

    private static List<String> technologies(String cell) {
        List<String> result = new ArrayList<>();
        for (String part : SPLIT.split(cell.replaceAll("[*«»\"]", " ").strip())) {
            String tech = part.strip();
            if (!tech.isEmpty() && !"-".equals(tech) && !result.contains(tech)) {
                result.add(tech);
            }
        }
        return result;
    }

    /**
     * Перезаписывает строки технологий методических секций по таблице.
     *
     * @param rows        строки критериев (объекты «критерий», «значение», «источник», «секция», «достоверность»)
     * @param sectionText текст Раздела 6
     * @return число лотов, чьи технологии записаны из таблицы
     */
    static int apply(List<Object> rows, String sectionText) {
        Map<String, List<String>> table = parseTable(sectionText);
        int done = 0;
        for (Map.Entry<String, List<String>> lot : table.entrySet()) {
            if (!lot.getValue().isEmpty() && replaceSection(rows, lot.getKey(), lot.getValue())) {
                done++;
            }
        }
        return done;
    }

    private static boolean replaceSection(List<Object> rows, String lotNumber, List<String> techs) {
        List<Object> out = new ArrayList<>();
        boolean inserted = false;
        for (Object o : rows) {
            if (o instanceof Map<?, ?> m && inMethodSection(m, lotNumber)) {
                if (!inserted) {
                    for (int t = 0; t < techs.size(); t++) {
                        out.add(technologyRow(t + 1, techs.get(t), text(m.get("секция")), lotNumber));
                    }
                    inserted = true;
                }
                if (isTechnologyRow(text(m.get("критерий")), techs)) {
                    continue;
                }
            }
            out.add(o);
        }
        if (inserted) {
            rows.clear();
            rows.addAll(out);
        }
        return inserted;
    }

    private static boolean inMethodSection(Map<?, ?> row, String lotNumber) {
        Matcher sm = METHOD_SECTION.matcher(text(row.get("секция")));
        return sm.find() && lotNumber.equals(sm.group(1));
    }

    private static boolean isTechnologyRow(String criterion, List<String> techs) {
        String c = criterion.strip().toLowerCase(Locale.ROOT);
        return c.startsWith("технология") || techs.stream().anyMatch(t -> t.toLowerCase(Locale.ROOT).equals(c));
    }

    private static Map<String, Object> technologyRow(int index, String tech, String section, String lotNumber) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("критерий", "Технология " + index);
        row.put("значение", tech);
        row.put("источник", SOURCE + lotNumber);
        row.put("секция", section);
        row.put("достоверность", EXTRACTED);
        return row;
    }

    private static String text(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
