package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «сверить_подписантов» узла «Трансформация»: ФИО лиц из преамбулы договора
 * («в лице Генерального директора Щербаковой Елены Олеговны») сверяются с расшифровками подписей
 * («Е.О. Щербакова», «Новикова Е.В.»).
 * <p>
 * Преамбула пишет ФИО в родительном падеже, подпись — фамилию в именительном и инициалы, поэтому
 * фамилии сравниваются по основе (без двух последних букв), а имя и отчество — по первым буквам.
 * Итог по каждому лицу: СОВПАДАЕТ; РАСХОЖДЕНИЕ (фамилия та же, инициалы другие); ПОДПИСЬ НЕ НАЙДЕНА
 * (расшифровки с этой фамилией в договоре нет — строки подписи пустые или подписывает другое лицо).
 * <pre>
 * {"оп": "сверить_подписантов", "класс_договора": "договор"}
 * </pre>
 */
final class SignerCheckOps {

    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final String WORD = "[А-ЯЁ][а-яё]+(?:-[А-ЯЁ][а-яё]+)?";
    private static final Pattern IN_PERSON = Pattern.compile("в\\s+лице", FLAGS);
    private static final Pattern FULL_NAME = Pattern.compile("(" + WORD + ")\\s+([А-ЯЁ][а-яё]+)\\s+([А-ЯЁ][а-яё]+(?:вич|ич|вн|чн)[аы]?)(?![а-яё])");
    private static final Pattern INITIALS_FIRST = Pattern.compile("(?<![А-ЯЁа-яё])([А-ЯЁ])\\.\\s?([А-ЯЁ])\\.\\s?(" + WORD + ")");
    private static final Pattern SURNAME_FIRST = Pattern.compile("(" + WORD + ")\\s+([А-ЯЁ])\\.\\s?([А-ЯЁ])\\.");
    /** Сколько символов после «в лице» просматривается в поисках ФИО. */
    private static final int PREAMBLE_WINDOW = 300;
    /** Сколько «в лице» в начале договора рассматривается (стороны договора). */
    private static final int MAX_PARTIES = 4;
    private static final int STEM_CUT = 2;
    private static final int MIN_STEM = 3;

    private SignerCheckOps() {
    }

    /** Лицо: фамилия (как в тексте), первые буквы имени и отчества. */
    record Person(String surname, char name, char patronymic) {

        String initials() {
            return name + "." + patronymic + ".";
        }
    }

    /**
     * Сверка подписантов по договорам прогона.
     *
     * @param op   параметры операции
     * @param docs документы прогона с классами
     * @return отчёт по каждому лицу преамбулы и итоговый JSON
     */
    static String check(Map<String, Object> op, Collection<ScenarioRunDoc> docs) {
        Pattern contractClass = SafeRegex.compile("^(?:" + op.getOrDefault("класс_договора", "договор") + ")$", FLAGS, "класс_договора");
        StringBuilder sb = new StringBuilder("СВЕРКА ПОДПИСАНТОВ (код)\n");
        int mismatches = 0;
        int missing = 0;
        int people = 0;
        for (ScenarioRunDoc doc : docs) {
            if (doc.isWorkNote() || doc.getDocClass() == null || !SafeRegex.matches(contractClass, doc.getDocClass().strip())) {
                continue;
            }
            sb.append("Договор «").append(doc.getFilename()).append("»:\n");
            List<Person> signatures = signatures(doc.getText());
            for (Person person : preamble(doc.getText())) {
                String verdict = verdict(person, signatures);
                people++;
                mismatches += verdict.startsWith("РАСХОЖДЕНИЕ") ? 1 : 0;
                missing += verdict.startsWith("ПОДПИСЬ НЕ НАЙДЕНА") ? 1 : 0;
                sb.append("- ").append(person.surname()).append(' ').append(person.initials()).append(" (преамбула): ").append(verdict).append('\n');
            }
        }
        if (people == 0) {
            sb.append("ФИО подписантов в преамбуле («в лице …») не найдены — сверка не выполнена\n");
        }
        return sb.append("{\"подписантов\": ").append(people).append(", \"расхождений\": ").append(mismatches)
                .append(", \"подпись_не_найдена\": ").append(missing).append("}").toString();
    }

    /**
     * Лица из преамбулы: ФИО (фамилия, имя, отчество) после «в лице».
     *
     * @param text текст договора
     * @return лица по порядку без повторов
     */
    static List<Person> preamble(String text) {
        Set<Person> people = new LinkedHashSet<>();
        Matcher in = IN_PERSON.matcher(text);
        for (int i = 0; i < MAX_PARTIES && in.find(); i++) {
            String window = text.substring(in.end(), Math.min(text.length(), in.end() + PREAMBLE_WINDOW));
            Matcher fm = FULL_NAME.matcher(window);
            if (fm.find()) {
                people.add(new Person(fm.group(1), fm.group(2).charAt(0), fm.group(3).charAt(0)));
            }
        }
        return new ArrayList<>(people);
    }

    /**
     * Расшифровки подписей вида «И.О. Фамилия» и «Фамилия И.О.» во всём тексте договора.
     *
     * @param text текст договора
     * @return лица по порядку появления
     */
    static List<Person> signatures(String text) {
        List<Person> result = new ArrayList<>();
        Matcher a = INITIALS_FIRST.matcher(text);
        while (a.find()) {
            addSignature(result, new Person(a.group(3), a.group(1).charAt(0), a.group(2).charAt(0)));
        }
        Matcher b = SURNAME_FIRST.matcher(text);
        while (b.find()) {
            addSignature(result, new Person(b.group(1), b.group(2).charAt(0), b.group(3).charAt(0)));
        }
        return result;
    }

    /** «М.П.» после расшифровки подписи — место печати, не инициалы. */
    private static void addSignature(List<Person> result, Person person) {
        if (person.name() != 'М' || person.patronymic() != 'П') {
            result.add(person);
        }
    }

    private static String verdict(Person person, List<Person> signatures) {
        List<String> sameSurname = new ArrayList<>();
        for (Person s : signatures) {
            if (!sameSurname(person.surname(), s.surname())) {
                continue;
            }
            if (s.name() == person.name() && s.patronymic() == person.patronymic()) {
                return "СОВПАДАЕТ — подпись «" + s.initials() + " " + s.surname() + "»";
            }
            sameSurname.add(s.initials() + " " + s.surname());
        }
        if (!sameSurname.isEmpty()) {
            return "РАСХОЖДЕНИЕ — в подписи другие инициалы: " + String.join(", ", new LinkedHashSet<>(sameSurname));
        }
        return "ПОДПИСЬ НЕ НАЙДЕНА — расшифровки подписи с фамилией " + person.surname() + " в договоре нет";
    }

    /**
     * Одна ли фамилия в разных падежах: общая основа без двух последних букв («Щербаковой» / «Щербакова»,
     * «Ларионова» / «Ларионов»).
     *
     * @param a фамилия
     * @param b фамилия
     * @return {@code true}, если основы совпадают
     */
    static boolean sameSurname(String a, String b) {
        String x = a.toLowerCase(Locale.ROOT).replace('ё', 'е');
        String y = b.toLowerCase(Locale.ROOT).replace('ё', 'е');
        int stem = Math.max(MIN_STEM, Math.min(x.length(), y.length()) - STEM_CUT);
        return x.length() >= stem && y.length() >= stem && x.substring(0, stem).equals(y.substring(0, stem));
    }
}
