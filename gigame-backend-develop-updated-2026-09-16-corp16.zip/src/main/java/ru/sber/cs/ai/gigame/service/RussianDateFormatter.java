package ru.sber.cs.ai.gigame.service;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Форматтер значений Excel с датами «дд.мм.гггг»: стандартный {@link DataFormatter}
 * даёт «7/1/20», нечитаемое для русских документов и регэкспов Формы 3
 * (ждут dd.MM.yyyy). Общий для потокового разбора XLSX и бинарного XLS.
 */
final class RussianDateFormatter extends DataFormatter {

    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final DateTimeFormatter DATE_TIME = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    @Override
    public String formatRawCellContents(double value, int formatIndex, String formatString, boolean use1904Windowing) {
        if (DateUtil.isADateFormat(formatIndex, formatString) && DateUtil.isValidExcelDate(value)) {
            LocalDateTime date = DateUtil.getLocalDateTime(value, use1904Windowing);
            return date.toLocalTime().equals(LocalTime.MIDNIGHT) ? date.toLocalDate().format(DATE) : date.format(DATE_TIME);
        }
        return super.formatRawCellContents(value, formatIndex, formatString, use1904Windowing);
    }
}
