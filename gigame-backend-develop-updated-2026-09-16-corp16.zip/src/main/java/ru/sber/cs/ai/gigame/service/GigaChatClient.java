package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatEmbeddingOptions;
import chat.giga.springai.GigaChatModel;
import chat.giga.springai.GigaChatOptions;
import chat.giga.springai.api.chat.GigaChatApi;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.content.Media;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Тонкая обёртка над Spring AI моделями (авто-настроенные GigaChat).
 * <p>
 * Сохраняет те же сигнатуры публичных методов, чтобы ChatService и ScenarioEngine
 * не требовали изменений.
 *
 * @see ChatModel
 * @see EmbeddingModel
 */
@Service
@Slf4j
public class GigaChatClient {

    /** Предохранитель раундов tool-цикла (инструменты лимитируются раньше). */
    static final int TOOL_ROUNDS_LIMIT = 60;
    /** Последние K tool-ответов остаются полными при сжатии истории. */
    static final int COMPACT_KEEP_LAST = 2;
    /** Tool-ответы короче порога не сжимаются (сжимать нечего). */
    static final int COMPACT_MIN_CHARS = 1500;
    /** Максимум дозапросов «продолжи» при обрыве ответа по лимиту длины. */
    static final int MAX_CONTINUATIONS = 4;
    static final String CONTINUE_PROMPT = "Твой ответ оборвался по лимиту длины. Продолжи ТОЧНО с места обрыва: "
            + "не повторяй уже написанное, без вступлений, пояснений и повторения заголовков — только продолжение текста.";
    /** Маркер в конце ответа, который остался усечённым по лимиту длины после всех дозапросов. */
    public static final String TRUNCATED_MARKER = "[… ответ модели усечён по лимиту длины …]";
    /** Глубина деления контекста при «context too long»: до 2^3 = 8 частей. */
    static final int MAX_SPLIT_DEPTH = 3;
    /** Контекст короче порога не делится — «context too long» на нём означает слишком длинную инструкцию. */
    static final int MIN_SPLIT_CONTEXT = 2_000;
    /**
     * Невидимая граница «инструкция | контекст» в тексте промпта узла (U+2063 INVISIBLE SEPARATOR):
     * при «context too long» делится только контекст после неё, перед отправкой модели вырезается.
     */
    public static final String SPLIT_BOUNDARY = "\u2063";
    /** Невидимая подсказка в конце промпта (U+2064): при делении объединять JSON-массивы ответов частей. */
    public static final String MERGE_ARRAYS_HINT = "\u2064";

    private final ChatModel chatModel;
    private final EmbeddingModel embeddingModel;
    /**
     * API файлового хранилища GigaChat (может отсутствовать в тестовом контексте).
     */
    private final ObjectProvider<GigaChatApi> gigaChatApiProvider;
    /** Общий ограничитель одновременных запросов к GigaChat; до внедрения Spring — без ограничения. */
    private GigaChatConcurrencyLimiter concurrencyLimiter = GigaChatConcurrencyLimiter.unlimited();
    @Value("${app.embedding.text-max-length:800}")
    private int textMaxLength;
    @Value("${app.embedding.batch-size:50}")
    private int batchSize;
    /**
     * Повторные попытки вызова GigaChat при временных сбоях (429, 5xx, сеть).
     * Дорогие многоузловые сценарии не должны падать из-за разового сбоя API.
     */
    @Value("${app.gigachat.retry.max-attempts:3}")
    private int retryMaxAttempts;
    @Value("${app.gigachat.retry.delay-millis:3000}")
    private long retryDelayMillis;
    @Value("${app.gigachat.retry.delay-429-millis:30000}")
    private long retryDelay429Millis;
    /**
     * Превышение лимита запросов (429): шаг не падает, а ждёт и продолжается
     * сам — пауза удваивается от delay-429-millis до rate-limit-max-delay-millis,
     * пока суммарное ожидание не превысит rate-limit-max-wait-millis.
     */
    @Value("${app.gigachat.retry.rate-limit-max-wait-millis:1800000}")
    private long rateLimitMaxWaitMillis = 1_800_000;
    @Value("${app.gigachat.retry.rate-limit-max-delay-millis:300000}")
    private long rateLimitMaxDelayMillis = 300_000;
    /**
     * Недоступность GigaChat (5xx, таймаут, обрыв соединения, DNS): шаг встаёт на паузу и продолжается сам,
     * пауза удваивается от delay-millis до unavailable-max-delay-millis, пока суммарное ожидание не превысит
     * unavailable-max-wait-millis. Значение 0 — прежнее правило: max-attempts попыток с линейной задержкой.
     */
    @Value("${app.gigachat.retry.unavailable-max-wait-millis:1800000}")
    private long unavailableMaxWaitMillis;
    @Value("${app.gigachat.retry.unavailable-max-delay-millis:120000}")
    private long unavailableMaxDelayMillis = 120_000;
    /**
     * Страховочный потолок одного сетевого LLM-вызова, секунд (больше
     * read-timeout клиента): read-timeout изредка не срабатывает — после
     * волны 429 JDK-клиент повисал в CompletableFuture.get() без отмены,
     * и поток узла висел часами. По истечении потолка вызов прерывается
     * и уходит в общий retry.
     */
    @Value("${app.gigachat.call-hard-timeout-seconds:660}")
    private long callHardTimeoutSeconds;
    /**
     * Размер пула потоков страховочных LLM-вызовов; 0 — по умолчанию
     * max(2, 2 × app.gigachat.max-concurrent). Пул ограничен: при сработавшем
     * потолке ожидания поток остаётся занят до ответа сети, и безграничный
     * cached-пул рос бы с каждым повисшим вызовом.
     */
    @Value("${app.gigachat.llm-call-pool-size:0}")
    private int llmCallPoolSize;
    @Value("${app.gigachat.max-concurrent:5}")
    private int maxConcurrent = 5;
    /** Потоки страховочных LLM-вызовов (daemon — не держат остановку JVM); создаётся при первом вызове. */
    private volatile ExecutorService llmCallPool;

    /**
     * Стек счётчиков токенов текущего потока: движок сценариев открывает кадр
     * перед выполнением узла и закрывает после — все LLM-вызовы узла суммируются.
     * Стек (а не одиночный счётчик) нужен для вложенных под-сценариев:
     * закрытый кадр вливается в родительский.
     */
    private static final ThreadLocal<Deque<long[]>> USAGE_CAPTURE =
            ThreadLocal.withInitial(ArrayDeque::new);
    /**
     * Проверка остановки прогона для потока узла: при взведённом флаге
     * ретраи прерываются — иначе отмена ждала бы весь бюджет повторов
     * (наблюдалось: cancel при мёртвой сети ждал 3×10-минутных таймаута).
     */
    private static final ThreadLocal<java.util.function.BooleanSupplier> RUN_CANCEL_CHECK =
            ThreadLocal.withInitial(() -> () -> false);
    /** Сообщение о паузе повторов в журнал прогона (узел, чей поток ждёт GigaChat). */
    private static final ThreadLocal<Consumer<String>> RUN_WAIT_NOTICE =
            ThreadLocal.withInitial(() -> notice -> { });
    /** Ошибка вызова, прерванного остановкой прогона (а не отказом GigaChat). */
    static final String CANCELLED = "Запрос к GigaChat прерван: прогон остановлен";

    @Autowired
    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel,
                          ObjectProvider<GigaChatApi> gigaChatApiProvider) {
        this.chatModel = chatModel;
        this.embeddingModel = embeddingModel;
        this.gigaChatApiProvider = gigaChatApiProvider;
    }

    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel) {
        this(chatModel, embeddingModel, null);
    }

    /**
     * Внедряет общий ограничитель одновременных запросов к GigaChat.
     *
     * @param limiter ограничитель (null — без ограничения)
     */
    @Autowired(required = false)
    public void setConcurrencyLimiter(GigaChatConcurrencyLimiter limiter) {
        this.concurrencyLimiter = limiter == null ? GigaChatConcurrencyLimiter.unlimited() : limiter;
    }

    /**
     * Открывает кадр учёта токенов для текущего потока.
     */
    public static void beginUsageCapture() {
        USAGE_CAPTURE.get().push(new long[1]);
    }

    /** Ставит проверку остановки прогона для текущего потока (ретраи прерываются). */
    public static void setRunCancelCheck(java.util.function.BooleanSupplier check) {
        RUN_CANCEL_CHECK.set(check == null ? () -> false : check);
    }

    /** Снимает проверку остановки прогона с текущего потока. */
    public static void clearRunCancelCheck() {
        RUN_CANCEL_CHECK.remove();
    }

    /**
     * Ставит для текущего потока вывод сообщений о паузах повторов в журнал прогона.
     *
     * @param notice получатель текста паузы (null — без вывода)
     */
    public static void setRunWaitNotice(Consumer<String> notice) {
        RUN_WAIT_NOTICE.set(notice == null ? text -> { } : notice);
    }

    /** Снимает вывод сообщений о паузах с текущего потока. */
    public static void clearRunWaitNotice() {
        RUN_WAIT_NOTICE.remove();
    }

    /**
     * Закрывает кадр учёта и возвращает суммарные токены кадра.
     * Токены вливаются в родительский кадр (вложенные под-сценарии).
     *
     * @return суммарные total_tokens кадра или {@code null}, если токенов не было
     */
    public static Integer endUsageCapture() {
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            return null;
        }
        long total = stack.pop()[0];
        if (!stack.isEmpty()) {
            stack.peek()[0] += total;
        } else {
            USAGE_CAPTURE.remove();
        }
        return total > 0 ? (int) Math.min(total, Integer.MAX_VALUE) : null;
    }

    /**
     * Добавляет usage LLM-вызова в открытый кадр учёта (если он есть).
     */
    public static void addCapturedUsage(Map<String, Object> usage) {
        if (usage == null) {
            return;
        }
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            USAGE_CAPTURE.remove();
            return;
        }
        Object total = usage.get("total_tokens");
        if (total instanceof Number number && stack.peek() != null) {
            stack.peek()[0] += number.longValue();
        }
    }

    // -------------------------------------------------------------------------
    // Chat completion (synchronous)
    // -------------------------------------------------------------------------

    /**
     * Синхронное выполнение чат-запроса.
     *
     * @param messages список сообщений в формате {role, content}
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages) {
        log.info("[{}] chatCompletion, messages={}",
                CurrentUserHolder.getCurrentUser(), messages.size());
        return chatCompletion(messages, null, null);
    }

    /**
     * Синхронный чат-запрос с переопределением модели и температуры
     * (настройки конкретного узла сценария).
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletion, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        return chatCompletionResult(messages, model, temperature).text();
    }

    /**
     * Результат чат-запроса: текст ответа и статистика использования токенов.
     *
     * @param text  текст ответа ассистента
     * @param usage {prompt_tokens, completion_tokens, total_tokens} или {@code null},
     *              если провайдер не вернул статистику
     */
    public record ChatResult(String text, Map<String, Object> usage) {
    }

    /**
     * Синхронный чат-запрос с переопределением модели/температуры,
     * возвращающий текст ответа вместе со статистикой usage.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionResult(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionResult, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        return chatCompletionSplitting(messages, model, temperature, 0);
    }

    /**
     * Обёртка над одиночным вызовом при 422 «context too long» (запрос больше
     * контекстного окна модели). Сообщение с границей {@link #SPLIT_BOUNDARY}
     * (промпт узла сценария: инструкция + контекст) делится по контексту — см.
     * {@link #chatCompletionSplittable}. Прочие сообщения (свободный текст) — по
     * прежнему правилу: самое длинное режется пополам по границе строки, ответы
     * половин конкатенируются. Глубина деления — до {@link #MAX_SPLIT_DEPTH}
     * (максимум 8 частей); дальше ошибка отдаётся как есть.
     */
    private ChatResult chatCompletionSplitting(List<Map<String, String>> messages, String model,
                                               Double temperature, int depth) {
        log.info("[{}] GigaChatClient.chatCompletionSplitting, messages={}, model={}, temperature={}, depth={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature, depth);
        try {
            return chatCompletionOnce(messages, model, temperature);
        } catch (RuntimeException e) {
            if (depth >= MAX_SPLIT_DEPTH || !isContextTooLong(e)) {
                throw e;
            }
            int boundary = boundaryMessage(messages);
            if (boundary >= 0) {
                return splitByBoundary(messages, boundary, model, temperature, e);
            }
            int idx = -1;
            int max = 0;
            for (int i = 0; i < messages.size(); i++) {
                int len = String.valueOf(messages.get(i).get("content")).length();
                if (len > max) {
                    max = len;
                    idx = i;
                }
            }
            if (idx < 0 || max < 20_000) {
                throw e;
            }
            String content = String.valueOf(messages.get(idx).get("content"));
            int cut = content.lastIndexOf('\n', content.length() / 2);
            if (cut < max / 4) {
                cut = content.length() / 2;
            }
            log.warn("[{}] GigaChat: запрос превышает контекст модели ({} символов) — "
                    + "делю сообщение на 2 части (глубина {})", CurrentUserHolder.getCurrentUser(), max, depth + 1);
            ChatResult r1 = callWithReplacedContent(messages, idx, content.substring(0, cut),
                    model, temperature, depth);
            ChatResult r2 = callWithReplacedContent(messages, idx, content.substring(cut),
                    model, temperature, depth);
            return new ChatResult(r1.text() + "\n\n" + r2.text(),
                    mergeUsage(r1.usage(), r2.usage()));
        }
    }

    private ChatResult callWithReplacedContent(List<Map<String, String>> messages, int idx,
                                               String part, String model, Double temperature,
                                               int depth) {
        return chatCompletionSplitting(replaceContent(messages, idx, part), model, temperature, depth + 1);
    }

    /** Копия списка сообщений с заменённым текстом сообщения idx. */
    private static List<Map<String, String>> replaceContent(List<Map<String, String>> messages, int idx, String part) {
        List<Map<String, String>> copy = new ArrayList<>();
        for (int i = 0; i < messages.size(); i++) {
            copy.add(i == idx
                    ? Map.of("role", messages.get(i).getOrDefault("role", "user"), "content", part)
                    : messages.get(i));
        }
        return copy;
    }

    /**
     * Чат-запрос узла сценария с неделимой инструкцией и делимым контекстом.
     * <p>
     * Запрос уходит одним user-сообщением «инструкция + контекст»; между ними
     * стоит невидимая граница {@link #SPLIT_BOUNDARY} (та же, что ставит
     * {@code AbstractScenarioExecutor.buildPrompt}), перед отправкой модели
     * она вырезается. Если GigaChat отвечает 422 «context too long», делится
     * ТОЛЬКО контекст (по границам документов, страниц, абзацев — см.
     * {@link PromptSplitter#cutPoint}), а инструкция повторяется в каждой части;
     * глубина деления — до {@link #MAX_SPLIT_DEPTH} (максимум 8 частей). Ответы
     * частей помечаются «=== Часть k/N (запрос разделён из-за лимита контекста) ===»,
     * в журнал прогона уходит уведомление; при {@code mergeJsonArrays} (в сообщении —
     * {@link #MERGE_ARRAYS_HINT}) JSON-массивы частей объединяются в один (узлы с
     * контрактом json_массив). Прежнее деление сообщения пополам отправляло
     * вторую половину без инструкции — модель пересказывала документ, а строки терялись.
     *
     * @param instruction     инструкция узла (не делится)
     * @param context         документы и результаты предыдущих шагов (делится); пусто — обычный запрос
     * @param model           модель GigaChat (null — по умолчанию)
     * @param temperature     температура (null — по умолчанию)
     * @param mergeJsonArrays объединять JSON-массивы ответов частей
     * @return текст ответа и суммарный usage
     */
    public ChatResult chatCompletionSplittable(String instruction, String context, String model,
                                               Double temperature, boolean mergeJsonArrays) {
        log.info("[{}] GigaChatClient.chatCompletionSplittable, instruction={}, context={}, model={}",
                CurrentUserHolder.getCurrentUser(), instruction == null ? 0 : instruction.length(),
                context == null ? 0 : context.length(), model);
        return chatCompletionResult(List.of(Map.of("role", "user", "content",
                splittableContent(instruction, context, mergeJsonArrays))), model, temperature);
    }

    /**
     * Текст сообщения «инструкция + граница + контекст (+ подсказка слияния массивов)».
     *
     * @param instruction     инструкция (не делится)
     * @param context         контекст (делится); пусто — граница не ставится
     * @param mergeJsonArrays объединять JSON-массивы ответов частей при делении
     * @return текст сообщения с невидимыми маркерами
     */
    public static String splittableContent(String instruction, String context, boolean mergeJsonArrays) {
        String head = instruction == null ? "" : instruction;
        if (context == null || context.isEmpty()) {
            return head;
        }
        return head + SPLIT_BOUNDARY + "\n\n" + context + (mergeJsonArrays ? MERGE_ARRAYS_HINT : "");
    }

    /** Текст сообщения без служебных маркеров деления (то, что уходит модели). */
    public static String stripSplitMarkers(String content) {
        return content == null ? null : content.replace(SPLIT_BOUNDARY, "").replace(MERGE_ARRAYS_HINT, "");
    }

    /** Индекс сообщения с границей деления либо -1. */
    private static int boundaryMessage(List<Map<String, String>> messages) {
        for (int i = 0; i < messages.size(); i++) {
            if (String.valueOf(messages.get(i).get("content")).contains(SPLIT_BOUNDARY)) {
                return i;
            }
        }
        return -1;
    }

    /** Деление контекста сообщения с границей на части; инструкция повторяется в каждой. */
    private ChatResult splitByBoundary(List<Map<String, String>> messages, int idx, String model,
                                       Double temperature, RuntimeException cause) {
        String content = String.valueOf(messages.get(idx).get("content"));
        boolean merge = content.endsWith(MERGE_ARRAYS_HINT);
        int boundary = content.indexOf(SPLIT_BOUNDARY);
        String instruction = content.substring(0, boundary).stripTrailing();
        String context = content.substring(boundary + SPLIT_BOUNDARY.length(),
                merge ? content.length() - MERGE_ARRAYS_HINT.length() : content.length()).strip();
        if (context.length() < MIN_SPLIT_CONTEXT) {
            throw cause;
        }
        // полный запрос уже отвергнут — сразу первое деление, без повторной отправки целиком
        int cut = PromptSplitter.cutPoint(context);
        log.warn("[{}] GigaChat: запрос превышает контекст модели (контекст {} символов) — "
                + "делю контекст на 2 части, инструкция повторяется", CurrentUserHolder.getCurrentUser(), context.length());
        List<ChatResult> parts = new ArrayList<>();
        callSplitting(messages, idx, instruction, context.substring(0, cut).stripTrailing(), model, temperature, 1, parts);
        callSplitting(messages, idx, instruction, context.substring(cut).stripLeading(), model, temperature, 1, parts);
        return assembleParts(parts, merge);
    }

    /** Вызов «инструкция + часть контекста»; при «context too long» контекст делится пополам, части — рекурсивно. */
    private void callSplitting(List<Map<String, String>> messages, int idx, String instruction, String context,
                               String model, Double temperature, int depth, List<ChatResult> parts) {
        String content = context.isEmpty() ? instruction : instruction + "\n\n" + context;
        try {
            parts.add(chatCompletionOnce(replaceContent(messages, idx, content), model, temperature));
        } catch (RuntimeException e) {
            if (depth >= MAX_SPLIT_DEPTH || !isContextTooLong(e) || context.length() < MIN_SPLIT_CONTEXT) {
                throw e;
            }
            int cut = PromptSplitter.cutPoint(context);
            log.warn("[{}] GigaChat: запрос превышает контекст модели (контекст {} символов) — "
                    + "делю контекст на 2 части (глубина {}), инструкция повторяется", CurrentUserHolder.getCurrentUser(),
                    context.length(), depth + 1);
            callSplitting(messages, idx, instruction, context.substring(0, cut).stripTrailing(), model, temperature,
                    depth + 1, parts);
            callSplitting(messages, idx, instruction, context.substring(cut).stripLeading(), model, temperature,
                    depth + 1, parts);
        }
    }

    /** Ответы частей: заголовки «Часть k/N» либо объединённый JSON-массив; уведомление в журнал прогона. */
    private static ChatResult assembleParts(List<ChatResult> parts, boolean mergeJsonArrays) {
        if (parts.size() == 1) {
            return parts.get(0);
        }
        RUN_WAIT_NOTICE.get().accept("запрос превышает контекст модели — разделён на " + parts.size()
                + " частей, инструкция повторена в каждой; ответы помечены «Часть k/" + parts.size() + "»"
                + (mergeJsonArrays ? ", JSON-массивы частей объединены" : ""));
        Map<String, Object> usage = null;
        List<String> texts = new ArrayList<>();
        for (ChatResult part : parts) {
            usage = mergeUsage(usage, part.usage());
            texts.add(part.text());
        }
        String merged = mergeJsonArrays ? PromptSplitter.mergeJsonArrays(texts) : null;
        if (merged != null) {
            return new ChatResult("=== Ответ собран из " + parts.size()
                    + " частей (запрос разделён из-за лимита контекста), JSON-массивы частей объединены ===\n"
                    + merged, usage);
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < texts.size(); i++) {
            sb.append(i == 0 ? "" : "\n\n").append(PromptSplitter.partHeader(i + 1, texts.size())).append('\n').append(texts.get(i));
        }
        return new ChatResult(sb.toString(), usage);
    }

    static boolean isContextTooLong(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            String msg = String.valueOf(t.getMessage()).toLowerCase();
            if (msg.contains("context too long")
                    || (msg.contains("422") && msg.contains("invalid params"))) {
                return true;
            }
        }
        return false;
    }

    static Map<String, Object> mergeUsage(Map<String, Object> a, Map<String, Object> b) {
        if (a == null || a.isEmpty()) {
            return b;
        }
        if (b == null || b.isEmpty()) {
            return a;
        }
        Map<String, Object> sum = new HashMap<>();
        for (var e : a.entrySet()) {
            long va = e.getValue() instanceof Number n ? n.longValue() : 0;
            long vb = b.get(e.getKey()) instanceof Number n ? n.longValue() : 0;
            sum.put(e.getKey(), va + vb);
        }
        return sum;
    }

    private ChatResult chatCompletionOnce(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionOnce, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        Prompt prompt;
        if (model == null && temperature == null) {
            prompt = toPrompt(messages);
        } else {
            var options = GigaChatOptions.builder();
            if (model != null) {
                options.model(model);
            }
            if (temperature != null) {
                options.temperature(temperature);
            }
            prompt = new Prompt(toPrompt(messages).getInstructions(), options.build());
        }
        ChatResponse response = callWithRetry(prompt);
        if (response == null) {
            throw new GigaChatException("GigaChat вернул пустой ответ");
        }
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        return continueIfTruncated(prompt, response, usage);
    }

    /**
     * Дочитывание ответа, оборванного по лимиту длины выхода модели
     * (finish_reason = length): в историю добавляются уже полученный текст и
     * просьба продолжить с места обрыва, куски склеиваются. До
     * {@link #MAX_CONTINUATIONS} дозапросов. Без этого длинные структурные
     * ответы (JSON на 8 лотов, таблицы критериев) приходили без хвоста, и
     * следующий кодовый узел падал «во входе не найден JSON-массив».
     */
    private ChatResult continueIfTruncated(Prompt prompt, ChatResponse first, Map<String, Object> firstUsage) {
        return continueText(prompt.getInstructions(), prompt.getOptions(), first, firstUsage);
    }

    /**
     * Общее дочитывание для обычного запроса и финального ответа агента: история
     * дополняется полученным текстом и просьбой продолжить. Если модель вместо
     * продолжения запрашивает инструменты, дочитывание прекращается. Ответ,
     * оставшийся усечённым после {@link #MAX_CONTINUATIONS} дозапросов, получает
     * маркер {@link #TRUNCATED_MARKER} и уведомление в журнал прогона — раньше
     * хвост терялся молча.
     *
     * @param messages   история запроса
     * @param options    опции модели (в т.ч. инструменты агента)
     * @param first      первый ответ
     * @param firstUsage usage первого ответа
     * @return склеенный текст и суммарный usage
     */
    private ChatResult continueText(List<Message> messages, ChatOptions options, ChatResponse first,
                                    Map<String, Object> firstUsage) {
        StringBuilder text = new StringBuilder(first.getResult().getOutput().getText());
        Map<String, Object> usage = firstUsage;
        ChatResponse response = first;
        for (int round = 1; isTruncated(response) && round <= MAX_CONTINUATIONS; round++) {
            log.warn("[{}] GigaChat: ответ оборван по лимиту длины ({} символов) — дочитываю, раунд {}",
                    CurrentUserHolder.getCurrentUser(), text.length(), round);
            List<Message> history = new ArrayList<>(messages);
            history.add(new AssistantMessage(text.toString()));
            history.add(new UserMessage(CONTINUE_PROMPT));
            response = callWithRetry(new Prompt(history, options));
            if (response == null || response.getResult() == null || response.getResult().getOutput() == null) {
                break;
            }
            Map<String, Object> part = extractUsage(response);
            addCapturedUsage(part);
            usage = mergeUsage(usage, part);
            if (response.getResult().getOutput().hasToolCalls()) {
                log.warn("[{}] GigaChat: при дочитывании модель запросила инструменты — дочитывание прекращено",
                        CurrentUserHolder.getCurrentUser());
                break;
            }
            text.append(response.getResult().getOutput().getText());
        }
        if (isTruncated(response)) {
            RUN_WAIT_NOTICE.get().accept("ответ модели усечён по лимиту длины после " + MAX_CONTINUATIONS
                    + " дозапросов — конец ответа отсутствует, поставлен маркер");
            text.append('\n').append(TRUNCATED_MARKER);
        }
        return new ChatResult(text.toString(), usage);
    }

    /** Ответ оборван моделью по лимиту выходных токенов. */
    static boolean isTruncated(ChatResponse response) {
        if (response == null || response.getResult() == null || response.getResult().getMetadata() == null) {
            return false;
        }
        String reason = response.getResult().getMetadata().getFinishReason();
        return "length".equalsIgnoreCase(reason) || "max_tokens".equalsIgnoreCase(reason);
    }

    /**
     * Агентский чат-запрос с инструментами (function calling GigaChat).
     * <p>
     * Модель сама решает, какие инструменты вызвать; цикл
     * «модель → инструмент → модель» выполняет {@code GigaChatModel}
     * (internal tool execution), финальный текст возвращается одним ответом.
     * Ограничение числа обращений — на стороне самих инструментов.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param tools       инструменты, доступные модели
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return финальный текст ответа и usage последнего вызова
     */
    public ChatResult chatCompletionWithTools(List<Map<String, String>> messages,
                                              List<ToolCallback> tools,
                                              String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionWithTools, messages={}, tools={}, model={}",
                CurrentUserHolder.getCurrentUser(), messages.size(),
                tools == null ? 0 : tools.size(), model);
        var options = GigaChatOptions.builder();
        if (model != null) {
            options.model(model);
        }
        if (temperature != null) {
            options.temperature(temperature);
        }
        GigaChatOptions built = options.build();
        built.setToolCallbacks(tools);
        // цикл ведём сами (не internal execution): это позволяет сжимать
        // историю между раундами — старые тяжёлые результаты инструментов
        // не пересылаются моделью заново на каждом раунде
        built.setInternalToolExecutionEnabled(false);
        Map<String, ToolCallback> byName = new HashMap<>();
        for (ToolCallback tool : tools) {
            byName.put(tool.getToolDefinition().name(), tool);
        }
        List<Message> history = new ArrayList<>(toPrompt(messages).getInstructions());
        Map<String, Object> usage = null;
        for (int round = 0; round < TOOL_ROUNDS_LIMIT; round++) {
            ChatResponse response = callWithRetry(new Prompt(history, built));
            if (response == null || response.getResult() == null
                    || response.getResult().getOutput() == null) {
                throw new GigaChatException("GigaChat вернул пустой ответ");
            }
            usage = extractUsage(response);
            addCapturedUsage(usage);
            AssistantMessage out = response.getResult().getOutput();
            if (!out.hasToolCalls()) {
                // финальный ответ без вызовов инструментов дочитывается так же, как обычный (finish_reason=length)
                ChatResult finalAnswer = continueText(history, built, response, usage);
                return new ChatResult(sanitizeToolText(finalAnswer.text()), finalAnswer.usage());
            }
            history.add(out);
            history.add(executeToolCalls(out, byName));
            compactToolHistory(history);
        }
        throw new GigaChatException("Лимит раундов инструментов ("
                + TOOL_ROUNDS_LIMIT + ") исчерпан без финального ответа");
    }

    /** Исполняет вызовы инструментов раунда; ошибка инструмента — ответ модели. */
    private static ToolResponseMessage executeToolCalls(AssistantMessage out,
                                                        Map<String, ToolCallback> byName) {
        List<ToolResponseMessage.ToolResponse> responses = new ArrayList<>();
        for (AssistantMessage.ToolCall call : out.getToolCalls()) {
            ToolCallback tool = byName.get(call.name());
            String result;
            try {
                result = tool == null
                        ? "{\"error\": \"неизвестный инструмент " + call.name() + "\"}"
                        : tool.call(call.arguments());
            } catch (Exception e) {
                result = "{\"error\": \"" + String.valueOf(e.getMessage())
                        .replace('"', '\'') + "\"}";
            }
            responses.add(new ToolResponseMessage.ToolResponse(
                    call.id(), call.name(), result));
        }
        return ToolResponseMessage.builder().responses(responses).build();
    }

    /**
     * Сжатие истории цикла (по мотивам deepagents summarization): все
     * tool-ответы, кроме последних {@link #COMPACT_KEEP_LAST}, длиннее
     * {@link #COMPACT_MIN_CHARS} заменяются коротким маркером — тяжёлые
     * фрагменты чтения не пересылаются на каждом последующем раунде
     * (наблюдалось: узел жёг 400-700k токенов на росте истории).
     * Нужное агент всегда может перечитать инструментом заново.
     */
    static void compactToolHistory(List<Message> history) {
        List<Integer> toolIdx = new ArrayList<>();
        for (int i = 0; i < history.size(); i++) {
            if (history.get(i) instanceof ToolResponseMessage) {
                toolIdx.add(i);
            }
        }
        for (int k = 0; k < toolIdx.size() - COMPACT_KEEP_LAST; k++) {
            int i = toolIdx.get(k);
            ToolResponseMessage msg = (ToolResponseMessage) history.get(i);
            List<ToolResponseMessage.ToolResponse> compacted = new ArrayList<>();
            boolean changed = false;
            for (ToolResponseMessage.ToolResponse r : msg.getResponses()) {
                if (r.responseData().length() > COMPACT_MIN_CHARS) {
                    compacted.add(new ToolResponseMessage.ToolResponse(r.id(), r.name(),
                            "{\"note\": \"[сжато] результат " + r.name() + " ("
                                    + r.responseData().length() + " симв) уже обработан "
                                    + "ранее; при необходимости вызови инструмент снова\"}"));
                    changed = true;
                } else {
                    compacted.add(r);
                }
            }
            if (changed) {
                history.set(i, ToolResponseMessage.builder().responses(compacted).build());
            }
        }
    }

    /**
     * После вызовов функций GigaChat может вернуть служебный токен
     * {@code <|superquote|>} вместо кавычек в финальном тексте (артефакт
     * function calling) — восстанавливаем обычные кавычки.
     *
     * @param text финальный текст ответа
     * @return текст с обычными кавычками
     */
    static String sanitizeToolText(String text) {
        return text == null ? null : text.replace("<|superquote|>", "\"");
    }

    /**
     * Чат-запрос с файлом-вложением: файл загружается в файловое хранилище
     * GigaChat (это делает {@code GigaChatModel} автоматически для Media без id),
     * модель распознаёт содержимое (включая сканы), после ответа файл удаляется
     * из хранилища.
     *
     * @param userText    текст запроса к модели
     * @param filename    имя файла (для хранилища)
     * @param content     содержимое файла
     * @param mimeType    MIME-тип файла (например, application/pdf)
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @param maxTokens   лимит токенов ответа (null — значение по умолчанию;
     *                    для полной перепечатки многостраничного скана нужен запас)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionWithFile(String userText, String filename, byte[] content,
                                             String mimeType, String model, Double temperature,
                                             Integer maxTokens) {
        log.info("[{}] GigaChatClient.chatCompletionWithFile, filename='{}', contentType={}, size={}, model={}",
                CurrentUserHolder.getCurrentUser(), filename, mimeType,
                content == null ? 0 : content.length, model);
        // имя файла уходит в Content-Disposition хранилища GigaChat: кириллица,
        // пути и пробелы ломают обработку файла — передаётся безопасное ASCII-имя
        var media = Media.builder()
                .mimeType(MimeType.valueOf(mimeType))
                .data(content)
                .name(safeAttachmentName(filename))
                .build();
        var userMessage = UserMessage.builder().text(userText).media(media).build();
        var options = GigaChatOptions.builder();
        if (model != null) {
            options.model(model);
        }
        if (temperature != null) {
            options.temperature(temperature);
        }
        if (maxTokens != null) {
            options.maxTokens(maxTokens);
        }
        Prompt prompt = new Prompt(List.of(userMessage), options.build());
        ChatResponse response = callWithRetry(prompt);
        if (response == null || response.getResult() == null || response.getResult().getOutput() == null) {
            throw new GigaChatException("GigaChat вернул пустой ответ");
        }
        deleteUploadedMedia(response);
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        String text = response.getResult().getOutput().getText();
        if (isTruncated(response)) {
            // дочитать нельзя: вложение уже удалено из хранилища, повторная загрузка — новый запрос;
            // без маркера обрыв распознанной страницы (max_tokens) оставался незаметным
            log.warn("[{}] GigaChat: ответ на вложение '{}' оборван по лимиту токенов ({}) — поставлен маркер",
                    CurrentUserHolder.getCurrentUser(), filename, maxTokens);
            text = text + "\n" + TRUNCATED_MARKER;
        }
        return new ChatResult(text, usage);
    }

    /**
     * Безопасное ASCII-имя вложения для файлового хранилища GigaChat:
     * расширение сохраняется, остальное заменяется хэшем исходного имени.
     *
     * @param filename исходное имя файла (может содержать путь и кириллицу)
     * @return имя вида {@code attachment-1a2b3c4d.pdf}
     */
    static String safeAttachmentName(String filename) {
        if (filename == null || filename.isBlank()) {
            return "";
        }
        String ext = "";
        int dot = filename.lastIndexOf('.');
        if (dot >= 0 && filename.substring(dot + 1).matches("[A-Za-z0-9]{1,8}")) {
            ext = "." + filename.substring(dot + 1).toLowerCase(Locale.ROOT);
        }
        return "attachment-" + Integer.toHexString(filename.hashCode()) + ext;
    }

    /**
     * Удаляет из файлового хранилища GigaChat файлы, загруженные моделью
     * для этого запроса (их id — в метаданных ответа). Ошибка удаления не
     * прерывает обработку: файлы приватные и лишь занимают квоту хранилища.
     *
     * @param response ответ модели
     */
    private void deleteUploadedMedia(ChatResponse response) {
        try {
            var api = gigaChatApiProvider != null ? gigaChatApiProvider.getIfAvailable() : null;
            if (api == null || response.getMetadata() == null) {
                return;
            }
            Object ids = response.getMetadata().get(GigaChatModel.UPLOADED_MEDIA_IDS);
            if (!(ids instanceof Collection<?> list)) {
                return;
            }
            for (Object id : list) {
                api.deleteFile(String.valueOf(id));
            }
        } catch (Exception e) {
            log.warn("[{}] Не удалось удалить файлы из хранилища GigaChat: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /**
     * Извлекает статистику использования токенов из ответа модели.
     *
     * @param response ответ Spring AI
     * @return map с ключами prompt_tokens/completion_tokens/total_tokens или {@code null}
     */
    private Map<String, Object> extractUsage(ChatResponse response) {
        try {
            var metadata = response.getMetadata();
            if (metadata == null || metadata.getUsage() == null) {
                return Map.of();
            }
            var usage = metadata.getUsage();
            Map<String, Object> map = new HashMap<>();
            map.put("prompt_tokens", usage.getPromptTokens());
            map.put("completion_tokens", usage.getCompletionTokens());
            map.put("total_tokens", usage.getTotalTokens());
            return map;
        } catch (Exception e) {
            log.info("[{}] Не удалось извлечь usage из ответа GigaChat: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return Map.of();
        }
    }

    /**
     * Вызов чат-модели с повторными попытками при временных сбоях.
     * <p>
     * Повторяются: 429 (превышение лимита — увеличенная задержка), 5xx, сетевые
     * таймауты. Не повторяются: 4xx-ошибки данных (400, 401, 402, 413) —
     * повтор их не исправит. Задержка растёт линейно с номером попытки.
     * Используется реактивный retryWhen — без блокировки потоков boundedElastic
     * в ожидании повтора.
     *
     * @param prompt промпт
     * @return ответ модели
     */
    private ChatResponse callWithRetry(Prompt prompt) {
        return withRetry(() -> callWithHardTimeout(prompt), () -> modelName(prompt));
    }

    /**
     * Имя модели запроса для текста ошибки: из опций промпта, иначе модель по умолчанию.
     *
     * @param prompt промпт
     * @return имя модели или {@code null}, если неизвестно
     */
    private String modelName(Prompt prompt) {
        ChatOptions options = prompt.getOptions();
        if (options != null && options.getModel() != null) {
            return options.getModel();
        }
        ChatOptions defaults = chatModel.getDefaultOptions();
        return defaults == null ? null : defaults.getModel();
    }

    /**
     * Вызов модели на отдельном потоке с жёстким потолком ожидания
     * {@code callHardTimeoutSeconds}: по истечении вызов прерывается,
     * а ошибка (в тексте — «timeout») уходит в общий retry как временная.
     * Поток узла при любом поведении сети освобождается гарантированно.
     */
    private ChatResponse callWithHardTimeout(Prompt prompt) {
        return limited(() -> sendWithHardTimeout(prompt));
    }

    /**
     * Одна HTTP-попытка с потолком ожидания; выполняется под разрешением ограничителя, взятым
     * до отправки (ожидание очереди не расходует потолок) и отпущенным сразу после попытки.
     */
    private ChatResponse sendWithHardTimeout(Prompt prompt) {
        if (callHardTimeoutSeconds <= 0) {
            return chatModel.call(prompt);
        }
        Future<ChatResponse> future = llmCallPool().submit(() -> chatModel.call(prompt));
        try {
            return future.get(callHardTimeoutSeconds, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            future.cancel(true);
            throw new GigaChatException("Страховочный timeout LLM-вызова: ответ не получен за "
                    + callHardTimeoutSeconds + " с", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            future.cancel(true);
            throw new GigaChatException("LLM-вызов прерван", e);
        } catch (ExecutionException e) {
            throw e.getCause() instanceof RuntimeException re
                    ? re
                    : new GigaChatException("Сбой LLM-вызова", e.getCause());
        }
    }

    /**
     * Ограниченный пул страховочных LLM-вызовов: размер — {@code app.gigachat.llm-call-pool-size}
     * либо max(2, 2 × max-concurrent); создаётся при первом обращении (в тестах без Spring — с умолчаниями).
     *
     * @return пул потоков LLM-вызовов
     */
    private ExecutorService llmCallPool() {
        ExecutorService pool = llmCallPool;
        if (pool == null) {
            synchronized (this) {
                if (llmCallPool == null) {
                    int size = llmCallPoolSize > 0 ? llmCallPoolSize : Math.max(2, 2 * maxConcurrent);
                    llmCallPool = Executors.newFixedThreadPool(size, r -> {
                        Thread t = new Thread(r, "llm-call");
                        t.setDaemon(true);
                        return t;
                    });
                }
                pool = llmCallPool;
            }
        }
        return pool;
    }

    /** Останавливает пул страховочных LLM-вызовов при выключении приложения. */
    @PreDestroy
    public void shutdownLlmCallPool() {
        ExecutorService pool = llmCallPool;
        if (pool != null) {
            pool.shutdownNow();
        }
    }

    private <T> T withRetry(Supplier<T> call) {
        return withRetry(call, () -> null);
    }

    /**
     * Вызов с повторами по {@link GigaChatRetryPolicy}; неповторяемая ошибка или исчерпанные паузы —
     * {@link GigaChatException} «Не удалось выполнить запрос к GigaChat: краткая причина».
     *
     * @param call  вызов
     * @param model имя модели запроса для текста причины (вычисляется только при ошибке)
     * @return результат вызова
     */
    private <T> T withRetry(Supplier<T> call, Supplier<String> model) {
        var cancelled = RUN_CANCEL_CHECK.get();
        var notice = RUN_WAIT_NOTICE.get();
        var policy = new GigaChatRetryPolicy(new GigaChatRetryPolicy.Settings(retryDelay429Millis, rateLimitMaxDelayMillis,
                rateLimitMaxWaitMillis, retryDelayMillis, unavailableMaxDelayMillis, unavailableMaxWaitMillis, retryMaxAttempts), model);
        while (true) {
            try {
                return call.get();
            } catch (RuntimeException e) {
                if (cancelled.getAsBoolean()) {
                    log.info("[{}] GigaChat: прогон остановлен — повторы прерваны", CurrentUserHolder.getCurrentUser());
                    throw new GigaChatException(CANCELLED, e);
                }
                String msg = failureText(e);
                GigaChatRetryPolicy.Wait wait = policy.next(isRateLimited(msg), isTransientFailure(msg), e);
                log.warn("[{}] GigaChat: {}: {}", CurrentUserHolder.getCurrentUser(), wait.notice(), msg);
                notice.accept(wait.notice());
                sleepUnlessCancelled(wait.delayMillis(), cancelled);
            }
        }
    }

    /** Ожидание кусками по 2 с с проверкой остановки прогона. */
    private static void sleepUnlessCancelled(long millis, java.util.function.BooleanSupplier cancelled) {
        long end = System.currentTimeMillis() + millis;
        while (System.currentTimeMillis() < end && !cancelled.getAsBoolean()) {
            try {
                Thread.sleep(Math.min(2000, Math.max(1, end - System.currentTimeMillis())));
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return;
            }
        }
    }

    /**
     * Превышение лимита запросов (429) — повторяется с увеличенной задержкой.
     *
     * @param msg текст ошибки
     * @return {@code true}, если ошибка — превышение лимита
     */
    private static boolean isRateLimited(String msg) {
        if (msg.contains("413") && msg.contains("Tokens limit")) {
            return false;
        }
        return msg.contains("429") || msg.contains("Too Many Requests");
    }

    /**
     * Временный сбой (5xx, сетевой таймаут, обрыв соединения, неразрешённое имя хоста) — повторяется.
     * 4xx-ошибки данных (400, 401, 402, 413) не повторяются: повтор их не исправит.
     *
     * @param msg текст ошибки
     * @return {@code true}, если сбой временный
     */
    /**
     * Текст сбоя с цепочкой причин (класс и сообщение каждой) — по нему распознаются
     * временные сбои: у «I/O error on POST request» причина (UnresolvedAddressException,
     * таймаут) лежит глубже верхнего сообщения.
     *
     * @param e исключение
     * @return сообщения и классы по цепочке причин
     */
    private static String failureText(Throwable e) {
        StringBuilder sb = new StringBuilder();
        Throwable t = e;
        for (int depth = 0; t != null && depth < 8; depth++) {
            sb.append(t.getClass().getSimpleName()).append(": ").append(t.getMessage()).append("; ");
            t = t.getCause() == t ? null : t.getCause();
        }
        return sb.toString();
    }

    private static boolean isTransientFailure(String msg) {
        if (msg.contains("413") && msg.contains("Tokens limit")) {
            return false;
        }
        boolean serverError = msg.contains("50") && (msg.contains("500") || msg.contains("502")
                || msg.contains("503") || msg.contains("504"));
        // имя не разрешилось (DNS через туннель мигает) — такой же временный сбой, как обрыв соединения
        return serverError
                || msg.contains("timed out") || msg.contains("timeout")
                || msg.contains("Connection") || msg.contains("connection")
                || msg.contains("UnresolvedAddress") || msg.contains("UnknownHost");
    }

    // -------------------------------------------------------------------------
    // Завершение чата (последовательное)
    // -------------------------------------------------------------------------

    /**
     * Потоковое выполнение чат-запроса, возвращает Flux текстовых фрагментов.
     * <p>
     * Использует синхронный вызов, обёрнутый в Flux — у GigaChat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ.
     *
     * @param messages список сообщений в формате {role, content}
     * @return Flux строк текста
     */
    public Flux<String> chatCompletionStream(List<Map<String, String>> messages) {
        return chatCompletionStreamResult(messages, null, null).map(ChatResult::text);
    }

    /**
     * Потоковый чат-запрос с переопределением модели/температуры и usage в результате.
     * <p>
     * Используется синхронный вызов, обёрнутый в Flux — у spring-ai-gigachat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ одним элементом.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return Flux с единственным ChatResult
     */
    public Flux<ChatResult> chatCompletionStreamResult(List<Map<String, String>> messages,
                                                       String model, Double temperature) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] GigaChatClient.chatCompletionStreamResult, messages={}, model={}",
                userId, messages.size(), model);
        return Flux.defer(() -> {
            CurrentUserHolder.setCurrentUser(userId);
            log.info("[{}] Start chat completion (synchronous)", userId);
            ChatResult result = chatCompletionResult(messages, model, temperature);
            log.info("[{}] Chat completion completed, {} characters", userId, result.text().length());
            return Flux.just(result);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    // -------------------------------------------------------------------------
    // эмбеддинги
    // -------------------------------------------------------------------------

    /**
     * Получает векторные эмбеддинги для списка текстов.
     * <p>
     * Пакетная обработка: по 50 текстов за раз. Текст усекается до 800 символов
     * (ограничение GigaChat ~514 токенов).
     *
     * @param texts список текстов для эмбеддинги
     * @return список массивов float[] векторных эмбеддингов
     */
    public List<float[]> getEmbeddings(List<String> texts) {
        log.info("[{}] GigaChatClient.getEmbeddings, texts={}",
                CurrentUserHolder.getCurrentUser(),
                texts == null ? 0 : texts.size());
        if (texts == null) {
            return List.of();
        }
        List<String> truncated = texts.stream()
                .map(t -> t.length() > textMaxLength ? t.substring(0, textMaxLength) : t)
                .toList();

        List<float[]> results = new ArrayList<>();
        for (int i = 0; i < truncated.size(); i += batchSize) {
            List<String> batch = truncated.subList(i, Math.min(i + batchSize, truncated.size()));
            // Используются специфичные для GigaChat опции, чтобы избежать NPE при getModel()
            try {
                var opts = GigaChatEmbeddingOptions.builder()
                        .withModel("Embeddings").withDimensions(1024).build();
                EmbeddingResponse response = withRetry(() -> limitedEmbeddings(() -> embeddingModel.call(
                        new EmbeddingRequest(batch, opts))));
                if (response == null) {
                    log.warn("[{}] Embedding batch {} вернул null, пропускаем", CurrentUserHolder.getCurrentUser(), i / batchSize);
                    results.addAll(Collections.nCopies(batch.size(), new float[1024]));
                    continue;
                }
                results.addAll(response.getResults().stream()
                        .map(Embedding::getOutput)
                        .toList());
            } catch (Exception e) {
                log.error("[{}] Embedding batch {} failed {}", CurrentUserHolder.getCurrentUser(), i / batchSize, e.getMessage());
                // Return nulls or empty arrays for failed batch
                results.addAll(Collections.nCopies(batch.size(), new float[1024]));
            }
        }
        return results;
    }

    // -------------------------------------------------------------------------
    // Внутренние вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Одна попытка чат-запроса под общим ограничителем: разрешение держится только
     * на время самого вызова и отпускается до паузы повтора в {@code withRetry}.
     * Ожидание очереди прерывается остановкой прогона и видно в его журнале.
     *
     * @param call попытка вызова модели
     * @param <T>  тип ответа
     * @return ответ модели
     */
    private <T> T limited(Supplier<T> call) {
        return concurrencyLimiter.call(call, RUN_CANCEL_CHECK.get(), RUN_WAIT_NOTICE.get());
    }

    /**
     * Одна попытка запроса эмбеддингов под общим ограничителем (если он распространяется на эмбеддинги).
     *
     * @param call попытка вызова модели эмбеддингов
     * @param <T>  тип ответа
     * @return ответ модели
     */
    private <T> T limitedEmbeddings(Supplier<T> call) {
        return concurrencyLimiter.callEmbeddings(call, RUN_CANCEL_CHECK.get(), RUN_WAIT_NOTICE.get());
    }

    /**
     * Преобразует наш формат List&lt;Map&lt;role,content&gt;&gt; в Spring AI Prompt.
     *
     * @param messages список сообщений
     * @return объект Prompt для Spring AI
     */
    private Prompt toPrompt(List<Map<String, String>> messages) {
        List<Message> aiMessages = new ArrayList<>();
        for (Map<String, String> msg : messages) {
            String role = msg.get("role");
            String content = stripSplitMarkers(msg.get("content"));
            switch (role) {
                case "system" -> aiMessages.add(new SystemMessage(content));
                case "assistant" -> aiMessages.add(new AssistantMessage(content));
                default /*user*/ -> aiMessages.add(new UserMessage(content));
            }
        }
        return new Prompt(aiMessages);
    }
}
