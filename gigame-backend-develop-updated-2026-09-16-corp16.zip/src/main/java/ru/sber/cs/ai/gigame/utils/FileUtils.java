package ru.sber.cs.ai.gigame.utils;

import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.multipart.FilePart;
import reactor.core.publisher.Mono;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Утилитный класс для работы с файлами в реактивном контексте.
 * <p>
 * Предоставляет методы для преобразования FilePart в InputStream
 * в рамках реактивной обработки multipart-загрузок.
 *
 * @see FilePart
 * @see Mono
 */
public class FileUtils {
    private static final Pattern FILENAME_PATTERN = Pattern.compile("filename=\"?([^\";]+)\"?", Pattern.CASE_INSENSITIVE);
    /** Начало ZIP-контейнера (книги Office 2007+). */
    private static final byte[] ZIP_SIGNATURE = {0x50, 0x4B, 0x03, 0x04};
    /** Начало составного документа OLE2 (бинарные книги Excel 97–2003). */
    private static final byte[] OLE2_SIGNATURE = {(byte) 0xD0, (byte) 0xCF, 0x11, (byte) 0xE0};

    /**
     * Маппинг расширений файлов на типы контента.
     * Поддерживаемые форматы: PDF, DOCX, XLSX, XLS (бинарный), PPTX, XML,
     * а также текстовые: TXT, CSV/TSV, MD, JSON, YAML, LOG (читаются как plain text).
     */
    private static final Map<String, String> EXTENSION_MAP = Map.ofEntries(
            Map.entry("pdf", "pdf"),
            Map.entry("docx", "docx"),
            Map.entry("xlsx", "xlsx"),
            Map.entry("xls", "xls"),
            Map.entry("pptx", "pptx"),
            Map.entry("xml", "xml"),
            Map.entry("txt", "txt"),
            Map.entry("text", "txt"),
            Map.entry("csv", "txt"),
            Map.entry("tsv", "txt"),
            Map.entry("md", "txt"),
            Map.entry("json", "txt"),
            Map.entry("yaml", "txt"),
            Map.entry("yml", "txt"),
            Map.entry("log", "txt")
    );

    private FileUtils() {
    }

    /**
     * Преобразует FilePart в Mono&lt;InputStream&gt; для реактивной обработки.
     * <p>
     * Собирает все фрагменты данных из FilePart в один byte[] массив
     * и возвращает их как ByteArrayInputStream внутри Mono.
     *
     * @param filePart загруженный файл
     * @return Mono, содержащее InputStream с данными файла
     */
    public static Mono<InputStream> toInputStream(FilePart filePart) {
        return DataBufferUtils.join(filePart.content())
                .handle((dataBuffer, sink) -> {
                    byte[] bytes = new byte[dataBuffer.readableByteCount()];
                    dataBuffer.read(bytes);
                    DataBufferUtils.release(dataBuffer);
                    sink.next(new ByteArrayInputStream(bytes));
                });
    }

    /**
     * Извлекает расширение файла из его имени.
     *
     * @param filename имя файла
     * @return расширение в нижнем регистре или "bin" если расширение не найдено
     */
    private static String extractExtension(String filename) {
        int dotIdx = filename.lastIndexOf('.');
        if (dotIdx < 0) {
            return "bin";
        }
        return filename.substring(dotIdx + 1);
    }

    /**
     * Сопоставляет расширение файла с нормализованным строковым типом контента.
     *
     * @param filename имя файла
     * @return тип контента: "pdf", "docx", "xlsx" или "txt"
     * @throws IllegalArgumentException если расширение не поддерживается
     */
    public static String detectContentType(String filename) {
        String ext = extractExtension(filename).toLowerCase();
        String type = EXTENSION_MAP.get(ext);
        if (type == null) {
            throw new FileException("Unsupported file extension: ." + ext);
        }
        return type;
    }

    /**
     * Поддерживается ли расширение файла парсером документов (единый список
     * с {@link #detectContentType(String)} — распаковка архивов не должна
     * отбрасывать форматы, которые парсер умеет читать).
     *
     * @param extension расширение без точки, в любом регистре
     * @return {@code true}, если файл с таким расширением разбирается
     */
    public static boolean isSupportedExtension(String extension) {
        return extension != null && EXTENSION_MAP.containsKey(extension.toLowerCase());
    }

    /**
     * Тип контента по расширению с поправкой на фактическое содержимое Excel-файла.
     * <p>
     * Почтовые клиенты сохраняют вложения под короткими именами («3_1~1 (1).XLS»), и книга Office 2007+
     * (ZIP-контейнер) получает расширение .xls: бинарный парсер падал, форма участника не разбиралась.
     * Обратный случай — старая бинарная книга (OLE2) с расширением .xlsx.
     *
     * @param filename имя файла
     * @param content  содержимое файла
     * @return тип контента («xlsx» для ZIP-содержимого с расширением .xls, «xls» для OLE2 с расширением .xlsx)
     */
    public static String detectContentType(String filename, byte[] content) {
        String type = detectContentType(filename);
        if ("xls".equals(type) && startsWith(content, ZIP_SIGNATURE)) {
            return "xlsx";
        }
        if ("xlsx".equals(type) && startsWith(content, OLE2_SIGNATURE)) {
            return "xls";
        }
        return type;
    }

    private static boolean startsWith(byte[] content, byte[] signature) {
        if (content == null || content.length < signature.length) {
            return false;
        }
        for (int i = 0; i < signature.length; i++) {
            if (content[i] != signature[i]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Извлекает имена файлов из списка FilePart.
     * <p>
     * Получает имя файла из заголовка Content-Disposition каждого FilePart.
     *
     * @param files Список FilePart с файлами
     * @return Список имен файлов
     */
    public static List<String> getFilenamesFromFileParts(List<FilePart> files) {
        return files.stream()
                .map(FileUtils::getFilename)
                .toList();
    }

    /**
     * Извлекает имя файла из FilePart через заголовок Content-Disposition.
     * <p>
     * В отличие от {@link FilePart#filename()}, сохраняет относительный путь
     * (например, при загрузке каталога через webkitdirectory).
     *
     * @param filePart загруженный файл
     * @return имя файла (возможно, с относительным путём)
     */
    public static String getFilename(FilePart filePart) {
        HttpHeaders headers = filePart.headers();
        @SuppressWarnings("java:S2583")
        String disposition = headers == null ? null : headers.getFirst(HttpHeaders.CONTENT_DISPOSITION);
        if (disposition == null || disposition.isBlank()) {
            return filePart.filename();
        }
        Matcher matcher = FILENAME_PATTERN.matcher(disposition);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return filePart.filename();
    }

}
