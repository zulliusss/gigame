package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ru.sber.cs.ai.gigame.service.scenario.executor.Form3Ops.str;

/**
 * Строки Формы 3 по реестру документов и критериям Шага 1 (шаблон Егоровой):
 * к1 компания, к2 исполнитель, к3 заказчик, к4 договор, к5 спецификация,
 * к6 акт/УПД, к7 дата подписания, к8 период квалификации (да/нет), к9 период
 * методики (да/нет), к10 сумма по акту, к11 заказчик в рейтинге (да/нет),
 * к12 мобильная разработка (да/нет), к13 только тестирование (да/нет),
 * к14 сумма зачтено, к15 причина незачёта, т_&lt;технология&gt; (да/нет) по
 * каждой технологии критериев, к16…к19 технология подтверждена в договоре /
 * спецификации / акте / отчёте, к20 аудит.
 * <p>
 * Сумма зачитывается, только если акт подписан заказчиком, найдена хотя бы
 * одна технология хотя бы в одном документе строки, заказчик в рейтинге,
 * дата акта внутри периода методики, нет мобильной разработки (если закупка
 * не мобильная) и спецификация не только на тестирование.
 */
final class Form3Rows {

    static final String YES = "да";
    static final String NO = "нет";
    static final String NO_DATA = "нет данных";
    static final String MANUAL = "проверить вручную";
    static final String DASH = "-";
    /** Формулировки причин незачёта — как в разметке Егоровой. */
    static final String REASON_NO_DOCS = "Подтверждающие документы не найдены";
    static final String REASON_PERIOD = "Акт не в периоде";
    static final String REASON_RATING = "Заказчик не в рейтинге";
    /** Поле строки с исходной строкой формы — ключ обогащения формы. */
    static final String SOURCE_LINE = "исходная_строка";
    /** Служебное поле строки: сколько договоров комплекта найдено для строки (правило «без договора не засчитывать»). */
    static final String CONTRACTS = "договоров_найдено";
    /**
     * Заказчики в рейтингах по умолчанию (переопределяется конфигом {@code "заказчики_в_рейтинге"}):
     * ТОП-25 банков по активам и крупнейшие компании (ТОП-100 РБК/Мосбиржи). Дочерние
     * и зависимые общества не засчитываются («ЛУКОЙЛ-Интер-Кард» ≠ «ЛУКОЙЛ») — имя
     * компании должно стоять отдельным словом, без дефисного продолжения.
     */
    private static final String DEFAULT_RATING = "Сбербанк|СБЕР\\b|ВТБ|Газпромбанк|Альфа\\s?-?\\s?Банк|Россельхозбанк|Открытие|"
            + "Совкомбанк|Райффайзен|Росбанк|Тинькофф|Т-Банк|Промсвязьбанк|Московский кредитный банк|МКБ|ЮниКредит|"
            + "Ак Барс|Почта Банк|Уралсиб|Банк Санкт-Петербург|Ситибанк|Хоум Банк|Русский Стандарт|ОТП Банк|Зенит|"
            + "ДОМ\\.РФ|Новикомбанк|Абсолют|"
            + "МЕТРО Кэш энд Керри|Metro Cash|X5|Магнит\\b|Яндекс|Ozon|Wildberries|Вайлдберриз|МТС\\b|МегаФон|Ростелеком|"
            + "(?<![\\wА-Яа-я-])(?:Газпром|Роснефть|ЛУКОЙЛ|Лукойл|НОВАТЭК|Норникель|Сургутнефтегаз|Татнефть|Северсталь|НЛМК|ММК|"
            + "РУСАЛ|Полюс|АЛРОСА|Аэрофлот|РЖД|Транснефть|Ростех|Росатом|ФосАгро|Интер РАО|РусГидро|Россети|Сибур|"
            + "Мечел|Евраз|ПИК|Самолет|ЛСР|Лента|Детский мир|М\\.Видео|Ситилинк|Softline|Positive Technologies|VK)(?![\\wА-Яа-я-])";
    /** Встроенный перечень заказчиков рейтинга — скомпилирован один раз (длиннее предела пользовательского шаблона). */
    private static final Pattern DEFAULT_RATING_PATTERN = Pattern.compile(DEFAULT_RATING,
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern MOBILE = Pattern.compile(
            "мобильн[а-я]*\\s+(приложен|разработ|платформ|клиент|верси|банк|устройств)|(?<![a-z])(ios|android)(?![a-z])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Технологии-платформы мобильной разработки в критериях. */
    private static final Pattern PLATFORM = Pattern.compile("(?iu)\\s*(ios|android|harmonyos|аврора|huawei\\s*\\w*)\\s*");
    /** Слова о мобильном приложении — сильное доказательство мобильной разработки (без упоминаний платформ). */
    private static final Pattern MOBILE_WORDS = Pattern.compile(
            "мобильн[а-я]*\\s+(приложен|разработ|платформ|клиент|верси|банк|устройств)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SUBJECT = Pattern.compile("Предмет\\s+(?:Спецификации|Заказа|Договора|отч[её]та)?\\s*:?\\s*([^\\n]{0,600})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern TESTING = Pattern.compile("тестирован|испытани|автотест|\\bQA\\b",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern DEVELOPMENT = Pattern.compile(
            "разработ|модификац|доработ|создани|реализац|внедрен|сопровожден|развити|проектирован|интеграц|миграц|поддержк",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final int SUBJECT_LIMIT = 600;
    private static final Pattern FORM_SPEC = Pattern.compile("Спецификаци\\S{0,3}\\s*№?\\s*(\\d{7,8})(?!\\d)");
    private static final Pattern FORM_AMOUNT = Pattern.compile("(?<![\\d,.])(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?![\\d])");
    private static final Pattern SPEC_NUMBER = Pattern.compile("(?<!\\d)(\\d{6,8})(?!\\d)");
    private static final Pattern CONTRACT_DIGITS = Pattern.compile("(?<![\\d/])(\\d{5,12})(?![\\d/])");
    /** Роль исполнителя с технологией в спецификации: «Главный разработчик GreenPlum», «Ведущий аналитик Python». */
    private static final Pattern ROLE_TECH = Pattern.compile("(?:разработчик|аналитик|архитектор|тестировщик|инженер)\\s+([A-Za-z][A-Za-z0-9+#./-]{1,24})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern CONTRACT_ALNUM = Pattern.compile("№\\s*([A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9/\\-]{2,24})");

    private Form3Rows() {
    }

    /** Документы, относящиеся к строке УПД. */
    private record Linked(Map<String, Object> upd, List<Map<String, Object>> specs,
                          List<Map<String, Object>> contracts, List<Map<String, Object>> reports, String specNote) {
    }

    /**
     * Номера спецификаций из строк формы участника, относящихся к УПД: строка
     * содержит номер УПД либо сумму и дату УПД (участники нередко пишут в
     * форме номер заказа вместо номера УПД).
     */
    static Set<String> formSpecHints(Map<String, Object> upd, String formLines) {
        Set<String> hints = new LinkedHashSet<>();
        if (formLines == null || formLines.isBlank()) {
            return hints;
        }
        String number = str(upd.get("номер")).replaceFirst("^0+", "");
        Pattern byNumber = number.isEmpty() ? null : Pattern.compile("УПД\\s*№?\\s*0*" + Pattern.quote(number) + "(?!\\d)");
        String amount = str(upd.get("сумма"));
        String date = str(upd.get("дата"));
        for (String line : formLines.split("\n")) {
            boolean hit = byNumber != null && byNumber.matcher(line).find();
            if (!hit && !amount.isEmpty() && !date.isEmpty() && line.contains(date)) {
                Matcher m = FORM_AMOUNT.matcher(line);
                while (m.find() && !hit) {
                    hit = amount.equals(m.group(1).replace(" ", "") + "." + m.group(2));
                }
            }
            if (hit) {
                Matcher m = FORM_SPEC.matcher(line);
                while (m.find()) {
                    hints.add(m.group(1));
                }
            }
        }
        return hints;
    }

    private static List<Map<String, Object>> withNumbers(List<Map<String, Object>> specs, Set<String> numbers) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> spec : specs) {
            if (numbers.contains(str(spec.get("номер")))) {
                out.add(spec);
            }
        }
        return out;
    }

    private static List<Map<String, Object>> dedupByNumber(List<Map<String, Object>> specs) {
        Set<String> seen = new LinkedHashSet<>();
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> spec : specs) {
            if (seen.add(str(spec.get("номер")))) {
                out.add(spec);
            }
        }
        return out;
    }

    /**
     * Строки формы по реестру.
     *
     * @param op       конфиг операции ({@code "заказчики_в_рейтинге"} — regex)
     * @param registry реестр документов
     * @param criteria критерии Шага 1
     * @return строки (карты полей)
     */
    static List<Map<String, Object>> build(Map<String, Object> op, Map<String, Object> registry,
                                           Form3Ops.Criteria criteria) {
        return build(op, registry, criteria, "", "");
    }

    /**
     * Строки формы по реестру с подсказками из исходной формы участника.
     *
     * @param formLines строки исходной формы (ячейки через «|»), может быть пустой
     */
    static List<Map<String, Object>> build(Map<String, Object> op, Map<String, Object> registry,
                                           Form3Ops.Criteria criteria, String formLines) {
        return build(op, registry, criteria, formLines, "");
    }

    /**
     * Строки заключения. С шапкой формы форма первична: каждая строка формы
     * участника получает вердикт — по найденному УПД (по номеру, иначе по сумме
     * и дате акта), а без документов в комплекте — по данным самой формы;
     * УПД комплекта, не заявленные в форме, в заключение не попадают. Без
     * шапки строки строятся по УПД реестра.
     *
     * @param headerLine строка-шапка исходной формы, может быть пустой
     */
    static List<Map<String, Object>> build(Map<String, Object> op, Map<String, Object> registry,
                                           Form3Ops.Criteria criteria, String formLines, String headerLine) {
        Registry docs = Registry.of(registry);
        // встроенный перечень длиннее предела пользовательского шаблона — он статический, через SafeRegex идёт только override
        Object ratingRaw = op.get("заказчики_в_рейтинге");
        Pattern rating = ratingRaw == null ? DEFAULT_RATING_PATTERN
                : SafeRegex.compile(String.valueOf(ratingRaw), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "заказчики_в_рейтинге");
        List<Map<String, Object>> rows = new ArrayList<>();
        Form3Form form = Form3Form.parse(headerLine);
        if (form == null) {
            for (Map<String, Object> upd : docs.upds()) {
                rows.add(row(link(upd, docs, formSpecHints(upd, formLines)), criteria, rating));
            }
            return rows;
        }
        Set<Map<String, Object>> used = Collections.newSetFromMap(new IdentityHashMap<>());
        List<Form3Form.Row> lines = form.rows(formLines);
        Map<Form3Form.Row, Map<String, Object>> matched = new IdentityHashMap<>();
        // первый проход — точные совпадения (номер УПД, дата акта), второй — запасные (сумма и дата, номер и сумма):
        // иначе запасной ход одной строки забирает документ, точно принадлежащий другой
        for (boolean fallback : new boolean[]{false, true}) {
            for (Form3Form.Row line : lines) {
                if (matched.containsKey(line)) {
                    continue;
                }
                Map<String, Object> upd = findUpd(line, docs.upds(), used, fallback);
                Map<String, Object> act = upd == null ? findAct(line, docs.acts(), used, fallback) : null;
                if (upd != null) {
                    matched.put(line, withFormDate(upd, line));
                } else if (act != null || fallback) {
                    matched.put(line, pseudoUpd(line, act));
                }
            }
        }
        for (Form3Form.Row line : lines) {
            Map<String, Object> upd = matched.get(line);
            Map<String, Object> row = row(link(upd, docs, formSpecHints(upd, line.line())), criteria, rating);
            row.put(SOURCE_LINE, line.line());
            rows.add(row);
        }
        return rows;
    }

    /** Реестр документов по типам. */
    private record Registry(List<Map<String, Object>> upds, List<Map<String, Object>> specs,
                            List<Map<String, Object>> contracts, List<Map<String, Object>> reports,
                            List<Map<String, Object>> acts) {
        @SuppressWarnings("unchecked")
        static Registry of(Map<String, Object> registry) {
            return new Registry((List<Map<String, Object>>) registry.getOrDefault("упд", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("спецификации", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("договоры", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("отчёты", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("акты", List.of()));
        }
    }

    /** Документы строки УПД: спецификации (с учётом подсказки формы), договор, отчёты. */
    private static Linked link(Map<String, Object> upd, Registry docs, Set<String> hint) {
        List<Map<String, Object>> candidates = matchSpecs(upd, docs.specs());
        String specNote = "";
        if (!hint.isEmpty()) {
            List<Map<String, Object>> narrowed = withNumbers(candidates, hint);
            if (!narrowed.isEmpty()) {
                specNote = candidates.size() > 1 ? "спецификация выбрана по форме участника" : "";
                candidates = narrowed;
            } else if (candidates.isEmpty()) {
                candidates = withNumbers(dedupByNumber(docs.specs()), hint);
                specNote = candidates.isEmpty() ? "" : "спецификация взята из формы участника (по сумме не сошлась)";
            }
        }
        return new Linked(upd, candidates, matchContracts(upd, docs.contracts()),
                matchReports(upd, candidates, docs.reports()), specNote);
    }

    /**
     * УПД строки формы: по номеру УПД в реквизитах акта, иначе по сумме и
     * дате акта (участники пишут в форме номер заказа вместо номера УПД или
     * повторяют номер соседней строки). Каждый УПД используется один раз.
     */
    private static Map<String, Object> findUpd(Form3Form.Row line, List<Map<String, Object>> upds,
                                               Set<Map<String, Object>> used, boolean fallback) {
        Set<String> numbers = Form3Form.numbers(Form3Form.UPD_NUMBER, line.act());
        for (Map<String, Object> upd : upds) {
            if (!used.contains(upd) && numbers.contains(str(upd.get("номер")).replaceFirst("^0+", ""))) {
                used.add(upd);
                return upd;
            }
        }
        if (!fallback || line.amount().isEmpty() || line.dates().isEmpty()) {
            return null;
        }
        for (Map<String, Object> upd : upds) {
            boolean sameDate = line.dates().contains(str(upd.get("дата")))
                    || line.dates().contains(str(upd.get("дата_приёмки")));
            if (!used.contains(upd) && sameDate && line.amount().equals(str(upd.get("сумма")))) {
                used.add(upd);
                return upd;
            }
        }
        return null;
    }

    /**
     * Акт сдачи-приёмки строки формы: по дате акта из формы; при нескольких
     * актах на дату — по номеру спецификации/заявки строки, затем по сумме.
     * Без совпадения даты — по номеру спецификации/заявки и сумме.
     */
    private static Map<String, Object> findAct(Form3Form.Row line, List<Map<String, Object>> acts,
                                               Set<Map<String, Object>> used, boolean fallback) {
        String number = specNumber(line.spec());
        List<Map<String, Object>> byDate = new ArrayList<>();
        for (Map<String, Object> act : acts) {
            if (!used.contains(act) && line.dates().contains(str(act.get("дата")))) {
                byDate.add(act);
            }
        }
        Map<String, Object> found = pick(byDate, number, line.amount());
        if (found == null && fallback && !number.isEmpty() && !line.amount().isEmpty()) {
            for (Map<String, Object> act : acts) {
                if (!used.contains(act) && sameNumber(act, number) && amountFits(act, line.amount())) {
                    found = act;
                    break;
                }
            }
        }
        if (found != null) {
            used.add(found);
        }
        return found;
    }

    private static Map<String, Object> pick(List<Map<String, Object>> candidates, String number, String amount) {
        if (candidates.size() <= 1) {
            return candidates.isEmpty() ? null : candidates.get(0);
        }
        for (Map<String, Object> act : candidates) {
            if (!number.isEmpty() && sameNumber(act, number)) {
                return act;
            }
        }
        for (Map<String, Object> act : candidates) {
            if (amountFits(act, amount)) {
                return act;
            }
        }
        return candidates.get(0);
    }

    private static boolean sameNumber(Map<String, Object> act, String number) {
        return number.equals(str(act.get("спецификация"))) || number.equals(str(act.get("заявка")));
    }

    @SuppressWarnings("unchecked")
    private static boolean amountFits(Map<String, Object> act, String amount) {
        return !amount.isEmpty() && (amount.equals(str(act.get("сумма")))
                || ((List<String>) act.getOrDefault("суммы", List.of())).contains(amount));
    }

    /** Номер спецификации (6–8 цифр) либо заявки («Заявка 104») из реквизитов формы. */
    static String specNumber(String spec) {
        Matcher m = SPEC_NUMBER.matcher(spec);
        if (m.find()) {
            return m.group(1);
        }
        return Form3Ops.firstGroup(Form3Acts.ORDER_REF, spec);
    }

    /**
     * УПД строки с датой, заявленной в форме: если дата формы совпадает с датой УПД
     * либо датой приёмки, она и считается датой акта (Егорова судит период по дате,
     * названной участником: «УПД 138 от 24.03.2025» — по 24.03, хотя приёмка позже).
     */
    private static Map<String, Object> withFormDate(Map<String, Object> upd, Form3Form.Row line) {
        Map<String, Object> copy = new LinkedHashMap<>(upd);
        copy.put("заявлено", line.claimedTechs());
        copy.put("колонки_технологий", line.techHeaders());
        String formDate = line.actDate();
        if (!formDate.isEmpty() && (formDate.equals(str(upd.get("дата"))) || formDate.equals(str(upd.get("дата_приёмки"))))) {
            copy.put("дата_по_форме", formDate);
        }
        // покупатель в УПД не разобран (иная печатная форма) — заказчик берётся из формы участника
        if (str(upd.get("покупатель")).isEmpty()) {
            copy.put("покупатель", line.customer());
        }
        if (str(upd.get("продавец")).isEmpty()) {
            copy.put("продавец", line.executor().isEmpty() ? line.company() : line.executor());
        }
        // участник засчитывает часть УПД (только профильные позиции): заявленная сумма меньше итога — берётся она
        String total = str(upd.get("сумма"));
        if (!line.amount().isEmpty() && !total.isEmpty() && !line.amount().equals(total) && less(line.amount(), total)) {
            copy.put("сумма", line.amount());
            copy.put("сумма_примечание", "сумма по форме участника " + line.amount() + " (итог УПД " + total + ")");
        }
        return copy;
    }

    private static boolean less(String a, String b) {
        try {
            return Double.parseDouble(a) < Double.parseDouble(b);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Запись строки формы без УПД в виде УПД-карты: реквизиты акта (если найден)
     * и формы участника; {@code "вид"} = «акт» либо «форма» (документов акта нет).
     */
    private static Map<String, Object> pseudoUpd(Form3Form.Row line, Map<String, Object> act) {
        Map<String, Object> upd = new LinkedHashMap<>();
        boolean hasAct = act != null;
        String order = hasAct ? str(act.get("заявка")) : "";
        upd.put("файл", hasAct ? str(act.get("файл")) : "");
        upd.put("вид", hasAct ? Form3Acts.KIND_ACT : "форма");
        String date = hasAct && !str(act.get("дата")).isEmpty() ? str(act.get("дата")) : line.actDate();
        upd.put("номер", hasAct ? "от " + date + (order.isEmpty() ? "" : " (заявка " + order + ")") : "");
        upd.put("метка", hasAct ? "Акт " + upd.get("номер") : line.act());
        upd.put("дата", date);
        upd.put("дата_приёмки", date);
        // стороны — из формы участника (первична), из акта — только если в форме пусто
        String seller = line.executor().isEmpty() ? line.company() : line.executor();
        String buyer = line.customer();
        upd.put("продавец", seller.isEmpty() && hasAct ? str(act.get("продавец")) : seller);
        upd.put("покупатель", buyer.isEmpty() && hasAct ? str(act.get("покупатель")) : buyer);
        upd.put("договор", contractNumber(line.contract()));
        upd.put("договор_дата", Form3Form.actDate(line.contract(), ""));
        // сумма формы, если она встречается в акте; распознанный скан суммам не судья — берётся сумма
        // формы с пометкой; для текстового акта без суммы формы — сумма акта с пометкой
        boolean scanned = hasAct && str(act.get("текст")).startsWith("[РАСПОЗНАНО") || hasAct && Boolean.TRUE.equals(act.get("скан"));
        boolean fits = hasAct && amountFits(act, line.amount());
        String amount = hasAct && !fits && !scanned && !str(act.get("сумма")).isEmpty() ? str(act.get("сумма")) : line.amount();
        upd.put("сумма", amount.isEmpty() && hasAct ? str(act.get("сумма")) : amount);
        String note = "";
        if (hasAct && !fits && !line.amount().isEmpty()) {
            note = scanned ? "сумма взята из формы участника (в распознанном скане акта не найдена"
                    + (str(act.get("сумма")).isEmpty() ? ")" : ", скан даёт " + act.get("сумма") + ")")
                    : "сумма формы " + line.amount() + " в акте не найдена, взята сумма акта";
        }
        upd.put("сумма_примечание", note);
        upd.put("подпись_заказчика", hasAct);
        upd.put("подпись_примечание", hasAct ? str(act.get("подпись_примечание")) : "");
        upd.put("спецификация", specNumber(line.spec()));
        upd.put("заказы", order.isEmpty() ? List.of() : List.of(order));
        upd.put("заявлено", line.claimedTechs());
        upd.put("колонки_технологий", line.techHeaders());
        upd.put("текст", hasAct ? str(act.get("текст")) : "");
        return upd;
    }

    /** Номер договора из реквизитов формы: длинный числовой, иначе буквенно-цифровой после «№». */
    static String contractNumber(String contract) {
        Matcher digits = CONTRACT_DIGITS.matcher(contract);
        if (digits.find()) {
            return digits.group(1);
        }
        return Form3Ops.firstGroup(CONTRACT_ALNUM, contract);
    }

    /**
     * Заказчик вне рейтинга — стоп-фактор (шаблон Егоровой): остальные проверки
     * не выполняются и помечаются прочерком, причина незачёта одна.
     */
    private static Map<String, Object> ratingStop(Map<String, Object> row) {
        if (!NO.equals(row.get("к11"))) {
            return row;
        }
        for (String key : List.of("к8", "к9", "к10", "к12", "к13", "к16", "к17", "к18", "к19")) {
            row.put(key, DASH);
        }
        row.replaceAll((key, value) -> key.startsWith("т_") ? DASH : value);
        row.put("к14", "0");
        row.put("к15", REASON_RATING);
        return row;
    }

    /** Кандидаты-спецификации: по номеру из УПД, иначе того же договора с равной суммой этапа. */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> matchSpecs(Map<String, Object> upd, List<Map<String, Object>> specs) {
        String number = str(upd.get("спецификация"));
        List<Map<String, Object>> byNumber = new ArrayList<>();
        List<Map<String, Object>> bySum = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (Map<String, Object> spec : specs) {
            if (!seen.add(str(spec.get("номер")))) {
                continue;
            }
            if (!number.isEmpty() && number.equals(str(spec.get("номер")))) {
                byNumber.add(spec);
            }
            boolean sameContract = str(spec.get("договор")).isEmpty() || str(upd.get("договор")).isEmpty()
                    || str(spec.get("договор")).equals(str(upd.get("договор")));
            List<String> sums = (List<String>) spec.getOrDefault("суммы", List.of());
            if (sameContract && !str(upd.get("сумма")).isEmpty() && sums.contains(str(upd.get("сумма")))) {
                bySum.add(spec);
            }
        }
        return byNumber.isEmpty() ? bySum : byNumber;
    }

    private static List<Map<String, Object>> matchContracts(Map<String, Object> upd, List<Map<String, Object>> contracts) {
        List<Map<String, Object>> matched = new ArrayList<>();
        String number = str(upd.get("договор"));
        for (Map<String, Object> contract : contracts) {
            if (!number.isEmpty() && number.equals(str(contract.get("номер")))) {
                matched.add(contract);
            }
        }
        return matched;
    }

    /**
     * Отчёты строки: по номеру спецификации-кандидата, по номеру УПД, по общему
     * номеру заказа (ЗНЗО/заказ/заявка) с УПД или по сумме УПД.
     */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> matchReports(Map<String, Object> upd, List<Map<String, Object>> specs,
                                                          List<Map<String, Object>> reports) {
        Set<String> specNumbers = new LinkedHashSet<>();
        for (Map<String, Object> spec : specs) {
            specNumbers.add(str(spec.get("номер")));
        }
        String updNumber = str(upd.get("номер")).replaceFirst("^0+", "");
        List<String> updOrders = (List<String>) upd.getOrDefault("заказы", List.of());
        List<Map<String, Object>> matched = new ArrayList<>();
        for (Map<String, Object> report : reports) {
            boolean bySpec = !str(report.get("спецификация")).isEmpty() && specNumbers.contains(str(report.get("спецификация")));
            boolean byUpd = !updNumber.isEmpty() && str(report.get("упд")).replaceFirst("^0+", "").equals(updNumber);
            List<String> orders = (List<String>) report.getOrDefault("заказы", List.of());
            boolean byNumber = orders.stream().anyMatch(updOrders::contains);
            List<String> sums = (List<String>) report.getOrDefault("суммы", List.of());
            // по сумме — только если отчёт не относится к другой спецификации: у нескольких УПД одного
            // договора суммы этапов совпадают, и отчёт чужой спецификации приносил чужие технологии
            String reportSpec = str(report.get("спецификация"));
            boolean foreignSpec = !reportSpec.isEmpty() && !specNumbers.isEmpty() && !specNumbers.contains(reportSpec);
            boolean bySum = !foreignSpec && !str(upd.get("сумма")).isEmpty() && sums.contains(str(upd.get("сумма")));
            if (bySpec || byUpd || byNumber || bySum) {
                matched.add(report);
            }
        }
        return matched;
    }

    private static Map<String, Object> row(Linked linked, Form3Ops.Criteria criteria, Pattern rating) {
        Map<String, Object> upd = linked.upd();
        Map<String, Object> row = new LinkedHashMap<>();
        String seller = str(upd.get("продавец"));
        String buyer = str(upd.get("покупатель"));
        row.put("к1", seller);
        row.put("к2", seller);
        row.put("к3", buyer);
        row.put("к4", contractLabel(upd));
        row.put("к5", specLabel(linked.specs()));
        row.put("к6", str(upd.get("метка")).isEmpty() ? "УПД " + upd.get("номер") + " от " + upd.get("дата") : str(upd.get("метка")));
        String actDate = str(upd.get("дата_по_форме"));
        if (actDate.isEmpty()) {
            actDate = str(upd.get("дата_приёмки")).isEmpty() ? str(upd.get("дата")) : str(upd.get("дата_приёмки"));
        }
        row.put("к7", actDate);
        String qual = criteria.qualFrom == null ? DASH : periodVerdict(actDate, criteria.qualFrom, criteria.qualTo);
        String method = periodVerdict(actDate, criteria.methodFrom, criteria.methodTo);
        row.put("к8", qual);
        row.put("к9", method);
        row.put("к10", str(upd.get("сумма")));
        boolean inRating = SafeRegex.find(rating, buyer);
        row.put("к11", inRating ? YES : NO);
        String mobile = mobileVerdict(linked, criteria);
        row.put("к12", mobile);
        String testing = testingOnlyVerdict(linked);
        row.put("к13", testing);
        Map<String, Set<String>> techPlaces = technologyPlaces(linked, criteria.allTechnologies());
        Map<String, Set<String>> proven = proven(withoutContractWhenSpecNamesRoles(techPlaces, linked), evidence(upd));
        List<String> reasons = reasons(linked, criteria, inRating, method, mobile, testing, proven);
        List<String> notClaimed = notClaimed(upd, criteria);
        row.put("к14", reasons.isEmpty() ? str(upd.get("сумма")) : "0");
        row.put("к15", reasons.isEmpty() ? DASH : String.join("; ", reasons));
        for (Map.Entry<String, Set<String>> tech : proven.entrySet()) {
            // технология засчитывается, только если участник заявил её в форме (разметка Егоровой, Комплект 1)
            row.put("т_" + tech.getKey(), tech.getValue().isEmpty() || notClaimed.contains(tech.getKey()) ? NO : YES);
        }
        row.put("к16", placeLabel(techPlaces, "договор"));
        row.put("к17", placeLabel(techPlaces, "спецификация"));
        row.put("к18", placeLabel(techPlaces, "акт"));
        row.put("к19", placeLabel(techPlaces, "отчёт"));
        row.put("к20", audit(linked, criteria, techPlaces, qual, method, buyer, mobile));
        row.put(CONTRACTS, String.valueOf(linked.contracts().size()));
        row.put("к20", str(row.get("к20")) + roleNote(techPlaces, linked));
        // строки для второго мнения агента: причина незачёта либо слабое доказательство мобильной разработки
        row.put("агенту", !reasons.isEmpty() || weakMobile(linked, mobile) ? YES : "");
        return ratingStop(row);
    }

    /**
     * Доказательные документы строки: договор, спецификация/заявка, акт (УПД) и
     * отчёт — как в разметке Егоровой (Комплект 1: Hadoop засчитан по договору,
     * «стр 32»; Комплект 6: Java/Python по договору и спецификации). Договор
     * рамочный тоже считается: методолог сверяет по нему.
     */
    private static Set<String> evidence(Map<String, Object> upd) {
        return Set.of("договор", "спецификация", "акт", "отчёт");
    }

    /** Места нахождения технологий, ограниченные доказательными документами. */
    private static Map<String, Set<String>> proven(Map<String, Set<String>> techPlaces, Set<String> evidence) {
        Map<String, Set<String>> proven = new LinkedHashMap<>();
        for (Map.Entry<String, Set<String>> e : techPlaces.entrySet()) {
            Set<String> places = new LinkedHashSet<>(e.getValue());
            places.retainAll(evidence);
            proven.put(e.getKey(), places);
        }
        return proven;
    }

    /** Причины незачёта в формулировках шаблона; пустой список — сумма зачитывается. */
    private static List<String> reasons(Linked linked, Form3Ops.Criteria criteria, boolean inRating, String method,
                                        String mobile, String testing, Map<String, Set<String>> techPlaces) {
        List<String> reasons = new ArrayList<>();
        boolean formOnly = "форма".equals(linked.upd().get("вид"));
        // акт/УПД не найден: строка засчитывается по спецификации, подтверждающей сумму этапа (разметка Егоровой,
        // Комплекты 1 и 6), иначе — «Подтверждающие документы не найдены»
        if (formOnly && !specConfirmsAmount(linked)) {
            reasons.add(REASON_NO_DOCS);
        } else if (!formOnly && !Boolean.TRUE.equals(linked.upd().get("подпись_заказчика"))) {
            reasons.add("акт не подписан заказчиком");
        }
        if (!inRating) {
            reasons.add(REASON_RATING);
        }
        if (NO.equals(method)) {
            reasons.add(REASON_PERIOD);
        }
        if (!criteria.allTechnologies().isEmpty() && techPlaces.values().stream().allMatch(Set::isEmpty)) {
            reasons.add("технология не найдена");
        }
        if (YES.equals(mobile) && !criteria.mobileProcurement) {
            reasons.add("мобильная разработка");
        }
        if (NO.equals(mobile) && criteria.mobileProcurement) {
            reasons.add("нет мобильной разработки");
        }
        if (YES.equals(testing)) {
            reasons.add("только услуги по тестированию");
        }
        return reasons;
    }

    /**
     * Без договора опыт не засчитывается (письмо Егоровой, Комплект 8 «без договора»: в комплекте только спецификации
     * и акты — все строки «Подтверждающие документы не найдены»). Включается параметром операции
     * {@code "без_договора_не_засчитывать": "true"}: строка, для которой договор не найден среди документов комплекта
     * (поле {@link #CONTRACTS}), получает сумму зачтено «0» и причину {@link #REASON_NO_DOCS} первой.
     *
     * @param op   конфиг операции
     * @param rows строки заключения (изменяются на месте)
     * @return число строк, не засчитанных из-за отсутствия договора
     */
    static int denyWithoutContract(Map<String, Object> op, List<Map<String, Object>> rows) {
        if (!"true".equalsIgnoreCase(String.valueOf(op.getOrDefault("без_договора_не_засчитывать", "false")))) {
            return 0;
        }
        int denied = 0;
        for (Map<String, Object> row : rows) {
            if (!"0".equals(str(row.get(CONTRACTS)))) {
                continue;
            }
            String reasons = str(row.get("к15"));
            if (!reasons.contains(REASON_NO_DOCS)) {
                row.put("к15", DASH.equals(reasons) || reasons.isEmpty() ? REASON_NO_DOCS : REASON_NO_DOCS + "; " + reasons);
            }
            row.put("к14", "0");
            row.put("агенту", YES);
            denied++;
        }
        return denied;
    }

    /** Спецификация строки подтверждает сумму этапа (акт/УПД не найден, но сумма есть в спецификации). */
    private static boolean specConfirmsAmount(Linked linked) {
        String amount = str(linked.upd().get("сумма"));
        return !amount.isEmpty() && linked.specs().stream().anyMatch(spec -> amountFits(spec, amount));
    }

    /** Технологии критериев, для которых в форме есть колонка, но участник не поставил «да». */
    @SuppressWarnings("unchecked")
    private static List<String> notClaimed(Map<String, Object> upd, Form3Ops.Criteria criteria) {
        List<String> headers = (List<String>) upd.getOrDefault("колонки_технологий", List.of());
        List<String> claimed = (List<String>) upd.getOrDefault("заявлено", List.of());
        List<String> out = new ArrayList<>();
        for (String tech : criteria.allTechnologies()) {
            boolean hasColumn = headers.stream().anyMatch(h -> Form3Ops.containsTechnology(h, tech));
            boolean claimedInForm = claimed.stream().anyMatch(h -> Form3Ops.containsTechnology(h, tech));
            if (hasColumn && !claimedInForm) {
                out.add(tech);
            }
        }
        return out;
    }

    /** В форме есть колонки платформ из критериев (iOS/Android/…), и участник не заявил ни одну. */
    private static boolean platformsNotClaimed(Map<String, Object> upd, Form3Ops.Criteria criteria) {
        List<String> platforms = criteria.allTechnologies().stream()
                .filter(t -> PLATFORM.matcher(t).matches()).toList();
        if (platforms.isEmpty()) {
            return false;
        }
        return notClaimed(upd, criteria).containsAll(platforms);
    }

    /** Мобильная разработка доказана лишь упоминанием платформы (iOS/Android) без слов о мобильном приложении. */
    private static boolean weakMobile(Linked linked, String mobile) {
        if (!YES.equals(mobile)) {
            return false;
        }
        List<Map<String, Object>> docs = new ArrayList<>(linked.specs());
        docs.addAll(linked.reports());
        docs.add(linked.upd());
        return docs.stream().noneMatch(doc -> MOBILE_WORDS.matcher(str(doc.get("текст"))).find());
    }

    /** Где найдена каждая технология критериев: договор / спецификация / акт / отчёт. */
    private static Map<String, Set<String>> technologyPlaces(Linked linked, List<String> required) {
        Map<String, Set<String>> places = new LinkedHashMap<>();
        for (String tech : required) {
            Set<String> found = new LinkedHashSet<>();
            if (anyContains(linked.contracts(), tech)) {
                found.add("договор");
            }
            if (anyContains(linked.specs(), tech)) {
                found.add("спецификация");
            }
            if (Form3Ops.containsTechnology(str(linked.upd().get("текст")), tech)) {
                found.add("акт");
            }
            if (anyContains(linked.reports(), tech)) {
                found.add("отчёт");
            }
            places.put(tech, found);
        }
        return places;
    }

    /**
     * Технологии договора не доказывают технологию строки, если спецификация сама называет роли исполнителей с технологиями
     * («Главный разработчик GreenPlum»): рамочный договор перечисляет ставки всех ролей, а работы заказа — только названные
     * в спецификации (Комплект 9 Егоровой: Python есть только в ставках договора 5028839, спецификация 5491012 называет
     * GreenPlum — «Технологии не найдены»). Спецификация без ролей (Комплект 1, 5285195) договор не отменяет.
     *
     * @param techPlaces места технологий строки
     * @param linked     документы строки
     * @return места технологий для доказательства (копия без «договор», если спецификация называет роли)
     */
    private static Map<String, Set<String>> withoutContractWhenSpecNamesRoles(Map<String, Set<String>> techPlaces, Linked linked) {
        if (specRoleTechnologies(linked).isEmpty()) {
            return techPlaces;
        }
        Map<String, Set<String>> filtered = new LinkedHashMap<>();
        for (Map.Entry<String, Set<String>> e : techPlaces.entrySet()) {
            Set<String> places = new LinkedHashSet<>(e.getValue());
            places.remove("договор");
            filtered.put(e.getKey(), places);
        }
        return filtered;
    }

    /** Технологии из ролей исполнителей в спецификациях строки («разработчик GreenPlum» → GreenPlum). */
    private static Set<String> specRoleTechnologies(Linked linked) {
        Set<String> techs = new LinkedHashSet<>();
        for (Map<String, Object> spec : linked.specs()) {
            Matcher m = ROLE_TECH.matcher(str(spec.get("текст")));
            while (m.find()) {
                techs.add(m.group(1));
            }
        }
        return techs;
    }

    /** Пояснение аудита: технология найдена только в договоре, а спецификация называет другие роли. */
    private static String roleNote(Map<String, Set<String>> techPlaces, Linked linked) {
        Set<String> roles = specRoleTechnologies(linked);
        boolean contractOnly = techPlaces.values().stream().anyMatch(p -> p.size() == 1 && p.contains("договор"));
        return roles.isEmpty() || !contractOnly ? ""
                : "; технологии только из договора не засчитываются: спецификация называет роли исполнителей (" + String.join(", ", roles) + ")";
    }

    private static boolean anyContains(List<Map<String, Object>> docs, String tech) {
        for (Map<String, Object> doc : docs) {
            if (Form3Ops.containsTechnology(str(doc.get("текст")), tech)) {
                return true;
            }
        }
        return false;
    }

    /** «да: Java, Python» — технологии, подтверждённые в документах этого типа, иначе «нет». */
    private static String placeLabel(Map<String, Set<String>> techPlaces, String place) {
        List<String> techs = new ArrayList<>();
        for (Map.Entry<String, Set<String>> e : techPlaces.entrySet()) {
            if (e.getValue().contains(place)) {
                techs.add(e.getKey());
            }
        }
        return techs.isEmpty() ? NO : YES + ": " + String.join(", ", techs);
    }

    /**
     * Мобильная разработка по текстам спецификаций/заявок, отчётов и акта/УПД строки (договор не смотрим — он рамочный);
     * если в форме есть колонки платформ (iOS/Android) и участник ни одну не заявил — «нет» (разметка Егоровой, Комплект 3).
     */
    private static String mobileVerdict(Linked linked, Form3Ops.Criteria criteria) {
        if (platformsNotClaimed(linked.upd(), criteria)) {
            return NO;
        }
        List<Map<String, Object>> docs = new ArrayList<>(linked.specs());
        docs.addAll(linked.reports());
        docs.add(linked.upd());
        for (Map<String, Object> doc : docs) {
            if (MOBILE.matcher(str(doc.get("текст"))).find()) {
                return YES;
            }
        }
        return NO;
    }

    /**
     * Только тестирование: в предмете спецификации (или отчёта, если спецификации
     * нет) есть тестирование и нет разработки/модификации/внедрения.
     */
    private static String testingOnlyVerdict(Linked linked) {
        List<Map<String, Object>> docs = linked.specs().isEmpty() ? linked.reports() : linked.specs();
        if (docs.isEmpty()) {
            return NO_DATA;
        }
        boolean testingOnly = true;
        for (Map<String, Object> doc : docs) {
            String subject = subject(str(doc.get("текст")));
            if (!TESTING.matcher(subject).find() || DEVELOPMENT.matcher(subject).find()) {
                testingOnly = false;
            }
        }
        return testingOnly ? YES : NO;
    }

    /** Предмет документа: фраза после «Предмет …:», иначе начало текста. */
    private static String subject(String text) {
        Matcher m = SUBJECT.matcher(text);
        if (m.find()) {
            return m.group(1);
        }
        return text.length() > SUBJECT_LIMIT ? text.substring(0, SUBJECT_LIMIT) : text;
    }

    private static String contractLabel(Map<String, Object> upd) {
        String number = str(upd.get("договор"));
        if (number.isEmpty()) {
            return NO_DATA;
        }
        String date = str(upd.get("договор_дата"));
        return "договор " + number + (date.isEmpty() ? "" : " от " + date);
    }

    private static String specLabel(List<Map<String, Object>> candidates) {
        if (candidates.isEmpty()) {
            return "не сопоставлена";
        }
        List<String> labels = new ArrayList<>();
        for (Map<String, Object> spec : candidates) {
            String date = str(spec.get("дата"));
            String kind = Form3Acts.KIND_ORDER.equals(spec.get("вид")) ? "заявка " : "";
            labels.add(kind + spec.get("номер") + (date.isEmpty() ? "" : " от " + date));
        }
        String joined = String.join(" или ", labels);
        return candidates.size() == 1 ? joined
                : joined + " (сумма этапа совпадает в нескольких спецификациях — выбрать по форме)";
    }

    /** «да»/«нет» по дате акта внутри периода; без дат в критериях — «проверить вручную». */
    static String periodVerdict(String actDate, LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            return MANUAL;
        }
        LocalDate act = Form3Ops.parseDate(actDate);
        if (act == null) {
            return MANUAL;
        }
        return !act.isBefore(from) && !act.isAfter(to) ? YES : NO;
    }

    private static String audit(Linked linked, Form3Ops.Criteria criteria, Map<String, Set<String>> techPlaces,
                                String qual, String method, String buyer, String mobile) {
        List<String> parts = new ArrayList<>();
        parts.add("период квалификации: " + periodNote(qual, criteria.qualFrom, criteria.qualTo));
        parts.add("период методики: " + periodNote(method, criteria.methodFrom, criteria.methodTo));
        for (Map.Entry<String, List<String>> lot : criteria.lots.entrySet()) {
            List<String> hit = new ArrayList<>();
            List<String> miss = new ArrayList<>();
            for (String tech : lot.getValue()) {
                Set<String> places = techPlaces.getOrDefault(tech, Set.of());
                (places.isEmpty() ? miss : hit).add(places.isEmpty() ? tech : tech + " (" + String.join(", ", places) + ")");
            }
            parts.add("лот " + lot.getKey() + ": " + (hit.isEmpty() ? "ничего не найдено" : "найдено " + String.join(", ", hit))
                    + (miss.isEmpty() ? "" : "; не найдено " + String.join(", ", miss)));
        }
        parts.add("заказчик: " + buyer);
        parts.add("технологии — по договору, спецификации/заявке, акту и отчёту; мобильная разработка — по спецификации/заявке, акту и отчёту");
        parts.add("документы строки: " + actNote(linked.upd()) + "договор " + linked.contracts().size() + ", спецификаций "
                + linked.specs().size() + ", отчётов " + linked.reports().size());
        for (String note : List.of("подпись_примечание", "сумма_примечание")) {
            if (!str(linked.upd().get(note)).isEmpty()) {
                parts.add(str(linked.upd().get(note)));
            }
        }
        List<String> claimed = claimed(linked.upd(), criteria, techPlaces);
        if (!claimed.isEmpty()) {
            parts.add("заявлено участником в форме, документами не подтверждено: " + String.join(", ", claimed));
        }
        parts.addAll(extraNotes(linked, criteria, mobile));
        if (linked.specs().size() > 1) {
            parts.add("спецификация: несколько кандидатов по сумме этапа");
        }
        if (!linked.specNote().isEmpty()) {
            parts.add(linked.specNote());
        }
        if (criteria.mobileProcurement) {
            parts.add("закупка мобильной разработки: мобильная разработка не стоп-фактор");
        }
        return String.join("; ", parts);
    }

    /** Пометки аудита v6.4: не заявленные в форме технологии, зачёт по спецификации без акта, слабая мобильность. */
    private static List<String> extraNotes(Linked linked, Form3Ops.Criteria criteria, String mobile) {
        List<String> notes = new ArrayList<>();
        List<String> notClaimed = notClaimed(linked.upd(), criteria);
        if (!notClaimed.isEmpty()) {
            notes.add("по форме участника не заявлено, не засчитывается: " + String.join(", ", notClaimed));
        }
        if ("форма".equals(linked.upd().get("вид")) && specConfirmsAmount(linked)) {
            notes.add("акт/УПД не найден, сумма этапа подтверждена спецификацией");
        }
        if (platformsNotClaimed(linked.upd(), criteria)) {
            notes.add("мобильная разработка по форме не заявлена (платформы «нет») — не засчитывается");
        }
        if (weakMobile(linked, mobile)) {
            notes.add("мобильная разработка — только по упоминанию платформы (iOS/Android), без слов о мобильном приложении: на проверку агенту");
        }
        return notes;
    }

    private static String actNote(Map<String, Object> upd) {
        String kind = str(upd.get("вид"));
        if ("форма".equals(kind)) {
            return "акт/УПД по номеру, сумме и дате не найден; ";
        }
        return Form3Acts.KIND_ACT.equals(kind) ? "акт «" + upd.get("файл") + "», " : "";
    }

    /** Технологии, отмеченные участником «да» в форме, но не найденные в документах строки. */
    @SuppressWarnings("unchecked")
    private static List<String> claimed(Map<String, Object> upd, Form3Ops.Criteria criteria,
                                        Map<String, Set<String>> techPlaces) {
        List<String> claimed = new ArrayList<>();
        List<String> headers = (List<String>) upd.getOrDefault("заявлено", List.of());
        for (String tech : criteria.allTechnologies()) {
            boolean claimedInForm = headers.stream().anyMatch(h -> Form3Ops.containsTechnology(h, tech));
            if (claimedInForm && techPlaces.getOrDefault(tech, Set.of()).isEmpty()) {
                claimed.add(tech);
            }
        }
        return claimed;
    }

    private static String periodNote(String verdict, LocalDate from, LocalDate to) {
        if (DASH.equals(verdict)) {
            return "квалификационные требования к периоду не предъявляются (в критериях нет дат)";
        }
        if (MANUAL.equals(verdict)) {
            return "проверить вручную (в критериях нет дат периода)";
        }
        return verdict + " (с " + from.format(Form3Ops.DATE) + " по " + to.format(Form3Ops.DATE) + ")";
    }
}
