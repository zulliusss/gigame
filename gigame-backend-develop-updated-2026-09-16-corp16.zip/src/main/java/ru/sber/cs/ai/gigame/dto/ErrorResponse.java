package ru.sber.cs.ai.gigame.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import ru.sber.cs.ai.gigame.exception.ApplicationRuntimeException;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.Map;

/**
 * Структура ответа с информацией об ошибке.
 */
@AllArgsConstructor
@Getter
@Builder
@Schema(
        name = "ErrorResponse",
        description = "Стандартизированный формат ответа при возникновении ошибки в API.",
        example = """
                {
                  "statusCode": 400,
                  "error": "Bad Request",
                  "message": "Invalid input data",
                  "timestamp": "2025-04-05T10:00:00Z",
                  "details": {
                    "field": "title",
                    "reason": "must not be null or blank"
                  }
                }
                """,
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public class ErrorResponse {

    @Schema(
            description = "HTTP статус код ошибки",
            example = "400",
            minimum = "400",
            maximum = "599"
    )
    private int statusCode;

    @Schema(
            description = "Имя типа ошибки по HTTP статусу",
            example = "Bad Request",
            allowableValues = {"Bad Request", "Forbidden", "Not Found", "Conflict", "Unprocessable Entity", "Internal Server Error", "Service Unavailable"}
    )
    private String error;

    @Schema(
            description = "Человеко-читаемое сообщение об ошибке",
            pattern = "^[\\w\\W]{0,255}$",
            example = "Title must not be null or empty"
    )
    private String message;

    @Schema(
            description = "Время возникновения ошибки в формате ISO 8601",
            example = "2025-04-05T10:00:00Z",
            type = "string",
            format = "date-time"
    )
    private OffsetDateTime timestamp;

    @Schema(
            description = "Дополнительные детали об ошибке (например, поле, причина)",
            additionalProperties = Schema.AdditionalPropertiesValue.FALSE,
            pattern = "^[\\w\\W]{0,255}$",
            example = """
                    {
                      "field": "knowledgeBaseId",
                      "reason": "must match pattern '^[A-Z0-9]{8}$'"
                    }
                    """
    )
    private Map<String, String> details;

    public static ErrorResponseBuilder builder() {
        return new ErrorResponseBuilder();
    }

    /**
     * Создаёт ответ об ошибке из прикладного исключения. Время — в UTC
     * с точностью до миллисекунд: строка вида {@code 2026-09-15T07:11:12.123Z}
     * укладывается в maxLength 32 спецификации при любом часовом поясе JVM
     * и наносекундных системных часах (Linux).
     *
     * @param ex прикладное исключение со статусом
     * @return ответ об ошибке
     */
    public static ErrorResponse of(ApplicationRuntimeException ex) {
        return builder()
                .statusCode(ex.getStatusCode())
                .error(getErrorName(ex.getStatusCode()))
                .message(ex.getMessage())
                .timestamp(OffsetDateTime.now(ZoneOffset.UTC).truncatedTo(ChronoUnit.MILLIS))
                .build();
    }

    private static String getErrorName(int statusCode) {
        return switch (statusCode) {
            case 400 -> "Bad Request";
            case 403 -> "Forbidden";
            case 404 -> "Not Found";
            case 409 -> "Conflict";
            case 422 -> "Unprocessable Entity";
            case 500 -> "Internal Server Error";
            case 503 -> "Service Unavailable";
            default -> "Unknown Error";
        };
    }
}