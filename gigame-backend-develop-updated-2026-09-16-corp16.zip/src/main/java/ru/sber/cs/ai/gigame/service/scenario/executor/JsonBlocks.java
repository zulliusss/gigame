package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.List;

/**
 * JSON-объекты верхнего уровня, встречающиеся в тексте ответов моделей (в том числе внутри блоков ```json).
 * Разбор — общий ({@link LlmJson}): объект с десятичной запятой («"сумма": 1234567,89») чинится,
 * а не пропускается.
 */
final class JsonBlocks {

    private JsonBlocks() {
    }

    /**
     * Все разбираемые JSON-объекты текста по порядку (непересекающиеся).
     *
     * @param text текст
     * @return объекты
     */
    static List<JsonNode> objects(String text) {
        List<JsonNode> result = new ArrayList<>();
        for (LlmJson.Parsed block : LlmJson.all(text == null ? "" : text, LlmJson.OBJECT).blocks()) {
            result.add(block.node());
        }
        return result;
    }

    /**
     * Объект с заданным значением поля «тип_документа».
     *
     * @param text текст
     * @param type тип документа
     * @return объект либо {@code null}
     */
    static JsonNode byDocumentType(String text, String type) {
        for (JsonNode node : objects(text)) {
            if (type.equalsIgnoreCase(node.path("тип_документа").asText("").strip())) {
                return node;
            }
        }
        return null;
    }
}
