package ru.sber.cs.ai.gigame.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.dto.agent.AgentPlanResponseDto;
import ru.sber.cs.ai.gigame.dto.agent.AgentQuestionResponseDto;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.repository.AgentLessonRepository;
import ru.sber.cs.ai.gigame.repository.AgentPlanRepository;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.scenario.executor.AgentEvidence;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;
import ru.sber.cs.ai.gigame.utils.UserUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

/**
 * Память агента (саморазвитие): уроки, планы, вопросы пользователю.
 * <p>
 * Уроки — правила, выученные из прошлых прогонов; частные (сценария)
 * применяются сразу, общие — после одобрения (защита от отравления памяти).
 * Планы — проверенные чек-листы, переиспользуемые для повторных заданий.
 * Вопросы — асинхронный human-in-the-loop: агент не останавливает прогон,
 * ответ пользователя превращается в урок. Механизмы универсальны — никакой
 * привязки к предметной области сценариев.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AgentMemoryService {

    /** Максимум уроков каждой области, подмешиваемых в промпт агента. */
    static final int LESSONS_LIMIT = 10;
    /** Порог рефлексии-сжатия: больше уроков — предлагается сжатие. */
    static final int COMPRESS_THRESHOLD = 15;
    /**
     * Максимум символов текста вопроса, цитируемого в уроке из ответа
     * пользователя: урок (lesson до 4000 символов по схеме) должен вмещать
     * ответ пользователя (до 4000 символов) по возможности целиком.
     */
    static final int LESSON_QUESTION_QUOTE_LIMIT = 1000;
    /**
     * Длина обрамления урока из ответа: «На вопрос «» (11 символов)
     * и «» пользователь уточнил: » (24 символа).
     */
    static final int LESSON_ANSWER_FRAME_LENGTH = 35;
    /**
     * Минимальный бюджет цитаты вопроса в уроке из ответа: если после ответа
     * пользователя на цитату остаётся меньше этого числа символов, вопрос не
     * цитируется вовсе — обрывок в несколько символов (или пустые кавычки «»)
     * ничего не объясняет, а место нужнее ответу.
     */
    static final int MIN_QUESTION_QUOTE = 50;
    /**
     * maxItems списков уроков, планов и вопросов в ответах (спецификация):
     * страховка, хвост сверх лимита не отдаётся.
     */
    static final int RESPONSE_MAX_ITEMS = 1000;
    /** Начала банальных «уроков», которые ничему не учат, — отсекаются кодом. */
    private static final List<String> GENERIC_LESSON_STARTS = List.of(
            "проверяй", "проверьте", "следите", "следи", "обращайте", "обращай",
            "убедитесь", "убедись", "уточняйте", "уточняй", "обязательно",
            "внимательно", "не забывайте", "не забудьте", "всегда", "тщательно");

    private final AgentLessonRepository lessonRepository;
    private final AgentPlanRepository planRepository;
    private final AgentQuestionRepository questionRepository;
    private final GigaChatClient gigaChatClient;
    private final ScenarioRepository scenarioRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();
    /** Само-прокси для вызова @Transactional-методов через Spring (см. setSelf). */
    private final AtomicReference<AgentMemoryService> self = new AtomicReference<>();

    @Autowired
    public void setSelf(@Lazy AgentMemoryService self) {
        this.self.set(self);
    }

    /**
     * Память сценария — часть сценария: изменять её может только автор
     * (читать — все, у кого есть доступ к сценарию).
     *
     * @param userId     пользователь
     * @param scenarioId сценарий (null — не сценарная память, проверка не нужна)
     * @throws NotFoundException сценарий удалён
     */
    private void checkScenarioAuthor(String userId, UUID scenarioId) {
        log.info("[{}] checkScenarioAuthor, scenarioId={}", userId, scenarioId);
        if (scenarioId == null) {
            return;
        }
        Scenario scenario = scenarioRepository.findById(scenarioId)
                .orElseThrow(() -> new NotFoundException("Сценарий не найден: " + scenarioId));
        UserUtils.checkUserId(userId, scenario.getUserId());
    }

    /**
     * Память сценария читают все, кому доступен сценарий: владелец и, для общего
     * сценария, любой пользователь.
     *
     * @param userId     пользователь
     * @param scenarioId сценарий
     * @throws NotFoundException сценарий удалён
     */
    private void checkScenarioReadable(String userId, UUID scenarioId) {
        log.info("[{}] checkScenarioReadable, scenarioId={}", userId, scenarioId);
        Scenario scenario = scenarioRepository.findById(scenarioId)
                .orElseThrow(() -> new NotFoundException("Сценарий не найден: " + scenarioId));
        if (!Boolean.TRUE.equals(scenario.getShared())) {
            UserUtils.checkUserId(userId, scenario.getUserId());
        }
    }

    /**
     * Право менять урок: системный не меняется никем, сценарный — только автор
     * сценария, личный общий — только его владелец (он подмешивается в промпты
     * владельца, чужая правка отравила бы его память).
     *
     * @param userId пользователь
     * @param lesson урок
     */
    private void checkLessonEditable(String userId, AgentLesson lesson) {
        checkNotSystem(lesson);
        if (lesson.getScenarioId() == null) {
            UserUtils.checkUserId(userId, lesson.getUserId());
            return;
        }
        checkScenarioAuthor(userId, lesson.getScenarioId());
    }

    /** Системный урок поставляется релизом — менять его нельзя никому. */
    private static void checkNotSystem(AgentLesson lesson) {
        if (AgentLesson.SOURCE_SYSTEM.equals(lesson.getSource())) {
            throw new IllegalArgumentException(
                    "Системный урок поставляется релизом и не редактируется");
        }
    }

    // -------------------------------------------------------------------
    // Уроки
    // -------------------------------------------------------------------

    /**
     * Уроки для промпта агентского узла — три слоя:
     * <ol>
     *     <li>СИСТЕМНЫЕ — поставляются релизом, действуют на всех;</li>
     *     <li>ЛИЧНЫЕ ОБЩИЕ запускающего — его кросс-сценарные правила,
     *     действуют только на его запуски;</li>
     *     <li>СЦЕНАРНЫЕ (одобренные) — часть сценария, едут с ним к любому
     *     запускающему.</li>
     * </ol>
     *
     * @param scenarioId   сценарий прогона (null — без сценарного слоя)
     * @param runnerUserId запускающий пользователь (null — без личного слоя)
     * @return тексты уроков
     */
    public List<String> lessonsForScenario(UUID scenarioId, String runnerUserId) {
        log.info("[{}] lessonsForScenario, scenarioId={}", runnerUserId, scenarioId);
        List<String> result = new ArrayList<>();
        lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                        AgentLesson.SOURCE_SYSTEM).stream()
                .limit(LESSONS_LIMIT)
                .forEach(l -> result.add(l.getLesson()));
        if (runnerUserId != null && !runnerUserId.isBlank()) {
            lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc(
                            runnerUserId, AgentLesson.SOURCE_SYSTEM).stream()
                    .limit(LESSONS_LIMIT)
                    .forEach(l -> result.add(l.getLesson()));
        }
        if (scenarioId != null) {
            // неодобренные кандидаты (авто-уроки из прогонов) не применяются
            lessonRepository.findByScenarioIdOrderByCreatedAtDesc(scenarioId).stream()
                    .filter(l -> Boolean.TRUE.equals(l.getApproved()))
                    .limit(LESSONS_LIMIT)
                    .forEach(l -> result.add(l.getLesson()));
        }
        return result;
    }

    /**
     * Все уроки для страницы «Память агента». Уроки сценария — тем, кому доступен
     * сценарий (владелец, для общего — все); общие уроки — только системные и свои
     * (чужие личные уроки цитируют вопросы агента с фрагментами чужих документов).
     *
     * @param scenarioId фильтр по сценарию; null — общие уроки
     * @return уроки
     */
    public List<AgentLessonResponseDto> getLessons(UUID scenarioId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getLessons, scenarioId={}", userId, scenarioId);
        List<AgentLesson> entities;
        if (scenarioId != null) {
            checkScenarioReadable(userId, scenarioId);
            entities = lessonRepository.findByScenarioIdOrderByCreatedAtDesc(scenarioId);
        } else {
            entities = new ArrayList<>(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                    AgentLesson.SOURCE_SYSTEM));
            if (userId != null && !userId.isBlank()) {
                entities.addAll(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc(
                        userId, AgentLesson.SOURCE_SYSTEM));
            }
            entities.sort(Comparator.comparing(AgentLesson::getCreatedAt,
                    Comparator.nullsLast(Comparator.reverseOrder())));
        }
        return SchemaLimitUtils.firstItems(entities, RESPONSE_MAX_ITEMS).stream()
                .map(AgentLessonResponseDto::from)
                .toList();
    }

    /**
     * Добавляет урок. Частный урок применяется сразу; общий — после одобрения.
     * Текст сохраняется не длиннее лимита схемы (4000), чтобы показанный
     * и отредактированный на странице памяти текст совпадал с хранимым.
     *
     * @param scenarioId сценарий; null — общий урок
     * @param lesson     текст правила
     * @param source     источник (user/reviser/auto)
     * @return сохранённый урок
     */
    @Transactional
    public AgentLessonResponseDto addLesson(UUID scenarioId, String lesson, String source) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] addLesson, scenarioId={}, source={}", userId, scenarioId, source);
        if (lesson == null || lesson.isBlank()) {
            throw new IllegalArgumentException("Текст урока обязателен");
        }
        checkScenarioAuthor(userId, scenarioId);
        AgentLesson entity = new AgentLesson();
        entity.setUserId(CurrentUserHolder.getCurrentUser());
        entity.setScenarioId(scenarioId);
        entity.setLesson(SchemaLimitUtils.clip(lesson.strip(), AgentLessonResponseDto.LESSON_MAX_LENGTH));
        entity.setSource(source == null ? AgentLesson.SOURCE_USER : source);
        entity.setApproved(true);
        return AgentLessonResponseDto.from(lessonRepository.save(entity));
    }

    /** Обновляет текст урока (сценарные — только автор сценария, личные общие — только владелец). */
    @Transactional
    public AgentLessonResponseDto updateLesson(UUID id, String lesson) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] updateLesson, id={}", userId, id);
        AgentLesson entity = lessonRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Урок не найден: " + id));
        checkLessonEditable(userId, entity);
        entity.setLesson(SchemaLimitUtils.clip(lesson.strip(), AgentLessonResponseDto.LESSON_MAX_LENGTH));
        return AgentLessonResponseDto.from(lessonRepository.save(entity));
    }

    /** Удаляет урок (сценарные — только автор сценария, личные общие — только владелец). */
    @Transactional
    public void deleteLesson(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] deleteLesson, id={}", userId, id);
        lessonRepository.findById(id).ifPresent(entity -> {
            checkLessonEditable(userId, entity);
            lessonRepository.delete(entity);
        });
    }

    /** Одобряет урок к применению (сценарные — только автор сценария, личные общие — только владелец). */
    @Transactional
    public AgentLessonResponseDto approveLesson(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] approveLesson, id={}", userId, id);
        AgentLesson entity = lessonRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Урок не найден: " + id));
        checkLessonEditable(userId, entity);
        entity.setApproved(true);
        return AgentLessonResponseDto.from(lessonRepository.save(entity));
    }

    /**
     * Рефлексия-сжатие: уроки сценария дистиллируются LLM-вызовом в меньший
     * набор общих правил (не теряя конкретных значений и констант); старые
     * уроки заменяются сжатыми с источником auto. Явное действие пользователя
     * со страницы памяти — без тихой фоновой магии. Без сценария сжимаются
     * только личные общие уроки вызывающего; системные уроки не сжимаются никогда.
     *
     * LLM-вызов идёт вне транзакции (соединение БД не удерживается на время ответа
     * модели); замена уроков — отдельной транзакцией {@link #replaceLessons}.
     *
     * @param scenarioId сценарий; null — личные общие уроки пользователя
     * @return новые (сжатые) уроки
     */
    public List<AgentLessonResponseDto> compressLessons(UUID scenarioId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] compressLessons, scenarioId={}", userId, scenarioId);
        checkScenarioAuthor(userId, scenarioId);
        List<AgentLesson> old = (scenarioId != null
                ? lessonRepository.findByScenarioIdOrderByCreatedAtDesc(scenarioId)
                : lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc(
                        userId, AgentLesson.SOURCE_SYSTEM)).stream()
                .filter(l -> !AgentLesson.SOURCE_SYSTEM.equals(l.getSource()))
                .toList();
        if (old.size() < 3) {
            throw new IllegalArgumentException("Слишком мало уроков для сжатия: " + old.size());
        }
        StringBuilder sb = new StringBuilder();
        for (AgentLesson lesson : old) {
            sb.append("- ").append(lesson.getLesson()).append('\n');
        }
        String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                "Ниже — правила, выученные ИИ-агентом на прогонах одного сценария. Сожми их "
                        + "в НЕ БОЛЕЕ 7 правил: объединяй дублирующие, обобщай похожие, но НЕ теряй "
                        + "конкретные значения, названия и константы. Верни ТОЛЬКО JSON-массив строк.\n\n"
                        + sb)), null, null);
        List<String> compressed = AgentEvidence.parsePlan(raw);
        if (compressed.isEmpty()) {
            throw new IllegalStateException("Сжатие не удалось: ответ модели не распознан");
        }
        return self.get().replaceLessons(scenarioId, old, compressed);
    }

    /**
     * Транзакция замены уроков сжатыми: старые удаляются, новые сохраняются
     * с источником auto.
     *
     * @param scenarioId сценарий; null — личные общие уроки
     * @param old        заменяемые уроки
     * @param compressed тексты сжатых правил
     * @return новые уроки
     */
    @Transactional
    public List<AgentLessonResponseDto> replaceLessons(UUID scenarioId, List<AgentLesson> old, List<String> compressed) {
        lessonRepository.deleteAll(old);
        List<AgentLesson> entities = new ArrayList<>();
        for (String text : compressed) {
            AgentLesson entity = new AgentLesson();
            entity.setUserId(CurrentUserHolder.getCurrentUser());
            entity.setScenarioId(scenarioId);
            entity.setLesson(SchemaLimitUtils.clip(text, AgentLessonResponseDto.LESSON_MAX_LENGTH));
            entity.setSource(AgentLesson.SOURCE_AUTO);
            entity.setApproved(true);
            entities.add(lessonRepository.save(entity));
        }
        log.info("[{}] Уроки сценария {} сжаты: {} -> {}", CurrentUserHolder.getCurrentUser(), scenarioId, old.size(), entities.size());
        return entities.stream()
                .map(AgentLessonResponseDto::from)
                .toList();
    }

    /**
     * Авто-уроки из прогона (источник reviser): LLM выделяет из выходов
     * узлов прогона (замечания критика, правки ревизора, расхождения)
     * кандидатов-уроков. Кандидаты сохраняются НЕОДОБРЕННЫМИ — в промпт
     * агента попадут только после одобрения на странице памяти
     * (защита от самоотравления). LLM-вызов идёт вне транзакции; сохранение
     * кандидатов — отдельной транзакцией {@link #saveLessonCandidates}.
     *
     * @param scenarioId  сценарий прогона
     * @param runOutputs  выходы узлов прогона (метка — текст)
     * @return сохранённые кандидаты-уроки
     */
    public List<AgentLessonResponseDto> extractLessonsFromRun(UUID scenarioId,
                                                   Map<String, String> runOutputs) {
        log.info("[{}] extractLessonsFromRun, scenarioId={}",
                CurrentUserHolder.getCurrentUser(), scenarioId);
        StringBuilder sb = new StringBuilder();
        runOutputs.forEach((label, text) -> sb.append("=== ").append(label).append(" ===\n")
                .append(text.length() > 6000 ? text.substring(0, 6000) + "…" : text)
                .append("\n\n"));
        String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                "Ниже — результаты узлов прогона сценария (включая замечания проверяющих и "
                        + "правки). Выдели НЕ БОЛЕЕ 5 ПЕРЕНОСИМЫХ правил для будущих прогонов — "
                        + "только из ФАКТИЧЕСКИ найденных ошибок и исправлений. Правило обязано "
                        + "быть конкретным: назвать термин/поле/формулировку из документов и "
                        + "действие с ним — формат «X — это Y», «X ищи в Z», «не бери A, бери B». "
                        + "Пример формата из ДРУГОЙ предметной области (его НЕ копируй): "
                        + "«Гарантийный срок ищи в разделе Гарантия договора, а не в "
                        + "спецификации». ЗАПРЕЩЕНЫ общие призывы («проверяйте», "
                        + "«обращайте внимание», «следите за корректностью») — лучше пустой "
                        + "массив, чем банальность. Если ошибок не было — верни []. "
                        + "Верни ТОЛЬКО JSON-массив строк.\n\n" + sb)), null, null);
        List<String> candidates = AgentEvidence.parsePlan(raw);
        if (candidates.isEmpty()) {
            return List.of();
        }
        return self.get().saveLessonCandidates(scenarioId, candidates);
    }

    /**
     * Транзакция сохранения кандидатов-уроков: банальные и дубликаты известных
     * уроков отсеиваются, остальные сохраняются неодобренными (источник reviser).
     *
     * @param scenarioId сценарий прогона
     * @param candidates тексты кандидатов от модели
     * @return сохранённые кандидаты
     */
    @Transactional
    public List<AgentLessonResponseDto> saveLessonCandidates(UUID scenarioId, List<String> candidates) {
        List<AgentLesson> entities = new ArrayList<>();
        List<String> known = knownLessonTexts(scenarioId);
        int dropped = 0;
        for (String text : candidates) {
            boolean duplicate = known.stream().anyMatch(k -> similarLesson(text, k));
            if (!specificLesson(text) || duplicate) {
                dropped++;
                continue;
            }
            AgentLesson lesson = new AgentLesson();
            lesson.setUserId(CurrentUserHolder.getCurrentUser());
            lesson.setScenarioId(scenarioId);
            lesson.setLesson(SchemaLimitUtils.clip(text, AgentLessonResponseDto.LESSON_MAX_LENGTH));
            lesson.setSource(AgentLesson.SOURCE_REVISER);
            lesson.setApproved(false);
            entities.add(lessonRepository.save(lesson));
        }
        log.info("[{}] Из прогона извлечено кандидатов-уроков: {} (отсеяно: {})", CurrentUserHolder.getCurrentUser(), entities.size(), dropped);
        return entities.stream()
                .map(AgentLessonResponseDto::from)
                .toList();
    }

    /**
     * Кандидат-урок полезен, только если конкретен: не начинается с общего
     * призыва и содержит фактуру — термин в кавычках, число или соответствие
     * («X — Y», «X = Y»). Банальности вида «проверяйте суммы» лишь шумят в
     * системном промпте агента (наблюдалось: все 5 кандидатов прогона —
     * общие призывы без единого конкретного правила).
     */
    static boolean specificLesson(String text) {
        String l = text == null ? "" : text.strip().toLowerCase(Locale.ROOT);
        if (l.isBlank() || GENERIC_LESSON_STARTS.stream().anyMatch(l::startsWith)) {
            return false;
        }
        return l.matches("(?s).*[«\"\\d=—].*");
    }

    /**
     * Активные уроки для дедупликации кандидатов: системные и сценарные —
     * кандидат-перефраз существующего правила бесполезен (наблюдалось:
     * извлечение вернуло системный урок №1 другими словами).
     */
    private List<String> knownLessonTexts(UUID scenarioId) {
        try {
            return lessonsForScenario(scenarioId, null);
        } catch (Exception e) {
            log.warn("[{}] Уроки для дедупликации недоступны: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    /**
     * Дубликат-перефраз: значимые слова кандидата в основном совпадают со
     * словами существующего урока (порог 60% от меньшего набора).
     */
    static boolean similarLesson(String a, String b) {
        Set<String> wa = lessonWords(a);
        Set<String> wb = lessonWords(b);
        if (wa.isEmpty() || wb.isEmpty()) {
            return false;
        }
        long common = wa.stream().filter(wb::contains).count();
        return common >= Math.min(wa.size(), wb.size()) * 0.6;
    }

    private static Set<String> lessonWords(String s) {
        return Arrays.stream(normalizedLesson(s).split("[^а-яёa-z0-9]+"))
                .filter(w -> w.length() >= 3)
                .collect(Collectors.toSet());
    }

    private static String normalizedLesson(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT)
                .replace('ё', 'е').replaceAll("[\\s\\u00A0]+", " ").strip();
    }

    // -------------------------------------------------------------------
    // Планы
    // -------------------------------------------------------------------

    /**
     * Ищет проверенный план сценария для задания (по хэшу нормализованного текста).
     * Планы — часть памяти сценария: план другого сценария с тем же текстом
     * задания не переиспользуется.
     *
     * @param scenarioId сценарий прогона (null — планы без сценария)
     * @param task       задание агенту
     * @return пункты плана или пустой список, если план не найден
     */
    public List<String> findPlan(UUID scenarioId, String task) {
        log.info("[{}] findPlan, scenarioId={}, taskChars={}",
                CurrentUserHolder.getCurrentUser(), scenarioId, task == null ? 0 : task.length());
        if (task == null) {
            return List.of();
        }
        return planRepository.findFirstByScenarioIdAndTaskHashOrderByUsesDesc(scenarioId, taskHash(task))
                .map(p -> {
                    p.setUses(p.getUses() + 1);
                    planRepository.save(p);
                    return AgentEvidence.parsePlan(p.getPlan());
                })
                .orElse(List.of());
    }

    /**
     * Сохраняет план успешно завершённого агентского прогона (или обновляет
     * существующий для того же задания).
     *
     * @param scenarioId сценарий
     * @param task       задание
     * @param plan       пункты плана
     */
    @Transactional
    public void savePlan(UUID scenarioId, String task, List<String> plan) {
        log.info("[{}] savePlan, scenarioId={}, planItems={}",
                CurrentUserHolder.getCurrentUser(), scenarioId, plan == null ? 0 : plan.size());
        try {
            String hash = taskHash(task);
            AgentPlan entity = planRepository.findFirstByScenarioIdAndTaskHashOrderByUsesDesc(scenarioId, hash)
                    .orElseGet(AgentPlan::new);
            entity.setScenarioId(scenarioId);
            entity.setTaskHash(hash);
            entity.setTaskPreview(task.length() > 300 ? task.substring(0, 300) + "…" : task);
            entity.setPlan(objectMapper.writeValueAsString(plan));
            if (entity.getUses() == null) {
                entity.setUses(0);
            }
            planRepository.save(entity);
        } catch (Exception e) {
            log.warn("[{}] План не сохранён в память: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /**
     * Планы сценария для страницы памяти — тем, кому доступен сценарий
     * (task_preview плана цитирует задание с контекстом документов).
     *
     * @param scenarioId сценарий
     * @return планы в виде DTO по схеме AgentPlan спецификации
     */
    public List<AgentPlanResponseDto> getPlans(UUID scenarioId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getPlans, scenarioId={}", userId, scenarioId);
        checkScenarioReadable(userId, scenarioId);
        return SchemaLimitUtils.firstItems(planRepository.findByScenarioIdOrderByUpdatedAtDesc(scenarioId), RESPONSE_MAX_ITEMS)
                .stream()
                .map(AgentPlanResponseDto::from)
                .toList();
    }

    /** Удаляет план из памяти (только автор сценария). */
    @Transactional
    public void deletePlan(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] deletePlan, id={}", userId, id);
        planRepository.findById(id).ifPresent(plan -> {
            checkScenarioAuthor(userId, plan.getScenarioId());
            planRepository.delete(plan);
        });
    }

    /** SHA-256 нормализованного задания (пробелы схлопнуты, нижний регистр). */
    static String taskHash(String task) {
        try {
            String normalized = task.replaceAll("\\s+", " ").strip().toLowerCase(Locale.ROOT);
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(normalized.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    // -------------------------------------------------------------------
    // Вопросы (асинхронный human-in-the-loop)
    // -------------------------------------------------------------------

    /**
     * Сохраняет вопросы агента к пользователю по итогам прогона узла.
     *
     * @param runId      прогон
     * @param scenarioId сценарий
     * @param nodeLabel  метка узла
     * @param questions  тексты вопросов
     */
    @Transactional
    public void saveQuestions(UUID runId, UUID scenarioId, String nodeLabel, List<String> questions) {
        log.info("[{}] saveQuestions, runId={}, scenarioId={}, node='{}', count={}",
                CurrentUserHolder.getCurrentUser(), runId, scenarioId, nodeLabel,
                questions == null ? 0 : questions.size());
        for (String question : questions) {
            AgentQuestion entity = new AgentQuestion();
            entity.setRunId(runId);
            entity.setScenarioId(scenarioId);
            entity.setNodeLabel(nodeLabel);
            entity.setQuestion(question);
            questionRepository.save(entity);
        }
    }

    /**
     * Вопросы прогона (для карточки прогона в UI).
     *
     * @param runId прогон
     * @return вопросы в виде DTO по схеме AgentQuestion спецификации
     */
    public List<AgentQuestionResponseDto> getQuestionsByRun(UUID runId) {
        log.info("[{}] getQuestionsByRun, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        return SchemaLimitUtils.firstItems(questionRepository.findByRunIdOrderByCreatedAtAsc(runId), RESPONSE_MAX_ITEMS)
                .stream()
                .map(AgentQuestionResponseDto::from)
                .toList();
    }

    /**
     * Прогон, к которому относится вопрос агента, — для проверки доступа
     * к прогону до ответа на вопрос.
     *
     * @param id вопрос
     * @return идентификатор прогона вопроса
     * @throws NotFoundException вопрос не найден
     */
    public UUID getQuestionRunId(UUID id) {
        log.info("[{}] getQuestionRunId, id={}", CurrentUserHolder.getCurrentUser(), id);
        return questionRepository.findById(id)
                .map(AgentQuestion::getRunId)
                .orElseThrow(() -> new NotFoundException("Вопрос не найден: " + id));
    }

    /**
     * Ответ пользователя на вопрос агента: сохраняется и превращается в
     * частный урок сценария — при следующем прогоне агент его учтёт.
     *
     * @param id     вопрос
     * @param answer текст ответа
     * @return обновлённый вопрос в виде DTO по схеме AgentQuestion спецификации
     */
    @Transactional
    public AgentQuestionResponseDto answerQuestion(UUID id, String answer) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] answerQuestion, id={}", userId, id);
        if (answer == null || answer.isBlank()) {
            throw new IllegalArgumentException("Текст ответа обязателен");
        }
        AgentQuestion question = questionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Вопрос не найден: " + id));
        // ответ рождает урок сценария — право автора
        checkScenarioAuthor(userId, question.getScenarioId());
        question.setAnswer(answer.strip());
        question.setAnsweredAt(OffsetDateTime.now());
        questionRepository.save(question);
        self.get().addLesson(question.getScenarioId(),
                lessonFromAnswer(question.getQuestion(), answer.strip()), AgentLesson.SOURCE_USER);
        return AgentQuestionResponseDto.from(question);
    }

    /**
     * Текст урока из ответа на вопрос, не длиннее лимита схемы (4000): цитата
     * вопроса занимает только место, оставшееся после ответа (не больше
     * {@link #LESSON_QUESTION_QUOTE_LIMIT}), так что ответ сохраняется целиком,
     * пока сам укладывается в лимит. При остатке меньше {@link #MIN_QUESTION_QUOTE}
     * вопрос не цитируется; если не помещается и префикс «Пользователь уточнил: »,
     * урок равен самому ответу — ответ не обрезается. Полный ответ хранится и в самом вопросе.
     *
     * @param questionText текст вопроса агента
     * @param answerText   ответ пользователя (без пробелов по краям)
     * @return текст урока
     */
    static String lessonFromAnswer(String questionText, String answerText) {
        int quoteBudget = Math.min(LESSON_QUESTION_QUOTE_LIMIT,
                AgentLessonResponseDto.LESSON_MAX_LENGTH - LESSON_ANSWER_FRAME_LENGTH - answerText.length());
        if (quoteBudget >= MIN_QUESTION_QUOTE) {
            return "На вопрос «" + SchemaLimitUtils.clip(questionText, quoteBudget) + "» пользователь уточнил: " + answerText;
        }
        String lesson = "Пользователь уточнил: " + answerText;
        return lesson.length() <= AgentLessonResponseDto.LESSON_MAX_LENGTH
                ? lesson
                : SchemaLimitUtils.clip(answerText, AgentLessonResponseDto.LESSON_MAX_LENGTH);
    }
}
