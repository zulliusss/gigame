package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Структурный индекс базы нормативки: акт → статья/раздел → текст документа,
 * построенный по именам файлов базы знаний («223-ФЗ статья 3 2 . Порядок…»,
 * «ГК РФ статья 421 …», «ПП 1352 от …», «Положение о закупках Сбербанка 2348-3 —
 * разд 5 …», «ТС 4620-3 04 - раздел 4. …», «Письмо Минфина … N …», «Справка …»).
 * <p>
 * Запрос — реквизит в том виде, в каком его пишет справочник типов риска:
 * «п. 2, 4 ч. 1 ст. 3 223-ФЗ», «ч. 17–21 ст. 3.2 223-ФЗ», «ст. 164 НК РФ»,
 * «п. 14(3) ПП 1352», «Положение о закупках 2348-3 разд. 5», «ТС 4620-3 разд. 4».
 * Ответ — текст именно этой части/пункта (или статьи целиком, если часть не
 * выделена), без векторного поиска и без участия модели.
 */
public final class NormIndex {

    /** Найденная норма. */
    public record Hit(String requisite, String document, String text, boolean partFound) {
    }

    /** Документ индекса: ключ акта, номер статьи/раздела, заголовок файла, текст. */
    record Entry(String act, String article, String title, String text) {
    }

    static final int TEXT_LIMIT = 2500;
    private static final int HEAD_LIMIT = 1500;

    private static final Pattern FILE_FZ = Pattern.compile("^(\\d{2,3}-ФЗ)\\s+(?:статья|ст)\\s+(\\d+(?:[\\s.]\\d+(?:-\\d+)?)?)");
    private static final Pattern FILE_CODE = Pattern.compile("^(ГК|НК|КоАП)\\s+РФ\\s+статья\\s+([\\d.]+)");
    private static final Pattern FILE_PP = Pattern.compile("^(?:ПП\\s+(\\d{3,4})|Постановление Правительства РФ от [\\d.]+ N\\s*(\\d{3,4}))");
    private static final Pattern FILE_POLICY = Pattern.compile("^Положение о закупках Сбербанка 2348-3 — (разд|прил Приложение)\\s+(\\S+)");
    private static final Pattern FILE_TS = Pattern.compile("^ТС 4620-3 \\d+ - раздел (\\d+)\\.\\s*(.*)");
    private static final Pattern FILE_LETTER = Pattern.compile("^Письмо (Минфина|ФАС)\\b.*?(N\\s*[\\d-]+|[А-Я]{2}-\\d{3,6}-\\d{2})?");
    private static final Pattern FILE_FZ_WHOLE = Pattern.compile("^(\\d{2,3}-ФЗ)\\s+[^с]");

    private static final Pattern REQ_FZ = Pattern.compile("(\\d{2,3}-ФЗ)");
    private static final Pattern REQ_CODE = Pattern.compile("(ГК|НК|КоАП)\\s+РФ");
    private static final Pattern REQ_PP = Pattern.compile("ПП\\s*(\\d{3,4})");
    private static final Pattern REQ_ARTICLE = Pattern.compile("(?:ст\\.|статьи|статья|ст)\\s*(\\d+(?:\\.\\d+)?(?:-\\d+)?)");
    private static final Pattern REQ_PART = Pattern.compile("ч\\.?\\s*(\\d+(?:\\.\\d+)?)(?:\\s*[–-]\\s*(\\d+))?");
    private static final Pattern REQ_POINTS = Pattern.compile("п\\.?\\s*(\\d+(?:\\(\\d+\\))?(?:\\s*,\\s*\\d+)*)");
    private static final Pattern REQ_SECTION = Pattern.compile("(прил\\.?\\s*|разд\\.?\\s*)(\\d+(?:\\.\\d+)?)");

    /** Заголовок части статьи в текстах базы: «17. …», «5 3 . …» (5.3), «14 3 . …» (14(3)). */
    private static final Pattern NEXT_PART = Pattern.compile("(?m)^\\s*\\d+(?:\\s*[.(]?\\s*\\d+\\s*\\)?)?\\s*\\.\\s+\\S");

    private final Map<String, List<Entry>> byAct = new LinkedHashMap<>();

    private NormIndex() {
    }

    /**
     * Индекс по документам базы (имя файла без расширения задаёт акт и статью).
     *
     * @param docs пары «имя файла → текст»
     * @return индекс
     */
    public static NormIndex build(Map<String, String> docs) {
        NormIndex index = new NormIndex();
        for (Map.Entry<String, String> doc : docs.entrySet()) {
            String name = doc.getKey().replaceFirst("(?i)\\.(txt|md|rtf|pdf|docx)$", "").strip();
            // тексты базы приходят с «\r\r\n» — возвраты каретки убираются, иначе якоря строк ловят пустые строки
            Entry entry = parseName(name, doc.getValue() == null ? "" : doc.getValue().replace("\r", ""));
            if (entry != null) {
                index.byAct.computeIfAbsent(entry.act(), k -> new ArrayList<>()).add(entry);
            }
        }
        return index;
    }

    static Entry parseName(String name, String text) {
        Matcher m = FILE_FZ.matcher(name);
        if (m.find()) {
            return new Entry(m.group(1), m.group(2).replaceAll("\\s+", ".").replace("..", "."), name, text);
        }
        m = FILE_CODE.matcher(name);
        if (m.find()) {
            return new Entry(m.group(1) + " РФ", m.group(2), name, text);
        }
        m = FILE_PP.matcher(name);
        if (m.find()) {
            return new Entry("ПП " + (m.group(1) != null ? m.group(1) : m.group(2)), "", name, text);
        }
        m = FILE_POLICY.matcher(name);
        if (m.find()) {
            return new Entry("Положение 2348-3",
                    (m.group(1).startsWith("прил") ? "прил." : "") + m.group(2).replace("¹", ".1"), name, text);
        }
        m = FILE_TS.matcher(name);
        if (m.find()) {
            return new Entry("ТС 4620-3", m.group(1), name, text);
        }
        m = FILE_LETTER.matcher(name);
        if (m.find()) {
            return new Entry("письмо " + m.group(1), "", name, text);
        }
        // справка узнаётся по базовому имени без учёта регистра: «справка_…», «архив.zip/Справка …»
        if (name.substring(name.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT).startsWith("справка")) {
            return new Entry("Справка", "", name, text);
        }
        m = FILE_FZ_WHOLE.matcher(name);
        if (m.find()) {
            return new Entry(m.group(1), "", name, text);
        }
        return null;
    }

    /** @return число документов в индексе */
    public int size() {
        return byAct.values().stream().mapToInt(List::size).sum();
    }

    /**
     * Нормы по строке реквизитов (несколько через «;»).
     *
     * @param request строка реквизитов справочника
     * @return найденные нормы (пустой список — ничего не распознано)
     */
    public List<Hit> resolve(String request) {
        List<Hit> hits = new ArrayList<>();
        if (request == null) {
            return hits;
        }
        // реквизиты разделены «;», но «;» внутри пояснения в скобках («(равноправие; запрет …)») — не разделитель
        for (String part : request.split(";(?![^(]*\\))")) {
            // пояснения в скобках убираются, номера пунктов вида «14(3)» остаются
            String req = part.replaceAll("\\((?=[^)]*[а-яА-Яa-zA-Z])[^)]*\\)", " ").strip();
            if (req.isEmpty()) {
                continue;
            }
            Hit hit = resolveOne(req, part.strip());
            if (hit != null) {
                hits.add(hit);
            }
        }
        return hits;
    }

    private Hit resolveOne(String req, String original) {
        String act = actKey(req);
        if (act == null) {
            return null;
        }
        List<Entry> entries = byAct.getOrDefault(act, List.of());
        if (entries.isEmpty()) {
            return null;
        }
        String article = group(REQ_ARTICLE, req, 1);
        String section = sectionKey(req);
        Entry entry = pick(entries, article.isEmpty() ? section : article, original);
        if (entry == null) {
            return null;
        }
        Matcher part = REQ_PART.matcher(req);
        String points = group(REQ_POINTS, req, 1);
        String fragment = null;
        if (part.find()) {
            fragment = partText(entry.text(), part.group(1), part.group(2), points);
        } else if (!points.isEmpty()) {
            fragment = partText(entry.text(), points.replaceAll("[()]", "."), null, "");
        }
        boolean found = fragment != null;
        String text = found ? fragment : head(entry.text());
        return new Hit(original, entry.title(), limit(text), found);
    }

    private static String sectionKey(String req) {
        Matcher m = REQ_SECTION.matcher(req);
        if (!m.find()) {
            return "";
        }
        return (m.group(1).startsWith("прил") ? "прил." : "") + m.group(2);
    }

    private static String actKey(String req) {
        Matcher m = REQ_FZ.matcher(req);
        if (m.find()) {
            return m.group(1);
        }
        m = REQ_CODE.matcher(req);
        if (m.find()) {
            return m.group(1) + " РФ";
        }
        m = REQ_PP.matcher(req);
        if (m.find()) {
            return "ПП " + m.group(1);
        }
        String lower = req.toLowerCase(Locale.ROOT);
        if (lower.contains("положени") || lower.contains("2348-3")) {
            return "Положение 2348-3";
        }
        if (lower.contains("тс 4620") || lower.contains("4620-3")) {
            return "ТС 4620-3";
        }
        if (lower.contains("справк")) {
            return "Справка";
        }
        if (lower.contains("письм")) {
            return lower.contains("фас") ? "письмо ФАС" : "письмо Минфина";
        }
        return null;
    }

    /** Документ акта: по номеру статьи/раздела; при нескольких — по совпадению слов запроса с заголовком. */
    private static Entry pick(List<Entry> entries, String number, String original) {
        List<Entry> candidates = new ArrayList<>();
        for (Entry e : entries) {
            if (number.isEmpty() ? e.article().isEmpty() || entries.size() == 1 : e.article().equals(number)) {
                candidates.add(e);
            }
        }
        if (candidates.isEmpty() && number.isEmpty()) {
            candidates.addAll(entries);
        }
        if (candidates.isEmpty()) {
            return null;
        }
        Entry best = candidates.get(0);
        int bestScore = -1;
        for (Entry e : candidates) {
            int score = overlap(e.title(), original);
            if (score > bestScore) {
                best = e;
                bestScore = score;
            }
        }
        return best;
    }

    private static int overlap(String title, String request) {
        int score = 0;
        String lowerTitle = title.toLowerCase(Locale.ROOT);
        for (String word : request.toLowerCase(Locale.ROOT).split("[^а-яёa-z0-9]+")) {
            if (word.length() >= 5 && lowerTitle.contains(word.substring(0, 5))) {
                score++;
            }
        }
        return score;
    }

    /**
     * Текст части статьи (диапазона частей) и, если указаны, только перечисленных
     * пунктов внутри неё. Заголовок части в текстах базы: «17. …», «5 3 . …» (5.3),
     * «14 3 . …» (14(3)).
     */
    static String partText(String text, String from, String to, String points) {
        int[] head = partStart(text, from);
        if (head == null) {
            return null;
        }
        String last = to == null ? from : to;
        int[] lastHead = partStart(text, last);
        // следующий заголовок ищется после КОНЦА заголовка последней части, а не сразу за её началом
        int searchFrom = lastHead == null ? head[1] : lastHead[1];
        Matcher next = NEXT_PART.matcher(text);
        int end = next.find(searchFrom) ? next.start() : text.length();
        String fragment = text.substring(head[0], end).strip();
        if (!points.isEmpty()) {
            String selected = pointsText(fragment, points);
            if (selected != null) {
                return selected;
            }
        }
        return fragment;
    }

    /** @return {начало, конец} заголовка части или {@code null} */
    private static int[] partStart(String text, String number) {
        String[] pieces = number.split("[.()]+");
        StringBuilder rx = new StringBuilder("(?m)^\\s*");
        for (int i = 0; i < pieces.length; i++) {
            if (pieces[i].isEmpty()) {
                continue;
            }
            if (i > 0) {
                rx.append("\\s*[.(]?\\s*");
            }
            rx.append(pieces[i]);
        }
        rx.append("\\s*\\)?\\s*\\.\\s+");
        Matcher m = Pattern.compile(rx.toString()).matcher(text);
        return m.find() ? new int[]{m.start(), m.end()} : null;
    }

    /** Пункты «2) …», «4) …» внутри части; заголовок части сохраняется первой строкой. */
    private static String pointsText(String fragment, String points) {
        StringBuilder out = new StringBuilder();
        int firstBreak = fragment.indexOf('\n');
        out.append(firstBreak > 0 ? fragment.substring(0, firstBreak).strip() : fragment.strip()).append('\n');
        boolean any = false;
        for (String p : points.split("\\s*,\\s*")) {
            Matcher m = Pattern.compile("(?s)(?<![\\d.])" + Pattern.quote(p.strip()) + "\\)\\s+(.*?)(?=\\s\\d{1,2}\\)\\s|\\z)")
                    .matcher(fragment);
            if (m.find()) {
                out.append(p.strip()).append(") ").append(m.group(1).strip()).append('\n');
                any = true;
            }
        }
        return any ? out.toString().strip() : null;
    }

    private static String head(String text) {
        return text.length() > HEAD_LIMIT ? text.substring(0, HEAD_LIMIT) + "…" : text;
    }

    private static String limit(String text) {
        return text.length() > TEXT_LIMIT ? text.substring(0, TEXT_LIMIT) + "…" : text;
    }

    private static String group(Pattern p, String text, int group) {
        Matcher m = p.matcher(text);
        return m.find() && m.group(group) != null ? m.group(group).strip() : "";
    }
}
