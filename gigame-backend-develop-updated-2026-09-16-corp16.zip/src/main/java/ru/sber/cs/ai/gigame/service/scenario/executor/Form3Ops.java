package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Кодовые операции Формы 3 (опыт участника закупки) без участия LLM.
 * <p>
 * «реестр_документов» разбирает тексты комплекта: УПД (номер, дата, продавец,
 * покупатель, договор, сумма «Всего к оплате», дата приёмки и подпись
 * заказчика), спецификации (номер, договор, дата подписания, суммы, текст),
 * договоры (номер, дата, текст) и отчёты о выполненных работах (спецификация,
 * договор, номера, суммы, текст). «строки_формы3» по реестру и выверенным
 * критериям Шага 1 строит строки формы — см. {@link Form3Rows}. Форматы взяты
 * с УПД/спецификаций ЭДО СберКорус.
 */
final class Form3Ops {

    static final ObjectMapper MAPPER = new ObjectMapper();
    static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    /** Текст документа в реестре: договор на сотню страниц несёт требования к ролям (технологии) в конце. */
    private static final int TEXT_LIMIT = 400000;
    private static final int MAX_SPEC_NUMBER = 8;

    private static final Pattern UPD_HEAD = Pattern.compile(
            "Сч[её]т-?фактура\\s*[N№]\\s*(\\d+)\\s+от\\s+(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern UPD_SELLER = Pattern.compile("Продавец:\\s*(.+?)\\s*\\(2\\)");
    private static final Pattern UPD_BUYER = Pattern.compile("Покупатель:\\s*(.+?)\\s*\\(6\\)");
    private static final Pattern UPD_TOTAL = Pattern.compile(
            "Всего к оплате\\s*\\(9\\)((?:\\s*(?:[\\d ]+[,.]\\d{2}|×|без НДС|без налога|-))+)");
    /** Итог печатной формы СберКорус — целые рубли без копеек: «Всего к оплате (9) 4341149». */
    private static final Pattern UPD_TOTAL_WHOLE = Pattern.compile("Всего к оплате\\s*\\(9\\)\\s*(\\d{3,12})(?![\\d,.])");
    /** Подпись покупателя в штампе ЭДО: две и более подписи «Подпись соответствует файлу документа». */
    private static final Pattern EDO_SIGNATURE = Pattern.compile("Подпись соответствует файлу документа");
    private static final int EDO_BOTH_SIDES = 2;
    private static final Pattern UPD_ACCEPT = Pattern.compile(
            "\"\\s*(\\d{1,2})\\s*\"\\s*([а-яё]+)\\s*(\\d{4})\\s*г\\.\\s*\\[18\\]");
    private static final Pattern UPD_BUYER_SIGN = Pattern.compile("Электронная подпись\\s+[А-ЯЁ][^\\[]{3,80}?\\[20\\]");
    static final Pattern CONTRACT_REF = Pattern.compile(
            "Договор[а-я]*\\s*№?\\s*(\\d{5,12})(?:[^\\n]{0,60}?от\\s*(\\d{2}\\.\\d{2}\\.\\d{4}))?");
    static final Pattern SPEC_REF = Pattern.compile("Спецификаци[а-я]*[^\\n№]{0,120}?№\\s*(\\d{6,8})");
    private static final Pattern SPEC_HEAD = Pattern.compile(Form3Acts.TYPE_LINE + "\\d?\\s*Спецификаци",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SPEC_CONTRACT = Pattern.compile("к\\s+Договору\\s*№?\\s*(\\d{5,12})");
    /** Заголовок договора в первых 60 знаках: «ДОГОВОР № …», «Рамочный Договор № …», «1 ДОГОВОР № …», «Тип документа: Договор». */
    private static final Pattern CONTRACT_HEAD = Pattern.compile(
            "^[\\s\\S]{0,60}?(?<![А-Яа-яЁё])(?<!к\\s)(?<!по\\s)Договор[а-яё]*\\s*№", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern REPORT_HEAD = Pattern.compile(Form3Acts.TYPE_LINE + "Отч[её]т\\s+о\\s+выполненн",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SIGN_STAMP = Pattern.compile("(\\d{2}\\.\\d{2}\\.\\d{4})\\s+\\d{2}:\\d{2}:\\d{2}");
    static final Pattern AMOUNT = Pattern.compile("(?<![\\d,.])(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?![\\d])");
    private static final Pattern FILE_NUMBER = Pattern.compile("(?<!\\d)(\\d{7,8})(?!\\d)");
    /** Номер документа в распознанном тексте: «Реквизиты документа: № 4801685». */
    private static final Pattern OCR_NUMBER = Pattern.compile("(?:Реквизиты документа|Номер документа|Номер)[^\\n]{0,40}?№\\s*(\\d{6,8})(?!\\d)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Буквенно-цифровой номер договора («Договор № АБ-С-ИТ-2020»). */
    static final Pattern CONTRACT_ALNUM = Pattern.compile("Договор[а-яё]*\\s*№\\s*([A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9/\\-]{2,24})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern CONTRACT_SIGNED = Pattern.compile("Дата подписания:\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
    /** Номера заказов (ЗНЗО, заказ, заявка) — связка отчёта с УПД; ИНН/КПП и номера договоров не берутся. */
    static final Pattern ORDER_REF = Pattern.compile(
            "(?:ЗНЗО|[Зз]аказ[а-я]*|[Зз]аявк[а-я]*)\\s*(?:на\\s+\\S+\\s+)?№?\\s*(\\d{6,14})(?!\\d)");
    private static final Pattern REPORT_UPD = Pattern.compile("УПД\\s*№?\\s*0*(\\d{3,10})");
    /** Номер договора в договоре/отчёте: заголовок бывает в верхнем регистре («ДОГОВОР № …»). */
    private static final Pattern CONTRACT_REF_CI = Pattern.compile(CONTRACT_REF.pattern(),
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Методологии: упоминание в названии должности («Главный инженер DevOps») применение методологии не подтверждает. */
    private static final Pattern METHODOLOGY = Pattern.compile("^(DevOps|DevSecOps|Agile|Scrum|Kanban|Sbergile|ITIL|SAFe)$",
            Pattern.CASE_INSENSITIVE);
    private static final String ROLE_BEFORE =
            "(?<!(?:инженер|специалист|разработчик|архитектор|аналитик|тестировщик|engineer)\\s{1,3})";

    /** Общепринятые сокращения технологий: в документах «JavaScript» пишут «JS», «TypeScript» — «TS». */
    private static final Map<String, String> TECH_SYNONYMS = Map.ofEntries(
            Map.entry("javascript", "JS"), Map.entry("typescript", "TS"), Map.entry("kubernetes", "k8s"),
            Map.entry("postgresql", "Postgres"), Map.entry("golang", "Go"), Map.entry("python", "Py"),
            Map.entry("c#", "CSharp"), Map.entry("react", "ReactJS"), Map.entry("node.js", "NodeJS"));

    static final Map<String, String> MONTHS = Map.ofEntries(
            Map.entry("января", "01"), Map.entry("февраля", "02"), Map.entry("марта", "03"),
            Map.entry("апреля", "04"), Map.entry("мая", "05"), Map.entry("июня", "06"),
            Map.entry("июля", "07"), Map.entry("августа", "08"), Map.entry("сентября", "09"),
            Map.entry("октября", "10"), Map.entry("ноября", "11"), Map.entry("декабря", "12"));

    private Form3Ops() {
    }

    /** Документ комплекта: имя файла и текст. */
    record Source(String name, String text) {
    }

    // ------------------------------------------------------------------ реестр

    /**
     * Реестр документов комплекта в JSON: {@code {"упд": [...], "спецификации": [...],
     * "договоры": [...], "отчёты": [...], "акты": [...], "прочее": [...],
     * "не_разобраны": [{"файл", "причина"}]}}. Нечитаемые документы (маркер ручной
     * проверки: скан без OCR, битый файл, нераспакованный архив) не классифицируются. Заявки
     * (заказы к рамочному договору) лежат среди спецификаций с полем «вид»,
     * акты сдачи-приёмки без структуры УПД — отдельным списком (см. {@link Form3Acts}).
     *
     * @param sources документы комплекта
     * @return JSON реестра
     */
    static String registry(List<Source> sources) {
        List<Map<String, Object>> upds = new ArrayList<>();
        List<Map<String, Object>> specs = new ArrayList<>();
        List<Map<String, Object>> contracts = new ArrayList<>();
        List<Map<String, Object>> reports = new ArrayList<>();
        List<Map<String, Object>> acts = new ArrayList<>();
        List<Map<String, Object>> unreadable = new ArrayList<>();
        List<String> other = new ArrayList<>();
        for (Source source : sources) {
            String text = normalize(source.text());
            // распознанный скан начинается со служебной строки OCR — заголовок документа ищется после неё
            String head = Form3Acts.body(text);
            if (ScenarioRunDoc.isUnreadable(text)) {
                // маркер ручной проверки — не документ: раньше слово «акт» в имени делало из него акт с пустой суммой
                unreadable.add(unreadableEntry(source.name(), text));
            } else if (UPD_HEAD.matcher(text).find()) {
                upds.add(parseUpd(source.name(), text));
            } else if (REPORT_HEAD.matcher(head).find()) {
                reports.add(parseReport(source.name(), text));
            } else if (Form3Acts.isAct(source.name(), text)) {
                acts.add(Form3Acts.parseAct(source.name(), text));
            } else if (Form3Acts.isOrder(source.name(), text)) {
                specs.add(Form3Acts.parseOrder(source.name(), text));
            } else if (SPEC_HEAD.matcher(head).find() && (SPEC_REF.matcher(text).find() || OCR_NUMBER.matcher(text).find())) {
                specs.add(parseSpec(source.name(), text));
            } else if (CONTRACT_HEAD.matcher(head).find() || CONTRACT_SIGNED.matcher(text).find()) {
                contracts.add(parseContract(source.name(), text));
            } else {
                other.add(source.name());
            }
        }
        Map<String, Object> registry = new LinkedHashMap<>();
        registry.put("упд", upds);
        registry.put("спецификации", specs);
        registry.put("договоры", contracts);
        registry.put("отчёты", reports);
        registry.put("акты", acts);
        registry.put("прочее", other);
        registry.put("не_разобраны", unreadable);
        return toJson(registry);
    }

    /** Запись реестра о документе, который не удалось разобрать: имя файла и причина из маркера. */
    private static Map<String, Object> unreadableEntry(String name, String text) {
        Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("файл", name);
        entry.put("причина", ScenarioRunDoc.unreadableReason(text));
        return entry;
    }

    /**
     * Нормализация текста ЭДО-документа: неразрывные пробелы, мягкие переносы,
     * возвраты каретки.
     */
    static String normalize(String text) {
        return text == null ? "" : text.replace('\u00A0', ' ').replace("\u00AD", "").replace("\r", "");
    }

    private static Map<String, Object> parseUpd(String name, String text) {
        Map<String, Object> upd = new LinkedHashMap<>();
        upd.put("файл", name);
        Matcher head = UPD_HEAD.matcher(text);
        head.find();
        upd.put("номер", head.group(1));
        upd.put("дата", head.group(2));
        upd.put("продавец", firstGroup(UPD_SELLER, text));
        upd.put("покупатель", firstGroup(UPD_BUYER, text));
        Matcher contract = CONTRACT_REF.matcher(text);
        String contractNumber = "";
        String contractDate = "";
        if (contract.find()) {
            contractNumber = contract.group(1);
            contractDate = contract.group(2) == null ? "" : contract.group(2);
        }
        upd.put("договор", contractNumber);
        upd.put("договор_дата", contractDate);
        upd.put("сумма", totalAmount(text));
        upd.put("дата_приёмки", acceptanceDate(text));
        upd.put("подпись_заказчика", UPD_BUYER_SIGN.matcher(text).find() || edoSignedByBothSides(text));
        upd.put("спецификация", specReference(text, name, contractNumber));
        upd.put("заказы", orderNumbers(text));
        upd.put("текст", limit(text));
        return upd;
    }

    private static boolean edoSignedByBothSides(String text) {
        int signatures = 0;
        Matcher m = EDO_SIGNATURE.matcher(text);
        while (m.find()) {
            signatures++;
        }
        return signatures >= EDO_BOTH_SIDES;
    }

    private static String totalAmount(String text) {
        Matcher m = UPD_TOTAL.matcher(text);
        if (!m.find()) {
            Matcher whole = UPD_TOTAL_WHOLE.matcher(text);
            return whole.find() ? whole.group(1) + ".00" : "";
        }
        String last = "";
        Matcher amounts = AMOUNT.matcher(m.group(1));
        while (amounts.find()) {
            last = amounts.group(1).replace(" ", "") + "." + amounts.group(2);
        }
        return last;
    }

    private static String acceptanceDate(String text) {
        Matcher m = UPD_ACCEPT.matcher(text);
        if (!m.find()) {
            return "";
        }
        String month = MONTHS.get(m.group(2).toLowerCase(Locale.ROOT));
        if (month == null) {
            return "";
        }
        return String.format("%02d.%s.%s", Integer.parseInt(m.group(1)), month, m.group(3));
    }

    private static String specReference(String text, String fileName, String contractNumber) {
        Matcher inText = SPEC_REF.matcher(text);
        if (inText.find()) {
            return inText.group(1);
        }
        Matcher inName = FILE_NUMBER.matcher(fileName);
        while (inName.find()) {
            if (!inName.group(1).equals(contractNumber) && inName.group(1).length() <= MAX_SPEC_NUMBER) {
                return inName.group(1);
            }
        }
        return "";
    }

    private static Map<String, Object> parseSpec(String name, String text) {
        Map<String, Object> spec = new LinkedHashMap<>();
        spec.put("файл", name);
        String number = firstGroup(SPEC_REF, text);
        if (number.isEmpty()) {
            number = firstGroup(OCR_NUMBER, text);
        }
        spec.put("номер", number.isEmpty() ? firstGroup(FILE_NUMBER, name) : number);
        spec.put("договор", firstGroup(SPEC_CONTRACT, text));
        spec.put("дата", latestStamp(text));
        spec.put("суммы", amounts(text));
        spec.put("текст", limit(text));
        return spec;
    }

    private static Map<String, Object> parseContract(String name, String text) {
        Map<String, Object> contract = new LinkedHashMap<>();
        contract.put("файл", name);
        Matcher ref = CONTRACT_REF_CI.matcher(text);
        // скан без текстового слоя: номер договора берётся из имени файла («Договор № 4652269 от …»);
        // рамочные договоры банков бывают с буквенно-цифровым номером («АБ-С-ИТ-2020»)
        String number = ref.find() ? ref.group(1) : firstGroup(CONTRACT_ALNUM, text);
        if (number.isEmpty()) {
            number = firstGroup(CONTRACT_ALNUM, name);
        }
        contract.put("номер", number.isEmpty() ? firstGroup(FILE_NUMBER, name) : number);
        String signed = firstGroup(CONTRACT_SIGNED, text);
        contract.put("дата", signed.isEmpty() ? latestStamp(text) : signed);
        contract.put("текст", limit(text));
        return contract;
    }

    /** Отчёт о выполненных работах: связки со спецификацией, договором, УПД, длинными номерами и суммами. */
    private static Map<String, Object> parseReport(String name, String text) {
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("файл", name);
        report.put("спецификация", firstGroup(SPEC_REF, text));
        report.put("договор", firstGroup(CONTRACT_REF_CI, text));
        report.put("упд", firstGroup(REPORT_UPD, text));
        report.put("заказы", orderNumbers(text));
        report.put("суммы", amounts(text));
        report.put("текст", limit(text));
        return report;
    }

    static List<String> amounts(String text) {
        Set<String> amounts = new LinkedHashSet<>();
        Matcher m = AMOUNT.matcher(text);
        while (m.find()) {
            amounts.add(m.group(1).replace(" ", "") + "." + m.group(2));
        }
        return new ArrayList<>(amounts);
    }

    private static List<String> orderNumbers(String text) {
        Set<String> numbers = new LinkedHashSet<>();
        Matcher m = ORDER_REF.matcher(text);
        while (m.find()) {
            numbers.add(m.group(1));
        }
        return new ArrayList<>(numbers);
    }

    static String limit(String text) {
        return text.length() > TEXT_LIMIT ? text.substring(0, TEXT_LIMIT) : text;
    }

    private static String latestStamp(String text) {
        LocalDate latest = null;
        Matcher m = SIGN_STAMP.matcher(text);
        while (m.find()) {
            LocalDate d = parseDate(m.group(1));
            if (d != null && (latest == null || d.isAfter(latest))) {
                latest = d;
            }
        }
        return latest == null ? "" : latest.format(DATE);
    }

    // ------------------------------------------------------------------ строки

    /**
     * Строки Формы 3 по реестру документов и критериям Шага 1 (см. {@link Form3Rows}).
     *
     * @param op           конфиг операции ({@code "заказчики_в_рейтинге"} — regex)
     * @param registryJson реестр из «реестр_документов»
     * @param criteriaText текст выверенных критериев (строки «Критерий | Значение | …»)
     * @return JSON-массив строк
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText) {
        return rows(op, registryJson, criteriaText, "");
    }

    /**
     * То же с исходной формой участника ({@code "форма_из_узла"}): строки формы
     * подсказывают, какая спецификация относится к УПД, когда по сумме этапа
     * подходят несколько или ни одной.
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText, String formLines) {
        return rows(op, registryJson, criteriaText, formLines, "");
    }

    /**
     * То же с шапкой исходной формы ({@code "шапка_из_узла"}): при наличии шапки
     * форма первична — строки заключения строятся по строкам формы участника.
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText, String formLines,
                       String headerLine) {
        List<Map<String, Object>> built = Form3Rows.build(op, parseRegistry(registryJson), Criteria.parse(normalize(criteriaText)),
                normalize(formLines), normalize(headerLine));
        Form3Rows.denyWithoutContract(op, built);
        return toJson(built);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> parseRegistry(String text) {
        // первый разбираемый JSON-объект входа (общий разбор LlmJson: строго, терпимо, с починкой запятых)
        LlmJson.Selection selection = LlmJson.first(text, LlmJson.OBJECT);
        LlmJson.Parsed block = selection.first();
        if (block == null && selection.lastError() == null) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: во входе нет реестра документов");
        }
        if (block == null) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: реестр не разобран: " + selection.lastError());
        }
        return (Map<String, Object>) block.value();
    }

    /**
     * Название вида «Go (Golang)» ищется по любому из вариантов и общепринятых
     * сокращений (JavaScript → JS), границы — не буквы.
     */
    static boolean containsTechnology(String text, String technology) {
        String cleaned = technology.replace(")", "").replace("(", " ").strip();
        List<String> variants = new ArrayList<>(List.of(cleaned.split("\\s+|/")));
        for (String variant : List.copyOf(variants)) {
            String synonym = TECH_SYNONYMS.get(variant.toLowerCase(Locale.ROOT));
            if (synonym != null) {
                variants.add(synonym);
            }
        }
        for (String variant : variants) {
            if (variant.length() < 2) {
                continue;
            }
            String roleGuard = METHODOLOGY.matcher(variant).matches() ? ROLE_BEFORE : "";
            Pattern p = Pattern.compile(roleGuard + "(?<![A-Za-zА-Яа-я0-9])" + Pattern.quote(variant) + "(?![A-Za-zА-Яа-я0-9])",
                    Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            if (p.matcher(text).find()) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ критерии

    /** Выверенные критерии Шага 1: периоды, технологии по лотам, признак мобильной закупки. */
    static final class Criteria {
        private static final Pattern PERIOD_QUAL = Pattern.compile(
                "(?m)^Период опыта участника по квалификационным требованиям\\s*[—-]\\s*календарные даты\\s*\\|\\s*"
                        + "с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern PERIOD_METHOD = Pattern.compile(
                "(?m)^Период опыта по методике оценки\\s*[—-]\\s*календарные даты\\s*\\|\\s*"
                        + "с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern QUAL_TEXT = Pattern.compile(
                "(?m)^Период опыта участника по квалификационным требованиям\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern METHOD_TEXT = Pattern.compile("(?m)^Период опыта по методике оценки\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern START_DATE = Pattern.compile(
                "(?m)^Дата начала срока подачи заявок\\s*\\|\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern SPAN = Pattern.compile(
                "(\\d{1,3})\\s*(?:\\([^)]*\\))?\\s*(год|лет|месяц)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        private static final Pattern LOT = Pattern.compile("^ЛОТ\\s*№\\s*(\\d+)\\s*\\((Квалификационн|Методическ)");
        private static final Pattern TECH = Pattern.compile("^Технология\\s*\\d+\\s*\\|\\s*([^|]+?)\\s*\\|");
        private static final Pattern MOBILE = Pattern.compile(
                "(?m)^Признак\\s*[«\"]?Мобильная разработка[»\"]?\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern MOBILE_EXCLUDED = Pattern.compile(
                "не\\s+засчит|не\\s+учит|исключ|не\\s+принима|не\\s+являет", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        private static final Pattern MOBILE_SUBJECT = Pattern.compile(
                "закупа|предмет|засчит|являет|учитыва|требует", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

        LocalDate qualFrom;
        LocalDate qualTo;
        LocalDate methodFrom;
        LocalDate methodTo;
        boolean mobileProcurement;
        final Map<String, List<String>> lots = new LinkedHashMap<>();
        private final Map<String, List<String>> methodLots = new LinkedHashMap<>();

        static Criteria parse(String text) {
            Criteria c = new Criteria();
            LocalDate start = parseDate(firstGroup(START_DATE, text));
            Matcher q = PERIOD_QUAL.matcher(text);
            if (q.find()) {
                c.qualFrom = parseDate(q.group(1));
                c.qualTo = parseDate(q.group(2));
            } else if (start != null) {
                c.qualFrom = minusSpan(start, firstGroup(QUAL_TEXT, text));
                c.qualTo = c.qualFrom == null ? null : start;
            }
            Matcher m = PERIOD_METHOD.matcher(text);
            if (m.find()) {
                c.methodFrom = parseDate(m.group(1));
                c.methodTo = parseDate(m.group(2));
            } else if (start != null) {
                c.methodFrom = minusSpan(start, firstGroup(METHOD_TEXT, text));
                c.methodTo = c.methodFrom == null ? null : start;
            }
            String mobile = firstGroup(MOBILE, text);
            c.mobileProcurement = !mobile.isEmpty() && !MOBILE_EXCLUDED.matcher(mobile).find()
                    && MOBILE_SUBJECT.matcher(mobile).find();
            c.parseLots(text);
            return c;
        }

        /** Начало периода: дата начала подачи заявок минус «N (…) лет/месяцев» из текста критерия. */
        private static LocalDate minusSpan(LocalDate start, String periodText) {
            Matcher span = SPAN.matcher(periodText);
            if (!span.find()) {
                return null;
            }
            int n = Integer.parseInt(span.group(1));
            return span.group(2).toLowerCase(Locale.ROOT).startsWith("месяц") ? start.minusMonths(n) : start.minusYears(n);
        }

        private void parseLots(String text) {
            String lot = null;
            boolean qualification = true;
            for (String line : text.split("\n")) {
                Matcher head = LOT.matcher(line.strip());
                if (head.find()) {
                    lot = head.group(1);
                    qualification = head.group(2).startsWith("Квалификац");
                    continue;
                }
                Matcher tech = TECH.matcher(line.strip());
                if (lot != null && tech.find() && !tech.group(1).toLowerCase(Locale.ROOT).startsWith("не указано")) {
                    (qualification ? lots : methodLots).computeIfAbsent(lot, k -> new ArrayList<>()).add(tech.group(1));
                }
            }
            for (Map.Entry<String, List<String>> e : methodLots.entrySet()) {
                lots.putIfAbsent(e.getKey(), e.getValue());
            }
        }

        List<String> allTechnologies() {
            Set<String> all = new LinkedHashSet<>();
            lots.values().forEach(all::addAll);
            return new ArrayList<>(all);
        }
    }

    // ------------------------------------------------------------------ утилиты

    static String firstGroup(Pattern p, String text) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1).strip() : "";
    }

    static LocalDate parseDate(String value) {
        try {
            return LocalDate.parse(value, DATE);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }

    static String str(Object value) {
        return value == null ? "" : String.valueOf(value).strip();
    }

    static String toJson(Object value) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать результат: " + e.getMessage());
        }
    }
}
