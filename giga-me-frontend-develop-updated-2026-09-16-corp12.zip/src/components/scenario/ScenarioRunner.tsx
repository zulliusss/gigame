import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  runScenario,
  continueScenarioStep,
  disableScenarioStepMode,
  cancelScenarioRun,
  downloadScenarioRunFile,
} from "@/api/scenarios";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/toast";
import {
  useScenarioStore,
  confirmLeaveEditor,
  type ExecStatus,
} from "@/stores/scenarioStore";
import { validateGraph } from "@/api/graphValidation";
import {
  CONNECTION_LOST_TYPE,
  runEventError,
  terminalRunStatus,
} from "@/api/runEvents";

interface ScenarioRunnerProps {
  scenarioId: string;
  onClose: () => void;
}

interface LogEntry {
  time: string;
  text: string;
  type: "info" | "start" | "done" | "error" | "iter";
  /** Полный текст (подсказка при наведении), если строка журнала обрезана */
  title?: string;
}

interface StepData {
  stepId?: string;
  nodeId: string;
  nodeLabel: string;
  nodeType: string;
  inputData?: { documents_text?: string; previous_output?: string };
  outputData?: { result?: string; error?: string };
  promptUsed?: string | null;
  stepIndex?: number;
  totalSteps?: number;
  tokensUsed?: number | null;
}

interface ScenarioEvent extends Record<string, unknown> {
  type?: string;
  data?: Record<string, unknown>;
  error?: string;
  count?: string;
}

function formatElapsed(startMs: number): string {
  const sec = Math.floor((Date.now() - startMs) / 1000);
  if (sec < 60) return `${sec}с`;
  return `${Math.floor(sec / 60)}м ${sec % 60}с`;
}

const now = () =>
  new Date().toLocaleTimeString("ru", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

export function ScenarioRunner({ scenarioId, onClose }: ScenarioRunnerProps) {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dirInputRef = useRef<HTMLInputElement>(null);
  const logEndRef = useRef<HTMLDivElement>(null);
  // startTime в ref: обработчик событий прогона создаётся один раз и замыкает
  // state — «завершён за 29765231м» (отсчёт с 1970) при чтении устаревшего 0
  const startTimeRef = useRef(0);
  // Текущий прогон: прерывание загрузки/чтения событий при закрытии панели
  // (AbortController для fetch и флаг для цикла событий); done — прогон
  // завершён и после размонтирования сбрасывать бейджи канваса не нужно
  const runCtlRef = useRef<{ controller: AbortController; done: boolean } | null>(null);
  const setExecStatus = useScenarioStore((s) => s.setExecStatus);
  const resetExecStatuses = useScenarioStore((s) => s.resetExecStatuses);
  const [files, setFiles] = useState<File[]>([]);
  const [phase, setPhase] = useState<
    "idle" | "uploading" | "running" | "paused" | "done" | "error"
  >("idle");
  // Причина ошибки для баннера: отказ в запуске, последняя ошибка узла, обрыв соединения
  const [errorText, setErrorText] = useState<string | null>(null);
  const [log, setLog] = useState<LogEntry[]>([]);
  const [progress, setProgress] = useState({ step: 0, total: 0 });
  const [startTime, setStartTime] = useState<number>(0);
  const [elapsed, setElapsed] = useState("");
  const [result, setResult] = useState<string | null>(null);
  const [runId, setRunId] = useState<string | null>(null);
  // content задан у старых кадров (base64/текст в WS); новые несут только
  // file_ready — байты качаются ручкой /runs/{runId}/files/{nodeId}
  const [savedFiles, setSavedFiles] = useState<
    {
      nodeLabel: string;
      filename: string;
      content?: string;
      mimeType: string;
      nodeId?: string;
    }[]
  >([]);
  const [stepMode, setStepMode] = useState(false);
  const [currentStep, setCurrentStep] = useState<StepData | null>(null);
  const [stepHistory, setStepHistory] = useState<StepData[]>([]);
  const totalTokens = stepHistory.reduce(
    (sum, s) => sum + (s.tokensUsed || 0),
    0
  );

  useEffect(() => {
    if (!startTime) return;
    const iv = setInterval(() => {
      if (phase === "uploading" || phase === "running" || phase === "paused") {
        setElapsed(formatElapsed(startTime));
      }
    }, 1000);
    return () => clearInterval(iv);
  }, [phase, startTime]);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [log]);

  // Размонтирование панели во время прогона: загрузка и чтение событий
  // прерываются, команда run не уходит, бейджи канваса не застывают
  useEffect(() => {
    return () => {
      const ctl = runCtlRef.current;
      if (ctl && !ctl.done) {
        ctl.controller.abort();
        resetExecStatuses();
      }
    };
  }, [resetExecStatuses]);

  const addLog = (
    text: string,
    type: LogEntry["type"] = "info",
    title?: string
  ) => {
    setLog((prev) => [...prev, { time: now(), text, type, title }]);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files)
      setFiles((prev) => [...prev, ...Array.from(e.target.files!)]);
    // if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const SUPPORTED = [
    ".pdf",
    ".docx",
    ".xlsx",
    ".xls",
    ".txt",
    ".xml",
    ".zip",
    ".7z",
  ];

  /** Выбор папки в браузере: добавляются все поддерживаемые файлы из неё и подкаталогов. */
  const handleDirChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const all = Array.from(e.target.files);
    const supported = all.filter((f) =>
      SUPPORTED.some((ext) => f.name.toLowerCase().endsWith(ext))
    );
    setFiles((prev) => [...prev, ...supported]);
    if (supported.length < all.length) {
      addLog(
        `Из папки добавлено ${supported.length} файл(ов), пропущено ${
          all.length - supported.length
        } неподдерживаемых`,
        "info"
      );
    }
    e.target.value = "";
  };

  // Отказ ручки continue/disable-step-mode (403/404, шлюз): фаза возвращается
  // в паузу, причина — тостом; раньше панель навсегда оставалась «running»
  const handleContinue = async () => {
    if (!runId) return;
    setPhase("running");
    try {
      await continueScenarioStep(runId);
    } catch (e) {
      console.error(e);
      setPhase("paused");
      toast(
        `Не удалось продолжить шаг: ${e instanceof Error ? e.message : "неизвестная ошибка"}`,
        "error"
      );
    }
  };

  const handleSkipStepMode = async () => {
    if (!runId) return;
    setPhase("running");
    try {
      await disableScenarioStepMode(runId);
    } catch (e) {
      console.error(e);
      setPhase("paused");
      toast(
        `Не удалось выключить пошаговый режим: ${e instanceof Error ? e.message : "неизвестная ошибка"}`,
        "error"
      );
    }
  };

  const handleRun = async () => {
    if (files.length === 0) return;
    // Проверка графа до запуска: на сервере выполняется сохранённая версия,
    // но нарушения меток рёбер If/Switch и названий узлов роняют прогон
    // (или молча пропускают ветки) — лучше показать нарушителя сейчас
    const { nodes, edges, focusElement } = useScenarioStore.getState();
    const issue = validateGraph(nodes, edges);
    if (issue) {
      focusElement(issue.nodeId, issue.edgeId);
      toast(issue.message, "error");
      return;
    }
    const ctl = { controller: new AbortController(), done: false };
    runCtlRef.current = ctl;
    const aborted = () => ctl.controller.signal.aborted;
    setPhase("uploading");
    setErrorText(null);
    setLog([]);
    setResult(null);
    setRunId(null);
    setProgress({ step: 0, total: 0 });
    setStartTime(Date.now());
    startTimeRef.current = Date.now();
    setCurrentStep(null);
    setStepHistory([]);
    resetExecStatuses();

    addLog(`Загрузка ${files.length} файл(ов) на сервер...`, "info");

    // Фаза после цикла: терминальный STATUS переводит в done/error; если
    // поток закрылся без него — прогон не считаем выполняющимся
    let terminal = false;

    try {
      for await (const event of runScenario(
        scenarioId,
        files,
        stepMode,
        ctl.controller.signal
      )) {
        if (aborted()) break;
        const scenarioEvent = event as ScenarioEvent;
        const eventData = (scenarioEvent.data ?? {}) as Record<string, unknown>;

        // кадр `{session_id, error}` без type: документы ещё обрабатываются,
        // сценарий не найден, нет доступа — раньше панель висела в «Запуск...»
        const commandError = runEventError(scenarioEvent);
        if (commandError) {
          terminal = true;
          setPhase("error");
          setErrorText(commandError);
          addLog(`Ошибка: ${commandError}`, "error");
          continue;
        }

        if (scenarioEvent.type === CONNECTION_LOST_TYPE) {
          terminal = true;
          const message = String(scenarioEvent.error ?? "Соединение потеряно");
          if (eventData.run_id) setRunId(eventData.run_id as string);
          setPhase("error");
          setErrorText(message);
          addLog(message, "error");
          continue;
        }

        if (scenarioEvent.type === "upload_processing") {
          const message =
            (eventData.message as string | undefined) ??
            `документы обрабатываются на сервере (${eventData.files} файл(ов))`;
          addLog(`⏳ ${message}...`, "info");
        }

        if (scenarioEvent.type === "upload_warning") {
          addLog(`⚠ ${eventData.message}`, "info");
        }

        if (scenarioEvent.type === "UPLOAD_DONE") {
          setPhase("running");
          addLog(`✓ Загружено ${scenarioEvent.count} файл(ов)`, "done");
          setProgress({ step: 0, total: 0 });
        }

        if (scenarioEvent.type === "STATUS") {
          if (eventData.run_id) setRunId(eventData.run_id as string);
          const statusValue = terminalRunStatus(scenarioEvent);
          if (statusValue === "COMPLETED") {
            terminal = true;
            setPhase("done");
            if (eventData.result) setResult(eventData.result as string);
            addLog(
              `Сценарий завершён за ${formatElapsed(startTimeRef.current)}`,
              "done"
            );
          } else if (statusValue === "FAILED") {
            terminal = true;
            setPhase("error");
            // прогон с ошибками узлов (on_error=continue/branch) завершается FAILED, но итог сохранён — показываем его
            if (eventData.result) setResult(eventData.result as string);
            // причина отказа в запуске (неизвестная операция в узле и т.п.) приходит в data.error;
            // при завершении с ошибками узлов её нет — в баннере остаётся последняя ошибка узла
            const reason =
              (eventData.error as string | undefined) ??
              (scenarioEvent as { error?: string }).error;
            if (reason) setErrorText(reason);
            addLog(
              reason
                ? `Сценарий завершился с ошибкой: ${reason}`
                : "Сценарий завершился с ошибкой",
              "error"
            );
          }
        }

        if (scenarioEvent.type === "NODE_STATUS") {
          const label =
            (eventData.node_label as string) || (eventData.node_id as string);
          const nodeId = eventData.node_id as string;
          const status = eventData.status as string;
          const step = eventData.step as number;
          const total = eventData.total as number;
          if (step && total) setProgress({ step, total });

          // Update visual status on canvas - convert to lowercase for ExecStatus
          const lowerStatus = status.toLowerCase() as ExecStatus;
          if (
            nodeId &&
            (lowerStatus === "running" ||
              lowerStatus === "completed" ||
              lowerStatus === "failed" ||
              lowerStatus === "skipped")
          ) {
            setExecStatus(nodeId, lowerStatus);
          }

          if (lowerStatus === "running") {
            addLog(`► ${label}`, "start");
          } else if (lowerStatus === "completed") {
            addLog(`✓ ${label}`, "done");
          } else if (lowerStatus === "skipped") {
            addLog(`⊘ ${label} — пропущено`, "info");
          } else if (lowerStatus === "failed") {
            const err = (eventData.error as string) || "Неизвестная ошибка";
            // строка журнала обрезана, полный текст — в подсказке и баннере
            addLog(
              `✗ ${label} — ${err.slice(0, 80)}${err.length > 80 ? "…" : ""}`,
              "error",
              err
            );
            setErrorText(`${label}: ${err}`);
          }
        }

        if (scenarioEvent.type === "STEP_COMPLETE") {
          const stepData: StepData = {
            stepId: eventData.step_id as string,
            nodeId: eventData.node_id as string,
            nodeLabel:
              (eventData.node_label as string) || (eventData.node_id as string),
            nodeType: (eventData.node_type as string) || "unknown",
            inputData: eventData.input_data as StepData["inputData"],
            outputData: eventData.output_data as StepData["outputData"],
            promptUsed: eventData.prompt_used as string | null,
            stepIndex: eventData.step_index as number,
            totalSteps: eventData.total_steps as number,
            tokensUsed: eventData.tokens_used as number | null,
          };
          setCurrentStep(stepData);
          setStepHistory((prev) => [...prev, stepData]);
        }

        if (scenarioEvent.type === "STEP_PAUSED") {
          setPhase("paused");
          const pausedNodeId = eventData.node_id as string;
          if (pausedNodeId) setExecStatus(pausedNodeId, "paused");
        }

        if (scenarioEvent.type === "SWITCH_RESULT") {
          const rule = eventData.matched_rule as string;
          const lbl = (eventData.node_label as string) || "Switch";
          addLog(`🔀 ${lbl} → "${rule}"`, "iter");
        }

        if (scenarioEvent.type === "IF_RESULT") {
          const branch = eventData.branch as string;
          const met = eventData.condition_met as boolean;
          const lbl = (eventData.node_label as string) || "If";
          addLog(
            `${met ? "✅" : "❌"} ${lbl} → ${branch}`,
            met ? "done" : "info"
          );
        }

        if (scenarioEvent.type === "RAG_SEARCH") {
          const lbl = (eventData.node_label as string) || "";
          const count = eventData.chunks_found as number;
          addLog(
            `  📚 ${lbl}: RAG нашёл ${count} фрагмент(ов) в базе знаний`,
            "iter"
          );
        }

        if (scenarioEvent.type === "PROCESSING_PROGRESS") {
          // живая трассировка агента: план, мысли, поиски, чтения, валидация
          const detail = (eventData.detail as string) || "";
          const lbl = (eventData.node_label as string) || "";
          if (detail) {
            addLog(`  🤖 ${lbl}: ${detail}`, "info");
          }
        }

        if (scenarioEvent.type === "LOOP_PROGRESS") {
          const detail = (eventData.detail as string) || "";
          if (detail) {
            addLog(
              `  📄 Документ ${eventData.iteration}/${eventData.total}: ${detail}`,
              "info"
            );
          } else {
            addLog(
              `  🔄 Итерация ${eventData.iteration}/${eventData.total}`,
              "iter"
            );
          }
        }

        if (event.type === "FILE_OUTPUT") {
          const nodeLabel =
            (eventData.node_label as string) ||
            (eventData.node_id as string) ||
            "";
          const filename = (eventData.filename as string) || "result.txt";
          const content = (eventData.content as string) || "";
          const mimeType = eventData.mime_type as string;
          const note = nodeLabel ? `${nodeLabel}: ` : "";
          addLog(
            `  📄 ${note}${filename}${
              mimeType === "text/plain" ? "" : ` (${mimeType})`
            }`,
            "info"
          );
          const fileNodeId = (eventData.node_id as string) || "";
          if (content) {
            setSavedFiles((prev) => [
              ...prev,
              { nodeLabel, filename, content, mimeType },
            ]);
          } else if (eventData.file_ready && fileNodeId) {
            setSavedFiles((prev) => [
              ...prev,
              { nodeLabel, filename, mimeType, nodeId: fileNodeId },
            ]);
          }
        }
      }
      // страховка: поток закрылся без терминального кадра — фаза не должна
      // остаться активной («Запуск...» навсегда)
      if (!terminal && !aborted()) {
        setPhase("error");
        setErrorText("Поток событий прогона закрылся без итогового статуса");
        addLog(
          "Поток событий закрылся без итогового статуса — состояние прогона смотрите в «Подробном отчёте»",
          "error"
        );
      }
    } catch (err) {
      // прерывание пользователем (закрытие панели) — не ошибка
      if (aborted() || (err instanceof Error && err.name === "AbortError")) {
        return;
      }
      setPhase("error");
      const message = err instanceof Error ? err.message : "Неизвестная";
      setErrorText(message);
      addLog(`Ошибка: ${message}`, "error");
    } finally {
      ctl.done = true;
    }
  };

  const isActive =
    phase === "uploading" || phase === "running" || phase === "paused";

  return (
    <div className="w-full h-full bg-card border-l border-border flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <h3 className="text-sm font-semibold">
          {phase === "paused" ? "⏸ Пауза (отладка)" : "Запуск"}
        </h3>
        <div className="flex items-center gap-2">
          {totalTokens > 0 && (
            <span
              className="text-[10px] text-[#7b1fa2] font-mono bg-[#7b1fa2]/10 rounded-md px-1.5 py-0.5"
              title="Суммарный расход токенов GigaChat за прогон"
            >
              🪙 {totalTokens.toLocaleString("ru-RU")}
            </span>
          )}
          {isActive && (
            <span className="text-[10px] text-muted-foreground font-mono bg-accent rounded-md px-1.5 py-0.5">
              {elapsed}
            </span>
          )}
          <button
            onClick={() => {
              // активный прогон: крестик останавливает его на бэкенде,
              // иначе выполнение продолжится и после закрытия панели;
              // в фазе загрузки — прерывает загрузку, команда run не уйдёт
              if (isActive) {
                const question = runId
                  ? "Прогон ещё выполняется. Остановить его?"
                  : "Загрузка документов ещё идёт. Прервать её и закрыть панель?";
                if (!window.confirm(question)) {
                  return;
                }
                if (runId) {
                  cancelScenarioRun(runId).catch(() => undefined);
                }
                runCtlRef.current?.controller.abort();
                // события прогона больше не читаются — бейджи «выполняется»
                // на канвасе иначе застынут навсегда
                resetExecStatuses();
              }
              onClose();
            }}
            title={isActive ? "Остановить прогон и закрыть" : "Закрыть"}
            className="w-6 h-6 rounded-lg hover:bg-accent flex items-center justify-center text-muted-foreground hover:text-foreground"
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {/* Progress bar */}
        {isActive && (
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] text-muted-foreground">
                {phase === "uploading"
                  ? "Загрузка файлов..."
                  : progress.total > 0
                  ? `Шаг ${progress.step} из ${progress.total}`
                  : "Запуск..."}
              </span>
              {progress.total > 0 && (
                <span className="text-[11px] text-muted-foreground">
                  {Math.round((progress.step / progress.total) * 100)}%
                </span>
              )}
            </div>
            <div className="h-1.5 bg-accent rounded-full overflow-hidden">
              {phase === "uploading" ? (
                <div className="h-full bg-[#1976d2] rounded-full animate-pulse w-full opacity-40" />
              ) : (
                <div
                  className={`h-full rounded-full transition-all duration-700 ${
                    phase === "paused" ? "bg-[#ff9800]" : "bg-[#21a038]"
                  }`}
                  style={{
                    width:
                      progress.total > 0
                        ? `${(progress.step / progress.total) * 100}%`
                        : "10%",
                  }}
                />
              )}
            </div>
          </div>
        )}

        {/* Current step inspector (debug mode) */}
        {currentStep && (phase === "paused" || phase === "running") && (
          <div className="border-2 border-[#ff9800]/40 rounded-xl bg-[#ff9800]/5 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-[10px] text-muted-foreground uppercase">
                  Шаг {currentStep.stepIndex}/{currentStep.totalSteps} ·{" "}
                  {currentStep.nodeType}
                </div>
                <div className="text-sm font-semibold text-foreground">
                  {currentStep.nodeLabel}
                </div>
              </div>
              {phase === "paused" && (
                <span className="text-[10px] bg-[#ff9800] text-white rounded px-1.5 py-0.5 font-medium">
                  PAUSED
                </span>
              )}
            </div>

            {/* Input */}
            {currentStep.inputData &&
              (currentStep.inputData.documents_text ||
                currentStep.inputData.previous_output) && (
                <details className="text-[11px]" open={phase === "paused"}>
                  <summary className="cursor-pointer font-medium text-[#1976d2]">
                    📥 Входные данные
                  </summary>
                  <div className="mt-1 space-y-1">
                    {currentStep.inputData.previous_output && (
                      <div>
                        <div className="text-[10px] text-muted-foreground mb-0.5">
                          Результат предыдущего шага:
                        </div>
                        <pre className="bg-background border border-border rounded p-1.5 max-h-32 overflow-auto whitespace-pre-wrap text-[10px]">
                          {currentStep.inputData.previous_output.slice(0, 800)}
                          {currentStep.inputData.previous_output.length > 800
                            ? "\n... (обрезано)"
                            : ""}
                        </pre>
                      </div>
                    )}
                    {currentStep.inputData.documents_text && (
                      <div>
                        <div className="text-[10px] text-muted-foreground mb-0.5">
                          Документы (полный текст):
                        </div>
                        <pre className="bg-background border border-border rounded p-1.5 max-h-24 overflow-auto whitespace-pre-wrap text-[10px]">
                          {currentStep.inputData.documents_text.slice(0, 400)}
                          {currentStep.inputData.documents_text.length > 400
                            ? "\n... (" +
                              currentStep.inputData.documents_text.length +
                              " симв)"
                            : ""}
                        </pre>
                      </div>
                    )}
                  </div>
                </details>
              )}

            {/* Prompt */}
            {currentStep.promptUsed && (
              <details className="text-[11px]" open={phase === "paused"}>
                <summary className="cursor-pointer font-medium text-[#7b1fa2]">
                  📝 Промпт в GigaChat
                </summary>
                <pre className="mt-1 bg-background border border-border rounded p-1.5 max-h-32 overflow-auto whitespace-pre-wrap text-[10px]">
                  {currentStep.promptUsed.slice(0, 1000)}
                  {currentStep.promptUsed.length > 1000
                    ? "\n... (обрезано)"
                    : ""}
                </pre>
              </details>
            )}

            {/* Output */}
            {currentStep.outputData?.result && (
              <details className="text-[11px]" open={phase === "paused"}>
                <summary className="cursor-pointer font-medium text-[#21a038]">
                  📤 Результат
                </summary>
                <pre className="mt-1 bg-background border border-border rounded p-1.5 max-h-40 overflow-auto whitespace-pre-wrap text-[10px]">
                  {currentStep.outputData.result.slice(0, 1500)}
                  {currentStep.outputData.result.length > 1500
                    ? "\n... (обрезано)"
                    : ""}
                </pre>
              </details>
            )}

            {/* Pause controls */}
            {phase === "paused" && (
              <div className="flex gap-2 pt-1">
                <Button
                  size="sm"
                  className="flex-1 rounded-xl bg-[#ff9800] hover:bg-[#f57c00] text-xs"
                  onClick={handleContinue}
                >
                  Далее →
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-xl text-xs"
                  onClick={handleSkipStepMode}
                >
                  ⏩ До конца
                </Button>
              </div>
            )}
          </div>
        )}

        {/* Done / Error banner */}
        {phase === "done" && (
          <div className="bg-[#21a038]/10 text-[#21a038] rounded-xl px-3 py-2 text-xs font-medium flex items-center gap-2">
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
            >
              <path d="M20 6L9 17l-5-5" />
            </svg>
            Выполнено за {elapsed}
          </div>
        )}
        {phase === "error" && (
          <div className="bg-destructive/10 text-destructive rounded-xl px-3 py-2 text-xs font-medium flex items-center gap-2">
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
            <span className="min-w-0 break-words" title={errorText ?? undefined}>
              Ошибка выполнения
              {errorText ? `: ${errorText}` : ""}
            </span>
          </div>
        )}

        {/* Log */}
        {log.length > 0 && (
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1.5">
              Лог
            </label>
            <div className="space-y-0.5 text-[11px] font-mono bg-background rounded-xl p-2.5 border border-border max-h-72 overflow-y-auto">
              {log.map((entry, i) => (
                <div
                  key={i}
                  title={entry.title}
                  className={`leading-relaxed ${
                    entry.type === "done"
                      ? "text-[#21a038]"
                      : entry.type === "error"
                      ? "text-destructive"
                      : entry.type === "start"
                      ? "text-[#1976d2]"
                      : entry.type === "iter"
                      ? "text-[#00897b]"
                      : "text-muted-foreground"
                  }`}
                >
                  <span className="text-muted-foreground/60">{entry.time}</span>{" "}
                  {entry.text}
                </div>
              ))}
              <div ref={logEndRef} />
            </div>
          </div>
        )}

        {/* Uploading spinner when waiting for first event */}
        {phase === "uploading" && log.length === 0 && (
          <div className="flex flex-col items-center py-6 text-muted-foreground gap-2">
            <div className="w-7 h-7 border-2 border-[#21a038] border-t-transparent rounded-full animate-spin" />
            <p className="text-xs">Подключение к серверу...</p>
          </div>
        )}

        {/* Result */}
        {result && (
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1.5">
              Результат
            </label>
            <div className="text-xs bg-accent rounded-xl p-3 max-h-48 overflow-y-auto whitespace-pre-wrap text-foreground leading-relaxed">
              {result.slice(0, 600)}
              {result.length > 600 ? "..." : ""}
            </div>
          </div>
        )}

        {/* Saved files */}
        {savedFiles.length > 0 && (
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1.5">
              Сохранённые файлы ({savedFiles.length})
            </label>
            <div className="space-y-1 max-h-44 overflow-y-auto">
              {savedFiles.map((f, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 text-[11px] bg-accent rounded-lg px-2.5 py-1.5"
                >
                  <svg
                    width="12"
                    height="12"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#00897b"
                    strokeWidth="2"
                    className="flex-shrink-0"
                  >
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                  </svg>
                  <span className="truncate flex-1">
                    {f.nodeLabel ? `${f.nodeLabel} — ` : ""}
                    {f.filename}
                  </span>
                  <button
                    onClick={async () => {
                      try {
                        let blob: Blob;
                        if (f.content !== undefined) {
                          const binary =
                            f.mimeType === "text/plain"
                              ? f.content
                              : Uint8Array.from(atob(f.content), (c) =>
                                  c.charCodeAt(0)
                                );
                          blob = new Blob([binary], { type: f.mimeType });
                        } else {
                          if (!runId || !f.nodeId) return;
                          blob = await downloadScenarioRunFile(runId, f.nodeId);
                        }
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement("a");
                        a.href = url;
                        a.download = f.filename;
                        a.click();
                        URL.revokeObjectURL(url);
                      } catch {
                        addLog(`Не удалось скачать ${f.filename}`, "error");
                      }
                    }}
                    className="text-muted-foreground hover:text-foreground flex-shrink-0"
                    title="Скачать"
                  >
                    <svg
                      width="12"
                      height="12"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                    >
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                      <polyline points="7 10 12 15 17 10" />
                      <line x1="12" y1="15" x2="12" y2="3" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Files (idle) */}
        {phase === "idle" && (
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1.5">
              Документы
            </label>
            <div className="space-y-1 max-h-52 overflow-y-auto">
              {files.map((f, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 text-[11px] bg-accent rounded-lg px-2.5 py-1.5"
                >
                  <svg
                    width="12"
                    height="12"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#21a038"
                    strokeWidth="2"
                    className="flex-shrink-0"
                  >
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                  </svg>
                  <span className="truncate flex-1">{f.name}</span>
                  <button
                    onClick={() =>
                      setFiles((prev) => prev.filter((_, j) => j !== i))
                    }
                    className="text-muted-foreground hover:text-destructive flex-shrink-0"
                  >
                    <svg
                      width="10"
                      height="10"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2.5"
                    >
                      <line x1="18" y1="6" x2="6" y2="18" />
                      <line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-2">
              <Button
                size="sm"
                variant="outline"
                className="flex-1 rounded-xl text-xs"
                onClick={() => fileInputRef.current?.click()}
              >
                + Файлы
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1 rounded-xl text-xs"
                title="Все поддерживаемые файлы папки и её подкаталогов"
                onClick={() => dirInputRef.current?.click()}
              >
                + Папка
              </Button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".pdf,.docx,.xlsx,.xls,.txt,.xml,.zip,.7z"
              multiple
              onChange={handleFileChange}
              className="hidden"
            />
            <input
              ref={dirInputRef}
              type="file"
              multiple
              onChange={handleDirChange}
              className="hidden"
              {...({ webkitdirectory: "" } as Record<string, string>)}
            />

            {/* Debug mode toggle */}
            <label className="flex items-center gap-2 mt-3 px-1 cursor-pointer text-xs select-none">
              <input
                type="checkbox"
                checked={stepMode}
                onChange={(e) => setStepMode(e.target.checked)}
                className="w-3.5 h-3.5 rounded accent-[#ff9800]"
              />
              <span className="text-foreground">
                🐛 Пошаговый режим (отладка)
              </span>
            </label>
            {stepMode && (
              <p className="text-[10px] text-muted-foreground mt-1 px-1">
                Сценарий будет приостанавливаться после каждой ноды для проверки
                данных
              </p>
            )}
          </div>
        )}

        {/* Step history (after run, in step mode) */}
        {stepHistory.length > 0 && (phase === "done" || phase === "error") && (
          <details className="text-xs">
            <summary className="cursor-pointer font-medium text-muted-foreground">
              История шагов ({stepHistory.length})
            </summary>
            <div className="mt-2 space-y-1.5">
              {stepHistory.map((s, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentStep(s)}
                  className={`w-full text-left text-[10px] rounded-lg px-2 py-1.5 border transition-colors ${
                    currentStep?.stepId === s.stepId
                      ? "bg-[#ff9800]/10 border-[#ff9800]"
                      : "bg-background border-border hover:bg-accent"
                  }`}
                >
                  <span className="font-mono text-muted-foreground">
                    {s.stepIndex}/{s.totalSteps}
                  </span>{" "}
                  {s.nodeLabel}
                  {!!s.tokensUsed && (
                    <span className="float-right text-muted-foreground font-mono">
                      {s.tokensUsed.toLocaleString("ru-RU")} ток.
                    </span>
                  )}
                </button>
              ))}
            </div>
          </details>
        )}
      </div>

      {/* Bottom */}
      <div className="px-4 py-3 border-t border-border space-y-2">
        {phase === "idle" && (
          <Button
            className="w-full rounded-xl bg-[#00897b] hover:bg-[#00796b] text-xs"
            onClick={handleRun}
            disabled={files.length === 0}
          >
            <svg
              width="14"
              height="14"
              viewBox="0 0 24 24"
              fill="currentColor"
              className="mr-1.5"
            >
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
            Запустить{stepMode ? " (отладка)" : ""} ({files.length} файл.)
          </Button>
        )}
        {runId && (phase === "done" || phase === "error") && (
          <>
            <Button
              size="sm"
              variant="outline"
              className="w-full rounded-xl text-xs"
              onClick={() => {
                if (!confirmLeaveEditor()) return;
                navigate(`/scenarios/${scenarioId}/runs/${runId}`);
              }}
            >
              Подробный отчёт
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="w-full rounded-xl text-xs"
              onClick={() => {
                setPhase("idle");
                setErrorText(null);
                setLog([]);
                setSavedFiles([]);
                setResult(null);
                setProgress({ step: 0, total: 0 });
                setCurrentStep(null);
                setStepHistory([]);
              }}
            >
              Запустить снова
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
