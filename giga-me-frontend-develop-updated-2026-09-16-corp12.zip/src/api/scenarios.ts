import { fetchApi, apiErrorFromResponse, errorMessageFromBody } from './client';
import { BASE_URL} from './constants';
import { getScenarioWebSocketClient, type StreamEvent, type StreamEventCallback } from './websocket';
import { INITIAL_BATCH_BYTES, PayloadTooLargeError, totalBytes, uploadAdaptive } from './uploadSplit';
import { limitGraphForGateway } from './graphLimits';
import { CONNECTION_LOST_MESSAGE, CONNECTION_LOST_TYPE, isTerminalRunEvent } from './runEvents';

/** Дедлайн ожидания открытия WebSocket прогона. */
const WS_CONNECT_TIMEOUT_MS = 15_000;
/** Повторы опроса upload-status при сбое сети/шлюза и пауза между ними. */
const UPLOAD_STATUS_RETRIES = 3;
const UPLOAD_STATUS_RETRY_PAUSE_MS = 3_000;
/** Дедлайн опроса партии: ~2 мин на файл (сканы PDF через GigaChat), не меньше 15 мин. */
const UPLOAD_POLL_MIN_MS = 15 * 60 * 1000;
const UPLOAD_POLL_PER_FILE_MS = 2 * 60 * 1000;

/** Размер партии загрузки, который прошёл шлюз корп-контура (уменьшается после 413, живёт до перезагрузки страницы). */
let gatewayBatchBytes = INITIAL_BATCH_BYTES;

export interface Scenario {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
  /** Общий сценарий: виден и доступен всем пользователям */
  shared?: boolean;
  /** Текущий пользователь — владелец */
  is_owner?: boolean;
  /** Средний рейтинг 1..5 (null — оценок нет) */
  rating_avg?: number | null;
  /** Количество оценок */
  rating_count?: number;
  /** Оценка текущего пользователя */
  my_rating?: number | null;
  /** Количество запусков */
  runs_count?: number;
}

export interface ScenarioDetail extends Scenario {
  graph_data: {
    nodes: ScenarioNode[];
    edges: ScenarioEdge[];
  };
}

export interface ScenarioNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  data: Record<string, string>;
}

export interface ScenarioEdge {
  id: string;
  source: string;
  target: string;
}

// списковый GET /runs больше не возвращает result — полный результат
// только в детальной ручке GET /runs/{id} (экономия трафика через SOWA)
export interface ScenarioRun {
  id: string;
  scenario_id: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  input_document_ids: string[];
  started_at: string | null;
  completed_at: string | null;
}

export interface ScenarioRunStep {
  id: string;
  node_id: string;
  node_type: string;
  status: string;
  input_data: unknown;
  output_data: unknown;
  prompt_used: string | null;
  tokens_used: number | null;
  started_at: string | null;
  completed_at: string | null;
}

export interface ScenarioRunDetail extends ScenarioRun {
  result: { output: string } | null;
  steps: ScenarioRunStep[];
}

export function getScenarios(): Promise<Scenario[]> {
  return fetchApi('/scenarios');
}

export function getScenario(id: string): Promise<ScenarioDetail> {
  return fetchApi(`/scenarios/${id}`);
}

export function createScenario(
  name: string,
  description?: string,
  graphData?: unknown,
): Promise<Scenario> {
  return fetchApi('/scenarios', {
    method: 'POST',
    body: JSON.stringify({
      name,
      // пустое описание не отправляется: null шлюз может не пропустить, бэкенд трактует отсутствие ключа так же
      ...(description ? { description } : {}),
      graph_data: limitGraphForGateway(graphData || { nodes: [], edges: [] }),
    }),
  });
}

export function updateScenario(
  id: string,
  data: { name?: string; description?: string; graph_data?: unknown; shared?: boolean },
): Promise<Scenario> {
  // позиции/размеры узлов и температура — в пределах схемы шлюза SOWA, иначе PUT отклоняется целиком
  const body = data.graph_data === undefined ? data : { ...data, graph_data: limitGraphForGateway(data.graph_data) };
  return fetchApi(`/scenarios/${id}`, {
    method: 'PUT',
    body: JSON.stringify(body),
  });
}

export function rateScenario(id: string, rating: number): Promise<void> {
  return fetchApi(`/scenarios/${id}/rating`, {
    method: 'POST',
    body: JSON.stringify({ rating }),
  });
}

export function duplicateScenario(id: string): Promise<Scenario> {
  return fetchApi(`/scenarios/${id}/duplicate`, { method: 'POST' });
}

export function deleteScenario(id: string): Promise<void> {
  return fetchApi(`/scenarios/${id}`, { method: 'DELETE' });
}

export function getScenarioRuns(scenarioId: string): Promise<ScenarioRun[]> {
  return fetchApi(`/scenarios/${scenarioId}/runs`);
}

export function getScenarioRun(runId: string): Promise<ScenarioRunDetail> {
  return fetchApi(`/scenarios/runs/${runId}`);
}

export function continueScenarioStep(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/continue`, { method: 'POST' });
}

export interface ScenarioVersionMeta {
  version_no: number;
  name: string;
  created_at: string;
}

export function getScenarioVersions(id: string): Promise<ScenarioVersionMeta[]> {
  return fetchApi(`/scenarios/${id}/versions`);
}

export function restoreScenarioVersion(id: string, versionNo: number): Promise<Scenario> {
  return fetchApi(`/scenarios/${id}/versions/${versionNo}/restore`, { method: 'POST' });
}


/**
 * Возобновление упавшего прогона по WebSocket (команда type=resume):
 * возвращает id нового прогона из первого события. Выполнение идёт на сервере
 * независимо от соединения — после получения id сокет закрывается.
 */
export function resumeScenarioRun(runId: string): Promise<string | null> {
  const client = getScenarioWebSocketClient();
  return new Promise<string | null>((resolve, reject) => {
    let settled = false;
    const finish = (value: string | null, err?: Error) => {
      if (settled) return;
      settled = true;
      client.setOnMessage(null);
      client.disconnect();
      if (err) reject(err);
      else resolve(value);
    };
    client.setOnMessage(((event: Record<string, unknown>) => {
      const data = (event.data ?? {}) as Record<string, unknown>;
      if (typeof data.run_id === 'string') {
        finish(data.run_id);
      } else if (event.error || data.error) {
        finish(null, new Error(String(event.error ?? data.error)));
      }
    }) as StreamEventCallback);
    client.connect();
    // send ставит сообщение в очередь до открытия сокета
    client.send({ type: 'resume', run_id: runId } as unknown as StreamEvent);
    // если id не пришёл — возобновление всё равно могло запуститься; вернём null,
    // вызывающий код предложит обновить список прогонов
    setTimeout(() => finish(null), 30000);
  });
}

export function disableScenarioStepMode(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/disable-step-mode`, { method: 'POST' });
}

/** Остановить выполняющийся прогон: прерывается на границе текущего узла. */
export function cancelScenarioRun(runId: string): Promise<void> {
  return fetchApi(`/scenarios/runs/${runId}/cancel`, { method: 'POST' });
}

/** Скачать файл файлового выхода: WS-кадр несёт только file_ready, байты — здесь. */
export async function downloadScenarioRunFile(runId: string, nodeId: string): Promise<Blob> {
  const res = await fetch(`${BASE_URL}/scenarios/runs/${runId}/files/${encodeURIComponent(nodeId)}`);
  if (!res.ok) {
    throw await apiErrorFromResponse(res);
  }
  return res.blob();
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/** Ошибка прерывания прогона пользователем (закрытие панели): раннер её не показывает. */
function abortError(): Error {
  const error = new Error('Прогон прерван');
  error.name = 'AbortError';
  return error;
}

function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw abortError();
}

/** Ожидание открытия сокета с дедлайном: без него зависший handshake держал фазу «Загрузка» навсегда. */
function waitForConnection(
  client: ReturnType<typeof getScenarioWebSocketClient>,
  timeoutMs: number,
): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    const deadline = Date.now() + timeoutMs;
    const checkConnection = () => {
      const ws = client.getWs();
      if (client.isConnected()) {
        resolve();
      } else if (ws === null || ws.readyState === WebSocket.CLOSING || ws.readyState === WebSocket.CLOSED) {
        reject(new Error('WebSocket connection closed before established'));
      } else if (Date.now() > deadline) {
        reject(new Error(`сервер не открыл соединение за ${Math.round(timeoutMs / 1000)} с`));
      } else {
        setTimeout(checkConnection, 10);
      }
    };
    checkConnection();
  });
}

export async function* runScenario(
  scenarioId: string,
  files: File[],
  stepMode: boolean = false,
  signal?: AbortSignal,
): AsyncGenerator<Record<string, unknown>> {
  const client = getScenarioWebSocketClient();

  let cleanupDone = false;

  // Set up handlers before connecting
  const queue: Record<string, unknown>[] = [];

  const notify = (message: string) => {
    queue.push({ type: 'upload_processing', data: { type: 'upload_processing', message } });
  };

  // Хвосты СТАРОГО прогона (например, отложенная отмена, сработавшая на
  // границе узла) приходят в тот же WS-канал и раньше помечали живой новый
  // прогон «завершился с ошибкой». Фильтр: события до команды run — чужие;
  // после — STATUS с run_id другого прогона отбрасывается.
  let runSent = false;
  let myRunId: string | null = null;

  // Освобождение сокета: терминальный STATUS (COMPLETED/FAILED), кадр ошибки
  // без type, обрыв или ошибка — сокет закрывается, обработчики снимаются.
  // Кадры признака done не несут (ScenarioWebSocketHandler.createStreamEvent),
  // раньше генератор ждал его вечно, а сокеты копились до перезагрузки.
  const finish = () => {
    if (cleanupDone) return;
    cleanupDone = true;
    client.setOnMessage(null);
    client.setOnClose(null);
    client.disconnect();
  };

  const handleMessage = (event: Record<string, unknown>) => {
      console.log("Received message:", event);
    const data = (event.data ?? {}) as Record<string, unknown>;
    if (!runSent) {
      return; // события, пришедшие до нашей команды run — хвост старого прогона
    }
    const evRunId = typeof data.run_id === 'string' ? data.run_id : null;
    if (evRunId && myRunId === null) {
      myRunId = evRunId;
    }
    if (evRunId && myRunId && evRunId !== myRunId) {
      return; // событие другого прогона
    }
    queue.push(event);
    if (isTerminalRunEvent(event)) {
      finish();
    }
  };

  // Обрыв сокета во время активного прогона: сервер продолжает выполнение,
  // поток событий к этому сокету потерян — синтетический кадр вместо вечного
  // «Запуск...»; автопереподключение для сценарного клиента отключено
  const handleClose = () => {
    if (cleanupDone || !runSent) return;
    queue.push({
      type: CONNECTION_LOST_TYPE,
      error: CONNECTION_LOST_MESSAGE,
      data: { run_id: myRunId ?? undefined },
    });
    finish();
  };

  client.setOnMessage(handleMessage as StreamEventCallback);
  client.setOnClose(handleClose);

  // Connect if not already connected
  client.connect();

  try {
    await waitForConnection(client, WS_CONNECT_TIMEOUT_MS);
  } catch (error) {
    console.error('WebSocket connect error:', error);
    client.setOnMessage(null);
    client.setOnClose(null);
    throw new Error(
      `Не удалось подключиться к серверу${error instanceof Error ? `: ${error.message}` : ''}`,
    );
  }

  try {
    // Загрузка идёт параллельно с выдачей событий: ход разбора (upload_processing,
    // upload_warning) попадает в журнал сразу, а не после окончания загрузки —
    // на комплекте сканов (30 минут) журнал раньше молчал до самого конца.
    if (files && files.length > 0) {
      let uploadDone = false;
      let uploadError: unknown = null;
      uploadFiles(scenarioId, files)
        .then(() => {
          queue.push({ type: 'UPLOAD_DONE', count: files.length.toString() });
        })
        .catch((error: unknown) => {
          uploadError = error;
        })
        .finally(() => {
          uploadDone = true;
        });
      while (!uploadDone || queue.length > 0) {
        throwIfAborted(signal);
        if (queue.length > 0) {
          yield queue.shift()!;
        } else {
          await sleep(50);
        }
      }
      if (uploadError) {
        throw uploadError;
      }
    }

    // панель закрыта во время загрузки — команда run не отправляется
    throwIfAborted(signal);

    // сокет мог закрыться за время долгой загрузки (таймаут бездействия
    // шлюза) — переподключаемся до команды run, а не полагаемся на очередь
    if (!client.isConnected()) {
      client.connect();
      await waitForConnection(client, WS_CONNECT_TIMEOUT_MS);
    }

    // Send run request via WebSocket
    runSent = true;
    client.send({
      scenario_id: scenarioId,
//       files: formData,
      step_mode: stepMode,
    } as StreamEvent);

    // Yield events as they arrive
    while (!cleanupDone || queue.length > 0) {
      throwIfAborted(signal);
      if (queue.length > 0) {
        yield queue.shift()!;
      } else {
        // Wait a bit before checking again
        await sleep(10);
      }
    }
  } catch (error) {
    if (!(error instanceof Error && error.name === 'AbortError')) {
      console.error('Stream error:', error);
    }
    finish();
    throw error;
  } finally {
    // Ensure cleanup happens
    try {
      finish();
    } catch {
      // Ignore errors during cleanup
    }
  }
  // Upload files to the server and return document IDs.
  // Асинхронный режим: запрос лишь принимает байты (секунды — шлюзовые
  // таймауты не срабатывают), разбор идёт в фоне, прогресс опрашивается
  // короткими запросами upload-status. Лимиты на ОДИН запрос: у бэкенда —
  // 100 файлов и 100 МБ тела (max-request-size); у прокси корп-контура — свой
  // лимит тела, неизвестный фронту (SynGX отвечает 413). Партии до 30 МБ и
  // 100 файлов; на 413 партия делится, одиночный ZIP режется на части
  // (uploadSplit.ts), найденный размер запоминается до перезагрузки страницы.
  // Первая партия заменяет кэш документов, последующие уходят с append=true.
  async function uploadFiles(
    scenarioId: string,
    files: File[]
  ): Promise<void> {
    gatewayBatchBytes = await uploadAdaptive(
      files,
      (batch, append) => uploadBatch(scenarioId, batch, append),
      notify,
      gatewayBatchBytes,
    );
  }

  // Прерванная попытка (обрыв сети, отказ шлюза на одной из партий) оставляет
  // фоновый разбор прошлой партии работать — повторный клик «Запустить» ловил
  // 422 «Предыдущая загрузка ещё обрабатывается». Ждём освобождения сами.
  async function waitUploadIdle(scenarioId: string): Promise<void> {
    const deadline = Date.now() + 10 * 60 * 1000;
    while (Date.now() < deadline) {
      throwIfAborted(signal);
      try {
        const statusResponse = await fetch(BASE_URL + `/scenarios/${scenarioId}/upload-status`, { signal });
        if (statusResponse.ok) {
          const status = (await statusResponse.json()) as { status: string };
          if (status.status !== 'processing') {
            return;
          }
          notify('ожидание завершения предыдущей загрузки…');
        }
      } catch (error) {
        // сбой сети/шлюза (в т.ч. HTML вместо JSON) — ждём и опрашиваем снова
        if (signal?.aborted) throw error;
      }
      await sleep(2000);
    }
    throw new Error('Предыдущая загрузка документов не завершилась за 10 минут');
  }

  async function uploadBatch(
    scenarioId: string,
    files: File[],
    append: boolean
  ): Promise<void> {
    const formData = new FormData();
    formData.append('content', ''); // Empty content placeholder
    for (const file of files) {
      formData.append('files', file);
    }

    const query = append ? '?async=true&append=true' : '?async=true';
    const post = () =>
      fetch(BASE_URL + `/scenarios/${scenarioId}/upload${query}`, {
        method: 'POST',
        body: formData,
        signal,
      });
    let response: Response;
    try {
      response = await post();
    } catch (error) {
      // сетевой сбой первой партии: append=false заменяет кэш — повтор безопасен;
      // добавочную партию не повторяем (документы могли уже попасть в кэш)
      if (append || signal?.aborted) throw error;
      notify('сетевой сбой при отправке партии — повтор через 3 с…');
      await sleep(UPLOAD_STATUS_RETRY_PAUSE_MS);
      response = await post();
    }

    if (response.status === 422) {
      const busyText = await response.clone().text();
      if (busyText.includes('обрабатывается')) {
        await waitUploadIdle(scenarioId);
        response = await post();
      }
    }

    if (response.status === 413) {
      // прокси отклонил тело по размеру ещё до бэкенда — кэш не тронут, партию можно переслать частями
      throw new PayloadTooLargeError(totalBytes(files));
    }

    if (!response.ok) {
      // бэкенд кладёт причину (лимит документов, битый архив и т.п.) в тело —
      // без неё пользователь видит голый код и не может понять, что чинить;
      // HTML-страница шлюза вместо JSON — «Шлюз вернул N без JSON»
      let detail = '';
      try {
        const text = await response.text();
        detail = errorMessageFromBody(response.status, response.statusText, text);
      } catch {
        // тело недоступно — остаётся только код
      }
      throw new Error(
        `Ошибка загрузки (${response.status})${detail ? `: ${detail.slice(0, 300)}` : ''}`
      );
    }

    // Поллинг фоновой задачи разбора до done/failed: сбой одного опроса
    // (сеть, 502 шлюза, HTML вместо JSON) повторяется, дедлайн — по числу файлов
    const pollBudgetMs = Math.max(UPLOAD_POLL_MIN_MS, files.length * UPLOAD_POLL_PER_FILE_MS);
    const pollDeadline = Date.now() + pollBudgetMs;
    let lastWarnings = 0;
    let lastMessage = '';
    let failures = 0;
    for (;;) {
      throwIfAborted(signal);
      if (Date.now() > pollDeadline) {
        throw new Error(
          `Разбор партии из ${files.length} файл(ов) не завершился за ${Math.round(pollBudgetMs / 60000)} мин — ` +
            'проверьте состояние загрузки и запустите прогон снова'
        );
      }
      await sleep(2000);
      // ответ строго по схеме UploadStatusResponse: во время processing documents — разобрано документов партии
      let status: {
        status: string;
        files: number;
        documents: number;
        warnings?: string[];
        error?: string;
      };
      try {
        const statusResponse = await fetch(BASE_URL + `/scenarios/${scenarioId}/upload-status`, { signal });
        if (!statusResponse.ok) {
          throw await apiErrorFromResponse(statusResponse);
        }
        status = await statusResponse.json();
      } catch (error) {
        if (signal?.aborted) throw error;
        failures++;
        const reason = error instanceof Error ? error.message : String(error);
        if (failures > UPLOAD_STATUS_RETRIES) {
          throw new Error(`Опрос состояния загрузки не удался ${failures} раз(а) подряд: ${reason}`);
        }
        notify(`сбой опроса состояния загрузки (${reason}) — повтор ${failures} из ${UPLOAD_STATUS_RETRIES} через 3 с…`);
        await sleep(UPLOAD_STATUS_RETRY_PAUSE_MS);
        continue;
      }
      failures = 0;
      const warnings = status.warnings ?? [];
      for (; lastWarnings < warnings.length; lastWarnings++) {
        queue.push({
          type: 'upload_warning',
          data: { type: 'upload_warning', message: warnings[lastWarnings] },
        });
      }
      if (status.status === 'done') {
        return;
      }
      if (status.status === 'failed' || status.status === 'none') {
        throw new Error(`Upload processing error: ${status.error || status.status}`);
      }
      // ход разбора (счётчик разобранных документов) — в журнал только при изменении, иначе журнал заливает;
      // «N из M» не пишем: документов из ZIP бывает больше, чем файлов в партии
      const message =
        status.documents > 0
          ? `разобрано документов: ${status.documents} (файлов в партии: ${status.files}; сканы PDF распознаются через GigaChat ≈1 мин на документ)`
          : `документы обрабатываются на сервере (${status.files} файл(ов))`;
      if (message !== lastMessage) {
        lastMessage = message;
        queue.push({
          type: 'upload_processing',
          data: { type: 'upload_processing', files: status.files, parsed: status.documents, message },
        });
      }
    }
  }
}
