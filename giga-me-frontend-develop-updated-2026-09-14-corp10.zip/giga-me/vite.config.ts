import path from "path"
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { federation } from '@module-federation/vite'

import { name } from './package.json'

export default defineConfig({
  plugins: [react(), tailwindcss(), federation({
    name: name,
    filename: 'assets/remoteEntry.js',
    manifest: true,
    exposes: {
        './RemoteApp': './src/RemoteApp',
    },
    dts: false,
    bundleAllCSS: true,
}),
],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    proxy: {
      // Локальный запуск: корпоративный путь шлюза перенаправляется на бэкенд
      // 8081: порт 8080 занял системный HpHwDiagA.exe (HP Diagnostics, без
      // админа не остановить) — вернуть 8080 после отключения службы HP
      '/proto/backend/giga-me': {
        target: 'http://localhost:8081',
        changeOrigin: true,
        ws: true,
        rewrite: (p) => p.replace(/^\/proto\/backend\/giga-me/, '/gigame'),
      },
    },
  },
})