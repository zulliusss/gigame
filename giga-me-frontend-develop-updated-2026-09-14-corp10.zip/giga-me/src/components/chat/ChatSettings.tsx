import { useEffect, useRef, useState } from 'react';

const MODELS = ['GigaChat-2', 'GigaChat-2-Pro', 'GigaChat-2-Max'];

interface ChatSettingsProps {
  model: string | null;
  temperature: number | null;
  onChange: (settings: { model: string; temperature: number }) => void;
  disabled?: boolean;
}

// Настройки GigaChat для диалога: модель и температура.
// Пустая модель / отрицательная температура на бэкенде означают «по умолчанию».
export function ChatSettings({ model, temperature, onChange, disabled }: ChatSettingsProps) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open]);

  const isCustomized = !!model || temperature !== null;

  return (
    <div ref={rootRef} className="relative">
      <button
        onClick={() => !disabled && setOpen((v) => !v)}
        disabled={disabled}
        className={`flex items-center gap-1.5 text-xs transition-colors disabled:opacity-50 ${
          isCustomized ? 'text-[#21a038]' : 'text-muted-foreground hover:text-foreground'
        }`}
        title="Модель и температура для этого диалога"
      >
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="3" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
        </svg>
        <span>{model || 'Модель по умолчанию'}</span>
        {temperature !== null && <span>· t={temperature}</span>}
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1.5 z-30 w-64 bg-card border border-border rounded-xl shadow-lg p-3 space-y-3">
          <div>
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1">
              Модель GigaChat
            </div>
            <select
              value={model || ''}
              onChange={(e) =>
                onChange({ model: e.target.value, temperature: temperature ?? -1 })
              }
              className="w-full text-xs bg-background border border-border rounded-lg px-2 py-1.5 text-foreground"
            >
              <option value="">По умолчанию (глобальная)</option>
              {MODELS.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
          <div>
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground mb-1">
              Температура: {temperature !== null ? temperature : 'по умолчанию'}
            </div>
            <div className="flex items-center gap-2">
              <input
                type="range"
                min={0}
                max={2}
                step={0.1}
                value={temperature ?? 0.7}
                onChange={(e) =>
                  onChange({ model: model || '', temperature: parseFloat(e.target.value) })
                }
                className="flex-1 accent-[#21a038]"
              />
              {temperature !== null && (
                <button
                  onClick={() => onChange({ model: model || '', temperature: -1 })}
                  className="text-[10px] text-muted-foreground hover:text-destructive"
                  title="Сбросить на значение по умолчанию"
                >
                  Сброс
                </button>
              )}
            </div>
            <div className="text-[10px] text-muted-foreground mt-1">
              Ниже — точнее и стабильнее, выше — креативнее
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
