export const BASE_URL = '/proto/backend/giga-me/api';
