# Project Rules — GigaMe Backend

> **Version**: 1.4.0 · **Framework**: Spring Boot 3.5.15 / Java 17 · **Last Updated**: 2026-08-06

---

## 1. Stack & Dependencies

| Category | Technology |
|---|---|
| Framework | Spring Boot 3.5.15 (WebFlux / reactive) |
| Language | Java 17 |
| AI | GigaChat API (`spring-ai-starter-model-gigachat` 1.1.4) |
| Database | PostgreSQL 15+ with `pgvector` |
| Migrations | Liquibase 5.0.3 (SQL changelog) |
| ORM | Spring Data JPA (Hibernate 6) + Hypersistence Utils 3.9.3 |
| Build | Maven, JaCoCo 0.8.13 (70% min coverage) |
| Docs | Apache POI 5.5.1, PDFBox 3.0.7 |
| API Docs | Springdoc 2.8.17 (Swagger UI) |
| Logging | SLF4J + Logback |
| Helpers | Lombok, Apache Commons Lang3 |

**Immutable rules**:
- Never change Java version or Spring Boot parent without team agreement + ADR.
- All new dependencies require review for reactive compatibility (no blocking APIs).
- Test scope: H2 + `reactor-test`.

---

## 2. Build & Commands

```bash
# Full build (lint + test + coverage + package)
mvn clean verify

# Skip tests (CI uses this, but NEVER in local dev without tests)
mvn package -DskipTests

# Run single test class / method
mvn test -Dtest=ChatServiceTest
mvn test -Dtest=ChatServiceTest#testSendGigaChatRequest

# Coverage report
mvn test jacoco:report
# Min coverage: 70% complexity (enforced by jacoco:check)

# SonarQube
mvn sonar:sonar

# Checkstyle only
mvn checkstyle:check
```

**CI gate** (Jenkinsfile):
1. `mvn validate` (checkstyle)
2. `mvn test` (unit + integration)
3. `mvn verify` (JaCoCo ≥ 70%)
4. `mvn package` (JAR)

**Rule**: Green CI is mandatory for merge. No exceptions.

---

## 3. Package Structure

```
ru.sber.cs.ai.gigame/
├── Application.java                  # @SpringBootApplication entry point
├── config/                           # Configuration classes
├── controller/                       # REST controllers (5)
├── dto/                              # DTOs (36 files, 5 subpackages)
│   ├── chat/
│   ├── document/
│   ├── kb/
│   ├── prompt/
│   ├── scenario/
│   └── scenario/graph/
├── exception/                        # Custom exceptions + @ControllerAdvice
├── model/                            # JPA entities (13)
├── repository/                       # Spring Data repositories (13)
├── service/                          # Services (13 top-level + 34 in scenario/)
├── utils/                            # Utilities (6)
└── ws/                               # WebSocket handlers (4)
```

**Rules**:
- Each entity → dedicated repository in same-level package.
- Each service package corresponds to a domain (chat, document, kb, scenario).
- DTOs organized by domain subpackage. No DTOs in root `dto/`.
- Controllers → services only, no business logic in controllers.
- New domain = new subpackage under `service/`, `dto/`, `controller/`, `model/`, `repository/`.

---

## 4. Code Style (checkstyle.xml)

### Formatting
- **Line length**: max 300 characters (ignore URLs, long imports).
- **Method length**: max 50 lines (empty lines not counted).
- **Parameters**: max 8 per method.
- **Indentation**: 4 spaces.

### Imports
- **No wildcard imports** (`import java.util.*` → forbidden).
- **No unused imports**.
- Static imports allowed sparingly (`eq`, `is`).

### Code Patterns
```java
// String comparison — constant first
"expected".equals(variable)

// Catch blocks — never empty
catch (IOException e) {
    log.warn("Resource cleanup failed", e);
    // intentionally empty logic
}

// No nested try-catch — extract to separate method

// Annotations — single per line
@Getter
@Setter
@NoArgsConstructor

// Lombok usage
@RequiredArgsConstructor  // constructor injection
@Data                      // equals/hashCode/toString (rarely)
@Slf4j                      // private final static Logger log
```

### Ordering (inside class)
1. Static fields
2. Instance fields
3. Constructors
4. Methods (public → protected → private)

---

## 5. Naming Conventions

| Element | Convention | Examples |
|---------|------------|----------|
| Package | lowercase, single word | `ru.sber.cs.ai.gigame.service` |
| Entity | PascalCase, singular | `Conversation`, `KnowledgeBase` |
| Repository | Pascal + `Repository` | `ConversationRepository` |
| Service | Pascal + `Service` | `ChatService`, `KBService` |
| DTO (record) | Pascal, descriptive | `ConversationCreate`, `ScenarioDetailResponse` |
| DTO (request) | Pascal + `Request` / `Create` / `Update` | `SendMessageRequest`, `KBCreate`, `KBUpdate` |
| DTO (response) | Pascal + `Response` / `View` | `ConversationResponse`, `DocumentViewResponse` |
| Exception | Pascal + `Exception` | `NotFoundException`, `ScenarioException` |
| Controller | Pascal + `Controller` | `ConversationController` |
| Constants | UPPER_SNAKE_CASE | `CHUNK_SIZE`, `MAX_HISTORY_MESSAGES` |
| Variables | camelCase | `userId`, `conversationId` |
| Enum values | UPPER_SNAKE_CASE | `IN_PROGRESS`, `SKIPPED` |

---

## 6. Entity Conventions

### Mandatory patterns
```java
@Entity
@Table(name = "conversations")
@Getter @Setter @NoArgsConstructor  // always
@AllArgsConstructor                 // only when needed (e.g., Embedding)
public class Conversation {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false)
    private UUID id;

    @Column(name = "user_id", nullable = false)
    private UUID userId;             // multi-tenancy — ALWAYS present

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    // ... other fields
}
```

### JSONB fields
```java
@JdbcTypeCode(SqlTypes.JSON)
@Column(name = "knowledge_base_ids", columnDefinition = "jsonb")
private List<UUID> knowledgeBaseIds;
```

### Cascade relationships
```java
@OneToMany(mappedBy = "conversation", cascade = CascadeType.ALL, orphanRemoval = true)
@JsonIgnore
private List<Message> messages = new ArrayList<>();
```

### Embedding / pgvector
```java
@Type(FloatArrayType.class)
@Array(length = 1024)
@Column(name = "vector", columnDefinition = "vector(1024)")
private float[] vector;
```

**Rules**:
- **All** entities must have `user_id` for multi-tenancy.
- **All** entities must have `createdAt` + `updatedAt`.
- Use `@JsonIgnore` on reverse `@OneToMany` to prevent N+1 serialization.
- Never use `@EqualsAndHashCode` with Lombok on entities with `UUID` PKs (use `id` only).

---

## 7. Repository Conventions

```java
@Repository
public interface ConversationRepository extends JpaRepository<Conversation, UUID> {

    // Multi-tenant queries — ALWAYS filter by userId
    List<Conversation> findAllByUserIdOrderByUpdatedAtDesc(UUID userId);

    Optional<Conversation> findByIdAndUserId(UUID id, UUID userId);

    // Use @Query for complex queries
    @Query("SELECT c FROM Conversation c WHERE c.userId = :userId " +
           "AND LOWER(c.title) LIKE LOWER(CONCAT('%', :q, '%'))")
    Page<Conversation> searchByUserIdAndQuery(
        @Param("userId") UUID userId,
        @Param("q") String query,
        Pageable pageable);
}
```

**Rules**:
- All queries MUST include `userId` filter (except shared/scoped queries like `findAllByUserIdOrSharedTrue`).
- Use `Pageable` for paginated endpoints.
- Custom `@Query` in JPQL, not native SQL (unless necessary for pgvector).

---

## 8. DTO Conventions

### Java records for simple DTOs
```java
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public record ConversationCreate(
    @Schema(description = "Conversation title", example = "My Chat")
    @NotBlank String title,

    @Schema(description = "List of KB IDs to use for RAG")
    List<UUID> knowledgeBaseIds
) {}
```

### Complex DTOs with Lombok
```java
@Builder
@AllArgsConstructor
public class ErrorResponse {
    private int statusCode;
    private String error;
    private String message;
    private OffsetDateTime timestamp;
    private List<String> details;
}
```

**Rules**:
- Records use `@JsonNaming(SnakeCaseStrategy.class)`.
- OpenAPI `@Schema` annotations on ALL public API fields.
- Validation annotations (`@NotBlank`, `@NotNull`, `@Size`) on request DTOs.
- Response DTOs never have validation annotations.

---

## 9. Service Layer

```java
@Service
@RequiredArgsConstructor
@Slf4j
public class ChatService {

    private final ConversationRepository conversationRepository;
    private final MessageRepository messageRepository;
    private final GigaChatClient gigachatClient;

    public ConversationResponse createConversation(UUID userId, ConversationCreate request) {
        log.info("Creating conversation for user: {}", userId);

        Conversation conversation = new Conversation();
        conversation.setUserId(userId);
        conversation.setTitle(request.title());
        conversation = conversationRepository.save(conversation);

        return toResponse(conversation);
    }

    private ConversationResponse toResponse(Conversation conversation) {
        // ...
    }
}
```

**Rules**:
- Constructor injection via `@RequiredArgsConstructor` only. No `@Autowired` fields.
- Private helper methods for mapping/conversion.
- Log at entry of public methods (`log.info`), errors at `log.error`.
- Use `@Transactional` only on JPA-write operations (not on pure reads).
- Services should NOT throw `RuntimeException` — use custom exception hierarchy.

---

## 10. Exception Hierarchy

```
ApplicationRuntimeException (base, with HTTP status)
├── NotFoundException        (404)
├── AccessDeniedException    (403)
├── FileException            (400/500)
├── GigaChatException        (502)
└── ScenarioException        (400/500)
```

```java
// Custom exception
public class NotFoundException extends ApplicationRuntimeException {
    public NotFoundException(String resource, Object id) {
        super(HttpStatus.NOT_FOUND, resource + " not found: " + id);
    }
}

// Central handler
@ControllerAdvice
public class ApplicationErrorHandler {

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(NotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body(ErrorResponse.from(ex));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneric(Exception ex) {
        log.error("Unhandled exception", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(ErrorResponse.from(ex));
    }
}
```

**Rules**:
- Custom exceptions MUST extend `ApplicationRuntimeException` with HTTP status.
- Never let `RuntimeException` bubble up to `@ControllerAdvice` without wrapping.
- `@ControllerAdvice` handles ALL custom exceptions + generic fallback.

---

## 11. API Design

### URL conventions
```
/api/conversations              → list, create
/api/conversations/{id}         → get, update, delete
/api/conversations/{id}/messages → send message
/api/conversations/{id}/upload  → upload files to cache
/api/knowledge-bases/{id}/documents/{docId}/reindex → reindex
```

- Plural nouns for collections.
- Nested resources for relationships (`/conversations/{id}/messages`).
- Action verbs only for non-CRUD operations (`/run`, `/continue`, `/duplicate`).

### Response format
```json
{
  "id": "uuid-here",
  "title": "My Chat",
  "created_at": "2026-08-06T10:00:00Z",
  "updated_at": "2026-08-06T10:05:00Z"
}
```

- Snake-case JSON field names via `@JsonNaming(SnakeCaseStrategy.class)`.
- ISO 8601 timestamps with timezone.
- UUIDs as strings.

### Error response
```json
{
  "status_code": 404,
  "error": "Not Found",
  "message": "Conversation not found: abc-123",
  "timestamp": "2026-08-06T10:00:00Z"
}
```

---

## 12. Database & Migrations

### PostgreSQL requirements
```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";
```

### Liquibase rules
- **Master changelog**: `db/changelog/db.changelog.xml`
- **Changelog sets**: `db/changelog/db.changelog-master.sql` (sequential IDs)
- **Feature changelogs**: `db/changelog/{version}/db.changelog-N.sql`
- **Extensions**: `preliquibase/postgresql.sql`

### Migration rules
- **Append-only**: never edit existing changelog files.
- New version = new directory under `db/changelog/` (e.g., `3.0/`).
- Each changelog file = single `ChangelogSet` with unique ID.
- Always include index creation in the same changelog as table/column creation.

### Embedding strategy
```java
// chunk-size: 1000 chars, overlap: 200
// collection_type: 'doc' or 'kb'
// topK: 5
// vector: float[1024], index: IVFFlat (100 lists, cosine similarity)
```

**Rules**:
- All table names: snake_case, plural (`conversations`, `knowledge_bases`).
- All column names: snake_case (`user_id`, `created_at`).
- pgvector index: `idx_embeddings_vector` using `vector_cosine_ops`, 100 lists.
- Foreign keys with `ON DELETE CASCADE` or `ON DELETE SET NULL`.

---

## 13. Scenario Engine Rules

### Node execution architecture
```
ScenarioEngine (topological sort)
  → ScenarioExecutorFactory (creates executor by type)
    → AbstractScenarioExecutor.execute()
      → 14 concrete executors (Input, Output, Processing, Loop, Switch, If, Calc, etc.)
```

### Node types
| Type | Executor | Purpose |
|------|----------|---------|
| `INPUT` | `ScenarioExecutorInputNode` | Pass documents text |
| `OUTPUT` | `ScenarioExecutorOutputNode` | Merge predecessors |
| `PROCESSING` | `ScenarioExecutorProcessingNode` | GigaChat call with RAG |
| `LOOP` | `ScenarioExecutorLoopNode` | classify/analyze iterations |
| `SWITCH` | `ScenarioExecutorSwitchNode` | Routing by classification |
| `IF` | `ScenarioExecutorIfNode` | Conditionals |
| `CALC` | `ScenarioExecutorCalcNode` | Formulas |
| `AGGREGATE` | `ScenarioExecutorAggregateNode` | Data aggregation |
| `TRANSFORM` | `ScenarioExecutorTransformNode` | Data transformation |
| `SUBSCENARIO` | `ScenarioExecutorSubscenarioNode` | Recursive execution |
| `CONTROL` | `ScenarioExecutorControlNode` | Workflow control |
| `WAIT` | `ScenarioExecutorWaitNode` | Pause/delay |

### Execution rules
- **SkipSet**: on branch (Switch/If), loser nodes + descendants marked `skipped`.
- **SSE events**: `ScenarioEventEmission` emits `status`, `node_status`, `loop_progress`, `rag_search`.
- **Step mode**: manual step-by-step execution via WebSocket.
- **Group mode**: batch processing multiple documents in one GigaChat call.

**Rules**:
- New node types require: enum entry + executor class + factory registration + test coverage.
- Each executor MUST extend `AbstractScenarioExecutor` and implement `execute()`.
- All executors MUST emit SSE events via `ScenarioEventEmission`.
- Never call GigaChat directly from executor — use `GigaChatClient`.

---

## 14. WebSocket Conventions

### Endpoints
```
/ws/chat        → ChatMessage in / StreamEvent out (SSE)
/ws/scenario    → ScenarioMessage in / StreamEvent out (SSE)
```

### Auth
- `X-UserId` header in WebSocket handshake.
- Session managed by `WebSocketSessionManager`.

### Event types
- **Chat**: `message`, `error`, `done`
- **Scenario**: `status`, `node_status`, `step_complete`, `step_paused`, `loop_progress`, `rag_search`

**Rules**:
- All WebSocket handlers MUST be stateless except session tracking.
- SSE streams MUST complete with `done` event or `error` event.
- Heartbeat/ping every 30s for long-lived connections.

---

## 15. Testing

### Structure mirrors main code
```
src/test/java/ru/sber/cs/ai/gigame/
├── ApplicationIntegrationTest.java
├── TestConfiguration.java
├── controller/      (8 tests)
├── service/         (23 top-level + 19 in scenario/)
├── repository/      (13 tests)
└── ...
```

### Test conventions
```java
@ExtendWith(MockitoExtension.class)
class ChatServiceTest {

    @Mock
    private ConversationRepository conversationRepository;

    @InjectMocks
    private ChatService chatService;

    @Test
    void testCreateConversation() {
        // Given
        UUID userId = UUID.randomUUID();
        ConversationCreate request = new ConversationCreate("Test", List.of());

        // When
        when(conversationRepository.save(any())).thenReturn(mockConversation);

        // Then
        ConversationResponse response = chatService.createConversation(userId, request);
        assertEquals("Test", response.title());
        verify(conversationRepository).save(any());
    }
}
```

**Rules**:
- **Every service method** MUST have a corresponding test.
- Minimum 70% complexity coverage (enforced by JaCoCo).
- Integration tests in `ApplicationIntegrationTest.java` for full-stack scenarios.
- Use H2 for test database (`src/test/resources/db/test-schema.sql`).
- Test resources in `src/test/resources/` (test files: `.docx`, `.pdf`, `.xlsx`).
- Test class names: `<ClassBeingTested>Test.java`.

---

## 16. Security & Privacy

### Sensitive data (NEVER log or expose)
- GigaChat credentials (`GIGACHAT_KEY`, `GIGACHAT_SERT`).
- User tokens / passwords.
- Full email addresses in logs.
- Raw payment payload bodies.

### Data handling
- All queries MUST include `userId` filter (multi-tenancy).
- Shared scenarios: `shared = true` flag in `Scenario` entity.
- File uploads: max 30 MB per file, max 100 MB request.
- Delete operations cascade properly (`ON DELETE CASCADE`).

### SSL for GigaChat API
- Certificate: `giga_ift.pem`
- Key: `giga_ift.key`
- Both in `src/main/resources/` (gitignored).

---

## 17. CI/CD (Jenkinsfile)

### Pipeline stages
1. **Checkout** — git clone
2. **Build** — `mvn clean validate` (checkstyle)
3. **Test** — `mvn test` (unit + integration)
4. **Coverage** — `mvn verify` (JaCoCo ≥ 70%)
5. **Package** — `mvn package -DskipTests`
6. **SonarQube** — `mvn sonar:sonar` (optional, quality gate)

### Branch rules
- `main` — protected, requires passing CI + 1 approval.
- Feature branches — any name, prefix with feature/ or task/.
- No direct commits to `main`.

---

## 18. Documentation

### OpenAPI
- Specification: `openapi/gigame.yaml`
- UI: `http://localhost:8080/gigame/swagger-ui.html`
- Endpoint: `http://localhost:8080/gigame/sample-api-docs`

### Inline docs
- Javadoc on ALL public service methods.
- Describe all parameters in Javadoc (`@param`).
- `@Schema` annotations on ALL DTO fields.

### Markdown docs
- `GIGACODE.md` — project overview (this is the single source of truth for architecture).
- `Rules.md` — development conventions (this file).
- `WEBSOCKET_API.md` — WebSocket protocol details.

---

## 19. Environment Variables

```bash
# Database (required)
DATABASE_URL=jdbc:postgresql://localhost:5432/gigame
db.username=your_user
db.password=your_password
DATABASE_SCHEMA=public

# GigaChat (required)
GIGACHAT_URL=https://gigachat-ift.sberdevices.delta.sbrf.ru/v1
GIGACHAT_SERT=classpath:giga_ift.pem
GIGACHAT_KEY=classpath:giga_ift.key
GIGACHAT_SCOPE=GIGACHAT_API_CORP
GIGACHAT_MODEL=GigaChat-2-Max

# App tuning (optional, defaults shown)
PORT=8080
CONTEXT_CHAR_LIMIT=200000
MAX_HISTORY_MESSAGES=20
TOPK=5
CHUNK_SIZE=1000
OVERLAP=200
```

---

## 20. Quick Reference — Do's and Don'ts

| ✅ Do | ❌ Don't |
|-------|----------|
| Use `@RequiredArgsConstructor` for injection | Use `@Autowired` fields |
| Filter all queries by `userId` | Write queries without multi-tenancy |
| Extend `ApplicationRuntimeException` | Throw bare `RuntimeException` |
| Use Java records for DTOs | Use classes with getters/setters for DTOs |
| Add `@Schema` annotations | Skip OpenAPI annotations |
| Keep methods ≤ 50 lines | Write god methods |
| Use snake-case JSON for DTOs | Use camel-case JSON |
| Append-only changelogs | Edit existing changelogs |
| Test service methods | Leave services untested |
| Log at entry of public methods | Log every line |

---

*For detailed architecture, endpoints, and database schema, see `GIGACODE.md`.*

## 21. Plan mode

В plan mode план должен содержать:
- Цель — 1–2 предложения, что именно делаем и для чего.
- Область — конкретные файлы и модули, которые будут затронуты.
- Шаги — упорядоченные, привязанные к файлам, не `изучить / сделать / проверить`.
- Что НЕ делаем — явные границы, что вне области этой задачи.
- Открытые вопросы — чего не знаешь, что нужно подтвердить до старта.
- Точки сверки — где остановиться и показать промежуточный результат.

Не разворачивай шаблон формально, если задача укладывается в один-два
файла. Коротко перечисли изменения и пропусти разделы, которые не нужны.