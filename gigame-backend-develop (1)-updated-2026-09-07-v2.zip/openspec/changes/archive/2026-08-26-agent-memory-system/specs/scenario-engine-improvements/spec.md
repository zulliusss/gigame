---
capability: scenario-engine-improvements
---

# Scenario Engine Improvements Specification

## Purpose

Определить улучшения scenario engine: остановка прогона, чекпоинты, userId awareness, shared-сценарии, лимиты WS-пэйлоадов и download-файлов.

---

## ADDED Requirements

### Requirement: Остановка прогона

Система SHALL позволять пользователю явно останавливать выполняющийся прогон.

#### Scenario: Остановить прогон
- **WHEN** пользователь отправляет `POST /api/scenarios/runs/{runId}/cancel`
- **THEN** `ScenarioEngine.requestCancel(runId)` взводит `cancelRequested = true` в `activeGraphs[runId]`
- **THEN** `continueStep(runId)` снимает паузу пошагового режима (если активен)
- **THEN** каждый узел проверяет `graph.isCancelRequested()` перед выполнением
- **THEN** инструменты агента (`AgentDocumentTools`) проверяют `runCancelled` на каждом вызове
- **THEN** прогон завершается со статусом `FAILED`
- **THEN** возвращает HTTP 200 (остановка запрошена)

#### Scenario: Остановить неактивный прогон
- **WHEN** прогон уже завершён или не найден
- **THEN** `requestCancel()` возвращает `false`
- **THEN** HTTP 200 (безопасный вызов)

#### Scenario: Обрыв соединения не останавливает прогон
- **WHEN** WebSocket-соединение разрывается
- **THEN** прогон продолжается (нестабильная корпоративная сеть)
- **THEN** только явный `POST .../cancel` останавливает прогон

---

### Requirement: Чекпоинты узлов

Система SHALL сохранять чекпоинт упавшего узла для возобновления.

#### Scenario: Чекпоинт при ошибке узла
- **WHEN** узел завершается с исключением
- **THEN** `handleNodeError()` вызывается с экземпляром `AbstractScenarioExecutor`
- **THEN** `saveNodeCheckpoint()` вызывает `executorNode.getCheckpoint()`
- **THEN** чекпоинт (наблюдения агентского цикла) сохраняется в `output_data` шага
- **THEN** сохраняется ПОСЛЕ failed-статуса (чтобы not overwrite)
- **THEN** при `resumeScenario()` чекпоинты восстанавливаются через `restoreAgentCheckpoints()`

---

### Requirement: userId awareness

Система SHALL передавать userId запускающего пользователя в Engine → применяются личные общие уроки.

#### Scenario: Запуск сценария с userId
- **WHEN** `ScenarioService.runScenario(userId, scenarioId, stepMode)` вызывается
- **THEN** `scenarioEngine.executeScenario(run, graphData, userId)` передаёт userId
- **THEN** `graph.setRunnerUserId(userId)` устанавливает запускающего
- **THEN** `AgentMemoryService.lessonsForScenario(scenarioId, runnerUserId)` включает личные общие уроки

#### Scenario: Возобновление с userId
- **WHEN** `ScenarioService.resumeOldRun(userId, runId)` вызывается
- **THEN** `scenarioEngine.resumeScenario(run, graphData, oldSteps, userId)` передаёт userId
- **THEN** восстанавливаются чекпоинты из старого прогона

---

### Requirement: Shared сценарии

Система SHALL позволять всем пользователям запускать общие (`shared=true`) сценарии.

#### Scenario: Запуск общего сценария
- **WHEN** пользователь отправляет `POST /api/scenarios/{id}/run` для `shared=true`
- **THEN** `UserUtils.checkUserId()` НЕ вызывается (проверка пропускается)
- **THEN** прогон создаётся для любого пользователя

#### Scenario: Запуск личного сценария
- **WHEN** пользователь отправляет `POST /api/scenarios/{id}/run` для `shared=false`
- **THEN** `UserUtils.checkUserId(userId, model.getUserId())` проверяет авторство
- **THEN** неавтор получает ошибку

#### Scenario: Возобновление общего прогона
- **WHEN** `POST /api/scenarios/runs/{runId}/resume` для общего сценария
- **THEN** проверка авторства пропускается
- **THEN** любой пользователь может возобновить

---

### Requirement: Лимиты WS-пэйлоадов

Система SHALL обрезать данные в WS-событиях для предотвращения раздувания сокетов.

#### Scenario: Обрезка result в status-событии
- **WHEN** эмитируется `ScenarioEventEmission.emitStatusEvent(finalResult)`
- **THEN** `finalResult` обрезается до `PREVIEW_RESULT` (3000 символов)
- **THEN** добавляется суффикс «… [показано начало; полные данные — в отчёте прогона]»

#### Scenario: Обрезка STEP_COMPLETE
- **WHEN** эмитируется `ScenarioEventEmission.emitStepCompleteEvent(step, node)`
- **THEN** `inputData.documents_text` обрезается до `PREVIEW_DOCS` (1000)
- **THEN** `inputData.previous_output` обрезается до `PREVIEW_PREV` (1000)
- **THEN** `outputData.result` обрезается до `PREVIEW_RESULT` (3000)
- **THEN** `prompt_used` обрезается до `PREVIEW_PROMPT` (2000)

#### Scenario: FILE_OUTPUT — только файл-гаджет
- **WHEN** эмитируется `ScenarioEventEmission.emitFileOutputEvent(result, mode, node)`
- **THEN** вместо base64-байтов устанавливается только `file_ready: true`
- **THEN** клиент забирает байты через `GET /api/scenarios/runs/{runId}/files/{nodeId}`

---

### Requirement: Скачать файл output-узла

Система SHALL отдавать файлы, сгенерированные output-узлом, по REST-эндпоинту.

#### Scenario: Скачать XLSX-файл
- **WHEN** пользователь отправляет `GET /api/scenarios/runs/{runId}/files/{nodeId}`
- **THEN** узел находится по `nodeId` в графе сценария
- **THEN** если `node.data().mode() == 'EXCEL'` → генерируется XLSX через `ScenarioResultToXlsx.jsonToXlsx()`
- **THEN** возвращается файл с `Content-Type: application/vnd.openxmlformats...`

#### Scenario: Скачать TXT-файл
- **WHEN** режим узла `TEXT_FILE` или `TEXT`
- **THEN** возвращается текст с `Content-Type: text/plain`

#### Scenario: Узел не файловый
- **WHEN** узел не имеет файлового режима
- **THEN** возвращается HTTP 404

#### Scenario: Доступ к файлу
- **WHEN** `shared=true` → любой пользователь может скачать
- **WHEN** `shared=false` → только автор сценария

---

### Requirement: Tool-calling цикл

Система SHALL выполнять цикл модель↔инструмент с ручным сжатием истории.

#### Scenario: Agent chat с инструментами
- **WHEN** `GigaChatClient.chatCompletionWithTools(messages, tools, model, temperature)` вызывается
- **THEN** устанавливается `internalToolExecutionEnabled: false`
- **THEN** цикл выполняется до `TOOL_ROUNDS_LIMIT` (60):
  1. `callWithRetry(prompt)` получает ответ
  2. Если `hasToolCalls()` → execute tool calls, добавить в историю
  3. `compactToolHistory(history)` сжимает старые tool-ответы
  4. Если нет tool calls → вернуть финальный текст
- **THEN** если лимит раундов исчерпан → `GigaChatException`

#### Scenario: Сжатие истории
- **WHEN** `compactToolHistory(history)` вызывается
- **THEN** все tool-ответы, кроме последних `COMPACT_KEEP_LAST` (2), длиннее `COMPACT_MIN_CHARS` (1500)
- **THEN** заменяются маркером «Tool response compacted»
- **THEN** Агент может перечитать инструментом заново

#### Scenario: Hard timeout LLM-вызова
- **WHEN** сетевой LLM-вызов длится > `callHardTimeoutSeconds` (660 секунд)
- **THEN** вызов прерывается через `ExecutorService`
- **THEN** уходит в общий retry-механизм

---

### Requirement: Счётчик токенов для tool-calling

Система SHALL захватывать токены для tool-цикла.

#### Scenario: Begin/End capture для tool-calling
- **WHEN** tool-calling цикл начинается (`beginUsageCapture()`)
- **THEN** создаётся новый кадр учёта токенов
- **WHEN** цикл завершается (`endUsageCapture()`)
- **THEN** токены вливаются в родительский кадр (для под-сценариев)

## ADDED API Endpoints

### POST /api/scenarios/runs/{runId}/cancel

Остановить выполняющийся прогон.

**Ответ:** HTTP 200

---

### GET /api/scenarios/runs/{runId}/files/{nodeId}

Скачать файл output-узла.

**Параметры:**
| Параметр | Тип | Обязательно |
|----------|-----|-------------|
| `runId` | UUID | Да |
| `nodeId` | String | Да |

**Ответ:** `application/octet-stream` (XLSX или text/plain)

## ADDED Data Models

Не требуются (изменения только в поведении существующих сущностей).
