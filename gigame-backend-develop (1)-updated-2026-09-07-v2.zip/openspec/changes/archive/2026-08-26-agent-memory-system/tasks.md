---
# tasks.md — generated from specs
---

# Tasks

## Таск 1: БД-миграции — agent_lessons, agent_plans, agent_questions

**Зависит от:** ничего
**Покрывает:** Data Models (все три сущности)

- [x] 1.1. Создать `db/changelog/2.0/db.changelog-4.sql` — таблица `agent_lessons` с полями `id`, `scenario_id`, `user_id`, `lesson`, `source`, `approved`, `created_at`, `updated_at`; индекс `idx_agent_lessons_scenario`
- [x] 1.2. В том же файле — таблица `agent_plans` с полями `id`, `scenario_id`, `task_hash`, `task_preview`, `plan`, `uses`, `created_at`, `updated_at`; индекс `idx_agent_plans_hash`
- [x] 1.3. В том же файле — таблица `agent_questions` с полями `id`, `run_id`, `scenario_id`, `node_label`, `question`, `answer`, `answered_at`, `created_at`; индекс `idx_agent_questions_run`
- [x] 1.4. Все CREATE — `IF NOT EXISTS` (идемпотентность)
- [x] 1.5. Обновить `db.changelog.xml` — включить `db.changelog-4.sql`

## Таск 2: БД-миграции — системные уроки

**Зависит от:** Таск 1
**Покрывает:** Data Models (данные)

- [x] 2.1. Создать `db/changelog/2.0/db.changelog-5.sql` — 6 INSERT-ов системных уроков с фиксированными UUID, `WHERE NOT EXISTS`
- [x] 2.2. Каждый урок: `source='system'`, `approved=true`, `scenario_id=NULL`, `user_id=NULL`
- [x] 2.3. Обновить `db.changelog.xml` — включить `db.changelog-5.sql`

## Таск 3: JPA-модели и репозитории

**Зависит от:** Таск 1
**Покрывает:** Data Models

- [x] 3.1. Создать `AgentLesson.java` — `@Entity`, `@Table(name = "agent_lessons")`, поля: `id` (UUID, PK), `scenarioId`, `userId`, `lesson` (TEXT, nullable=false), `source` (VARCHAR(32), default='user'), `approved` (BOOLEAN, default=false), `createdAt`, `updatedAt`. Константы: `SOURCE_USER`, `SOURCE_REVISER`, `SOURCE_AUTO`, `SOURCE_SYSTEM`
- [x] 3.2. Создать `AgentPlan.java` — `@Entity`, `@Table(name = "agent_plans")`, поля: `id`, `scenarioId`, `taskHash` (VARCHAR(64), nullable=false), `taskPreview` (TEXT), `plan` (TEXT, nullable=false), `uses` (INTEGER, default=0), `createdAt`, `updatedAt`
- [x] 3.3. Создать `AgentQuestion.java` — `@Entity`, `@Table(name = "agent_questions")`, поля: `id`, `runId` (nullable=false), `scenarioId`, `nodeLabel` (VARCHAR(255)), `question` (TEXT, nullable=false), `answer` (TEXT), `answeredAt`, `createdAt`
- [x] 3.4. Создать `AgentLessonRepository.java` — методы: `findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc`, `findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc`, `findByScenarioIdOrderByCreatedAtDesc`, `findByScenarioIdIsNullOrderByCreatedAtDesc`, `findById`
- [x] 3.5. Создать `AgentPlanRepository.java` — метод: `findFirstByTaskHashOrderByUsesDesc`
- [x] 3.6. Создать `AgentQuestionRepository.java` — метод: `findByRunIdOrderByCreatedAtDesc`
- [x] 3.7. Создать DTO: `AgentLessonResponseDto.java` (record)
- [x] 3.8. Создать DTO: `AgentLessonCreateRequest.java`, `AgentLessonUpdateRequest.java`, `AgentLessonCompressRequest.java`, `AgentLessonExtractRequest.java`, `AgentQuestionAnswerRequest.java`

## Таск 4: AgentMemoryService — CRUD уроков

**Зависит от:** Таск 3
**Покрывает:** Requirement CRUD уроков агента

- [x] 4.1. Создать `AgentMemoryService.java` — `@Service`, `@RequiredArgsConstructor`, `@Slf4j`
- [x] 4.2. Метод `getLessons(UUID scenarioId)` — возвращает список уроков, отсортированный по `createdAt DESC`. Если `scenarioId != null` — фильтр по сценарию, иначе — общие уроки
- [x] 4.3. Метод `addLesson(String userId, UUID scenarioId, String lesson, String source)` — валидация (lesson не пустой), `checkScenarioAuthor`, сохранение с `approved=true` (личный общий — сразу, сценарный — тоже)
- [x] 4.4. Метод `updateLesson(String userId, UUID id, String lesson)` — проверка `checkNotSystem`, `checkScenarioAuthor`, обновление текста
- [x] 4.5. Метод `deleteLesson(String userId, UUID id)` — проверка `checkNotSystem`, `checkScenarioAuthor`, удаление
- [x] 4.6. Вспомогательный `checkScenarioAuthor(String userId, UUID scenarioId)` — если `scenarioId != null`, загружает сценарий и сравнивает `userId`
- [x] 4.7. Вспомогательный `checkNotSystem(AgentLesson lesson)` — выбрасывает `IllegalArgumentException` для системных уроков

## Таск 5: AgentMemoryService — одобрение уроков

**Зависит от:** Таск 4
**Покрывает:** Requirement Одобрение урока

- [x] 5.1. Метод `approveLesson(String userId, UUID id)` — находит урок, `checkScenarioAuthor`, устанавливает `approved=true`, сохраняет

## Таск 6: AgentMemoryService — сжатие и извлечение уроков

**Зависит от:** Таск 4
**Покрывает:** Requirement Рефлексия-сжатие, Requirement Авто-извлечение

- [x] 6.1. Метод `compressLessons(String userId, UUID scenarioId)` — проверка `< 3 уроков`, GigaChat-вызов с промптом для сжатия в ≤7 правил, `parsePlan`, удаление старых, сохранение новых с `source='auto'`
- [x] 6.2. Метод `extractLessonsFromRun(String userId, UUID scenarioId, Map<String, String> runOutputs)` — сбор outputs из шагов прогона, GigaChat-вызов с промптом для извлечения ≤5 правил, фильтрация: `specificLesson()` (не банальный), `similarLesson()` (не дубликат), сохранение с `source='reviser'`, `approved=false`
- [x] 6.3. Статический `specificLesson(String text)` — проверка `GENERIC_LESSON_STARTS`, regex `(?s).*[«\"\\d=—].*`
- [x] 6.4. Статический `similarLesson(String a, String b)` — split на слова (≥3 символов), 60% совпадения
- [x] 6.5. Статический список `GENERIC_LESSON_STARTS` — 12+ триггерных слов

## Таск 7: AgentMemoryService — применение уроков к промпту

**Зависит от:** Таск 6
**Покрывает:** Requirement Применение уроков к промпту

- [x] 7.1. Метод `lessonsForScenario(UUID scenarioId, String runnerUserId)` — три слоя:
  - Layer 1: системные (`source='system'`, `scenario_id=NULL`), limit 10
  - Layer 2: личные общие (`user_id=runnerUserId`, `scenario_id=NULL`, `source≠'system'`), limit 10
  - Layer 3: сценарные (`scenario_id=UUID`, `approved=true`), limit 10
- [x] 7.2. Константа `LESSONS_LIMIT = 10`, `COMPRESS_THRESHOLD = 15`
- [x] 7.3. Авто-кандидаты (`approved=false`) НЕ включаются

## Таск 8: AgentMemoryService — память планов

**Зависит от:** Таск 4
**Покрывает:** Requirement Память планов

- [x] 8.1. Метод `findPlan(String task)` — `taskHash(task)` через SHA-256, поиск по хэшу, `uses++`, `parsePlan(p.getPlan())`, возврат или `null`
- [x] 8.2. Метод `savePlan(UUID scenarioId, String task, List<String> plan)` — хэш, поиск или создание `AgentPlan`, `uses++`
- [x] 8.3. Приватный `taskHash(String task)` — нормализация (lowercase, trim, collapse whitespace), SHA-256 в hex

## Таск 9: AgentMemoryService — вопросы агента

**Зависит от:** Таск 4
**Покрывает:** Requirement Вопросы агента

- [x] 9.1. Метод `getQuestionsByRun(UUID runId)` — `questionRepository.findByRunIdOrderByCreatedAtDesc(runId)`
- [x] 9.2. Метод `answerQuestion(String userId, UUID questionId, String answer)` — находит вопрос, сохраняет `answer` и `answeredAt`, автоматически создаёт урок сценария из ответа

## Таск 10: AgentMemoryController — REST API

**Зависит от:** Таск 9
**Покрывает:** ADDED API Endpoints (все 12 endpoints)

- [x] 10.1. Создать `AgentMemoryController.java` — `@RestController`, `@RequestMapping("/api/agent")`, `@RequiredArgsConstructor`
- [x] 10.2. `GET /lessons` — `Mono.fromCallable(() -> memoryService.getLessons(scenarioId))`
- [x] 10.3. `POST /lessons` — парсит `scenarioId` из тела, `memoryService.addLesson(userId, scenarioId, lesson, "user")`
- [x] 10.4. `PUT /lessons/{id}` — `memoryService.updateLesson(userId, id, lesson)`
- [x] 10.5. `DELETE /lessons/{id}` — `memoryService.deleteLesson(userId, id)`
- [x] 10.6. `POST /lessons/{id}/approve` — `memoryService.approveLesson(userId, id)`
- [x] 10.7. `POST /lessons/compress` — `memoryService.compressLessons(userId, scenarioId)`
- [x] 10.8. `POST /lessons/extract` — загружает run и steps, собирает outputs, вызывает `memoryService.extractLessonsFromRun`
- [x] 10.9. `GET /plans?scenario_id=uuid` — `memoryService.getPlans(scenarioId)`
- [x] 10.10. `DELETE /plans/{id}` — `memoryService.deletePlan(userId, id)`
- [x] 10.11. `GET /questions?run_id=uuid` — `memoryService.getQuestionsByRun(runId)`
- [x] 10.12. `POST /questions/{id}/answer` — `memoryService.answerQuestion(userId, id, answer)`
- [x] 10.13. Все эндпоинты — `Mono.fromCallable() ... subscribeOn(Schedulers.boundedElastic())`
- [x] 10.14. Все эндпоинты — `@RequestHeader(name = "X-UserId", required = false)`

## Таск 11: AgentDocumentTools — инструменты чтения/поиска

**Зависит от:** ничего
**Покрывает:** Requirement Tool-calling цикл (инструменты)

- [x] 11.1. Создать `AgentDocumentTools.java` — record `DocEntry(filename, text)`
- [x] 11.2. Record `ReadRequest(name, offset)`
- [x] 11.3. Record `SearchRequest(query, [docs])`
- [x] 11.4. Record `KbSearchRequest(query)`
- [x] 11.5. Record `ThoughtRequest(thought)`
- [x] 11.6. Record `WriteRequest(name, content)`
- [x] 11.7. Поля: `docsByName`, `calls`, `kbSearch`, `callLog`, `seenCalls`, `observations`, `thoughts`, `fruitlessQueries`, `fruitlessStreak`, `progress`, `runCancelled`, `workNoteNames`, `writeSink`
- [x] 11.8. Константы: `READ_CHUNK=12000`, `SEARCH_MAX_HITS=12`, `MAX_TOOL_CALLS=40`, `MAX_SEQUENTIAL_READS=3`, `MAX_THOUGHTS=15`, `FRUITLESS_STREAK_LIMIT=3`, `WRITE_MAX_CHARS=60000`
- [x] 11.9. Метод `searchDocuments(SearchRequest)` — точный поиск подстроки в текстах документов, контекст ±600 символов, лимит 12 хитов, фильтр по именам (docs-список)
- [x] 11.10. Метод `readDocument(ReadRequest)` — чтение фрагмента документа по имени и смещению, `READ_CHUNK` символов
- [x] 11.11. Метод `searchKnowledgeBase(KbSearchRequest)` — делегирование `kbSearch.apply(query)`
- [x] 11.12. Метод `note_thought(ThoughtRequest)` — запись рассуждения, лимит `MAX_THOUGHTS`
- [x] 11.13. Метод `writeFile(WriteRequest)` — сохранение рабочего файла, вызов `writeSink`, проверка лимитов
- [x] 11.14. Метод `callbacks()` — создание `FunctionToolCallback` для каждого инструмента, `list_documents` НЕ как инструмент (422 от GigaChat)
- [x] 11.15. Защита: `overLimit(logEntry)` — проверка `MAX_TOOL_CALLS`, `runCancelled`
- [x] 11.16. Защита: `isRepeat(key)` — дедупликация через `seenCalls`
- [x] 11.17. Защита: `isSequentialReadBinge(name)` — детект сплошного чтения
- [x] 11.18. Метод `prefetch(List<SearchRequest>)` — ReWOO-предвыборка, пакетный поиск без участия модели
- [x] 11.19. Метод `documentSummary()` — «имя (N символов)» для системного промпта
- [x] 11.20. Метод `docsSnapshot()` — map документов без рабочих файлов

## Таск 12: AgentEvidence — рабочая тетрадь и валидация

**Зависит от:** ничего
**Покрывает:** Requirement Tool-calling цикл (валидация)

- [x] 12.1. Создать `AgentEvidence.java` — record `Entry(item, name, value, quote, doc, verdict)`
- [x] 12.2. Константы: `CONFIRMED`, `CALCULATED`, `QUOTE_NOT_FOUND`, `DOC_NOT_FOUND`, `NO_QUOTE`, `NOT_SPECIFIED`, `MAX_QUESTIONS=5`
- [x] 12.3. Статический `parse(String answer)` — извлечение JSON с массивом «записи», парсинг полей: пункт, название, значение, цитата, документ
- [x] 12.4. Статический `parsePlan(String raw)` — JSON-массив строк, терпимо к тексту вокруг
- [x] 12.5. Статический `parseSearchPlan(String raw)` — JSON-массив объектов с «запрос» и «документы»
- [x] 12.6. Статический `validate(List<Entry>, Map<String, String>)` — вызов `validatedEntry()` для каждой записи
- [x] 12.7. `validatedEntry(Entry, Map)` — 6 шагов: blank quote → NO_QUOTE / CONFIRMED; точное вхождение → CONFIRMED; числа в документе → CALCULATED; поиск по цитате в любом документе → CONFIRMED с исправлением doc; числа в единственном документе → CALCULATED; fallback → QUOTE_NOT_FOUND / DOC_NOT_FOUND
- [x] 12.8. Статический `sourceNumbersPresent(String quote, String docText)` — поиск чисел ≥3 цифр в цитате, проверка в документе
- [x] 12.9. Статический `normalized(String s)` — lowercase, ё→е, collapse whitespace

## Таск 13: KbAggregateService — агрегирующие вопросы

**Зависит от:** Таск 3
**Покрывает:** Requirement Агрегирующие вопросы — SUM, Requirement Агрегирующие вопросы — LIST

- [x] 13.1. Создать `KbAggregateService.java` — `@Service`, record `AggregateResult(context, sources)`
- [x] 13.2. Паттерны: `SUM_INTENT`, `LIST_INTENT` — регулярные выражения для распознавания намерения
- [x] 13.3. Конфигурация: `@Value("${app.chat.aggregate-enabled:true}")`, `@Value("${app.chat.aggregate-max-docs:200}")`, `@Value("${app.chat.aggregate-doc-char-limit:30000}")`, `@Value("${app.chat.aggregate-parallelism:2}")`
- [x] 13.4. Метод `tryAggregate(List<UUID> kbIds, String query)` — проверка `enabled`, `SUM_INTENT` / `LIST_INTENT`, загрузка документов
- [x] 13.5. `sumResult(List<Document> docs, String query)` — MapReduce: `extractAll(docs, query)` (параллельно), `retryMissedSequentially`, сумма кодом, контекст с разбивкой по документам
- [x] 13.6. `listResult(List<Document> docs)` — метаданные без LLM, количество + список имён
- [x] 13.7. `tooManyContext(int count)` — отказ с рекомендацией сценария
- [x] 13.8. `extractAll()` — `Executors.newFixedThreadPool(parallelism)`, порядок сохраняется
- [x] 13.9. `retryMissedSequentially()` — повтор неуспешных извлечений

## Таск 14: EmbeddingService — гибридный поиск

**Зависит от:** Таск 3
**Покрывает:** Requirement Гибридный поиск

- [x] 14.1. Константы: `RRF_K = 60`, `LEXICAL_DISTANCE = 0.15`
- [x] 14.2. Метод `hybridSearchWithSources(collectionType, collectionId, queryEmbedding, queryText)` — векторный канал + лексический канал, RRF-слияние
- [x] 14.3. Метод `hybridSearch()` — обёртка, возвращает только тексты
- [x] 14.4. Статический `lexicalTerms(String queryText)` — regex `[а-яёa-zA-Z]{5,}|\d{4,}`, до 3 самых длинных
- [x] 14.5. Добавить `searchLexical(collectionType, collectionId, term, topK)` в `EmbeddingRepository` — LIKE-поиск по тексту фрагмента

## Таск 15: ChatService — улучшенный RAG

**Зависит от:** Таск 14, Таск 13
**Покрывает:** Requirement Адресация к документу, Requirement Дополнение коротких реплик

- [x] 15.1. Внедрить `KbAggregateService` в конструктор `ChatService`
- [x] 15.2. Метод `ragQueryWithHistory(Conversation, Message)` — если длина < `ragShortQueryChars` (60), дополняет предыдущим вопросом пользователя
- [x] 15.3. Обновить `buildRagContext(kbIds, query, currentQuery)` — вызов `kbAggregateService.tryAggregate()`, если не null — возврат sources
- [x] 15.4. Метод `filterByReferencedDocument(hits, query)` — три сигнала: long number ≥5, basename, token pair
- [x] 15.5. Метод `addressedFullDocsContext(List<ChunkHit>)` — полные тексты адресованных документов (до 3), лимит `contextCharLimit / N`
- [x] 15.6. Метод `docReferencedInQuery(queryLower, filename)` — long number, basename, `tokenPairReferenced()`
- [x] 15.7. Метод `tokenPairReferenced(queryLower, nameLower)` — числовой токен + буквенный токен (≥4 букв)
- [x] 15.8. Обновить `buildRagContext(kbIds, queryEmbedding)` → 3 аргумента (добавлен `currentQuery`)
- [x] 15.9. Обновить `ragRouterSearchDocs()` — вызов `hybridSearch()` вместо `searchSimilar()`

## Таск 16: GigaChatClient — tool-calling цикл

**Зависит от:** Таск 11
**Покрывает:** Requirement Tool-calling цикл, Requirement Счётчик токенов

- [x] 16.1. Константы: `TOOL_ROUNDS_LIMIT=60`, `COMPACT_KEEP_LAST=2`, `COMPACT_MIN_CHARS=1500`
- [x] 16.2. Hard timeout: `@Value("${app.gigachat.call-hard-timeout-seconds:660}")` — `ExecutorService` для прерывания зависших LLM-вызовов
- [x] 16.3. Метод `chatCompletionWithTools(messages, tools, model, temperature)` — `internalToolExecutionEnabled: false`, цикл до 60 раундов
- [x] 16.4. Приватный `executeToolCalls(AssistantMessage, Map)` — исполнение tool calls, обработка ошибок, `ToolResponseMessage`
- [x] 16.5. Статический `compactToolHistory(List<Message>)` — замена старых tool-ответов маркером
- [x] 16.6. Метод `setRunCancelCheck(BooleanSupplier)`, `clearRunCancelCheck()` — ThreadLocal для проверки остановки
- [x] 16.7. Обновить `callWithRetry()` — проверка `RUN_CANCEL_CHECK.getAsBoolean()` для прерывания ретраев
- [x] 16.8. `beginUsageCapture()` / `endUsageCapture()` — захват токенов для tool-цикла
- [x] 16.9. Лимит чтения GigaChat: `read-timeout: ${GIGACHAT_READ_TIMEOUT:60s}`
- [x] 16.10. Jackson: `spring.jackson.default-property-inclusion: non_null`

## Таск 17: ScenarioEngine — cancel, checkpoint, userId

**Зависит от:** Таск 7, Таск 12
**Покрывает:** Requirement Остановка прогона, Requirement Чекпоинты узлов, Requirement userId awareness

- [x] 17.1. Поле `ConcurrentHashMap<String, ScenarioRunGraph> activeGraphs` — хранение графов активных прогонов
- [x] 17.2. Метод `requestCancel(String runId)` — `activeGraphs.get(runId).requestCancel()`, `continueStep(runId)`, возврат `true/false`
- [x] 17.3. Обновить `executeScenario(run, graphData, userId)` — новый overload с `userId`, вызов `doExecute(..., userId)`
- [x] 17.4. Обновить `doExecute(..., runnerUserId)` — `graph.setRunId()`, `graph.setScenarioId()`, `graph.setRunnerUserId()`, `activeGraphs.put(runId, graph)`
- [x] 17.5. Проверка `graph.isCancelRequested()` в `executeNode()` перед выполнением узла
- [x] 17.6. `GigaChatClient.setRunCancelCheck(graph::isCancelRequested)` перед выполнением узла, `clearRunCancelCheck()` в finally
- [x] 17.7. Метод `saveNodeCheckpoint(step, executorNode)` — `executor.getCheckpoint()`, `appendOutputData("checkpoint", abbreviated(30000))`
- [x] 17.8. Обновить `handleNodeError(..., executorNode)` — вызов `saveNodeCheckpoint` ПОСЛЕ failed-статуса
- [x] 17.9. Обновить `resumeScenario(..., userId)` и `resumeExecution(..., runnerUserId)` — передача userId, `activeGraphs.put()`, `restoreAgentCheckpoints()`

## Таск 18: ScenarioRunGraph — cancel и working docs

**Зависит от:** Таск 17
**Покрывает:** Requirement Остановка прогона (базовый уровень)

- [x] 18.1. Поля: `runId` (@Setter), `scenarioId` (@Setter), `runnerUserId` (@Setter), `cancelRequested` (AtomicBoolean)
- [x] 18.2. Методы: `isCancelRequested()`, `requestCancel()`
- [x] 18.3. Метод `addWorkingDoc(filename, text)` — синхронизированный, создание `ScenarioRunDoc(filename, text, workNote=true)`, проверка дублирования исходных имён
- [x] 18.4. Обновить `buildNode(int index, ...)` — 1-базный индекс (was 0-базный, `incrementAndGet`)

## Таск 19: ScenarioService — shared сценарии и download

**Зависит от:** Таск 18
**Покрывает:** Requirement Shared сценарии, Requirement Скачать файл output-узла

- [x] 19.1. В `runScenario(userId, scenarioId, stepMode)` — проверка: если `model.shared == false` → `checkUserId`, иначе пропуск
- [x] 19.2. В `resumeOldRun(userId, runId)` — та же логика для shared
- [x] 19.3. Метод `downloadRunFile(userId, runId, nodeId)` — проверка shared, поиск node в графе, генерация XLSX/TXT из `output_data`, `ResponseEntity<Resource>`
- [x] 19.4. Приватный `fileResponse(filename, mime, bytes)` — `ByteArrayResource`, Content-Disposition, Content-Type
- [x] 19.5. Обновить `executeScenario` call — передача `userId`

## Таск 20: ScenarioController — cancel и download

**Зависит от:** Таск 19
**Покрывает:** ADDED API Endpoints (cancel, download)

- [x] 20.1. Метод `cancelRun(userId, runId)` — `scenarioEngine.requestCancel(runId.toString())`, `Mono.fromRunnable ... then()`
- [x] 20.2. Метод `downloadRunFile(userId, runId, nodeId)` — делегирование `scenarioService.downloadRunFile()`, `ResponseEntity<Resource>`

## Таск 21: ScenarioEventEmission — лимиты WS-пэйлоадов

**Зависит от:** Таск 18
**Покрывает:** Requirement Лимиты WS-пэйлоадов

- [x] 21.1. Константы: `PREVIEW_DOCS=1000`, `PREVIEW_PREV=1000`, `PREVIEW_PROMPT=2000`, `PREVIEW_RESULT=3000`
- [x] 21.2. Статический `preview(String value, int limit)` — обрезка + суффикс
- [x] 21.3. Приватный `previewMap(Map<String, String> data, Map<String, Integer> limits)` — обрезка каждого значения
- [x] 21.4. Обновить `emitStatusEvent(finalResult)` — вызов `preview(finalResult, PREVIEW_RESULT)`
- [x] 21.5. Обновить `emitStepCompleteEvent(step, node)` — `previewMap` для `inputData` и `outputData`, `preview` для `prompt_used`
- [x] 21.6. Обновить `emitFileOutputEvent(result, mode, node)` — вместо base64-байтов → `file_ready: true`, удаление `KEY_CONTENT`, `KEY_ENCODING`
- [x] 21.7. Удалить import `Base64`

## Таск 22: PromptRateRequest — типизированный DTO

**Зависит от:** ничего
**Покрывает:** Requirement оценки промптов (улучшение)

- [x] 22.1. Создать `PromptRateRequest.java` — record с полем `rating` (Integer, 1-5), `@Schema` аннотации
- [x] 22.2. Обновить `PromptController.ratePrompt()` — использовать `body.rating()` вместо `body.get("rating")`

## Таск 23: Integration — Application configuration

**Зависит от:** Таск 13
**Покрывает:** Configuration

- [x] 23.1. Добавить `spring.jackson.default-property-inclusion: non_null` в `application.yaml`
- [x] 23.2. Обновить `spring.gigachat.internal.read-timeout: ${GIGACHAT_READ_TIMEOUT:60s}` — уже присутствует в YAML (line 108)
- [x] 23.3. Добавить параметры `app.chat.aggregate-*`, `app.chat.rag-short-query-chars` — добавлены 5 параметров в `app.chat` секцию

## Таск 24: Tests

**Зависит от:** все implement-таски (1–23)
**Покрывает:** Все требования

- [x] 24.1. `AgentMemoryControllerTest.java` — тесты CRUD, approve, compress, extract (mock сервисов)
- [x] 24.2. `AgentMemoryServiceTest.java` — тесты `lessonsForScenario` (3 слоя), `compressLessons`, `extractLessonsFromRun`, `specificLesson`, `similarLesson`, `findPlan`, `savePlan`, `answerQuestion`
- [x] 24.3. `AgentDocumentToolsTest.java` — тесты `search_documents`, `read_document`, `note_thought`, `write_file`, `prefetch`, `callbacks()`, лимиты (MAX_TOOL_CALLS, sequential reads)
- [x] 24.4. `AgentEvidenceTest.java` — тесты `parse()`, `parsePlan()`, `parseSearchPlan()`, `validate()` (все вердикты: CONFIRMED, CALCULATED, NO_QUOTE, QUOTE_NOT_FOUND, DOC_NOT_FOUND)
- [x] 24.5. `ScenarioExecutorProcessingNodeTest.java` — тесты с инструментами агента, чекпоинтами, lessonsForScenario
- [x] 24.6. `ScenarioEventEmissionTest.java` — тесты `preview()`, `previewMap()`, лимиты в STEP_COMPLETE, FILE_OUTPUT file_ready
- [x] 24.7. `KbAggregateServiceTest.java` — тесты `tryAggregate` (SUM, LIST, tooManyDocs, noValues), `extractAll`, `retryMissedSequentially`
- [x] 24.8. `EmbeddingServiceTest.java` — тесты `lexicalTerms()`, `hybridSearch` (RRF слияние), пустой запрос
- [x] 24.9. `GigaChatClientTest.java` / `GigaChatClientRetryTest.java` — тесты `chatCompletionWithTools` (tool-цикл, лимит раундов), `compactToolHistory`, hard timeout
- [x] 24.10. `ScenarioEngineTest.java` — тесты `requestCancel`, `executeScenario(userId)`
- [x] 24.11. `ScenarioRunServiceTest.java` — тесты возобновления с userId
- [x] 24.12. `ScenarioControllerTest.java` — тесты `cancelRun`, `downloadRunFile` (XLSX, TXT, не файловый узел)
- [x] 24.13. `ScenarioServiceTest.java` — тесты shared scenarios (run, resume)
- [x] 24.14. `ScenarioMapperTest.java` — обновить тесты (удалить/обновить)
- [x] 24.15. `ChatServiceTest.java` — тесты `ragQueryWithHistory`, `filterByReferencedDocument`, `addressedFullDocsContext`
- [x] 24.16. `PromptControllerTest.java` — обновить тесты для `PromptRateRequest`
- [x] 24.17. `TestConfiguration.java` — тестовая конфигурация (mock GigaChat, EmbeddingService)
- [x] 24.18. `test-schema.sql` — тестовая схема с новыми таблицами

## Таск 25: OpenAPI — документация

**Зависит от:** Таск 10, Таск 20
**Покрывает:** ADDED API Endpoints (документация)

- [x] 25.1. Обновить `openapi/gigame.yaml` — добавить тег `agent-memory`
- [x] 25.2. Добавить схемы: `AgentLessonResponseDto`, `AgentLessonCreateRequest`, `AgentLessonUpdateRequest`, `AgentLessonCompressRequest`, `AgentLessonExtractRequest`, `AgentQuestionAnswerRequest`, `AgentPlan`, `AgentQuestion`
- [x] 25.3. Добавить эндпоинты: `GET/POST /api/agent/lessons`, `PUT/DELETE /api/agent/lessons/{id}`, `POST /api/agent/lessons/{id}/approve`, `POST /api/agent/lessons/compress`, `POST /api/agent/lessons/extract`
- [x] 25.4. Добавить эндпоинты: `GET /api/agent/plans`, `DELETE /api/agent/plans/{id}`
- [x] 25.5. Добавить эндпоинты: `GET /api/agent/questions`, `POST /api/agent/questions/{id}/answer`
- [x] 25.6. Добавить эндпоинт: `POST /api/scenarios/runs/{runId}/cancel`
- [x] 25.7. Добавить эндпоинт: `GET /api/scenarios/runs/{runId}/files/{nodeId}`
- [x] 25.8. Обновить паттерн промпта: `^[\w\W]{0,500000}$`

## Итоговый план (последовательность выполнения)

```
БД:   Таск 1 → Таск 2
Модели: Таск 3 (зависит от 1)
Сервисы памяти: Таск 4 → 5 → 6 → 7 → 8 → 9 (цепочка)
Контроллер памяти: Таск 10 (зависит от 9)
Инструменты: Таск 11, 12 (параллельно)
RAG: Таск 13 → 14 → 15 (цепочка)
GigaChat: Таск 16
Scenario: Таск 17 → 18 → 19 → 20 (цепочка)
Emission: Таск 21
Прочее: Таск 22, 23 (независимы)
Тесты: Таск 24 (зависит от 1–23)
OpenAPI: Таск 25 (зависит от 10, 20)
```

Параллельно можно: **Таск 11 + Таск 12** и **Таск 22 + Таск 23**.
