---
title: "Design — Система памяти агента"
author: "delta-spec"
created: "2026-08-26"
---

# Design: Система памяти агента и улучшения

## Architecture

### Диаграмма компонентов

```
┌──────────────────────────────────────────────────────────────────┐
│                      AGENT MEMORY SYSTEM                          │
│                                                                   │
│  REST API: /api/agent/*                                          │
│  ├─ AgentMemoryController (12 endpoints)                         │
│  └─ AgentMemoryService (CRUD, compress, extract, dedup)          │
│       │                                                          │
│       ├─ AgentLesson (entity) ──▶ AgentLessonRepository          │
│       ├─ AgentPlan  (entity) ──▶ AgentPlanRepository             │
│       └─ AgentQuestion(entity) ─▶ AgentQuestionRepository        │
│                                                                    │
│  ProcessingNode executor ◀── AgentMemoryService.lessonsForScenario│
│       │                                                          │
│       ▼                                                          │
│  ┌─────────────────────┐         ┌─────────────────────┐        │
│  │ AgentDocumentTools  │         │   AgentEvidence      │        │
│  │                     │         │                      │        │
│  │ search_documents()  │◀────────▶ validate()           │        │
│  │ read_document()     │         │  ПОДТВЕРЖДЕНО        │        │
│  │ search_knowledge_   │         │  РАСЧЁТНОЕ           │        │
│  │   base()            │         │  БЕЗ ЦИТАТЫ          │        │
│  │ note_thought()      │         │  ЦИТАТА НЕ НАЙДЕНА   │        │
│  │ write_file()        │         │  ДОКУМЕНТ НЕ НАЙДЕН  │        │
│  └─────────────────────┘         └─────────────────────┘        │
│                                                                    │
│  KbAggregateService (chat RAG)                                    │
│  ├─ SUM intent → MapReduce из всех документов                    │
│  └─ LIST intent → метаданные без LLM                             │
└──────────────────────────────────────────────────────────────────┘
```

## Layered Lesson System

Уроки применяются в промпт агента тремя слоями:

```
Layer 1: SYSTEM (source='system')
├─ Поставляются релизом (db.changelog-5.sql)
├─ 6 встроенных правил
├─ approved=true, read-only
└─ limit: 10
         │
         ▼
Layer 2: USER GLOBAL (source≠'system', scenario_id=NULL, user_id=runner)
├─ Кросс-сценарные правила пользователя
├─ Применяются только к запуск этого пользователя
├─ approved=true (автоматически)
└─ limit: 10
         │
         ▼
Layer 3: SCENARIO (scenario_id=UUID, approved=true)
├─ Частные правила сценария
├─ Едут с сценарием к любому запускающему
├─ source: user, reviser (after approve), auto (after compress)
└─ limit: 10
```

**Защита от отравления**: auto-кандидаты (`source='auto'`) сохраняются `approved=false`.
Они НЕ попадают в промпт до одобрения пользователем.

## Citation Validation Pipeline

```
Агент генерирует ответ:
{ "записи": [ {"пункт": 1, "значение": "1 500 000", "цитата": "Итого: 1 500 000 руб.", "документ": "contract.pdf"} ] }
         │
         ▼
AgentEvidence.parse(answer)
         │
         ▼
AgentEvidence.validate(entries, docsByName)
         │
         ├── Шаг 1: цитата = blank → NO_QUOTE (или CONFIRMED для "не указано")
         │
         ├── Шаг 2: docText содержит normalized(цитата) → CONFIRMED
         │
         ├── Шаг 3: docText содержит все числа из цитаты → CALCULATED
         │
         ├── Шаг 4: любой документ содержит цитату → CONFIRMED (с исправлением doc)
         │
         ├── Шаг 5: единственный документ содержит все числа → CALCULATED
         │
         └── Шаг 6: fallback → QUOTE_NOT_FOUND или DOC_NOT_FOUND
```

**Анти-самоподтверждение**: рабочие файлы (`write_file`) исключены из проверки цитат.

## Hybrid Search

```
hybridSearch(collectionType, collectionId, embedding, queryText)
         │
         ├── vector_result = searchSimilar(embedding)         # ранг 1..K
         │      └── score[text] += 1 / (60 + rank)
         │
         ├── lexical_terms(queryText)                         # числа ≥4, слова ≥5
         │      │
         │      └── для каждого терма:
         │           lexical_result = searchLexical(collection, term)
         │           score[text] += 1 / (60 + rank)
         │
         └── merge: sort by score DESC, limit topK
              └── дистанция лексических хитов = 0.15 (условно-хорошая)
```

**lexicalTerms**: до 3 самых длинных термина (числа ≥4 цифр или слова ≥5 букв).

## KB Aggregate

```
tryAggregate(kbIds, query)
         │
         ├── SUM intent? ("общая сумма", "сумма по всем", "итого")
         │      ├── docs > maxDocs (200) → отказ + рекомендация сценария
         │      └── MapReduce:
         │           ├── parallelism=2: извлечь value из каждого документа
         │           ├── retry miss-ы последовательно
         │           ├── total = sum кодом
         │           └── контекст: "ИТОГО: N | docs: file1=N | file2=N"
         │
         └── LIST intent? ("сколько документов", "перечисли все")
                └── metadata без LLM: "Всего: N | 1. file1 | 2. file2 | ..."
```

## Agent Document Tools

### Инструменты (Function Calling)

| Инструмент | Описание |
|------------|----------|
| `search_documents(query, [docs])` | Точный поиск подстроки с контекстом |
| `read_document(name, offset)` | Чтение фрагмента (12 000 символов) |
| `search_knowledge_base(query)` | Семантический поиск по БЗ (опционально) |
| `note_thought(thought)` | Рассуждение (до 15 шт.) |
| `write_file(name, content)` | Рабочий файл прогона (до 60k символов) |

### Защита от зацикливания

```
MAX_TOOL_CALLS = 40                          # общий лимит
MAX_SEQUENTIAL_READS = 3                     # одного файла подряд
FRUITLESS_STREAK_LIMIT = 3                   # пустых поисков
seenCalls (HashSet)                          # дедуп вызовов
isSequentialReadBinge(name)                  # детект "листания"
runCancelled (AtomicBoolean)                 # остановка
```

### ReWOO Prefetch

Пакетный поиск без round-trip'ов модели:
1. Модель генерирует список `SearchRequest[]`
2. `prefetch(queries)` выполняет ВСЕ поиски сразу
3. Результаты компактно подкладываются в промпт
4. Основной цикл добирает точечно

## Scenario Engine Improvements

### Cancel Flow

```
POST /api/scenarios/runs/{runId}/cancel
    │
    ▼
ScenarioEngine.requestCancel(runId)
    │
    ├── activeGraphs[runId].requestCancel()     # AtomicBoolean = true
    ├── continueStep(runId)                      # снять паузу step mode
    │
    ▼
Узел проверяет: graph.isCancelRequested()
    │
    ▼ Прогон завершается FAILED
```

### Checkpoint

```
try {
    executorNode.execute(...)
} catch (Exception e) {
    handleNodeError(..., executorNode)
        │
        └── saveNodeCheckpoint(step, executorNode)
                │
                └── stepService.appendOutputData("checkpoint", checkpoint)
```

### Shared Scenarios

```
runScenario(userId, scenarioId):
    model = scenarioRepository.findById(scenarioId)
    │
    ├── if model.shared == true   → любой пользователь может запустить
    └── if model.shared == false  → только автор (UserUtils.checkUserId)
```

## Configuration

### Новые параметры application.yaml

| Параметр | Значение по умолчанию | Описание |
|----------|----------------------|----------|
| `app.chat.aggregate-enabled` | `true` | Включить агрегирующие вопросы |
| `app.chat.aggregate-max-docs` | `200` | Лимит документов для агрегации |
| `app.chat.aggregate-doc-char-limit` | `30 000` | Лимит символов на документ |
| `app.chat.aggregate-parallelism` | `2` | Параллельность извлечений |
| `app.chat.rag-short-query-chars` | `60` | Порог короткой реплики |
| `app.gigachat.call-hard-timeout-seconds` | `660` | Жёсткий таймаут LLM-вызова |
| `spring.gigachat.internal.read-timeout` | `${GIGACHAT_READ_TIMEOUT:60s}` | Читаемый таймаут GigaChat |
