## ADDED Requirements

### Requirement: Топологическая сортировка графа
Система SHALL сортировать узлы графа сценария топологически (алгоритм Кана) для определения порядка выполнения.

#### Scenario: Линейный граф
- **WHEN** граф содержит узлы A→B→C (ребро A→B, ребро B→C)
- **THEN** порядок сортировки: A, B, C (in_degree: A=0, B=1, C=1)
- **THEN** `OUTPUT_NODE` всегда имеет out_degree=0

#### Scenario: Циклический граф
- **WHEN** граф содержит цикл A→B→C→A
- **THEN** выбрасывается `ScenarioException(400)`: "Graph contains a cycle"
- **THEN** выполнение прерывается

### Requirement: Выполнение узлов волнами
Система SHALL выполнять узлы сценария параллельными волнами (независимые узлы в одной волне) через `ExecutorCompletionService`.

#### Scenario: Два независимых узла
- **WHEN** граф содержит A (INPUT_NODE) и B (PROCESSING_NODE) без рёбер между ними
- **THEN** оба выполняются параллельно (волна 1: оба)
- **THEN** `parallelThreads` по умолчанию равен **4** (соответствует `@Value("${app.scenario.parallel-threads:4}")` в `ScenarioEngine`)

### Requirement: Skip-set при ветвлении (DFS-обход)
Система SHALL помечать невыбранные ветви и их потомков как `SKIPPED`, когда узел Switch/If выполняет ветвление.

#### Scenario: Пропуск ветви Switch
- **WHEN** `SWITCH_NODE` направляет выполнение в ветвь B1, а не B2
- **THEN** B2 и все потомки B2 помечаются `SKIPPED`
- **THEN** `AbstractScenarioExecutor.getSkipSet()` вычисляет через DFS-обход потомков

### Requirement: SSE-события на всех фазах выполнения
Система SHALL эмитировать SSE-события при изменении статуса, статуса узлов, прогресса шагов, результатов RAG и вывода файлов.

#### Scenario: Событие статуса
- **WHEN** запуск сценария начинается
- **THEN** эмитируется `type="status"`, `run_id`, `status="RUNNING"`
- **WHEN** запуск сценария завершается
- **THEN** эмитируется `type="status"`, `status="COMPLETED"`

#### Scenario: Событие статуса узла
- **WHEN** узел начинает выполнение
- **THEN** эмитируется `type="node_status"`, `node_id`, `status="RUNNING"`
- **WHEN** узел завершает выполнение
- **THEN** эмитируется `type="node_status"`, `status="COMPLETED"`

### Requirement: Пошаговый режим с паузой/продолжением
Система SHALL поддерживать отладочный пошаговый режим: пауза перед каждым узлом через `CompletableFuture<Void>` и продолжение через endpoint `/continue`.

> **Таймаут**: `PAUSE_TIMEOUT_MINUTES = 30` (hardcoded в `ScenarioEngine.java`). `@Scheduled(fixedRate = 60000)` очищает просроченные сессии.

#### Scenario: Пауза перед каждым узлом
- **WHEN** сценарий запускается с `step_mode=true`
- **THEN** перед каждым узлом создаётся `CompletableFuture<Void>` (таймаут 30 минут)
- **THEN** через SSE эмитируется `type="step_paused"`, `node_id`, `total`
- **THEN** `POST /api/scenarios/runs/{runId}/continue` завершает future

#### Scenario: Отключение пошагового режима во время выполнения
- **WHEN** `POST /api/scenarios/runs/{runId}/disable-step-mode`
- **THEN** все ожидающие `CompletableFuture` завершаются
- **THEN** оставшиеся узлы выполняются без пауз