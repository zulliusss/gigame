## ADDED Requirements

### Requirement: Экспорт сценария в DOCX
Система SHALL экспортировать завершённые прогоны сценариев в DOCX через Apache POI, с опциональным включением шагов.

#### Scenario: Экспорт с шагами
- **WHEN** пользователь запрашивает `GET /api/scenarios/runs/{runId}/export?include_steps=true`
- **THEN** вызывается `ExportToDocx.generateDocx(runId, runDetail, includeSteps=true)`
- **THEN** DOCX содержит: заголовок "Результат сценария", статус, таблицу шагов (вход/выход/промпт), результат
- **THEN** ответ с `Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document`
- **THEN** имя файла: `scenario-result-{runId}.docx`

#### Scenario: Экспорт без шагов
- **WHEN** `include_steps=false`
- **THEN** включаются только статус и финальный результат
- **THEN** детали узлов не экспортируются

### Requirement: Экспорт JSON в XLSX
Система SHALL конвертировать JSON-вывод сценария в XLSX с автоматическим определением колонок и автоподбором ширины.

#### Scenario: Простой JSON в XLSX
- **WHEN** вызывается `ScenarioResultToXlsx.jsonToXlsx(jsonData, null)`
- **THEN** все поля JSON становятся колонками XLSX
- **THEN** числа определяются как числовые, строки — как текст
- **THEN** автоподбор ширины применяется ко всем колонкам

#### Scenario: Колонки по правилам
- **WHEN** переданы `rules="{колонки: [\"name\", \"value\"], группа: \"\"}"`
- **THEN** выводятся только колонки `name` и `value`
- **THEN** заголовок имеет стиль с границей и жирным шрифтом