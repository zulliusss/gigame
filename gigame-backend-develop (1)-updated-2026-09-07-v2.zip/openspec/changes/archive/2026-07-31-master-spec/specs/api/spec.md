## ADDED Requirements

### Requirement: Все endpoint'ы требуют X-UserId
Система SHALL требовать заголовок `X-UserId` в каждом REST-запросе и WebSocket-handshake для мультитенантности.

#### Scenario: Отсутствующий X-UserId
- **WHEN** запрос отправлен без заголовка `X-UserId`
- **THEN** `UserUtils.getUserId()` возвращает `"anonymous"` (запасной вариант)
- **THEN** `AccessDeniedException` не выбрасывается, если нет явной проверки

#### Scenario: Несовпадение user_id
- **WHEN** запрос с `X-UserId=user1` пытается получить доступ к ресурсу `user2`
- **THEN** выбрасывается `AccessDeniedException(403)`

### Requirement: Формат SSE-потока
Система SHALL возвращать ответы чата/сценария как SSE-потоки в формате `data: {json}`.

> **Важно**: SSE-потоки для чата и сценариев доступны **только через WebSocket**, не через REST.

#### Scenario: SSE чата через WebSocket
- **WHEN** клиент отправляет через WebSocket `/ws/chat` сообщение `{"action": "SEND", "conversation_id": "uuid", "content": "токен"}`
- **THEN** возвращается SSE-поток: `data: {"conversation_id": "uuid", "content": "токен", "done": false}` на каждый токен
- **THEN** `data: {"content": "", "done": true, "usage": {"total_tokens": N}}` для финального события

#### Scenario: SSE сценария через WebSocket
- **WHEN** клиент отправляет через WebSocket `/ws/scenario` сообщение `{"scenario_id": "uuid", "step_mode": false}`
- **THEN** SSE-события: `type="status"`, `type="node_status"`, `type="step_paused"`, `type="step_complete"`
- **THEN** каждое событие содержит поле `type` как дискриминатор

### Requirement: Конвенция snake_case для DTO
Система SHALL использовать `snake_case` для всех имён полей JSON через `@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)`.

#### Scenario: Сериализация DTO
- **WHEN** клиент получает `ConversationResponse`
- **THEN** поля: `{id, title, knowledge_base_id, knowledge_base_ids, model, temperature, created_at, updated_at}`
- **THEN** НЕ `{id, title, knowledgeBaseId, knowledgeBaseIds, model, temperature, createdAt, updatedAt}`

### Requirement: REST-интерфейс чата
Система SHALL предоставлять REST-эндпоинты для CRUD диалогов. Сообщения отправляются через WebSocket.

#### Scenario: CRUD диалогов
- **GET** `/api/conversations?q=` — список с поиском по заголовку
- **POST** `/api/conversations` — создание (`title` по умолчанию "Новый диалог")
- **GET** `/api/conversations/{id}` — с сообщениями
- **PUT** `/api/conversations/{id}` — обновление заголовка
- **DELETE** `/api/conversations/{id}` — удаление
- **POST** `/api/conversations/{id}/upload` — загрузка документов в кэш (multipart)

### Requirement: REST-интерфейс документов
Система SHALL предоставлять REST-эндпоинты для управления документами.

#### Scenario: CRUD документов
- **GET** `/api/documents` — список всех документов (отсутствует — реализовано только GET по ID)
- **POST** `/api/documents` — загрузка файла (отсутствует — документы загружаются через KB)
- **GET** `/api/documents/{id}` — получение документа с извлечённым текстом
- **DELETE** `/api/documents/{id}` — удаление

### Requirement: REST-интерфейс баз знаний
Система SHALL предоставлять полный CRUD для баз знаний.

#### Scenario: CRUD БЗ
- **GET** `/api/knowledge-bases?q=` — список
- **POST** `/api/knowledge-bases` — создание
- **GET** `/api/knowledge-bases/{id}` — с документами
- **PUT** `/api/knowledge-bases/{id}` — обновление
- **DELETE** `/api/knowledge-bases/{id}` — удаление + каскадное удаление KB-эмбеддингов
- **POST** `/api/knowledge-bases/{id}/documents` — загрузка документа (async индексация)
- **POST** `/api/knowledge-bases/{id}/documents/{docId}/reindex` — переиндексация
- **DELETE** `/api/knowledge-bases/{id}/documents/{docId}` — удаление из БЗ

### Requirement: REST-интерфейс сценариев
Система SHALL предоставлять CRUD для сценариев и управление запусками. Запуск сценария — через WebSocket.

#### Scenario: CRUD сценариев
- **GET** `/api/scenarios` — список
- **POST** `/api/scenarios` — создание
- **GET** `/api/scenarios/{id}` — детали
- **PUT** `/api/scenarios/{id}` — обновление
- **DELETE** `/api/scenarios/{id}` — удаление
- **POST** `/api/scenarios/{id}/duplicate` — дублирование
- **GET** `/api/scenarios/{id}/runs` — список запусков сценария (REST)
- **POST** `/api/scenarios/{id}/upload` — загрузка файлов в кэш

#### Scenario: Управление запусками
- **GET** `/api/scenarios/runs/{runId}` — статус запуска
- **GET** `/api/scenarios/runs/{runId}/export?include_steps=true` — экспорт в DOCX
- **POST** `/api/scenarios/runs/{runId}/continue` — продолжить paused/failed прогон
- **POST** `/api/scenarios/runs/{runId}/disable-step-mode` — отключить step-режим

#### Scenario: Запуск через WebSocket
- **WS** `/ws/scenario` — запуск, возобновление сценария (не через REST `POST /api/scenarios/{id}/run`)
- **WHEN** клиент отправляет `{"scenario_id": "uuid", "step_mode": false}`
- **THEN** `ScenarioWebSocketHandler.handle()` направляет в `scenarioService.runScenario()`

### Requirement: Версии сценариев
Система SHALL поддерживать версионирование сценариев.

#### Scenario: Управление версиями
- **GET** `/api/scenarios/{id}/versions` — список версий
- **POST** `/api/scenarios/{id}/versions/{versionNo}/restore` — восстановить версию

### Requirement: WebSocket-интерфейс чата
Система SHALL принимать WebSocket-сообщения с `ActionType` (SEND, REGENERATE, EDIT) и возвращать SSE-потоки.

#### Scenario: Отправка сообщения через WebSocket
- **WHEN** клиент отправляет `{"action": "SEND", "conversation_id": "uuid", "content": "Привет"}`
- **THEN** `ChatWebSocketHandler.handle()` парсит сообщение
- **THEN** вызывается `ChatService.sendMessageStream()`
- **THEN** возвращается SSE-поток

#### Scenario: Редактирование через WebSocket
- **WHEN** клиент отправляет `{"action": "EDIT", "message_id": "uuid"}`
- **THEN** `ChatWebSocketHandler.handle()` направляет в `editMessageStream()`
- **THEN** AI перегенерирует ответ с отредактированного сообщения

#### Scenario: Регенерация через WebSocket
- **WHEN** клиент отправляет `{"action": "REGENERATE", "conversation_id": "uuid", "message_id": "uuid"}`
- **THEN** последнее сообщение ассистента удаляется
- **THEN** GigaChat генерирует новый ответ с тем же контекстом

### Requirement: Формат ответа об ошибке
Система SHALL возвращать ошибки в формате `ErrorResponse` с полями `status_code`, `error`, `message`, `timestamp`, `details`.

#### Scenario: Ошибка 404
- **WHEN** ресурс не найден
- **THEN** `NotFoundException(404)` → `ErrorResponse{status_code: 404, error: "Not Found", message: "сообщение", timestamp: now, details: null}`
- **THEN** `@ControllerAdvice` маппит в `ResponseEntity`
