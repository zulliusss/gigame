## ADDED Requirements

### Requirement: Загрузка документа
Система SHALL принимать загрузку файлов (PDF, DOCX, XLSX, TXT) до 30MB на файл, извлекать текст и сохранять в базе данных.

#### Scenario: Успешная загрузка PDF
- **WHEN** пользователь отправляет `POST /api/documents` с multipart-файлом `report.pdf` (10MB, `application/pdf`)
- **THEN** PDFBox 3.0.7 извлекает текст из PDF
- **THEN** запись в `documents` содержит `filename="report.pdf"`, `content_type="application/pdf"`, `size_bytes=10485760`, `extracted_text`, `user_id`
- **THEN** ответ — `DocumentViewResponse(id, filename, content_type, size_bytes, extracted_text, created_at)` с HTTP 201

#### Scenario: Неподдерживаемый формат
- **WHEN** пользователь загружает `image.png`
- **THEN** выбрасывается `FileException(422)`: "Unsupported file format: png"

### Requirement: Извлечение текста из разных форматов
Система SHALL поддерживать извлечение текста из PDF (PDFBox 3.0.7), DOCX/XLSX (Apache POI 5.5.1), TXT (прямое чтение) и plain-text вариантов.

#### Scenario: Извлечение текста из DOCX
- **WHEN** пользователь загружает `document.docx`
- **THEN** Apache POI XWPF парсит параграфы в текст
- **THEN** `extracted_text` содержит объединённый текст параграфов

#### Scenario: Извлечение текста из XLSX
- **WHEN** пользователь загружает `spreadsheet.xlsx`
- **THEN** Apache POI XSSF обходит все строки и ячейки
- **THEN** `extracted_text` содержит значения ячеек, объединённые переносами строк

### Requirement: OCR для отсканированных PDF
Система SHALL опционально выполнять OCR для отсканированных PDF (извлечено <40 символов) через GigaChat Files API.

#### Scenario: Запуск OCR
- **WHEN** PDF даёт меньше `minParsedChars=40` символов и `ocr-via-gigachat=true`
- **THEN** PDF отправляется в GigaChat Files API для распознавания
- **THEN** `extracted_text` заменяется результатом OCR
- **THEN** настройки OCR: `ocr-model`, `ocr-max-tokens=8000`