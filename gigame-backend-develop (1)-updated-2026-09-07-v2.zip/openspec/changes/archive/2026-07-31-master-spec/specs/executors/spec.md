## ADDED Requirements

### Requirement: 12 executor-тизов по NodeType Enum
Система SHALL содержать ровно 12 типов узлов сценариев, определяемых `ScenarioNodeType` enum, и 12 соответствующих классов-исполнителей через `ScenarioExecutorFactory`.

#### Scenario: Перечень executor-типов
- **WHEN** рассматривается `ScenarioNodeType` enum
- **THEN** присутствуют значения: `PROCESSING_NODE`, `IF_NODE`, `SWITCH_NODE`, `LOOP_NODE`, `INPUT_NODE`, `OUTPUT_NODE`, `CALC_NODE`, `AGGREGATE_NODE`, `TRANSFORM_NODE`, `SUBSCENARIO_NODE`, `CONTROL_NODE`, `WAIT_NODE`
- **THEN** каждое значение маппится на отдельный класс `ScenarioExecutorXxxNode extends AbstractScenarioExecutor`

## Overview

Система содержит **12** конкретных исполнителей узлов сценариев (не 16, как указывалось ранее). Все они реализуют `AbstractScenarioExecutor` и создаются через `ScenarioExecutorFactory` по значению `ScenarioNodeType`.

### NodeType Enum (12 значений)

| Enum Value | Класс | Значение в графе |
|------------|-------|-----------------|
| `INPUT_NODE` | `ScenarioExecutorInputNode` | `"input"` |
| `OUTPUT_NODE` | `ScenarioExecutorOutputNode` | `"output"` |
| `PROCESSING_NODE` | `ScenarioExecutorProcessingNode` | `"processing"` |
| `LOOP_NODE` | `ScenarioExecutorLoopNode` | `"loop"` |
| `SWITCH_NODE` | `ScenarioExecutorSwitchNode` | `"switch"` |
| `IF_NODE` | `ScenarioExecutorIfNode` | `"if_node"` |
| `CALC_NODE` | `ScenarioExecutorCalcNode` | `"calc"` |
| `AGGREGATE_NODE` | `ScenarioExecutorAggregateNode` | `"aggregate"` |
| `TRANSFORM_NODE` | `ScenarioExecutorTransformNode` | `"transform"` |
| `SUBSCENARIO_NODE` | `ScenarioExecutorSubscenarioNode` | `"subscenario"` |
| `CONTROL_NODE` | `ScenarioExecutorControlNode` | `"control"` |
| `WAIT_NODE` | `ScenarioExecutorWaitNode` | `"wait"` |

---

### Requirement: InputNode — проброс документов
`ScenarioExecutorInputNode` SHALL передавать текст документов как есть на следующий узел без вызова LLM.

#### Scenario: Выполнение InputNode
- **WHEN** `INPUT_NODE` выполняется
- **THEN** возвращает `documentsText` — конкатенацию текстов всех входных `ScenarioRunDoc`
- **THEN** узел помечается `COMPLETED`

### Requirement: OutputNode — объединение предшественников
`ScenarioExecutorOutputNode` SHALL объединять выходы всех предшественников и поддерживать типы `TEXT_FILE`/`EXCEL`.

#### Scenario: Объединение текстового вывода
- **WHEN** `OUTPUT_NODE` выполняется с `OUTPUT_TYPE=TEXT_FILE`
- **THEN** конкатенирует все поля `previousOutput` от предшественников

#### Scenario: Экспорт в Excel
- **WHEN** `OUTPUT_NODE` имеет тип `EXCEL`
- **THEN** вызывается `ScenarioResultToXlsx.jsonToXlsx(jsonData, rules)`
- **THEN** эмитируется `type="file_output"` с `mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"`

### Requirement: ProcessingNode — вызов LLM с RAG
`ScenarioExecutorProcessingNode` SHALL вызывать GigaChat с промптом, RAG-контекстом (через `buildPrompt`), разрешением выражений (`{{output:label}}`) и групповым режимом.

#### Scenario: RAG-контекст в промпте
- **WHEN** `PROCESSING_NODE` выполняется с `buildPrompt(input, documents, kbChunks, rag)`
- **THEN** RAG-контекст, тексты документов и чанки БЗ добавляются в промпт
- **THEN** `{{output:prev_node_label}}` разрешается через `ExpressionResolver`

#### Scenario: Групповой режим sequential
- **WHEN** `group_mode="sequential"` установлен
- **THEN** каждый документ обрабатывается последовательно
- **THEN** `group-parallelism` = 1 (один LLM-вызов за раз)

### Requirement: LoopNode — classify strict / full analysis
`ScenarioExecutorLoopNode` SHALL обрабатывать каждый документ через GigaChat в режиме `classify_strict` или `full analysis`.

#### Scenario: Строгая классификация
- **WHEN** `loop_mode="classify_strict"` и `classes=["positive", "negative", "neutral"]`
- **THEN** каждый документ классифицируется GigaChat однословным ответом
- **THEN** `mode="classify_strict"` → ответ — одно из `["positive", "negative", "neutral"]`

#### Scenario: Полный анализ
- **WHEN** `loop_mode="full analysis"`
- **THEN** каждый документ анализируется полным промптом GigaChat
- **THEN** на каждой итерации эмитируются `type="node_status"` и `type="loop_progress"`

### Requirement: SwitchNode — маршрутизация по классификации
`ScenarioExecutorSwitchNode` SHALL направлять выполнение на основе классификации узла или правил.

#### Scenario: Ветвь по умолчанию
- **WHEN** ни одно правило не совпало
- **THEN** используется `defaultLabelSet`
- **THEN** эмитируется `type="switch_result"`, `matched_rule="default"`

### Requirement: IfNode — условное ветвление
`ScenarioExecutorIfNode` SHALL вычислять условия с операторами: `contains`, `equals`, `greater_than`, `less_than`, `startsWith`.

#### Scenario: Проверка contains
- **WHEN** `IF_NODE` с `operator="contains"`, `field="output.text"`, `value="error"`
- **THEN** вычисляется условие: `output.text.contains("error")`
- **THEN** эмитируется `type="if_result"`, `condition_met=true/false`

### Requirement: CalcNode — вычисление формул
`ScenarioExecutorCalcNode` SHALL вычислять формулы через `FormulaEvaluator` с BigDecimal и поддержкой функций.

#### Scenario: Простая формула
- **WHEN** `formula="SUM(A1:A10)"`
- **THEN** `FormulaEvaluator` вычисляет с агрегацией
- **THEN** результат — `BigDecimal`

### Requirement: AggregateNode — агрегация данных
`ScenarioExecutorAggregateNode` SHALL агрегировать данные по ключу группы с опциональной фильтрацией.

#### Scenario: Группировка
- **WHEN** `AGGREGATE_NODE` с `groupKey="category"`
- **THEN** данные группируются по полю `category`
- **THEN** `SUM/AVG` вычисляются по каждой группе

### Requirement: TransformNode — преобразования текста
`ScenarioExecutorTransformNode` SHALL поддерживать преобразования текста: `regex_replace`, `substring`, `split`, `join`, `upper`, `lower`, `trim`, `replace`.

#### Scenario: Замена по регулярному выражению
- **WHEN** `TRANSFORM_NODE` с `operation="regex_replace"`, `pattern="\d+"`, `replacement="NUMBER"`
- **THEN** все цифры в выходе заменяются на "NUMBER"

### Requirement: SubscenarioNode — рекурсивное выполнение
`ScenarioExecutorSubscenarioNode` SHALL поддерживать рекурсивное выполнение подсценария с максимальной глубиной 2.

#### Scenario: Простая рекурсия
- **WHEN** `SUBSCENARIO_NODE` с `subScenarioId`
- **THEN** дочерний сценарий выполняется с теми же входными документами
- **THEN** максимальная глубина рекурсии = 2 (соответствует `MAX_SUB_DEPTH = 2` в `ScenarioEngine`)

### Requirement: ControlNode — валидация
`ScenarioExecutorControlNode` SHALL проверять предусловия и останавливать выполнение при ошибке.

#### Scenario: Ошибка валидации
- **WHEN** `CONTROL_NODE` вычисляет условие = false
- **THEN** срабатывает `on_error="stop"`
- **THEN** выбрасывается `ScenarioException(400)`

### Requirement: WaitNode — ожидание
`ScenarioExecutorWaitNode` SHALL поддерживать настраиваемую задержку.

#### Scenario: Ожидание
- **WHEN** `WAIT_NODE` с `duration_ms=5000`
- **THEN** поток засыпает на 5 секунд