## ADDED Requirements

### Requirement: Жизненный цикл прогона сценария
Система SHALL отслеживать прогоны сценариев с переходами статуса: `RUNNING → COMPLETED / FAILED`, с поддержкой `step_mode`.

> **Важно**: Запуск сценария происходит через WebSocket (`/ws/scenario`), не через REST `POST /api/scenarios/{id}/run`.

#### Scenario: Запуск прогона через WebSocket
- **WHEN** пользователь отправляет через WebSocket `/ws/scenario` сообщение `{"scenario_id": "uuid", "step_mode": false}`
- **THEN** `ScenarioWebSocketHandler.handle()` направляет в `scenarioService.runScenario()`
- **THEN** создаётся `ScenarioRun` со `status="RUNNING"`, `user_id`
- **THEN** граф сценария выполняется через `ScenarioEngine.doExecute()`
- **THEN** SSE-события эмитируются в реальном времени

#### Scenario: Завершение прогона
- **WHEN** все узлы выполнились успешно
- **THEN** `status` устанавливается в `"COMPLETED"`, заполняется `result`
- **THEN** устанавливается `completed_at`

### Requirement: Возобновление упавшего прогона
Система SHALL позволять возобновлять прогон со статусом `FAILED` с последнего успешного узла.

#### Scenario: Возобновление после ошибки
- **WHEN** `POST /api/scenarios/runs/{runId}/continue` на прогоне со статусом `FAILED`
- **THEN** вызывается `ScenarioEngine.resumeExecution()`
- **THEN** завершённые LLM-узлы восстанавливаются через `restoreLlmNode()`
- **THEN** выполнение продолжается с упавшего узла

### Requirement: Таймаут пошагового режима
Система SHALL очищать зависшие сессии пошагового режима после 30-минутного таймаута через `@Scheduled`.

#### Scenario: Очистка зависшей сессии
- **WHEN** пошаговый режим находится на паузе дольше 30 минут
- **THEN** `@Scheduled(fixedRate = 60000)` → `evictExpiredStepEvents()`
- **THEN** `CompletableFuture` отменяется
- **THEN** прогон помечается `FAILED`