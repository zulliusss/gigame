## ADDED Requirements

### Requirement: CRUD для баз знаний
Система SHALL поддерживать полный CRUD для баз знаний с мультитенантностью через `user_id`.

#### Scenario: Создание БЗ
- **WHEN** пользователь отправляет `POST /api/knowledge-bases` с `{"name": "Маркетинговые документы", "description": "Все маркетинговые материалы"}`
- **THEN** создаётся запись в `knowledge_bases` с `user_id`
- **THEN** ответ — `KBResponse(id, name, description, created_at, updated_at)` с HTTP 201

#### Scenario: Удаление БЗ
- **WHEN** пользователь отправляет `DELETE /api/knowledge-bases/{id}`
- **THEN** БЗ удаляется
- **THEN** все связи `KBDocument` удаляются каскадно
- **THEN** все kb-эмбеддинги удаляются (`deleteKBCollection(id)`)

### Requirement: Загрузка документа в БЗ
Система SHALL принимать загрузку документа в БЗ, асинхронно индексировать и отслеживать статус.

#### Scenario: Загрузка с асинхронной индексацией
- **WHEN** пользователь отправляет `POST /api/knowledge-bases/{id}/documents` с файлом
- **THEN** `Document` создаётся через `DocumentService`
- **THEN** создаётся `KBDocument(kb_id, doc_id, status="processing")`
- **THEN** `DocumentIndexService.indexDocumentAsync(kbId, docId, kbDocId)` запускается через `@Async`
- **THEN** при успехе: `status → "ready"`; при ошибке: `status → "error"`, заполняется `error_message`
- **THEN** ответ — `KBDocumentResponse(id, filename, status="processing")` с HTTP 201

### Requirement: RAG-поиск с LLM-роутером (fail-open)
Система SHALL маршрутизировать RAG-запросы к релевантным БЗ через GigaChat, с откатом на все БЗ при ошибке.

#### Scenario: Успешный LLM-роутинг
- **WHEN** `ragRouterEnabled=true` и пользователь отправляет сообщение
- **THEN** GigaChat получает запрос: "Определи, каких баз знаний касается вопрос. Ответь номерами через запятую или 'all'."
- **THEN** ответ парсится: `"1,3"` → выбраны БЗ с индексами 1 и 3

#### Scenario: Откат при ошибке роутера
- **WHEN** ответ LLM-роутера не удаётся распарсить
- **THEN** используются все привязанные БЗ (fail-open)
- **THEN** `filterRelevantKbs()` всё равно применяет `RAG_DISTANCE_DELTA=0.08` для фильтрации БЗ

### Requirement: Несколько БЗ на один диалог
Система SHALL поддерживать несколько баз знаний на один диалог через колонку `knowledge_base_ids` типа JSONB.

#### Scenario: Диалог с несколькими БЗ
- **WHEN** диалог создаётся с `knowledge_base_ids=["kb-uuid-1", "kb-uuid-2"]`
- **THEN** обе БЗ являются кандидатами для RAG-маршрутизации
- **THEN** RAG-поиск выполняется по обеим (с учётом фильтрации LLM-роутером)