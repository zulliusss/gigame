## ADDED Requirements

### Requirement: Создание диалога
Система SHALL позволять пользователям создавать новые диалоги с GigaChat, опционально указывая модель, температуру и несколько баз знаний.

#### Scenario: Создание по умолчанию
- **WHEN** пользователь отправляет `POST /api/conversations` с JSON-телом `{"title": "Новый диалог", "model": "GigaChat-2-Max", "temperature": 0.7}`
- **THEN** создаётся запись в `conversations` с `user_id`, `title="Новый диалог"`, `model="GigaChat-2-Max"`, `temperature=0.7`
- **THEN** ответ — `ConversationResponse(id, title, model, temperature, created_at, updated_at)` с HTTP 201

#### Scenario: Без указания заголовка
- **WHEN** пользователь отправляет `POST /api/conversations` без заголовка
- **THEN** `title` принимает значение по умолчанию `"Новый диалог"`
- **THEN** возвращается `ConversationResponse` со стандартным заголовком

### Requirement: Отправка сообщения через WebSocket
Система SHALL передавать ответы AI потоком через WebSocket (`/ws/chat`) с эмиссией токенов в реальном времени.

> **Важно**: Отправка сообщений **не** доступна через REST (`POST /api/conversations/{id}/messages` отсутствует). Используется WebSocket `/ws/chat`.

#### Scenario: Нормальная потоковая передача
- **WHEN** пользователь отправляет через WebSocket `/ws/chat` сообщение `{"action": "SEND", "conversation_id": "uuid", "content": "Привет", "document_ids": []}`
- **THEN** `ChatWebSocketHandler.handle()` парсит `ActionType.SEND`
- **THEN** вызывается `ChatService.sendMessageStream()`
- **THEN** ответ — SSE-поток:
  `{"content": "При", "done": false}` →
  `{"content": "вет", "done": false}` →
  `{"content": "", "done": true, "usage": {"total_tokens": 150}}`
- **THEN** каждый токен эмитируется как `data: {json}` — без префикса `event:`
- **THEN** `done: true` сигнализирует конец потока с метаданными `usage`

#### Scenario: Ошибка во время потоковой передачи
- **WHEN** GigaChat API недоступен
- **THEN** SSE эмитирует `{"error": "Service unavailable", "done": true}`
- **THEN** `Message.sources` не модифицируется

### Requirement: Автоматическая генерация заголовка
Система SHALL автоматически генерировать заголовки диалогов из первого сообщения пользователя через GigaChat.

#### Scenario: Первое сообщение запускает генерацию
- **WHEN** пользователь отправляет первое сообщение в новом диалоге
- **THEN** `autoGenerateTitle()` выполняется асинхронно на `Schedulers.boundedElastic()`
- **THEN** GigaChat генерирует заголовок (макс `maxAutoTitleLength=100` символов)
- **THEN** `conversation.title` обновляется в базе данных

### Requirement: LLM-роутинг по нескольким базам знаний
Система SHALL маршрутизировать RAG-запросы к релевантным базам знаний через GigaChat (LLM-роутер), с fail-open при ошибке.

#### Scenario: Успешная маршрутизация
- **WHEN** пользователь отправляет сообщение с `knowledge_base_ids=["kb1", "kb2"]` и `ragRouterEnabled=true`
- **THEN** GigaChat вызывается с промптом: "Определи, каких баз знаний касается вопрос. Ответь номерами через запятую или 'all'."
- **THEN** `parseRoutedKbs()` парсит ответ как "1,3" → выбираются БЗ с индексами 1 и 3
- **THEN** `filterRelevantKbs()` применяет фильтр `RAG_DISTANCE_DELTA=0.08`

#### Scenario: Ошибка роутера (fail-open)
- **WHEN** ответ GigaChat не удаётся распарсить (например, "unknown, error, не знаю")
- **THEN** используются все привязанные БЗ (откат: `ragRouterEnabled=true` → все)
- **THEN** `filterRelevantKbs()` всё равно применяет фильтр по расстоянию

### Requirement: Суммаризация истории диалога
Система SHALL суммаризировать старые сообщения истории, когда их количество превышает `maxHistoryMessages=20`.

#### Scenario: Суммаризация при переполнении
- **WHEN** в диалоге больше 20 сообщений
- **THEN** `updateConversationSummary()` выполняется асинхронно через `Schedulers.boundedElastic()`
- **THEN** GigaChat суммаризирует 15 самых старых сообщений в поле `conversation.summary`
- **THEN** `summaryMessageCount` увеличивается
- **THEN** в последующие промпты включается `summary` вместо оригинальных сообщений

### Requirement: Регенерация последнего ответа AI
Система SHALL позволять регенерировать последний ответ ассистента через WebSocket.

#### Scenario: Регенерация через WebSocket
- **WHEN** WebSocket-сообщение `{"action": "REGENERATE", "conversation_id": "uuid", "message_id": "uuid"}`
- **THEN** последнее сообщение ассистента удаляется
- **THEN** GigaChat генерирует новый ответ с тем же контекстом
- **THEN** SSE-поток отправляется обратно