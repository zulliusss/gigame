## ADDED Requirements

### Requirement: UUID для первичных ключей
Система SHALL использовать `UUID DEFAULT uuid_generate_v4()` как первичные ключи для JPA-сущностей с автогенерацией.

#### Scenario: Создание сущности
- **WHEN** сохраняется сущность с автогенерацией ID
- **THEN** `id` генерируется через `@GeneratedValue(strategy = GenerationType.UUID)`
- **THEN** БД использует `DEFAULT uuid_generate_v4()`

> **Исключение**: `ScenarioVersion` использует ручной `@Id` (без `@GeneratedValue`) — ID устанавливается из конструктора при создании версии.

### Requirement: 10 JPA-сущностей
Система SHALL содержать ровно 10 JPA-сущностей.

#### Scenario: Перечень сущностей
- **WHEN** рассматривается схема БД
- **THEN** присутствуют таблицы: conversations, messages, documents, knowledge_bases, kb_documents, embeddings, scenarios, scenario_runs, scenario_run_steps, scenario_versions
- **THEN** 4 root-сущности имеют `user_id`, 6 дочерних — нет

#### Scenario: Таблица сущностей
- **WHEN** проверяется полный перечень
- **THEN** сущности соответствуют таблице:

| # | Сущность | Таблица | user_id | Примечание |
|---|----------|---------|---------|------------|
| 1 | `Conversation` | conversations | ✅ | |
| 2 | `Message` | messages | ❌ | дочерняя |
| 3 | `Document` | documents | ✅ | |
| 4 | `KnowledgeBase` | knowledge_bases | ✅ | |
| 5 | `KBDocument` | kb_documents | ❌ | дочерняя |
| 6 | `Embedding` | embeddings | ❌ | дочерняя |
| 7 | `Scenario` | scenarios | ✅ | |
| 8 | `ScenarioRun` | scenario_runs | ❌ | дочерняя |
| 9 | `ScenarioRunStep` | scenario_run_steps | ❌ | дочерняя |
| 10 | `ScenarioVersion` | scenario_versions | ❌ | ручной @Id (не auto-UUID) |

### Requirement: user_id на root-сущностях
Система SHALL обеспечивать мультитенантность через колонку `user_id` на root-сущностях. Дочерние сущности (Message, KBDocument, Embedding, ScenarioRun, ScenarioRunStep) не имеют `user_id` — доступ контролируется через связь с родительской сущностью, у которой `user_id` есть.

#### Scenario: user_id на root-сущностях
- **WHEN** создаётся `Conversation`, `Document`, `KnowledgeBase` или `Scenario`
- **THEN** сохраняется `user_id`
- **THEN** только сущности с совпадающим `user_id` видны пользователю

#### Scenario: Дочерние сущности без user_id
- **WHEN** создаётся `Message`, `KBDocument`, `Embedding`, `ScenarioRun`, `ScenarioRunStep`
- **THEN** `user_id` колонка **отсутствует** (не требуется)
- **THEN** доступ контролируется через связь с родительской root-сущностью

### Requirement: JSONB для гибких данных
Система SHALL использовать JSONB (`@JdbcTypeCode(SqlTypes.JSON)`, `columnDefinition="jsonb"`) для всех гибких колонок. `Map<String, Object>` маппится через `@JdbcTypeCode(SqlTypes.JSON)`, не через `@Type(JsonType)`.

#### Scenario: Граф сценария в JSONB
- **WHEN** сценарий создаётся
- **THEN** `graph_data` сохраняется как `{nodes: [...], edges: [...]}` в `scenarios.graph_data`
- **THEN** `@JdbcTypeCode(SqlTypes.JSON)` маппит JPA `Map<String, Object>` → jsonb

#### Scenario: Источники сообщения в JSONB
- **WHEN** сообщение создаётся с RAG-источниками
- **THEN** `sources` сохраняется как `[{document_id, document_name, snippet}]` в `messages.sources`
- **THEN** `@JdbcTypeCode(SqlTypes.JSON)` обрабатывает маппинг

#### Scenario: Документы сообщения в JSONB
- **WHEN** сообщение создаётся с документом
- **THEN** `document_ids` (не `docs`) сохраняется как `["doc-uuid-1", "doc-uuid-2"]` в `messages.document_ids`
- **THEN** поле называется `document_ids`, не `docs`

### Requirement: pgvector с индексом IVFFlat
Система SHALL использовать `vector(1024)` с индексом IVFFlat (`vector_cosine_ops`, 100 списков) для поиска эмбеддингов. Вектор хранится как `float[]` с аннотациями `@Type(FloatArrayType.class)`, `@Array(length = 1024)`, `columnDefinition = "vector(1024)"` — **не** `@Type(JsonType)`.

#### Scenario: Создание индекса IVFFlat
- **WHEN** таблица эмбеддингов создаётся
- **THEN** `CREATE INDEX idx_embeddings_vector ON embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100)`

#### Scenario: Поиск с оператором <->
- **WHEN** вызывается `embeddingService.searchSimilar()`
- **THEN** `SELECT chunk_text FROM embeddings WHERE collection_type=? AND collection_id=? ORDER BY embedding <->? LIMIT topK`

### Requirement: Только Liquibase (без ddl-auto:update)
Система SHALL использовать Liquibase для всех изменений схемы (`ddl-auto: validate`), никогда `ddl-auto: update`.

#### Scenario: Миграция при запуске
- **WHEN** приложение запускается
- **THEN** `Liquibase` применяет все ожидающие изменения через SQL-файлы в `src/main/resources/db/changelog/`
- **THEN** `Hibernate` проверяет, что JPA-модель соответствует БД (`ddl-auto: validate`)
- **THEN** при несовпадении → `SchemaValidationException`