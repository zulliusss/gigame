# Tasks: Master Spec

## What needs to be done

1. ✅ **Proposal** — написан
2. ✅ **Specs (10)** — написаны
3. ✅ **Design** — написан
4. ✅ **Tasks** — написан

## Remaining

- [x] **Утверждение мастер-спеки**:
  - [x] Показать команде
  - [x] Синхронизировать с кодом (убедиться, что spec-файлы не расходятся с `src/`)
  - [x] Отправить на ревью в `#spec-review`
- [x] **Обновление context**:
  - [x] Обновить `openspec/context/03-architecture.md` — добавить ссылки на spec-артефакты
  - [x] Добавить `05-security-and-compliance.md` — пометить зоны без автономии агента
  - [x] Заполнить `07-anti-patterns.md` — уточнить у команды
- [x] **Привязка к CI/CD**:
  - [x] Добавить `mvn validate` + `checkstyle` в pipeline (если не было)
  - [x] Убедиться, что `mvn clean package` проходит с новым checkstyle
- [x] **Синхронизация с кодом**:
  - [x] ~~Проверить, что все endpoint из `specs/api/spec.md` есть в `ScenarioController`~~ — выполнено при аудите spec-vs-code
  - [x] ~~Проверить, что все DTO из `specs/api/spec.md` есть в `dto/scenario/`~~ — выполнено при аудите spec-vs-code
  - [x] ~~Проверить, что все 12+ executor-типов из `specs/executors/spec.md` есть в `ScenarioExecutorFactory`~~ — выполнено при аудите spec-vs-code
  - [x] ~~Проверить, что все SSE-события из `specs/scenario-engine/spec.md` есть в `ScenarioEventEmission`~~ — выполнено при аудите spec-vs-code
  - [x] ~~Проверить, что `open-in-view: false` — не меняли на `true`~~ — выполнено при аудите spec-vs-code
  - [x] ~~Проверить, что `ddl-auto: validate` — не меняли на `update`~~ — выполнено при аудите spec-vs-code
  - [x] **Финальная проверка**: перечитать все spec-файлы после правок, убедиться что изменения согласованы между собой