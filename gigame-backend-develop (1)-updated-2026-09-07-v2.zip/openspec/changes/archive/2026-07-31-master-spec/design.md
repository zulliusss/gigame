# Design: Master Architecture

## System Overview

```
┌─────────────────────────────────────────────────────┐
│                   GigaMe Backend                      │
│              (Spring Boot 3.5.15 / Java 17)          │
│                  Spring WebFlux (Reactive)           │
├─────────────────────────────────────────────────────┤
│                                                       │
│  ┌──────────────┐   ┌──────────────┐                │
│  │   Chat       │   │  Documents    │                │
│  │  (SSE)      │   │  (PDF/DOCX)  │                │
│  │  + WebSocket │   │  + OCR       │                │
│  └──────────────┘   └──────────────┘                │
│                                                       │
│  ┌──────────────┐   ┌──────────────┐                │
│  │   KB + RAG  │   │ Embeddings   │                │
│  │   (LLM-      │   │ (pgvector    │                │
│  │    роутинг)  │   │  IVFFlat)   │                │
│  └──────────────┘   └──────────────┘                │
│                                                       │
│  ┌─────────────────────────────────────────┐         │
│  │         Scenario Engine                   │         │
│  │  ┌─────────────────────────────────────┐ │         │
│  │  │  12 Executor Nodes                   │ │         │
│  │  │  Input/Output/Processing/If/        │ │         │
│  │  │  Switch/Loop/Calc/Aggregate/       │ │         │
│  │  │  Transform/Subscenario/Control/    │ │         │
│  │  │  Wait/...                           │ │         │
│  │  └─────────────────────────────────────┘ │         │
│  │  + SkipSet (DFS)                         │         │
│  │  + Topological Sort (Kahn's BFS)         │         │
│  │  + SSE Events (10 types)               │         │
│  │  + Step Mode (CompletableFuture)        │         │
│  └─────────────────────────────────────────┘         │
│                                                       │
│  ┌─────────────────────────────────────────┐         │
│  │           REST API (20+ endpoints)       │         │
│  │           WebSocket (/ws/chat, /ws/     │         │
│  │            scenario)                      │         │
│  └─────────────────────────────────────────┘         │
│                                                       │
│  PostgreSQL 15+ ──────────┬─ pgvector (IVFFlat)     │
│                           │  Liquibase Migrations   │
│                           │  10 JPA Entities + JSONB│
│                           └───────────────────────── │
└───────────────────────────────────────────────────────┘
```

## Ключевые решения

### 1. Почему WebFlux (не WebMVC)?

- **Reactive насквозь**: все endpoint'ы возвращают `Flux<T>` или `Mono<T>`
- **Нет блокировок**: `Schedulers.boundedElastic()` для JPA-вызовов
- **Зачем**: SSE-потоки (чат + сценарии) + WebSocket = 1M+ конкурентных соединений вместо Tomcat-пула на 200 потоков
- **Ограничение**: блокирующие вызовы должны быть явными — `Mono.fromCallable(() -> ...).subscribeOn(boundedElastic())`

### 2. Почему pgvector (не Elasticsearch / Milvus)?

- **Единая БД**: без дополнительной инфраструктуры
- **pgvector**: vector(1024) + IVFFlat + косинусная близость
- **Ограничение**: IVFFlat требует ручного `REINDEX` при изменении данных (не перестраивается автоматически)
- **topK=5**: достаточно для RAG по небольшим и средним БЗ (< 10K документов)

### 3. Почему Liquibase (не `ddl-auto: update`)?

- **Нет авто-миграции на проде**: `validate` гарантирует совпадение dev/test/prod схем
- **Только SQL**: каждый change set — чистый SQL (видимый в ревью)
- **Почему не Hibernate auto**: см. `07-anti-patterns.md` — `update` запрещён на проде

### 4. Почему `CompletableFuture` для step-mode (не State Machine / Camunda)?

- **Лёгковесный**: без внешнего движка — только `CompletableFuture` + `ConcurrentHashMap`
- **PAUSE_TIMEOUT_MINUTES=30**: очистка stale-сессий через `@Scheduled`
- **Почему не**: Camunda добавила бы 200MB+ в `target/`

### 5. `X-UserId` мультитенантность (без auth/roles)

- **User ID**: извлекается из каждого запроса (REST-заголовок + WebSocket handshake)
- **Запасной вариант**: `UserUtils.getUserId()` → `"anonymous"`
- **Данные**: root-сущности (`Conversation`, `Document`, `KnowledgeBase`, `Scenario`) имеют колонку `user_id`
- **Дочерние сущности**: (`Message`, `KBDocument`, `Embedding`, `ScenarioRun`, `ScenarioRunStep`, `ScenarioVersion`) не имеют `user_id` — доступ через связь с parent
- **Нет администратора**: однопользовательская модель (без RBAC, без ролей)

### 6. LLM-роутер (RAG fail-open)

- **Когда**: `ragRouterEnabled=true`, вызывается GigaChat → `"Определи, каких БЗ касается вопрос"` → `"1,3"` или `"all"`
- **Отказ**: ошибка парсинга → все БЗ → `filterRelevantKbs()` (RAG_DISTANCE_DELTA = 0.08)
- **Ограничение**: нет повторной попытки при ошибке роутера

### 7. OCR через GigaChat Files API

- **Когда**: PDF < `minParsedChars=40` символов → `ScanOcrService`
- **Включение**: `ocr-via-gigachat=false` (по умолчанию)
- **Модель**: `ocr-model`, `ocr-max-tokens=8000`

## Data Flow

### Поток чата

```
User → WS /ws/chat (SEND action)
        │
        ├── ChatService.sendMessageStream()
        │     ├── buildChatMessages() — system + doc texts + history + RAG
        │     │     ├── buildDocumentsContext() — full docs (small) / mixed (large+small)
        │     │     │     ├── charLimit < 200000 → полный текст
        │     │     │     └── charLimit > 200000 → поиск по эмбеддингам + RAG
        │     │     └── buildRagContext() — поиск по БЗ → LLM-роутер → фильтр
        │     │           ├── routeKbsByLlm() → парсинг "1,3" или "all"
        │     │           └── filterRelevantKbs() — RAG_DISTANCE_DELTA
        │     ├── GigaChat.chat(prompt) → SSE
        │     └── SSE: `{content, done, usage}`
        └── autoGenerateTitle() — в фоне
```

### Поток выполнения сценария

```
User → WS /ws/scenario (scenario_id + step_mode)
        │
        ├── ScenarioEngine.executeScenario()
        │     ├── topologicalSort() — Kahn's BFS
        │     ├── stripNoteNodes()
        │     ├── executeWaves() — параллельно через ExecutorCompletionService
        │     │     ├── Волна 1: INPUT_NODE + независимые
        │     │     ├── Волна 2: PROCESSING + зависимые
        │     │     └── ...
        │     ├── для каждого узла:
        │     │     ├── ScenarioExecutorFactory.create(type)
        │     │     ├── AbstractScenarioExecutor.execute()
        │     │     │     └── PROCESSING_NODE → GigaChat + RAG
        │     │     │     └── SWITCH_NODE → matchRules()
        │     │     │     └── ... ещё 10
        │     │     ├── SSE: type="node_status"
        │     │     └── SSE: type="step_complete" (если step_mode)
        │     └── SSE: type="status", status="COMPLETED"
        └── ScenarioRun → `status="COMPLETED"`
```

## ER-диаграмма

```
┌───────────────┐   ┌───────────────┐   ┌───────────────┐
│ conversations  │   │   messages    │   │   documents   │
│ (user_id ✅)  │──→│ (user_id ❌)  │──→│ (user_id ✅)  │
│ title         │   │ role          │   │ filename      │
│ knowledge_    │   │ content       │   │ text          │
│ base_ids      │   │ sources       │   └───────────────┘
│ summary       │   │ document_ids  │         │
└───────────────┘   └───────────────┘         │
       │                                       │
       │   ┌───────────────┐                   │
       │   │ knowledge_    │                   │
       └──→│ bases         │                   │
           │ (user_id ✅)  │                   │
           └───────────────┘                   │
                  │                            │
                  │   ┌───────────────┐        │
                  └──→│   embeddings  │        │
                      │ (user_id ❌)  │        │
                      │ vector(1024)  │        │
                      │ type='kb'    │        │
                      └───────────────┘        │
                                               │
          ┌───────────────┐                   │
          │   scenarios   │                   │
          │ (user_id ✅)  │                   │
          │ graph_data    │                   │
          └───────────────┘                   │
                │                             │
          ┌───────────────┐                  │
          │ scenario_runs │                  │
          │ (user_id ❌)  │                  │
          └───────────────┘                  │
                │                             │
          ┌───────────────────┐              │
          │ scenario_run_steps│              │
          │ (user_id ❌)      │              │
          └───────────────────┘              │
                                               │
          ┌───────────────────┐              │
          │ scenario_versions │              │
          │ (user_id ❌)      │              │
          │ @Id manual        │              │
          └───────────────────┘              │
```

## Карта интеграций

```
┌────────────────┐     ┌────────────────┐     ┌────────────────┐
│  GigaChat      │────→│  PostgreSQL    │←────│  GigaChat      │
│  API (HTTP)   │     │  15+ pgvector  │     │  Embeddings   │
└────────────────┘     └────────────────┘     └────────────────┘
       │                      │
       │                      │
       │   ┌──────────────────┐
       └──→│  Application     │
           │  (Spring Boot)  │
           └──────────────────┘
```

## Безопасность

- **`X-UserId`**: все endpoint'ы, WebSocket handshake
- **Запасной вариант**: `"anonymous"` при отсутствии заголовка
- **Проверка**: `UserUtils.checkUserId(requestUserId, entityUserId)` → `AccessDeniedException(403)`
- **Мультитенантность**: root-сущности (`Conversation`, `Document`, `KnowledgeBase`, `Scenario`) имеют `user_id`. Дочерние сущности (`Message`, `KBDocument`, `Embedding`, `ScenarioRun`, `ScenarioRunStep`, `ScenarioVersion`) — нет, доступ контролируется через связь с родительской сущностью.
- **Нет токенов**: без JWT, без OAuth2, без сессий (stateless — сертификаты classpath для GigaChat + БД)

## Производительность

| Область | Цель/Дефолт | Способ | Примечание |
|---------|-------------|--------|------------|
| Конкурентные пользователи | 1000 | WebFlux | |
| Макс. размер файла | 30MB | `application.yaml` | |
| Таймаут чтения | 60s | `GigaChatClient` (`internal.read-timeout`) | В spec было 300s — не соответствует коду |
| Таймаут подключения | 10s | `GigaChatClient` (`internal.connect-timeout`) | В spec было 30s — не соответствует коду |
| Батч эмбеддингов | 50 | `DocumentIndexService` | |
| Потоков парсинга | 4 | `parseParallelism` (`@Value`) | |
| Таймаут step-mode | 30 мин | `CompletableFuture` + `PAUSE_TIMEOUT_MINUTES` | Hardcoded в `ScenarioEngine` |
| Размер чанка | 1000 | `TextSplitter` | |
| Перекрытие | 200 | `TextSplitter` | |
| Parallel threads | **4** | `app.scenario.parallel-threads` | В spec было 2 — не соответствует коду |
| Max sub-scenario depth | **2** | `MAX_SUB_DEPTH` | Hardcoded в `ScenarioEngine`, не 3 как в spec |

## Зависимости

| Библиотека | Версия | Назначение |
|------------|---------|-----------|
| `spring-boot-starter-webflux` | 3.5.15 | REST + SSE |
| `spring-boot-starter-data-jpa` | 3.5.15 | JPA |
| `spring-ai-starter-model-gigachat` | 1.1.4 | GigaChat API |
| `postgresql` | 15+ | JDBC |
| `liquibase-core` | 5.0.3 | Миграции |
| `hypersistence-utils-hibernate-63` | 3.9.3 | JSONB + pgvector |
| `apache-poi` | 5.5.1 | DOCX/XLSX |
| `pdfbox` | 3.0.7 | Парсинг PDF |
| `springdoc-openapi-webflux-ui` | 2.8.17 | Swagger |
| `lombok` | последняя | Boilerplate |
| `checkstyle` | 3.6.0 | Проверка стиля |

## Конфигурация (`application.yaml`)

```yaml
server:
  port: ${PORT:8080}
  servlet.multipart.max-file-size: 30MB
  servlet.multipart.max-request-size: 100MB
  max-http-request-header-size: 20MB

spring:
  webflux:
    base-path: /gigame
  jpa:
    open-in-view: false
    hibernate.ddl-auto: validate
  ai:
    gigachat:
      internal:
        connect-timeout: 10s
        read-timeout: 60s
      embedding:
        options:
          dimensions: 1024
```

## Integration Map

```
┌────────────┐     ┌────────────┐     ┌────────────┐
│  GigaChat  │────→│  PostgreSQL │←────│  GigaChat   │
│  API       │     │  15+       │     │  Embeddings│
│  (HTTP)   │     │  pgvector   │     │  (HTTP)    │
└────────────┘     └────────────┘     └────────────┘
       │                 │
       │                 │
       │   ┌──────────────┐
       └──→│  Application  │
           │  (Spring Boot)│
           └──────────────┘
```

## Security

- **`X-UserId`**: all endpoints, WebSocket handshake
- **Fallback**: `"anonymous"` when header missing
- **Check**: `UserUtils.checkUserId(requestUserId, entityUserId)` — `AccessDeniedException(403)`
- **No tokens**: no JWT, no OAuth2, no sessions (stateless — classpath cert for GigaChat + DB for user)

## Performance

| Area | Target | Method |
|------|--------|--------|
| Concurrent users | 1000 | WebFlux |
| Max file size | 30MB | `application.yaml` |
| Read timeout | 60s | `GigaChatClient` (`internal.read-timeout`) |
| Connect timeout | 10s | `GigaChatClient` (`internal.connect-timeout`) |
| Embedding batch | 50 | `DocumentIndexService` |
| Doc parsing threads | 4 | `parseParallelism` |
| Step mode timeout | 30 min | `CompletableFuture` + `PAUSE_TIMEOUT_MINUTES` (hardcoded) |
| Chunk size | 1000 | `TextSplitter` |
| Overlap | 200 | `TextSplitter` |
| Parallel threads | **4** | `app.scenario.parallel-threads` |
| Max sub-scenario depth | **2** | `MAX_SUB_DEPTH` (hardcoded) |

## Dependencies

| Library | Version | Usage |
|---------|---------|-------|
| `spring-boot-starter-webflux` | 3.5.15 | REST + SSE |
| `spring-boot-starter-data-jpa` | 3.5.15 | JPA |
| `spring-ai-starter-model-gigachat` | 1.1.4 | GigaChat API |
| `postgresql` | 15+ | JDBC |
| `liquibase-core` | 5.0.3 | Migrations |
| `hypersistence-utils-hibernate-63` | 3.9.3 | JSONB + pgvector |
| `apache-poi` | 5.5.1 | DOCX/XLSX |
| `pdfbox` | 3.0.7 | PDF parsing |
| `springdoc-openapi-webflux-ui` | 2.8.17 | Swagger |
| `lombok` | latest | Boilerplate |
| `checkstyle` | 3.6.0 | Style checks |

## Config (`application.yaml`)

```yaml
server:
  port: ${PORT:8080}
  servlet.multipart.max-file-size: 30MB
  servlet.multipart.max-request-size: 100MB
  max-http-request-header-size: 20MB

spring:
  webflux:
    base-path: /gigame
  jpa:
    open-in-view: false
    hibernate.ddl-auto: validate
  ai:
    gigachat:
      internal:
        connect-timeout: 10s
        read-timeout: 60s
      embedding:
        options:
          dimensions: 1024
```

> **Важно**: `server.servlet.context-path` не используется — это WebFlux приложение. Для установки base path используется `spring.webflux.base-path`.
>
> Таймауты GigaChat: `10s` connect, `60s` read (путь `spring.ai.gigachat.internal.*`, не `chat.*`).