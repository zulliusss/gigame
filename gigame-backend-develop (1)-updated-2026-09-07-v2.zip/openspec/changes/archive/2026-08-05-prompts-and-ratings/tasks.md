# Tasks: Prompt API & Ratings System

## 1. Database Migration

- [x] 1.1 Создать `db.changelog-2.sql` — таблица `prompts`, `prompt_ratings`, `scenario_ratings`
- [x] 1.2 Добавить `ALTER TABLE scenarios ADD COLUMN shared`
- [x] 1.3 Добавить индексы: `idx_prompt_ratings_pid`, `idx_scenario_ratings_sid`, `idx_prompts_updated`
- [x] 1.4 Запустить миграцию, проверить создание таблиц

## 2. Entities & Repositories

- [x] 2.1 Создать `Prompt` entity (all fields: id, userId, title, description, text, model, shared, usageCount, timestamps)
- [x] 2.2 Создать `PromptRating` entity с `@IdClass(PromptRating.Key.class)`
- [x] 2.3 Создать `ScenarioRating` entity с `@IdClass(ScenarioRating.Key.class)`
- [x] 2.4 Создать `PromptRepository` с `findByUserIdOrSharedTrueOrderByUpdatedAtDesc`
- [x] 2.5 Создать `PromptRatingRepository` с `findByPromptIdIn`
- [x] 2.6 Создать `ScenarioRatingRepository` с `findByScenarioIdIn`
- [x] 2.7 Добавить поле `shared` в `Scenario` entity (default false)

## 3. DTOs

- [x] 3.1 Создать `PromptCreate` record (title, description, text, model, shared) with snake_case
- [x] 3.2 Создать `PromptUpdate` record (title, description, text, model, shared, null-fields = no-change)
- [x] 3.3 Создать `PromptResponse` record (id, title, description, text, model, shared, isOwner, usageCount, ratingAvg, ratingCount, myRating, updatedAt)

## 4. PromptController

- [x] 4.1 Создать `PromptController` with `@RequestMapping("/api/prompts")`
- [x] 4.2 Implement `GET /api/prompts` — list prompts with user filtering
- [x] 4.3 Implement `POST /api/prompts` — create prompt (201 Created)
- [x] 4.4 Implement `PUT /api/prompts/{id}` — update prompt (owner-only)
- [x] 4.5 Implement `DELETE /api/prompts/{id}` — delete prompt (owner-only)
- [x] 4.6 Implement `POST /api/prompts/{id}/rating` — rate prompt (1..5, replace)
- [x] 4.7 Implement `POST /api/prompts/{id}/use` — use prompt (increment counter, return text)
- [x] 4.8 Add OpenAPI annotations (@Operation, @Tag, @Parameter)
- [x] 4.9 Use `Mono.fromCallable()` + `Schedulers.boundedElastic()` for all endpoints

## 5. PromptService

- [x] 5.1 Create `PromptService` with `PromptRepository` and `PromptRatingRepository` dependencies
- [x] 5.2 Implement `getPrompts(userId)` — filter + join with ratings
- [x] 5.3 Implement `createPrompt(userId, body)` — validation + save
- [x] 5.4 Implement `updatePrompt(userId, id, body)` — owner check + partial update
- [x] 5.5 Implement `deletePrompt(userId, id)` — owner check + delete
- [x] 5.6 Implement `ratePrompt(userId, id, rating)` — visibility check + upsert
- [x] 5.7 Implement `usePrompt(userId, id)` — visibility check + increment + return text
- [x] 5.8 Implement `ratingSummaries()` — batch aggregation in memory
- [x] 5.9 Implement `myRatings()` — filter ratings for current user
- [x] 5.10 Implement `toResponse()` — map entity + stats to DTO
- [x] 5.11 Implement `checkVisible()` — shared or owner check
- [x] 5.12 Implement `normalizeModel()` — blank/null → null

## 6. Rating for Scenarios

- [x] 6.1 Implement `rateScenario(userId, id, rating)` in `ScenarioService`
- [x] 6.2 Add visibility check: shared or owner can rate
- [x] 6.3 Add `POST /api/scenarios/{id}/rating` in `ScenarioController`
- [x] 6.4 Use `ScenarioRatingRepository` for storage

## 7. Error Handling & Validation

- [x] 7.1 Validate `rating` is 1..5, throw `IllegalArgumentException` if out of range
- [x] 7.2 Validate `title` and `text` are not blank on create
- [x] 7.3 Return 404 for not found prompts/scenarios
- [x] 7.4 Return 403/400 for access denied (non-owner action on private entity)

## 8. Tests

- [x] 8.1 Create `PromptControllerTest` — CRUD endpoints
- [x] 8.2 Create `PromptServiceTest` — getPrompts with rating aggregation
- [x] 8.3 Create `PromptServiceTest` — ratePrompt, usePrompt, owner checks
- [x] 8.4 Create `ScenarioServiceRateTest` — rateScenario with shared visibility
- [x] 8.5 Test shared visibility: shared prompt visible to all, private only to owner
- [x] 8.6 Test replace-rating: second call overwrites first
- [x] 8.7 Test rating stats: ratingAvg, ratingCount, myRating calculations
- [x] 8.8 Test validation: rating out of range, blank title/text

## 9. Integration & Verification

- [x] 9.1 Run `mvn test` — verify all tests pass (53 passed, 0 failures)
- [x] 9.2 Run `mvn verify` — checkstyle pass
- [x] 9.3 Verify Liquibase migration runs successfully
- [x] 9.4 Manual test: create prompt → rate → verify stats → delete
