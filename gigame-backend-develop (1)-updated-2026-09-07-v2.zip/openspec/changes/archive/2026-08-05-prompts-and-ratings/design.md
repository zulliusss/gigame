# Design: Prompt API & Ratings System

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                    /api/prompts                           │
│  POST    /                    → createPrompt()           │
│  GET     /                    → listPrompts()            │
│  PUT     /{id}                → updatePrompt()           │
│  DELETE  /{id}                → deletePrompt()           │
│  POST    /{id}/rating         → ratePrompt()             │
│  POST    /{id}/use            → usePrompt()              │
├──────────────────────────────────────────────────────────┤
│                    /api/scenarios/{id}/rating            │
│  POST    /{id}/rating         → rateScenario()           │
└──────────────────────────────────────────────────────────┘

PromptController ──▶ PromptService ──▶ PromptRepository
                              ──▶ PromptRatingRepository
```

## Entities

### Prompt

```
┌────────────────────────────────────┐
│ Prompt                              │
├────────────────────────────────────┤
│ id: UUID (PK)                       │
│ userId: VARCHAR(64)                 │
│ title: VARCHAR(255) NOT NULL        │
│ description: TEXT                   │
│ text: TEXT NOT NULL                 │
│ model: VARCHAR(64)                  │
│ shared: BOOLEAN NOT NULL DEFAULT T  │
│ usageCount: INTEGER NOT NULL D 0    │
│ createdAt: TIMESTAMPTZ              │
│ updatedAt: TIMESTAMPTZ              │
└────────────────────────────────────┘

PromptRating (1..N)
┌────────────────────────────────────┐
│ PromptRating                        │
├────────────────────────────────────┤
│ promptId: UUID (PK FK)              │
│ userId: VARCHAR(64) (PK)            │
│ rating: INTEGER NOT NULL (1..5)     │
│ updatedAt: TIMESTAMPTZ              │
│ PK: (promptId, userId)              │
└────────────────────────────────────┘
```

### ScenarioRating

```
┌────────────────────────────────────┐
│ ScenarioRating                      │
├────────────────────────────────────┤
│ scenarioId: UUID (PK FK)            │
│ userId: VARCHAR(64) (PK)            │
│ rating: INTEGER NOT NULL (1..5)     │
│ updatedAt: TIMESTAMPTZ              │
│ PK: (scenarioId, userId)            │
└────────────────────────────────────┘
```

## Data Flow

### Список промптов с рейтингами

```
GET /api/prompts
  │
  ├─▶ findByUserIdOrSharedTrueOrderByUpdatedAtDesc(userId)
  │     → List<Prompt>
  │
  ├─▶ extract ids → findByPromptIdIn(ids)
  │     → List<PromptRating>
  │
  ├─▶ in-memory aggregation:
  │     ratingSummaries()    → Map<promptId, [sum, count]>
  │     myRatings()          → Map<promptId, rating>
  │
  └─▶ toResponse() → List<PromptResponse>
```

### Оценка промпта

```
POST /api/prompts/{id}/rating  { "rating": 4 }
  │
  ├─▶ findPrompt(id)
  ├─▶ checkVisible(userId, prompt)  // shared or owner
  ├─▶ validate rating 1..5
  └─▶ save(PromptRating{promptId, userId, rating})
        // replace: PK (promptId, userId) → upsert by delete-then-insert
```

### Использование промпта

```
POST /api/prompts/{id}/use
  │
  ├─▶ findPrompt(id)
  ├─▶ checkVisible(userId, prompt)
  ├─▶ prompt.usageCount++
  └─▶ return prompt.text
```

## Shared Visibility

Все 3 сущности с `shared` флагом используют одинаковую логику:

```
list(userId):
  WHERE (userId = :userId OR shared = true)
  ORDER BY updatedAt DESC

action(userId, id):
  entity = find(id)
  if (!entity.shared && entity.userId != userId) → AccessDenied
  perform action
```

## Database Migration

- Таблица `prompts` — CREATE TABLE IF NOT EXISTS
- Таблица `prompt_ratings` — PK (prompt_id, user_id), FK → prompts
- Таблица `scenario_ratings` — PK (scenario_id, user_id), FK → scenarios
- ALTER TABLE scenarios ADD COLUMN IF NOT EXISTS shared
- Индексы на `prompt_id`, `scenario_id`, `prompts.updated_at`
