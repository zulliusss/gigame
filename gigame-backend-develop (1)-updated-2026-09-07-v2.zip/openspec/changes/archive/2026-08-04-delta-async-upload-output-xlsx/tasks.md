# Tasks: Async Upload, Output Node Enrichment, XLSX Enhancement

## 1. Async Upload

- [x] 1.1 Implement `ScenarioUploadTaskService` with `UploadTask` inner class,
  `start()`, `isProcessing()`, `status()`, `runTask()`, `shutdown()`
- [x] 1.2 Implement `ScenarioController.submitUploadTask()` — async branch in
  `uploadFiles()`, new `uploadStatus()` endpoint, new `submitUploadTask()` method
- [x] 1.3 Wire `ScenarioUploadTaskService` into `ScenarioController` constructor
- [x] 1.4 Add `ScenarioUploadTaskService` dependency to `ScenarioWebSocketHandler`
  and block run during `isProcessing()`
- [x] 1.5 Wire `ScenarioUploadTaskService` into `ScenarioWebSocketHandler` constructor
- [x] 1.6 Add `upload-status` to OpenAPI spec (ScenarioController)
- [x] 1.7 Update `ScenarioControllerTest` — test async upload and status endpoint
- [x] 1.8 Update `ScenarioWebSocketHandlerTest` — mock `ScenarioUploadTaskService`,
  test guard during processing

## 2. Output Node Enrichment

- [x] 2.1 Implement `ScenarioOutputSupportService` with
  `accumulateIfConfigured()`, `saveToKnowledgeBaseIfConfigured()`,
  `previousRows()`, `parseRows()`, `parseRules()`
- [x] 2.2 Wire `ScenarioOutputSupportService` into `ScenarioEngine` constructor
- [x] 2.3 Add `setRunContext()` call in `ScenarioEngine.doExecute()` when
  executor is `ScenarioExecutorOutputNode`
- [x] 2.4 Add `setRunContext()` and enrichment calls in
  `ScenarioExecutorOutputNode.execute()`
- [x] 2.5 Create `ScenarioOutputSupportServiceTest` — test accumulate, KB save,
  previous rows, parse fallback
- [x] 2.6 Create `InMemoryFilePart` — `FilePart` impl for internal KB uploads
- [x] 2.7 Wire `InMemoryFilePart` into `ScenarioOutputSupportService.saveToKnowledgeBaseIfConfigured()`

## 3. XLSX Export Enhancement

- [x] 3.1 Enhance `XlsxTemplate` — add `highlightSections`, `XlsxColumn.highlight`,
  `parseHighlight()`, `parsePrefixColumn()`, `isDynamic()`
- [x] 3.2 Implement `XlsxTemplate.expandColumns()` for dynamic column expansion
- [x] 3.3 Implement `isSectionRow()` — section detection
- [x] 3.4 Implement `highlightStyle()` — cached colored CellStyle
- [x] 3.5 Update `createTemplatedXlsx()` — expand columns, apply section + highlight styles
- [x] 3.6 Change `extractJson()` visibility to package-private (`static`)
- [x] 3.7 Handle empty data with template — header-only workbook
- [x] 3.8 Update `ScenarioResultToXlsxTemplateTest` — add tests for:
  - [x] dynamic columns
  - [x] section highlighting (`sectionRows_highlightedWithHeaderStyle`)
  - [x] cell color highlighting (`highlightMap_paintsCellsByValue`)
  - [x] empty array with template (`emptyArrayWithTemplate_producesHeaderOnlyWorkbook`)
- [x] 3.9 Wire `ScenarioResultToXlsx.extractJson()` into `ScenarioOutputSupportService.parseRows()`

## 4. Code Quality / Cleanup

- [x] 4.1 Refactor `OpenApiConfig` — extract helper methods, remove lambda parameters
- [x] 4.2 Refactor `ExpressionResolverTest` — parameterized test with `Arguments` stream
- [x] 4.3 Remove unused `evalRaw()` helpers from `FormulaEvaluatorTest`
- [x] 4.4 Add `@SuppressWarnings("java:S5778")` to test methods in `ScenarioServiceTest`
- [x] 4.5 Add `@SuppressWarnings("java:S2973")` SONAR suppressions where needed
- [x] 4.6 Fix CRLF line endings in test files (Git auto-conversion)

## 5. Integration & Verification

- [x] 5.1 Run full test suite — `mvn test` (1274 passed, 0 failures, 0 errors)
- [x] 5.2 Verify JaCoCo coverage ≥ 70% (Complexity: 71.8%, Instruction: 88.6%, Line: 88.0%)
- [x] 5.3 Run `mvn verify` — Checkstyle pass (BUILD SUCCESS)
- [x] 5.4 Manual test: async upload + polling + scenario run
- [x] 5.5 Manual test: accumulate across two scenario runs
- [x] 5.6 Manual test: XLSX export with dynamic columns and highlighting
