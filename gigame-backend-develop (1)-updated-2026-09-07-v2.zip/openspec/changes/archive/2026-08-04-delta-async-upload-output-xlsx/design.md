# Design: Асинхронная загрузка, Обогащение Output-узла, Улучшение экспорта XLSX

## Архитектура

```
┌─────────────────────────────────────────────────────────────────┐
│                     Слой HTTP-запросов                           │
│                                                                 │
│  POST /api/scenarios/{id}/upload?async=true                     │
│       │                                                         │
│       ▼                                                         │
│  ScenarioController.submitUploadTask()                          │
│       │                                                         │
│       ├── читает байты файлов → List<RawFile>                   │
│       └── делегирует ScenarioUploadTaskService.start()          │
│                                                                 │
│  GET  /api/scenarios/{id}/upload-status                         │
│       │                                                         │
│       ▼                                                         │
│  ScenarioUploadTaskService.status()                             │
│       │                                                         │
│       └── возвращает {status, files, documents, warnings, error}│
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                     Слой фонового выполнения                     │
│                                                                 │
│  ScenarioUploadTaskService (ExecutorService pool=2)             │
│       │                                                         │
│       ├── runTask(): parseFiles() → docsTextCache               │
│       ├── status(): снимок состояния ConcurrentHashMap          │
│       └── isProcessing(): проверка защиты WebSocket             │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                     Слой движка сценариев                        │
│                                                                 │
│  ScenarioExecutorOutputNode                                     │
│       │                                                         │
│       ├── setRunContext(support, run)                           │
│       ├── execute():                                            │
│       │   1. accumulateIfConfigured() ← предыдущие прогоны       │
│       │   2. emitFileOutputEvent() ← SSE                        │
│       │   3. saveToKnowledgeBaseIfConfigured() ← KBService      │
│       └── ScenarioOutputSupportService                          │
│           ├── накопление: прохождение истории ScenarioRun       │
│           └── saveToKB: InMemoryFilePart + kbService            │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│                     Слой экспорта                                │
│                                                                 │
│  ScenarioResultToXlsx.jsonToXlsx(data, rules)                   │
│       │                                                         │
│       ├── XlsxTemplate.parse(rules)                             │
│       │   ├── колонки: статические + динамические (key_prefix)  │
│       │   ├── highlightSections: boolean                        │
│       │   └── highlight: отображение значение→цвет на колонку   │
│       ├── XlsxTemplate.expandColumns(data)                      │
│       ├── createTemplatedXlsx():                                │
│       │   ├── заголовочные строки (с группировкой + заголовки)  │
│       │   └── строки данных: стиль секции + цвета ячеек         │
│       └── highlightStyle(): кэшированная CellStyle на цвет      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Детали компонентов

### ScenarioUploadTaskService

**Состояние**: `ConcurrentHashMap<UUID, UploadTask>` (в памяти, без
персистентности). Каждый `UploadTask` отслеживает `status`, `filesTotal`,
`documentsCached`, `error` и список SSE-событий (для извлечения предупреждений).

**Жизненный цикл**: Создаётся при первой загрузке с `async=true` для сценария.
Автоматически освобождается (когда `isProcessing()` возвращает false), когда
статус `done` или `failed`. Пул останавливается на `@PreDestroy`.

**Параллелизм**: Одна задача на сценарий, enforced проверкой статуса.
Несколько сценариев могут обрабатываться параллельно (размер пула 2).

### ScenarioOutputSupportService

**Поток накопления**:
```
предыдущие прогоны (DESC по startedAt)
    → пропустить текущий прогон
    → найти первый шаг с совпадающим node ID и результатом
    → parseRows(result) → JSON-массив объектов
    → merge(previous, current)
```

**Поток сохранения в БЗ**:
```
разобрать rules → извлечь UUID "в_базу_знаний"
    → получить userId из сценария
    → создать InMemoryFilePart (имя, содержимое)
    → kbService.addDocumentToKB(userId, kbId, filePart)
```

### ScenarioExecutorOutputNode

Добавлен `setRunContext(ScenarioOutputSupportService, ScenarioRun)`, вызываемый
`ScenarioEngine` при создании executor factory. Узел проверяет
`outputSupport != null && run != null` перед вызовом методов обогащения.

### Улучшения XlsxTemplate

- **Динамические колонки**: `parsePrefixColumn()` создаёт колонки с пустым
  `key` и непустым `keyPrefix`. `expandColumns()` проходит по ключам данных,
  сопоставляет префикс, создаёт конкретные колонки.
- **Обнаружение секций**: `isSectionRow()` проверяет, что значение есть только
  в первой колонке.
- **Подсветка ячеек**: `highlightColor()` сопоставляет значение ячейки с именем
  цвета; `highlightStyle()` кэширует `CellStyle` по цвету в `LinkedHashMap`.

## Записи решений

1. **Отслеживание задач в памяти вместо DB-backed jobs** — Просто, подходит для
   use case. При необходимости персистентности позже `UploadTask` может быть
   сохранён в БД.
2. **Синхронное сохранение в БЗ в пределах выполнения узла** — Упрощает обработку
   ошибок (warn + continue). Fire-and-forget усложнит отчётность о статусе.
3. **Только IndexedColors (без пользовательской палитры)** — Проще, избегать
   лимитов стилей Excel, покрывает три требуемых цвета.
4. **Package-private `extractJson()`** — Избегает раздувания API; вызывающие
   (`ScenarioOutputSupportService`) находятся в том же пакете.
