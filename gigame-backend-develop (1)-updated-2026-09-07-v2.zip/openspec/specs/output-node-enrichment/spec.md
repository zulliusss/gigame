# Output Node Enrichment

## Purpose

Extends the OUTPUT_NODE type with additional behavior controlled via JSON `rules`: accumulating results between scenario runs ("accumulate") and saving results as documents in the knowledge base ("to_kb").

## Requirements

### Requirement: Accumulation Between Runs (accumulate)

When an output node's `rules` contain `{"accumulate": true}`, its result SHALL include rows from the previous successful run of the same scenario, prepended BEFORE the current run's rows.

#### Scenario: Accumulation with previous run

- **WHEN** output node has `"accumulate": true` in its rules
- **AND** the same scenario was previously run and this node completed successfully with results
- **THEN** the combined result contains first rows from the past run, then rows from the current run
- **THEN** concatenation is performed at the JSON-string level: both results parsed as JSON object arrays, concatenated (`previous + current`)

#### Scenario: No previous run

- **WHEN** output node has `"accumulate": true`
- **AND** there is no previous successful run of this scenario
- **THEN** current result is returned unchanged

#### Scenario: Parse error

- **WHEN** accumulation failed (JSON parse error, row format mismatch)
- **THEN** current result is returned unchanged (scenario run does not fail)
- **THEN** a warning is logged: "Accumulative output node {id} not assembled"

#### Scenario: Previous run without results

- **WHEN** previous run exists but this node had an empty result
- **THEN** current result is returned unchanged

### Requirement: Knowledge Base Save (to_kb)

When an output node's `rules` contain `{"to_kb": "<kb-uuid>"}`, its result SHALL be saved as a text document in the specified knowledge base.

#### Scenario: Save result to KB

- **WHEN** output node has `"to_kb": "<uuid>"` in its rules
- **THEN** a text document is created in the KB after the node completes
- **THEN** filename: `registry-{runIdPrefix}.txt` (first 8 characters of run ID)
- **THEN** content:
  ```
  Run registry {runId} of scenario {scenarioId}

  {result JSON}
  ```

#### Scenario: KB save error is non-fatal

- **WHEN** KB save fails (invalid UUID, KB not found, permission error)
- **THEN** scenario run continues (node completes successfully)
- **THEN** a warning is logged: "Failed to save node {id} result to knowledge base"

#### Scenario: Missing KB ID

- **WHEN** `"to_kb"` is empty or absent
- **THEN** document is not saved (no-op)

### Requirement: Execution Order

Accumulation MUST occur before SSE file emission. KB save MUST occur after SSE file emission. Both actions MUST be performed inside the node's `execute()` method.

#### Scenario: Order: accumulate → emit → save

- **WHEN** output node has both `"accumulate": true` and `"to_kb"`
- **THEN** accumulation is applied first (result = previous + current)
- **THEN** accumulated result is emitted via SSE as file output
- **THEN** KB save uses the same accumulated result

### Requirement: Engine Integration

`ScenarioEngine` MUST inject `ScenarioOutputSupportService` context into `ScenarioExecutorOutputNode` before execution.

#### Scenario: Engine passes output node support context

- **WHEN** `ScenarioEngine` creates `ScenarioExecutorOutputNode`
- **THEN** `outputNode.setRunContext(outputSupportService, run)` is called
- **THEN** the node has access to accumulation and KB save functions
