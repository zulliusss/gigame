# Ratings System

## Purpose

Allow users to rate prompts and AI scenarios on a 1–5 scale, with aggregate statistics returned in list responses.

## Requirements

### Requirement: Prompt Ratings (1..5)

The system SHALL allow each user to rate prompts from 1 to 5. One rating per (prompt, user) pair.

#### Scenario: Set prompt rating

- **WHEN** `POST /api/prompts/{id}/rating` is called with body `{"rating": 4}`
- **THEN** the rating is saved for the `(userId, promptId)` pair
- **THEN** `rating` must be in range 1..5
- **THEN** missing `rating` or out-of-range value returns validation error

#### Scenario: Replace rating

- **WHEN** a user calls `POST /api/prompts/{id}/rating` again with a new rating
- **THEN** the previous rating is replaced (replace-model)
- **THEN** a new record is created in `prompt_ratings`

#### Scenario: Rate shared prompt

- **WHEN** a prompt has `shared = true`
- **THEN** any user can rate it

#### Scenario: Rate private prompt

- **WHEN** a prompt has `shared = false`
- **THEN** only the owner can rate their own prompt
- **THEN** another user receives an error

#### Scenario: Rating summary in response

- **WHEN** `GET /api/prompts` is called
- **THEN** each prompt returns `ratingAvg` (average, rounded to 0.1)
- **THEN** each prompt returns `ratingCount` (total number of ratings)
- **THEN** each prompt returns `myRating` (current user's rating, `null` if not rated)

### Requirement: Scenario Ratings (1..5)

The system SHALL allow users to rate AI scenarios from 1 to 5.

#### Scenario: Set scenario rating

- **WHEN** `POST /api/scenarios/{id}/rating` is called with body `{"rating": 3}`
- **THEN** the rating is saved for the `(userId, scenarioId)` pair
- **THEN** `rating` must be in range 1..5
- **THEN** missing `rating` or out-of-range value returns validation error

#### Scenario: Replace scenario rating

- **WHEN** a user re-rates the same scenario
- **THEN** the previous rating is replaced

#### Scenario: Scenario rating visibility

- **WHEN** a scenario has `shared = true`
- **THEN** any user can rate it
- **WHEN** a scenario has `shared = false`
- **THEN** only the owner can rate their own scenario

### Requirement: Rating Storage

Ratings SHALL be stored in separate tables with a composite primary key.

#### Scenario: prompt_ratings table

- **WHEN** a prompt rating is saved
- **THEN** a record is created in `prompt_ratings`
- **THEN** composite key: `(prompt_id, user_id)`
- **THEN** `rating` is INTEGER, not null
- **THEN** `updated_at` is timestamp with time zone, auto-updated

#### Scenario: scenario_ratings table

- **WHEN** a scenario rating is saved
- **THEN** a record is created in `scenario_ratings`
- **THEN** composite key: `(scenario_id, user_id)`
- **THEN** `rating` is INTEGER, not null
- **THEN** `updated_at` is timestamp with time zone, auto-updated

### Requirement: Average Rating Calculation

Average rating SHALL be computed at the service layer when returning lists.

#### Scenario: Average rating with no ratings

- **WHEN** a prompt or scenario has no ratings
- **THEN** `ratingAvg` is `null`
- **THEN** `ratingCount` is `0`

#### Scenario: Average rating with ratings

- **WHEN** a prompt or scenario has ratings
- **THEN** `ratingAvg` = `ROUND(SUM(rating) / COUNT(rating), 1)` (rounded to 0.1)
- **THEN** `ratingCount` = `COUNT(*)` of all ratings

#### Scenario: Batch calculation for list

- **WHEN** `GET /api/prompts` is called (returns N prompts)
- **THEN** all ratings are loaded in one query by ID list (`findByPromptIdIn`)
- **THEN** aggregation is performed in memory (O(N) DB queries)
- **THEN** for each prompt, `ratingAvg`, `ratingCount`, `myRating` are calculated
