# Prompt API

## Purpose

Allow users to create, manage, share, and rate prompt templates with usage statistics.

## Requirements

### Requirement: Prompt Library

The system SHALL provide a CRUD interface for storing and searching tested prompt templates.

#### Scenario: List prompts

- **WHEN** `GET /api/prompts` is called with `X-UserId` header
- **THEN** the user's own prompts and all shared prompts are returned
- **THEN** results are sorted by last updated date descending
- **THEN** each prompt includes statistics: `ratingAvg`, `ratingCount`, `myRating`, `usageCount`

#### Scenario: Create prompt

- **WHEN** `POST /api/prompts` is called with body `title`, `text`
- **THEN** a prompt record is created
- **THEN** required fields — `title` (1..255 chars) and `text` (1..65536 chars)
- **THEN** missing `title` or `text` returns validation error
- **THEN** `shared` defaults to `true`
- **THEN** the created prompt is returned with `isOwner: true`

#### Scenario: Update prompt

- **WHEN** `PUT /api/prompts/{id}` is called with body `PromptUpdate`
- **THEN** only non-null fields are updated (`title`, `description`, `text`, `model`, `shared`)
- **THEN** only the prompt owner can update it
- **THEN** non-owner receives an access denied error

#### Scenario: Delete prompt

- **WHEN** `DELETE /api/prompts/{id}` is called
- **THEN** the prompt record is deleted
- **THEN** only the owner can delete
- **THEN** returns `204 No Content`

#### Scenario: Shared prompt visible to all

- **WHEN** a prompt has `shared = true`
- **THEN** it is returned in `GET /api/prompts` for any user

#### Scenario: Private prompt visible only to owner

- **WHEN** a prompt has `shared = false`
- **THEN** it is returned only to the owner (matching `userId`)

### Requirement: Prompt Model

A prompt SHALL store the GigaChat model it was tested on.

#### Scenario: Model at creation

- **WHEN** a prompt is created with `model` field
- **THEN** the model is saved (up to 64 chars)
- **THEN** empty value means "any model"

#### Scenario: Model in response

- **WHEN** a prompt is returned via `PromptResponse`
- **THEN** `model` is sent as `null` or string
- **THEN** empty strings and whitespace are normalized to `null`

### Requirement: Usage Counter

The system SHALL count how many times a prompt was used through the UI.

#### Scenario: Increment usage

- **WHEN** `POST /api/prompts/{id}/use` is called
- **THEN** `usageCount` is incremented by 1
- **THEN** the prompt text is returned (`"text": "..."`)
- **THEN** a shared prompt is available to any user
- **THEN** a private prompt is available only to the owner

### Requirement: Visibility State on Update

When updating a prompt via `PUT /api/prompts/{id}`, the user can change the `shared` field.

#### Scenario: Toggle shared

- **WHEN** the owner updates `shared` to `false`
- **THEN** the prompt becomes unavailable to other users
- **WHEN** the owner updates `shared` to `true`
- **THEN** the prompt becomes visible to all users
