# Async Upload

## Purpose

Allows uploading large sets of documents into a scenario without holding the HTTP connection open. Documents are parsed in the background; the client polls a status endpoint to receive completion information.

## Requirements

### Requirement: Async Upload Endpoint

When calling the upload endpoint with `async=true`, the server SHALL accept file bytes, enqueue a parsing task for background execution, and return an immediate response (202 No Content). The task SHALL NOT block the HTTP request.

#### Scenario: Upload with async=true

- **WHEN** `POST /api/scenarios/{id}/upload?async=true&append=false` is called with one or more files
- **THEN** response 200/204 is returned immediately (file bytes consumed, parsing not yet started)
- **THEN** document parsing task has been enqueued
- **THEN** scenario execution is blocked until parsing completes (protected via `ScenarioUploadTaskService.isProcessing`)

#### Scenario: Concurrent uploads are rejected

- **WHEN** a second upload with `async=true` is started for the same scenario while the first is still `processing`
- **THEN** the second request is rejected with `FileException` ("Previous document upload is still being processed")

### Requirement: Upload Status Endpoint

A new endpoint SHALL provide polling information about the background parsing task.

#### Scenario: Status returns processing

- **WHEN** `GET /api/scenarios/{id}/upload-status` is called during parsing
- **THEN** response contains `"status": "processing"`, `"files"` (total count), `"documents"` (current cache count), empty `warnings` and `error`

#### Scenario: Status returns done

- **WHEN** `GET /api/scenarios/{id}/upload-status` is called after successful parsing completion
- **THEN** response contains `"status": "done"`, `"documents"` (total count)

#### Scenario: Status returns failed

- **WHEN** `GET /api/scenarios/{id}/upload-status` is called after parsing failure
- **THEN** response contains `"status": "failed"`, `"error"` (error message)

#### Scenario: No active task

- **WHEN** `GET /api/scenarios/{id}/upload-status` is called for a scenario without an upload task
- **THEN** response contains `"status": "none"`, `"files": 0`, `"documents": 0`

### Requirement: WebSocket Protection

The scenario WebSocket handler SHALL block execution requests while a background upload is active.

#### Scenario: WebSocket start blocked during upload

- **WHEN** a WebSocket message with type `"start"` is sent while `ScenarioUploadTaskService.isProcessing()` returns `true`
- **THEN** server sends an error message ("Scenario documents are still being processed (async upload) — wait for completion via GET upload-status and rerun")
- **THEN** scenario execution is not initiated

### Requirement: Background Parsing

The background task SHALL parse files the same way as synchronous upload: text extraction (POI, PDFBox), archive handling (ZIP/7z), document limit checks, scenario cache append/clear.

#### Scenario: Document limit checked after parsing

- **WHEN** background parsing completes
- **THEN** total document count (already in cache + new) is checked against `maxDocumentsPerRun` (from scenario config)
- **THEN** if the limit is exceeded, the task ends with `FileException` ("Too many documents considering already loaded")

### Requirement: Resource Cleanup

The background executor pool SHALL be stopped when the application shuts down.

#### Scenario: Pool shutdown on destruction

- **WHEN** the application context closes
- **THEN** `ScenarioUploadTaskService.shutdown()` is called (via `@PreDestroy`)
- **THEN** the executor pool stops (`shutdownNow()`)
