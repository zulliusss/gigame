---
capability: embeddings
---

# Embeddings Specification

## Purpose

Define text chunking with overlap, embedding storage in pgvector `vector(1024)`, and cosine similarity search with IVFFlat index.

## Requirements

### Requirement: Чанкование текста с перекрытием
Система SHALL делить текст на чанки размером `chunkSize=1000` с перекрытием `overlap=200`, используя рекурсивное разделение по разделителям.

#### Scenario: Стандартное чанкование
- **WHEN** документ длиной 3500 символов подвергается чанкованию
- **THEN** создаётся 3 чанка: chunk[0]=1000, chunk[1]=1000+200 (перекрытие), chunk[2]=1500+200 (перекрытие)
- **THEN** приоритет разделителей: `\n\n` → `\n` → `. ` → ` `` ` → посимвольно

### Requirement: Хранение эмбеддингов в pgvector
Система SHALL хранить 1024-мерные векторы из GigaChat Embeddings API в колонке pgvector `vector(1024)`.

#### Scenario: Сохранение чанков документа
- **WHEN** вызывается `embeddingService.storeDocumentChunks(docId, chunks, embeddings)`
- **THEN** создаются записи `Embedding` с `collection_type="doc"`, `collection_id=docId`, `source_document_id=docId`, `chunk_index=0..N`, `chunk_text`, `vector=float[1024]`

#### Scenario: Сохранение чанков базы знаний
- **WHEN** вызывается `embeddingService.storeKBChunks(kbId, docId, chunks, embeddings)`
- **THEN** создаются записи `Embedding` с `collection_type="kb"`, `collection_id=kbId`, `source_document_id=docId`

### Requirement: Поиск по косинусной близости
Система SHALL искать эмбеддинги через косинусное расстояние (оператор `<->`) с индексом IVFFlat (100 списков, `vector_cosine_ops`).

#### Scenario: Top-K поиск
- **WHEN** вызывается `embeddingService.searchSimilar("kb", kbId, queryEmbedding)`
- **THEN** SQL-запрос: `SELECT chunk_text FROM embeddings WHERE collection_type='kb' AND collection_id=? ORDER BY embedding <-> ? LIMIT 5`
- **THEN** возвращаются 5 ближайших чанков, упорядоченных по расстоянию

### Requirement: Гибридный поиск (вектор + лексический, RRF)
Система SHALL объединять векторный и лексический каналы поиска через Reciprocal Rank Fusion (RRF, k=60).

#### Scenario: Гибридный поиск по документу
- **WHEN** `EmbeddingService.hybridSearch(collectionType, collectionId, queryEmbedding, queryText)` вызывается
- **THEN** векторный канал возвращает чанки по косинусному расстоянию
- **THEN** лексический канал извлекает термины из `queryText`:
  - числа от 4 цифр (`\d{4,}`)
  - слова от 5 букв (`[а-яёa-zA-Z]{5,}`)
  - до 3 самых длинных, отсортированных по убыванию длины
- **THEN** для каждого термина выполняется `searchLexical(collectionType, collectionId, term)`
- **THEN** чанки обоих каналов сливаются по RRF:
  ```
  score[text] = Σ (1 / (60 + rank))
  ```
- **THEN** чисто лексическим хитам присваивается дистанция `0.15` (условно-хорошая)
- **THEN** возвращается топ-K по убыванию `score`

#### Scenario: Пустой запрос
- **WHEN** `queryText` равен `null`
- **THEN** `lexicalTerms()` возвращает пустой список
- **THEN** используется только векторный канал

#### Scenario: Запрос без подходящих термов
- **WHEN** в запросе нет слов ≥5 букв и чисел ≥4 цифр
- **THEN** лексический канал возвращает пустой список
- **THEN** возвращается только векторный результат

### Requirement: Лексический поиск в репозитории
Система SHALL поддерживать SQL-запросы LIKE для лексического канала гибридного поиска.

#### Scenario: Поле для lexical-поиска
- **WHEN** `EmbeddingRepository.searchLexical(collectionType, collectionId, term, topK)` вызывается
- **THEN** выполняется SQL-запрос `LIKE %term%` по `chunk_text`
- **THEN** возвращается массив объектов: `(chunk_text, source_document_id)`
