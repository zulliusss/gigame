---
capability: agent-memory
---

# Agent Memory Specification

## Purpose

Определить систему памяти агента: уроки (правила), планы (чек-листы) и вопросы (human-in-the-loop) для саморазвивающегося AI-агента.

---

## Requirements

### Requirement: CRUD уроков агента
Система SHALL поддерживать создание, чтение, обновление и удаление уроков — правил, выученных из прошлых прогонов.

#### Scenario: Добавить урок сценария
- **WHEN** пользователь отправляет `POST /api/agent/lessons` с `{"scenario_id": "uuid", "lesson": "Сумма акта — это Итого с НДС"}`
- **THEN** создаётся `AgentLesson` с `scenario_id`, `source='user'`, `approved=true`
- **THEN** возвращается `AgentLessonResponseDto` с HTTP 200
- **THEN** урок сразу применяется к промпту агентского узла

#### Scenario: Добавить общий урок
- **WHEN** пользователь отправляет `POST /api/agent/lessons` с `{"lesson": "Правило для всех"}` (без `scenario_id`)
- **THEN** создаётся `AgentLesson` с `scenario_id=NULL`
- **THEN** урок сохраняет `approved=true` (личный общий активен сразу)
- **THEN** применяется к промпту только запускающего пользователя

#### Scenario: Получить уроки сценария
- **WHEN** пользователь отправляет `GET /api/agent/lessons?scenario_id=uuid`
- **THEN** возвращаются уроки для этого сценария, отсортированные по `created_at DESC`
- **THEN** ответ — массив `AgentLessonResponseDto[]`

#### Scenario: Получить общие уроки
- **WHEN** пользователь отправляет `GET /api/agent/lessons` (без параметра `scenario_id`)
- **THEN** возвращаются все `AgentLesson` с `scenario_id=NULL`
- **THEN** порядок: `created_at DESC`

#### Scenario: Изменить урок
- **WHEN** пользователь отправляет `PUT /api/agent/lessons/{id}` с `{"lesson": "Новый текст"}`
- **THEN** урок обновляется
- **THEN** системный урок (`source='system'`) не может быть изменён → HTTP 400
- **THEN** сценарный урок меняет только автор сценария → иначе HTTP 403

#### Scenario: Удалить урок
- **WHEN** пользователь отправляет `DELETE /api/agent/lessons/{id}`
- **THEN** урок удаляется
- **THEN** системный урок не может быть удалён → HTTP 400

### Requirement: Одобрение урока
Система SHALL позволять одобрять неодобренные уроки (auto-кандидаты), после чего они применяются к промпту.

#### Scenario: Одобрить урок
- **WHEN** пользователь отправляет `POST /api/agent/lessons/{id}/approve`
- **THEN** `AgentLesson.approved` устанавливается в `true`
- **THEN** сценарный урок может одобрить только автор сценария → иначе HTTP 403

### Requirement: Рефлексия-сжатие уроков
Система SHALL дистиллировать уроки сценария в меньший набор правил через LLM.

#### Scenario: Сжатие уроков
- **WHEN** пользователь отправляет `POST /api/agent/lessons/compress` с `{"scenario_id": "uuid"}`
- **THEN** если уроков < 3 → HTTP 400
- **THEN** GigaChat вызывается с промптом для сжатия в ≤7 правил
- **THEN** старые уроки удаляются (`lessonRepository.deleteAll`)
- **THEN** создаются новые уроки с `source='auto'`, `approved=true`
- **THEN** возвращаются сжатые уроки

#### Scenario: Сжатие < 3 уроков
- **WHEN** в сценарии менее 3 уроков
- **THEN** возвращается HTTP 400 с сообщением «Слишком мало уроков для сжатия»

### Requirement: Авто-извлечение кандидатов-уроков
Система SHALL извлекать кандидатов-уроков из выходов узлов прогона через LLM.

#### Scenario: Извлечь из прогона
- **WHEN** пользователь отправляет `POST /api/agent/lessons/extract` с `{"run_id": "uuid"}`
- **THEN** загружаются шаги прогона и собираются выходы узлов
- **THEN** GigaChat вызывается с промптом для извлечения ≤5 правил из замечаний
- **THEN** каждый кандидат проходит фильтрацию:
  - не начинается с банального слова (`GENERIC_LESSON_STARTS`)
  - не является дубликатом существующего (60% значимых слов совпадает)
  - содержит фактуру (число, термин в кавычках, '=' или '—')
- **THEN** прошедшие сохраняются с `source='reviser'`, `approved=false`
- **THEN** возвращаются как неодобренные кандидаты

#### Scenario: Извлечь банальности
- **WHEN** LLM возвращает общие призывы («проверяйте», «следите»)
- **THEN** `specificLesson()` возвращает `false`
- **THEN** кандидат отбрасывается

### Requirement: Применение уроков к промпту
Система SHALL подмешивать уроки в промпт агентского узла тремя слоями.

#### Scenario: Три слоя уроков
- **WHEN** `AgentMemoryService.lessonsForScenario(scenarioId, runnerUserId)` вызывается
- **THEN** возвращаются:
  1. Системные уроки (`source='system'`, `scenario_id=NULL`) — до 10
  2. Личные общие запускающего (`user_id=runner`, `scenario_id=NULL`, `source≠'system'`) — до 10
  3. Сценарные одобренные (`scenario_id=UUID`, `approved=true`) — до 10
- **THEN** auto-кандидаты (`approved=false`) НЕ включаются

### Requirement: Память планов
Система SHALL сохранять и искать проверенные чек-листы по хэшу нормализованного задания.

#### Scenario: Сохранить план
- **WHEN** `AgentMemoryService.savePlan(scenarioId, task, plan)` вызывается
- **THEN** вычисляется SHA-256 нормализованного текста задания
- **THEN** если план с таким хэшем уже существует → `uses++` и `plan` обновляется
- **THEN** иначе создаётся новая запись `AgentPlan`

#### Scenario: Найти план
- **WHEN** `AgentMemoryService.findPlan(task)` вызывается
- **THEN** вычисляется хэш нормализованного текста
- **THEN** ищется `AgentPlan` по `task_hash`, сортированный по `uses DESC`
- **THEN** если найден → `uses++` и возвращаются пункты плана (`parsePlan`)
- **THEN** если не найден → возвращает `null`

#### Scenario: Получить планы сценария
- **WHEN** пользователь отправляет `GET /api/agent/plans?scenario_id=uuid`
- **THEN** возвращаются `AgentPlan[]` для сценария

#### Scenario: Удалить план
- **WHEN** пользователь отправляет `DELETE /api/agent/plans/{id}`
- **THEN** план удаляется
- **THEN** только автор сценария может удалить план

### Requirement: Вопросы агента (human-in-the-loop)
Система SHALL собирать вопросы от агента к пользователю (асинхронно) и превращать ответы в уроки.

#### Scenario: Получить вопросы по прогону
- **WHEN** пользователь отправляет `GET /api/agent/questions?run_id=uuid`
- **THEN** возвращаются `AgentQuestion[]` для прогона

#### Scenario: Ответить на вопрос
- **WHEN** пользователь отправляет `POST /api/agent/questions/{id}/answer` с `{"answer": "текст ответа"}`
- **THEN** `AgentQuestion.answer` и `answered_at` сохраняются
- **THEN** ответ автоматически превращается в урок сценария
- **THEN** при следующем прогоне вопроса не повторится (ответ сохранён в уроке)

### Requirement: Системные уроки
Система SHALL поставлять фиксированный набор системных уроков с релизом (`source='system'`), которые действуют для всех пользователей и не могут быть изменены или удалены.

#### Scenario: Системные уроки загружаются из миграции
- **WHEN** база данных инициализируется через Liquibase
- **THEN** `db.changelog-5.sql` INSERT-ит 6 системных уроков с фиксированными UUID
- **THEN** каждый системный урок имеет `source='system'`, `approved=true`, `scenario_id=NULL`, `user_id=NULL`
- **THEN** INSERT использует `WHERE NOT EXISTS` для идемпотентности

---

## Data Models

### AgentLesson

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | UUID | PK |
| `scenario_id` | UUID | NULL = общий |
| `user_id` | VARCHAR(64) | Автор |
| `lesson` | TEXT | Правило |
| `source` | VARCHAR(32) | user/reviser/auto/system |
| `approved` | BOOLEAN | Только одобренные в промпте |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

### AgentPlan

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | UUID | PK |
| `scenario_id` | UUID | |
| `task_hash` | VARCHAR(64) | SHA-256 |
| `task_preview` | TEXT | |
| `plan` | TEXT | JSON-массив строк |
| `uses` | INTEGER | Счётчик |
| `created_at` | TIMESTAMPTZ | |
| `updated_at` | TIMESTAMPTZ | |

### AgentQuestion

| Поле | Тип | Описание |
|------|-----|----------|
| `id` | UUID | PK |
| `run_id` | UUID | Прогон |
| `scenario_id` | UUID | |
| `node_label` | VARCHAR(255) | |
| `question` | TEXT | |
| `answer` | TEXT | |
| `answered_at` | TIMESTAMPTZ | |
| `created_at` | TIMESTAMPTZ | |
