---
capability: scenario-engine
---

# Scenario Engine Specification

## Purpose

Define the graph-based scenario engine: topological sort (Kahn's BFS), parallel wave execution via `ExecutorCompletionService`, skip-set on branch (DFS), SSE events, and step-by-step debugging mode with pause/resume.

## Requirements

### Requirement: Топологическая сортировка графа
Система SHALL сортировать узлы графа сценария топологически (алгоритм Кана) для определения порядка выполнения.

#### Scenario: Линейный граф
- **WHEN** граф содержит узлы A→B→C (ребро A→B, ребро B→C)
- **THEN** порядок сортировки: A, B, C (in_degree: A=0, B=1, C=1)
- **THEN** `OUTPUT_NODE` всегда имеет out_degree=0

#### Scenario: Циклический граф
- **WHEN** граф содержит цикл A→B→C→A
- **THEN** выбрасывается `ScenarioException(400)`: "Graph contains a cycle"
- **THEN** выполнение прерывается

### Requirement: Выполнение узлов волнами
Система SHALL выполнять узлы сценария параллельными волнами (независимые узлы в одной волне) через `ExecutorCompletionService`.

#### Scenario: Два независимых узла
- **WHEN** граф содержит A (INPUT_NODE) и B (PROCESSING_NODE) без рёбер между ними
- **THEN** оба выполняются параллельно (волна 1: оба)
- **THEN** `parallelThreads` по умолчанию равен **4** (соответствует `@Value("${app.scenario.parallel-threads:4}")` в `ScenarioEngine`)

### Requirement: Skip-set при ветвлении (DFS-обход)
Система SHALL помечать невыбранные ветви и их потомков как `SKIPPED`, когда узел Switch/If выполняет ветвление.

#### Scenario: Пропуск ветви Switch
- **WHEN** `SWITCH_NODE` направляет выполнение в ветвь B1, а не B2
- **THEN** B2 и все потомки B2 помечаются `SKIPPED`
- **THEN** `AbstractScenarioExecutor.getSkipSet()` вычисляет через DFS-обход потомков

### Requirement: SSE-события на всех фазах выполнения
Система SHALL эмитировать SSE-события при изменении статуса, статуса узлов, прогресса шагов, результатов RAG и вывода файлов.

#### Scenario: Событие статуса
- **WHEN** запуск сценария начинается
- **THEN** эмитируется `type="status"`, `run_id`, `status="RUNNING"`
- **WHEN** запуск сценария завершается
- **THEN** эмитируется `type="status"`, `status="COMPLETED"`

#### Scenario: Событие статуса узла
- **WHEN** узел начинает выполнение
- **THEN** эмитируется `type="node_status"`, `node_id`, `status="RUNNING"`
- **WHEN** узел завершает выполнение
- **THEN** эмитируется `type="node_status"`, `status="COMPLETED"`

### Requirement: Пошаговый режим с паузой/продолжением
Система SHALL поддерживать отладочный пошаговый режим: пауза перед каждым узлом через `CompletableFuture<Void>` и продолжение через endpoint `/continue`.

> **Таймаут**: `PAUSE_TIMEOUT_MINUTES = 30` (hardcoded в `ScenarioEngine.java`). `@Scheduled(fixedRate = 60000)` очищает просроченные сессии.

#### Scenario: Пауза перед каждым узлом
- **WHEN** сценарий запускается с `step_mode=true`
- **THEN** перед каждым узлом создаётся `CompletableFuture<Void>` (таймаут 30 минут)
- **THEN** через SSE эмитируется `type="step_paused"`, `node_id`, `total`
- **THEN** `POST /api/scenarios/runs/{runId}/continue` завершает future

#### Scenario: Отключение пошагового режима во время выполнения
- **WHEN** `POST /api/scenarios/runs/{runId}/disable-step-mode`
- **THEN** все ожидающие `CompletableFuture` завершаются
- **THEN** оставшиеся узлы выполняются без пауз

### Requirement: Остановка прогона
Система SHALL позволять пользователю явно останавливать выполняющийся прогон через REST.

#### Scenario: Остановить прогон
- **WHEN** пользователь отправляет `POST /api/scenarios/runs/{runId}/cancel`
- **THEN** `ScenarioEngine.requestCancel(runId)` взводит `cancelRequested = true` в `activeGraphs[runId]`
- **THEN** `continueStep(runId)` снимает паузу пошагового режима (если активен)
- **THEN** каждый узел проверяет `graph.isCancelRequested()` перед выполнением
- **THEN** инструменты агента (`AgentDocumentTools`) проверяют `runCancelled` на каждом вызове
- **THEN** прогон завершается со статусом `FAILED`
- **THEN** возвращает HTTP 200 (остановка запрошена)

#### Scenario: Остановить неактивный прогон
- **WHEN** прогон уже завершён или не найден
- **THEN** `requestCancel()` возвращает `false`
- **THEN** HTTP 200 (безопасный вызов)

#### Scenario: Обрыв соединения не останавливает прогон
- **WHEN** WebSocket-соединение разрывается
- **THEN** прогон продолжается (нестабильная корпоративная сеть)
- **THEN** только явный `POST .../cancel` останавливает прогон

### Requirement: Чекпоинты узлов
Система SHALL сохранять чекпоинт упавшего узла для возобновления.

#### Scenario: Чекпоинт при ошибке узла
- **WHEN** узел завершается с исключением
- **THEN** `handleNodeError()` вызывается с экземпляром `AbstractScenarioExecutor`
- **THEN** `saveNodeCheckpoint()` вызывает `executorNode.getCheckpoint()`
- **THEN** чекпоинт (наблюдения агентского цикла) сохраняется в `output_data` шага
- **THEN** сохраняется ПОСЛЕ failed-статуса (чтобы not overwrite)
- **THEN** при `resumeScenario()` чекпоинты восстанавливаются через `restoreAgentCheckpoints()`

### Requirement: userId awareness
Система SHALL передавать userId запускающего пользователя в Engine → применяются личные общие уроки.

#### Scenario: Запуск сценария с userId
- **WHEN** `ScenarioService.runScenario(userId, scenarioId, stepMode)` вызывается
- **THEN** `scenarioEngine.executeScenario(run, graphData, userId)` передаёт userId
- **THEN** `graph.setRunnerUserId(userId)` устанавливает запускающего
- **THEN** `AgentMemoryService.lessonsForScenario(scenarioId, runnerUserId)` включает личные общие уроки

#### Scenario: Возобновление с userId
- **WHEN** `ScenarioService.resumeOldRun(userId, runId)` вызывается
- **THEN** `scenarioEngine.resumeScenario(run, graphData, oldSteps, userId)` передаёт userId
- **THEN** восстанавливаются чекпоинты из старого прогона

### Requirement: Shared сценарии
Система SHALL позволять всем пользователям запускать общие (`shared=true`) сценарии.

#### Scenario: Запуск общего сценария
- **WHEN** пользователь отправляет `POST /api/scenarios/{id}/run` для `shared=true`
- **THEN** `UserUtils.checkUserId()` НЕ вызывается (проверка пропускается)
- **THEN** прогон создаётся для любого пользователя

#### Scenario: Запуск личного сценария
- **WHEN** пользователь отправляет `POST /api/scenarios/{id}/run` для `shared=false`
- **THEN** `UserUtils.checkUserId(userId, model.getUserId())` проверяет авторство
- **THEN** неавтор получает ошибку

#### Scenario: Возобновление общего прогона
- **WHEN** `POST /api/scenarios/runs/{runId}/resume` для общего сценария
- **THEN** проверка авторства пропускается
- **THEN** любой пользователь может возобновить

### Requirement: Лимиты WS-пэйлоадов
Система SHALL обрезать данные в WS-событиях для предотвращения раздувания сокетов.

#### Scenario: Обрезка result в status-событии
- **WHEN** эмитируется `ScenarioEventEmission.emitStatusEvent(finalResult)`
- **THEN** `finalResult` обрезается до `PREVIEW_RESULT` (3000 символов)
- **THEN** добавляется суффикс «… [показано начало; полные данные — в отчёте прогона]»

#### Scenario: Обрезка STEP_COMPLETE
- **WHEN** эмитируется `ScenarioEventEmission.emitStepCompleteEvent(step, node)`
- **THEN** `inputData.documents_text` обрезается до `PREVIEW_DOCS` (1000)
- **THEN** `inputData.previous_output` обрезается до `PREVIEW_PREV` (1000)
- **THEN** `outputData.result` обрезается до `PREVIEW_RESULT` (3000)
- **THEN** `prompt_used` обрезается до `PREVIEW_PROMPT` (2000)

#### Scenario: FILE_OUTPUT — только файл-гаджет
- **WHEN** эмитируется `ScenarioEventEmission.emitFileOutputEvent(result, mode, node)`
- **THEN** вместо base64-байтов устанавливается только `file_ready: true`
- **THEN** клиент забирает байты через `GET /api/scenarios/runs/{runId}/files/{nodeId}`
