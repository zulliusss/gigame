# XLSX Export Enhancement

## Purpose

Extends XLSX export (`ScenarioResultToXlsx`) with dynamic column expansion, section highlighting, and cell value-based highlighting for output node templates.

## Requirements

### Requirement: Dynamic Columns via key_prefix

A column definition with `key_prefix` (instead of `key`) SHALL expand into separate columns for each unique data key starting with that prefix at execution time.

#### Scenario: Dynamic column expansion

- **WHEN** rules contain `{"key_prefix": "technology_", "header_prefix": "Technology: "}`
- **AND** data contains keys: `technology_a`, `technology_b`, `technology_c`
- **THEN** three columns are created with headers: "Technology: a", "Technology: b", "Technology: c"
- **THEN** columns appear in order of first key discovery in data

#### Scenario: Static and dynamic columns coexist

- **WHEN** rules contain both `"key": "criterion"` and `"key_prefix": "tech_"`
- **THEN** the static column appears first, followed by expanded dynamic columns

#### Scenario: Dynamic column with no matches

- **WHEN** a prefix column has no matching keys in data
- **THEN** no columns are expanded for that prefix

### Requirement: Section Highlighting

When rules contain `{"highlight_sections": true}`, rows where only the first column has a value (others empty) SHALL receive the header font style (bold).

#### Scenario: Section row highlighted

- **WHEN** `"highlight_sections": true` is set
- **AND** a row has a value only in the first column, empty in others
- **THEN** the row uses the header cell style (bold font)
- **THEN** normal data rows use normal style (non-bold)

#### Scenario: Section highlighting disabled

- **WHEN** `"highlight_sections"` is not set or `false`
- **THEN** all data rows use normal data style

#### Scenario: Section row not recognized

- **WHEN** a row has values in multiple columns (not a section pattern)
- **THEN** it uses normal data style even when section highlighting is enabled

### Requirement: Cell Value-Based Highlighting

A column definition MAY contain a `"highlight": {"value": "color"}` mapping. When a cell value matches the key, it SHALL receive colored fill.

#### Scenario: Green for "Matches"

- **WHEN** rules contain `"highlight": {"Matches": "green"}`
- **AND** cell value is `"Matches"` (case-insensitive comparison)
- **THEN** cell receives LIGHT_GREEN fill (`IndexedColors.LIGHT_GREEN`)

#### Scenario: Red for "Not matches"

- **WHEN** rules contain `"highlight": {"Not matches": "red"}`
- **AND** cell value is `"Not matches"` (case-insensitive comparison)
- **THEN** cell receives ROSE fill (`IndexedColors.ROSE`)

#### Scenario: Unrecognized color name

- **WHEN** color name is unrecognized ("green", "red", "yellow", etc.)
- **THEN** fill is not applied (falls back to default data style)

#### Scenario: Bilingual highlight colors

- **WHEN** value key matches a Russian or English color name
- **THEN** both are supported: "green"/"зелёный" → LIGHT_GREEN, "red"/"красный" → ROSE, "yellow"/"желтый" → LIGHT_YELLOW

#### Scenario: Highlight styles are cached

- **WHEN** multiple cells require the same highlight
- **THEN** a single `CellStyle` is created and reused (Excel style limit safety)

### Requirement: Empty Array with Template

When data is an empty JSON array `[]` but a template is specified, export SHALL create an XLSX with only the header row.

#### Scenario: Empty data produces header-only workbook

- **WHEN** data is `[]` and rules specify columns
- **THEN** a workbook with one header row is created
- **THEN** no data rows are created
- **THEN** no exception is thrown

### Requirement: extractJson Visibility

The `extractJson()` method SHALL be package-private (accessible in `scenario` package) to support accumulation logic in `ScenarioOutputSupportService`.

#### Scenario: extractJson used by accumulation

- **WHEN** `ScenarioOutputSupportService.parseRows()` needs to extract JSON from a node result
- **THEN** it can call `ScenarioResultToXlsx.extractJson()` (same package)
