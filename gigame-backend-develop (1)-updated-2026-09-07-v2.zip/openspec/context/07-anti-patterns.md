---
owner: Сеньор / Тимлид
updated: 2026-08-05
---
# Anti-patterns

## Deprecated API / паттерны

- **`server.servlet.context-path`** — не использовать в WebFlux. Для base path: `spring.webflux.base-path`
- **`spring.jpa.hibernate.ddl-auto: update`** — на проде только `validate`. Миграции — только через Liquibase SQL
- **`open-in-view: true`** — ломает реактивный стек, вызывает `LazyInitializationException`

## На чем спотыкаются

### 1. `@Type(JsonType)` для pgvector — неправильно

`float[]` для pgvector требует `@Type(FloatArrayType.class) + @Array(length = 1024)`. `@Type(JsonType)` подходит только для `Map<String, Object>` JSONB-колонок.

```java
// ❌ Неправильно
@Column(columnDefinition = "vector(1024)")
@Type(JsonType)
private float[] vector;

// ✅ Правильно
@Column(columnDefinition = "vector(1024)")
@Type(FloatArrayType.class)
@Array(length = 1024)
private float[] vector;
```

### 2. REST эндпоинты для SSE-потоков

Отправка сообщений чата и запуск сценариев — **только через WebSocket**. Нет REST-эндпоинтов `POST /api/conversations/{id}/messages` или `POST /api/scenarios/{id}/run`.

### 3. JSONB поле `document_ids` vs `docs`

В сущности `Message` поле называется `documentIds` (не `docs`). В БД — `document_ids` (snake_case). При ручных запросах к БД использовать правильное имя.

### 4. user_id только на root-сущностях

Только 5 из 11 JPA-сущностей имеют `user_id`: `Conversation`, `Document`, `KnowledgeBase`, `Scenario`, `Prompt`. Дочерние (`Message`, `KBDocument`, `Embedding`, `ScenarioRun`, `ScenarioRunStep`, `ScenarioVersion`, `PromptRating`, `ScenarioRating`) — нет. Фильтрация по `user_id` для дочерних — через JOIN с parent.

### 5. `parallel-threads` по умолчанию 4, не 2

В `ScenarioEngine`: `@Value("${app.scenario.parallel-threads:4}")`. В документации могли быть старые значения.

### 6. `MAX_SUB_DEPTH = 2`, не 3

Глубина рекурсии для `SUBSCENARIO_NODE` захардкожена в `ScenarioEngine` как `2`.

### 7. GigaChat timeouts на другом пути

Конфигурация по пути `spring.ai.gigachat.internal.*`, а не `chat.*`. Значения: connect=**10s**, read=**60s**.

### 8. Replace-модель для рейтингов

Повторный вызов `POST /{id}/rating` создаёт **новую** запись, а не обновляет старую. PK `(entityId, userId)` обеспечивает uniqueness. Для batch-расчёта рейтингов использовать `findByPromptIdIn(ids)` или `findByScenarioIdIn(ids)`, агрегация in-memory.

```java
// ❌ Неправильно: искать и обновлять
PromptRating existing = ratingRepository.findByPromptIdAndUserId(promptId, userId);
if (existing != null) {
    existing.setRating(newRating);
}

// ✅ Правильно: save создает новую запись (PK ensures uniqueness)
PromptRating vote = new PromptRating();
vote.setPromptId(promptId);
vote.setUserId(userId);
vote.setRating(newRating);
ratingRepository.save(vote);  // upsert by PK
```

### 9. Shared visibility logic

При проверке видимости использовать `Boolean.TRUE.equals(entity.getShared())` (null-safe). Не использовать `entity.getShared() == true`.

```java
// ❌ Неправильно
if (prompt.getShared()) { ... }

// ✅ Правильно
if (Boolean.TRUE.equals(prompt.getShared())) { ... }
```

### 10. Reactive endpoints без `boundedElastic`

Все REST-эндпоинты должны использовать `Mono.fromCallable()` + `Schedulers.boundedElastic()`. Не вызывать JPA-репозитории напрямую в reactive-потоке.

```java
// ❌ Неправильно
@GetMapping
public List<PromptResponse> listPrompts(String userId) {
    return promptService.getPrompts(userId);  // blocks reactive thread!
}

// ✅ Правильно
@GetMapping
public Mono<List<PromptResponse>> listPrompts(String userId) {
    return Mono.fromCallable(() -> promptService.getPrompts(userId))
            .subscribeOn(Schedulers.boundedElastic());
}
```

## Bad examples

```java
// ❌ REST для чата — нет такого эндпоинта
@PostMapping("/{id}/messages")
public Flux<ServerSentEvent> sendMessage(...) { ... }

// ✅ WebSocket
@Component
public class ChatWebSocketHandler implements WebSocketHandler {
    public void handleTextMessage(...) {
        switch (actionType) {
            case SEND -> chatService.sendMessageStream(...);
        }
    }
}
```
