---
owner: Тимлид (context owner)
updated: 2026-08-05
---
# Start Here

## Продукт
**GigaMe Backend** — Spring Boot 3.5.15 / Java 17 backend-сервис для AI-чата с GigaChat, RAG, баз знаний и графового движка сценариев (12 узлов) (Сбер, внутренний). Версия: 1.4.0.

## Последние изменения (с 2026-07-31)

- **Prompt Library** — CRUD для промптов (`/api/prompts`), сущность `Prompt` с полем `shared`, счётчиком использований, привязкой модели GigaChat
- **Ratings System** — оценка сценариев и промптов (1–5), эндпоинты `POST /api/scenarios/{id}/rating` и `POST /api/prompts/{id}/rating`, replace-модель
- **Shared visibility** — поле `shared` в `Scenario` (по умолчанию `false`), аналогично `Prompt` (`shared=true`)
- **Async upload** — асинхронная загрузка файлов сценария (`async=true` + `GET /upload-status`)
- **Output node enrichment** — «накапливать» (нарастающий итог), «в базу знаний» (сохранение реестра)
- **XLSX export** — динамические колонки (`key_prefix`), выделение секций, подсветка ячеек

## Перед любой задачей

1. **Прочитай** `01-product-context.md` — пойми, для кого продукт и какие сценарии нельзя ломать.
2. **Сверься** с `05-security-and-compliance.md` (⚠️ не согласован с ИБ) и `07-anti-patterns.md` (заполнен).
3. **Убедись**, что не нарушаешь архитектурные инварианты (`03-architecture.md`):
   - Reactive (WebFlux), никакого WebMVC
   - `open-in-view: false`
   - Liquibase для миграций (`ddl-auto: validate`)
   - Все эндпоинты — через `X-UserId`
   - WebSocket-only SSE (нет REST-отправки сообщений или запуска сценариев)
4. **Проверь** конвенции кода (`checkstyle.xml`): Java records для DTO, `"constant".equals()`, без `*`-imports, без `nested try`.

## Главные запреты

- **Не менять** структуру API-ответов и WebSocket-событий без backward-compatibility.
- **Не добавлять** блокирующие вызовы в WebFlux без `boundedElastic` пула.
- **Не использовать** `spring.jpa.hibernate.ddl-auto: update` — только Liquibase.
- **Не нарушать** изоляцию `user_id` — данные одного пользователя не видны другому.
- **Не писать** секреты, ключи, сертификаты в код или репозиторий (classpath только).
- **Не превышать** 80% coverage по JaCoCo (нижняя планка).

## Куда смотреть

- **Актуальный код:** `src/main/java/ru/sber/cs/ai/gigame/`
- **API:** OpenAPI `openapi/gigame.yaml`, Swagger UI на `/gigame/swagger-ui.html`
- **WebSocket:** `/ws/chat` и `/ws/scenario` (см. `WEBSOCKET_API.md`)
- **Спецификации:** `openspec/specs/` — 15 main spec-файлов (prompts, ratings, async-upload, output-node-enrichment, xlsx-export добавлены)
- **Архитектура:** `openspec/context/03-architecture.md` — диаграмма и инварианты
- **Anti-patterns:** `openspec/context/07-anti-patterns.md` — частые ошибки
- **Тесты:** `mvn test -Dtest=ClassName` (100+ существующих тестов)
- **Сырой контекст:** `openspec/context/_raw/ABOUT.md` — полное описание продукта (но сверяйся с кодом при расхождениях)