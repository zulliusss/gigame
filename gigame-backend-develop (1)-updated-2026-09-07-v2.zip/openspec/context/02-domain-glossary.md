---
owner: Аналитик
updated: 2026-08-05
---
# Глоссарий

> Все термины используются в прямом значении, неоднозначных/внутренних переопределений нет.

## Системы и аббревиатуры

| Термин | Значение |
|--------|----------|
| **GigaChat** | AI-платформа Сбера (LLM + эмбеддинги). API-доступ по сертификатам (.pem/.key) |
| **GigaMe** | Внутренний продукт Сбера — программа для работы с GigaChat (frontend + backend) |
| **GigaMe Backend** | Backend-сервис (этот проект), Spring Boot, Java 17 |
| **RAG** | Retrieval-Augmented Generation — поиск релевантных фрагментов через pgvector + LLM |
| **KB / БЗ** | Knowledge Base / База знаний — коллекция документов с векторными эмбеддингами для RAG |
| **pgvector** | Расширение PostgreSQL для векторного поиска (1024d, IVFFlat, cosine distance `<->`) |
| **SSE** | Server-Sent Events — потоковая передача токенов и событий выполнения |
| **Scenario** | Сценарий — графовый workflow (не JS-код). Состоит из узлов (nodes) и рёбер (edges) |
| **Scenario Run** | Прогон сценария — конкретное выполнение графа с документами |
| **Scenario Run Step** | Шаг прогона — результат выполнения одного узла в рамках run |
| **WebSocket** | `/ws/chat` и `/ws/scenario` — единственный канал для SSE-потоков (REST-отправка сообщений и запуск сценариев отсутствуют) |
| **OCR** | Оптическое распознавание PDF-сканов через GigaChat Files API |
| **JSONB** | Тип PostgreSQL для хранения гибких данных (graphData, metadata, documentIds) |
| **IVFFlat** | Тип индекса pgvector (Inverted File with Flat vectors), 100 lists |
| **LLM-роутинг** | Определение через GigaChat, каких БЗ касается вопрос (fail-open) |
| **Checkstyle** | Инструмент контроля стиля кода (error-level) |
| **Prompt** | Шаблон промпта для GigaChat, с shared visibility и статистикой (usageCount, rating) |
| **Replace-модель** | Повторный вызов `POST /{id}/rating` заменяет предыдущую оценку (PK `(entityId, userId)`) |
| **Async Upload** | Асинхронная загрузка файлов сценария (`async=true` + polling через `GET /upload-status`) |
| **SkipSet** | Набор узлов, пропускаемых при выполнении сценария (на ветвлении Switch/If, DFS) |
| **StepMode** | Пошаговый режим отладки сценария (pause after each node) |

## Связи терминов

- **Scenario** состоит из **Nodes** (узлы) и **Edges** (рёбра) — граф
- **ScenarioRun** = один **прогон** графа с конкретными **документами на входе**
- **ScenarioRunStep** = результат выполнения **одного узла** в прогоне
- **KB** содержит **Documents**; **Documents** чанкуются → **Embeddings** (vector)
- **Загрузка** документа ≠ **индексация** (загрузка → извлечение текста; индексация → чанкование + эмбеддинг)
- **Prompt** имеет **shared** флаг (видимость всем/личные), **rating** (оценка 1–5), **usageCount** (счётчик использований)
- **Scenario** также имеет **shared** флаг (с v1.4.0)