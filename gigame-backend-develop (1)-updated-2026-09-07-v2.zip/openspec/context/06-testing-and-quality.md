---
owner: QA / тест-лид
updated: 2026-08-05
---
# Testing & Quality
> Подсказка: что и зачем проверять. В отличие от 04 (как запускать), здесь — стратегия проверок.

## Coverage

- **Минимум:** 80% complexity по JaCoCo
- **Отчёт:** `target/coverage-reports/` после `mvn test jacoco:report`

## Критичные модули (обязательно покрывать)

1. **Scenario Engine** — топологическая сортировка, SkipSet (DFS), StepMode, все 12 executor-ов
2. **ChatService** — RAG-поиск, суммаризация, валидация историй
3. **EmbeddingService** — чанкование (1000/200), IVFFlat индекс, cosine similarity
4. **PromptService** — shared visibility, rating aggregation, replace-модель
5. **KBService** — CRUD, привязка документов, реиндексация
6. **WebSocket handlers** — `/ws/chat`, `/ws/scenario`, SSE-потоки
7. **DocumentService** — парсинг (PDF/DOCX/XLSX/TXT/7z), soft degradation, parallel parsing

## Стратегия тестирования

### Unit-тесты
- Service layer: mock repository, verify business logic
- Controller layer: `@WebMvcTest` или mock `Mono`, verify REST contracts
- Repository layer: `@DataJpaTest` с H2/Testcontainers

### Integration-тесты
- Сценарии запуска с `ScenarioEngineIntegrationTest`
- RAG-поиск с реальными embedding
- WebSocket-сессии, SSE-потоки

### Проверка качества
- **Checkstyle:** `mvn validate` — error-level, все правила из `checkstyle.xml`
- **Sonar:** покрытие, когнитивная сложность, дублирование, security hotspots
- **JaCoCo:** coverage report, minimum 80%

## Запуск:
```bash
mvn test                                  # все тесты
mvn test -Dtest=ClassNameTest             # один тест
mvn test jacoco:report                    # coverage report
```

## Прошло = 
- Все тесты зелёные (0 failures, 0 errors)
- Coverage ≥ 80% complexity
- Checkstyle: 0 violations
- Когнитивная сложность методов ≤ 15
- Нет пустых catch-блоков
