---
owner: Архитектор / Тимлид
updated: 2026-08-05
---
# Architecture

## Инварианты

1. **Reactive throughout** — весь стек на Spring WebFlux (reactive). Блокирующие вызовы (JDBC) — только в выделенных пулах. Никакого WebMVC.
2. **No `open-in-view`** — `spring.jpa.open-in-view: false`. Все запросы к БД — только в `@Transactional` контексте. Иначе — LazyInitializationException.
3. **WebSocket — единственный канал для SSE** — чат (`/ws/chat`) и сценарии (`/ws/scenario`) работают через WebSocket + SSE-потоки. Нет REST-эндпоинтов для отправки сообщений или запуска сценариев.
4. **UUID PK + user_id на root-сущностях** — JPA-сущности с автогенерацией используют `DEFAULT uuid_generate_v4()`. Root-сущности (`Conversation`, `Document`, `KnowledgeBase`, `Scenario`, `Prompt`) имеют `user_id`. Дочерние (`Message`, `KBDocument`, `Embedding`, `ScenarioRun`, `ScenarioRunStep`, `ScenarioVersion`, `PromptRating`, `ScenarioRating`) — нет, доступ через parent.
5. **Миграции через Liquibase** — `ddl-auto: validate`, никакой `update` в проде. Каждое изменение схемы — SQL-файл в Liquibase changelog.
6. **Shared visibility** — `shared` флаг на `Prompt` (по умолчанию `true`) и `Scenario` (по умолчанию `false`). Логика: `WHERE (userId = :userId OR shared = true)`.

## Обязательные / запрещенные паттерны

**Обязательно:**
- DTO — Java records (response DTO)
- Логирование — Slf4j structured logging
- Lombok — `@RequiredArgsConstructor`, `@Data`, `@Slf4j`
- Исключения — кастомные (`NotFoundException`, `ScenarioException`, ...) + `@ControllerAdvice` + `ApplicationRuntimeException`
- Миграции — Liquibase (`ddl-auto: validate`)
- JSONB — `@JdbcTypeCode(SqlTypes.JSON)` для `Map<String,Object>`, `@Type(FloatArrayType.class)` для `float[]` (pgvector)
- Reactive endpoints — `Mono.fromCallable()` + `Schedulers.boundedElastic()` для всех REST-эндпоинтов

**Запрещено:**
- `*`-imports (AvoidStarImport)
- `nested try` — выносить в отдельный метод
- `variable.equals("constant")` — только `"constant".equals(variable)`
- `open-in-view: true`
- `spring.jpa.hibernate.ddl-auto: update` (на проде — только validate через Liquibase)
- Блокирующие вызовы в реактивном потоке без явного `Schedulers.boundedElastic()`
- Вызов `UserUtils.getUserId()` без проверки на `null` — fallback: `"anonymous"`

## Схема

```
┌─────────────────────────────────────────────────────────┐
│                   GigaMe Backend                        │
│              (Spring Boot 3.5.15 / Java 17)             │
│                  Spring WebFlux (Reactive)               │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  REST API                                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Conversations│  │  Documents   │  │Knowledge Bases│  │
│  │ CRUD only   │  │ GET/DELETE   │  │ CRUD + docs  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│  (SSE через WS)  (через KB)                           │
│                                                          │
│  Prompt Library (v1.4.0)                                │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  /api/prompts│  │  /api/prompts│  │  /api/prompts│  │
│  │  GET / PUT   │  │  POST /{id}  │  │  DELETE /{id}│  │
│  │  + ratings   │  │  + rating    │  │  + /use      │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
│                                                          │
│  WebSocket                                               │
│  /ws/chat    → SEND/REGENERATE/EDIT → SSE токены        │
│  /ws/scenario→ run/continue/disable-step → SSE events   │
│                                                          │
│  Scenario Engine (12 узлов)                              │
│  Input | Output | Processing | Loop | Switch | If       │
│  Calc  | Aggregate| Transform | Subscenario | Control | Wait│
│  SkipSet (DFS) | TopoSort (Kahn BFS) | StepMode         │
│                                                          │
│  PostgreSQL 15+ ─ pgvector (IVFFlat, cosine, 100 lists)  │
│  ──────────────── Liquibase (all SQL, validate)         │
│  ──────────────── 11 JPA entities (5 with user_id)      │
└─────────────────────────────────────────────────────────┘
```

## Ключевые интеграции и зависимости

| Система | Роль | Тип | Примечание |
|---------|------|-----|------------|
| **PostgreSQL 15+** | Основное хранилище (JPA + pgvector) | sync (пул) | |
| **pgvector** | Векторный поиск (IVFFlat, 100 lists, cosine) | sync | `vector(1024)` |
| **GigaChat API** | LLM-вызовы (chat + embeddings) | sync | connect: 10s, read: **60s** |
| **GigaChat Files API** | OCR сканов | sync | ocr-via-gigachat: false (по умолч.) |
| **Liquibase** | Миграции схемы | auto (при старте) | ddl-auto: validate |
| **XZ (org.tukaani)** | 7z support (ZipExtractor) | sync | v1.12 |

## Entity inventory (v1.4.0)

**Root entities (user_id):** `Conversation`, `Document`, `KnowledgeBase`, `Scenario`, `Prompt`
**Child entities (no user_id):** `Message`, `KBDocument`, `Embedding`, `ScenarioRun`, `ScenarioRunStep`, `ScenarioVersion`, `PromptRating`, `ScenarioRating`

**JPA entities total:** 11 (5 с `user_id`, 6 без)
**Main Java files:** 133
**Test Java files:** 131
**OpenAPI specs:** 15
