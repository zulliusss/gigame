---
created: 2026-08-05
updated: 2026-08-05
---
# Changelog & Recent Changes

## Version 1.4.0 (2026-08-05)

### Новые модули

#### Prompt Library (`/api/prompts`)
- **CRUD:** `GET`, `POST`, `PUT/{id}`, `DELETE/{id}`
- **Rating:** `POST /{id}/rating` (1–5, replace-модель)
- **Usage:** `POST /{id}/use` — инкремент счётчика + возврат текста
- **Entity:** `Prompt` с полями `id`, `userId`, `title`, `description`, `text`, `model`, `shared`, `usageCount`, `createdAt`, `updatedAt`
- **Shared:** по умолчанию `true`, visible всем
- **Model:** привязка к модели GigaChat (до 64 chars, normalize blank → null)
- **Stats в ответе:** `ratingAvg` (rounded to 0.1), `ratingCount`, `myRating`, `usageCount`

#### Ratings System
- **Prompt Ratings:** `PromptRating` entity, PK `(promptId, userId)`
- **Scenario Ratings:** `ScenarioRating` entity, PK `(scenarioId, userId)`
- **Replace-модель:** повторная оценка создаёт новую запись (PK ensures uniqueness)
- **Batch calculation:** один `IN`-запрос для всех рейтингов списка, агрегация in-memory
- **Visibility:** shared или owner может оценить

#### Shared visibility
- **Scenario:** добавлено поле `shared` (по умолчанию `false`)
- **Логика:** `WHERE (userId = :userId OR shared = true) ORDER BY updatedAt DESC`
- **Actions:** `checkVisible(userId, entity)` → `shared` или owner

### Улучшения сценариев

#### Async Upload
- **async=true:** асинхронная загрузка файлов сценария
- **Polling:** `GET /upload-status` для отслеживания прогресса
- **Цель:** обход шлюзовых таймаутов на больших комплектах файлов

#### Output Node Enrichment
- **«Накапливать»:** нарастающий итог через прогоны (aggregation across runs)
- **«В базу знаний»:** сохранение реестра в БЗ (KB persistence)

#### XLSX Export Improvements
- **Динамические колонки:** `key_prefix` для генерации header
- **Выделение секций:** жирный шрифт для section headers
- **Подсветка ячеек:** зелёный/красный/жёлтый по значению

### Улучшения парсинга документов

#### Soft Degradation
- Битый файл получает маркер «[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]» + предупреждение в лог
- Не роняет весь комплект

#### OOXML Bomb Rejection
- **rejectOoxmlBomb:** отсечка до POI
- **Env:** `${MAX_OOXML_ENTRY_MB}` (дефолт 50 MB)

#### Parallel Parsing
- **parseAllParallel:** разделение на сбор сырых документов и параллельную фазу
- **Env:** `${PARSE_PARALLELISM}` (дефолт 4)

#### 7z Support
- **ZipExtractor:** взаимная рекурсия zip↔7z
- **Общие лимиты:** защита от bomb attacks
- **Dependency:** `org.tukaani:xz:1.12`

#### XLSX Smart Number Handling
- **setCellSmart:** суммы как числа, целые строки (номера, ИНН) — текст

## Версии

- **Текущая:** 1.4.0 (pom.xml)
- **Предыдущая:** 1.3.1

## Stats

| Metric | Value |
|--------|-------|
| Main Java files | 133 |
| Test Java files | 131 |
| Total tests | 500+ |
| OpenAPI specs | 15 |
| Liquibase changelogs | 2 (db.changelog-1.sql, db.changelog-2.sql) |
| JPA entities | 11 (5 root with user_id, 6 child) |
| REST controllers | 5 |
| WebSocket handlers | 2 |
| Scenario executors | 12 |

## OpenSpec Changes Archive

| Archive | Status | Description |
|---------|--------|-------------|
| `2026-07-31-master-spec` | archived | Master specification sync |
| `2026-08-04-delta-async-upload-output-xlsx` | archived | Async upload, output enrichment, XLSX improvements |
| `2026-08-05-prompts-and-ratings` | archived | Prompt Library + Ratings System |
