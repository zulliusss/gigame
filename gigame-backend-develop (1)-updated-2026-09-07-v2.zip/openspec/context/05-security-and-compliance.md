---
owner: ИБ / AppSec
updated: 2026-08-05
---
# Security & Compliance

> ⚠️ **Блок не согласован с ИБ** — требуется отдельное согласование.

## Классификация данных

> TODO: [уточнить у ИБ — ПДн, коммерческая/банковская тайна]

## Аутентификация / мультитенантность

- **`X-UserId`** — обязательный заголовок в каждом REST-запросе и WebSocket-handshake
- **Fallback**: `UserUtils.getUserId()` → `"anonymous"` при отсутствии заголовка
- **Root-сущности имеют `user_id`**: `Conversation`, `Document`, `KnowledgeBase`, `Scenario`, `Prompt`
- **Дочерние сущности** (`Message`, `KBDocument`, `Embedding`, `ScenarioRun`, `ScenarioRunStep`, `ScenarioVersion`, `PromptRating`, `ScenarioRating`) **не имеют** `user_id` — доступ контролируется через связь с родительской root-сущностью
- **Проверка**: `UserUtils.checkUserId(requestUserId, entityUserId)` → `AccessDeniedException(403)`
- **Нет токенов**: без JWT, без OAuth2, без сессий

## Shared visibility

- **Prompt**: `shared=true` (по умолчанию), видим всем. `shared=false` → только owner.
- **Scenario**: `shared=false` (по умолчанию), `shared=true` → видим всем.
- **Логика**: `WHERE (userId = :userId OR shared = true) ORDER BY updatedAt DESC`
- **Действия** (rating, use, update, delete): `checkVisible(userId, entity)` → `shared` или owner

## Запреты (известные из кода)

- Секреты НЕ должны попадать в код: сертификаты `.pem`/`.key` — в classpath, не в репозиторий
- `X-UserId` обязателен — ни один endpoint не должен обходить проверку
- Rating-эндпоинты проверяют visibility (shared или owner) перед сохранением

## Зоны без автономии агента

> TODO: [уточнить у ИБ]

## Аудит

> TODO: [требования аудита]

## Связанные артефакты

- **Main spec**: `openspec/specs/api/spec.md` — X-UserId контракты
- **Main spec**: `openspec/specs/data-model/spec.md` — user_id на root vs child
- **Main spec**: `openspec/specs/prompts/spec.md` — shared visibility для промптов
- **Main spec**: `openspec/specs/ratings/spec.md` — replace-модель для рейтингов
- **Main spec**: `openspec/specs/scenario-engine/spec.md` — SSE events и step-mode

## ⚠️ Важно

Этот блок необходимо показать ИБ на согласование перед использованием контекста.
