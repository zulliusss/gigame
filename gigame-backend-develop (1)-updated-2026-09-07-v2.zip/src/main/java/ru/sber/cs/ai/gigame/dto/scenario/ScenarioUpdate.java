package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;

/**
 * DTO для обновления сценария.
 * Используется при изменении имени, описания и/или графа выполнения сценария.
 *
 * @param name        Новое название сценария (опционально, максимум 64 символа)
 * @param description Новое описание сценария (опционально, максимум 255 символов)
 * @param graphData   Обновленные данные графа выполнения (опционально)
 * @see ScenarioCreate
 * @see ScenarioResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Запрос на обновление AI-сценария (workflow)",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioUpdate(
        @Schema(
                description = "Новое название сценария",
                example = "Обновленная обработка заявок",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Новое описание сценария",
                example = "Обновленная логика обработки заявок",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String description,

        @Schema(
                description = "Обновленные данные графа выполнения"
        )
        GraphDataDto graphData,
//        @Size(max = 1000)
//        Map<String, Object> graphData

        @Schema(
                description = "Сделать сценарий общим (виден и доступен всем пользователям). "
                        + "null — не менять. Менять может только владелец."
        )
        Boolean shared
) {
    /** Совместимость с прежними вызовами без поля shared. */
    public ScenarioUpdate(String name, String description, GraphDataDto graphData) {
        this(name, description, graphData, null);
    }
}
