package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Getter
public abstract class AbstractScenarioExecutor {
    /**
     * Максимальная длина текста документа для включения полного содержимого в промпт.
     * Документы длиннее этого лимита обрезаются.
     */
    @Setter
    private int docCharLimit;

    static final String OPERATOR_CONTAINS = "contains";
    static final String OPERATOR_NOT_CONTAINS = "not_contains";
    static final String OPERATOR_EQUALS = "equals";
    static final String OPERATOR_GREATER_THAN = "greater_than";
    static final String OPERATOR_LESS_THAN = "less_than";
    static final String OPERATOR_STARTSWITH = "startswith";

    protected final ScenarioRunNode node;

    protected String prompt;

    /**
     * Частичное состояние узла на момент сбоя (чекпойнт): агентские узлы
     * кладут сюда собранные наблюдения — движок сохраняет их в шаг, а
     * возобновление отдаёт агенту рабочим файлом, чтобы дорогой цикл
     * не начинался с нуля после обрыва сети.
     */
    protected String checkpoint;

    protected AbstractScenarioExecutor(ScenarioRunNode node) {
        this.node = node;
        prompt = "";
    }

    @SuppressWarnings("unused")
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        return null;
    }

    /**
     * Вычисляет множество узлов, которые следует пропустить при условном переходе.
     * <p>
     * Используется при выполнении Switch/If узлов для определения, какие узлы
     * недостижимы из-за ветвления.
     *
     * @param unchosenTargets невыбранные цели
     * @param chosenTargets   выбранные цели
     * @param successors      карта successor-узлов
     * @return множество узлов для пропуска
     */
    protected Set<String> getSkipSet(Set<String> unchosenTargets,
                                     Set<String> chosenTargets,
                                     Map<String, List<String>> successors) {
        Set<String> reachableFromChosen = new HashSet<>();
        for (String ct : chosenTargets) {
            reachableFromChosen.addAll(getAllDescendants(ct, successors));
        }

        Set<String> skip = new HashSet<>();
        for (String ut : unchosenTargets) {
            for (String n : getAllDescendants(ut, successors)) {
                if (!reachableFromChosen.contains(n)) {
                    skip.add(n);
                }
            }
        }
        return skip;
    }

    /**
     * Находит всех потомков узла в графе.
     * <p>
     * Использует DFS (глубинный поиск) для обхода графа.
     *
     * @param nodeId идентификатор узла
     * @param graph  граф в виде map(nodeId -> List&lt;successorIds&gt;)
     * @return множество всех потомков
     */
    private Set<String> getAllDescendants(String nodeId, Map<String, List<String>> graph) {
        Set<String> visited = new HashSet<>();
        Deque<String> stack = new ArrayDeque<>();
        stack.push(nodeId);
        while (!stack.isEmpty()) {
            String nid = stack.pop();
            if (visited.contains(nid)) {
                continue;
            }
            visited.add(nid);
            for (String neighbor : graph.getOrDefault(nid, List.of())) {
                stack.push(neighbor);
            }
        }
        return visited;
    }

    /**
     * Строит промпт для узла обработки.
     * <p>
     * Собирает контекст из документов, предыдущего вывода и RAG-фрагментов.
     * Ограничивает размер контекста по MAX_CONTEXT.
     *
     * @param documentsText текст документа
     * @param kbChunks      RAG-фрагменты из базы знаний
     * @param ragConfigured флаг, что RAG настроен
     * @return сформированный промпт
     */
    protected String buildPrompt(String input,
                                 String documentsText,
                                 List<String> kbChunks,
                                 boolean ragConfigured) {

        String promptTemplate = node.getPrompt();
        // Выражения {{output:Метка}} / {{json:Метка:путь}} дают адресный доступ к выходам
        // конкретных узлов. Если они используются, автоматический блок «Результаты
        // предыдущих шагов» не добавляется — контекстом управляет автор сценария.
        boolean hasExpressions = ExpressionResolver.hasExpressions(promptTemplate);
        if (hasExpressions) {
            promptTemplate = ExpressionResolver.resolve(promptTemplate, node.getGraph().getNodeMap());
        }

        List<String> contextParts = new ArrayList<>();

        if (!documentsText.isEmpty()) {
            String docText = documentsText;
            if (docText.length() > docCharLimit) {
                docText = docText.substring(0, docCharLimit) + "\n\n[... документы обрезаны ...]";
            }
            contextParts.add("Документы:\n" + docText);
        }

        if (!input.isEmpty() && !hasExpressions) {
            String prev = input;
            if (prev.length() > docCharLimit) {
                prev = prev.substring(0, docCharLimit) + "\n\n[... обрезано ...]";
            }
            contextParts.add("Результаты предыдущих шагов:\n" + prev);
        }

        if (kbChunks != null && !kbChunks.isEmpty()) {
            String joined = String.join("\n\n---\n\n", kbChunks);
            contextParts.add(
                    "Релевантные фрагменты из базы знаний (используй их для ответа):\n" + joined
            );
        } else if (ragConfigured) {
            contextParts.add(
                    "⚠️ БАЗА ЗНАНИЙ ПОДКЛЮЧЕНА, НО РЕЛЕВАНТНЫХ ФРАГМЕНТОВ НЕ НАЙДЕНО.\n" +
                            "В твоём ответе явно укажи: «В базе знаний не найдено релевантных " +
                            "данных для этого запроса». НЕ ВЫДУМЫВАЙ никакие исторические аналоги, " +
                            "средние значения, справочные данные или примеры — если их нет во " +
                            "входных данных, их НЕТ."
            );
        }

        String context = String.join("\n\n", contextParts);
        return context.isEmpty() ? promptTemplate : promptTemplate + "\n\n" + context;
    }

    protected List<String> prepareNextInput() {
        List<String> result = new ArrayList<>();
        var output = node.getOutput();
        var label = node.getLabel();
        if (output != null && !output.isEmpty()) {
            result.add("=== РЕЗУЛЬТАТ ОТ \"" + label + "\" ===\n" + String.join("\n\n", output));
        }
        return result;
    }
}
