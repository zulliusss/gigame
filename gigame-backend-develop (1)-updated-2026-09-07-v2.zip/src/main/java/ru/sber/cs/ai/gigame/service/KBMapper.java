package ru.sber.cs.ai.gigame.service;

import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;

public class KBMapper {
    private KBMapper() {
    }

    /**
     * Преобразует сущность KnowledgeBase в DTO для ответа клиенту.
     *
     * @param kb              сущность базы знаний
     * @param requesterUserId нормализованный идентификатор запрашивающего пользователя
     * @return DTO с метаданными базы знаний
     */
    static KBResponse toKBResponse(KnowledgeBase kb, String requesterUserId) {
        return new KBResponse(
                kb.getId(),
                kb.getName(),
                kb.getDescription(),
                kb.isShared(),
                requesterUserId.equals(kb.getUserId()),
                kb.getCreatedAt(),
                kb.getUpdatedAt()
        );
    }

    /**
     * Преобразует сущность KBDocument в DTO для ответа клиенту.
     *
     * @param kbDoc сущность документа базы знаний
     * @return DTO с метаданными документа базы знаний
     */
    static KBDocumentResponse toKBDocumentResponse(KBDocument kbDoc) {
        Document doc = kbDoc.getDocument();
        return new KBDocumentResponse(
                kbDoc.getId(),
                doc != null ? doc.getId() : kbDoc.getDocumentId(),
                kbDoc.getFilename(),
                doc != null ? doc.getContentType() : null,
                doc != null && doc.getSizeBytes() != null ? doc.getSizeBytes() : 0,
                kbDoc.getChunkCount() != null ? kbDoc.getChunkCount() : 0,
                kbDoc.getStatus(),
                kbDoc.getErrorMessage(),
                kbDoc.getCreatedAt()
        );
    }
}
