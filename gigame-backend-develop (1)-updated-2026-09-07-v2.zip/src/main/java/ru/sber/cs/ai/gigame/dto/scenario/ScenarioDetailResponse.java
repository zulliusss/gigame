package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO для подробного представления сценария.
 * Возвращает полную информацию о сценарии, включая граф выполнения.
 *
 * @param id          Уникальный идентификатор сценария
 * @param name        Название сценария
 * @param description Описание сценария
 * @param createdAt   Дата и время создания сценария
 * @param updatedAt   Дата и время последнего обновления
 * @param graphData   Данные графа выполнения в формате Map
 * @see ScenarioResponse
 * @see ScenarioCreate
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Полная информация о AI-сценарии (workflow) с графом выполнения",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioDetailResponse(
        @Schema(
                description = "Уникальный идентификатор сценария",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Название сценария",
                example = "Обработка заявок",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Описание сценария",
                example = "Автоматическая обработка входящих заявок",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String description,

        @Schema(
                description = "Дата и время создания сценария"
        )
        OffsetDateTime createdAt,

        @Schema(
                description = "Дата и время последнего обновления"
        )
        OffsetDateTime updatedAt,

        @Schema(
                description = "Данные графа выполнения в формате Map (JSON-структура)"
        )
        GraphDataDto graphData,

        @Schema(description = "Общий сценарий (виден всем пользователям)")
        Boolean shared
) {
    /** Совместимость с прежними вызовами без признака общего доступа. */
    public ScenarioDetailResponse(UUID id, String name, String description,
                                  OffsetDateTime createdAt, OffsetDateTime updatedAt,
                                  GraphDataDto graphData) {
        this(id, name, description, createdAt, updatedAt, graphData, false);
    }
}
