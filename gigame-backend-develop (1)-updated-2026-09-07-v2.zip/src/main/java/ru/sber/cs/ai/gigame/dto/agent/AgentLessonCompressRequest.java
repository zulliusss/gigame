package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.UUID;

/**
 * DTO для рефлексии-сжатия уроков сценария.
 * Используется в запросе {@code POST /api/agent/lessons/compress}.
 *
 * @param scenarioId Сценарий, уроки которого дистиллируются
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Запрос на сжатие уроков сценария",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentLessonCompressRequest(
        @Schema(
                description = "Идентификатор сценария (UUID)"
        )
        UUID scenarioId
) {
}
