package ru.sber.cs.ai.gigame.dto.agent;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для изменения текста урока агента.
 * Используется в запросе {@code PUT /api/agent/lessons/{id}}.
 *
 * @param lesson Новый текст урока
 */
@Schema(
        description = "Запрос на изменение текста урока агента",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentLessonUpdateRequest(
        @Schema(
                description = "Новый текст урока",
                maxLength = 4000
        )
        String lesson
) {
}
