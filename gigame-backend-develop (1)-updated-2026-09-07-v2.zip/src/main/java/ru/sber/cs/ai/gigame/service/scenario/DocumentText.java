package ru.sber.cs.ai.gigame.service.scenario;

/**
 * Документ, подготовленный к прогону сценария: имя и извлечённый текст.
 * <p>
 * Для файлов из ZIP-архива имя содержит имя архива и путь внутри него
 * ("архив.zip/папка/файл.pdf") — по нему работает группировка документов.
 */
public record DocumentText(String filename, String text) {
}
