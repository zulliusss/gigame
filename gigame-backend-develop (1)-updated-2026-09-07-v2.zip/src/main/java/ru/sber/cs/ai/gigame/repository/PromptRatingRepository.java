package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sber.cs.ai.gigame.model.PromptRating;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий оценок промптов.
 */
public interface PromptRatingRepository extends JpaRepository<PromptRating, PromptRating.Key> {

    /**
     * Все оценки перечисленных промптов (для расчёта средних по списку).
     *
     * @param promptIds идентификаторы промптов
     * @return оценки
     */
    List<PromptRating> findByPromptIdIn(List<UUID> promptIds);
}
