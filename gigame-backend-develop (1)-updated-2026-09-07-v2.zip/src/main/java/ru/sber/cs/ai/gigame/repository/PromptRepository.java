package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sber.cs.ai.gigame.model.Prompt;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий базы промптов.
 */
public interface PromptRepository extends JpaRepository<Prompt, UUID> {

    /**
     * Промпты, видимые пользователю: его собственные и все общие.
     *
     * @param userId идентификатор пользователя
     * @return промпты, новые сверху
     */
    List<Prompt> findByUserIdOrSharedTrueOrderByUpdatedAtDesc(String userId);
}
