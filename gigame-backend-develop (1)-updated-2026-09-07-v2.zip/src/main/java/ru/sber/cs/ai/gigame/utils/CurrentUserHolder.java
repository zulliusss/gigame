package ru.sber.cs.ai.gigame.utils;

import org.apache.commons.lang3.ObjectUtils;

import java.util.function.Supplier;

/**
 * Поток-локальный хранитель текущего пользователя.
 * <p>
 * Заполняется в граничных методах сервисов (из параметра {@code userId}),
 * а не в WebFilter-е, чтобы исключить влияние реактивного стека: синхронная
 * цепочка вызовов внутри одного сервисного метода выполняется на одном
 * потоке, поэтому хранилище надёжно видно всем последующим по цепочке
 * вызовам ({@link #getCurrentUser()}).
 *
 * @see #getCurrentUser()
 * @see #withUser(String, Supplier)
 */
public final class CurrentUserHolder {

    private static final ThreadLocal<String> CURRENT_USER = new ThreadLocal<>();

    private CurrentUserHolder() {
    }

    /**
     * Устанавливает текущий userId.
     *
     * @param userId идентификатор пользователя (null означает "аноним")
     */
    public static void setCurrentUser(String userId) {
        if (ObjectUtils.isEmpty(userId)) {
            CURRENT_USER.set("anonymous");
            return;
        }
        CURRENT_USER.set(userId);
    }

    /**
     * Выполняет тело с установленным текущим userId и гарантированно очищает
     * хранилище после завершения (в том числе по исключению).
     * <p>
     * Используется на границе синхронных сервисных методов: параметр
     * {@code userId} передаётся сервису, помещается в хранилище, а последующие
     * вызовы по цепочке читают его через {@link #getCurrentUser()}.
     *
     * @param userId идентификатор пользователя (может быть null)
     * @param action тело, выполняемое с установленным текущим пользователем
     * @param <T>    тип результата
     * @return результат выполнения {@code action}
     */
    public static <T> T withUser(String userId, Supplier<T> action) {
        if (ObjectUtils.isEmpty(userId)) {
            userId = "anonymous";
        }
        setCurrentUser(userId);
        try {
            return action.get();
        } finally {
            clear();
        }
    }

    /**
     * Возвращает текущий userId или {@code null} если не установлен.
     *
     * @return userId или null
     */
    public static String getCurrentUser() {
        return CURRENT_USER.get();
    }

    /**
     * Очищает ThreadLocal. Вызывать обязательно в конце обработки,
     * чтобы предотвратить утечку в пулах потоков.
     */
    public static void clear() {
        CURRENT_USER.remove();
    }
}