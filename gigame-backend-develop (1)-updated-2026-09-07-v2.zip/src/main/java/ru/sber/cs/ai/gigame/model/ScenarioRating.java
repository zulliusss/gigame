package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Оценка сценария пользователем (1..5). Одна оценка на пару
 * «сценарий + пользователь»; повторное голосование обновляет оценку.
 */
@Entity
@Table(name = "scenario_ratings")
@IdClass(ScenarioRating.Key.class)
@Getter
@Setter
@NoArgsConstructor
public class ScenarioRating {

    /** Составной ключ оценки: сценарий + пользователь. */
    @Getter
    @Setter
    @NoArgsConstructor
    public static class Key implements Serializable {
        private UUID scenarioId;
        private String userId;

        public Key(UUID scenarioId, String userId) {
            this.scenarioId = scenarioId;
            this.userId = userId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof Key key)) {
                return false;
            }
            return scenarioId.equals(key.scenarioId) && userId.equals(key.userId);
        }

        @Override
        public int hashCode() {
            return scenarioId.hashCode() * 31 + userId.hashCode();
        }
    }

    @Id
    @Column(name = "scenario_id")
    private UUID scenarioId;

    @Id
    @Column(name = "user_id")
    private String userId;

    /** Оценка от 1 до 5. */
    @Column(nullable = false)
    private Integer rating;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;
}
