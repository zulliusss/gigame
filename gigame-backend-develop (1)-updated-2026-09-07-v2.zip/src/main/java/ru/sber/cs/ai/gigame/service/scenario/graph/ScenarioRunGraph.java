package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Getter
public class ScenarioRunGraph {
    private final Map<String, ScenarioRunNode> nodeMap;
    private final Map<Pair<String, String>, EdgeDataDto> edgeMap = new HashMap<>();
    private final ScenarioRunNode startNode;
    private final Map<String, ScenarioRunDoc> docMap;
    private final Map<String, float[]> embeddingCache;
    /** Идентификаторы прогона — для памяти агента (уроки, вопросы). */
    @Setter
    private UUID runId;
    @Setter
    private UUID scenarioId;
    /** Запускающий пользователь — его личные общие уроки применяются к прогону. */
    @Setter
    private String runnerUserId;
    /** Запрошена остановка прогона: узлы и инструменты агента проверяют флаг. */
    private final AtomicBoolean cancelRequested = new AtomicBoolean();

    public ScenarioRunGraph(GraphDataDto graphData) {
        AtomicInteger idx = new AtomicInteger();
        this.nodeMap = graphData.nodes().stream()
                .collect(Collectors.toMap(
                        NodeDto::id,
                        node -> buildNode(idx.incrementAndGet(), node, this)));
        for (var edge : graphData.edges()) {
            String src = edge.source();
            String tgt = edge.target();
            nodeMap.get(src).getChildNodeList().add(nodeMap.get(tgt));
            nodeMap.get(tgt).getParentNodeList().add(nodeMap.get(src));
            var edgeData = edge.data();
            edgeMap.put(Pair.of(src, tgt), edgeData);
        }
        startNode = nodeMap.values().stream()
                .filter(node -> node.getParentNodeList().isEmpty())
                .findFirst().orElseThrow();
        docMap = new HashMap<>();
        embeddingCache = new HashMap<>();
    }

    /**
     * Индекс узла 1-базный: он показывается пользователю как «шаг N из M»
     * в событиях node_status.
     */
    private ScenarioRunNode buildNode(int index, NodeDto node, ScenarioRunGraph graph) {
        return ScenarioRunNode.fromDto(index, node, graph);
    }

    public void addDocs(List<String> documentTextList, List<String> filenameList) {
        if (documentTextList != null && !documentTextList.isEmpty()) {
            for (int i = 0; i < documentTextList.size(); i++) {
                docMap.put("DOC_" + (i + 1), new ScenarioRunDoc(filenameList.get(i), documentTextList.get(i)));
            }
        }
    }

    public boolean isCancelRequested() {
        return cancelRequested.get();
    }

    public void requestCancel() {
        cancelRequested.set(true);
    }

    /**
     * Сохраняет рабочий файл агента (write_file) в документы прогона:
     * последующие агент-узлы видят его инструментами. Повторная запись под
     * тем же именем обновляет файл; имя исходного документа занять нельзя.
     *
     * @param filename имя рабочего файла
     * @param text     содержимое
     * @return {@code null} при успехе, иначе текст ошибки
     */
    public synchronized String addWorkingDoc(String filename, String text) {
        for (var entry : docMap.entrySet()) {
            if (entry.getValue().getFilename().equals(filename)) {
                if (!entry.getValue().isWorkNote()) {
                    return "Имя занято исходным документом прогона — выбери другое.";
                }
                entry.setValue(new ScenarioRunDoc(filename, text, true));
                return null;
            }
        }
        docMap.put("WORK_" + (docMap.size() + 1), new ScenarioRunDoc(filename, text, true));
        return null;
    }
}
