package ru.sber.cs.ai.gigame.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;

/**
 * Утилитный класс для работы с идентификаторами пользователей.
 * <p>
 * Предоставляет методы для получения и проверки userId из HTTP-заголовков.
 * Поддерживает анонимные сессии (необязательный userId).
 *
 * @see ObjectUtils
 */
@Slf4j
public class UserUtils {
    private UserUtils() {
    }

    /**
     * Проверяет совпадение userId с ожидаемым значением.
     * Выбрасывает исключение, если userId не совпадают.
     *
     * @param userId       userId из HTTP-заголовка
     * @param actualUserId ожидаемый userId из сущности
     * @throws IllegalArgumentException если userId не совпадают
     */
    public static void checkUserId(String userId, String actualUserId) {
        String normalized = ObjectUtils.isEmpty(userId) ? "anonymous" : userId;
        if (!normalized.equals(actualUserId)) {
            throw new AccessDeniedException("illegal userId");
        }
    }
}
