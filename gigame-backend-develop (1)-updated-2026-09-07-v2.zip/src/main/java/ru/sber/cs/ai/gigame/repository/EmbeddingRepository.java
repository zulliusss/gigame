package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.Embedding;
import ru.sber.cs.ai.gigame.service.EmbeddingService;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с векторными эмбеддингами.
 * <p>
 * Предоставляет методы для поиска похожих фрагментов текста и управления эмбеддингами.
 * Использует pgvector для эффективного поиска по косинусному сходству.
 *
 * @see Embedding
 * @see EmbeddingService
 */
@Repository
public interface EmbeddingRepository extends JpaRepository<Embedding, UUID> {

    /**
     * Выполняет полнотекстовый поиск похожих фрагментов текста на основе векторного сходства.
     * <p>
     * Использует оператор {@code <=>} из pgvector для вычисления косинусного расстояния.
     *
     * @param type     тип коллекции ("doc" или "kb")
     * @param collId   идентификатор коллекции
     * @param queryVec запросный вектор (1024-мерный)
     * @param topK     количество результатов
     * @return список похожих текстовых фрагментов
     */
    @Query(value = "SELECT e.chunk_text FROM " +
            "{h-schema}embeddings e " +
            "WHERE e.collection_type = :type AND e.collection_id = :collId " +
            "ORDER BY e.embedding <=> CAST(:queryVec AS VECTOR) " +
            "LIMIT :topK",
            nativeQuery = true)
    List<String> searchSimilar(
            @Param("type") String type,
            @Param("collId") UUID collId,
            @Param("queryVec") float[] queryVec,
            @Param("topK") int topK
    );

    /**
     * Поиск похожих фрагментов с метаданными источника и расстоянием.
     * <p>
     * Возвращает строки [chunk_text, source_document_id, distance] — расстояние
     * нужно для честного слияния результатов из нескольких баз знаний.
     *
     * @param type     тип коллекции ("doc" или "kb")
     * @param collId   идентификатор коллекции
     * @param queryVec запросный вектор (1024-мерный)
     * @param topK     количество результатов
     * @return список Object[]{String chunkText, UUID sourceDocumentId, Double distance}
     */
    @Query(value = "SELECT e.chunk_text, e.source_document_id, " +
            "(e.embedding <=> CAST(:queryVec AS VECTOR)) AS distance FROM " +
            "{h-schema}embeddings e " +
            "WHERE e.collection_type = :type AND e.collection_id = :collId " +
            "ORDER BY e.embedding <=> CAST(:queryVec AS VECTOR) " +
            "LIMIT :topK",
            nativeQuery = true)
    List<Object[]> searchSimilarWithSource(
            @Param("type") String type,
            @Param("collId") UUID collId,
            @Param("queryVec") float[] queryVec,
            @Param("topK") int topK
    );

    /**
     * Лексический канал гибридного поиска: фрагменты, дословно содержащие
     * паттерн (номер, точный термин) — эмбеддинги такие совпадения размывают.
     *
     * @param type    тип коллекции ("doc" или "kb")
     * @param collId  идентификатор коллекции
     * @param pattern LIKE-паттерн (например, «%1808920%»)
     * @param topK    количество результатов
     * @return список Object[]{String chunkText, UUID sourceDocumentId}
     */
    @Query(value = "SELECT e.chunk_text, e.source_document_id FROM " +
            "{h-schema}embeddings e " +
            "WHERE e.collection_type = :type AND e.collection_id = :collId " +
            "AND lower(e.chunk_text) LIKE lower(:pattern) " +
            "LIMIT :topK",
            nativeQuery = true)
    List<Object[]> searchLexical(
            @Param("type") String type,
            @Param("collId") UUID collId,
            @Param("pattern") String pattern,
            @Param("topK") int topK);

    /**
     * Удаляет все эмбеддинги для указанной коллекции.
     *
     * @param type   тип коллекции ("doc" или "kb")
     * @param collId идентификатор коллекции
     */
    @Modifying
    @Query("DELETE FROM Embedding e WHERE e.collectionType = :type AND e.collectionId = :collId")
    void deleteByCollection(@Param("type") String type, @Param("collId") UUID collId);

    /**
     * Удаляет эмбеддинги конкретного документа из базы знаний.
     * Используется при удалении документа из KB.
     *
     * @param kbId  идентификатор базы знаний
     * @param docId идентификатор документа
     */
    @Modifying
    @Query("DELETE FROM Embedding e WHERE e.collectionType = 'kb' AND e.collectionId = :kbId AND e.sourceDocumentId = :docId")
    void deleteKBDocumentChunks(@Param("kbId") UUID kbId, @Param("docId") UUID docId);
}
