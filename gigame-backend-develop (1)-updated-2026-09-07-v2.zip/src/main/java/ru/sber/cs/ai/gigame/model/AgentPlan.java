package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Память планов агента: проверенный чек-лист для задания (Agent Workflow
 * Memory). Повтор того же задания переиспользует план вместо генерации —
 * дешевле и детерминированнее. Ключ — хэш нормализованного текста задания.
 */
@Entity
@Table(name = "agent_plans")
@Getter
@Setter
@NoArgsConstructor
public class AgentPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "scenario_id")
    private UUID scenarioId;

    /** SHA-256 нормализованного задания. */
    @Column(name = "task_hash", nullable = false, length = 64)
    private String taskHash;

    /** Начало задания — для страницы памяти. */
    @Column(name = "task_preview", columnDefinition = "TEXT")
    private String taskPreview;

    /** JSON-массив пунктов плана. */
    @Column(nullable = false, columnDefinition = "TEXT")
    private String plan;

    /** Сколько раз план переиспользован. */
    @Column(nullable = false)
    private Integer uses = 0;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;
}
