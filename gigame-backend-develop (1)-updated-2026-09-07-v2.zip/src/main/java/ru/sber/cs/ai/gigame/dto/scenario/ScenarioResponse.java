package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO для краткого представления сценария.
 * Возвращает основную информацию о сценарии без деталей графа выполнения.
 *
 * @param id          Уникальный идентификатор сценария
 * @param name        Название сценария
 * @param description Описание сценария
 * @param createdAt   Дата и время создания сценария
 * @param updatedAt   Дата и время последнего обновления
 * @see ScenarioDetailResponse
 * @see ScenarioCreate
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Краткая информация о AI-сценарии (workflow)",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioResponse(
        @Schema(
                description = "Уникальный идентификатор сценария",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Название сценария",
                example = "Обработка заявок",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Описание сценария",
                example = "Автоматическая обработка входящих заявок",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String description,

        @Schema(
                description = "Дата и время создания сценария"
        )
        OffsetDateTime createdAt,

        @Schema(
                description = "Дата и время последнего обновления"
        )
        OffsetDateTime updatedAt,

        @Schema(description = "Общий сценарий (виден всем пользователям)")
        Boolean shared,

        @Schema(description = "Текущий пользователь — владелец сценария")
        Boolean isOwner,

        @Schema(description = "Средний рейтинг сценария (1..5), null — оценок нет")
        Double ratingAvg,

        @Schema(description = "Количество оценок")
        Long ratingCount,

        @Schema(description = "Оценка текущего пользователя (1..5), null — не оценивал")
        Integer myRating,

        @Schema(description = "Количество запусков сценария")
        Long runsCount
) {
    /** Совместимость с прежними вызовами без статистики. */
    public ScenarioResponse(UUID id, String name, String description,
                            OffsetDateTime createdAt, OffsetDateTime updatedAt) {
        this(id, name, description, createdAt, updatedAt, false, true, null, 0L, null, 0L);
    }
}
