package ru.sber.cs.ai.gigame.dto.scenario;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для оценки сценария.
 * Используется в запросе {@code POST /api/scenarios/{id}/rating}.
 *
 * @param rating Оценка от 1 до 5
 * @see ScenarioResponse
 */
@Schema(
        description = "Запрос на оценку сценария",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioRateRequest(
        @Schema(
                description = "Оценка сценария от 1 до 5",
                example = "5",
                minimum = "1",
                maximum = "5"
        )
        Integer rating
) {
}
