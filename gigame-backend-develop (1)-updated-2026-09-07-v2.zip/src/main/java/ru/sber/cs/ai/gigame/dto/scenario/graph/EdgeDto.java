package ru.sber.cs.ai.gigame.dto.scenario.graph;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для ребра в графе.
 *
 * @param id     Уникальный идентификатор ребра
 * @param source Идентификатор исходного узла
 * @param target Идентификатор целевого узла
 * @param data   Опциональные данные ребра (например, метка)
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Ребро, соединяющее два узла в графе",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record EdgeDto(
        @Schema(
                description = "Уникальный идентификатор ребра",
                example = "e0",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String id,

        @Schema(
                description = "Идентификатор исходного узла",
                example = "node_0",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String source,

        @Schema(
                description = "Идентификатор целевого узла",
                example = "node_1",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String target,

        @Schema(
                description = "Опциональные данные ребра (например, метка)"
        )
        EdgeDataDto data
) {
}
