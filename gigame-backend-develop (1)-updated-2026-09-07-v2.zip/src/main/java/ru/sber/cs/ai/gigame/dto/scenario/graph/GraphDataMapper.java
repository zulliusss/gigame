package ru.sber.cs.ai.gigame.dto.scenario.graph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Маппер для преобразования Map&lt;String, Object&gt; в GraphDataDto и обратно.
 * Используется для конвертации данных графа из базы данных в DTO-представление и наоборот.
 */
public class GraphDataMapper {

    private GraphDataMapper() {
    }

    /**
     * Преобразует Map&lt;String, Object&gt; в GraphDataDto.
     *
     * @param graphData данные графа в формате Map (из базы данных)
     * @return GraphDataDto с узлами и рёбрами
     */
    @SuppressWarnings("unchecked")
    public static GraphDataDto toDto(Map<String, Object> graphData) {
        if (graphData == null) {
            return new GraphDataDto(List.of(), List.of());
        }
        List<NodeDto> nodes = mapNodes((List<Map<String, Object>>) graphData.getOrDefault("nodes", List.of()));
        List<EdgeDto> edges = mapEdges((List<Map<String, Object>>) graphData.getOrDefault("edges", List.of()));
        return new GraphDataDto(nodes, edges);
    }

    /**
     * Преобразует GraphDataDto в Map&lt;String, Object&gt;.
     *
     * @param graphData DTO для графа
     * @return данные графа в формате Map для сохранения в базу данных
     */
    public static Map<String, Object> fromDto(GraphDataDto graphData) {
        if (graphData == null) {
            return Map.of();
        }

        Map<String, Object> result = new HashMap<>();
        result.put("nodes", mapNodesFromDto(graphData.nodes()));
        result.put("edges", mapEdgesFromDto(graphData.edges()));

        return result;
    }

    /**
     * Преобразует список узлов из Map в List&lt;NodeDto&gt;.
     *
     * @param nodesRaw список узлов в формате Map
     * @return список NodeDto
     */
    private static List<NodeDto> mapNodes(List<Map<String, Object>> nodesRaw) {
        if (nodesRaw == null) {
            return List.of();
        }

        List<NodeDto> nodes = new ArrayList<>();
        for (Map<String, Object> node : nodesRaw) {
            nodes.add(mapNode(node));
        }
        return nodes;
    }

    /**
     * Преобразует один узел из Map в NodeDto.
     *
     * @param node узел в формате Map
     * @return NodeDto
     */
    @SuppressWarnings("unchecked")
    private static NodeDto mapNode(Map<String, Object> node) {
        if (node == null) {
            return null;
        }
        return NodeDto.builder()
                .id(getString(node, "id"))
                .type(getString(node, "type"))
                .data(mapNodeData((Map<String, Object>) node.getOrDefault("data", Map.of())))
                .position(mapPosition((Map<String, Object>) node.getOrDefault("position", Map.of())))
                .measured(mapMeasured((Map<String, Object>) node.getOrDefault("measured", Map.of())))
                .build();
    }

    /**
     * Преобразует данные узла из Map в NodeDataDto.
     *
     * @param data данные узла в формате Map
     * @return NodeDataDto
     */
    private static NodeDataDto mapNodeData(Map<String, Object> data) {
        if (data == null) {
            return NodeDataDto.builder().build();
        }
        return NodeDataDto.builder()
                .label(getString(data, "label"))
                .prompt(getString(data, "prompt"))
                .classes(getString(data, "classes"))
                .rules(getString(data, "rules"))
                .classifyStrict(getString(data, "classify_strict"))
                .mode(getString(data, "mode"))
                .field(getString(data, "field"))
                .operator(getString(data, "operator"))
                .value(getString(data, "value"))
                .knowledgeBaseId(getString(data, "knowledge_base_id"))
                .model(getString(data, "model"))
                .temperature(getString(data, "temperature"))
                .onError(getString(data, "on_error"))
                .build();

    }

    /**
     * Преобразует позицию узла из Map в PositionDto.
     *
     * @param position позиция в формате Map
     * @return PositionDto
     */
    private static PositionDto mapPosition(Map<String, Object> position) {
        if (position == null) {
            return new PositionDto(null, null);
        }
        Integer x = getInteger(position, "x");
        Integer y = getInteger(position, "y");
        return new PositionDto(x, y);
    }

    /**
     * Преобразует размер узла(блока) из Map в MeasuredDto.
     *
     * @param meausured размер узла(блока) в формате Map
     * @return MeasuredDto
     */
    private static MeasuredDto mapMeasured(Map<String, Object> meausured) {
        if (meausured == null) {
            return new MeasuredDto(null, null);
        }
        Integer height = getInteger(meausured, "height");
        Integer width = getInteger(meausured, "width");
        return new MeasuredDto(width, height);
    }

    /**
     * Преобразует список рёбер из Map в List&lt;EdgeDto&gt;.
     *
     * @param edgesRaw список рёбер в формате Map
     * @return список EdgeDto
     */
    private static List<EdgeDto> mapEdges(List<Map<String, Object>> edgesRaw) {
        if (edgesRaw == null) {
            return List.of();
        }
        List<EdgeDto> edges = new ArrayList<>();
        for (Map<String, Object> edge : edgesRaw) {
            edges.add(mapEdge(edge));
        }
        return edges;
    }

    /**
     * Преобразует одно ребро из Map в EdgeDto.
     *
     * @param edge ребро в формате Map
     * @return EdgeDto
     */
    @SuppressWarnings("unchecked")
    private static EdgeDto mapEdge(Map<String, Object> edge) {
        if (edge == null) {
            return null;
        }
        String id = getString(edge, "id");
        String source = getString(edge, "source");
        String target = getString(edge, "target");
        EdgeDataDto data = mapEdgeData((Map<String, Object>) edge.getOrDefault("data", Map.of()));
        return new EdgeDto(id, source, target, data);
    }

    /**
     * Преобразует данные ребра из Map в EdgeDataDto.
     *
     * @param data данные ребра в формате Map
     * @return EdgeDataDto
     */
    private static EdgeDataDto mapEdgeData(Map<String, Object> data) {
        if (data == null) {
            return new EdgeDataDto(null);
        }
        String label = getString(data, "label");
        return new EdgeDataDto(label);
    }

    // === Обратное преобразование: DTO -> Map ===

    /**
     * Преобразует список узлов из NodeDto в List&lt;Map&gt;.
     *
     * @param nodes список NodeDto
     * @return список узлов в формате Map
     */
    private static List<Map<String, Object>> mapNodesFromDto(List<NodeDto> nodes) {
        if (nodes == null) {
            return List.of();
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (NodeDto node : nodes) {
            result.add(mapNodeFromDto(node));
        }
        return result;
    }

    /**
     * Преобразует один узел из NodeDto в Map.
     *
     * @param node NodeDto
     * @return узел в формате Map
     */
    private static Map<String, Object> mapNodeFromDto(NodeDto node) {
        if (node == null) {
            return Map.of();
        }
        Map<String, Object> result = new HashMap<>();
        result.put("id", node.id());
        result.put("type", node.type());
        result.put("data", mapNodeDataFromDto(node.data()));
        result.put("position", mapPositionFromDto(node.position()));
        result.put("measured", mapMeasuredFromDto(node.measured()));

        return result;
    }

    /**
     * Преобразует данные узла из NodeDataDto в Map.
     *
     * @param data NodeDataDto
     * @return данные узла в формате Map
     */
    private static Map<String, Object> mapNodeDataFromDto(NodeDataDto data) {
        if (data == null) {
            return Map.of();
        }

        Map<String, Object> result = new HashMap<>();
        result.put("label", data.label());
        result.put("prompt", data.prompt());
        result.put("classes", data.classes());
        result.put("rules", data.rules());
        result.put("classify_strict", data.classifyStrict());
        result.put("mode", data.mode());
        result.put("field", data.field());
        result.put("operator", data.operator());
        result.put("value", data.value());
        result.put("knowledge_base_id", data.knowledgeBaseId());
        result.put("model", data.model());
        result.put("temperature", data.temperature());
        result.put("on_error", data.onError());

        return result;
    }

    /**
     * Преобразует позицию узла из PositionDto в Map.
     *
     * @param position PositionDto
     * @return позиция в формате Map
     */
    private static Map<String, Object> mapPositionFromDto(PositionDto position) {
        if (position == null) {
            return Map.of();
        }

        Map<String, Object> result = new HashMap<>();
        result.put("x", position.x());
        result.put("y", position.y());

        return result;
    }

    /**
     * Преобразует размеры узла из MeasuredDto в Map.
     *
     * @param measured MeasuredDto
     * @return позиция в формате Map
     */
    private static Map<String, Object> mapMeasuredFromDto(MeasuredDto measured) {
        if (measured == null) {
            return Map.of();
        }

        Map<String, Object> result = new HashMap<>();
        result.put("height", measured.height());
        result.put("width", measured.width());

        return result;
    }

    /**
     * Преобразует список рёбер из EdgeDto в List&lt;Map&gt;.
     *
     * @param edges список EdgeDto
     * @return список рёбер в формате Map
     */
    private static List<Map<String, Object>> mapEdgesFromDto(List<EdgeDto> edges) {
        if (edges == null) {
            return List.of();
        }

        List<Map<String, Object>> result = new ArrayList<>();
        for (EdgeDto edge : edges) {
            result.add(mapEdgeFromDto(edge));
        }
        return result;
    }

    /**
     * Преобразует одно ребро из EdgeDto в Map.
     *
     * @param edge EdgeDto
     * @return ребро в формате Map
     */
    private static Map<String, Object> mapEdgeFromDto(EdgeDto edge) {
        if (edge == null) {
            return Map.of();
        }
        Map<String, Object> result = new HashMap<>();
        result.put("id", edge.id());
        result.put("source", edge.source());
        result.put("target", edge.target());
        result.put("data", mapEdgeDataFromDto(edge.data()));

        return result;
    }

    /**
     * Преобразует данные ребра из EdgeDataDto в Map.
     *
     * @param data EdgeDataDto
     * @return данные ребра в формате Map
     */
    private static Map<String, Object> mapEdgeDataFromDto(EdgeDataDto data) {
        if (data == null) {
            return Map.of();
        }

        Map<String, Object> result = new HashMap<>();
        result.put("label", data.label());

        return result;
    }

    /**
     * Извлекает строковое значение из Map.
     *
     * @param map карта данных
     * @param key ключ
     * @return значение или null
     */
    private static String getString(Map<String, Object> map, String key) {
        Object value = map.get(key);
        return value != null ? value.toString() : null;
    }

    /**
     * Извлекает целочисленное значение из Map.
     *
     * @param map карта данных
     * @param key ключ
     * @return значение или null
     */
    private static Integer getInteger(Map<String, Object> map, String key) {
        if (map.get(key) instanceof Integer integerValue) {
            return integerValue;
        }
        if (map.get(key) instanceof Number numberValue) {
            return numberValue.intValue();
        }
        return null;
    }

}
