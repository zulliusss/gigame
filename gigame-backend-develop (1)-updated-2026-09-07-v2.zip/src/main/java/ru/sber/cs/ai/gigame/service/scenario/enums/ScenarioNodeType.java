package ru.sber.cs.ai.gigame.service.scenario.enums;

import lombok.Getter;

import java.util.Objects;

@Getter
public enum ScenarioNodeType {
    PROCESSING_NODE("processing"),
    IF_NODE("if_node"),
    SWITCH_NODE("switch"),
    LOOP_NODE("loop"),
    INPUT_NODE("input"),
    OUTPUT_NODE("output"),
    CALC_NODE("calc"),
    AGGREGATE_NODE("aggregate"),
    TRANSFORM_NODE("transform"),
    SUBSCENARIO_NODE("subscenario"),
    CONTROL_NODE("control"),
    WAIT_NODE("wait"),
    /** Заметка на канве: аннотация для людей, в выполнении не участвует. */
    NOTE_NODE("note"),
    UNKNOWN("unknown");

    private final String nodeType;

    ScenarioNodeType(String nodeType) {
        this.nodeType = nodeType;
    }

    public static ScenarioNodeType valueOfNodeType(String nodeType) {
        for (ScenarioNodeType e : values()) {
            if (Objects.equals(e.nodeType, nodeType)) {
                return e;
            }
        }
        return ScenarioNodeType.UNKNOWN;
    }

    @Override
    public String toString() {
        return nodeType;
    }
}
