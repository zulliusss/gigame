package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.model.AgentLesson;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO урока агента для ответов.
 * Используется во всех GET/POST/PUT endpoints контроллера {@code /api/agent/lessons}.
 *
 * @param id          идентификатор урока
 * @param scenarioId  сценарий-владелец; null — общий урок
 * @param userId      автор урока
 * @param lesson      текст правила
 * @param source      источник: user | reviser | auto | system
 * @param approved    общие уроки применяются только после одобрения
 * @param createdAt   дата создания
 * @param updatedAt   дата последнего обновления
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Урок агента",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentLessonResponseDto(
        @Schema(description = "Идентификатор урока")
        UUID id,

        @Schema(
                description = "Идентификатор сценария; null — общий урок",
                pattern = "^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})?$"
        )
        UUID scenarioId,

        @Schema(description = "Автор урока (ID пользователя)")
        String userId,

        @Schema(
                description = "Текст урока",
                maxLength = 4000
        )
        String lesson,

        @Schema(
                description = "Источник урока",
                pattern = "^(user|reviser|auto|system)$"
        )
        String source,

        @Schema(description = "Одобрен ли общий урок для применения")
        Boolean approved,

        @Schema(description = "Дата создания")
        OffsetDateTime createdAt,

        @Schema(description = "Дата последнего обновления")
        OffsetDateTime updatedAt
) {

    /**
     * Преобразует сущность {@link AgentLesson} в DTO.
     */
    public static AgentLessonResponseDto from(AgentLesson entity) {
        return new AgentLessonResponseDto(
                entity.getId(),
                entity.getScenarioId(),
                entity.getUserId(),
                entity.getLesson(),
                entity.getSource(),
                entity.getApproved(),
                entity.getCreatedAt(),
                entity.getUpdatedAt()
        );
    }
}
