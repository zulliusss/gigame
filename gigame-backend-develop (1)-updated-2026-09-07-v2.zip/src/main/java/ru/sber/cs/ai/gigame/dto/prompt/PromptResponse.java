package ru.sber.cs.ai.gigame.dto.prompt;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO промпта из базы промптов со статистикой использования.
 *
 * @param id          идентификатор промпта
 * @param title       короткое название
 * @param description для какой задачи промпт
 * @param text        текст промпта
 * @param shared      общий промпт (виден всем)
 * @param isOwner     текущий пользователь — владелец
 * @param usageCount  сколько раз промпт брали в работу
 * @param ratingAvg   средний рейтинг (1..5), null — оценок нет
 * @param ratingCount количество оценок
 * @param myRating    оценка текущего пользователя, null — не оценивал
 * @param updatedAt   дата последнего обновления
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(description = "Промпт из базы промптов со статистикой",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public record PromptResponse(
        @Schema(description = "Идентификатор промпта")
        UUID id,
        @Schema(description = "Короткое название", pattern = "^[\\w\\W]{0,255}$")
        String title,
        @Schema(description = "Для какой задачи промпт", pattern = "^[\\w\\W]{0,4096}$")
        String description,
        @Schema(description = "Текст промпта", pattern = "^[\\w\\W]{0,65536}$")
        String text,
        @Schema(description = "Модель GigaChat, на которой промпт проверен (пусто — любая)",
                pattern = "^[\\w\\W]{0,64}$")
        String model,
        @Schema(description = "Общий промпт (виден всем пользователям)")
        Boolean shared,
        @Schema(description = "Текущий пользователь — владелец")
        Boolean isOwner,
        @Schema(description = "Сколько раз промпт использовали")
        Integer usageCount,
        @Schema(description = "Средний рейтинг (1..5), null — оценок нет")
        Double ratingAvg,
        @Schema(description = "Количество оценок")
        Long ratingCount,
        @Schema(description = "Оценка текущего пользователя, null — не оценивал")
        Integer myRating,
        @Schema(description = "Дата последнего обновления")
        OffsetDateTime updatedAt
) {
}
