package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

@Component
public class ScenarioExecutorFactory {

    private final GigaChatClient gigaChatClient;
    private final EmbeddingService embeddingService;
    /**
     * Ленивая ссылка на движок (для узла «Под-сценарий»):
     * прямая инъекция невозможна — движок сам использует фабрику.
     */
    private final ObjectProvider<ScenarioEngine> engineProvider;
    @Value("${app.embedding.text-max-length:800}")
    private int ragQueryMaxLength;
    @Value("${app.processing-node.cache-short-query-length:200}")
    private int cacheShortQueryLength;
    @Value("${app.loop-node.delay-between-iterations:1000}")
    private int delayBetweenIterations;
    @Value("${app.loop-node.classify-head-chars:5000}")
    private int classifyHeadChars;
    @Value("${app.loop-node.classify-tail-chars:2000}")
    private int classifyTailChars;
    @Value("${app.chat.document-char-limit:200000}")
    private int docCharLimit;
    /**
     * Параллельность LLM-вызовов групп в processing-узле режима group
     * (env {@code SCENARIO_GROUP_PARALLELISM}). 1 — последовательно (как раньше);
     * при больших наборах (100+ групп) ускоряет прогон кратно значению,
     * ограничение — квоты одновременных запросов GigaChat.
     */
    @Value("${app.scenario.group-parallelism:1}")
    private int groupParallelism;

    /** Память агента (уроки/планы/вопросы); может отсутствовать в тестах. */
    private final ObjectProvider<AgentMemoryService> agentMemoryProvider;

    public ScenarioExecutorFactory(GigaChatClient gigaChatClient,
                                   EmbeddingService embeddingService,
                                   ObjectProvider<ScenarioEngine> engineProvider,
                                   ObjectProvider<AgentMemoryService> agentMemoryProvider) {
        this.gigaChatClient = gigaChatClient;
        this.embeddingService = embeddingService;
        this.engineProvider = engineProvider;
        this.agentMemoryProvider = agentMemoryProvider;
    }

    public AbstractScenarioExecutor createExecutor(ScenarioRunNode node) {
        return switch (node.getType()) {
            case INPUT_NODE -> new ScenarioExecutorInputNode(node);
            case OUTPUT_NODE -> new ScenarioExecutorOutputNode(node);
            case PROCESSING_NODE -> {
                var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
                executor.setConfiguration(ragQueryMaxLength, cacheShortQueryLength);
                executor.setDocCharLimit(docCharLimit);
                executor.setGroupParallelism(groupParallelism);
                executor.setAgentMemory(agentMemoryProvider != null
                        ? agentMemoryProvider.getIfAvailable() : null);
                yield executor;
            }
            case IF_NODE -> new ScenarioExecutorIfNode(node);
            case SWITCH_NODE -> new ScenarioExecutorSwitchNode(node);
            case CALC_NODE -> new ScenarioExecutorCalcNode(node);
            case AGGREGATE_NODE -> new ScenarioExecutorAggregateNode(node);
            case TRANSFORM_NODE -> new ScenarioExecutorTransformNode(node);
            case SUBSCENARIO_NODE -> new ScenarioExecutorSubscenarioNode(node, engineProvider.getObject());
            case CONTROL_NODE -> new ScenarioExecutorControlNode(node);
            case WAIT_NODE -> new ScenarioExecutorWaitNode(node);
            case LOOP_NODE -> {
                var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);
                executor.setDelayBetweenIterations(delayBetweenIterations);
                executor.setClassifyLimits(classifyHeadChars, classifyTailChars);
                executor.setDocCharLimit(docCharLimit);
                yield executor;
            }
            // Добавьте другие типы по мере необходимости
            default -> throw new IllegalArgumentException("Unknown node type: " + node.getType());
        };
    }
}