package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Промпт из базы промптов: проверенные формулировки, которые надёжно
 * решают задачу. Общие промпты видны всем пользователям; счётчик
 * использований и оценки помогают находить лучшие.
 */
@Entity
@Table(name = "prompts")
@Getter
@Setter
@NoArgsConstructor
public class Prompt {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /** Владелец промпта (изменение и удаление — только владельцу). */
    @Column(name = "user_id")
    private String userId;

    /** Короткое название («Извлечение сумм из УПД»). */
    @Column(nullable = false)
    private String title;

    /** Для какой задачи промпт и в чём его особенности. */
    @Column(columnDefinition = "TEXT")
    private String description;

    /** Сам текст промпта. */
    @Column(columnDefinition = "TEXT", nullable = false)
    private String text;

    /** Модель GigaChat, на которой промпт проверен (пусто — любая). */
    @Column(name = "model", length = 64)
    private String model;

    /** Общий промпт виден всем пользователям (по умолчанию — да). */
    @Column(nullable = false)
    private Boolean shared = true;

    /** Сколько раз промпт брали в работу (кнопка «использовать»). */
    @Column(name = "usage_count", nullable = false)
    private Integer usageCount = 0;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;
}
