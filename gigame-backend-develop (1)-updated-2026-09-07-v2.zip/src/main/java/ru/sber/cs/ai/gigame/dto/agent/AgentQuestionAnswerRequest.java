package ru.sber.cs.ai.gigame.dto.agent;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для ответа пользователя на вопрос агента.
 * Используется в запросе {@code POST /api/agent/questions/{id}/answer}.
 *
 * @param answer Текст ответа
 */
@Schema(
        description = "Ответ пользователя на вопрос агента",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentQuestionAnswerRequest(
        @Schema(
                description = "Текст ответа",
                maxLength = 4000
        )
        String answer
) {
}
