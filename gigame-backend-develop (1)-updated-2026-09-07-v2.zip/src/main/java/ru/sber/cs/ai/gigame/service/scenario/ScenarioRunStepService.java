package ru.sber.cs.ai.gigame.service.scenario;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
@Slf4j
public class ScenarioRunStepService {

    static final String KEY_DOCUMENTS_TEXT = "documents_text";
    static final String KEY_PREVIOUS_OUTPUT = "previous_output";
    static final String KEY_RESULT = "result";
    static final String KEY_ERROR = "error";
    /** Имена файлов документов прогона (шаг входного узла) — для возобновления. */
    static final String KEY_DOC_NAMES = "doc_names";

    private static final String MSG_UNKNOWN_ERROR = "Неизвестная ошибка";

    private final ScenarioRunStepRepository stepRepository;

    public ScenarioRunStepService(ScenarioRunStepRepository stepRepository) {
        this.stepRepository = stepRepository;
    }

    public ScenarioRunStep setScenarioStepStatusRunning(UUID runId, String nodeId, ScenarioNodeType nodeType) {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId(nodeId);
        step.setNodeType(nodeType.toString());
        step.setStatus(ScenarioStatus.RUNNING.getValue());
        step.setStartedAt(OffsetDateTime.now());
        return stepRepository.save(step);
    }

    public ScenarioRunStep setScenarioStepStatusCompleted(ScenarioRunStep step,
                                                          String previousOutput,
                                                          String documentsText,
                                                          String output,
                                                          String prompt) {
        return setScenarioStepStatusCompleted(step, previousOutput, documentsText, output, prompt, null);
    }

    public ScenarioRunStep setScenarioStepStatusCompleted(ScenarioRunStep step,
                                                          String previousOutput,
                                                          String documentsText,
                                                          String output,
                                                          String prompt,
                                                          Integer tokensUsed) {
        step.setStatus(ScenarioStatus.COMPLETED.getValue());
        step.setInputData(Map.of(
                KEY_DOCUMENTS_TEXT, documentsText,
                KEY_PREVIOUS_OUTPUT, previousOutput));
        step.setOutputData(Map.of(KEY_RESULT, output));
        step.setPromptUsed(prompt);
        step.setTokensUsed(tokensUsed);
        step.setCompletedAt(OffsetDateTime.now());
        return stepRepository.save(step);
    }

    /**
     * Копирует завершённый шаг старого прогона в новый (возобновлённый) прогон,
     * чтобы цепочка повторных возобновлений видела восстановленные LLM-узлы.
     */
    public ScenarioRunStep copyStepToRun(UUID newRunId, ScenarioRunStep oldStep) {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(newRunId);
        step.setNodeId(oldStep.getNodeId());
        step.setNodeType(oldStep.getNodeType());
        step.setStatus(ScenarioStatus.COMPLETED.getValue());
        step.setInputData(oldStep.getInputData());
        step.setOutputData(oldStep.getOutputData());
        step.setPromptUsed(oldStep.getPromptUsed());
        step.setTokensUsed(oldStep.getTokensUsed());
        step.setStartedAt(OffsetDateTime.now());
        step.setCompletedAt(OffsetDateTime.now());
        return stepRepository.save(step);
    }

    /**
     * Дописывает ключ в выходные данные сохранённого шага (Map.of неизменяем).
     *
     * @param step  шаг прогона
     * @param key   ключ выходных данных
     * @param value значение
     * @return обновлённый шаг
     */
    public ScenarioRunStep appendOutputData(ScenarioRunStep step, String key, String value) {
        var data = new HashMap<>(
                step.getOutputData() != null ? step.getOutputData() : Map.of());
        data.put(key, value);
        step.setOutputData(data);
        return stepRepository.save(step);
    }

    public ScenarioRunStep setScenarioStepStatusFailed(ScenarioRunStep step,
                                                       String messageText) {
        step.setStatus(ScenarioStatus.FAILED.getValue());
        step.setOutputData(Map.of(KEY_ERROR, messageText != null ? messageText : MSG_UNKNOWN_ERROR));
        step.setCompletedAt(OffsetDateTime.now());
        return stepRepository.save(step);
    }
}
