package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.MessageRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class MessageService {
    private final MessageRepository messageRepository;

    private final MessageService self;

    public MessageService(
            @Lazy MessageService self,
            MessageRepository messageRepository) {
        this.self = self;
        this.messageRepository = messageRepository;
    }

    /**
     * Сохраняет сообщение ассистента в базе данных.
     *
     * @param conversation диалог
     * @param content      текст ответа ассистента
     */
    @Transactional
    protected void saveAssistantMessage(Conversation conversation, String content) {
        self.saveAssistantMessage(conversation, content, null);
    }

    /**
     * Сохраняет сообщение ассистента с источниками RAG.
     *
     * @param conversation диалог
     * @param content      текст ответа ассистента
     * @param sources      источники RAG {document_id, document_name, snippet} или {@code null}
     */
    @Transactional
    public void saveAssistantMessage(Conversation conversation, String content,
                                     List<Map<String, String>> sources) {
        log.debug("[{}] saveAssistantMessage, conversationId={}, chars={}, sources={}",
                CurrentUserHolder.getCurrentUser(), conversation.getId(),
                content == null ? 0 : content.length(), sources == null ? 0 : sources.size());
        Message assistantMessage = new Message();
        assistantMessage.setConversation(conversation);
        assistantMessage.setRole("assistant");
        assistantMessage.setContent(content);
        if (sources != null && !sources.isEmpty()) {
            assistantMessage.setSources(sources);
        }
        messageRepository.save(assistantMessage);
    }
}
