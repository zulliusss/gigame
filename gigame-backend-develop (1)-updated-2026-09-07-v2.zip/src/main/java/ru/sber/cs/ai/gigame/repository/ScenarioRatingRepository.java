package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sber.cs.ai.gigame.model.ScenarioRating;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий оценок сценариев.
 */
public interface ScenarioRatingRepository extends JpaRepository<ScenarioRating, ScenarioRating.Key> {

    /**
     * Все оценки перечисленных сценариев (для расчёта средних по списку).
     *
     * @param scenarioIds идентификаторы сценариев
     * @return оценки
     */
    List<ScenarioRating> findByScenarioIdIn(List<UUID> scenarioIds);
}
