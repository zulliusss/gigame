package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sber.cs.ai.gigame.model.AgentQuestion;

import java.util.List;
import java.util.UUID;

public interface AgentQuestionRepository extends JpaRepository<AgentQuestion, UUID> {

    List<AgentQuestion> findByRunIdOrderByCreatedAtAsc(UUID runId);

    List<AgentQuestion> findByScenarioIdAndAnsweredAtIsNullOrderByCreatedAtDesc(UUID scenarioId);
}
