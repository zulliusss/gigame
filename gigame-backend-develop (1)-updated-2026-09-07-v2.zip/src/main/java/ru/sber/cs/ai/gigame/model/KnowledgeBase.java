package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Сущность базы знаний (Knowledge Base).
 * <p>
 * Базы знаний позволяют создавать постоянные коллекции документов,
 * которые используются для RAG-поиска при обработке запросов пользователей.
 *
 * @see KBDocument
 * @see Conversation
 */
@Entity
@Table(name = "knowledge_bases")

@Getter
@Setter
@NoArgsConstructor
public class KnowledgeBase {

    /**
     * Уникальный идентификатор базы знаний (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Название базы знаний.
     */
    @Column(nullable = false)
    private String name;

    /**
     * Описание базы знаний.
     */
    @Column(columnDefinition = "TEXT")
    private String description;

    /**
     * Идентификатор пользователя, создавшего KB.
     * Используется для изоляции данных между пользователями.
     */
    @Column(name = "user_id")
    private String userId;

    /**
     * Признак общей базы знаний: общая база видна всем пользователям
     * (только для чтения и RAG-поиска), изменять её может только владелец.
     */
    @Column(name = "shared", nullable = false)
    private boolean shared = false;

    /**
     * Дата и время создания KB (автоматически устанавливается).
     */
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    /**
     * Дата и время последнего обновления (автоматически обновляется).
     */
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;

    /**
     * Список документов, входящих в базу знаний.
     * Удаление KB приводит к каскадному удалению связанных KBDocument.
     */
    @OneToMany(mappedBy = "knowledgeBase", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<KBDocument> documents = new ArrayList<>();
}
