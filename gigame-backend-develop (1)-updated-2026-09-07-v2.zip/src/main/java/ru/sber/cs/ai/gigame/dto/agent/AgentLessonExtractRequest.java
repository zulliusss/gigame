package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.UUID;

/**
 * DTO для извлечения кандидатов-уроков из прогона.
 * Используется в запросе {@code POST /api/agent/lessons/extract}.
 *
 * @param runId Прогон, из шагов которого извлекаются уроки
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Запрос на извлечение уроков из прогона",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentLessonExtractRequest(
        @Schema(
                description = "Идентификатор прогона (UUID)"
        )
        UUID runId
) {
}
