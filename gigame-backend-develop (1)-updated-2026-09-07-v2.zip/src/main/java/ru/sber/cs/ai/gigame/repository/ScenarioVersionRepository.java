package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sber.cs.ai.gigame.model.ScenarioVersion;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ScenarioVersionRepository extends JpaRepository<ScenarioVersion, UUID> {

    List<ScenarioVersion> findByScenarioIdOrderByVersionNoDesc(UUID scenarioId);

    Optional<ScenarioVersion> findByScenarioIdAndVersionNo(UUID scenarioId, Integer versionNo);

    Optional<ScenarioVersion> findFirstByScenarioIdOrderByVersionNoDesc(UUID scenarioId);
}
