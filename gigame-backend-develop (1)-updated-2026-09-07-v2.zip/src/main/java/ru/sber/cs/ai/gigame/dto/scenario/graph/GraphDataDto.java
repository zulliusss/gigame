package ru.sber.cs.ai.gigame.dto.scenario.graph;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Size;

import java.util.List;

/**
 * DTO для данных графа, содержащих узлы и рёбра.
 *
 * @param nodes Список узлов в графе
 * @param edges Список рёбер, соединяющих узлы
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Данные графа, содержащие узлы и рёбра для выполнения сценария",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record GraphDataDto(
        @Schema(
                description = "Список узлов в графе"
        )
        @Size(max = 1000)
        List<NodeDto> nodes,

        @Schema(
                description = "Список рёбер, соединяющих узлы"
        )
        @Size(max = 1000)
        List<EdgeDto> edges
) {
}
