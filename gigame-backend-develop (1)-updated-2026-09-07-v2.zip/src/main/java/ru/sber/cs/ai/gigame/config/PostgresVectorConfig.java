package ru.sber.cs.ai.gigame.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * Конфигурация PostgreSQL с расширением pgvector.
 * <p>
 * Hibernate 6.5+ поддерживает pgvector "из коробки" через:
 * <ul>
 *   <li>Аннотацию {@code @JdbcTypeCode(SqlTypes.VECTOR)} для полей типа {@code float[]}</li>
 *   <li>Автоматическое преобразование между {@code float[]} и PostgreSQL типом vector</li>
 * </ul>
 * <p>
 * Используется для хранения и поиска векторных эмбеддингов (1024-мерных векторов).
 *
 * @see EnableJpaAuditing
 */
@Configuration
@EnableJpaAuditing
public class PostgresVectorConfig {

    // Нет определений бинов - Hibernate обрабатывает векторные типы автоматически
}
