package ru.sber.cs.ai.gigame.dto.agent;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для добавления урока агента.
 * Используется в запросе {@code POST /api/agent/lessons}.
 *
 * @param scenarioId Сценарий урока; пусто или null — общий урок
 * @param lesson     Текст урока
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Запрос на добавление урока агента",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record AgentLessonCreateRequest(
        @Schema(
                description = "Идентификатор сценария (UUID); пусто — общий урок",
                pattern = "^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})?$"
        )
        String scenarioId,

        @Schema(
                description = "Текст урока",
                maxLength = 4000
        )
        String lesson
) {
}
