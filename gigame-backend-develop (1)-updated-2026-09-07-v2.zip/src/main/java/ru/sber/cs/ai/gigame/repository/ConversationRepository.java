package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.Conversation;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с диалогами.
 * <p>
 * Предоставляет методы для создания, чтения, обновления и удаления диалогов,
 * а также поиска по пользователю и заголовку.
 *
 * @see Conversation
 */
@Repository
public interface ConversationRepository extends JpaRepository<Conversation, UUID> {

    /**
     * Возвращает все диалоги пользователя, отсортированные по дате последнего обновления (новые первыми).
     *
     * @param userId идентификатор пользователя
     * @return список диалогов пользователя
     */
    List<Conversation> findByUserIdOrderByUpdatedAtDesc(String userId);

    /**
     * Возвращает диалоги пользователя, заголовки которых содержат указанный поисковый запрос,
     * отсортированные по дате обновления (регистронезависимый поиск).
     *
     * @param userId идентификатор пользователя
     * @param search поисковый запрос в заголовке диалога
     * @return список соответствующих диалогов
     */
    List<Conversation> findByUserIdAndTitleContainingIgnoreCaseOrderByUpdatedAtDesc(String userId, String search);

    /**
     * Ищет диалоги пользователя по заголовку ИЛИ по содержимому сообщений
     * (регистронезависимо), отсортированные по дате обновления.
     *
     * @param userId идентификатор пользователя
     * @param search поисковый запрос
     * @return список соответствующих диалогов
     */
    @Query("""
            SELECT DISTINCT c FROM Conversation c
            LEFT JOIN c.messages m
            WHERE c.userId = :userId
              AND (LOWER(c.title) LIKE LOWER(CONCAT('%', :search, '%'))
                   OR LOWER(m.content) LIKE LOWER(CONCAT('%', :search, '%')))
            ORDER BY c.updatedAt DESC
            """)
    List<Conversation> searchByTitleOrMessageContent(@Param("userId") String userId,
                                                     @Param("search") String search);
}
