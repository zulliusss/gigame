package ru.sber.cs.ai.gigame.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.handler.SimpleUrlHandlerMapping;
import org.springframework.web.reactive.socket.WebSocketHandler;
import ru.sber.cs.ai.gigame.ws.ChatWebSocketHandler;
import ru.sber.cs.ai.gigame.ws.ScenarioWebSocketHandler;

import java.util.HashMap;
import java.util.Map;

/**
 * Конфигурация WebSocket для потоковой передачи данных в реальном времени.
 * <p>
 * Использует WebFlux WebSocket (Reactor Netty) для доставки сообщений
 * между сервером и клиентом (чат и сценарии).
 * <p>
 * Доступные эндпоинты:
 * <ul>
 *   <li>/ws/chat — для чат-интерфейса</li>
 *   <li>/ws/scenario — для выполнения сценариев</li>
 * </ul>
 *
 * @see WebSocketHandler
 */
@Configuration
@RequiredArgsConstructor
public class WebSocketConfig {

    private final ChatWebSocketHandler chatWebSocketHandler;
    private final ScenarioWebSocketHandler scenarioWebSocketHandler;

    /**
     * Конфигурация WebSocket handler mapping.
     * Spring Boot автоматически создает WebSocketHandlerAdapter при наличии
     * WebSocketHandler beans в контексте.
     */
    @Bean
    public SimpleUrlHandlerMapping webSocketHandlerMapping() {
        Map<String, WebSocketHandler> urlMap = new HashMap<>();
        urlMap.put("/ws/chat", chatWebSocketHandler);
        urlMap.put("/ws/scenario", scenarioWebSocketHandler);

        SimpleUrlHandlerMapping mapping = new SimpleUrlHandlerMapping();
        mapping.setUrlMap(urlMap);
        mapping.setOrder(10);
        return mapping;
    }
}
