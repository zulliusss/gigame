package ru.sber.cs.ai.gigame.dto.prompt;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для оценки промпта.
 * Используется в запросе {@code POST /api/prompts/{id}/rating}.
 *
 * @param rating Оценка от 1 до 5
 * @see PromptResponse
 */
@Schema(
        description = "Запрос на оценку промпта",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record PromptRateRequest(
        @Schema(
                description = "Оценка промпта от 1 до 5",
                example = "5",
                minimum = "1",
                maximum = "5"
        )
        Integer rating
) {
}
