package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sber.cs.ai.gigame.model.AgentPlan;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface AgentPlanRepository extends JpaRepository<AgentPlan, UUID> {

    Optional<AgentPlan> findFirstByTaskHashOrderByUsesDesc(String taskHash);

    List<AgentPlan> findByScenarioIdOrderByUpdatedAtDesc(UUID scenarioId);
}
