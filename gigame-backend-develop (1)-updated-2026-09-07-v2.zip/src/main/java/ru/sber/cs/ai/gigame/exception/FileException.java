package ru.sber.cs.ai.gigame.exception;

/**
 * Исключение, выбрасываемое при ошибках обработки файлов.
 */
public class FileException extends ApplicationRuntimeException {

    public FileException(String message) {
        super(message, 422);
    }

    public FileException(String message, Throwable cause) {
        super(message, cause, 422);
    }
}
