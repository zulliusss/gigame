package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.Getter;
import lombok.Setter;

@Getter
public class ScenarioRunDoc {
    private final String filename;
    private final String text;
    /**
     * Рабочий файл, записанный агентом (write_file): виден последующим
     * агент-узлам, но НЕ является источником для цитатной валидации —
     * иначе агент подтверждал бы значения цитатами из собственного конспекта.
     */
    private final boolean workNote;
    @Setter
    private String docClass;

    public ScenarioRunDoc(String filename, String text) {
        this(filename, text, false);
    }

    public ScenarioRunDoc(String filename, String text, boolean workNote) {
        this.filename = filename;
        this.text = text;
        this.workNote = workNote;
    }
}
