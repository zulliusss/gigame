package ru.sber.cs.ai.gigame.dto.document;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO для просмотра документа: метаданные и извлечённый текст.
 * Используется для перехода к источнику из ответов ассистента (RAG).
 *
 * @param id            Уникальный идентификатор документа
 * @param filename      Имя файла
 * @param contentType   Тип контента ("pdf", "docx", "xlsx", ...)
 * @param sizeBytes     Размер файла в байтах
 * @param extractedText Извлечённый текст документа
 * @param createdAt     Дата и время загрузки
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Документ с извлечённым текстом для просмотра источника",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record DocumentViewResponse(
        @Schema(
                description = "Уникальный идентификатор документа",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Имя файла",
                example = "договор.pdf",
                pattern = "^[\\w\\W]{0,500}$"
        )
        String filename,

        @Schema(
                description = "Тип контента",
                example = "pdf",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String contentType,

        @Schema(
                description = "Размер файла в байтах",
                example = "10240"
        )
        Integer sizeBytes,

        @Schema(
                description = "Извлечённый текст документа"
        )
        String extractedText,

        @Schema(
                description = "Дата и время загрузки документа"
        )
        OffsetDateTime createdAt
) {
}
