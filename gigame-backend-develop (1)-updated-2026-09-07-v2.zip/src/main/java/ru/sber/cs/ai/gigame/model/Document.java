package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Сущность загруженного документа.
 * <p>
 * Хранит метаданные о загруженных файлах (PDF, DOCX, XLSX, TXT)
 * и извлечённый из них текст для последующей обработки и RAG-поиска.
 */
@Entity
@Table(name = "documents")

@Getter
@Setter
@NoArgsConstructor
public class Document {

    /**
     * Уникальный идентификатор документа (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Исходное имя файла.
     */
    @Column(nullable = false, length = 500)
    private String filename;

    /**
     * MIME-тип содержимого файла (например, "application/pdf").
     */
    @Column(name = "content_type")
    private String contentType;

    /**
     * Извлечённый из файла текст (используется для RAG и поиска).
     * Может быть большим, поэтому хранится в columnDefinition = "TEXT".
     */
    @Column(name = "extracted_text", columnDefinition = "TEXT")
    private String extractedText;

    /**
     * Размер файла в байтах.
     */
    @Column(name = "size_bytes")
    private Integer sizeBytes;

    /**
     * Идентификатор пользователя, загрузившего документ.
     * Используется для изоляции данных между пользователями.
     */
    @Column(name = "user_id")
    private String userId;

    /**
     * Дата и время загрузки документа (автоматически устанавливается).
     */
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    /**
     * Дата и время последнего обновления (автоматически обновляется).
     */
    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;
}
