package ru.sber.cs.ai.gigame.dto.scenario.graph;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;

/**
 * DTO для данных узла, содержащих различные атрибуты в зависимости от типа узла.
 *
 * @param label          Текст метки узла
 * @param prompt         Промпт или инструкция для узлов обработки
 * @param classes        Метки классов для узлов цикла/классификации
 * @param rules          Правила маршрутизации для узлов переключателя (строка JSON)
 * @param classifyStrict Флаг строгой классификации для узлов цикла
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Данные, связанные с узлом графа",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
@Builder
public record NodeDataDto(
        @Schema(
                description = "Текст метки узла",
                example = "ТЗ + КП",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String label,

        @Schema(
                description = "Промпт или инструкция для узлов обработки",
                example = "Ты работаешь с техническим заданием (ТЗ) на закупку. Извлеки все требования...",
                pattern = "^[\\w\\W]{0,20480}$",
                nullable = true
        )
        String prompt,

        @Schema(
                description = "Метки классов для узлов цикла/классификации",
                example = "ТЗ, КП",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String classes,

        @Schema(
                description = "Правила маршрутизации для узлов переключателя (строка JSON)",
                example = "[{\"value\":\"ТЗ\",\"operator\":\"contains\",\"label\":\"ТЗ\"}]",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String rules,

        @Schema(
                description = "Флаг строгой классификации для узлов цикла",
                example = "true",
                nullable = true
        )
        String classifyStrict,

        @Schema(
                description = "Режим работы",
                example = "all, first",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String mode,

        @Schema(
                description = "Поле сравнения для блока условия",
                example = "Статус",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String field,

        @Schema(
                description = "Оператор сравнения для блока условия",
                example = "all",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String operator,

        @Schema(
                description = "Значение сравнения для блока условия",
                example = "all",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String value,

        @Schema(
                description = "База знаний",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
                nullable = true
        )
        String knowledgeBaseId,

        @Schema(
                description = "Модель GigaChat для этого узла (пусто — модель по умолчанию)",
                example = "GigaChat-2-Max",
                pattern = "^[\\w\\W]{0,64}$",
                nullable = true
        )
        String model,

        @Schema(
                description = "Температура генерации для этого узла (пусто — значение по умолчанию)",
                example = "0.1",
                pattern = "^[0-9.,]{0,8}$",
                nullable = true
        )
        String temperature,

        @Schema(
                description = "Поведение при ошибке узла: пусто/stop — остановить сценарий, "
                        + "continue — продолжить с ошибкой в результате, "
                        + "branch — выполнить только рёбра с меткой «ошибка»",
                example = "continue",
                pattern = "^(stop|continue|branch)?$",
                nullable = true
        )
        String onError
) {
}
