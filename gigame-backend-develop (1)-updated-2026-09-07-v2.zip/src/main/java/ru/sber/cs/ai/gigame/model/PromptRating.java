package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Оценка промпта пользователем (1..5). Одна оценка на пару
 * «промпт + пользователь»; повторное голосование обновляет оценку.
 */
@Entity
@Table(name = "prompt_ratings")
@IdClass(PromptRating.Key.class)
@Getter
@Setter
@NoArgsConstructor
public class PromptRating {

    /** Составной ключ оценки: промпт + пользователь. */
    @Getter
    @Setter
    @NoArgsConstructor
    public static class Key implements Serializable {
        private UUID promptId;
        private String userId;

        public Key(UUID promptId, String userId) {
            this.promptId = promptId;
            this.userId = userId;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof Key key)) {
                return false;
            }
            return promptId.equals(key.promptId) && userId.equals(key.userId);
        }

        @Override
        public int hashCode() {
            return promptId.hashCode() * 31 + userId.hashCode();
        }
    }

    @Id
    @Column(name = "prompt_id")
    private UUID promptId;

    @Id
    @Column(name = "user_id")
    private String userId;

    /** Оценка от 1 до 5. */
    @Column(nullable = false)
    private Integer rating;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;
}
