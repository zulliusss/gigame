package ru.sber.cs.ai.gigame.exception;

/**
 * Исключение, выбрасываемое при ошибках обработки сценариев.
 */
public class ScenarioException extends ApplicationRuntimeException {

    public ScenarioException(String message) {
        super(message, 400);
    }

    public ScenarioException(String message, Throwable cause) {
        super(message, cause, 400);
    }
}
