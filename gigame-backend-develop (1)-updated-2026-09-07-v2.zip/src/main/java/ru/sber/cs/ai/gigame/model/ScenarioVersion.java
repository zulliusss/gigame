package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Версия сценария: снапшот состояния перед каждым сохранением изменений.
 * Позволяет посмотреть историю и восстановить любую прежнюю версию.
 */
@Data
@Entity
@Table(name = "scenario_versions")
public class ScenarioVersion {

    @Id
    private UUID id;

    @Column(name = "scenario_id", nullable = false)
    private UUID scenarioId;

    @Column(name = "version_no", nullable = false)
    private Integer versionNo;

    private String name;

    private String description;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "graph_data", columnDefinition = "jsonb")
    private Map<String, Object> graphData;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;
}
