package ru.sber.cs.ai.gigame.service.scenario;

import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_DOCUMENTS_TEXT;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_ERROR;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_PREVIOUS_OUTPUT;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioRunStepService.KEY_RESULT;

public class ScenarioMapper {

    /**
     * Максимальная длина строкового поля шага в подробном отчёте прогона.
     * Полные тексты хранятся в БД и уходят в файловые выгрузки; отчёт — витрина
     * для человека, и корпоративные прокси (SOWA) валидируют его поля по схеме
     * с потолком 500 000 символов — больший ответ блокируется целиком (403).
     */
    private static final int REPORT_FIELD_LIMIT = 200_000;

    private ScenarioMapper() {
    }

    /**
     * Усекает строковое поле отчёта до {@link #REPORT_FIELD_LIMIT} с явной
     * пометкой об усечении; {@code null} и короткие значения — как есть.
     */
    private static String clipString(String value) {
        if (value == null || value.length() <= REPORT_FIELD_LIMIT) {
            return value;
        }
        return value.substring(0, REPORT_FIELD_LIMIT)
                + "\n\n…[показаны первые " + REPORT_FIELD_LIMIT + " из " + value.length()
                + " символов — полный текст доступен в файловых выгрузках узлов]";
    }

    /**
     * Преобразует сущность Scenario в DTO для ответа клиенту.
     *
     * @param s сущность сценария
     * @return DTO с метаданными сценария
     */
    static ScenarioResponse toResponse(Scenario s) {
        return new ScenarioResponse(
                s.getId(),
                s.getName(),
                s.getDescription(),
                s.getCreatedAt(),
                s.getUpdatedAt(),
                Boolean.TRUE.equals(s.getShared()),
                true,
                null,
                0L,
                null,
                0L
        );
    }

    /**
     * Преобразует сущность Scenario в DTO с полными данными графа.
     *
     * @param s сущность сценария
     * @return DTO с полной информацией о сценарии
     */
    static ScenarioDetailResponse toDetailResponse(Scenario s) {
        return new ScenarioDetailResponse(
                s.getId(),
                s.getName(),
                s.getDescription(),
                s.getCreatedAt(),
                s.getUpdatedAt(),
                GraphDataMapper.toDto(s.getGraphData()),
                Boolean.TRUE.equals(s.getShared())
        );
    }

    /**
     * Преобразует сущность ScenarioRun в DTO для ответа клиенту.
     *
     * @param r сущность запуска
     * @return DTO с метаданными запуска
     */
    static ScenarioRunResponse toRunResponse(ScenarioRun r) {
        return new ScenarioRunResponse(
                r.getId(),
                r.getScenarioId(),
                r.getStatus(),
                r.getInputDocumentIds(),
                r.getStartedAt(),
                r.getCompletedAt()
        );
    }

    /**
     * Преобразует сущность ScenarioRunStep в DTO для ответа клиенту.
     *
     * @param s сущность шага запуска
     * @return DTO с данными шага
     */
    static ScenarioRunStepResponse toStepResponse(ScenarioRunStep s) {
        return new ScenarioRunStepResponse(
                s.getId(),
                s.getNodeId(),
                s.getNodeType(),
                s.getStatus(),
                getScenarioRunStepInputDataResponse(s),
                getScenarioRunStepOutputDataResponse(s),
                clipString(s.getPromptUsed()),
                s.getTokensUsed(),
                s.getStartedAt(),
                s.getCompletedAt()
        );
    }

    private static ScenarioRunStepOutputDataResponse getScenarioRunStepOutputDataResponse(ScenarioRunStep s) {
        if (s.getOutputData() == null) {
            return null;
        }
        return new ScenarioRunStepOutputDataResponse(
                clipString(s.getOutputData().get(KEY_RESULT)),
                clipString(s.getOutputData().get(KEY_ERROR))
        );
    }

    private static ScenarioRunStepInputDataResponse getScenarioRunStepInputDataResponse(ScenarioRunStep s) {
        if (s.getInputData() == null) {
            return null;
        }
        return new ScenarioRunStepInputDataResponse(
                clipString(s.getInputData().get(KEY_DOCUMENTS_TEXT)),
                clipString(s.getInputData().get(KEY_PREVIOUS_OUTPUT))
        );
    }
}
