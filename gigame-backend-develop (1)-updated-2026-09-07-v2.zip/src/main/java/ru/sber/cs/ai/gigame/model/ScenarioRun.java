package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Сущность запуска сценария.
 * <p>
 * Хранит информацию о выполнении конкретного экземпляра сценария,
 * включая входные данные, статус, результат и историю выполнения шагов.
 *
 * @see Scenario
 * @see ScenarioRunStep
 */
@Entity
@Table(name = "scenario_runs")

@Getter
@Setter
@NoArgsConstructor
public class ScenarioRun {

    /**
     * Уникальный идентификатор запуска (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Идентификатор сценария, который был запущен.
     */
    @Column(name = "scenario_id", nullable = false)
    private UUID scenarioId;

    /**
     * Текущий статус выполнения сценария.
     * Возможные значения: "pending", "running", "completed", "failed".
     */
    @Column(nullable = false, length = 50)
    private String status = "pending";

    /**
     * Список идентификаторов входных документов (JSONB).
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "input_document_ids", columnDefinition = "jsonb")
    private List<String> inputDocumentIds;

    /**
     * Итоговый результат выполнения сценария (текст).
     */
    @Column(columnDefinition = "TEXT")
    private String result;

    /**
     * Дата и время начала выполнения.
     * Устанавливается автоматически перед сохранением в БД.
     */
    @Column(name = "started_at", nullable = false)
    private OffsetDateTime startedAt;

    /**
     * Дата и время завершения выполнения.
     * Устанавливается только для завершённых запусков.
     */
    @Column(name = "completed_at")
    private OffsetDateTime completedAt;

    /**
     * Список шагов выполнения сценария, отсортированных по времени начала.
     */
    @OneToMany(mappedBy = "runId", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("startedAt ASC")
    private List<ScenarioRunStep> steps = new ArrayList<>();

    /**
     * Предварительная инициализация даты начала при сохранении.
     * Устанавливает {@code startedAt} текущим временем, если оно не указано.
     */
    @PrePersist
    @SuppressWarnings("unused")
    private void prePersist() {
        if (startedAt == null) {
            startedAt = OffsetDateTime.now();
        }
    }
}
