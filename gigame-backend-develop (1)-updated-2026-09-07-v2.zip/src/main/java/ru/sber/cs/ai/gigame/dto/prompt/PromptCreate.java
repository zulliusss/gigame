package ru.sber.cs.ai.gigame.dto.prompt;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO создания промпта.
 *
 * @param title       короткое название (обязательно)
 * @param description для какой задачи промпт (опционально)
 * @param text        текст промпта (обязательно)
 * @param model       модель GigaChat, на которой промпт проверен (опционально)
 * @param shared      общий промпт; null — по умолчанию общий
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(description = "Запрос на создание промпта",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public record PromptCreate(
        @Schema(description = "Короткое название", pattern = "^[\\w\\W]{1,255}$")
        String title,
        @Schema(description = "Для какой задачи промпт", pattern = "^[\\w\\W]{0,4096}$")
        String description,
        @Schema(description = "Текст промпта", pattern = "^[\\w\\W]{1,65536}$")
        String text,
        @Schema(description = "Модель GigaChat, на которой промпт проверен",
                pattern = "^[\\w\\W]{0,64}$")
        String model,
        @Schema(description = "Общий промпт (по умолчанию true)")
        Boolean shared
) {
}
