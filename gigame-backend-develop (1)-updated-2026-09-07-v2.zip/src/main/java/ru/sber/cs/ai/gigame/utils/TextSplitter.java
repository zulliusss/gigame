package ru.sber.cs.ai.gigame.utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.KBService;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Порт рекурсивного разбиения текста из langchain.
 * <p>
 * Разбивает текст на перекрывающиеся фрагменты, используя рекурсивную стратегию
 * селекторов. Если текст не удаётся разделить первым селектором, пробует следующий.
 *
 * @see DocumentService
 * @see KBService
 */
@Component
public class TextSplitter {
    private static final String[] SEPARATORS = {"\n\n", "\n", ". ", " ", ""};
    @Value("${app.embedding.chunk-size:1000}")
    private int defaultChunkSize;
    @Value("${app.embedding.overlap:200}")
    private int defaultOverlap;

    /**
     * Разбивает текст на фрагменты с настройками по умолчанию.
     *
     * @param text текст для разбиения
     * @return список фрагментов текста
     */
    public List<String> split(String text) {
        return split(text, defaultChunkSize, defaultOverlap);
    }

    /**
     * Разбивает текст на перекрывающиеся фрагменты с использованием рекурсивного разбиения по символам.
     * <p>
     * Алгоритм:
     * <ol>
     *   <li>Разбивает текст по первому селектору из списка</li>
     *   <li>Если фрагмент всё ещё слишком большой, рекурсивно использует следующий селектор</li>
     *   <li>Объединяет маленькие фрагменты до размера chunkSize с перекрытием</li>
     * </ol>
     *
     * @param text      текст для разбиения
     * @param chunkSize максимальный размер фрагмента в символах
     * @param overlap   перекрытие между последовательными фрагментами в символах
     * @return список фрагментов текста
     */
    public List<String> split(String text, int chunkSize, int overlap) {
        if (text == null || text.isBlank()) {
            return List.of();
        }
        List<String> chunks = splitRecursive(text, chunkSize, 0);
        return mergeWithOverlap(chunks, chunkSize, overlap);
    }

    /**
     * Рекурсивно разбивает текст, находя первый селектор, который создаёт подфрагменты.
     * Если любой подфрагмент всё ещё больше chunkSize, рекурсирует с следующим селектором.
     *
     * @param text           текст для разбиения
     * @param chunkSize      максимальный размер фрагмента
     * @param separatorIndex индекс текущего селектора в массиве SEPARATORS
     * @return список фрагментов текста
     */
    private List<String> splitRecursive(String text, int chunkSize, int separatorIndex) {
        if (text.length() <= chunkSize) {
            return List.of(text);
        }
        String separator = SEPARATORS[separatorIndex];
        String[] parts;
        if (separator.isEmpty()) {
            // Пустой селектор: разбивает на отдельные символы, сгруппированные по chunkSize
            List<String> result = new ArrayList<>();
            for (int i = 0; i < text.length(); i += chunkSize) {
                result.add(text.substring(i, Math.min(i + chunkSize, text.length())));
            }
            return result;
        } else {
            parts = text.split(Pattern.quote(separator), -1);
        }

        if (parts.length <= 1) {
            // Селектор не найден — пробует следующий
            return splitRecursive(text, chunkSize, separatorIndex + 1);
        }

        List<String> result = new ArrayList<>();
        for (String part : parts) {
            String trimmed = part.strip();
            if (trimmed.isEmpty()) {
                continue;
            }
            if (trimmed.length() <= chunkSize) {
                result.add(trimmed);
            } else {
                // Подфрагмент всё ещё слишком большой — рекурсия с следующим селектором
                result.addAll(splitRecursive(trimmed, chunkSize, separatorIndex + 1));
            }
        }
        return result;
    }

    /**
     * Объединяет маленькие последовательные фрагменты в фрагменты размером до chunkSize
     * с перекрытием за счёт повторного включения завершающего текста предыдущего объединённого фрагмента.
     *
     * @param chunks    список фрагментов для объединения
     * @param chunkSize максимальный размер объединённого фрагмента
     * @param overlap   размер перекрытия
     * @return список объединённых фрагментов
     */
    private List<String> mergeWithOverlap(List<String> chunks, int chunkSize, int overlap) {
        List<String> merged = new ArrayList<>();
        StringBuilder current = new StringBuilder();

        for (String chunk : chunks) {
            if (current.isEmpty()) {
                current.append(chunk);
            } else if (wouldAppend(current, chunk, chunkSize)) {
                current.append(" ").append(chunk);
            } else {
                merged.add(current.toString());
                var previous = current.toString();
                current = new StringBuilder();
                appendWithOverlap(current, previous, chunk, overlap);
            }
        }

        if (!current.isEmpty()) {
            merged.add(current.toString());
        }

        return merged;
    }

    /**
     * Проверяет, поместится ли новый фрагмент в текущий с учётом пробела.
     */
    private boolean wouldAppend(StringBuilder current, String chunk, int chunkSize) {
        return current.length() + 1 + chunk.length() <= chunkSize;
    }

    /**
     * Добавляет новый фрагмент с учётом перекрытия.
     */
    private void appendWithOverlap(StringBuilder current, String prev, String chunk, int overlap) {
        if (overlap > 0 && prev.length() > overlap) {
            String overlapText = getOverlapText(prev, overlap);
            current.append(overlapText).append(" ").append(chunk);
        } else {
            current.append(chunk);
        }
    }

    /**
     * Извлекает текст для перекрытия из конца предыдущего фрагмента.
     * Пытается начать с границы слова.
     */
    private String getOverlapText(String prev, int overlap) {
        String overlapText = prev.substring(prev.length() - overlap);
        int spaceIdx = overlapText.indexOf(' ');
        if (spaceIdx >= 0 && spaceIdx < overlapText.length() - 1) {
            return overlapText.substring(spaceIdx + 1);
        }
        return overlapText;
    }
}
