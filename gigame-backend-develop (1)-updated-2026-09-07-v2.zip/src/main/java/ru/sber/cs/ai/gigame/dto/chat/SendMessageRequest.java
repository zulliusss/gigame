package ru.sber.cs.ai.gigame.dto.chat;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для отправки сообщения в чат.
 * Используется при отправке нового сообщения в существующую беседу.
 *
 * @param content Текст сообщения для отправки (максимум 4096 символов)
 * @see MessageResponse
 */
@Schema(
        description = "Запрос на отправку сообщения в беседу",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record SendMessageRequest(
        @Schema(
                description = "Текст сообщения для отправки",
                example = "Какие услуги вы предоставляете?",
                pattern = "^[\\w\\W]{0,4096}$"
        )
        String content
) {
}
