package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * DTO для представления шага выполнения сценария.
 * Содержит информацию о выполнении конкретного узла графа сценария.
 *
 * @param id          Уникальный идентификатор шага
 * @param nodeId      Идентификатор узла в графе сценария
 * @param nodeType    Тип узла (например, "task", "condition", "gateway")
 * @param status      Статус выполнения узла (например, "pending", "completed", "failed")
 * @param inputData   Входные данные для выполнения узла
 * @param outputData  Выходные данные после выполнения узла
 * @param promptUsed  Использованный промпт (для LLM-узлов)
 * @param tokensUsed  Количество использованных токенов (для LLM-узлов)
 * @param startedAt   Дата и время начала выполнения узла
 * @param completedAt Дата и время завершения выполнения узла
 * @see ScenarioRunDetailResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Шаг выполнения AI-сценария (узел графа)",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioRunStepResponse(
        @Schema(
                description = "Уникальный идентификатор шага",
                example = "550e8400-e29b-41d4-a716-446655440000",
                pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
        )
        UUID id,

        @Schema(
                description = "Идентификатор узла в графе сценария",
                example = "node_001",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String nodeId,

        @Schema(
                description = "Тип узла (input, output, task, condition, gateway, loop, switch, if_node)",
                example = "task",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String nodeType,

        @Schema(
                description = "Статус выполнения узла (pending, running, completed, failed, paused)",
                example = "completed",
                pattern = "^[\\w\\W]{0,32}$"
        )
        String status,

        @Schema(
                description = "Входные данные для выполнения узла"
        )
        ScenarioRunStepInputDataResponse inputData,

        @Schema(
                description = "Выходные данные после выполнения узла"
        )
        ScenarioRunStepOutputDataResponse outputData,

        @Schema(
                description = "Использованный промпт (для LLM-узлов)",
                pattern = "^[\\w\\W]{0,4096}$",
                example = "Классифицируй заявку..."
        )
        String promptUsed,

        @Schema(
                description = "Количество использованных токенов (для LLM-узлов)",
                minimum = "0",
                maximum = "2147483647",
                example = "150"
        )
        Integer tokensUsed,

        @Schema(
                description = "Дата и время начала выполнения узла"
        )
        OffsetDateTime startedAt,

        @Schema(
                description = "Дата и время завершения выполнения узла"
        )
        OffsetDateTime completedAt
) {
}
