package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Вопрос агента пользователю (асинхронный human-in-the-loop): агент не
 * останавливает прогон, а собирает спорные места (неподтверждённые цитаты,
 * ненайденные данные) в вопросы. Ответ пользователя сохраняется и
 * превращается в урок сценария — при следующем прогоне вопрос не повторится.
 */
@Entity
@Table(name = "agent_questions")
@Getter
@Setter
@NoArgsConstructor
public class AgentQuestion {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(name = "run_id", nullable = false)
    private UUID runId;

    @Column(name = "scenario_id")
    private UUID scenarioId;

    @Column(name = "node_label")
    private String nodeLabel;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String question;

    @Column(columnDefinition = "TEXT")
    private String answer;

    @Column(name = "answered_at")
    private OffsetDateTime answeredAt;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;
}
