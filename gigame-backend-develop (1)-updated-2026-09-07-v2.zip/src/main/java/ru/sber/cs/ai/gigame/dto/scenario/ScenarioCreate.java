package ru.sber.cs.ai.gigame.dto.scenario;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;

/**
 * DTO для создания нового сценария.
 * Используется при инициализации нового сценария выполнения с описанием графа задач.
 *
 * @param name        Название сценария (максимум 64 символа)
 * @param description Описание сценария (максимум 255 символов)
 * @param graphData   Данные графа выполнения в формате Map (JSON-структура)
 * @see ScenarioResponse
 * @see ScenarioDetailResponse
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Запрос на создание нового AI-сценария (workflow)",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record ScenarioCreate(
        @Schema(
                description = "Название сценария",
                example = "Обработка заявок",
                pattern = "^[\\w\\W]{0,64}$"
        )
        String name,

        @Schema(
                description = "Описание сценария",
                example = "Автоматическая обработка входящих заявок с classification и роутингом",
                pattern = "^[\\w\\W]{0,255}$",
                nullable = true
        )
        String description,

        @Schema(
                description = "Данные графа выполнения в формате Map (JSON-структура)"
        )
        GraphDataDto graphData
//        @Size(max = 1000)
//        Map<String, Object> graphData
) {
}
