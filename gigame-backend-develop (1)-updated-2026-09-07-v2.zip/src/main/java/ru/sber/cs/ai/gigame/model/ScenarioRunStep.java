package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * Сущность шага выполнения сценария.
 * <p>
 * Хранит информацию о выполнении одного узла графа сценария,
 * включая входные/выходные данные, статус и используемый промпт.
 *
 * @see ScenarioRun
 */
@Entity
@Table(name = "scenario_run_steps")
@Getter
@Setter
@NoArgsConstructor
public class ScenarioRunStep {

    /**
     * Уникальный идентификатор шага (UUID).
     */
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /**
     * Идентификатор запуска сценария, к которому относится шаг.
     */
    @Column(name = "run_id", nullable = false)
    private UUID runId;

    /**
     * Идентификатор узла графа (из graph_data).
     */
    @Column(name = "node_id")
    private String nodeId;

    /**
     * Тип узла (input, output, loop, switch, if_node или custom).
     */
    @Column(name = "node_type", length = 100)
    private String nodeType;

    /**
     * Текущий статус выполнения узла.
     * Возможные значения: "pending", "running", "completed", "failed".
     */
    @Column(nullable = false, length = 50)
    private String status = "pending";

    /**
     * Входные данные, переданные в узел (JSONB).
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "input_data", columnDefinition = "jsonb")
    private Map<String, String> inputData;

    /**
     * Результат выполнения узла (JSONB).
     */
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "output_data", columnDefinition = "jsonb")
    private Map<String, String> outputData;

    /**
     * Промпт, использованный при выполнении узла (если применимо).
     */
    @Column(name = "prompt_used", columnDefinition = "TEXT")
    private String promptUsed;

    /**
     * Количество использованных токенов (если доступно).
     */
    @Column(name = "tokens_used")
    private Integer tokensUsed;

    /**
     * Дата и время начала выполнения узла.
     */
    @Column(name = "started_at")
    private OffsetDateTime startedAt;

    /**
     * Дата и время завершения выполнения узла.
     */
    @Column(name = "completed_at")
    private OffsetDateTime completedAt;
}
