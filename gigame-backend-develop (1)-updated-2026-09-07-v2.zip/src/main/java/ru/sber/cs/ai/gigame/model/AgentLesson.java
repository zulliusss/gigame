package ru.sber.cs.ai.gigame.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.OffsetDateTime;
import java.util.UUID;

/**
 * Урок агента: правило, выученное из прошлых прогонов (ответ пользователя,
 * принятое ревизором замечание, дистилляция). Частный урок привязан к
 * сценарию и применяется сразу; общий урок ({@code scenarioId == null})
 * применяется во всех сценариях только после одобрения — защита от
 * отравления общей памяти.
 */
@Entity
@Table(name = "agent_lessons")
@Getter
@Setter
@NoArgsConstructor
public class AgentLesson {

    /** Источники уроков. */
    public static final String SOURCE_USER = "user";
    public static final String SOURCE_REVISER = "reviser";
    public static final String SOURCE_AUTO = "auto";
    /** Системный урок: поставляется релизом, read-only, действует для всех. */
    public static final String SOURCE_SYSTEM = "system";

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    /** Сценарий-владелец; {@code null} — общий урок для всех сценариев. */
    @Column(name = "scenario_id")
    private UUID scenarioId;

    @Column(name = "user_id")
    private String userId;

    /** Текст правила («сумма акта — это Итого с НДС, не аванс»). */
    @Column(nullable = false, columnDefinition = "TEXT")
    private String lesson;

    /** Откуда урок: user | reviser | auto. */
    @Column(nullable = false, length = 32)
    private String source = SOURCE_USER;

    /** Общие уроки применяются только после одобрения. */
    @Column(nullable = false)
    private Boolean approved = false;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private OffsetDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt;
}
