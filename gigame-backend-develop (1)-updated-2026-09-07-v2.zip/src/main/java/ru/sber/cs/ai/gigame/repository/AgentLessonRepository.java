package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.sber.cs.ai.gigame.model.AgentLesson;

import java.util.List;
import java.util.UUID;

public interface AgentLessonRepository extends JpaRepository<AgentLesson, UUID> {

    List<AgentLesson> findByScenarioIdOrderByCreatedAtDesc(UUID scenarioId);

    List<AgentLesson> findByScenarioIdIsNullAndApprovedTrueOrderByCreatedAtDesc();

    List<AgentLesson> findByScenarioIdIsNullOrderByCreatedAtDesc();

    List<AgentLesson> findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(String source);

    List<AgentLesson> findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc(
            String userId, String source);
}
