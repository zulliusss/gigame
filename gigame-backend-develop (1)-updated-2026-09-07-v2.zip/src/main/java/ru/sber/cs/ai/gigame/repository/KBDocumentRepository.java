package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.KBDocument;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Репозиторий для работы со связями документов и баз знаний.
 * <p>
 * Предоставляет методы для управления KBDocument и загрузки связанных документов.
 *
 * @see KBDocument
 */
@Repository
public interface KBDocumentRepository extends JpaRepository<KBDocument, UUID> {

    /**
     * Возвращает все связи между KB и документами для указанной базы знаний.
     *
     * @param knowledgeBaseId идентификатор базы знаний
     * @return список связей KBDocument
     */
    List<KBDocument> findByKnowledgeBaseId(UUID knowledgeBaseId);

    /**
     * Возвращает связи между KB и документами с eagerly загруженным объектом Document.
     * Используется для избежания LazyInitializationException при работе с detached сущностями.
     *
     * @param kbId идентификатор базы знаний
     * @return список связей с предзагруженными документами
     */
    @Query(value = "SELECT k FROM KBDocument k JOIN FETCH k.document WHERE k.knowledgeBase.id = :kbId")
    List<KBDocument> findByKnowledgeBaseIdWithDocument(@Param("kbId") UUID kbId);

    /**
     * Возвращает связь между指定ной KB и документом, если такая существует.
     *
     * @param knowledgeBaseId идентификатор базы знаний
     * @param documentId      идентификатор документа
     * @return опциональная связь KBDocument
     */
    Optional<KBDocument> findByKnowledgeBaseIdAndDocumentId(UUID knowledgeBaseId, UUID documentId);

    /**
     * Возвращает все связи документа с базами знаний (с предзагруженной KB).
     * Используется для проверки доступа к документу через общие базы.
     *
     * @param documentId идентификатор документа
     * @return список связей KBDocument с базами знаний
     */
    @Query(value = "SELECT k FROM KBDocument k JOIN FETCH k.knowledgeBase WHERE k.documentId = :documentId")
    List<KBDocument> findByDocumentIdWithKnowledgeBase(@Param("documentId") UUID documentId);
}
