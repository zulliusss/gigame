package ru.sber.cs.ai.gigame.service.scenario.enums;

import lombok.Getter;

// -------------------------------------------------------------------------
// Status and Type Values (Enum)
// -------------------------------------------------------------------------
@Getter
@SuppressWarnings({"unused"})
public enum ScenarioStatus {
    RUNNING("running"),
    COMPLETED("completed"),
    FAILED("failed"),
    SKIPPED("skipped"),
    UNKNOWN("unknown");

    private final String value;

    ScenarioStatus(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
