package ru.sber.cs.ai.gigame.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.sber.cs.ai.gigame.model.Scenario;

import java.util.List;
import java.util.UUID;

/**
 * Репозиторий для работы с сценариями (workflows).
 * <p>
 * Предоставляет методы для управления сценариями и получения списка всех сценариев.
 *
 * @see Scenario
 */
@Repository
public interface ScenarioRepository extends JpaRepository<Scenario, UUID> {

    /**
     * Возвращает все сценарии, отсортированные по дате последнего обновления (новые первыми).
     *
     * @return список всех сценариев
     */
    List<Scenario> findAllByUserIdOrderByUpdatedAtDesc(String userId);

    /**
     * Сценарии, видимые пользователю: его собственные и все общие.
     *
     * @param userId идентификатор пользователя
     * @return сценарии, новые сверху
     */
    List<Scenario> findAllByUserIdOrSharedTrueOrderByUpdatedAtDesc(String userId);
}
