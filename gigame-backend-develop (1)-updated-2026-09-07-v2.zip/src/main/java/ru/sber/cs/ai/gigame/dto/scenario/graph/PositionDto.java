package ru.sber.cs.ai.gigame.dto.scenario.graph;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO для позиции узла на графе.
 *
 * @param x Горизонтальная координата
 * @param y Вертикальная координата
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Позиция узла на графе",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
public record PositionDto(
        @Schema(
                description = "Координата X (горизонтальная)",
                minimum = "0",
                maximum = "4096",
                example = "400"
        )
        Integer x,

        @Schema(
                description = "Координата Y (вертикальная)",
                minimum = "0",
                maximum = "4096",
                example = "30"
        )
        Integer y
) {
}
