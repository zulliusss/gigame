package ru.sber.cs.ai.gigame.dto.scenario.graph;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;

/**
 * DTO для узла в графе.
 *
 * @param id       Уникальный идентификатор узла
 * @param type     Тип узла (input, output, loop, switch, if_node, processing)
 * @param data     Данные узла (метка, промпт, классы, правила и т.д.)
 * @param position Координаты позиции узла
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(
        description = "Узел в графе выполнения сценария",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE
)
@Builder
public record NodeDto(
        @Schema(
                description = "Уникальный идентификатор узла",
                example = "node_0",
                pattern = "^[\\w\\W]{0,255}$"
        )
        String id,

        @Schema(
                description = "Тип узла",
                example = "input",
                allowableValues = {"input", "output", "loop", "switch", "if_node", "processing",
                        "calc", "aggregate", "transform", "subscenario", "control", "wait", "note"}
        )
        // ScenarioNodeType type,
        String type,

        @Schema(
                description = "Данные узла (метка, промпт, классы, правила и т.д.)"
        )
        NodeDataDto data,

        @Schema(
                description = "Координаты позиции узла"
        )
        PositionDto position,

        @Schema(
                description = "Размер блока(узла)"
        )
        MeasuredDto measured
) {
}
