package ru.sber.cs.ai.gigame.dto.prompt;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * DTO обновления промпта: null-поля не меняются.
 *
 * @param title       новое название
 * @param description новое описание
 * @param text        новый текст
 * @param model       модель GigaChat; null — не менять, "" — сбросить
 * @param shared      признак общего промпта
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Schema(description = "Запрос на обновление промпта",
        additionalProperties = Schema.AdditionalPropertiesValue.FALSE)
public record PromptUpdate(
        @Schema(description = "Новое название", pattern = "^[\\w\\W]{0,255}$")
        String title,
        @Schema(description = "Новое описание", pattern = "^[\\w\\W]{0,4096}$")
        String description,
        @Schema(description = "Новый текст промпта", pattern = "^[\\w\\W]{0,65536}$")
        String text,
        @Schema(description = "Модель GigaChat; null — не менять, пустая строка — сбросить",
                pattern = "^[\\w\\W]{0,64}$")
        String model,
        @Schema(description = "Признак общего промпта; null — не менять")
        Boolean shared
) {
}
