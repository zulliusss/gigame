package ru.sber.cs.ai.gigame.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonCompressRequest;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonCreateRequest;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonExtractRequest;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonUpdateRequest;
import ru.sber.cs.ai.gigame.dto.agent.AgentQuestionAnswerRequest;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Память агента: уроки (частные и общие), планы, вопросы пользователю.
 * Память прозрачна: всё видно, редактируемо и удаляемо — защита от
 * тихого отравления выученными ошибками.
 */
@RestController
@RequestMapping("/api/agent")
@RequiredArgsConstructor
@Slf4j
public class AgentMemoryController {

    private final AgentMemoryService memoryService;
    private final ScenarioRunRepository runRepository;
    private final ScenarioRunStepRepository stepRepository;

    @GetMapping("/lessons")
    @Operation(summary = "Уроки агента",
            description = "Уроки сценария (scenario_id) или общие уроки (без параметра).")
    public Mono<List<AgentLessonResponseDto>> getLessons(
            @Parameter(description = "Сценарий; пусто — общие уроки")
            @RequestParam(name = "scenario_id", required = false) UUID scenarioId) {
        return Mono.fromCallable(() -> memoryService.getLessons(scenarioId))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @PostMapping("/lessons")
    @Operation(summary = "Добавить урок",
            description = "Частный урок сценария применяется сразу; общий (без scenario_id) — "
                    + "после одобрения.")
    public Mono<AgentLessonResponseDto> addLesson(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @RequestBody AgentLessonCreateRequest body) {
        log.info("[{}] addLesson", userId);
        UUID scenarioId = body.scenarioId() == null || body.scenarioId().isBlank()
                ? null : UUID.fromString(body.scenarioId());
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> memoryService.addLesson(scenarioId, body.lesson(), "user")))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @PutMapping("/lessons/{id}")
    @Operation(summary = "Изменить текст урока",
            description = "Уроки сценария меняет только автор сценария.")
    public Mono<AgentLessonResponseDto> updateLesson(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id,
            @RequestBody AgentLessonUpdateRequest body) {
        log.info("[{}] updateLesson, id={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> memoryService.updateLesson(id, body.lesson())))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @DeleteMapping("/lessons/{id}")
    @Operation(summary = "Удалить урок",
            description = "Уроки сценария удаляет только автор сценария.")
    public Mono<Void> deleteLesson(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id) {
        log.info("[{}] deleteLesson, id={}", userId, id);
        return Mono.<Void>fromRunnable(() -> CurrentUserHolder.withUser(userId,
                        () -> {
                            memoryService.deleteLesson(id);
                            return null;
                        }))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @PostMapping("/lessons/{id}/approve")
    @Operation(summary = "Одобрить урок",
            description = "Уроки сценария одобряет только автор сценария.")
    public Mono<AgentLessonResponseDto> approveLesson(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id) {
        log.info("[{}] approveLesson, id={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> memoryService.approveLesson(id)))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @PostMapping("/lessons/compress")
    @Operation(summary = "Рефлексия-сжатие уроков сценария",
            description = "Дистиллирует уроки сценария в не более 7 правил (LLM), "
                    + "заменяя исходные.")
    public Mono<List<AgentLessonResponseDto>> compressLessons(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @RequestBody AgentLessonCompressRequest body) {
        log.info("[{}] compressLessons, scenarioId={}", userId, body.scenarioId());
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> memoryService.compressLessons(body.scenarioId())))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @GetMapping("/plans")
    @Operation(summary = "Планы сценария из памяти планов")
    public Mono<List<AgentPlan>> getPlans(
            @RequestParam(name = "scenario_id") UUID scenarioId) {
        return Mono.fromCallable(() -> memoryService.getPlans(scenarioId))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @DeleteMapping("/plans/{id}")
    @Operation(summary = "Удалить план из памяти",
            description = "Планы сценария удаляет только автор сценария.")
    public Mono<Void> deletePlan(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id) {
        log.info("[{}] deletePlan, id={}", userId, id);
        return Mono.<Void>fromRunnable(() -> CurrentUserHolder.withUser(userId,
                        () -> {
                            memoryService.deletePlan(id);
                            return null;
                        }))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @PostMapping("/lessons/extract")
    @Operation(summary = "Извлечь кандидатов-уроков из прогона",
            description = "LLM выделяет правила из замечаний/правок узлов прогона. Кандидаты "
                    + "сохраняются неодобренными и применяются только после одобрения.")
    public Mono<List<AgentLessonResponseDto>> extractLessons(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @RequestBody AgentLessonExtractRequest body) {
        log.info("[{}] extractLessons, runId={}", userId, body.runId());
        UUID runId = body.runId();
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                () -> {
                    var run = runRepository.findById(runId)
                            .orElseThrow(() -> new NotFoundException("Прогон не найден: " + runId));
                    Map<String, String> outputs = new LinkedHashMap<>();
                    stepRepository.findByRunIdOrderByStartedAtAsc(runId).forEach(step -> {
                        var output = step.getOutputData();
                        Object result = output == null ? null : output.get("result");
                        if (result != null && !String.valueOf(result).isBlank()) {
                            outputs.put(step.getNodeId() + " (" + step.getNodeType() + ")",
                                    String.valueOf(result));
                        }
                    });
                    return memoryService.extractLessonsFromRun(run.getScenarioId(), outputs);
                })).subscribeOn(Schedulers.boundedElastic());
    }

    @GetMapping("/questions")
    @Operation(summary = "Вопросы агента по прогону")
    public Mono<List<AgentQuestion>> getQuestions(
            @RequestParam(name = "run_id") UUID runId) {
        return Mono.fromCallable(() -> memoryService.getQuestionsByRun(runId))
                .subscribeOn(Schedulers.boundedElastic());
    }

    @PostMapping("/questions/{id}/answer")
    @Operation(summary = "Ответить на вопрос агента",
            description = "Ответ сохраняется и превращается в урок сценария — при следующем "
                    + "прогоне агент его учтёт.")
    public Mono<AgentQuestion> answerQuestion(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id,
            @RequestBody AgentQuestionAnswerRequest body) {
        log.info("[{}] answerQuestion, id={}", userId, id);
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId,
                        () -> memoryService.answerQuestion(id, body.answer())))
                .subscribeOn(Schedulers.boundedElastic());
    }
}
