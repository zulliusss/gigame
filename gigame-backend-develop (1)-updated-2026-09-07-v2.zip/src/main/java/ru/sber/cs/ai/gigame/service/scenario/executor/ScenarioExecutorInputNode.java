package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class ScenarioExecutorInputNode extends AbstractScenarioExecutor {

    protected ScenarioExecutorInputNode(ScenarioRunNode node) {
        super(node);
    }

    @SuppressWarnings("java:S2973") // forEach body: both adds are semantically one operation
    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> runDocList = new ArrayList<>();
        List<String> resultList = new ArrayList<>();
        var docMap = node.getGraph().getDocMap();
        if (docMap.isEmpty()) {
            return "";
        }
        docMap.forEach((key, value) -> {
            runDocList.add(key);
            resultList.add("<<<" + key + ">>>\n" +
                    value.getText() + "\n<<<END_" + key + ">>>");
        });
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getDocList().addAll(runDocList);
        }
        return String.join("\n\n", resultList);
    }
}
