-- =====================================================
-- ChangeSet 4: Scenario versions & chat improvements
-- =====================================================
-- 2026-07-10: Adding scenario versions table, chat model/temperature/summary
--             columns, shared KB flag, and RAG source tracking.
--             Uses ${spring.liquibase.default-schema} placeholder for schema.

-- Scenario versions table (idempotent CREATE TABLE IF NOT EXISTS)
CREATE TABLE IF NOT EXISTS scenario_versions (
    id UUID PRIMARY KEY,
    scenario_id UUID NOT NULL,
    version_no INTEGER NOT NULL,
    name VARCHAR(255),
    description TEXT,
    graph_data JSONB,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_scenario_versions_sid
    ON scenario_versions(scenario_id, version_no);

-- Chat improvements: multiple KBs per conversation, model/temperature,
-- summary tracking, RAG sources
ALTER TABLE IF EXISTS conversations
    ADD COLUMN IF NOT EXISTS knowledge_base_ids JSONB,
    ADD COLUMN IF NOT EXISTS model VARCHAR(64),
    ADD COLUMN IF NOT EXISTS temperature DOUBLE PRECISION,
    ADD COLUMN IF NOT EXISTS summary TEXT,
    ADD COLUMN IF NOT EXISTS summary_message_count INTEGER NOT NULL DEFAULT 0;
ALTER TABLE IF EXISTS messages
    ADD COLUMN IF NOT EXISTS sources JSONB;

-- Shared knowledge base flag
ALTER TABLE IF EXISTS knowledge_bases
    ADD COLUMN IF NOT EXISTS shared BOOLEAN NOT NULL DEFAULT FALSE;