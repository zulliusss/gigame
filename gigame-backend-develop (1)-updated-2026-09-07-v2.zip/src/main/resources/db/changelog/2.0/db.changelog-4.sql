-- =====================================================
-- ChangeSet 7: Agent memory — lessons, plans, questions
-- =====================================================
-- 2026-08-04: Саморазвивающийся агент: уроки (частные для сценария и
--             общие), память планов (переиспользование чек-листов),
--             вопросы агента пользователю (human-in-the-loop, async).
--             Idempotent (IF NOT EXISTS).

-- Уроки агента: scenario_id NULL = общий урок (применяется после одобрения)
CREATE TABLE IF NOT EXISTS agent_lessons (
    id UUID PRIMARY KEY,
    scenario_id UUID,
    user_id VARCHAR(64),
    lesson TEXT NOT NULL,
    source VARCHAR(32) NOT NULL DEFAULT 'user',
    approved BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_lessons_scenario ON agent_lessons(scenario_id);

-- Память планов: проверенные чек-листы по хэшу нормализованного задания
CREATE TABLE IF NOT EXISTS agent_plans (
    id UUID PRIMARY KEY,
    scenario_id UUID,
    task_hash VARCHAR(64) NOT NULL,
    task_preview TEXT,
    plan TEXT NOT NULL,
    uses INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_plans_hash ON agent_plans(task_hash);

-- Вопросы агента пользователю (асинхронный human-in-the-loop):
-- ответ пользователя превращается в урок сценария
CREATE TABLE IF NOT EXISTS agent_questions (
    id UUID PRIMARY KEY,
    run_id UUID NOT NULL,
    scenario_id UUID,
    node_label VARCHAR(255),
    question TEXT NOT NULL,
    answer TEXT,
    answered_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_agent_questions_run ON agent_questions(run_id);
