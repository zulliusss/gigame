-- =====================================================
-- ChangeSet 5: Shared scenarios, ratings & prompt library
-- =====================================================
-- 2026-08-02: Scenario sharing flag, per-user scenario ratings,
--             prompt library with ratings and usage counters.
--             All statements are idempotent (IF NOT EXISTS / IF EXISTS).

-- Shared scenario flag: shared scenarios are visible to all users
ALTER TABLE IF EXISTS scenarios
    ADD COLUMN IF NOT EXISTS shared BOOLEAN NOT NULL DEFAULT FALSE;

-- Per-user scenario ratings (1..5), one vote per user per scenario
CREATE TABLE IF NOT EXISTS scenario_ratings (
    scenario_id UUID NOT NULL,
    user_id VARCHAR(64) NOT NULL,
    rating INTEGER NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    PRIMARY KEY (scenario_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_scenario_ratings_sid ON scenario_ratings(scenario_id);

-- Prompt library: proven prompts shared between users
CREATE TABLE IF NOT EXISTS prompts (
    id UUID PRIMARY KEY,
    user_id VARCHAR(64),
    title VARCHAR(255) NOT NULL,
    description TEXT,
    text TEXT NOT NULL,
    shared BOOLEAN NOT NULL DEFAULT TRUE,
    usage_count INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_prompts_updated ON prompts(updated_at DESC);

-- Per-user prompt ratings (1..5)
CREATE TABLE IF NOT EXISTS prompt_ratings (
    prompt_id UUID NOT NULL,
    user_id VARCHAR(64) NOT NULL,
    rating INTEGER NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    PRIMARY KEY (prompt_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_prompt_ratings_pid ON prompt_ratings(prompt_id);
