-- =====================================================
-- ChangeSet 6: Prompt library — target model
-- =====================================================
-- 2026-08-03: Prompts may declare which GigaChat model they work best with.
--             Idempotent (IF EXISTS / IF NOT EXISTS).

ALTER TABLE IF EXISTS prompts
    ADD COLUMN IF NOT EXISTS model VARCHAR(64);
