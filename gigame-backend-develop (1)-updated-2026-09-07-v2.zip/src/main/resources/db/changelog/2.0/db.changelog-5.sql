-- =====================================================
-- ChangeSet 8: Системные уроки агента (поставляются релизом)
-- =====================================================
-- 2026-08-04: Слой системной памяти: правила из практики боевых прогонов,
--             read-only для пользователей, действуют для всех. Обновление
--             набора — только новым релизом (этим файлом).
--             Idempotent: фиксированные UUID + WHERE NOT EXISTS.

INSERT INTO agent_lessons (id, scenario_id, user_id, lesson, source, approved)
SELECT 'a0000000-0000-0000-0000-000000000001', NULL, NULL,
       'Сумма акта или счёта — это «Итого» с НДС; не бери «к оплате за вычетом аванса» и не бери сам аванс.',
       'system', TRUE
WHERE NOT EXISTS (SELECT 1 FROM agent_lessons WHERE id = 'a0000000-0000-0000-0000-000000000001');

INSERT INTO agent_lessons (id, scenario_id, user_id, lesson, source, approved)
SELECT 'a0000000-0000-0000-0000-000000000002', NULL, NULL,
       'Дата подписания документа с электронной подписью — позднейшая дата в штампах подписей всех сторон.',
       'system', TRUE
WHERE NOT EXISTS (SELECT 1 FROM agent_lessons WHERE id = 'a0000000-0000-0000-0000-000000000002');

INSERT INTO agent_lessons (id, scenario_id, user_id, lesson, source, approved)
SELECT 'a0000000-0000-0000-0000-000000000003', NULL, NULL,
       'Роли и технологии исполнителей ищи в таблицах работ документа (например «Разработчик Java»), а не в описательном тексте.',
       'system', TRUE
WHERE NOT EXISTS (SELECT 1 FROM agent_lessons WHERE id = 'a0000000-0000-0000-0000-000000000003');

INSERT INTO agent_lessons (id, scenario_id, user_id, lesson, source, approved)
SELECT 'a0000000-0000-0000-0000-000000000004', NULL, NULL,
       '«Дата публикации» закупки в извещениях часто называется «дата начала срока подачи заявок» — ищи по слову «подачи».',
       'system', TRUE
WHERE NOT EXISTS (SELECT 1 FROM agent_lessons WHERE id = 'a0000000-0000-0000-0000-000000000004');

INSERT INTO agent_lessons (id, scenario_id, user_id, lesson, source, approved)
SELECT 'a0000000-0000-0000-0000-000000000005', NULL, NULL,
       'Порог сопоставимого опыта в рублях = процент из требований × НМЦ; показывай исходные числа расчёта.',
       'system', TRUE
WHERE NOT EXISTS (SELECT 1 FROM agent_lessons WHERE id = 'a0000000-0000-0000-0000-000000000005');

INSERT INTO agent_lessons (id, scenario_id, user_id, lesson, source, approved)
SELECT 'a0000000-0000-0000-0000-000000000006', NULL, NULL,
       'Периоды вида «за последние N лет» отсчитывай от даты размещения/публикации закупки, формат ДД.ММ.ГГГГ - ДД.ММ.ГГГГ.',
       'system', TRUE
WHERE NOT EXISTS (SELECT 1 FROM agent_lessons WHERE id = 'a0000000-0000-0000-0000-000000000006');
