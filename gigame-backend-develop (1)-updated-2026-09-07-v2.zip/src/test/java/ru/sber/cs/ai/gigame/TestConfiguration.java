package ru.sber.cs.ai.gigame;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;

/**
 * Test configuration for mocking external dependencies.
 */
@Profile("test")
@Configuration
public class TestConfiguration {

    @Bean
    @Primary
    public GigaChatClient mockGigaChatClient() {
        return new GigaChatClient(null, null) {
            @Override
            public String chatCompletion(java.util.List<java.util.Map<String, String>> messages) {
                return "Mocked AI response";
            }

            @Override
            public reactor.core.publisher.Flux<String> chatCompletionStream(
                    java.util.List<java.util.Map<String, String>> messages) {
                return reactor.core.publisher.Flux.just("Mocked AI response");
            }

            @Override
            public java.util.List<float[]> getEmbeddings(java.util.List<String> texts) {
                // Return 1024-dim vectors
                return texts.stream()
                        .map(t -> new float[1024])
                        .toList();
            }
        };
    }

    @Bean
    @Primary
    public EmbeddingService mockEmbeddingService() {
        return new EmbeddingService(null) {
            @Override
            public java.util.List<String> searchSimilar(String collectionType, java.util.UUID collectionId,
                                                        float[] queryEmbedding) {
                return java.util.List.of("Mocked similar chunk");
            }

            @Override
            public java.util.List<String> hybridSearch(String collectionType, java.util.UUID collectionId,
                                                       float[] queryEmbedding, String queryText) {
                return java.util.List.of("Mocked similar chunk");
            }
        };
    }
}
