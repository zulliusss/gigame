package ru.sber.cs.ai.gigame.dto.chat;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class MessageResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var convId = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var docIds = List.of("doc1", "doc2");
        var sources = List.of(new RagSource(UUID.randomUUID(), "file.pdf", "..."));
        var dto = new MessageResponse(id, convId, "assistant", "Response text", docIds, sources, now);
        assertEquals(id, dto.id());
        assertEquals(convId, dto.conversationId());
        assertEquals("assistant", dto.role());
        assertEquals("Response text", dto.content());
        assertEquals(2, dto.documentIds().size());
        assertEquals("doc1", dto.documentIds().get(0));
        assertEquals(1, dto.sources().size());
        assertEquals("file.pdf", dto.sources().get(0).documentName());
        assertEquals(now, dto.createdAt());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new MessageResponse(null, null, null, null, null, null, null);
        assertNull(dto.id());
        assertNull(dto.conversationId());
        assertNull(dto.role());
        assertNull(dto.content());
        assertNull(dto.documentIds());
        assertNull(dto.sources());
        assertNull(dto.createdAt());
    }

    @Test
    void testConstruction_withEmptyDocumentIds() {
        var dto = new MessageResponse(null, null, null, null, List.of(), null, null);
        assertTrue(dto.documentIds().isEmpty());
    }
}
