package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConversationTest {

    @Test
    void testConversationDefaultValues() {
        Conversation conversation = new Conversation();
        assertEquals("Новый диалог", conversation.getTitle());
        assertNull(conversation.getKnowledgeBaseId());
        assertNull(conversation.getUserId());
        assertTrue(conversation.getMessages().isEmpty());
    }

    @Test
    void testConversationWithCustomValues() {
        UUID userId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        OffsetDateTime createdAt = OffsetDateTime.now();

        Conversation conversation = new Conversation();
        conversation.setId(UUID.randomUUID());
        conversation.setTitle("Test Conversation");
        conversation.setKnowledgeBaseId(kbId);
        conversation.setUserId(userId.toString());
        conversation.setCreatedAt(createdAt);

        assertEquals("Test Conversation", conversation.getTitle());
        assertEquals(kbId, conversation.getKnowledgeBaseId());
        assertEquals(userId.toString(), conversation.getUserId());
        assertEquals(createdAt, conversation.getCreatedAt());
    }

    @Test
    void testConversationAddMessage() {
        Conversation conversation = new Conversation();
        Message message = new Message();
        message.setConversation(conversation);
        message.setRole("user");
        message.setContent("Hello");

        conversation.getMessages().add(message);

        assertEquals(1, conversation.getMessages().size());
        assertEquals(message, conversation.getMessages().get(0));
    }

    @Test
    void testConversationRemoveMessage() {
        Conversation conversation = new Conversation();
        Message message = new Message();
        message.setConversation(conversation);
        conversation.getMessages().add(message);

        assertEquals(1, conversation.getMessages().size());
        conversation.getMessages().remove(message);
        assertTrue(conversation.getMessages().isEmpty());
    }

    @Test
    void testToString() {
        Conversation conversation = new Conversation();
        String str = conversation.toString();
        assertNotNull(str);
        assertTrue(str.contains("Conversation"));
    }
}
