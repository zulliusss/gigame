package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.MessageRepository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MessageServiceTest {

    @Mock
    private MessageRepository messageRepository;

    @InjectMocks
    private MessageService messageService;

    @Test
    void testSaveAssistantMessage() {
        final Message[] capturedMessage = new Message[1];

        when(messageRepository.save(any(Message.class)))
                .thenAnswer(inv -> {
                    capturedMessage[0] = inv.getArgument(0);
                    return capturedMessage[0];
                });
        ReflectionTestUtils.setField(messageService, "self", messageService);

        var conversation = new Conversation();
        messageService.saveAssistantMessage(conversation, "Test response");

        verify(messageRepository).save(any(Message.class));
        assertNotNull(capturedMessage[0]);
        assertEquals("assistant", capturedMessage[0].getRole());
        assertEquals("Test response", capturedMessage[0].getContent());
        assertEquals(conversation.getId(), capturedMessage[0].getConversation().getId());
    }
}
