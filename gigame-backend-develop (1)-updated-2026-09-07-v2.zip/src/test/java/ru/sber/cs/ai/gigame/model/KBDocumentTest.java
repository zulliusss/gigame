package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KBDocumentTest {

    @Test
    void testKBDocumentDefaultValues() {
        KBDocument kbDoc = new KBDocument();
        assertNull(kbDoc.getId());
        assertNull(kbDoc.getKnowledgeBase());
        assertNull(kbDoc.getDocumentId());
        assertNull(kbDoc.getDocument());
        assertEquals(Integer.valueOf(0), kbDoc.getChunkCount());
        assertEquals("processing", kbDoc.getStatus());
        assertNull(kbDoc.getErrorMessage());
        assertNull(kbDoc.getCreatedAt());
        assertNull(kbDoc.getUpdatedAt());
    }

    @Test
    void testKBDocumentWithAllFields() {
        var kb = new KnowledgeBase();
        UUID docId = UUID.randomUUID();
        OffsetDateTime createdAt = OffsetDateTime.now();

        KBDocument kbDoc = new KBDocument();
        kbDoc.setId(UUID.randomUUID());
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        kbDoc.setChunkCount(5);
        kbDoc.setStatus("ready");
        kbDoc.setErrorMessage(null);
        kbDoc.setCreatedAt(createdAt);

        assertEquals(kb.getId(), kbDoc.getKnowledgeBase().getId());
        assertEquals(docId, kbDoc.getDocumentId());
        assertEquals(Integer.valueOf(5), kbDoc.getChunkCount());
        assertEquals("ready", kbDoc.getStatus());
        assertNull(kbDoc.getErrorMessage());
        assertEquals(createdAt, kbDoc.getCreatedAt());
    }

    @Test
    void testKBDocumentWithErrorMessage() {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setStatus("failed");
        kbDoc.setErrorMessage("Some error occurred");

        assertEquals("failed", kbDoc.getStatus());
        assertEquals("Some error occurred", kbDoc.getErrorMessage());
    }

    @Test
    void testKBDocumentGetFilename_withNullDocument() {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setDocument(null);

        assertNull(kbDoc.getFilename());
    }

    @Test
    void testKBDocumentGetFilename_withDocument() {
        KBDocument kbDoc = new KBDocument();
        Document doc = new Document();
        doc.setFilename("test.pdf");
        kbDoc.setDocument(doc);

        assertEquals("test.pdf", kbDoc.getFilename());
    }

    @Test
    void testToString() {
        KBDocument kbDoc = new KBDocument();
        String str = kbDoc.toString();
        assertNotNull(str);
        assertTrue(str.contains("KBDocument"));
    }
}
