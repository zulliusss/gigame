package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioExecutorSwitchNodeTest {

    // ================================================================
    // Constructor
    // ================================================================

    @Test
    void testConstructor() {
        var node = ScenarioRunNode.fromDto(0, makeSwitchNode("[{\"label\":\"test\",\"value\":\"test\"}]", "all"), null);
        var executor = new ScenarioExecutorSwitchNode(node);
        assertNotNull(executor);
    }

    // ================================================================
    // execute - simple text matching (parent is not loop)
    // ================================================================

    @Test
    void testExecute_textMatching_matchRoutedToCorrectBranch() {
        var switchDto = makeSwitchNode("[{\"label\":\"A\",\"value\":\"match_text\",\"operator\":\"contains\"}]", "all");
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchA = makeNode("branch-a", ScenarioNodeType.PROCESSING_NODE);
        var branchB = makeNode("branch-b", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchA, branchB),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-a", "A"),
                        edge("switch-1", "branch-b", "else")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("this contains match_text inside");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertFalse(graph.getNodeMap().get("branch-a").getInput().isEmpty());
        assertTrue(graph.getNodeMap().get("branch-b").getInput().isEmpty());
    }

    @Test
    void testExecute_textMatching_noMatch_fallsBackToElseBranch() {
        var switchDto = makeSwitchNode("[{\"label\":\"A\",\"value\":\"match_text\",\"operator\":\"contains\"}]", "all");
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchA = makeNode("branch-a", ScenarioNodeType.PROCESSING_NODE);
        var branchDefault = makeNode("branch-default", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchA, branchDefault),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-a", "A"),
                        edge("switch-1", "branch-default", "default")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("no match here");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertTrue(graph.getNodeMap().get("branch-a").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("branch-default").getInput().isEmpty());
    }

    @Test
    void testExecute_textMatching_equalsOperator() {
        var switchDto = makeSwitchNode("[{\"label\":\"Exact\",\"value\":\"exact_value\",\"operator\":\"equals\"}]", "all");
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchExact = makeNode("branch-exact", ScenarioNodeType.PROCESSING_NODE);
        var branchDefault = makeNode("branch-default", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchExact, branchDefault),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-exact", "Exact"),
                        edge("switch-1", "branch-default", "default")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("exact_value");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertFalse(graph.getNodeMap().get("branch-exact").getInput().isEmpty());
        assertTrue(graph.getNodeMap().get("branch-default").getInput().isEmpty());
    }

    @Test
    void testExecute_textMatching_startswithOperator() {
        var switchDto = makeSwitchNode("[{\"label\":\"Starts\",\"value\":\"prefix\",\"operator\":\"startswith\"}]", "all");
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchStarts = makeNode("branch-starts", ScenarioNodeType.PROCESSING_NODE);
        var branchDefault = makeNode("branch-default", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchStarts, branchDefault),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-starts", "Starts"),
                        edge("switch-1", "branch-default", "default")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("prefix_rest_of_text");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertFalse(graph.getNodeMap().get("branch-starts").getInput().isEmpty());
        assertTrue(graph.getNodeMap().get("branch-default").getInput().isEmpty());
    }

    @Test
    void testExecute_textMatching_firstMode_stopsAfterFirstMatch() {
        var switchDto = makeSwitchNode("[{\"label\":\"First\",\"value\":\"match\",\"operator\":\"contains\"},{\"label\":\"Second\",\"value\":\"match\",\"operator\":\"contains\"}]", "first");
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchFirst = makeNode("branch-first", ScenarioNodeType.PROCESSING_NODE);
        var branchSecond = makeNode("branch-second", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchFirst, branchSecond),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-first", "First"),
                        edge("switch-1", "branch-second", "Second")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("match text");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertFalse(graph.getNodeMap().get("branch-first").getInput().isEmpty());
    }

    // ================================================================
    // execute - parent is LOOP_NODE (processWhenParentLoop)
    // ================================================================

    @Test
    void testExecute_parentIsLoop_routesMultipleInputsCorrectly() {
        var switchDto = makeSwitchNode("[{\"label\":\"A\",\"value\":\"cat_a\"}]", "all");
        var loopDto = makeNode("loop-1", ScenarioNodeType.LOOP_NODE);
        var branchA = makeNode("branch-a", ScenarioNodeType.PROCESSING_NODE);
        var branchB = makeNode("branch-b", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(loopDto, switchDto, branchA, branchB),
                List.of(
                        edge("loop-1", "switch-1", null),
                        edge("switch-1", "branch-a", "A"),
                        edge("switch-1", "branch-b", "else")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("data cat_a document");
        switchNode.getInput().add("data for default branch");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertFalse(graph.getNodeMap().get("branch-a").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("branch-b").getInput().isEmpty());
    }

    @Test
    void testExecute_parentIsLoop_manyInputsWithEarlyMatch_noConcurrentModification() {
        // регресс: удаление сматченного входа во время итерации по списку
        // кидало ConcurrentModificationException при матче не-последнего
        // элемента (кейс Егоровой: 17 документов, «Документация» первой)
        var switchDto = makeSwitchNode("[{\"label\":\"A\",\"value\":\"cat_a\"}]", "all");
        var loopDto = makeNode("loop-1", ScenarioNodeType.LOOP_NODE);
        var branchA = makeNode("branch-a", ScenarioNodeType.PROCESSING_NODE);
        var branchB = makeNode("branch-b", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(loopDto, switchDto, branchA, branchB),
                List.of(
                        edge("loop-1", "switch-1", null),
                        edge("switch-1", "branch-a", "A"),
                        edge("switch-1", "branch-b", "else")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().addAll(List.of(
                "первый cat_a документ", "второй без класса",
                "третий cat_a документ", "четвёртый без класса"));

        new ScenarioExecutorSwitchNode(switchNode).execute(null);

        assertEquals(2, graph.getNodeMap().get("branch-a").getInput().size());
        assertEquals(2, graph.getNodeMap().get("branch-b").getInput().size());
        // сматченная ветка активирована — иначе планировщик её молча пропустит
        assertFalse(graph.getNodeMap().get("branch-a").getSkip());
        assertFalse(graph.getNodeMap().get("branch-b").getSkip());
    }

    // ================================================================
    // execute - classifyStrict mode (parent loop has classifyStrict=true)
    // ================================================================

    @Test
    void testExecute_classifyStrict_routesDocsByClassToCorrectBranch() {
        var switchDto = makeSwitchNode("[]", "all");
        var loopDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Loop").classifyStrict("true").classes("ТЗ,КП").build())
                .position(new PositionDto(100, 100))
                .build();
        var branchTz = makeNode("branch-tz", ScenarioNodeType.PROCESSING_NODE);
        var branchKp = makeNode("branch-kp", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(loopDto, switchDto, branchTz, branchKp),
                List.of(
                        edge("loop-1", "switch-1", null),
                        edge("switch-1", "branch-tz", "ТЗ"),
                        edge("switch-1", "branch-kp", "КП")
                ));
        var graph = new ScenarioRunGraph(gd);
        graph.addDocs(List.of("Текст ТЗ", "Текст КП"), List.of("tz.pdf", "kp.pdf"));
        graph.getDocMap().get("DOC_1").setDocClass("ТЗ");
        graph.getDocMap().get("DOC_2").setDocClass("КП");
        graph.getNodeMap().get("loop-1").getDocList().addAll(List.of("DOC_1", "DOC_2"));

        var switchNode = graph.getNodeMap().get("switch-1");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertTrue(graph.getNodeMap().get("branch-tz").getDocList().contains("DOC_1"));
        assertTrue(graph.getNodeMap().get("branch-kp").getDocList().contains("DOC_2"));
        assertFalse(graph.getNodeMap().get("branch-tz").getDocList().contains("DOC_2"));
    }

    @Test
    void testExecute_classifyStrict_defaultBranchGetsUnmatchedDocs() {
        var switchDto = makeSwitchNode("[]", "all");
        var loopDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Loop").classifyStrict("true").classes("ТЗ,КП").build())
                .position(new PositionDto(100, 100))
                .build();
        var branchTz = makeNode("branch-tz", ScenarioNodeType.PROCESSING_NODE);
        var branchDefault = makeNode("branch-default", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(loopDto, switchDto, branchTz, branchDefault),
                List.of(
                        edge("loop-1", "switch-1", null),
                        edge("switch-1", "branch-tz", "ТЗ"),
                        edge("switch-1", "branch-default", "default")
                ));
        var graph = new ScenarioRunGraph(gd);
        graph.addDocs(List.of("Текст ТЗ", "Текст КП"), List.of("tz.pdf", "kp.pdf"));
        graph.getDocMap().get("DOC_1").setDocClass("ТЗ");
        graph.getDocMap().get("DOC_2").setDocClass("КП");
        graph.getNodeMap().get("loop-1").getDocList().addAll(List.of("DOC_1", "DOC_2"));

        var switchNode = graph.getNodeMap().get("switch-1");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertTrue(graph.getNodeMap().get("branch-tz").getDocList().contains("DOC_1"));
        assertTrue(graph.getNodeMap().get("branch-default").getDocList().contains("DOC_2"));
    }

    @Test
    void testExecute_classifyStrict_marksBranchSkipped_whenNoDocsForIt() {
        var switchDto = makeSwitchNode("[]", "all");
        var loopDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Loop").classifyStrict("true").classes("ТЗ").build())
                .position(new PositionDto(100, 100))
                .build();
        var branchTz = makeNode("branch-tz", ScenarioNodeType.PROCESSING_NODE);
        var branchKp = makeNode("branch-kp", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(loopDto, switchDto, branchTz, branchKp),
                List.of(
                        edge("loop-1", "switch-1", null),
                        edge("switch-1", "branch-tz", "ТЗ"),
                        edge("switch-1", "branch-kp", "КП")
                ));
        var graph = new ScenarioRunGraph(gd);
        graph.addDocs(List.of("Текст ТЗ"), List.of("tz.pdf"));
        graph.getDocMap().get("DOC_1").setDocClass("ТЗ");
        graph.getNodeMap().get("loop-1").getDocList().add("DOC_1");

        var switchNode = graph.getNodeMap().get("switch-1");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertTrue(graph.getNodeMap().get("branch-tz").getDocList().contains("DOC_1"));
        assertFalse(graph.getNodeMap().get("branch-tz").getSkip());
        assertTrue(graph.getNodeMap().get("branch-kp").getSkip());
    }

    // ================================================================
    // execute - stores output
    // ================================================================

    @Test
    void testExecute_storesOutputInNode() {
        var switchDto = makeSwitchNode("[{\"label\":\"A\",\"value\":\"text\"}]", "all");
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchA = makeNode("branch-a", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchA),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-a", "A")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("text to match");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertNotNull(switchNode.getOutput());
    }

    // ================================================================
    // execute - parse rules from string
    // ================================================================

    @Test
    void testExecute_parsesRulesFromString() {
        var switchDto = NodeDto.builder()
                .id("switch-1")
                .type(ScenarioNodeType.SWITCH_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Switch")
                        .rules("[{\"label\":\"Parsed\",\"value\":\"test\"}]")
                        .mode("all")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchParsed = makeNode("branch-parsed", ScenarioNodeType.PROCESSING_NODE);
        var branchDefault = makeNode("branch-default", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchParsed, branchDefault),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-parsed", "Parsed"),
                        edge("switch-1", "branch-default", "default")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("this is a test");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertFalse(graph.getNodeMap().get("branch-parsed").getInput().isEmpty());
    }

    @Test
    void testExecute_handlesInvalidRulesGracefully() {
        var switchDto = NodeDto.builder()
                .id("switch-1")
                .type(ScenarioNodeType.SWITCH_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Switch")
                        .rules("invalid json")
                        .mode("all")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var inputNode = makeNode("input-1", ScenarioNodeType.INPUT_NODE);
        var branchDefault = makeNode("branch-default", ScenarioNodeType.PROCESSING_NODE);
        var gd = new GraphDataDto(List.of(inputNode, switchDto, branchDefault),
                List.of(
                        edge("input-1", "switch-1", null),
                        edge("switch-1", "branch-default", "default")
                ));
        var graph = new ScenarioRunGraph(gd);
        var switchNode = graph.getNodeMap().get("switch-1");
        switchNode.getInput().add("test");
        new ScenarioExecutorSwitchNode(switchNode).execute(null);
        assertNotNull(switchNode.getOutput());
    }

    // ================================================================
    // Helpers
    // ================================================================

    private static NodeDto makeSwitchNode(String rules, String mode) {
        return NodeDto.builder()
                .id("switch-1")
                .type(ScenarioNodeType.SWITCH_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Switch")
                        .rules(rules)
                        .mode(mode)
                        .build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static NodeDto makeNode(String id, ScenarioNodeType type) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(id).build())
                .position(new PositionDto(100, 100))
                .build();
    }

    private static EdgeDto edge(String src, String tgt, String label) {
        return new EdgeDto(src + "-" + tgt, src, tgt, new EdgeDataDto(label));
    }
}