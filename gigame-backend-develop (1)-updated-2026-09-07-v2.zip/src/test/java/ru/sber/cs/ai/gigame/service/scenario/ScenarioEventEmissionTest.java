package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioEventType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScenarioEventEmissionTest {

    @Mock
    private ScenarioRunNode node;

    @Mock
    private ScenarioRunStep step;

    private UUID runId;
    private UUID kbId;
    private int total;

    @BeforeEach
    void setUp() {
        runId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        total = 3;

        // Setup node mock
        lenient().when(node.getId()).thenReturn("node-1");
        lenient().when(node.getType()).thenReturn(ScenarioNodeType.PROCESSING_NODE);
        lenient().when(node.getLabel()).thenReturn("Test Node");
        lenient().when(node.getIndex()).thenReturn(1);
        lenient().when(node.getTotal()).thenReturn(total);
        lenient().when(node.getKnowledgeBaseId()).thenReturn(kbId);
    }

    // -------------------------------------------------------------------------
    // Status Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitStatusEvent_withResult() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitStatusEvent(sink, runId, ScenarioStatus.COMPLETED, "Final Result");
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event.data());
                    assertEquals("status", event.data().get("type").toString());
                    assertEquals(runId.toString(), event.data().get("run_id"));
                    assertEquals("completed", event.data().get("status").toString());
                    assertEquals("Final Result", event.data().get("result").toString());
                })
                .verifyComplete();
    }

    @Test
    void testEmitStatusEvent_withoutResult() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitStatusEvent(sink, runId, ScenarioStatus.RUNNING, null);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("status", event.data().get("type").toString());
                    assertEquals(runId.toString(), event.data().get("run_id").toString());
                    assertEquals("running", event.data().get("status").toString());
                    assertTrue(event.data().get("result") == null || event.data().get("result").toString().isEmpty());
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // Node Status Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitNodeStatusEvent() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitNodeStatusEvent(sink, node, ScenarioStatus.RUNNING);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("node_status", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals("Test Node", event.data().get("node_label").toString());
                    assertEquals("processing", event.data().get("node_type").toString());
                    assertEquals("running", event.data().get("status").toString());
                    assertEquals(1, event.data().get("step"));
                    assertEquals(3, event.data().get("total"));
                })
                .verifyComplete();
    }

    @Test
    void testEmitNodeErrorEvent() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitNodeErrorEvent(sink, node, "Test error message", total);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("node_status", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals("Test error message", event.data().get("error").toString());
                    assertEquals("failed", event.data().get("status").toString());
                    assertEquals(1, event.data().get("step"));
                    assertEquals(3, event.data().get("total"));
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // Switch Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitSwitchResultEvent() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitSwitchResultEvent(sink, node, "rule-1 matched");
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("switch_result", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals("Test Node", event.data().get("node_label").toString());
                    assertEquals("rule-1 matched", event.data().get("matched_rule").toString());
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // Loop Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitLoopProgressEvent_withDetail() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitLoopProgressEvent(sink, node, 2, 5, "Processing document 2 of 5");
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("loop_progress", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals(2, event.data().get("iteration"));
                    assertEquals(5, event.data().get("total"));
                    assertEquals("Processing document 2 of 5", event.data().get("detail").toString());
                })
                .verifyComplete();
    }

    @Test
    void testEmitLoopProgressEvent_withoutDetail() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitLoopProgressEvent(sink, node, 1, 3, null);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("loop_progress", event.data().get("type").toString());
                    assertEquals(1, event.data().get("iteration"));
                    assertEquals(3, event.data().get("total"));
                    assertNull(event.data().get("detail"));
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // If Node Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitIfResultEvent_withConditionMet() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitIfResultEvent(sink, node, true, "true-branch");
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("if_result", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals(true, event.data().get("condition_met"));
                    assertEquals("true-branch", event.data().get("branch").toString());
                })
                .verifyComplete();
    }

    @Test
    void testEmitIfResultEvent_withoutConditionMet() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitIfResultEvent(sink, node, false, "false-branch");
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("if_result", event.data().get("type").toString());
                    assertEquals(false, event.data().get("condition_met"));
                    assertEquals("false-branch", event.data().get("branch").toString());
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // RAG Search Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitRagSearchEvent() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitRagSearchEvent(sink, node, 5);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("rag_search", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals(kbId.toString(), event.data().get("kb_id").toString());
                    assertEquals(5, event.data().get("chunks_found"));
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // Step Complete Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitStepCompleteEvent() {
        when(step.getId()).thenReturn(UUID.randomUUID());
        lenient().when(step.getNodeId()).thenReturn("node-1");
        when(step.getNodeType()).thenReturn("processing");
        when(step.getInputData()).thenReturn(Map.of("key", "value"));
        when(step.getOutputData()).thenReturn(Map.of("result", "output"));
        when(step.getPromptUsed()).thenReturn("prompt text");

        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitStepCompleteEvent(sink, node, step);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("step_complete", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals("Test Node", event.data().get("node_label").toString());
                    assertEquals("processing", event.data().get("node_type").toString());
                    assertEquals(Map.of("key", "value"), event.data().get("input_data"));
                    assertEquals(Map.of("result", "output"), event.data().get("output_data"));
                    assertEquals("prompt text", event.data().get("prompt_used").toString());
                    assertEquals(1, event.data().get("step_index"));
                    assertEquals(3, event.data().get("total_steps"));
                })
                .verifyComplete();
    }

    @Test
    void testEmitStatusEvent_bigFinalResultTrimmedToPreview() {
        // финальный кадр STATUS нёс полный результат прогона (сотни КБ на
        // сценариях с формами), UI показывает 600 символов
        String bigResult = "И".repeat(200_000);
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitStatusEvent(sink, UUID.randomUUID(),
                    ScenarioStatus.COMPLETED, bigResult);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    String result = event.data().get("result").toString();
                    assertTrue(result.length()
                            < ScenarioEventEmission.PREVIEW_RESULT + 100);
                    assertTrue(result.contains("показано начало"));
                })
                .verifyComplete();
    }

    @Test
    @SuppressWarnings("unchecked")
    void testEmitStepCompleteEvent_bigDataTrimmedToPreview() {
        // полные тексты в STEP_COMPLETE раздували WS-кадр до мегабайт и
        // валили корп. SOWA; в сокет уходит превью, полные данные — ручкой
        String bigDocs = "Д".repeat(400_000);
        String bigResult = "Р".repeat(50_000);
        String bigPrompt = "П".repeat(20_000);
        when(step.getId()).thenReturn(UUID.randomUUID());
        when(step.getNodeType()).thenReturn("processing");
        when(step.getInputData()).thenReturn(Map.of(
                "documents_text", bigDocs, "previous_output", "короткий"));
        when(step.getOutputData()).thenReturn(Map.of("result", bigResult));
        when(step.getPromptUsed()).thenReturn(bigPrompt);

        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitStepCompleteEvent(sink, node, step);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    var input = (Map<String, String>) event.data().get("input_data");
                    var output = (Map<String, String>) event.data().get("output_data");
                    String prompt = event.data().get("prompt_used").toString();
                    assertTrue(input.get("documents_text").length()
                            < ScenarioEventEmission.PREVIEW_DOCS + 100);
                    assertTrue(input.get("documents_text").contains("показано начало"));
                    assertEquals("короткий", input.get("previous_output"));
                    assertTrue(output.get("result").length()
                            < ScenarioEventEmission.PREVIEW_RESULT + 100);
                    assertTrue(prompt.length()
                            < ScenarioEventEmission.PREVIEW_PROMPT + 100);
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // Step Paused Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitStepPausedEvent() {
        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitStepPausedEvent(sink, node, total);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("step_paused", event.data().get("type").toString());
                    assertEquals("node-1", event.data().get("node_id").toString());
                    assertEquals("Test Node", event.data().get("node_label").toString());
                    assertEquals("processing", event.data().get("node_type").toString());
                    assertEquals(3, event.data().get("total_steps"));
                })
                .verifyComplete();
    }

    // -------------------------------------------------------------------------
    // File Output Events
    // -------------------------------------------------------------------------

    @Test
    void testEmitFileOutputEvent_excel() {
        // node with mode="excel"
        var nodeDto = NodeDto.builder()
                .id("node-output-1")
                .type("output")
                .data(NodeDataDto.builder()
                        .label("Output Node")
                        .mode("excel")
                        .build())
                .build();
        var fileNode = new ScenarioRunNode(nodeDto);

        var jsonData = "[{\"name\":\"Alice\",\"age\":30},{\"name\":\"Bob\",\"age\":25}]";

        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitFileOutputEvent(sink, fileNode, jsonData);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("file_output", event.data().get("type").toString());
                    assertEquals("node-output-1", event.data().get("node_id").toString());
                    assertEquals("Output Node", event.data().get("node_label").toString());
                    assertEquals("result.xlsx", event.data().get("filename").toString());
                    assertEquals(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            event.data().get("mime_type").toString());
                    // в кадре только «файл готов» — байты забираются ручкой
                    // GET /runs/{runId}/files/{nodeId}
                    assertEquals(Boolean.TRUE, event.data().get("file_ready"));
                    assertNull(event.data().get("content"));
                })
                .verifyComplete();
    }

    @Test
    void testEmitFileOutputEvent_textFile() {
        // node with mode="text_file"
        var nodeDto = NodeDto.builder()
                .id("node-output-2")
                .type("output")
                .data(NodeDataDto.builder()
                        .label("Text Output")
                        .mode("text_file")
                        .build())
                .build();
        var fileNode = new ScenarioRunNode(nodeDto);

        var textResult = "Hello, world!\nThis is a text file.";

        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitFileOutputEvent(sink, fileNode, textResult);
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertNotNull(event);
                    assertNotNull(event.data());
                    assertEquals("file_output", event.data().get("type").toString());
                    assertEquals("node-output-2", event.data().get("node_id").toString());
                    assertEquals("Text Output", event.data().get("node_label").toString());
                    assertEquals("result.txt", event.data().get("filename").toString());
                    assertEquals("text/plain", event.data().get("mime_type").toString());
                    assertEquals(Boolean.TRUE, event.data().get("file_ready"));
                    assertNull(event.data().get("content"));
                })
                .verifyComplete();
    }

    @Test
    void testEmitFileOutputEvent_textMode() {
        // в живых сценариях текстовый выход хранится и как mode="text"
        var nodeDto = NodeDto.builder()
                .id("node-output-3")
                .type("output")
                .data(NodeDataDto.builder()
                        .label("Text Output")
                        .mode("text")
                        .build())
                .build();
        var fileNode = new ScenarioRunNode(nodeDto);

        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitFileOutputEvent(sink, fileNode, "plain text");
            sink.complete();
        });

        StepVerifier.create(flux)
                .assertNext(event -> {
                    assertEquals("result.txt", event.data().get("filename").toString());
                    assertEquals("text/plain", event.data().get("mime_type").toString());
                    assertEquals(Boolean.TRUE, event.data().get("file_ready"));
                    assertNull(event.data().get("content"));
                })
                .verifyComplete();
    }

    @Test
    void testEmitFileOutputEvent_nullMode_shouldNotEmit() {
        // node with mode=null — method should return early without emitting
        when(node.getMode()).thenReturn(null);

        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitFileOutputEvent(sink, node, "some result");
            sink.complete();
        });

        StepVerifier.create(flux)
                .expectComplete()
                .verify();
    }

    @Test
    void testEmitFileOutputEvent_unknownMode_shouldNotEmit() {
        when(node.getMode()).thenReturn("unknown");

        var flux = Flux.<ServerSentEvent<Map<String, Object>>>create(sink -> {
            ScenarioEventEmission.emitFileOutputEvent(sink, node, "some result");
            sink.complete();
        });

        StepVerifier.create(flux)
                .expectComplete()
                .verify();
    }

    // -------------------------------------------------------------------------
    // Event Type Enum Tests
    // -------------------------------------------------------------------------

    @Test
    void testScenarioEventTypeValues() {
        assertEquals("status", ScenarioEventType.STATUS.toString());
        assertEquals("node_status", ScenarioEventType.NODE_STATUS.toString());
        assertEquals("loop_progress", ScenarioEventType.LOOP_PROGRESS.toString());
        assertEquals("switch_result", ScenarioEventType.SWITCH_RESULT.toString());
        assertEquals("if_result", ScenarioEventType.IF_RESULT.toString());
        assertEquals("step_complete", ScenarioEventType.STEP_COMPLETE.toString());
        assertEquals("step_paused", ScenarioEventType.STEP_PAUSED.toString());
        assertEquals("rag_search", ScenarioEventType.RAG_SEARCH.toString());
    }
}