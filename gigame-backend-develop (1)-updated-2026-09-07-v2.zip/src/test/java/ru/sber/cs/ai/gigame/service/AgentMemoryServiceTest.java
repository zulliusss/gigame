package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.repository.AgentLessonRepository;
import ru.sber.cs.ai.gigame.repository.AgentPlanRepository;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты памяти агента: уроки (частные/общие), планы (хэш задания),
 * вопросы (ответ превращается в урок), рефлексия-сжатие.
 */
@ExtendWith(MockitoExtension.class)
class AgentMemoryServiceTest {

    @Mock
    private AgentLessonRepository lessonRepository;
    @Mock
    private AgentPlanRepository planRepository;
    @Mock
    private AgentQuestionRepository questionRepository;
    @Mock
    private GigaChatClient gigaChatClient;
    @Mock
    private ScenarioRepository scenarioRepository;

    @InjectMocks
    private AgentMemoryService service;

    private static AgentLesson lesson(UUID scenarioId, String text, boolean approved) {
        AgentLesson l = new AgentLesson();
        l.setId(UUID.randomUUID());
        l.setScenarioId(scenarioId);
        l.setLesson(text);
        l.setApproved(approved);
        return l;
    }

    @Test
    void lessonsForScenario_combinesSystemPersonalAndScenarioLayers() {
        UUID sid = UUID.randomUUID();
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(lesson(null, "системный урок", true)));
        when(lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc(
                "RUNNER", AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(lesson(null, "личный общий урок", true)));
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid))
                .thenReturn(List.of(lesson(sid, "урок сценария", true)));

        List<String> lessons = service.lessonsForScenario(sid, "RUNNER");

        assertEquals(List.of("системный урок", "личный общий урок", "урок сценария"), lessons);
    }

    @Test
    void lessonsForScenario_anonymousGetsNoPersonalLayer() {
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                AgentLesson.SOURCE_SYSTEM))
                .thenReturn(List.of(lesson(null, "системный урок", true)));

        assertEquals(List.of("системный урок"), service.lessonsForScenario(null, null));
    }

    @Test
    void systemLesson_cannotBeModified() {
        AgentLesson system = lesson(null, "системный", true);
        system.setSource(AgentLesson.SOURCE_SYSTEM);
        when(lessonRepository.findById(system.getId())).thenReturn(Optional.of(system));

        assertThrows(IllegalArgumentException.class,
                () -> service.updateLesson(system.getId(), "правка"));
        assertThrows(IllegalArgumentException.class,
                () -> service.deleteLesson(system.getId()));
    }

    @Test
    void addLesson_userLessonsActiveImmediately() {
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));
        UUID sid = UUID.randomUUID();
        var scenario = new Scenario();
        scenario.setUserId("U");
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenario));

        CurrentUserHolder.withUser("U", () -> {
            AgentLessonResponseDto scenarioLesson =
                    service.addLesson(sid, "урок сценария", null);
            // личный общий урок действует только на запуски владельца — активен сразу
            AgentLessonResponseDto personal = service.addLesson(null, "личный общий урок", null);

            assertTrue(scenarioLesson.approved());
            assertTrue(personal.approved());
            assertThrows(IllegalArgumentException.class,
                    () -> service.addLesson(null, " ", null));
            return null;
        });
    }

    @Test
    void planRoundTrip_saveAndFindByNormalizedHash() {
        when(planRepository.findFirstByTaskHashOrderByUsesDesc(any()))
                .thenReturn(Optional.empty());
        when(planRepository.save(any(AgentPlan.class))).thenAnswer(inv -> inv.getArgument(0));
        UUID sid = UUID.randomUUID();
        service.savePlan(sid, "Найди  НМЦ\nв извещении", List.of("пункт 1", "пункт 2"));

        // то же задание с другими пробелами/регистром — тот же хэш
        String h1 = AgentMemoryService.taskHash("Найди  НМЦ\nв извещении");
        String h2 = AgentMemoryService.taskHash("найди нмц в извещении");
        assertEquals(h1, h2);

        AgentPlan saved = new AgentPlan();
        saved.setPlan("[\"пункт 1\", \"пункт 2\"]");
        saved.setUses(0);
        when(planRepository.findFirstByTaskHashOrderByUsesDesc(h1))
                .thenReturn(Optional.of(saved));

        List<String> found = service.findPlan("НАЙДИ НМЦ В ИЗВЕЩЕНИИ");

        assertEquals(List.of("пункт 1", "пункт 2"), found);
        assertEquals(1, saved.getUses());
    }

    @Test
    void answerQuestion_savesAnswerAndCreatesScenarioLesson() {
        UUID qid = UUID.randomUUID();
        UUID sid = UUID.randomUUID();
        AgentQuestion question = new AgentQuestion();
        question.setId(qid);
        question.setScenarioId(sid);
        question.setQuestion("Где искать дату публикации?");
        when(questionRepository.findById(qid)).thenReturn(Optional.of(question));
        when(questionRepository.save(any(AgentQuestion.class))).thenAnswer(inv -> inv.getArgument(0));
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        CurrentUserHolder.withUser("U", () -> {
            AgentQuestion answered = service.answerQuestion(qid,
                    "дата публикации = «дата начала срока подачи заявок»");

            assertNotNull(answered.getAnsweredAt());
            verify(lessonRepository).save(any(AgentLesson.class));
            return null;
        });
    }

    @Test
    void extractLessonsFromRun_savesUnapprovedReviserCandidates() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"сумма акта — Итого с НДС, не аванс\"]");
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        var saved = service.extractLessonsFromRun(UUID.randomUUID(),
                Map.of("критик", "РАСХОЖДЕНИЕ: сумма акта — взят аванс"));

        assertEquals(1, saved.size());
        assertEquals(AgentLesson.SOURCE_REVISER, saved.get(0).source());
        assertEquals(false, saved.get(0).approved());
    }

    @Test
    void extractLessonsFromRun_filtersGenericAndDuplicateCandidates() {
        UUID sid = UUID.randomUUID();
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Проверяйте соответствие сумм актов документам\", "
                        + "\"Сумма акта — это «Итого» с НДС\", "
                        + "\"дата публикации = дата начала срока подачи заявок\"]");
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid))
                .thenReturn(List.of(lesson(sid, "Сумма акта — это «Итого» с НДС", true)));
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        var saved = service.extractLessonsFromRun(sid, Map.of("критик", "правки"));

        // банальный призыв отсечён, дубликат существующего урока пропущен,
        // конкретное новое правило сохранено
        assertEquals(1, saved.size());
        assertTrue(saved.get(0).lesson().contains("дата публикации"));
    }

    @Test
    void similarLesson_catchesRephrasedDuplicates() {
        // перефраз системного урока — дубликат (наблюдалось: extract вернул
        // системное правило другими словами, и дедуп по вхождению его пропустил)
        assertTrue(AgentMemoryService.similarLesson(
                "Сумма акта — это строка 'Итого' с НДС, а не к оплате за вычетом аванса",
                "Сумма акта или счёта — это «Итого» с НДС; не бери «к оплате за вычетом "
                        + "аванса» и не бери сам аванс."));
        assertFalse(AgentMemoryService.similarLesson(
                "дата публикации = дата начала срока подачи заявок",
                "Сумма акта — это «Итого» с НДС"));
    }

    @Test
    void specificLesson_rejectsGenericAdvice() {
        assertFalse(AgentMemoryService.specificLesson(
                "Обращайте внимание на наличие актов и их содержание"));
        assertFalse(AgentMemoryService.specificLesson(
                "Следите за корректностью расчёта общей суммы опыта"));
        // без цифр/кавычек/соответствия — тоже не урок
        assertFalse(AgentMemoryService.specificLesson(
                "Технологии подтверждаются актами"));
        assertTrue(AgentMemoryService.specificLesson(
                "Сумма акта — это «Итого» с НДС, не аванс"));
        assertTrue(AgentMemoryService.specificLesson(
                "дата публикации = дата начала срока подачи заявок"));
    }

    @Test
    void lessonsForScenario_skipsUnapprovedCandidates() {
        UUID sid = UUID.randomUUID();
        AgentLesson candidate = lesson(sid, "кандидат", true);
        candidate.setApproved(false);
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid))
                .thenReturn(List.of(candidate, lesson(sid, "одобренный", true)));
        when(lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                AgentLesson.SOURCE_SYSTEM)).thenReturn(List.of());

        assertEquals(List.of("одобренный"), service.lessonsForScenario(sid, null));
    }

    @Test
    void scenarioMemory_mutationsRequireScenarioAuthor() {
        UUID sid = UUID.randomUUID();
        var scenario = new Scenario();
        scenario.setUserId("AUTHOR");
        when(scenarioRepository.findById(sid)).thenReturn(Optional.of(scenario));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("STRANGER",
                        () -> service.addLesson(sid, "урок", null)));
    }

    @Test
    void compressLessons_replacesWithDistilledRules() {
        UUID sid = UUID.randomUUID();
        when(lessonRepository.findByScenarioIdOrderByCreatedAtDesc(sid)).thenReturn(List.of(
                lesson(sid, "урок 1", true), lesson(sid, "урок 2", true), lesson(sid, "урок 3", true)));
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"сжатое правило\"]");
        when(lessonRepository.save(any(AgentLesson.class))).thenAnswer(inv -> inv.getArgument(0));

        CurrentUserHolder.withUser("U", () -> {
            List<AgentLessonResponseDto> compressed = service.compressLessons(sid);

            assertEquals(1, compressed.size());
            assertEquals("сжатое правило", compressed.get(0).lesson());
            assertEquals(AgentLesson.SOURCE_AUTO, compressed.get(0).source());
            verify(lessonRepository).deleteAll(anyList());
            return null;
        });
    }
}
