package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioRunStepTest {

    @Test
    void testScenarioRunStepDefaultValues() {
        ScenarioRunStep step = new ScenarioRunStep();
        assertNull(step.getId());
        assertNull(step.getRunId());
        assertNull(step.getNodeId());
        assertNull(step.getNodeType());
        assertEquals("pending", step.getStatus());
        assertNull(step.getInputData());
        assertNull(step.getOutputData());
        assertNull(step.getPromptUsed());
        assertNull(step.getTokensUsed());
        assertNull(step.getStartedAt());
        assertNull(step.getCompletedAt());
    }

    @Test
    void testScenarioRunStepWithAllFields() {
        UUID id = UUID.randomUUID();
        UUID runId = UUID.randomUUID();
        OffsetDateTime startedAt = OffsetDateTime.now();

        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(id);
        step.setRunId(runId);
        step.setNodeId("node1");
        step.setNodeType("input");
        step.setStatus("running");
        step.setInputData(Map.of("key", "value"));
        step.setOutputData(Map.of("result", "output"));
        step.setPromptUsed("Test prompt");
        step.setTokensUsed(100);
        step.setStartedAt(startedAt);

        assertEquals(id, step.getId());
        assertEquals(runId, step.getRunId());
        assertEquals("node1", step.getNodeId());
        assertEquals("input", step.getNodeType());
        assertEquals("running", step.getStatus());
        assertNotNull(step.getInputData());
        assertNotNull(step.getOutputData());
        assertEquals("Test prompt", step.getPromptUsed());
        assertEquals(Integer.valueOf(100), step.getTokensUsed());
        assertEquals(startedAt, step.getStartedAt());
    }

    @Test
    void testScenarioRunStepWithCompletedStatus() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setStatus("completed");
        step.setCompletedAt(OffsetDateTime.now());

        assertEquals("completed", step.getStatus());
        assertNotNull(step.getCompletedAt());
    }

    @Test
    void testScenarioRunStepWithNullPrompt() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setPromptUsed(null);

        assertNull(step.getPromptUsed());
    }

    @Test
    void testScenarioRunStepWithEmptyInputData() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setInputData(Map.of());

        assertTrue(step.getInputData().isEmpty());
    }

    @Test
    void testScenarioRunStepWithLoopType() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setNodeType("loop");
        step.setPromptUsed("(loop — см. итерации)");

        assertEquals("loop", step.getNodeType());
    }

    @Test
    void testScenarioRunStepWithSwitchType() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setNodeType("switch");
        step.setPromptUsed(null);

        assertEquals("switch", step.getNodeType());
    }

    @Test
    void testToString() {
        ScenarioRunStep step = new ScenarioRunStep();
        String str = step.toString();
        assertNotNull(str);
        assertTrue(str.contains("ScenarioRunStep"));
    }
}
