package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Document;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class DocumentRepositoryTest {

    @Autowired
    private DocumentRepository underTest;

    @Test
    void testFindById_returnsDocument() {
        Document document = new Document();
        document.setFilename("test.pdf");
        document.setExtractedText("Content");
        underTest.save(document);

        Document found = underTest.findById(document.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("test.pdf", found.getFilename());
    }

    @Test
    void testSaveAndDelete() {
        Document document = new Document();
        document.setFilename("delete.pdf");
        document.setExtractedText("Content");

        Document saved = underTest.save(document);
        assertNotNull(saved.getId());

        underTest.delete(saved);
        assertFalse(underTest.findById(saved.getId()).isPresent());
    }
}
