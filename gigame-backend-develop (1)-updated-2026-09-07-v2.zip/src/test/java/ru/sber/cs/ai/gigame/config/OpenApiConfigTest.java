package ru.sber.cs.ai.gigame.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Method;
import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for {@link OpenApiConfig} — verifies OpenAPI 3.0 bean definitions
 * (GroupedOpenApi groups, Info, Contact, Servers, and customizer).
 */
class OpenApiConfigTest {

    private final OpenApiConfig config = new OpenApiConfig();

    @Test
    @DisplayName("OpenApiConfig should be a valid Spring @Configuration class")
    void configShouldBeConfigurationClass() {
        assertThat(OpenApiConfig.class.getAnnotation(Configuration.class))
                .isNotNull();
    }

    @Test
    @DisplayName("Should have @Slf4j annotation generating log field")
    void configShouldHaveSlf4j() {
        // @Slf4j is a compile-time annotation; Lombok generates:
        // private static final org.slf4j.Logger log = ...
        boolean hasLogField = java.util.Arrays.stream(OpenApiConfig.class.getDeclaredFields())
                .anyMatch(f -> "log".equals(f.getName())
                        && f.getType().isInterface());
        assertThat(hasLogField).isTrue();
    }

    @Test
    @DisplayName("Should create exactly 5 GroupedOpenApi beans")
    void shouldCreateFiveGroupedOpenApiBeans() {
        List<GroupedOpenApi> beans = List.of(
                config.actuatorApi(),
                config.chatApi(),
                config.documentApi(),
                config.knowledgeBaseApi(),
                config.scenarioApi()
        );

        assertThat(beans).hasSize(5);

        List<String> groups = beans.stream()
                .map(GroupedOpenApi::getGroup)
                .toList();

        assertThat(groups)
                .containsExactlyInAnyOrder(
                        "actuator", "chat", "documents", "knowledge-base", "scenarios");
    }

    @Test
    @DisplayName("actuatorApi bean should have correct group and paths")
    void actuatorApi_shouldHaveCorrectGroupAndPaths() {
        GroupedOpenApi bean = config.actuatorApi();

        assertThat(bean.getGroup()).isEqualTo("actuator");
        assertThat(bean.getDisplayName()).isEqualTo("💀 Актуатор");
        assertThat(bean.getPathsToMatch()).containsExactly("/actuator/**");
    }

    @Test
    @DisplayName("chatApi bean should have correct group and paths")
    void chatApi_shouldHaveCorrectGroupAndPaths() {
        GroupedOpenApi bean = config.chatApi();

        assertThat(bean.getGroup()).isEqualTo("chat");
        assertThat(bean.getDisplayName()).isEqualTo("💬 Чат");
        assertThat(bean.getPathsToMatch()).containsExactly("/api/conversations/**");
    }

    @Test
    @DisplayName("documentApi bean should have correct group and paths")
    void documentApi_shouldHaveCorrectGroupAndPaths() {
        GroupedOpenApi bean = config.documentApi();

        assertThat(bean.getGroup()).isEqualTo("documents");
        assertThat(bean.getDisplayName()).isEqualTo("📁 Документы");
        assertThat(bean.getPathsToMatch()).containsExactly("/api/documents/**");
    }

    @Test
    @DisplayName("knowledgeBaseApi bean should have correct group and paths")
    void knowledgeBaseApi_shouldHaveCorrectGroupAndPaths() {
        GroupedOpenApi bean = config.knowledgeBaseApi();

        assertThat(bean.getGroup()).isEqualTo("knowledge-base");
        assertThat(bean.getDisplayName()).isEqualTo("🧠 Базы знаний");
        assertThat(bean.getPathsToMatch()).containsExactly("/api/knowledge-bases/**");
    }

    @Test
    @DisplayName("scenarioApi bean should have correct group and paths")
    void scenarioApi_shouldHaveCorrectGroupAndPaths() {
        GroupedOpenApi bean = config.scenarioApi();

        assertThat(bean.getGroup()).isEqualTo("scenarios");
        assertThat(bean.getDisplayName()).isEqualTo("⚙️ Сценарии");
        assertThat(bean.getPathsToMatch())
                .containsExactlyInAnyOrder("/api/scenarios/**", "/api/scenario-runs/**");
    }

    @Test
    @DisplayName("customOpenAPI bean should have correct Info metadata")
    void customOpenAPI_shouldHaveCorrectInfo() {
        OpenAPI openAPI = config.customOpenAPI();

        Info info = openAPI.getInfo();
        assertThat(info).isNotNull();
        assertThat(info.getTitle()).isEqualTo("GigaMe Backend API");
        assertThat(info.getVersion()).isEqualTo("1.0");

        Contact contact = info.getContact();
        assertThat(contact).isNotNull();
        assertThat(contact.getName()).isEqualTo("Железнов Максим");
        assertThat(contact.getEmail())
                .isEqualTo("Zheleznov.M.Yu@sberbank.ru");
    }

    @Test
    @DisplayName("customOpenAPI bean should have localhost development server")
    void customOpenAPI_shouldHaveLocalhostServer() {
        OpenAPI openAPI = config.customOpenAPI();

        List<Server> servers = openAPI.getServers();
        assertThat(servers).isNotEmpty();

        Server server = servers.get(0);
        assertThat(server.getUrl()).contains("localhost");
        assertThat(server.getDescription()).isEqualTo("Локальный сервер разработки");
    }

    @Test
    @DisplayName("customOpenAPI should contain description with key features")
    void customOpenAPI_shouldHaveDescriptionWithFeatures() {
        OpenAPI openAPI = config.customOpenAPI();
        String description = openAPI.getInfo().getDescription();

        assertThat(description).isNotNull()
                .contains("GigaMe")
                .contains("Чат")
                .contains("RAG")
                .contains("Сценарии")
                .contains("Базы знаний");
    }

    @Test
    @DisplayName("changeSomeProperties bean should return OpenApiCustomizer")
    void changeSomeProperties_shouldReturnOpenApiCustomizer() {
        OpenApiCustomizer customizer = config.changeSomeProperties();
        assertThat(customizer).isNotNull();
    }

    @Test
    @DisplayName("Should declare all expected @Bean methods")
    void shouldHaveExpectedBeanMethods() {
        List<String> beanMethodNames = List.of(
                "actuatorApi", "chatApi", "documentApi",
                "knowledgeBaseApi", "scenarioApi",
                "customOpenAPI", "changeSomeProperties"
        );

        List<String> actualBeanMethods = Stream.of(OpenApiConfig.class.getDeclaredMethods())
                .filter(m -> m.isAnnotationPresent(Bean.class))
                .map(Method::getName)
                .toList();

        assertThat(actualBeanMethods).containsExactlyInAnyOrderElementsOf(beanMethodNames);
    }
}
