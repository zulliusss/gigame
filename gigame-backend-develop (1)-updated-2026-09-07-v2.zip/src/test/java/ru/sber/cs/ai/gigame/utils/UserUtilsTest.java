package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class UserUtilsTest {

    @Test
    void testCheckUserId_withMatchingIds_doesNotThrow() {
        assertDoesNotThrow(() -> UserUtils.checkUserId("user123", "user123"));
    }

    @Test
    void testCheckUserId_withNonMatchingIds_throwsAccessDeniedException() {
        assertThrows(AccessDeniedException.class,
                () -> UserUtils.checkUserId("user123", "user456"));
    }

    @Test
    void testCheckUserId_withNullUserId_andNonMatchingActual_throwsAccessDeniedException() {
        assertThrows(AccessDeniedException.class,
                () -> UserUtils.checkUserId(null, "user456"));
    }

    @Test
    void testCheckUserId_withNullUserId_andMatchingActual_doesNotThrow() {
        assertDoesNotThrow(() -> UserUtils.checkUserId(null, "anonymous"));
    }
}
