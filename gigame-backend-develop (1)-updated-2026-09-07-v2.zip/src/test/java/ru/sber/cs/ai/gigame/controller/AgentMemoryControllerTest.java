package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты типизированных DTO-запросов памяти агента: тела запросов
 * десериализуются из snake_case JSON без Map (требование СОВЫ).
 */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {AgentMemoryController.class, TestConfiguration.class})
@WebFluxTest(controllers = AgentMemoryController.class)
// холодный старт контекста на нагруженной машине превышает дефолтные 5с
@AutoConfigureWebTestClient(timeout = "30000")
class AgentMemoryControllerTest {

    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private AgentMemoryService memoryService;
    @MockitoBean
    private ScenarioRunRepository runRepository;
    @MockitoBean
    private ScenarioRunStepRepository stepRepository;

    private String userId;
    private AgentLesson lessonEntity;

    @BeforeEach
    void setUp() {
        userId = "test-user";
        lessonEntity = new AgentLesson();
        lessonEntity.setId(UUID.randomUUID());
        lessonEntity.setLesson("Суммы брать из УПД");
    }

    @Test
    void addLesson_ShouldParseSnakeCaseBody() {
        UUID scenarioId = UUID.randomUUID();
        when(memoryService.addLesson(eq(scenarioId),
                eq("Суммы брать из УПД"), eq(AgentLesson.SOURCE_USER)))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"" + scenarioId + "\", \"lesson\": \"Суммы брать из УПД\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).addLesson(eq(scenarioId),
                eq("Суммы брать из УПД"), eq(AgentLesson.SOURCE_USER));
    }

    @Test
    void addLesson_ShouldTreatBlankScenarioIdAsGlobal() {
        when(memoryService.addLesson(isNull(),
                eq("Общий урок"), eq(AgentLesson.SOURCE_USER)))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"\", \"lesson\": \"Общий урок\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).addLesson(isNull(),
                eq("Общий урок"), eq(AgentLesson.SOURCE_USER));
    }

    @Test
    void updateLesson_ShouldParseLessonBody() {
        UUID id = UUID.randomUUID();
        when(memoryService.updateLesson(id, "Новый текст"))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.put()
                .uri("/api/agent/lessons/{id}", id)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"lesson\": \"Новый текст\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).updateLesson(id, "Новый текст");
    }

    @Test
    void answerQuestion_ShouldParseAnswerBody() {
        UUID id = UUID.randomUUID();
        when(memoryService.answerQuestion(id, "Дата — из штампа ЭП"))
                .thenReturn(new AgentQuestion());

        webClient.post()
                .uri("/api/agent/questions/{id}/answer", id)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"answer\": \"Дата — из штампа ЭП\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).answerQuestion(id, "Дата — из штампа ЭП");
    }
}
