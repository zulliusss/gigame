package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile;
import org.apache.commons.compress.utils.SeekableInMemoryByteChannel;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.ScanOcrService;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты getDocuments: распаковка ZIP, маркер скана, лимит документов.
 */
@ExtendWith(MockitoExtension.class)
@SuppressWarnings("unused")
class ScenarioServiceDocumentsTest {

    @Mock
    private ScenarioRepository scenarioRepository;
    @Mock
    private ScenarioRunRepository scenarioRunRepository;
    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;
    @Mock
    private ScenarioVersionRepository scenarioVersionRepository;
    @Mock
    private ScenarioEngine scenarioEngine;
    @Mock
    private DocumentService documentService;
    @Mock
    private ScanOcrService scanOcrService;

    @InjectMocks
    private ScenarioService scenarioService;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(scenarioService, "minParsedChars", 40);
    }

    private FilePart mockFilePart(String filename, byte[] content) {
        FilePart mockFile = mock(FilePart.class);
        when(mockFile.filename()).thenReturn(filename);
        lenient().when(mockFile.headers()).thenReturn(null);
        when(mockFile.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap(content)));
        return mockFile;
    }

    private static byte[] zipOf(Map<String, byte[]> entries) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ZipOutputStream zos = new ZipOutputStream(bos)) {
            for (var e : entries.entrySet()) {
                zos.putNextEntry(new ZipEntry(e.getKey()));
                zos.write(e.getValue());
                zos.closeEntry();
            }
        }
        return bos.toByteArray();
    }

    private static byte[] sevenZOf(Map<String, byte[]> entries) throws IOException {
        SeekableInMemoryByteChannel channel = new SeekableInMemoryByteChannel();
        try (SevenZOutputFile szf = new SevenZOutputFile(channel)) {
            for (var e : entries.entrySet()) {
                SevenZArchiveEntry entry = new SevenZArchiveEntry();
                entry.setName(e.getKey());
                entry.setDirectory(false);
                szf.putArchiveEntry(entry);
                szf.write(e.getValue());
                szf.closeArchiveEntry();
            }
        }
        return Arrays.copyOf(channel.array(), (int) channel.size());
    }

    @Test
    void getDocuments_zipIsUnpackedIntoSeveralDocuments() throws IOException {
        byte[] zip = zipOf(Map.of(
                "Договор 123/договор.pdf", "pdf".getBytes(),
                "Договор 123/Signature.sig", "junk".getBytes(),
                "Договор 123/акт.docx", "docx".getBytes()));
        FilePart file = mockFilePart("документы.zip", zip);
        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("Текст договора достаточной длины для порога скан-детекции");
        when(documentService.parseText(any(InputStream.class), eq("docx")))
                .thenReturn("Текст акта достаточной длины для порога скан-детекции!");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals(2, docs.size());
        assertTrue(docs.stream().anyMatch(d -> d.filename().equals("документы.zip/Договор 123/договор.pdf")));
        assertTrue(docs.stream().anyMatch(d -> d.filename().equals("документы.zip/Договор 123/акт.docx")));
    }

    @Test
    void getDocuments_zipWithoutSupportedDocuments_throws() throws IOException {
        byte[] zip = zipOf(Map.of("Signature.sig", "junk".getBytes()));
        FilePart file = mockFilePart("пустой.zip", zip);
        var files = List.of(file);
        assertThrows(FileException.class, () -> scenarioService.getDocuments(files, null));
    }

    @Test
    void getDocuments_scannedPdf_replacedWithManualReviewMarker() throws IOException {
        FilePart file = mockFilePart("скан.pdf", "оригинальные байты".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("pdf"))).thenReturn("  \n ");

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(1, docs.size());
        assertTrue(docs.get(0).text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(docs.get(0).text().contains("скан.pdf"));
        assertTrue(events.stream().anyMatch(e ->
                "upload_warning".equals(e.data() != null ? e.data().get("type") : null)));
    }

    @Test
    void getDocuments_brokenFile_getsManualReviewMarkerInsteadOfFailingWholeBatch() throws IOException {
        // битый файл (XML-бомба в docx, повреждение) не должен ронять загрузку комплекта
        FilePart good = mockFilePart("хороший.txt", "нормальный текст документа".getBytes());
        FilePart broken = mockFilePart("битый.docx", "мусор".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenReturn("нормальный текст документа");
        when(documentService.parseText(any(InputStream.class), eq("docx")))
                .thenThrow(new IOException("Zip bomb detected"));

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(good, broken), events);

        assertEquals(2, docs.size());
        var brokenDoc = docs.stream().filter(d -> d.filename().equals("битый.docx")).findFirst().orElseThrow();
        assertTrue(brokenDoc.text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(brokenDoc.text().contains("не удалось обработать"));
        assertTrue(events.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).contains("не обработан")));
    }

    @Test
    void getDocuments_ooxmlBomb_rejectedFastWithMarker_withoutReachingPoi() throws IOException {
        // docx с document.xml, раздувающимся сверх лимита (тут 1 МБ), отсекается
        // ДО передачи в POI: parseText для docx не должен вызываться вовсе
        ReflectionTestUtils.setField(scenarioService, "maxOoxmlEntryMb", 1);
        byte[] bomb = zipOf(Map.of("word/document.xml", new byte[2 * 1024 * 1024]));
        FilePart file = mockFilePart("бомба.docx", bomb);

        List<ServerSentEvent<Map<String, Object>>> events = new ArrayList<>();
        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), events);

        assertEquals(1, docs.size());
        assertTrue(docs.get(0).text().contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        verify(documentService, never()).parseText(any(InputStream.class), eq("docx"));
    }

    @Test
    void getDocuments_sevenZipArchive_unpackedLikeZip() throws IOException {
        // .7z маршрутизируется в экстрактор так же, как .zip (архив собран в ZipExtractorTest-стиле)
        byte[] sevenZ = sevenZOf(Map.of(
                "Договор 123/договор.pdf", "pdf-bytes".getBytes(),
                "Договор 123/Signature(01).sig", "junk".getBytes()));
        FilePart file = mockFilePart("документы.7z", sevenZ);
        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("Текст договора достаточной длины для порога скан-детекции");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals(1, docs.size());
        assertEquals("документы.7z/Договор 123/договор.pdf", docs.get(0).filename());
    }

    @Test
    void getDocuments_shortButNonEmptyTxt_isNotMarked() throws IOException {
        // маркер применяется только к PDF: короткий txt остаётся как есть
        FilePart file = mockFilePart("короткий.txt", "ok".getBytes());
        when(documentService.parseText(any(InputStream.class), eq("txt"))).thenReturn("ok");

        List<DocumentText> docs = scenarioService.getDocuments(List.of(file), null);

        assertEquals("ok", docs.get(0).text());
    }

    @Test
    void getDocumentsText_returnsTextsInOrder() throws IOException {
        FilePart file1 = mockFilePart("a.txt", "1".getBytes());
        FilePart file2 = mockFilePart("b.txt", "2".getBytes());
        // парсинг параллельный — стаб привязан к содержимому, а не к порядку вызовов
        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenAnswer(inv -> "1".equals(new String(((InputStream) inv.getArgument(0)).readAllBytes()))
                        ? "первый текст" : "второй текст");

        List<String> texts = scenarioService.getDocumentsText(List.of(file1, file2), null);

        assertEquals(List.of("первый текст", "второй текст"), texts);
    }
}
