package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioDetailResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var graph = new GraphDataDto(List.of(), List.of());
        var dto = new ScenarioDetailResponse(id, "Scenario", "Description", now, now, graph);
        assertEquals(id, dto.id());
        assertEquals("Scenario", dto.name());
        assertEquals("Description", dto.description());
        assertEquals(now, dto.createdAt());
        assertEquals(now, dto.updatedAt());
        assertEquals(0, dto.graphData().nodes().size());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioDetailResponse(null, null, null, null, null, null);
        assertNull(dto.id());
        assertNull(dto.name());
        assertNull(dto.description());
        assertNull(dto.createdAt());
        assertNull(dto.updatedAt());
        assertNull(dto.graphData());
    }
}