package ru.sber.cs.ai.gigame.dto.scenario.graph;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class EdgeDataDtoTest {

    @Test
    void testConstruction_withLabel() {
        var dto = new EdgeDataDto("my_label");
        assertEquals("my_label", dto.label());
    }

    @Test
    void testConstruction_withNullLabel() {
        var dto = new EdgeDataDto(null);
        assertNull(dto.label());
    }
}