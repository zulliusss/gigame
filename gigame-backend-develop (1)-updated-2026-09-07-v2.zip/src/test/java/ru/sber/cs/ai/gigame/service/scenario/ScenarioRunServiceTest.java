package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScenarioRunServiceTest {

    @Mock
    private ScenarioRunRepository scenarioRunRepository;

    @InjectMocks
    private ScenarioRunService runService;

    @Captor
    private ArgumentCaptor<ScenarioRun> scenarioRunCaptor;

    private UUID runId;
    private UUID scenarioId;
    private ScenarioRun run;

    @BeforeEach
    void setUp() {
        runId = UUID.randomUUID();
        scenarioId = UUID.randomUUID();

        run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(OffsetDateTime.now());
    }

    // -------------------------------------------------------------------------
    // setScenarioRunStatusRunning
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioRunStatusRunning() {
        when(scenarioRunRepository.save(any())).thenReturn(run);

        ScenarioRun result = runService.setScenarioRunStatusRunning(run);

        assertNotNull(result);
        assertEquals(run, result);
        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        assertEquals(ScenarioStatus.RUNNING.getValue(), scenarioRunCaptor.getValue().getStatus());
    }

    @Test
    void testSetScenarioRunStatusRunning_doesNotChangeOtherFields() {
        run.setCompletedAt(null);
        run.setResult("original result");

        when(scenarioRunRepository.save(any())).thenReturn(run);

        runService.setScenarioRunStatusRunning(run);

        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        ScenarioRun captured = scenarioRunCaptor.getValue();
        assertEquals(runId, captured.getId());
        assertEquals(scenarioId, captured.getScenarioId());
        assertEquals("original result", captured.getResult());
    }

    // -------------------------------------------------------------------------
    // setScenarioRunStatusFailed
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioRunStatusFailed() {
        when(scenarioRunRepository.save(any())).thenReturn(run);

        ScenarioRun result = runService.setScenarioRunStatusFailed(run);

        assertNotNull(result);
        assertEquals(run, result);
        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        assertEquals(ScenarioStatus.FAILED.getValue(), scenarioRunCaptor.getValue().getStatus());
    }

    @Test
    void testSetScenarioRunStatusFailed_doesNotChangeOtherFields() {
        run.setCompletedAt(null);

        when(scenarioRunRepository.save(any())).thenReturn(run);

        runService.setScenarioRunStatusFailed(run);

        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        ScenarioRun captured = scenarioRunCaptor.getValue();
        assertEquals(ScenarioStatus.FAILED.getValue(), captured.getStatus());
        assertEquals(runId, captured.getId());
    }

    // -------------------------------------------------------------------------
    // setScenarioRunStatusCompleted
    // -------------------------------------------------------------------------

    @Test
    void testSetScenarioRunStatusCompleted() {
        when(scenarioRunRepository.save(any())).thenReturn(run);

        ScenarioRun result = runService.setScenarioRunStatusCompleted(run, "Final result");

        assertNotNull(result);
        assertEquals(run, result);
        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        ScenarioRun captured = scenarioRunCaptor.getValue();

        assertEquals(ScenarioStatus.COMPLETED.getValue(), captured.getStatus());
        assertEquals("Final result", captured.getResult());
        assertNotNull(captured.getCompletedAt());
    }

    @Test
    void testSetScenarioRunStatusCompleted_withNullResult() {
        when(scenarioRunRepository.save(any())).thenReturn(run);

        ScenarioRun result = runService.setScenarioRunStatusCompleted(run, null);

        assertNotNull(result);
        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        ScenarioRun captured = scenarioRunCaptor.getValue();

        assertEquals(ScenarioStatus.COMPLETED.getValue(), captured.getStatus());
        assertNull(captured.getResult());
        assertNotNull(captured.getCompletedAt());
    }

    @Test
    void testSetScenarioRunStatusCompleted_setsCompletedAt() {
        run.setCompletedAt(null);

        when(scenarioRunRepository.save(any())).thenReturn(run);

        runService.setScenarioRunStatusCompleted(run, "Result");

        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        ScenarioRun captured = scenarioRunCaptor.getValue();
        assertNotNull(captured.getCompletedAt());
    }

    // -------------------------------------------------------------------------
    // Integration Tests
    // -------------------------------------------------------------------------

    @Test
    void testCompleteSequence_ofStatusChanges() {
        // Start with pending
        when(scenarioRunRepository.save(any())).thenReturn(run);
        assertSame(run, runService.setScenarioRunStatusRunning(run));

        // Running -> completed
        when(scenarioRunRepository.save(any())).thenReturn(run);
        ScenarioRun completed = runService.setScenarioRunStatusCompleted(run, "Done");

        assertEquals(ScenarioStatus.COMPLETED.getValue(), completed.getStatus());
        assertEquals("Done", completed.getResult());
        assertNotNull(completed.getCompletedAt());
    }

    @Test
    void testFailedSequence_ofStatusChanges() {
        // Start with pending
        when(scenarioRunRepository.save(any())).thenReturn(run);
        assertSame(run, runService.setScenarioRunStatusRunning(run));

        // Running -> failed
        when(scenarioRunRepository.save(any())).thenReturn(run);
        ScenarioRun failed = runService.setScenarioRunStatusFailed(run);

        assertEquals(ScenarioStatus.FAILED.getValue(), failed.getStatus());
    }

    @Test
    void testMultipleCalls_saveEachTime() {
        when(scenarioRunRepository.save(any())).thenReturn(run);

        runService.setScenarioRunStatusRunning(run);
        runService.setScenarioRunStatusRunning(run);
        runService.setScenarioRunStatusCompleted(run, "Done");

        // Verify save was called 3 times
        verify(scenarioRunRepository, times(3)).save(any());
    }

    @Test
    void testRepositorySaveCalledWithSameInstance() {
        when(scenarioRunRepository.save(any())).thenReturn(run);

        runService.setScenarioRunStatusRunning(run);

        verify(scenarioRunRepository).save(scenarioRunCaptor.capture());
        assertSame(run, scenarioRunCaptor.getValue());
    }

    // -------------------------------------------------------------------------
    // failOrphanedRunningRuns (восстановление после рестарта)
    // -------------------------------------------------------------------------

    @Test
    void testFailOrphanedRunningRuns_marksRunningAsFailed() {
        run.setStatus(ScenarioStatus.RUNNING.getValue());
        when(scenarioRunRepository.findByStatus(ScenarioStatus.RUNNING.getValue()))
                .thenReturn(List.of(run));

        runService.failOrphanedRunningRuns();

        assertEquals(ScenarioStatus.FAILED.getValue(), run.getStatus());
        verify(scenarioRunRepository).saveAll(List.of(run));
    }

    @Test
    void testFailOrphanedRunningRuns_noOrphans_noSave() {
        when(scenarioRunRepository.findByStatus(ScenarioStatus.RUNNING.getValue()))
                .thenReturn(List.of());

        runService.failOrphanedRunningRuns();

        verify(scenarioRunRepository, times(0)).saveAll(any());
    }
}
