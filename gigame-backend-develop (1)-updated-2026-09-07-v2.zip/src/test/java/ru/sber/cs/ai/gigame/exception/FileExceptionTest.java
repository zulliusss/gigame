package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class FileExceptionTest {

    @Test
    void testFileException_withMessage() {
        FileException ex = new FileException("File error");

        assertEquals("File error", ex.getMessage());
        assertEquals(422, ex.getStatusCode());
        assertNull(ex.getDetails());
    }

    @Test
    void testFileException_withCause() {
        Exception cause = new Exception("Inner error");
        FileException ex = new FileException("File error", cause);

        assertEquals("File error", ex.getMessage());
        assertEquals(422, ex.getStatusCode());
        assertEquals(cause, ex.getCause());
    }

}
