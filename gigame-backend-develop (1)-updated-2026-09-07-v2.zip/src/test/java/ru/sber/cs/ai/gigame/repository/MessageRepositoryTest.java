package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Message;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class MessageRepositoryTest {

    @Autowired
    ConversationRepository conversationRepository;
    @Autowired
    private MessageRepository messageRepository;

    @Test
    void testFindById_returnsMessage() {
        var conversation = new Conversation();
        conversation.setTitle("test");
        conversationRepository.save(conversation);

        Message message = new Message();
        message.setConversation(conversation);
        message.setRole("user");
        message.setContent("Hello");
        messageRepository.save(message);

        Message found = messageRepository.findById(message.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("Hello", found.getContent());
    }

    @Test
    void testFindByConversationIdOrderByCreatedAtAsc_returnsSortedMessages() {
        var conversation = new Conversation();
        conversation.setTitle("test");
        conversationRepository.save(conversation);
        Message msg1 = new Message();
        msg1.setConversation(conversation);
        msg1.setRole("user");
        msg1.setContent("First");
        messageRepository.save(msg1);

        Message msg2 = new Message();
        msg2.setConversation(conversation);
        msg2.setRole("assistant");
        msg2.setContent("Second");
        messageRepository.save(msg2);

        List<Message> result = messageRepository.findByConversationIdOrderByCreatedAtAsc(conversation.getId());

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("First", result.get(0).getContent());
        assertEquals("Second", result.get(1).getContent());
    }

    @Test
    void testFindByConversationId_returnsEmptyList_whenNoMessages() {
        List<Message> result = messageRepository.findByConversationIdOrderByCreatedAtAsc(UUID.randomUUID());

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        var conversation = new Conversation();
        conversation.setTitle("test");
        conversationRepository.save(conversation);

        Message message = new Message();
        message.setConversation(conversation);
        message.setRole("user");
        message.setContent("To delete");

        Message saved = messageRepository.save(message);
        assertNotNull(saved.getId());

        messageRepository.delete(saved);
        assertFalse(messageRepository.findById(saved.getId()).isPresent());
    }
}
