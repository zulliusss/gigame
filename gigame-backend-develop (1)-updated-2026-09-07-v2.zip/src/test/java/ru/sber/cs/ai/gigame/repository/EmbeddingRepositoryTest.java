package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Embedding;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class EmbeddingRepositoryTest {

    @Autowired
    private EmbeddingRepository underTest;

    @Test
    void testFindById_returnsEmbedding() {
        UUID collId = UUID.randomUUID();
        Embedding embedding = new Embedding();
        embedding.setCollectionType("doc");
        embedding.setCollectionId(collId);
        embedding.setVector(new float[10]);
        underTest.save(embedding);

        Embedding found = underTest.findById(embedding.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("doc", found.getCollectionType());
    }

    @Test
    void testDeleteByCollection() {
        UUID collId = UUID.randomUUID();
        Embedding emb1 = new Embedding();
        emb1.setCollectionType("doc");
        emb1.setCollectionId(collId);
        emb1.setVector(new float[10]);
        underTest.save(emb1);

        Embedding emb2 = new Embedding();
        emb2.setCollectionType("doc");
        emb2.setCollectionId(collId);
        emb2.setVector(new float[10]);
        underTest.save(emb2);

        underTest.deleteByCollection("doc", collId);

        List<Embedding> result = underTest.findAll();
        assertTrue(result.isEmpty());
    }

    @Test
    void testDeleteKBDocumentChunks() {
        UUID kbId = UUID.randomUUID();
        UUID docId = UUID.randomUUID();

        Embedding emb1 = new Embedding();
        emb1.setCollectionType("kb");
        emb1.setCollectionId(kbId);
        emb1.setSourceDocumentId(docId);
        emb1.setVector(new float[10]);
        underTest.save(emb1);

        Embedding emb2 = new Embedding();
        emb2.setCollectionType("kb");
        emb2.setCollectionId(kbId);
        emb2.setSourceDocumentId(docId);
        emb2.setVector(new float[10]);
        underTest.save(emb2);

        // Different doc should not be deleted
        Embedding emb3 = new Embedding();
        emb3.setCollectionType("kb");
        emb3.setCollectionId(kbId);
        emb3.setSourceDocumentId(UUID.randomUUID());
        emb3.setVector(new float[10]);
        underTest.save(emb3);

        underTest.deleteKBDocumentChunks(kbId, docId);

        List<Embedding> result = underTest.findAll();
        assertEquals(1, result.size());
        assertEquals(emb3.getId(), result.get(0).getId());
    }

    @Test
    void testSaveAndDelete() {
        Embedding embedding = new Embedding();
        embedding.setCollectionType("doc");
        embedding.setCollectionId(UUID.randomUUID());
        embedding.setVector(new float[10]);

        Embedding saved = underTest.save(embedding);
        assertNotNull(saved.getId());

        underTest.delete(saved);
        assertFalse(underTest.findById(saved.getId()).isPresent());
    }
}
