package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ApplicationErrorHandlerTest {

    private final ApplicationErrorHandler handler = new ApplicationErrorHandler();

    @Test
    void testHandleNotFoundException() {
        NotFoundException ex = new NotFoundException("Resource not found");

        ResponseEntity<ErrorResponse> response = handler.handleNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(404, response.getBody().getStatusCode());
        assertEquals("Not Found", response.getBody().getError());
        assertEquals("Resource not found", response.getBody().getMessage());
        assertNotNull(response.getBody().getTimestamp());
    }

    @Test
    void testHandleAccessDeniedException() {
        AccessDeniedException ex = new AccessDeniedException("Access denied");

        ResponseEntity<ErrorResponse> response = handler.handleAccessDeniedException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(403, response.getBody().getStatusCode());
        assertEquals("Forbidden", response.getBody().getError());
        assertEquals("Access denied", response.getBody().getMessage());
    }

    @Test
    void testHandleFileException() {
        FileException ex = new FileException("File error");

        ResponseEntity<ErrorResponse> response = handler.handleFileException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(422, response.getBody().getStatusCode());
        assertEquals("Unprocessable Entity", response.getBody().getError());
        assertEquals("File error", response.getBody().getMessage());
    }

    @Test
    void testHandleScenarioException() {
        ScenarioException ex = new ScenarioException("Scenario error");

        ResponseEntity<ErrorResponse> response = handler.handleScenarioException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(400, response.getBody().getStatusCode());
        assertEquals("Bad Request", response.getBody().getError());
        assertEquals("Scenario error", response.getBody().getMessage());
    }

    @Test
    void testHandleNotFoundException_withInnerException() {
        NotFoundException ex = new NotFoundException("Resource not found");

        ResponseEntity<ErrorResponse> response = handler.handleNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void testHandleNotFoundException_withoutMessage() {
        NotFoundException ex = new NotFoundException();

        ResponseEntity<ErrorResponse> response = handler.handleNotFoundException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Ресурс не найден", response.getBody().getMessage());
    }

    @Test
    void testHandleAccessDeniedException_withoutMessage() {
        AccessDeniedException ex = new AccessDeniedException();

        ResponseEntity<ErrorResponse> response = handler.handleAccessDeniedException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Доступ запрещен", response.getBody().getMessage());
    }

    @Test
    void testHandleFileException_withCause() {
        Exception cause = new Exception("Inner error");
        FileException ex = new FileException("File error", cause);

        ResponseEntity<ErrorResponse> response = handler.handleFileException(ex);

        assertNotNull(response);
        assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("File error", response.getBody().getMessage());
    }
}
