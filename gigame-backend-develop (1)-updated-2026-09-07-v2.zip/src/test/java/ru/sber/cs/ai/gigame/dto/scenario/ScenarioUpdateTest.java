package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioUpdateTest {

    @Test
    void testConstruction_withAllFields() {
        var graph = new GraphDataDto(null, null);
        var dto = new ScenarioUpdate("New Name", "New Description", graph);
        assertEquals("New Name", dto.name());
        assertEquals("New Description", dto.description());
        assertNull(dto.graphData().nodes());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioUpdate(null, null, null);
        assertNull(dto.name());
        assertNull(dto.description());
        assertNull(dto.graphData());
    }
}