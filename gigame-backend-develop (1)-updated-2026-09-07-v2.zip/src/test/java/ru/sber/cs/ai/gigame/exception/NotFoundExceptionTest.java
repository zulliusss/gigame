package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class NotFoundExceptionTest {

    @Test
    void testNotFoundException_withMessage() {
        NotFoundException ex = new NotFoundException("Resource not found");

        assertEquals("Resource not found", ex.getMessage());
        assertEquals(404, ex.getStatusCode());
        assertNull(ex.getDetails());
    }

    @Test
    void testNotFoundException_withoutMessage() {
        NotFoundException ex = new NotFoundException();

        assertEquals("Ресурс не найден", ex.getMessage());
        assertEquals(404, ex.getStatusCode());
    }
}
