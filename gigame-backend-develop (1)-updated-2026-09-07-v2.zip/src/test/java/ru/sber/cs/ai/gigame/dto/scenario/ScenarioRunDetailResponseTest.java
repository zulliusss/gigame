package ru.sber.cs.ai.gigame.dto.scenario;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioRunDetailResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var scenarioId = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var step = new ScenarioRunStepResponse(UUID.randomUUID(), "node1", "task",
                "completed", null, null, null, null, now, now);
        var dto = new ScenarioRunDetailResponse(id, scenarioId, "completed",
                List.of("doc1"), "result", now, now, List.of(step));
        assertEquals(id, dto.id());
        assertEquals(scenarioId, dto.scenarioId());
        assertEquals("completed", dto.status());
        assertEquals(1, dto.inputDocumentIds().size());
        assertEquals("doc1", dto.inputDocumentIds().get(0));
        assertEquals("result", dto.result());
        assertEquals(now, dto.startedAt());
        assertEquals(now, dto.completedAt());
        assertEquals(1, dto.steps().size());
        assertEquals("node1", dto.steps().get(0).nodeId());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ScenarioRunDetailResponse(null, null, null, null, null, null, null, null);
        assertNull(dto.id());
        assertNull(dto.scenarioId());
        assertNull(dto.status());
        assertNull(dto.inputDocumentIds());
        assertNull(dto.result());
        assertNull(dto.startedAt());
        assertNull(dto.completedAt());
        assertNull(dto.steps());
    }

    @Test
    void testConstruction_withEmptyLists() {
        var dto = new ScenarioRunDetailResponse(null, null, null, List.of(), null, null, null, List.of());
        assertTrue(dto.inputDocumentIds().isEmpty());
        assertTrue(dto.steps().isEmpty());
    }
}