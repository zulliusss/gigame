package ru.sber.cs.ai.gigame.dto.chat;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ConversationWithMessagesTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var msg = new MessageResponse(UUID.randomUUID(), id, "user", "Hello", List.of(), null, now);
        var dto = new ConversationWithMessages(id, "Title", "kb-123", List.of("kb-123"),
                "GigaChat-2-Max", 0.7, now, now, List.of(msg));
        assertEquals(id, dto.id());
        assertEquals("Title", dto.title());
        assertEquals("kb-123", dto.knowledgeBaseId());
        assertEquals(List.of("kb-123"), dto.knowledgeBaseIds());
        assertEquals("GigaChat-2-Max", dto.model());
        assertEquals(0.7, dto.temperature());
        assertEquals(now, dto.createdAt());
        assertEquals(now, dto.updatedAt());
        assertEquals(1, dto.messages().size());
        assertEquals("Hello", dto.messages().get(0).content());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ConversationWithMessages(null, null, null, null, null, null, null, null, null);
        assertNull(dto.id());
        assertNull(dto.title());
        assertNull(dto.knowledgeBaseId());
        assertNull(dto.knowledgeBaseIds());
        assertNull(dto.model());
        assertNull(dto.temperature());
        assertNull(dto.createdAt());
        assertNull(dto.updatedAt());
        assertNull(dto.messages());
    }

    @Test
    void testConstruction_withEmptyMessages() {
        var dto = new ConversationWithMessages(null, null, null, null, null, null, null, null, List.of());
        assertTrue(dto.messages().isEmpty());
    }
}
