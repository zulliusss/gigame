package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты {@link ExpressionResolver}: подстановка выражений {{output:…}} и {{json:…}}
 * в промптах узлов сценария.
 */
class ExpressionResolverTest {

    private static final Stream<Arguments> RESOLVE_ARGS = Stream.of(
            Arguments.of(
                "output by node id",
                "Контекст: {{output:node-1}}",
                "результат работы узла",
                "Контекст: результат работы узла",
                null
            ),
            Arguments.of(
                "output by label",
                "{{output:Extractor}}",
                "результат",
                "результат",
                null
            ),
            Arguments.of(
                "json simple field",
                "Цена: {{json:node-1:цена}}",
                "какой-то текст\n{\"цена\": 1250.5, \"количество\": 320}\nхвост",
                "Цена: 1250.5",
                null
            ),
            Arguments.of(
                "json nested field",
                "{{json:node-1:участник.имя}}",
                "{\"участник\": {\"имя\": \"Альфа\", \"балл\": 95}}",
                "Альфа",
                null
            ),
            Arguments.of(
                "json array item",
                "{{json:node-1:позиции[0].имя}}",
                "{\"позиции\": [{\"имя\": \"Первая\"}, {\"имя\": \"Вторая\"}]}",
                "Первая",
                null
            ),
            Arguments.of(
                "json index out of bounds",
                "{{json:node-1:список[99]}}",
                "{\"список\": [1, 2]}",
                null,
                "вне диапазона"
            ),
            Arguments.of(
                "json no JSON in output",
                "{{json:node-1:поле}}",
                "просто текст без JSON",
                null,
                "нет разбираемого JSON"
            ),
            Arguments.of(
                "json field not found",
                "{{json:node-1:нетТакогоПоля}}",
                "{\"цена\": 100}",
                null,
                "не найдено"
            ),
            Arguments.of(
                "json without path",
                "{{json:node-1}}",
                "{\"цена\": 100}",
                null,
                "не указан путь к полю"
            )
    );

    private Map<String, ScenarioRunNode> nodeMap;

    @BeforeEach
    void setUp() {
        var nodeDto = NodeDto.builder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Extractor")
                        .prompt("какой-то промпт")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var gd = new GraphDataDto(List.of(nodeDto), List.of());
        var graph = new ScenarioRunGraph(gd);
        nodeMap = graph.getNodeMap();
    }

    // ================================================================
    // hasExpressions
    // ================================================================

    @Test
    void testHasExpressions_withOutput() {
        assertTrue(ExpressionResolver.hasExpressions("{{output:Extractor}}"));
    }

    @Test
    void testHasExpressions_withJson() {
        assertTrue(ExpressionResolver.hasExpressions("{{json:Extractor:цена}}"));
    }

    @Test
    void testHasExpressions_withLeadingTrailingSpaces() {
        assertTrue(ExpressionResolver.hasExpressions("  {{ output : Extractor }}  "));
    }

    @Test
    void testHasExpressions_withoutExpression() {
        assertFalse(ExpressionResolver.hasExpressions("просто текст без выражений"));
    }

    @Test
    void testHasExpressions_withEmptyTemplate() {
        assertFalse(ExpressionResolver.hasExpressions(""));
    }

    @Test
    void testHasExpressions_withNullTemplate() {
        assertFalse(ExpressionResolver.hasExpressions(null));
    }

    @Test
    void testHasExpressions_withJsonPath() {
        assertTrue(ExpressionResolver.hasExpressions("{{json:Узел:путь.к[0].полю}}"));
    }

    // ================================================================
    // resolve — output / json
    // ================================================================

    static Stream<Arguments> resolveParams() {
        return RESOLVE_ARGS;
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("resolveParams")
    void testResolve(String description, String expression, String nodeOutput,
                     String expected, String errorToken) {
        var gd = new GraphDataDto(List.of(
                NodeDto.builder()
                        .id("node-1")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Extractor").prompt("").build())
                        .position(new PositionDto(100, 100))
                        .build()
        ), List.of());
        var graph = new ScenarioRunGraph(gd);
        var nm = graph.getNodeMap();
        nm.get("node-1").getOutput().add(nodeOutput);

        String resolved = ExpressionResolver.resolve(expression, nm);

        if (expected != null) {
            assertEquals(expected, resolved);
        } else {
            assertTrue(resolved.contains(errorToken));
        }
    }

    @Test
    void testResolve_output_multipleLines() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("строка 1");
        src.getOutput().add("строка 2");

        String resolved = ExpressionResolver.resolve("{{output:node-1}}", nodeMap);

        assertTrue(resolved.contains("строка 1"));
        assertTrue(resolved.contains("строка 2"));
    }

    @Test
    void testResolve_output_nodeNotFound() {
        String resolved = ExpressionResolver.resolve("{{output:Несуществующий}}", nodeMap);

        assertTrue(resolved.contains("не найден"));
    }

    @Test
    void testResolve_output_usesFirstMatchingLabel() {
        var gd = new GraphDataDto(List.of(
                NodeDto.builder()
                        .id("n1")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Extractor").prompt("").build())
                        .position(new PositionDto(0, 0))
                        .build(),
                NodeDto.builder()
                        .id("n2")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Extractor").prompt("").build())
                        .position(new PositionDto(100, 0))
                        .build()
        ), List.of());
        var graph = new ScenarioRunGraph(gd);
        var nm = graph.getNodeMap();

        nm.get("n1").getOutput().add("один");
        nm.get("n2").getOutput().add("два");

        String resolved = ExpressionResolver.resolve("{{output:Extractor}}", nm);

        // находит первый узел с подходящей меткой
        assertEquals("один", resolved);
    }

    // ================================================================
    // resolve — json
    // ================================================================

    private static Stream<Arguments> jsonResolveArgs() {
        return Stream.of(
                Arguments.of(
                        "simpleField",
                        "какой-то текст\n{\"цена\": 1250.5, \"количество\": 320}\nхвост",
                        "{{json:node-1:цена}}",
                        "1250.5"
                ),
                Arguments.of(
                        "nestedField",
                        "{\"участник\": {\"имя\": \"Альфа\", \"балл\": 95}}",
                        "{{json:node-1:участник.имя}}",
                        "Альфа"
                ),
                Arguments.of(
                        "arrayItem",
                        "{\"позиции\": [{\"имя\": \"Первая\"}, {\"имя\": \"Вторая\"}]}",
                        "{{json:node-1:позиции[0].имя}}",
                        "Первая"
                )
        );
    }

    @MethodSource("jsonResolveArgs")
    @ParameterizedTest(name = "resolve: {0}")
    void testResolve_json(String label, String outputText, String expression, String expected) {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add(outputText);

        String resolved = ExpressionResolver.resolve(expression, nodeMap);

        assertEquals(expected, resolved);
    }

    @Test
    void testResolve_json_nodeNotFound() {
        String resolved = ExpressionResolver.resolve("{{json:Несущ:поле}}", nodeMap);

        assertTrue(resolved.contains("не найден"));
    }

    @Test
    void testResolve_json_emptyOutput() {

        String resolved = ExpressionResolver.resolve("{{json:node-1:поле}}", nodeMap);

        assertTrue(resolved.contains("нет разбираемого JSON"));
    }

    // ================================================================
    // resolve — несколько выражений в одном шаблоне
    // ================================================================

    @Test
    void testResolve_multipleExpressionsInTemplate() {
        // создаём два узла
        var gd = new GraphDataDto(List.of(
                NodeDto.builder()
                        .id("n1")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Цены").prompt("").build())
                        .position(new PositionDto(0, 0))
                        .build(),
                NodeDto.builder()
                        .id("n2")
                        .type(ScenarioNodeType.PROCESSING_NODE.toString())
                        .data(NodeDataDto.builder().label("Расчёт").prompt("").build())
                        .position(new PositionDto(100, 0))
                        .build()
        ), List.of());
        var graph = new ScenarioRunGraph(gd);
        var nm = graph.getNodeMap();
        nm.get("n1").getOutput().add("{\"цена\": 100}");
        nm.get("n2").getOutput().add("текст вывода");

        String resolved = ExpressionResolver.resolve("Поле: {{json:Цены:цена}}, Вывод: {{output:Расчёт}}", nm);

        assertEquals("Поле: 100, Вывод: текст вывода", resolved);
    }

    @Test
    void testResolve_outputAndJsonMixed() {
        ScenarioRunNode src = nodeMap.get("node-1");
        src.getOutput().add("{\"цена\": 200}");

        String resolved = ExpressionResolver.resolve("{{output:node-1}} | {{json:node-1:цена}}", nodeMap);

        assertTrue(resolved.contains("цена"));
        assertTrue(resolved.contains("200"));
    }

    // ================================================================
    // resolve — выражений нет, шаблон не меняется
    // ================================================================

    @Test
    void testResolve_withoutExpressions_unchanged() {
        String template = "просто промпт без выражений";

        String resolved = ExpressionResolver.resolve(template, nodeMap);

        assertEquals(template, resolved);
    }

    @Test
    void testResolve_withEmptyTemplate_unchanged() {
        String resolved = ExpressionResolver.resolve("", nodeMap);

        assertEquals("", resolved);
    }

    // ================================================================
    // extractJsonPathFromText — статический метод, доступный напрямую
    // ================================================================

    @Test
    void testExtractJsonPathFromText_deepNestedWithArrays() {
        String text = "{\"data\": [{\"items\": [{\"value\": 42}]}]}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "data[0].items[0].value");

        assertEquals("42", result);
    }

    @Test
    void testExtractJsonPathFromText_noJson_returnsError() {
        String text = "просто текст";

        String result = ExpressionResolver.extractJsonPathFromText(text, "поле");

        assertTrue(result.contains("нет разбираемого JSON"));
    }

    @Test
    void testExtractJsonPathFromText_stringValue() {
        String text = "{\"имя\": \"Альфа\"}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "имя");

        assertEquals("Альфа", result);
    }

    @Test
    void testExtractJsonPathFromText_numberValue() {
        String text = "{\"цена\": 1250.5}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "цена");

        assertEquals("1250.5", result);
    }

    @Test
    void testExtractJsonPathFromText_nullValue() {
        String text = "{\"поле\": null}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "поле");

        assertEquals("", result);
    }

    @Test
    void testExtractJsonPathFromText_objectValue() {
        String text = "{\"объект\": {\"внутри\": true}}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "объект");

        assertTrue(result.contains("внутри"));
        assertTrue(result.contains("true"));
    }

    @Test
    void testExtractJsonPathFromText_arrayValue() {
        String text = "{\"массив\": [1, 2, 3]}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "массив");

        assertTrue(result.contains("1"));
        assertTrue(result.contains("3"));
    }

    @Test
    void testExtractJsonPathFromText_withCommasInDecimals() {
        String text = "{\"цена\": 1250,5}";

        String result = ExpressionResolver.extractJsonPathFromText(text, "цена");

        assertEquals("1250.5", result);
    }
}