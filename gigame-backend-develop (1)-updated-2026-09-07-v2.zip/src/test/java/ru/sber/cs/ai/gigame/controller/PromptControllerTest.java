package ru.sber.cs.ai.gigame.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.prompt.PromptCreate;
import ru.sber.cs.ai.gigame.dto.prompt.PromptRateRequest;
import ru.sber.cs.ai.gigame.dto.prompt.PromptResponse;
import ru.sber.cs.ai.gigame.dto.prompt.PromptUpdate;
import ru.sber.cs.ai.gigame.exception.ApplicationErrorHandler;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.service.PromptService;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        PromptController.class,
        TestConfiguration.class,
        ApplicationErrorHandler.class
})
@WebFluxTest(controllers = PromptController.class)
@SuppressWarnings("unused")
class PromptControllerTest {

    @Autowired
    private WebTestClient webClient;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private PromptService promptService;

    private UUID userId;
    private UUID promptId;
    private PromptResponse promptResponse;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        promptId = UUID.randomUUID();
        promptResponse = new PromptResponse(
                promptId,
                "Test Prompt",
                "Description",
                "This is the prompt text",
                "GigaChat-2-Max",
                true,
                true,
                5,
                4.5,
                10L,
                4,
                OffsetDateTime.now()
        );
    }

    // -------------------------------------------------------------------------
    // GET /api/prompts
    // -------------------------------------------------------------------------

    @Test
    void testListPrompts() {
        when(promptService.getPrompts()).thenReturn(List.of(promptResponse));

        webClient.get()
                .uri("/api/prompts")
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class)
                .value(body -> {
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> list = (List<Map<String, Object>>) body;
                    // SnakeCaseStrategy: "id" not "id"
                });
    }

    @Test
    void testListPrompts_empty() {
        when(promptService.getPrompts()).thenReturn(List.of());

        webClient.get()
                .uri("/api/prompts")
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectBody(List.class)
                .value(body -> {
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> list = (List<Map<String, Object>>) body;
                });
    }

    // -------------------------------------------------------------------------
    // POST /api/prompts
    // -------------------------------------------------------------------------

    @Test
    void testCreatePrompt() {
        PromptCreate body = new PromptCreate("New Prompt", "Description", "Prompt text", "GigaChat-2-Max", true);
        when(promptService.createPrompt(eq(body))).thenReturn(promptResponse);

        webClient.post()
                .uri("/api/prompts")
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(PromptResponse.class)
                .value(resp -> {
                });
    }

    @Test
    void testCreatePrompt_defaultShared() {
        // shared = null → default true
        PromptCreate body = new PromptCreate("New Prompt", "Description", "Prompt text", null, null);
        when(promptService.createPrompt(eq(body))).thenReturn(promptResponse);

        webClient.post()
                .uri("/api/prompts")
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON);
    }

    @Test
    void testUpdatePrompt() {
        PromptUpdate body = new PromptUpdate("Updated Title", "New Description", "New text", "GigaChat", false);
        when(promptService.updatePrompt(eq(promptId), eq(body))).thenReturn(promptResponse);

        webClient.put()
                .uri("/api/prompts/{id}", promptId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(PromptResponse.class);
    }

    @Test
    void testUpdatePrompt_nullFields() {
        // null fields should not be changed
        PromptUpdate body = new PromptUpdate(null, null, "New text only", null, null);
        when(promptService.updatePrompt(eq(promptId), eq(body))).thenReturn(promptResponse);

        webClient.put()
                .uri("/api/prompts/{id}", promptId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON);
    }

    @Test
    void testDeletePrompt() {
        doNothing().when(promptService).deletePrompt(eq(promptId));

        webClient.delete()
                .uri("/api/prompts/{id}", promptId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isNoContent();
    }

    // -------------------------------------------------------------------------
    // POST /api/prompts/{id}/rating
    // -------------------------------------------------------------------------

    @Test
    void testRatePrompt() {
        doNothing().when(promptService).ratePrompt(eq(promptId), eq(5));

        webClient.post()
                .uri("/api/prompts/{id}/rating", promptId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(Map.of("rating", 5))
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void testRatePrompt_missingRatingField() {
        // DTO без поля rating → null → IllegalArgumentException
        // (как в rateScenario_ShouldReturnBadRequest_WhenMissingRatingField)
        webClient.post()
                .uri("/api/prompts/{id}/rating", promptId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new PromptRateRequest(null))
                .exchange()
                .expectStatus().is5xxServerError();
    }

    @Test
    void testRatePrompt_notFound() {
        doThrow(new NotFoundException("Промпт не найден: " + promptId))
                .when(promptService).ratePrompt(eq(promptId), eq(3));

        webClient.post()
                .uri("/api/prompts/{id}/rating", promptId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(Map.of("rating", 3))
                .exchange()
                .expectStatus().isNotFound();
    }

    // -------------------------------------------------------------------------
    // POST /api/prompts/{id}/use
    // -------------------------------------------------------------------------

    @Test
    void testUsePrompt() {
        when(promptService.usePrompt(eq(promptId))).thenReturn("Test prompt text");

        webClient.post()
                .uri("/api/prompts/{id}/use", promptId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(Map.class)
                .value(body -> {
                    @SuppressWarnings("unchecked")
                    Map<String, String> map = (Map<String, String>) body;
                });
    }

    @Test
    void testUsePrompt_notFound() {
        when(promptService.usePrompt(eq(promptId)))
                .thenThrow(new NotFoundException("Промпт не найден: " + promptId));

        webClient.post()
                .uri("/api/prompts/{id}/use", promptId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isNotFound();
    }
}
