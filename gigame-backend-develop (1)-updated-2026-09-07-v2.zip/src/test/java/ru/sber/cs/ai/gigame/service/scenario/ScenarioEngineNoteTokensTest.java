package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.GigaChatClient;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты вырезания узлов-заметок из графа и учёта токенов по кадрам.
 */
class ScenarioEngineNoteTokensTest {

    private static NodeDto node(String id, String type) {
        return NodeDto.builder()
                .id(id)
                .type(type)
                .data(NodeDataDto.builder().label(id).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    // ------------------------------------------------------------------
    // stripNoteNodes
    // ------------------------------------------------------------------

    @Test
    void stripNoteNodes_removesNotesAndTheirEdges() {
        var gd = new GraphDataDto(
                List.of(node("in", "input"), node("out", "output"),
                        node("note1", "note"), node("note2", "note")),
                List.of(new EdgeDto("e1", "in", "out", new EdgeDataDto(null)),
                        // защитный случай: ребро к заметке тоже удаляется
                        new EdgeDto("e2", "note1", "out", new EdgeDataDto(null))));

        var stripped = ScenarioEngine.stripNoteNodes(gd);

        assertEquals(List.of("in", "out"), stripped.nodes().stream().map(NodeDto::id).toList());
        assertEquals(1, stripped.edges().size());
        assertEquals("e1", stripped.edges().get(0).id());
    }

    @Test
    void stripNoteNodes_noNotes_returnsSameInstance() {
        var gd = new GraphDataDto(
                List.of(node("in", "input"), node("out", "output")),
                List.of(new EdgeDto("e1", "in", "out", new EdgeDataDto(null))));

        assertSame(gd, ScenarioEngine.stripNoteNodes(gd));
    }

    // ------------------------------------------------------------------
    // учёт токенов (кадры GigaChatClient)
    // ------------------------------------------------------------------

    @Test
    void usageCapture_sumsCallsWithinFrame() {
        GigaChatClient.beginUsageCapture();
        GigaChatClient.addCapturedUsage(Map.of("total_tokens", 100));
        GigaChatClient.addCapturedUsage(Map.of("total_tokens", 250L));
        assertEquals(350, GigaChatClient.endUsageCapture());
    }

    @Test
    void usageCapture_nestedFrame_flowsIntoParent() {
        // родитель (узел «Под-сценарий»)
        GigaChatClient.beginUsageCapture();
        GigaChatClient.addCapturedUsage(Map.of("total_tokens", 10));
        // вложенный кадр
        GigaChatClient.beginUsageCapture();
        GigaChatClient.addCapturedUsage(Map.of("total_tokens", 5));
        assertEquals(5, GigaChatClient.endUsageCapture());
        // вложенные токены влились в родительский кадр
        assertEquals(15, GigaChatClient.endUsageCapture());
    }

    @Test
    void usageCapture_noCalls_returnsNull() {
        GigaChatClient.beginUsageCapture();
        assertNull(GigaChatClient.endUsageCapture());
    }

    @Test
    void usageCapture_endWithoutBegin_isSafe() {
        assertNull(GigaChatClient.endUsageCapture());
    }

    @Test
    void usageCapture_addWithoutFrame_isIgnored() {
        GigaChatClient.addCapturedUsage(Map.of("total_tokens", 42));
        GigaChatClient.beginUsageCapture();
        assertNull(GigaChatClient.endUsageCapture());
    }

    @Test
    void usageCapture_nullOrMissingUsage_ignored() {
        GigaChatClient.beginUsageCapture();
        GigaChatClient.addCapturedUsage(null);
        GigaChatClient.addCapturedUsage(Map.of("prompt_tokens", 7));
        assertNull(GigaChatClient.endUsageCapture());
        assertTrue(true);
    }
}
