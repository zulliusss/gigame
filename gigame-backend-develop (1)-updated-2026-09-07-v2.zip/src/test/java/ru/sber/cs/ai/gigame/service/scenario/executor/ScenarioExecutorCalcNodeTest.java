package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Тесты вычислительного узла «Расчёт»: детерминированные вычисления по формулам без LLM.
 */
class ScenarioExecutorCalcNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    /** Типовой JSON с данными (плоский объект цен и количества), который вставляет предыдущий узел. */
    private static final String FLAT_INPUT = """
            Исходные данные:
            {"цена": 1250.5, "количество": 320, "ставка": 0.15}
            """;

    /** Табличные данные: объект с массивом строк (расчёт баллов). */
    private static final String TABULAR_INPUT = """
            ДАННЫЕ ДЛЯ РАСЧЁТА
            {
              "позиции": [
                {"участник": "ООО Альфа", "цена": 4210140, "срок": 120, "опыт": 7},
                {"участник": "ООО Бета",  "цена": 7840320, "срок": 90,  "опыт": 5},
                {"участник": "ООО Гамма", "цена": 4214370, "срок": 150, "опыт": 3}
              ],
              "НМЦ": 16000000
            }
            """;

    /** Конфигурация с формулами для расчёта баллов. */
    private static final String RULES_BALL = """
            {
              "формулы": [
                {"имя": "Балл_цены", "формула": "1 - (цена - МИН(цена)) / (МАКС(цена) - МИН(цена))"},
                {"имя": "Балл_срока", "формула": "1 - (срок - МИН(срок)) / (МАКС(срок) - МИН(срок))"},
                {"имя": "Итог", "формула": "0.6 * Балл_цены + 0.4 * Балл_срока"}
              ]
            }
            """;

    // ------------------------------------------------------------------
    // Хелперы: построение графа
    // ------------------------------------------------------------------

    /** Создаёт граф с одним вычислительным узлом (без родителей). */
    private static ScenarioRunGraph graphWithRules(String nodeId, String rules) {
        var calcDto = NodeDto.builder()
                .id(nodeId)
                .type(ScenarioNodeType.CALC_NODE.toString())
                .data(NodeDataDto.builder().label("Расчёт").rules(rules).build())
                .position(new PositionDto(100, 0))
                .build();
        var outDto = NodeDto.builder()
                .id("out-1")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Выход").build())
                .position(new PositionDto(200, 0))
                .build();
        var gd = new GraphDataDto(List.of(calcDto, outDto),
                List.of(new EdgeDto("e1", nodeId, "out-1", new EdgeDataDto(null))));
        return new ScenarioRunGraph(gd);
    }

    /** Устанавливает входные данные узла из графа. */
    private static void setInput(ScenarioRunGraph graph, String nodeId, String... inputs) {
        var node = graph.getNodeMap().get(nodeId);
        node.getInput().clear();
        for (String s : inputs) {
            node.getInput().add(s);
        }
    }

    // ==================================================================
    // Конструктор
    // ==================================================================

    @Test
    void testConstructor() {
        var graph = graphWithRules("calc-1", "{}");
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);
        assertNotNull(executor);
    }

    // ==================================================================
    // execute — плоский объект (одна строка)
    // ==================================================================

    @Test
    void testExecute_flatObject() {
        var graph = graphWithRules("calc-1", """
                {"формулы": [{"имя": "Итог", "формула": "цена * количество * (1 - ставка)"}]}
                """);
        setInput(graph, "calc-1", FLAT_INPUT);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        // 1250.5 * 320 * (1 - 0.15) = 1250.5 * 320 * 0.85 = 340136
        assertTrue(result.contains("340136"), result);
        // отчёт содержит маркер
        assertTrue(result.contains("===РЕЗУЛЬТАТЫ РАСЧЁТА==="));
        // выход передан дочернему узлу
        var child = graph.getNodeMap().get("out-1");
        assertFalse(child.getInput().isEmpty());
    }

    // ==================================================================
    // execute — табличные данные с формулами и фильтром
    // ==================================================================

    @Test
    void testExecute_withFilterAndSort() {
        var graph = graphWithRules("calc-1", """
                {
                  "формулы": [
                    {"имя": "Балл_цены", "формула": "1 - (цена - МИН(цена)) / (МАКС(цена) - МИН(цена))"},
                    {"имя": "Балл_срока", "формула": "1 - (срок - МИН(срок)) / (МАКС(срок) - МИН(срок))"}
                  ],
                  "фильтр": "цена > 4000000",
                  "сортировка": ["-Балл_цены"]
                }
                """);
        setInput(graph, "calc-1", TABULAR_INPUT);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        // после фильтра должно остаться 2 строки (Альфа 4210140, Бета 7840320 — обе > 4000000)
        assertTrue(result.contains("2"), "после фильтра осталось 2 строки");
        // строки упорядочены по убыванию Балл_цены
        assertTrue(result.contains("Бета"), "первая строка — Бета (больше цена → меньше балл)");
    }

    @Test
    void testExecute_withoutFilter_allRowsPass() {
        var graph = graphWithRules("calc-1", """
                {
                  "формулы": [
                    {"имя": "Балл_цены", "формула": "МИН(цена) / цена"}
                  ]
                }
                """);
        setInput(graph, "calc-1", TABULAR_INPUT);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        // все 3 строки прошли
        assertTrue(result.contains("3"), "все 3 строки");
    }

    // ==================================================================
    // execute — пустая конфигурация формул
    // ==================================================================

    @Test
    void testExecute_noFormulas_throws() {
        var graph = graphWithRules("calc-1", """
                {"формулы": []}
                """);
        setInput(graph, "calc-1", FLAT_INPUT);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void testExecute_emptyFormulas_throws() {
        var graph = graphWithRules("calc-1", "{}");
        setInput(graph, "calc-1", FLAT_INPUT);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    // ==================================================================
    // execute — фильтр отбрасывает все строки
    // ==================================================================

    @Test
    void testExecute_filterAllRows_throws() {
        var graph = graphWithRules("calc-1", """
                {"формулы": [{"имя": "x", "формула": "1"}], "фильтр": "цена > 999999999"}
                """);
        setInput(graph, "calc-1", TABULAR_INPUT);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    // ==================================================================
    // execute — ВПР между таблицами (ВПР по reестру таблиц)
    // ==================================================================

    @Test
    void testExecute_simpleFormulaWithGlobalVariable() {
        var graph = graphWithRules("calc-1", """
                {
                  "формулы": [
                    {"имя": "Доля", "формула": "цена / НМЦ"}
                  ]
                }
                """);
        setInput(graph, "calc-1", TABULAR_INPUT);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("===РЕЗУЛЬТАТЫ РАСЧЁТА==="));
    }

    // ==================================================================
    // execute — ВПР между таблицами (VLOOKUP по реестру таблиц)
    // ==================================================================

    @Test
    void testExecute_vlookupBetweenTables() {
        var graph = graphWithRules("calc-1", """
                {
                  "формулы": [
                    {"имя": "Результат", "формула": "ВПР(ставки; участник; 'ООО Альфа'; ставка)"}
                  ]
                }
                """);
        setInput(graph, "calc-1", """
                ДАННЫЕ ДЛЯ РАСЧЁТА
                {
                  "участники": [
                    {"участник": "ООО Альфа", "цена": 100},
                    {"участник": "ООО Бета", "цена": 200}
                  ],
                  "ставки": [
                    {"участник": "ООО Альфа", "ставка": 0.15},
                    {"участник": "ООО Бета", "ставка": 0.10}
                  ]
                }
                """);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("0.15"), result);
    }

    // ==================================================================
    // execute — группировка
    // ==================================================================

    @Test
    void testExecute_groupBy() {
        var graph = graphWithRules("calc-1", """
                {
                  "формулы": [
                    {"имя": "Балл", "формула": "цена"}
                  ],
                  "группировка": "тип"
                }
                """);
        String input = """
                ДАННЫЕ ДЛЯ РАСЧЁТА
                {
                  "строки": [
                    {"тип": "A", "цена": 100, "название": "Первый"},
                    {"тип": "B", "цена": 200, "название": "Второй"},
                    {"тип": "A", "цена": 300, "название": "Третий"}
                  ]
                }
                """;
        setInput(graph, "calc-1", input);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("Свод по группам"));
        assertTrue(result.contains("A") || result.contains("B"));
    }

    // ==================================================================
    // execute — детерминированность (одинаковый вход → одинаковый выход)
    // ==================================================================

    @Test
    void testExecute_deterministicIdenticalInput() {
        var graph1 = graphWithRules("calc-1", RULES_BALL);
        setInput(graph1, "calc-1", TABULAR_INPUT);
        var node1 = graph1.getNodeMap().get("calc-1");
        var r1 = new ScenarioExecutorCalcNode(node1).execute(sink);

        var graph2 = graphWithRules("calc-1", RULES_BALL);
        setInput(graph2, "calc-1", TABULAR_INPUT);
        var node2 = graph2.getNodeMap().get("calc-1");
        var r2 = new ScenarioExecutorCalcNode(node2).execute(sink);

        assertEquals(r1, r2);
    }

    // ==================================================================
    // execute — предупреждения при нечисловых значениях
    // ==================================================================

    @Test
    void testExecute_warning_whenZNAChDefault() {
        var graph = graphWithRules("calc-1", """
                {"формулы": [{"имя": "Итог", "формула": "ЗНАЧ(сумма; 0) / 2"}]}
                """);
        String input = """
                ДАННЫЕ ДЛЯ РАСЧЁТА
                {"строки": [
                  {"сумма": 1000, "название": "Первый"},
                  {"название": "Второй"}
                ]}
                """;
        setInput(graph, "calc-1", input);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        // Вторая строка: сумма отсутствует → ЗНАЧ(сумма; 0) → предупреждение
        assertTrue(result.contains("⚠️") || result.contains("Предупреждение"));
    }

    // ==================================================================
    // execute — строка с меткой данных
    // ==================================================================

    @Test
    void testExecute_dataMarkerUsedCorrectly() {
        var graph = graphWithRules("calc-1", """
                {"формулы": [{"имя": "Итог", "формула": "цена"}]}
                """);
        // Данные после маркера ДАННЫЕ ДЛЯ РАСЧЁТА — основная таблица из последнего JSON
        String input = """
                Текст до маркера: что-то прочее
                ДАННЫЕ ДЛЯ РАСЧЁТА
                {"таблица": [{"цена": 100}], "общие": {"цена": 1}}
                """;
        setInput(graph, "calc-1", input);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("100"), "должна взять таблицу после маркера");
    }

    // ==================================================================
    // execute — плоский объект без таблицы (список из одной строки)
    // ==================================================================

    @Test
    void testExecute_simpleObjectNoList() {
        var graph = graphWithRules("calc-1", """
                {"формулы": [{"имя": "Итог", "формула": "цена * количество"}]}
                """);
        setInput(graph, "calc-1", """
                ДАННЫЕ ДЛЯ РАСЧЁТА
                {"цена": 10, "количество": 5}
                """);
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("50"), "10 * 5 = 50");
    }

    // ==================================================================
    // execute — без данных throws
    // ==================================================================

    @Test
    void testExecute_noDataMarker_throws() {
        var graph = graphWithRules("calc-1", """
                {"формулы": [{"имя": "x", "формула": "1"}]}
                """);
        setInput(graph, "calc-1", "просто текст без JSON");
        var node = graph.getNodeMap().get("calc-1");
        var executor = new ScenarioExecutorCalcNode(node);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }
}