package ru.sber.cs.ai.gigame.exception;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;

import java.time.OffsetDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class ErrorResponseTest {

    @Test
    void testErrorResponseBuilder() {
        ErrorResponse response = ErrorResponse.builder()
                .statusCode(400)
                .error("Bad Request")
                .message("Invalid input")
                .timestamp(OffsetDateTime.now())
                .build();

        assertEquals(400, response.getStatusCode());
        assertEquals("Bad Request", response.getError());
        assertEquals("Invalid input", response.getMessage());
        assertNotNull(response.getTimestamp());
    }

    @Test
    void testErrorResponseOf_NotFoundException() {
        NotFoundException ex = new NotFoundException("Not found");
        ErrorResponse response = ErrorResponse.of(ex);

        assertEquals(404, response.getStatusCode());
        assertEquals("Not Found", response.getError());
        assertEquals("Not found", response.getMessage());
        assertNotNull(response.getTimestamp());
    }

    @Test
    void testErrorResponseOf_AccessDeniedException() {
        AccessDeniedException ex = new AccessDeniedException("Access denied");
        ErrorResponse response = ErrorResponse.of(ex);

        assertEquals(403, response.getStatusCode());
        assertEquals("Forbidden", response.getError());
        assertEquals("Access denied", response.getMessage());
    }

    @Test
    void testErrorResponseOf_FileException() {
        FileException ex = new FileException("File error");
        ErrorResponse response = ErrorResponse.of(ex);

        assertEquals(422, response.getStatusCode());
        assertEquals("Unprocessable Entity", response.getError());
        assertEquals("File error", response.getMessage());
    }

    @Test
    void testErrorResponseOf_ScenarioException() {
        ScenarioException ex = new ScenarioException("Scenario error");
        ErrorResponse response = ErrorResponse.of(ex);

        assertEquals(400, response.getStatusCode());
        assertEquals("Bad Request", response.getError());
        assertEquals("Scenario error", response.getMessage());
    }

    @Test
    void testGetErrorName_400() {
        String result = getErrorName(400);
        assertEquals("Bad Request", result);
    }

    @Test
    void testGetErrorName_403() {
        String result = getErrorName(403);
        assertEquals("Forbidden", result);
    }

    @Test
    void testGetErrorName_404() {
        String result = getErrorName(404);
        assertEquals("Not Found", result);
    }

    @Test
    void testGetErrorName_409() {
        String result = getErrorName(409);
        assertEquals("Conflict", result);
    }

    @Test
    void testGetErrorName_422() {
        String result = getErrorName(422);
        assertEquals("Unprocessable Entity", result);
    }

    @Test
    void testGetErrorName_500() {
        String result = getErrorName(500);
        assertEquals("Internal Server Error", result);
    }

    @Test
    void testGetErrorName_503() {
        String result = getErrorName(503);
        assertEquals("Service Unavailable", result);
    }

    @Test
    void testGetErrorName_unknown() {
        String result = getErrorName(505);
        assertEquals("Unknown Error", result);
    }

    private String getErrorName(int statusCode) {
        return switch (statusCode) {
            case 400 -> "Bad Request";
            case 403 -> "Forbidden";
            case 404 -> "Not Found";
            case 409 -> "Conflict";
            case 422 -> "Unprocessable Entity";
            case 500 -> "Internal Server Error";
            case 503 -> "Service Unavailable";
            default -> "Unknown Error";
        };
    }
}
