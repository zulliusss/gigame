package ru.sber.cs.ai.gigame.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

class JacksonConfigTest {

    @Test
    void objectMapper_shouldHaveJavaTimeModule() {
        JacksonConfig config = new JacksonConfig();
        ObjectMapper mapper = config.objectMapper();

        assertThat(mapper).isNotNull();
    }

    @Test
    void objectMapper_shouldExcludeNullFields() {
        JacksonConfig config = new JacksonConfig();
        ObjectMapper mapper = config.objectMapper();

        DateTimeWrapper wrapper = new DateTimeWrapper();
        wrapper.setLocalDateTime(null);
        String json;
        try {
            json = mapper.writeValueAsString(wrapper);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        assertThat(json).doesNotContain("nullValue");
    }

    @Test
    void objectMapper_shouldIgnoreUnknownProperties() {
        JacksonConfig config = new JacksonConfig();
        ObjectMapper mapper = config.objectMapper();

        String json = "{\"localDateTime\":\"2026-05-15T14:30:45\",\"unknownField\":\"value\"}";
        DateTimeWrapper result;
        try {
            result = mapper.readValue(json, DateTimeWrapper.class);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        assertThat(result).isNotNull();
        assertThat(result.getLocalDateTime()).isNotNull();
    }

    @Test
    void objectMapper_shouldSerializeLocalDateTimeAsIsoFormat() {
        JacksonConfig config = new JacksonConfig();
        ObjectMapper mapper = config.objectMapper();

        LocalDateTime now = LocalDateTime.of(2026, 5, 15, 14, 30, 45);
        DateTimeWrapper wrapper = new DateTimeWrapper();
        wrapper.setLocalDateTime(now);
        String json;
        try {
            json = mapper.writeValueAsString(wrapper);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        assertThat(json).contains("2026-05-15T14:30:45");
    }

    @Setter
    @Getter
    private static class DateTimeWrapper {
        private LocalDateTime localDateTime;
    }
}
