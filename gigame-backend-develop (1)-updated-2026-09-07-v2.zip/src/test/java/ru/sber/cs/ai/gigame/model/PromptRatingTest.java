package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Unit tests for {@link PromptRating} and its nested {@link PromptRating.Key} class.
 */
class PromptRatingTest {

    // -------------------------------------------------------------------------
    // PromptRating.Key — constructor & fields
    // -------------------------------------------------------------------------

    @Test
    void keyConstructor_setsFields() {
        UUID promptId = UUID.randomUUID();
        String userId = "test-user";

        PromptRating.Key key = new PromptRating.Key(promptId, userId);

        assertEquals(promptId, key.getPromptId());
        assertEquals(userId, key.getUserId());
    }

    @Test
    void keyNoArgsConstructor_createsEmptyKey() {
        PromptRating.Key key = new PromptRating.Key();

        assertNotNull(key);
        assertFalse(key.getPromptId() != null && key.getUserId() != null);
    }

    // -------------------------------------------------------------------------
    // PromptRating.Key — equals (symmetry, reflexivity, consistency, null, type)
    // -------------------------------------------------------------------------
    @Test
    void keyEquals_withSameObject() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-1";
        PromptRating.Key key = new PromptRating.Key(promptId, userId);
        assertEquals(promptId, key.getPromptId());
        assertEquals(userId, key.getUserId());
    }

    @Test
    void keyEquals_withDifferentPromptId() {
        UUID promptId1 = UUID.randomUUID();
        UUID promptId2 = UUID.randomUUID();
        String userId = "user-1";

        PromptRating.Key key1 = new PromptRating.Key(promptId1, userId);
        PromptRating.Key key2 = new PromptRating.Key(promptId2, userId);

        assertNotEquals(key1, key2);
        assertNotEquals(key2, key1);
    }

    @Test
    void keyEquals_withDifferentUserId() {
        UUID promptId = UUID.randomUUID();
        String userId1 = "user-1";
        String userId2 = "user-2";

        PromptRating.Key key1 = new PromptRating.Key(promptId, userId1);
        PromptRating.Key key2 = new PromptRating.Key(promptId, userId2);

        assertNotEquals(key1, key2);
        assertNotEquals(key2, key1);
    }

    @Test
    void keyEquals_withDifferentPromptIdAndUserId() {
        PromptRating.Key key1 = new PromptRating.Key(UUID.randomUUID(), "user-1");
        PromptRating.Key key2 = new PromptRating.Key(UUID.randomUUID(), "user-2");

        assertNotEquals(key1, key2);
    }

    @Test
    void keyEquals_withSameValues_returnsTrue() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-1";

        PromptRating.Key key1 = new PromptRating.Key(promptId, userId);
        PromptRating.Key key2 = new PromptRating.Key(promptId, userId);

        assertEquals(key1, key2);
        assertEquals(key2, key1);
    }

    @Test
    void keyEquals_withNullFields_throwsNPE() {
        // The Key.equals implementation does not guard against null UUID,
        // so calling equals between two different keys with null promptId throws NPE.
        // Self-equals is safe due to the `this == o` guard.
        PromptRating.Key key1 = new PromptRating.Key(null, "user-a");
        PromptRating.Key key2 = new PromptRating.Key(null, "user-b");

        // equals throws NPE because promptId is null and .equals() is called on it
        assertThrows(NullPointerException.class, () -> key1.equals(key2));
    }

    @Test
    void keyEquals_withDifferentNullFields() {
        PromptRating.Key key1 = new PromptRating.Key(UUID.randomUUID(), null);
        PromptRating.Key key2 = new PromptRating.Key(null, null);

        assertNotEquals(key1, key2);
    }

    // -------------------------------------------------------------------------
    // PromptRating.Key — hashCode
    // -------------------------------------------------------------------------

    @Test
    void keyHashCode_consistentAcrossCalls() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-1";
        PromptRating.Key key = new PromptRating.Key(promptId, userId);

        int hash1 = key.hashCode();
        int hash2 = key.hashCode();

        assertEquals(hash1, hash2);
    }

    @Test
    void keyHashCode_equalKeysHaveEqualHash() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-1";

        PromptRating.Key key1 = new PromptRating.Key(promptId, userId);
        PromptRating.Key key2 = new PromptRating.Key(promptId, userId);

        assertEquals(key1.hashCode(), key2.hashCode());
    }

    @Test
    void keyHashCode_differentKeysHaveDifferentHash() {
        PromptRating.Key key1 = new PromptRating.Key(UUID.randomUUID(), "user-1");
        PromptRating.Key key2 = new PromptRating.Key(UUID.randomUUID(), "user-2");

        // Note: hash collision is technically possible but extremely unlikely
        assertNotEquals(key1.hashCode(), key2.hashCode());
    }

    @Test
    void keyHashCode_withNullFields_throwsNPE() {
        // The Key.hashCode implementation does not guard against null UUID,
        // so calling hashCode on a key with null promptId throws NPE
        PromptRating.Key key = new PromptRating.Key(null, null);

        assertThrows(
                NullPointerException.class, key::hashCode);
    }

    @Test
    void keyHashCode_contract_withEquals() {
        // Collect many keys and verify the hashCode/equality contract
        UUID promptId = UUID.randomUUID();

        PromptRating.Key keyA = new PromptRating.Key(promptId, "alice");
        PromptRating.Key keyB = new PromptRating.Key(promptId, "alice");
        PromptRating.Key keyC = new PromptRating.Key(promptId, "bob");

        // equal => same hash
        assertEquals(keyA, keyB);
        assertEquals(keyA.hashCode(), keyB.hashCode());

        // not equal => possibly different hash
        assertNotEquals(keyA, keyC);
        assertNotEquals(keyA.hashCode(), keyC.hashCode());
    }

    // -------------------------------------------------------------------------
    // PromptRating — entity getters / setters
    // -------------------------------------------------------------------------

    @Test
    void promptRatingNoArgsConstructor_createsEntity() {
        PromptRating rating = new PromptRating();

        assertNotNull(rating);
    }

    @Test
    void promptRatingSettersAndGetters() {
        PromptRating rating = new PromptRating();
        UUID promptId = UUID.randomUUID();
        String userId = "user-123";
        Integer ratingVal = 4;
        OffsetDateTime updatedAt = OffsetDateTime.now();

        rating.setPromptId(promptId);
        rating.setUserId(userId);
        rating.setRating(ratingVal);
        rating.setUpdatedAt(updatedAt);

        assertEquals(promptId, rating.getPromptId());
        assertEquals(userId, rating.getUserId());
        assertEquals(ratingVal, rating.getRating());
        assertEquals(updatedAt, rating.getUpdatedAt());
    }

    @Test
    void promptRatingSettersReturnThis_forFluentChaining() {
        PromptRating rating = new PromptRating();

        // Lombok @Setter should return void, but verify basic setter behaviour
        UUID promptId = UUID.randomUUID();
        rating.setPromptId(promptId);
        assertEquals(promptId, rating.getPromptId());
    }

    @Test
    void promptRatingRatingField_canStoreAllValues() {
        for (int val = 1; val <= 5; val++) {
            PromptRating rating = new PromptRating();
            rating.setRating(val);
            assertEquals(val, rating.getRating());
        }
    }

    // -------------------------------------------------------------------------
    // PromptRating.Key — general contract helpers
    // -------------------------------------------------------------------------

    @Test
    void keyHashCode_nullPointerHandling() {
        // hashCode throws NPE when promptId is null (by design in implementation)
        PromptRating.Key key = new PromptRating.Key();
        key.setPromptId(null);
        key.setUserId(null);

        assertThrows(
                NullPointerException.class, key::hashCode);
    }

    @Test
    void keyEquals_transitive() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-trans";

        PromptRating.Key key1 = new PromptRating.Key(promptId, userId);
        PromptRating.Key key2 = new PromptRating.Key(promptId, userId);
        PromptRating.Key key3 = new PromptRating.Key(promptId, userId);

        assertEquals(key1, key2);
        assertEquals(key2, key3);
        assertEquals(key1, key3);
    }

    @Test
    void promptRating_entity_fields_allNullableByDefault() {
        PromptRating rating = new PromptRating();

        // All fields are null by default (no-arg constructor from Lombok)
        assertNull(rating.getPromptId());
        assertNull(rating.getUserId());
        assertNull(rating.getRating());
        assertNull(rating.getUpdatedAt());
    }
}
