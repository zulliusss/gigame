package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioNodeTest {

    // ------------------ Builders ------------------

    private NodeDataDto.NodeDataDtoBuilder dataBuilder() {
        return NodeDataDto.builder();
    }

    private NodeDto.NodeDtoBuilder dtoBuilder() {
        return NodeDto.builder();
    }

    // ------------------ Tests ------------------

    @Test
    void testConstructor_withAllFields() {
        NodeDataDto data = dataBuilder()
                .label("Test Label")
                .rules("rules text")
                .prompt("prompt text")
                .mode("specific")
                .classifyStrict("true")
                .classes("class1,class2")
                .field("field")
                .operator("contains")
                .value("value")
                .knowledgeBaseId(UUID.randomUUID().toString())
                .build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();
        ScenarioRunNode node = new ScenarioRunNode(dto);

        assertNotNull(node);
        assertEquals("node-1", node.getId());
        assertEquals(ScenarioNodeType.PROCESSING_NODE, node.getType());
        assertEquals("Test Label", node.getLabel());
        assertEquals(0, node.getIndex());
        assertEquals(0, node.getTotal());
        assertEquals("rules text", node.getRules());
        assertEquals("prompt text", node.getPrompt());
        assertEquals("specific", node.getMode());
        assertTrue(node.isClassifyStrict());
        assertEquals("class1,class2", node.getClasses());
        assertEquals("field", node.getField());
        assertEquals("contains", node.getOperator());
        assertEquals("value", node.getValue());
        assertNotNull(node.getKnowledgeBaseId());
    }

    @Test
    void testFromDto_withAllFields() {
        NodeDataDto data = dataBuilder()
                .label("Test Label")
                .rules("rules text")
                .prompt("prompt text")
                .mode("specific")
                .classifyStrict("true")
                .classes("class1,class2")
                .field("field")
                .operator("contains")
                .value("value")
                .knowledgeBaseId(UUID.randomUUID().toString())
                .build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();
        GraphDataDto graphData = new GraphDataDto(List.of(dto), List.of());
        ScenarioRunNode node = ScenarioRunNode.fromDto(1, dto, new ScenarioRunGraph(graphData));

        assertNotNull(node);
        assertEquals("node-1", node.getId());
        assertEquals(ScenarioNodeType.PROCESSING_NODE, node.getType());
        assertEquals("Test Label", node.getLabel());
        assertEquals(1, node.getIndex());
        assertEquals(1, node.getTotal());
        assertEquals("rules text", node.getRules());
        assertEquals("prompt text", node.getPrompt());
        assertEquals("specific", node.getMode());
        assertTrue(node.isClassifyStrict());
        assertEquals("class1,class2", node.getClasses());
        assertEquals("field", node.getField());
        assertEquals("contains", node.getOperator());
        assertEquals("value", node.getValue());
        assertNotNull(node.getKnowledgeBaseId());
    }

    @Test
    void testFromDto_withMinimalFields() {
        // Все поля null по умолчанию
        NodeDataDto data = dataBuilder().build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();
        GraphDataDto graphData = new GraphDataDto(List.of(dto), List.of());
        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, new ScenarioRunGraph(graphData));
        assertNotNull(node);
        assertEquals("node-1", node.getId());
        assertEquals(ScenarioNodeType.INPUT_NODE, node.getType());
        assertEquals(ScenarioNodeType.INPUT_NODE.toString(), node.getLabel());
        assertEquals(0, node.getIndex());
        assertEquals(1, node.getTotal());
        assertEquals("[]", node.getRules());
        assertEquals("", node.getPrompt());
        assertEquals("all", node.getMode());
        assertFalse(node.isClassifyStrict());
        assertEquals("", node.getClasses());
    }

    @Test
    void testFromDto_withEmptyNodeType() {
        NodeDataDto data = dataBuilder().label("Label").build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(null)
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals(ScenarioNodeType.UNKNOWN, node.getType());
    }

    @Test
    void testFromDto_withEmptyLabel() {
        NodeDataDto data = dataBuilder().label("").build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals(ScenarioNodeType.OUTPUT_NODE, node.getType());
        assertEquals(ScenarioNodeType.OUTPUT_NODE.toString(), node.getLabel());
    }

    @Test
    void testFromDto_withNullLabel() {
        NodeDataDto data = dataBuilder().label(null).build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.SWITCH_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals(ScenarioNodeType.SWITCH_NODE, node.getType());
        assertEquals(ScenarioNodeType.SWITCH_NODE.toString(), node.getLabel());
    }

    @Test
    void testFromDto_withNullRules() {
        NodeDataDto data = dataBuilder().rules(null).label("Label").build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals("[]", node.getRules());
    }

    @Test
    void testFromDto_withEmptyRules() {
        NodeDataDto data = dataBuilder().rules("").label("Label").build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals("[]", node.getRules());
    }

    @Test
    void testFromDto_withNullPrompt() {
        NodeDataDto data = dataBuilder().label("Label").prompt(null).build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals("", node.getPrompt());
    }

    @Test
    void testFromDto_withEmptyMode() {
        NodeDataDto data = dataBuilder().label("Label").mode("").build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals("all", node.getMode());
    }

    @Test
    void testFromDto_withNullClassifyStrict() {
        NodeDataDto data = dataBuilder().label("Label").classifyStrict(null).build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertFalse(node.isClassifyStrict());
    }

    @Test
    void testFromDto_withFalseClassifyStrict() {
        NodeDataDto data = dataBuilder().label("Label").classifyStrict("false").build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertFalse(node.isClassifyStrict());
    }

    @Test
    void testFromDto_withClasses() {
        NodeDataDto data = dataBuilder()
                .label("Label")
                .mode("all")
                .classes("class1,class2,class3")
                .build();

        NodeDto dto = dtoBuilder()
                .id("node-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(data)
                .position(new PositionDto(100, 100))
                .build();

        ScenarioRunNode node = ScenarioRunNode.fromDto(0, dto, null);

        assertEquals("class1,class2,class3", node.getClasses());
    }

    @Test
    void testFromDto_differentNodeTypes() {
        // Input node
        NodeDto inputNode = dtoBuilder()
                .id("input")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(dataBuilder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
        ScenarioRunNode input = ScenarioRunNode.fromDto(0, inputNode, null);
        assertEquals(ScenarioNodeType.INPUT_NODE, input.getType());

        // Loop node
        NodeDto loopNode = dtoBuilder()
                .id("loop")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(dataBuilder()
                        .label("Loop")
                        .rules("rules")
                        .mode("all")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        ScenarioRunNode loop = ScenarioRunNode.fromDto(1, loopNode, null);
        assertEquals(ScenarioNodeType.LOOP_NODE, loop.getType());

        // Switch node
        NodeDto switchNode = dtoBuilder()
                .id("switch")
                .type(ScenarioNodeType.SWITCH_NODE.toString())
                .data(dataBuilder()
                        .label("Switch")
                        .rules("rules")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        ScenarioRunNode switchN = ScenarioRunNode.fromDto(2, switchNode, null);
        assertEquals(ScenarioNodeType.SWITCH_NODE, switchN.getType());

        // If node
        NodeDto ifNode = dtoBuilder()
                .id("if")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(dataBuilder().label("If").build())
                .position(new PositionDto(100, 100))
                .build();
        ScenarioRunNode ifNodeObj = ScenarioRunNode.fromDto(3, ifNode, null);
        assertEquals(ScenarioNodeType.IF_NODE, ifNodeObj.getType());

        // Output node
        NodeDto outputNode = dtoBuilder()
                .id("output")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(dataBuilder().label("Output").build())
                .position(new PositionDto(100, 100))
                .build();
        ScenarioRunNode output = ScenarioRunNode.fromDto(4, outputNode, null);
        assertEquals(ScenarioNodeType.OUTPUT_NODE, output.getType());
    }

}