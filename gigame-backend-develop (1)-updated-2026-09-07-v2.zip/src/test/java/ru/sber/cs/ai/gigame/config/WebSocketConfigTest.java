package ru.sber.cs.ai.gigame.config;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNullApi;

import static org.assertj.core.api.Assertions.assertThat;

class WebSocketConfigTest {

    @Test
    void configShouldBeConfigurationClass() {
        assertThat(WebSocketConfig.class.getAnnotation(Configuration.class))
                .isNotNull();
    }

    @Test
    void configShouldHaveRequiredArgsConstructor() {
        assertThat(WebSocketConfig.class.getAnnotation(NonNullApi.class))
                .isNull();
    }

    @Test
    void configClassShouldExist() {
        assertThat(WebSocketConfig.class).isNotNull();
    }

    @Test
    void configShouldHaveBeanMethod() {
        boolean hasBeanMethod = false;
        for (java.lang.reflect.Method method : WebSocketConfig.class.getDeclaredMethods()) {
            if (method.isAnnotationPresent(Bean.class)) {
                hasBeanMethod = true;
                break;
            }
        }
        assertThat(hasBeanMethod).isTrue();
    }
}
