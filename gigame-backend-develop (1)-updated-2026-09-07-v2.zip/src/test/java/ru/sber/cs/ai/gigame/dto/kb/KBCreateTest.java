package ru.sber.cs.ai.gigame.dto.kb;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class KBCreateTest {

    @Test
    void testConstruction_withAllFields() {
        var dto = new KBCreate("KB Name", "Description here", true);
        assertEquals("KB Name", dto.name());
        assertEquals("Description here", dto.description());
        assertTrue(dto.shared());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new KBCreate(null, null, null);
        assertNull(dto.name());
        assertNull(dto.description());
        assertNull(dto.shared());
    }
}
