package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты шаблона формы XLSX (rules output-узла): фиксированные колонки,
 * двухуровневая шапка, обратная совместимость.
 */
class ScenarioResultToXlsxTemplateTest {

    private static final String DATA_JSON = """
            [
              {"исполнитель": "ООО ГлоуБайт", "договор": "3730725", "сумма": 4210140,
               "лишний_ключ": "игнорируется"},
              {"исполнитель": "ООО ГлоуБайт", "сумма": 7840320}
            ]
            """;

    private static Sheet readSheet(byte[] xlsx) throws IOException {
        return new XSSFWorkbook(new ByteArrayInputStream(xlsx)).getSheetAt(0);
    }

    @Test
    void template_fixedColumnsInOrder_missingKeysEmpty() throws IOException {
        String rules = """
                {"колонки": [
                  {"ключ": "договор", "заголовок": "Реквизиты договора"},
                  {"ключ": "исполнитель", "заголовок": "Наименование участника"},
                  {"ключ": "сумма", "заголовок": "Сумма, руб."}
                ]}
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, rules));

        // одна строка шапки (групп нет)
        var header = sheet.getRow(0);
        assertEquals("Реквизиты договора", header.getCell(0).getStringCellValue());
        assertEquals("Наименование участника", header.getCell(1).getStringCellValue());
        assertEquals("Сумма, руб.", header.getCell(2).getStringCellValue());
        // данные: порядок по шаблону, отсутствующий ключ — пустая ячейка, лишний игнорируется
        // числа пишутся ЧИСЛОВЫМИ ячейками (для Excel-аналитики и локали пользователя)
        var row1 = sheet.getRow(1);
        assertEquals("3730725", row1.getCell(0).getStringCellValue());
        assertEquals("ООО ГлоуБайт", row1.getCell(1).getStringCellValue());
        assertEquals(4210140.0, row1.getCell(2).getNumericCellValue());
        assertEquals(3, (int) row1.getLastCellNum());
        var row2 = sheet.getRow(2);
        assertEquals("", row2.getCell(0).getStringCellValue());
        assertEquals(7840320.0, row2.getCell(2).getNumericCellValue());
    }

    @Test
    void template_twoLevelHeader_mergesAdjacentGroups() throws IOException {
        String rules = """
                {"лист": "Форма 3",
                 "колонки": [
                  {"ключ": "исполнитель", "заголовок": "Участник", "группа": "Основные данные"},
                  {"ключ": "договор", "заголовок": "Договор", "группа": "Основные данные"},
                  {"ключ": "сумма", "заголовок": "Сумма", "группа": "Квалификация"}
                ]}
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, rules));

        assertEquals("Форма 3", sheet.getSheetName());
        // строка 0 — группы, строка 1 — заголовки, строка 2 — первая строка данных
        assertEquals("Основные данные", sheet.getRow(0).getCell(0).getStringCellValue());
        assertEquals("Квалификация", sheet.getRow(0).getCell(2).getStringCellValue());
        assertEquals("Участник", sheet.getRow(1).getCell(0).getStringCellValue());
        assertEquals("ООО ГлоуБайт", sheet.getRow(2).getCell(0).getStringCellValue());
        // объединение соседних одинаковых групп: A1:B1
        List<CellRangeAddress> merged = sheet.getMergedRegions();
        assertTrue(merged.stream().anyMatch(r ->
                r.getFirstRow() == 0 && r.getLastRow() == 0
                        && r.getFirstColumn() == 0 && r.getLastColumn() == 1));
    }

    @Test
    void largeDecimalNumbers_renderedAsNumericCells() throws IOException {
        String rules = "{\"колонки\": [{\"ключ\": \"сумма\", \"заголовок\": \"Сумма\"}]}";
        String data = "[{\"сумма\": 12137779.5}, {\"сумма\": 7840320.0}]";
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(data, rules));

        assertEquals(12137779.5, sheet.getRow(1).getCell(0).getNumericCellValue());
        assertEquals(7840320.0, sheet.getRow(2).getCell(0).getNumericCellValue());
    }

    @Test
    void decimalStrings_becomeNumericCells_integerStringsStayText() throws IOException {
        // суммы-строки «986724.24» из LLM-JSON → числовые ячейки (Excel показывает
        // по локали — с запятой в русской); целые строки (номера, ИНН) — текст
        String rules = """
                {"колонки": [
                  {"ключ": "сумма", "заголовок": "Сумма"},
                  {"ключ": "номер", "заголовок": "Номер договора"}
                ]}
                """;
        String data = "[{\"сумма\": \"986724.24\", \"номер\": \"50005020373\"}]";
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(data, rules));

        assertEquals(986724.24, sheet.getRow(1).getCell(0).getNumericCellValue());
        assertEquals("50005020373", sheet.getRow(1).getCell(1).getStringCellValue());
    }

    @Test
    void prefixColumn_expandsIntoColumnPerMatchingKey() throws IOException {
        // динамическая колонка: по одной на каждую технологию из данных,
        // сколько бы их ни было (кейс «5 технологий — только 3 колонки»)
        String rules = """
                {"колонки": [
                  {"ключ": "договор", "заголовок": "Договор"},
                  {"ключ_префикс": "тех_", "заголовок_префикс": "Технология: ", "группа": "Блок 2"}
                ]}
                """;
        String data = """
                [{"договор": "Д-1", "тех_Java": "да — п. 1.1", "тех_Python": "нет"},
                 {"договор": "Д-2", "тех_Java": "да", "тех_Go": "нет"}]
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(data, rules));

        // строка 0 — группы (у префиксных колонок есть группа), строка 1 — заголовки
        var header = sheet.getRow(1);
        assertEquals("Договор", header.getCell(0).getStringCellValue());
        assertEquals("Технология: Java", header.getCell(1).getStringCellValue());
        assertEquals("Технология: Python", header.getCell(2).getStringCellValue());
        assertEquals("Технология: Go", header.getCell(3).getStringCellValue());
        assertEquals("да — п. 1.1", sheet.getRow(2).getCell(1).getStringCellValue());
        assertEquals("", sheet.getRow(2).getCell(3).getStringCellValue());
        assertEquals("нет", sheet.getRow(3).getCell(3).getStringCellValue());
    }

    @Test
    void sectionRows_highlightedWithHeaderStyle() throws IOException {
        // строки-секции (значение только в первой колонке) выделяются стилем шапки
        String rules = """
                {"выделять_секции": true,
                 "колонки": [
                  {"ключ": "критерий", "заголовок": "Критерий"},
                  {"ключ": "значение", "заголовок": "Значение"}
                ]}
                """;
        String data = """
                [{"критерий": "Общая информация по закупке", "значение": ""},
                 {"критерий": "Категория закупки", "значение": "ИТ-ресурсы"}]
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(data, rules));

        // секция получает жирный шрифт (как у шапки), обычная строка — нет
        var wb = sheet.getWorkbook();
        var sectionFont = wb.getFontAt(sheet.getRow(1).getCell(0).getCellStyle().getFontIndex());
        var dataFont = wb.getFontAt(sheet.getRow(2).getCell(0).getCellStyle().getFontIndex());
        assertTrue(sectionFont.getBold());
        assertFalse(dataFont.getBold());
    }

    @Test
    void highlightMap_paintsCellsByValue() throws IOException {
        // подсветка вердиктов: «Соответствует» — зелёная заливка, «Не соответствует» — красная
        String rules = """
                {"колонки": [
                  {"ключ": "характеристика", "заголовок": "Характеристика"},
                  {"ключ": "решение", "заголовок": "Решение",
                   "подсветка": {"Соответствует": "зелёный", "Не соответствует": "красный"}}
                ]}
                """;
        String data = """
                [{"характеристика": "Размер", "решение": "Соответствует"},
                 {"характеристика": "Глубина корпуса", "решение": "Не соответствует"}]
                """;
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(data, rules));

        var ok = sheet.getRow(1).getCell(1).getCellStyle();
        var bad = sheet.getRow(2).getCell(1).getCellStyle();
        var plain = sheet.getRow(1).getCell(0).getCellStyle();
        assertEquals(IndexedColors.LIGHT_GREEN.getIndex(), ok.getFillForegroundColor());
        assertEquals(IndexedColors.ROSE.getIndex(), bad.getFillForegroundColor());
        assertEquals(FillPatternType.NO_FILL, plain.getFillPattern());
    }

    @Test
    void emptyArrayWithTemplate_producesHeaderOnlyWorkbook() throws IOException {
        // пустой массив при заданном шаблоне — файл с шапкой, а не ошибка узла
        String rules = "{\"колонки\": [{\"ключ\": \"а\", \"заголовок\": \"Колонка А\"}]}";
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx("[]", rules));

        assertEquals("Колонка А", sheet.getRow(0).getCell(0).getStringCellValue());
        assertEquals(0, sheet.getLastRowNum());
    }

    @Test
    void withoutTemplate_dynamicColumnsPreserved() throws IOException {
        // прежнее поведение: колонки из ключей JSON
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, null));
        assertEquals("исполнитель", sheet.getRow(0).getCell(0).getStringCellValue());
        assertEquals("Данные", sheet.getSheetName());
    }

    @Test
    void defaultRulesArray_treatedAsNoTemplate() throws IOException {
        // getRules() по умолчанию возвращает "[]" — шаблоном не считается
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON, "[]"));
        assertEquals("исполнитель", sheet.getRow(0).getCell(0).getStringCellValue());
    }

    @Test
    void foreignRulesFormat_treatedAsNoTemplate() throws IOException {
        // rules другого узла (например, calc) не ломают экспорт
        Sheet sheet = readSheet(ScenarioResultToXlsx.jsonToXlsx(DATA_JSON,
                "{\"критерии\": [{\"название\": \"Цена\"}]}"));
        assertEquals("исполнитель", sheet.getRow(0).getCell(0).getStringCellValue());
    }
}
