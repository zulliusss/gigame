package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.PromptRating;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class PromptRatingRepositoryTest {

    @Autowired
    private PromptRatingRepository underTest;

    // -------------------------------------------------------------------------
    // Save & findById (via Iterable)
    // -------------------------------------------------------------------------

    @Test
    void save_andFindByPromptIdIn_returnsRating() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-1";

        PromptRating rating = new PromptRating();
        rating.setPromptId(promptId);
        rating.setUserId(userId);
        rating.setRating(5);

        PromptRating saved = underTest.save(rating);

        assertNotNull(saved);
        assertNotNull(saved.getPromptId());

        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        assertNotNull(results);
        assertEquals(1, results.size());
        assertEquals(5, results.get(0).getRating());
    }

    @Test
    void save_multipleRatings_samePrompt_differentUsers() {
        UUID promptId = UUID.randomUUID();

        PromptRating r1 = new PromptRating();
        r1.setPromptId(promptId);
        r1.setUserId("user-alice");
        r1.setRating(5);
        underTest.save(r1);

        PromptRating r2 = new PromptRating();
        r2.setPromptId(promptId);
        r2.setUserId("user-bob");
        r2.setRating(3);
        underTest.save(r2);

        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        assertEquals(2, results.size());
    }

    @Test
    void save_multipleRatings_sameUser_differentPrompts() {
        String userId = "user-alice";

        UUID promptId1 = UUID.randomUUID();
        PromptRating r1 = new PromptRating();
        r1.setPromptId(promptId1);
        r1.setUserId(userId);
        r1.setRating(4);
        underTest.save(r1);

        UUID promptId2 = UUID.randomUUID();
        PromptRating r2 = new PromptRating();
        r2.setPromptId(promptId2);
        r2.setUserId(userId);
        r2.setRating(2);
        underTest.save(r2);

        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId1, promptId2));
        assertEquals(2, results.size());
    }

    // -------------------------------------------------------------------------
    // findByPromptIdIn edge cases
    // -------------------------------------------------------------------------

    @Test
    void findByPromptIdIn_emptyList_returnsEmptyList() {
        List<PromptRating> results = underTest.findByPromptIdIn(List.of());
        assertNotNull(results);
        assertTrue(results.isEmpty());
    }

    @Test
    void findByPromptIdIn_noMatchingPrompts_returnsEmptyList() {
        UUID nonExistentId = UUID.randomUUID();
        List<PromptRating> results = underTest.findByPromptIdIn(List.of(nonExistentId));
        assertNotNull(results);
        assertTrue(results.isEmpty());
    }

    @Test
    void findByPromptIdIn_multipleIds_partialMatch() {
        UUID promptId1 = UUID.randomUUID();
        UUID promptId2 = UUID.randomUUID();
        UUID promptId3 = UUID.randomUUID();

        PromptRating r1 = new PromptRating();
        r1.setPromptId(promptId1);
        r1.setUserId("user-1");
        r1.setRating(5);
        underTest.save(r1);

        PromptRating r3 = new PromptRating();
        r3.setPromptId(promptId3);
        r3.setUserId("user-2");
        r3.setRating(3);
        underTest.save(r3);

        // Search for all 3, but only 2 exist
        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId1, promptId2, promptId3));
        assertEquals(2, results.size());
    }

    // -------------------------------------------------------------------------
    // Update (updatedAt)
    // -------------------------------------------------------------------------

    @Test
    void save_ratingUpdatedAt_isSet() {
        UUID promptId = UUID.randomUUID();
        PromptRating rating = new PromptRating();
        rating.setPromptId(promptId);
        rating.setUserId("user-update");
        rating.setRating(4);
        rating.setUpdatedAt(OffsetDateTime.now()); // @UpdateTimestamp doesn't work in create-drop mode

        PromptRating saved = underTest.save(rating);
        assertEquals(rating.getPromptId(), saved.getPromptId());
        // After reload from DB, updatedAt should be present
        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        assertEquals(1, results.size());
        assertNotNull(results.get(0).getUpdatedAt());
    }

    @Test
    void update_rating_updatesRatingAndUpdatedAt() {
        UUID promptId = UUID.randomUUID();

        PromptRating rating = new PromptRating();
        rating.setPromptId(promptId);
        rating.setUserId("user-update");
        rating.setRating(3);
        underTest.save(rating);

        assertNull(rating.getUpdatedAt());
        rating.setRating(5);
        underTest.save(rating);

        // Reload from DB and verify
        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        assertEquals(1, results.size());
        assertEquals(5, results.get(0).getRating());
        // updatedAt should have been updated by @UpdateTimestamp
        assertNotNull(results.get(0).getUpdatedAt());
    }

    // -------------------------------------------------------------------------
    // Delete
    // -------------------------------------------------------------------------

    @Test
    void delete_byKey_removesRating() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-delete";

        PromptRating rating = new PromptRating();
        rating.setPromptId(promptId);
        rating.setUserId(userId);
        rating.setRating(5);
        PromptRating saved = underTest.save(rating);

        // Verify exists
        assertEquals(1, underTest.findByPromptIdIn(List.of(promptId)).size());

        // Delete by composite key
        underTest.delete(saved);

        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        assertTrue(results.isEmpty());
    }

    @Test
    void deleteById_removesRating() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-deletebyid";

        PromptRating rating = new PromptRating();
        rating.setPromptId(promptId);
        rating.setUserId(userId);
        rating.setRating(2);
        PromptRating saved = underTest.save(rating);
        assertEquals(rating.getPromptId(), saved.getPromptId());
        underTest.deleteById(new PromptRating.Key(promptId, userId));

        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        assertTrue(results.isEmpty());
    }

    // -------------------------------------------------------------------------
    // SaveAll
    // -------------------------------------------------------------------------

    @Test
    void saveAll_multipleRatings() {
        PromptRating r1 = new PromptRating();
        r1.setPromptId(UUID.randomUUID());
        r1.setUserId("user-batch-1");
        r1.setRating(5);

        PromptRating r2 = new PromptRating();
        r2.setPromptId(UUID.randomUUID());
        r2.setUserId("user-batch-2");
        r2.setRating(3);

        List<PromptRating> saved = underTest.saveAll(List.of(r1, r2));

        assertEquals(2, saved.size());
        assertNotNull(saved.get(0).getPromptId());
        assertNotNull(saved.get(1).getPromptId());
    }

    @Test
    void saveAll_emptyList_returnsEmptyList() {
        List<PromptRating> saved = underTest.saveAll(List.of());
        assertNotNull(saved);
        assertTrue(saved.isEmpty());
    }

    // -------------------------------------------------------------------------
    // Composite key operations
    // -------------------------------------------------------------------------

    @Test
    void save_andFindWithCompositeKey() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-composite";

        PromptRating.Key key = new PromptRating.Key(promptId, userId);

        PromptRating rating = new PromptRating();
        rating.setPromptId(key.getPromptId());
        rating.setUserId(key.getUserId());
        rating.setRating(4);

        PromptRating saved = underTest.save(rating);

        assertNotNull(saved);
        assertEquals(promptId, saved.getPromptId());
        assertEquals(userId, saved.getUserId());
    }

    @Test
    void rating_withAllRatingValues_canBeStored() {
        for (int val = 1; val <= 5; val++) {
            PromptRating rating = new PromptRating();
            rating.setPromptId(UUID.randomUUID());
            rating.setUserId("user-values-" + val);
            rating.setRating(val);
            underTest.save(rating);

            List<PromptRating> results = underTest.findByPromptIdIn(List.of(rating.getPromptId()));
            assertEquals(1, results.size());
            assertEquals(val, results.get(0).getRating());
        }
    }

    // -------------------------------------------------------------------------
    // Count and exists checks via findByPromptIdIn
    // -------------------------------------------------------------------------

    @Test
    void findByPromptIdIn_ratingFieldsAreNotNull() {
        UUID promptId = UUID.randomUUID();
        PromptRating rating = new PromptRating();
        rating.setPromptId(promptId);
        rating.setUserId("user-fields");
        rating.setRating(5);
        underTest.save(rating);

        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        PromptRating fetched = results.get(0);

        assertNotNull(fetched.getPromptId());
        assertNotNull(fetched.getUserId());
        assertNotNull(fetched.getRating());
        assertNotNull(fetched.getUpdatedAt());
    }

    // -------------------------------------------------------------------------
    // Duplicate rating (same prompt + user) — replaces via save
    // -------------------------------------------------------------------------

    @Test
    void saveSamePromptUserId_updatesExistingRating() {
        UUID promptId = UUID.randomUUID();
        String userId = "user-duplicate";

        PromptRating r1 = new PromptRating();
        r1.setPromptId(promptId);
        r1.setUserId(userId);
        r1.setRating(1);
        underTest.save(r1);

        // Save another rating with the same composite key
        PromptRating r2 = new PromptRating();
        r2.setPromptId(promptId);
        r2.setUserId(userId);
        r2.setRating(5);
        underTest.save(r2);

        // Should only have 1 (or 2) depending on DB behaviour; Hibernate typically
        // does UPDATE for same identity, so count stays 1
        List<PromptRating> results = underTest.findByPromptIdIn(List.of(promptId));
        assertEquals(1, results.size());
        assertEquals(5, results.get(0).getRating());
    }

    // -------------------------------------------------------------------------
    // Null field handling
    // -------------------------------------------------------------------------

    // Note: prompt_id is part of the composite primary key, so it cannot be null.
    // These tests verify that the repository works correctly with properly populated keys.
}
