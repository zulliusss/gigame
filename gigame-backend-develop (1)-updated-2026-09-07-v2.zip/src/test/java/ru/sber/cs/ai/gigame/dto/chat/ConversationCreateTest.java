package ru.sber.cs.ai.gigame.dto.chat;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class ConversationCreateTest {

    @Test
    void testConstruction_withAllFields() {
        var dto = new ConversationCreate("Test Title", "kb-123",
                List.of("kb-123", "kb-456"), "GigaChat-2-Max", 0.5);
        assertEquals("Test Title", dto.title());
        assertEquals("kb-123", dto.knowledgeBaseId());
        assertEquals(2, dto.knowledgeBaseIds().size());
        assertEquals("GigaChat-2-Max", dto.model());
        assertEquals(0.5, dto.temperature());
    }

    @Test
    void testConstruction_withNullFields() {
        var dto = new ConversationCreate(null, null, null, null, null);
        assertNull(dto.title());
        assertNull(dto.knowledgeBaseId());
        assertNull(dto.knowledgeBaseIds());
        assertNull(dto.model());
        assertNull(dto.temperature());
    }
}
