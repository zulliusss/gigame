package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import ru.sber.cs.ai.gigame.dto.prompt.PromptCreate;
import ru.sber.cs.ai.gigame.dto.prompt.PromptResponse;
import ru.sber.cs.ai.gigame.dto.prompt.PromptUpdate;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Prompt;
import ru.sber.cs.ai.gigame.model.PromptRating;
import ru.sber.cs.ai.gigame.repository.PromptRatingRepository;
import ru.sber.cs.ai.gigame.repository.PromptRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class PromptServiceTest {

    @Mock
    private PromptRepository promptRepository;

    @Mock
    private PromptRatingRepository promptRatingRepository;

    @InjectMocks
    private PromptService promptService;

    @Captor
    private ArgumentCaptor<Prompt> promptCaptor;

    @Captor
    private ArgumentCaptor<PromptRating> ratingCaptor;

    private String userIdStr;
    private UUID promptId;
    private Prompt prompt;

    @BeforeEach
    void setUp() {
        userIdStr = UUID.randomUUID().toString();
        promptId = UUID.randomUUID();
        prompt = new Prompt();
        prompt.setId(promptId);
        prompt.setUserId(userIdStr);
        prompt.setTitle("Test Prompt");
        prompt.setDescription("Test description");
        prompt.setText("Test text");
        prompt.setModel("GigaChat-2-Max");
        prompt.setShared(true);
        prompt.setUsageCount(0);
        prompt.setCreatedAt(OffsetDateTime.now());
        prompt.setUpdatedAt(OffsetDateTime.now());
    }

    // -------------------------------------------------------------------------
    // GET / Prompts list
    // -------------------------------------------------------------------------

    @Test
    void testGetPrompts_returnsOwnAndShared() {
        Prompt sharedPrompt = new Prompt();
        sharedPrompt.setId(UUID.randomUUID());
        sharedPrompt.setTitle("Shared Prompt");
        sharedPrompt.setShared(true);
        sharedPrompt.setCreatedAt(OffsetDateTime.now());
        sharedPrompt.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString()))
                .thenReturn(List.of(prompt, sharedPrompt));
        when(promptRatingRepository.findByPromptIdIn(any())).thenReturn(List.of());

        List<PromptResponse> result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.getPrompts());

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Test Prompt", result.get(0).title());
    }

    @Test
    void testGetPrompts_empty() {
        when(promptRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString()))
                .thenReturn(List.of());
        // when the list is empty, findByPromptIdIn is called with empty list
        when(promptRatingRepository.findByPromptIdIn(any())).thenReturn(List.of());

        List<PromptResponse> result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.getPrompts());

        assertNotNull(result);
        assertEquals(0, result.size());
    }

    @Test
    void testGetPrompts_withRatings() {
        PromptRating rating1 = new PromptRating();
        rating1.setPromptId(promptId);
        rating1.setUserId("user1");
        rating1.setRating(5);
        PromptRating rating2 = new PromptRating();
        rating2.setPromptId(promptId);
        rating2.setUserId("user2");
        rating2.setRating(3);

        when(promptRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString()))
                .thenReturn(List.of(prompt));
        when(promptRatingRepository.findByPromptIdIn(any()))
                .thenReturn(List.of(rating1, rating2));

        List<PromptResponse> result = CurrentUserHolder.withUser("user1",
                () -> promptService.getPrompts());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(4.0, result.get(0).ratingAvg());
        assertEquals(2L, result.get(0).ratingCount());
    }

    @Test
    void testGetPrompts_withMyRating() {
        PromptRating myRating = new PromptRating();
        myRating.setPromptId(promptId);
        myRating.setUserId(userIdStr);
        myRating.setRating(4);

        when(promptRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString()))
                .thenReturn(List.of(prompt));
        when(promptRatingRepository.findByPromptIdIn(any()))
                .thenReturn(List.of(myRating));

        List<PromptResponse> result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.getPrompts());

        assertNotNull(result);
        assertEquals(4, result.get(0).myRating());
    }

    @Test
    void testGetPrompts_noRatings_myRatingIsNull() {
        when(promptRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString()))
                .thenReturn(List.of(prompt));
        when(promptRatingRepository.findByPromptIdIn(any())).thenReturn(List.of());

        List<PromptResponse> result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.getPrompts());

        assertNotNull(result);
        assertNull(result.get(0).ratingAvg());
        assertEquals(0L, result.get(0).ratingCount());
        assertNull(result.get(0).myRating());
    }

    // -------------------------------------------------------------------------
    // CREATE Prompt
    // -------------------------------------------------------------------------

    @Test
    void testCreatePrompt_success() {
        PromptCreate body = new PromptCreate("New Prompt", "Description", "Prompt text", "GigaChat", true);
        doAnswer(inv -> {
            Prompt p = inv.getArgument(0);
            if (p.getId() == null) {
                p.setId(UUID.randomUUID());
            }
            return p;
        }).when(promptRepository).save(any());

        PromptResponse result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.createPrompt(body));

        assertNotNull(result);
        assertEquals("New Prompt", result.title());
        assertEquals("Prompt text", result.text());
        assertEquals(true, result.shared());
        verify(promptRepository).save(promptCaptor.capture());
        assertEquals(userIdStr, promptCaptor.getValue().getUserId());
        assertEquals("New Prompt", promptCaptor.getValue().getTitle());
    }

    @Test
    void testCreatePrompt_defaultShared_true() {
        PromptCreate body = new PromptCreate("New Prompt", "Desc", "Text", null, null);
        doAnswer(inv -> {
            Prompt p = inv.getArgument(0);
            if (p.getId() == null) {
                p.setId(UUID.randomUUID());
            }
            return p;
        }).when(promptRepository).save(any());

        PromptResponse result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.createPrompt(body));

        assertNotNull(result);
        assertEquals(true, result.shared());
    }

    @Test
    void testCreatePrompt_blankTitle_throws() {
        PromptCreate body = new PromptCreate("  ", "Desc", "Text", null, true);
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> promptService.createPrompt(body)));
    }

    @Test
    void testCreatePrompt_blankText_throws() {
        PromptCreate body = new PromptCreate("Title", "Desc", "   ", null, true);
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> promptService.createPrompt(body)));
    }

    @Test
    void testCreatePrompt_nullTitle_throws() {
        PromptCreate body = new PromptCreate(null, "Desc", "Text", null, true);
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> promptService.createPrompt(body)));
    }

    @Test
    void testCreatePrompt_nullText_throws() {
        PromptCreate body = new PromptCreate("Title", "Desc", null, null, true);
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> promptService.createPrompt(body)));
    }

    @Test
    void testCreatePrompt_stripsWhitespace() {
        PromptCreate body = new PromptCreate("  Title  ", "Desc", "  Text  ", "  GigaChat  ", true);
        doAnswer(inv -> {
            Prompt p = inv.getArgument(0);
            if (p.getId() == null) {
                p.setId(UUID.randomUUID());
            }
            p.setUpdatedAt(OffsetDateTime.now());
            return p;
        }).when(promptRepository).save(any());

        CurrentUserHolder.withUser(userIdStr,
                () -> promptService.createPrompt(body));

        verify(promptRepository).save(promptCaptor.capture());
        assertEquals("Title", promptCaptor.getValue().getTitle());
        // text is not stripped in createPrompt
        assertEquals("  Text  ", promptCaptor.getValue().getText());
        assertEquals("GigaChat", promptCaptor.getValue().getModel());
    }

    // -------------------------------------------------------------------------
    // UPDATE Prompt
    // -------------------------------------------------------------------------

    @Test
    void testUpdatePrompt_success() {
        Prompt existing = new Prompt();
        existing.setId(promptId);
        existing.setUserId(userIdStr);
        existing.setTitle("Old Title");
        existing.setText("Old Text");
        existing.setShared(true);
        existing.setModel("GigaChat");
        existing.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findById(any())).thenReturn(Optional.of(existing));
        doAnswer(inv -> {
            Prompt p = inv.getArgument(0);
            if (p.getUpdatedAt() == null) {
                p.setUpdatedAt(OffsetDateTime.now());
            }
            return p;
        }).when(promptRepository).save(any());

        PromptUpdate body = new PromptUpdate("New Title", "New Desc", "New Text", "GigaChat-2", true);
        PromptResponse result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.updatePrompt(promptId, body));

        assertNotNull(result);
        assertEquals("New Title", result.title());
        assertEquals("New Text", result.text());
        assertEquals("New Desc", result.description());
        assertEquals("GigaChat-2", result.model());
    }

    @Test
    void testUpdatePrompt_nullFieldsNotChanged() {
        Prompt existing = new Prompt();
        existing.setId(promptId);
        existing.setUserId(userIdStr);
        existing.setTitle("Original");
        existing.setText("Original text");
        existing.setShared(false);
        existing.setModel("GigaChat");
        existing.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findById(any())).thenReturn(Optional.of(existing));
        doAnswer(inv -> {
            Prompt p = inv.getArgument(0);
            if (p.getUpdatedAt() == null) {
                p.setUpdatedAt(OffsetDateTime.now());
            }
            return p;
        }).when(promptRepository).save(any());

        // Only update title
        PromptUpdate body = new PromptUpdate("New Title", null, null, null, null);
        PromptResponse result = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.updatePrompt(promptId, body));

        assertNotNull(result);
        assertEquals("New Title", result.title());
        assertEquals("Original text", result.text());
        assertEquals(false, result.shared());
        assertEquals("GigaChat", result.model());
    }

    @Test
    void testUpdatePrompt_notOwner_throws() {
        Prompt existing = new Prompt();
        existing.setId(promptId);
        existing.setUserId("other-user");
        existing.setShared(false);
        existing.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findById(any())).thenReturn(Optional.of(existing));

        PromptUpdate body = new PromptUpdate("New Title", null, null, null, null);
        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> promptService.updatePrompt(promptId, body)));
    }

    @Test
    void testUpdatePrompt_notFound_throws() {
        when(promptRepository.findById(any())).thenReturn(Optional.empty());

        PromptUpdate body = new PromptUpdate("New Title", null, null, null, null);
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> promptService.updatePrompt(promptId, body)));
    }

    // -------------------------------------------------------------------------
    // DELETE Prompt
    // -------------------------------------------------------------------------

    @Test
    void testDeletePrompt_success() {
        Prompt existing = new Prompt();
        existing.setId(promptId);
        existing.setUserId(userIdStr);
        existing.setShared(true);

        when(promptRepository.findById(any())).thenReturn(Optional.of(existing));

        assertDoesNotThrow(() -> CurrentUserHolder.withUser(userIdStr, () -> {
                promptService.deletePrompt(promptId);
                return null;
        }));
        verify(promptRepository).delete(existing);
    }

    @Test
    void testDeletePrompt_notOwner_throws() {
        Prompt existing = new Prompt();
        existing.setId(promptId);
        existing.setUserId("other-user");
        existing.setShared(false);

        when(promptRepository.findById(any())).thenReturn(Optional.of(existing));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                        promptService.deletePrompt(promptId);
                        return null;
                }));
    }

    @Test
    void testDeletePrompt_sharedAccessibleButNotOwner_throws() {
        // Even shared prompts can only be deleted by owner
        Prompt existing = new Prompt();
        existing.setId(promptId);
        existing.setUserId("other-user");
        existing.setShared(true);

        when(promptRepository.findById(any())).thenReturn(Optional.of(existing));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                        promptService.deletePrompt(promptId);
                        return null;
                }));
    }

    @Test
    void testDeletePrompt_notFound_throws() {
        when(promptRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                        promptService.deletePrompt(promptId);
                        return null;
                }));
    }

    // -------------------------------------------------------------------------
    // RATE Prompt
    // -------------------------------------------------------------------------

    @Test
    void testRatePrompt_success() {
        when(promptRepository.findById(any())).thenReturn(Optional.of(prompt));

        CurrentUserHolder.withUser(userIdStr, () -> {
            promptService.ratePrompt(promptId, 5);
            return null;
        });

        verify(promptRatingRepository).save(ratingCaptor.capture());
        PromptRating captured = ratingCaptor.getValue();
        assertEquals(promptId, captured.getPromptId());
        assertEquals(userIdStr, captured.getUserId());
        assertEquals(5, captured.getRating());
    }

    @Test
    void testRatePrompt_outOfRange_min_throws() {
        when(promptRepository.findById(any())).thenReturn(Optional.of(prompt));

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                        promptService.ratePrompt(promptId, 0);
                        return null;
                }));
    }

    @Test
    void testRatePrompt_outOfRange_max_throws() {
        when(promptRepository.findById(any())).thenReturn(Optional.of(prompt));

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                        promptService.ratePrompt(promptId, 6);
                        return null;
                }));
    }

    @Test
    void testRatePrompt_sharedPrompt_otherUser() {
        Prompt sharedPrompt = new Prompt();
        sharedPrompt.setId(promptId);
        sharedPrompt.setUserId("other-user");
        sharedPrompt.setShared(true);
        sharedPrompt.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findById(any())).thenReturn(Optional.of(sharedPrompt));

        CurrentUserHolder.withUser(userIdStr, () -> {
            promptService.ratePrompt(promptId, 3);
            return null;
        });

        verify(promptRatingRepository).save(ratingCaptor.capture());
        assertEquals(promptId, ratingCaptor.getValue().getPromptId());
        assertEquals(userIdStr, ratingCaptor.getValue().getUserId());
    }

    @Test
    void testRatePrompt_privatePrompt_otherUser_throws() {
        Prompt privatePrompt = new Prompt();
        privatePrompt.setId(promptId);
        privatePrompt.setUserId("other-user");
        privatePrompt.setShared(false);
        privatePrompt.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findById(any())).thenReturn(Optional.of(privatePrompt));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                        promptService.ratePrompt(promptId, 3);
                        return null;
                }));
    }

    @Test
    void testRatePrompt_notFound_throws() {
        when(promptRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                        promptService.ratePrompt(promptId, 3);
                        return null;
                }));
    }

    // -------------------------------------------------------------------------
    // USE Prompt
    // -------------------------------------------------------------------------

    @Test
    void testUsePrompt_success() {
        when(promptRepository.findById(any())).thenReturn(Optional.of(prompt));

        String text = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.usePrompt(promptId));

        assertEquals("Test text", text);
        assertEquals(1, prompt.getUsageCount());
    }

    @Test
    void testUsePrompt_sharedPrompt_otherUser() {
        Prompt sharedPrompt = new Prompt();
        sharedPrompt.setId(promptId);
        sharedPrompt.setUserId("other-user");
        sharedPrompt.setShared(true);
        sharedPrompt.setText("Shared text");
        sharedPrompt.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findById(any())).thenReturn(Optional.of(sharedPrompt));

        String text = CurrentUserHolder.withUser(userIdStr,
                () -> promptService.usePrompt(promptId));

        assertEquals("Shared text", text);
    }

    @Test
    void testUsePrompt_privatePrompt_otherUser_throws() {
        Prompt privatePrompt = new Prompt();
        privatePrompt.setId(promptId);
        privatePrompt.setUserId("other-user");
        privatePrompt.setShared(false);
        privatePrompt.setUpdatedAt(OffsetDateTime.now());

        when(promptRepository.findById(any())).thenReturn(Optional.of(privatePrompt));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> promptService.usePrompt(promptId)));
    }

    @Test
    void testUsePrompt_notFound_throws() {
        when(promptRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class, () -> CurrentUserHolder.withUser(userIdStr,
                () -> promptService.usePrompt(promptId)));
    }
}
