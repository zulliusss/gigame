package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class ScenarioRunStepRepositoryTest {

    @Autowired
    private ScenarioRunStepRepository runStepRepository;

    @Autowired
    private ScenarioRepository scenarioRepository;

    @Autowired
    private ScenarioRunRepository scenarioRunRepository;

    @Test
    void testFindById_returnsScenarioRunStep() {
        UUID runId = UUID.randomUUID();
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId("node1");
        step.setNodeType("input");
        runStepRepository.save(step);

        ScenarioRunStep found = runStepRepository.findById(step.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("node1", found.getNodeId());
    }

    @Test
    void testFindByRunIdOrderByStartedAtAsc_returnsSortedSteps() {
        var scenario = new Scenario();
        scenario.setName("Тестовый сценарий");
        scenario.setDescription("Тестовый сценарий");
        scenarioRepository.save(scenario);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        run.setStatus("running");
        scenarioRunRepository.save(run);
        ScenarioRunStep step1 = new ScenarioRunStep();
        step1.setRunId(run.getId());
        step1.setNodeId("node1");
        runStepRepository.save(step1);

        ScenarioRunStep step2 = new ScenarioRunStep();
        step2.setRunId(run.getId());
        step2.setNodeId("node2");
        runStepRepository.save(step2);

        List<ScenarioRunStep> result = runStepRepository.findByRunIdOrderByStartedAtAsc(run.getId());

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("node1", result.get(0).getNodeId());
        assertEquals("node2", result.get(1).getNodeId());
    }

    @Test
    void testFindByRunId_returnsEmptyList_whenNoSteps() {
        List<ScenarioRunStep> result = runStepRepository.findByRunIdOrderByStartedAtAsc(UUID.randomUUID());

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        UUID runId = UUID.randomUUID();
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId("node1");

        ScenarioRunStep saved = runStepRepository.save(step);
        assertNotNull(saved.getId());

        runStepRepository.delete(saved);
        assertFalse(runStepRepository.findById(saved.getId()).isPresent());
    }
}
