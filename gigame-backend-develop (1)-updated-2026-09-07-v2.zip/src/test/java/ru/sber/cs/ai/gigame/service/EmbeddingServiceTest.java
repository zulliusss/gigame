package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.model.Embedding;
import ru.sber.cs.ai.gigame.repository.EmbeddingRepository;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class EmbeddingServiceTest {

    @Mock
    private EmbeddingRepository embeddingRepository;

    @InjectMocks
    private EmbeddingService embeddingService;

    @Captor
    private ArgumentCaptor<List<Embedding>> embeddingListCaptor;

    private UUID docId;
    private UUID kbId;

    @BeforeEach
    void setUp() {
        docId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        ReflectionTestUtils.setField(embeddingService, "topK", 5);
    }

    @Test
    void testStoreDocumentChunks() {
        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        List<float[]> embeddings = List.of(new float[1024], new float[1024]);

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeDocumentChunks(docId, chunks, embeddings);

        verify(embeddingRepository).saveAll(embeddingListCaptor.capture());
        List<Embedding> saved = embeddingListCaptor.getValue();
        assertEquals(2, saved.size());
        assertEquals("doc", saved.get(0).getCollectionType());
        assertEquals(docId, saved.get(0).getCollectionId());
    }

    @Test
    void testStoreKBChunks() {
        UUID sourceDocId = UUID.randomUUID();
        List<String> chunks = List.of("Chunk 1", "Chunk 2");
        List<float[]> embeddings = List.of(new float[1024], new float[1024]);

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeKBChunks(kbId, sourceDocId, chunks, embeddings);

        verify(embeddingRepository).saveAll(embeddingListCaptor.capture());
        List<Embedding> saved = embeddingListCaptor.getValue();
        assertEquals(2, saved.size());
        assertEquals("kb", saved.get(0).getCollectionType());
        assertEquals(kbId, saved.get(0).getCollectionId());
        assertEquals(sourceDocId, saved.get(0).getSourceDocumentId());
    }

    @Test
    void testSearchSimilar() {
        float[] queryVector = new float[1024];
        List<String> expectedResult = List.of("Similar chunk 1", "Similar chunk 2");
        when(embeddingRepository.searchSimilar(eq("doc"), eq(docId), any(float[].class), anyInt()))
                .thenReturn(expectedResult);

        List<String> result = embeddingService.searchSimilar("doc", docId, queryVector);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedResult, result);
        verify(embeddingRepository).searchSimilar(eq("doc"), eq(docId), any(float[].class), eq(5));
    }

    @Test
    void testDeleteDocumentChunks() {
        doNothing().when(embeddingRepository).deleteByCollection("doc", docId);

        embeddingService.deleteDocumentChunks(docId);

        verify(embeddingRepository).deleteByCollection("doc", docId);
    }

    @Test
    void testDeleteKBDocumentChunks() {
        doNothing().when(embeddingRepository).deleteKBDocumentChunks(kbId, docId);

        embeddingService.deleteKBDocumentChunks(kbId, docId);

        verify(embeddingRepository).deleteKBDocumentChunks(kbId, docId);
    }

    @Test
    void testDeleteKBCollection() {
        doNothing().when(embeddingRepository).deleteByCollection("kb", kbId);

        embeddingService.deleteKBCollection(kbId);

        verify(embeddingRepository).deleteByCollection("kb", kbId);
    }

    @Test
    void testLexicalTerms_extractsLongWordsAndNumbers() {
        List<String> terms = EmbeddingService.lexicalTerms(
                "Найди неустойку по договору 1808920 в акте от 2024 года");

        // числа от 4 цифр и слова от 6 букв, топ-3 по длине, в нижнем регистре
        assertEquals(List.of("неустойку", "договору", "1808920"), terms);
    }

    @Test
    void testLexicalTerms_nullAndShortWordsGiveEmpty() {
        assertEquals(List.of(), EmbeddingService.lexicalTerms(null));
        assertEquals(List.of(), EmbeddingService.lexicalTerms("акт от 123"));
    }

    @Test
    void testHybridSearch_lexicalHitJoinsVectorResults() {
        float[] queryVector = new float[1024];
        when(embeddingRepository.searchSimilarWithSource(eq("kb"), eq(kbId), any(float[].class), anyInt()))
                .thenReturn(List.<Object[]>of(
                        new Object[]{"векторный фрагмент", docId.toString(), 0.30}));
        when(embeddingRepository.searchLexical(eq("kb"), eq(kbId), eq("%1808920%"), anyInt()))
                .thenReturn(List.<Object[]>of(
                        new Object[]{"дословный фрагмент с 1808920", docId.toString()}));

        List<String> result = embeddingService.hybridSearch("kb", kbId, queryVector, "1808920");

        assertEquals(2, result.size());
        assertEquals(List.of("векторный фрагмент", "дословный фрагмент с 1808920"),
                result.stream().sorted(java.util.Comparator.comparingInt(String::length)).toList());
    }

    @Test
    void testHybridSearchWithSources_duplicateChunkRankedFirst() {
        float[] queryVector = new float[1024];
        // «общий» встречается в обоих каналах — RRF суммирует его очки,
        // и он обгоняет вектор-лидера
        when(embeddingRepository.searchSimilarWithSource(eq("kb"), eq(kbId), any(float[].class), anyInt()))
                .thenReturn(List.<Object[]>of(
                        new Object[]{"вектор-лидер", docId.toString(), 0.10},
                        new Object[]{"общий фрагмент про неустойку", docId.toString(), 0.20}));
        when(embeddingRepository.searchLexical(eq("kb"), eq(kbId), eq("%неустойка%"), anyInt()))
                .thenReturn(List.<Object[]>of(
                        new Object[]{"общий фрагмент про неустойку", docId.toString()}));

        List<EmbeddingService.ChunkHit> hits =
                embeddingService.hybridSearchWithSources("kb", kbId, queryVector, "неустойка");

        assertEquals("общий фрагмент про неустойку", hits.get(0).text());
        // дистанция дубликата взята из векторного канала, а не условная лексическая
        assertEquals(0.20, hits.get(0).distance());
    }

    @Test
    void testStoreDocumentChunks_withEmptyLists() {
        List<String> chunks = List.of();
        List<float[]> embeddings = List.of();

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeDocumentChunks(docId, chunks, embeddings);

        verify(embeddingRepository).saveAll(anyList());
    }

    @Test
    void testStoreKBChunks_withEmptyLists() {
        UUID sourceDocId = UUID.randomUUID();
        List<String> chunks = List.of();
        List<float[]> embeddings = List.of();

        when(embeddingRepository.saveAll(anyList())).thenReturn(null);

        embeddingService.storeKBChunks(kbId, sourceDocId, chunks, embeddings);

        verify(embeddingRepository).saveAll(anyList());
    }
}
