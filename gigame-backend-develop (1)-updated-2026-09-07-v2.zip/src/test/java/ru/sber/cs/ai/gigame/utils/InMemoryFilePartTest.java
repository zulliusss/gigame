package ru.sber.cs.ai.gigame.utils;

import org.junit.jupiter.api.Test;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Flux;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InMemoryFilePartTest {

    private static final String TEST_FILENAME = "test.txt";
    private static final byte[] TEST_BYTES = "Hello, World!".getBytes();

    @Test
    void testRecordFilename() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertEquals(TEST_FILENAME, part.filename());
    }

    @Test
    void testRecordBytes() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertArrayEquals(TEST_BYTES, part.bytes());
    }

    @Test
    void testName_returnsConstant() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertEquals("files", part.name());
    }

    @Test
    void testHeaders_returnsHttpHeaders() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        HttpHeaders headers = part.headers();
        assertNotNull(headers);
    }

    @Test
    void testContent_returnsFluxWithDataBuffer() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        Flux<DataBuffer> content = part.content();
        assertNotNull(content);

        byte[] result = readFlux(content);
        assertArrayEquals(TEST_BYTES, result);
    }

    @Test
    void testContent_emptyBytes() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, new byte[0]);
        Flux<DataBuffer> content = part.content();
        assertNotNull(content);

        byte[] result = readFlux(content);
        assertArrayEquals(new byte[0], result);
    }

    @Test
    void testTransferTo_validDestination() throws IOException {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        Path tempFile = Files.createTempFile("test", ".txt");

        part.transferTo(tempFile).block();

        assertArrayEquals(TEST_BYTES, Files.readAllBytes(tempFile));
        Files.delete(tempFile);
    }

    @Test
    void testTransferTo_overwritesExistingFile() throws IOException {
        byte[] originalBytes = "original".getBytes();
        byte[] newBytes = "overwritten".getBytes();

        Path tempFile = Files.createTempFile("test", ".txt");
        Files.write(tempFile, originalBytes);

        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, newBytes);
        part.transferTo(tempFile).block();

        assertArrayEquals(newBytes, Files.readAllBytes(tempFile));
        Files.delete(tempFile);
    }

    @Test
    void testTransferTo_withLargeContent() throws IOException {
        byte[] largeBytes = new byte[1024 * 1024]; // 1 MB
        for (int i = 0; i < largeBytes.length; i++) {
            largeBytes[i] = (byte) (i % 256);
        }

        InMemoryFilePart part = new InMemoryFilePart("large.bin", largeBytes);
        Path tempFile = Files.createTempFile("large", ".bin");
        try {
            part.transferTo(tempFile).block();
            assertArrayEquals(largeBytes, Files.readAllBytes(tempFile));
        } finally {
            deleteFile(tempFile);
        }
    }

    @Test
    void testEquals_sameContent_returnsTrue() {
        InMemoryFilePart part1 = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        InMemoryFilePart part2 = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertEquals(part1, part2);
    }

    @Test
    void testEquals_differentFilename_returnsFalse() {
        InMemoryFilePart part1 = new InMemoryFilePart("file1.txt", TEST_BYTES);
        InMemoryFilePart part2 = new InMemoryFilePart("file2.txt", TEST_BYTES);
        assertNotEquals(part1, part2);
    }

    @Test
    void testEquals_differentBytes_returnsFalse() {
        InMemoryFilePart part1 = new InMemoryFilePart(TEST_FILENAME, "content1".getBytes());
        InMemoryFilePart part2 = new InMemoryFilePart(TEST_FILENAME, "content2".getBytes());
        assertNotEquals(part1, part2);
    }

    @Test
    void testEquals_sameInstance_returnsTrue() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertEquals(part, part);
    }

    @Test
    void testEquals_withNull_returnsFalse() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertNotEquals(null, part);
    }

    @Test
    void testEquals_withDifferentType_returnsFalse() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertNotEquals("not a FilePart", part);
    }

    @Test
    void testHashCode_sameContent_sameHashCode() {
        InMemoryFilePart part1 = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        InMemoryFilePart part2 = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        assertEquals(part1.hashCode(), part2.hashCode());
    }

    @Test
    void testHashCode_differentContent_differentHashCode() {
        InMemoryFilePart part1 = new InMemoryFilePart("a.txt", "x".getBytes());
        InMemoryFilePart part2 = new InMemoryFilePart("b.txt", "y".getBytes());
        assertNotEquals(part1.hashCode(), part2.hashCode());
    }

    @Test
    void testToString_containsFilename() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        String toString = part.toString();
        assertNotNull(toString);
        assertTrue(toString.contains(TEST_FILENAME));
        assertTrue(toString.contains("InMemoryFilePart"));
    }

    @Test
    void testNullFilename() {
        InMemoryFilePart part = new InMemoryFilePart(null, TEST_BYTES);
        assertNull(part.filename());
    }

    @Test
    void testNullBytes_contentThrowsNpe() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, null);
        assertThrows(NullPointerException.class, part::content);
    }

    @Test
    void testEquals_nullBytes() {
        InMemoryFilePart part1 = new InMemoryFilePart(TEST_FILENAME, null);
        InMemoryFilePart part2 = new InMemoryFilePart(TEST_FILENAME, null);
        assertEquals(part1, part2);
    }

    @Test
    void testHashCode_nullBytes() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, null);
        assertNotEquals(0, part.hashCode());
    }

    @Test
    void testTransferTo_nonExistentDirectory_throwsException() {
        InMemoryFilePart part = new InMemoryFilePart(TEST_FILENAME, TEST_BYTES);
        Path invalidPath = Path.of("/non/existent/directory/file.txt");
        var mono = part.transferTo(invalidPath);
        UncheckedIOException exception = assertThrows(UncheckedIOException.class, mono::block);
        assertNotNull(exception.getCause());
    }

    private byte[] readFlux(Flux<DataBuffer> flux) {
        byte[][] chunks = flux.map(buf -> {
            byte[] b = new byte[(int) buf.readableByteCount()];
            buf.read(b);
            DataBufferUtils.release(buf);
            return b;
        }).collectList().block().toArray(new byte[0][]);

        byte[] result = new byte[0];
        for (byte[] chunk : chunks) {
            byte[] combined = new byte[result.length + chunk.length];
            System.arraycopy(result, 0, combined, 0, result.length);
            System.arraycopy(chunk, 0, combined, result.length, chunk.length);
            result = combined;
        }
        return result;
    }

    private void deleteFile(Path path) {
        try {
            Files.delete(path);
        } catch (IOException ignored) {
            // ignore cleanup failures
        }
    }
}
