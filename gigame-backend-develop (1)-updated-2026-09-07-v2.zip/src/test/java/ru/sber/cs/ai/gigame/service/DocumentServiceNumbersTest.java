package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Тесты нормализации чисел при извлечении текста: склейка разрядов,
 * разорванных пробелами-разделителями и переносами строк.
 */
class DocumentServiceNumbersTest {

    @Test
    void gluesGroupedThousands() {
        assertEquals("Сумма 9750986,34 руб.",
                DocumentService.normalizeNumberGroups("Сумма 9 750 986,34 руб."));
    }

    @Test
    void gluesTornDecimalNumber() {
        assertEquals("Итого 9750986,34",
                DocumentService.normalizeNumberGroups("Итого 975 09 86,34"));
    }

    @Test
    void gluesNumberWrappedByLineBreak() {
        assertEquals("НМЦ 3941343,56 руб.",
                DocumentService.normalizeNumberGroups("НМЦ 394134\n3,56 руб."));
    }

    @Test
    void gluesNumberWrappedAfterComma() {
        assertEquals("Акт на 384553,94",
                DocumentService.normalizeNumberGroups("Акт на 384553,\n94"));
    }

    @Test
    void keepsNeighbouringIndependentNumbers() {
        assertEquals("2025 100000,00",
                DocumentService.normalizeNumberGroups("2025 100 000,00"));
    }

    @Test
    void nullAndEmptyPassThrough() {
        assertEquals(null, DocumentService.normalizeNumberGroups(null));
        assertEquals("", DocumentService.normalizeNumberGroups(""));
    }
}
