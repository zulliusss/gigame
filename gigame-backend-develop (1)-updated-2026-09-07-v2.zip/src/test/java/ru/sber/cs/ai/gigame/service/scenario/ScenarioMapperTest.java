package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class ScenarioMapperTest {

    private UUID userId;
    private UUID scenarioId;
    private UUID runId;
    private UUID stepId;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;
    private OffsetDateTime startedAt;
    private OffsetDateTime completedAt;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        scenarioId = UUID.randomUUID();
        runId = UUID.randomUUID();
        stepId = UUID.randomUUID();
        createdAt = OffsetDateTime.now().minusDays(1);
        updatedAt = OffsetDateTime.now();
        startedAt = OffsetDateTime.now();
        completedAt = OffsetDateTime.now().plusHours(1);
    }

    // -------------------------------------------------------------------------
    // Scenario to Response
    // -------------------------------------------------------------------------

    @Test
    void testToResponse_withAllFields() {
        Scenario scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setName("Test Scenario");
        scenario.setDescription("Test description");
        scenario.setCreatedAt(createdAt);
        scenario.setUpdatedAt(updatedAt);
        scenario.setUserId(userId.toString());

        ScenarioResponse response = ScenarioMapper.toResponse(scenario);

        assertNotNull(response);
        assertEquals(scenarioId, response.id());
        assertEquals("Test Scenario", response.name());
        assertEquals("Test description", response.description());
        assertEquals(createdAt, response.createdAt());
        assertEquals(updatedAt, response.updatedAt());
    }

    @Test
    void testToResponse_withNullDescription() {
        Scenario scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setName("Scenario");
        scenario.setDescription(null);
        scenario.setCreatedAt(createdAt);
        scenario.setUpdatedAt(updatedAt);

        ScenarioResponse response = ScenarioMapper.toResponse(scenario);

        assertNull(response.description());
    }

    @Test
    void testToResponse_withEmptyDescription() {
        Scenario scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setName("Scenario");
        scenario.setDescription("");
        scenario.setCreatedAt(createdAt);
        scenario.setUpdatedAt(updatedAt);

        ScenarioResponse response = ScenarioMapper.toResponse(scenario);

        assertEquals("", response.description());
    }

    // -------------------------------------------------------------------------
    // Scenario to Detail Response
    // -------------------------------------------------------------------------

    @Test
    void testToDetailResponse_withGraphData() {
        Scenario scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setName("Scenario with Graph");
        scenario.setDescription("Description");
        scenario.setCreatedAt(createdAt);
        scenario.setUpdatedAt(updatedAt);

        // Create graph data
        NodeDto node1 = NodeDto.builder()
                .id("node-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Node 1")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto node2 = NodeDto.builder()
                .id("node-2")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Node 2")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        EdgeDto edge = new EdgeDto(
                "edge-1",
                "node-1",
                "node-2",
                new EdgeDataDto("edge-1")
        );
        GraphDataDto graphData = new GraphDataDto(
                List.of(node1, node2),
                List.of(edge)
        );
        scenario.setGraphData(GraphDataMapper.fromDto(graphData));

        ScenarioDetailResponse response = ScenarioMapper.toDetailResponse(scenario);

        assertNotNull(response);
        assertEquals(scenarioId, response.id());
        assertEquals("Scenario with Graph", response.name());
        assertNotNull(response.graphData());
        assertEquals(2, response.graphData().nodes().size());
        assertEquals(1, response.graphData().edges().size());
    }

    @Test
    void testToDetailResponse_withNullGraphData() {
        Scenario scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setName("Scenario");
        scenario.setCreatedAt(createdAt);
        scenario.setUpdatedAt(updatedAt);
        scenario.setGraphData(null);

        ScenarioDetailResponse response = ScenarioMapper.toDetailResponse(scenario);

        assertNotNull(response);
        assertNotNull(response.graphData());
        assertEquals(0, response.graphData().nodes().size());
        assertEquals(0, response.graphData().edges().size());
    }

    // -------------------------------------------------------------------------
    // ScenarioRun to Response
    // -------------------------------------------------------------------------

    @Test
    void testToRunResponse_withAllFields() {
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        run.setStartedAt(startedAt);
        run.setCompletedAt(completedAt);
        run.setResult("Final result");
        run.setInputDocumentIds(List.of("doc_id_1"));

        ScenarioRunResponse response = ScenarioMapper.toRunResponse(run);

        assertNotNull(response);
        assertEquals(runId, response.id());
        assertEquals(scenarioId, response.scenarioId());
        assertEquals("completed", response.status());
        assertEquals(startedAt, response.startedAt());
        assertEquals(completedAt, response.completedAt());
        assertEquals(List.of("doc_id_1"), response.inputDocumentIds());
    }

    @Test
    void testToRunResponse_withNullInputDocumentIds() {
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(startedAt);
        run.setInputDocumentIds(null);

        ScenarioRunResponse response = ScenarioMapper.toRunResponse(run);

        assertNull(response.inputDocumentIds());
    }

    @Test
    void testToRunResponse_withEmptyInputDocumentIds() {
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(startedAt);
        run.setInputDocumentIds(List.of());

        ScenarioRunResponse response = ScenarioMapper.toRunResponse(run);

        assertEquals(List.of(), response.inputDocumentIds());
    }

    // -------------------------------------------------------------------------
    // ScenarioRunStep to Response
    // -------------------------------------------------------------------------

    @Test
    void testToStepResponse_withAllFields() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(stepId);
        step.setNodeId("node-1");
        step.setNodeType("processing");
        step.setStatus("completed");
        step.setInputData(Map.of("previous_output", "value"));
        step.setOutputData(Map.of("result", "output"));
        step.setPromptUsed("System prompt");
        step.setTokensUsed(150);
        step.setStartedAt(startedAt);
        step.setCompletedAt(completedAt);

        ScenarioRunStepResponse response = ScenarioMapper.toStepResponse(step);

        assertNotNull(response);
        assertEquals(stepId, response.id());
        assertEquals("node-1", response.nodeId());
        assertEquals("processing", response.nodeType());
        assertEquals("completed", response.status());
        assertEquals("value", response.inputData().previousOutput());
        assertEquals("output", response.outputData().result());
        assertEquals("System prompt", response.promptUsed());
        assertEquals(Integer.valueOf(150), response.tokensUsed());
        assertEquals(startedAt, response.startedAt());
        assertEquals(completedAt, response.completedAt());
    }

    @Test
    void testToStepResponse_withNullPrompt() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(stepId);
        step.setNodeId("node-1");
        step.setNodeType("processing");
        step.setStatus("running");
        step.setPromptUsed(null);

        ScenarioRunStepResponse response = ScenarioMapper.toStepResponse(step);

        assertNull(response.promptUsed());
    }

    @Test
    void testToStepResponse_withNullTokensUsed() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(stepId);
        step.setNodeId("node-1");
        step.setNodeType("processing");
        step.setStatus("running");
        step.setTokensUsed(null);

        ScenarioRunStepResponse response = ScenarioMapper.toStepResponse(step);

        assertNull(response.tokensUsed());
    }

    @Test
    void testToStepResponse_withEmptyDataMaps() {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(stepId);
        step.setNodeId("node-1");
        step.setNodeType("processing");
        step.setStatus("pending");
        step.setInputData(Map.of());
        step.setOutputData(Map.of());
        step.setPromptUsed("");

        ScenarioRunStepResponse response = ScenarioMapper.toStepResponse(step);

        assertNull(response.inputData().previousOutput());
        assertNull(response.outputData().result());
        assertEquals("", response.promptUsed());
    }

    // -------------------------------------------------------------------------
    // ScenarioRunDetailResponse
    // -------------------------------------------------------------------------

    @Test
    void testScenarioRunDetailResponse_creation() {
        ScenarioRunStepResponse stepResponse = new ScenarioRunStepResponse(
                stepId,
                "node-1",
                "processing",
                "completed",
                new ScenarioRunStepInputDataResponse("", "2024-01-01"),
                new ScenarioRunStepOutputDataResponse("Результат", null),
                "prompt",
                100,
                startedAt,
                completedAt
        );

        ScenarioRunDetailResponse response = new ScenarioRunDetailResponse(
                runId,
                scenarioId,
                "completed",
                List.of("doc-1", "doc-2"),
                "result",
                startedAt,
                completedAt,
                List.of(stepResponse)
        );

        assertNotNull(response);
        assertEquals(runId, response.id());
        assertEquals(scenarioId, response.scenarioId());
        assertEquals("completed", response.status());
        assertEquals(List.of("doc-1", "doc-2"), response.inputDocumentIds());
        assertEquals("result", response.result());
        assertEquals(startedAt, response.startedAt());
        assertEquals(completedAt, response.completedAt());
        assertEquals(1, response.steps().size());
        assertEquals(stepId, response.steps().get(0).id());
    }

    @Test
    void testScenarioRunDetailResponse_withEmptySteps() {
        ScenarioRunDetailResponse response = new ScenarioRunDetailResponse(
                runId,
                scenarioId,
                "pending",
                null,
                null,
                startedAt,
                null,
                List.of()
        );

        assertEquals(0, response.steps().size());
    }

    @Test
    void testScenarioRunDetailResponse_withMultipleSteps() {
        List<ScenarioRunStepResponse> steps = getStepResponseList();

        ScenarioRunDetailResponse response = new ScenarioRunDetailResponse(
                runId,
                scenarioId,
                "in_progress",
                null,
                null,
                startedAt,
                null,
                steps
        );

        assertEquals(3, response.steps().size());
        assertEquals("input", response.steps().get(0).nodeType());
        assertEquals("processing", response.steps().get(1).nodeType());
        assertEquals("output", response.steps().get(2).nodeType());
    }

    private List<ScenarioRunStepResponse> getStepResponseList() {
        return List.of(
                new ScenarioRunStepResponse(
                        UUID.randomUUID(),
                        "node-1",
                        "input",
                        "completed",
                        new ScenarioRunStepInputDataResponse(null, null),
                        new ScenarioRunStepOutputDataResponse(null, null),
                        null,
                        null,
                        startedAt,
                        completedAt),
                new ScenarioRunStepResponse(
                        UUID.randomUUID(),
                        "node-2",
                        "processing",
                        "completed",
                        new ScenarioRunStepInputDataResponse(null, null),
                        new ScenarioRunStepOutputDataResponse(null, null),
                        null,
                        null,
                        startedAt,
                        completedAt),
                new ScenarioRunStepResponse(
                        UUID.randomUUID(),
                        "node-3",
                        "output",
                        "pending",
                        new ScenarioRunStepInputDataResponse(null, null),
                        new ScenarioRunStepOutputDataResponse(null, null),
                        null,
                        null,
                        startedAt,
                        null)
        );
    }
}
