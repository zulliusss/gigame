package ru.sber.cs.ai.gigame.config;

import org.junit.jupiter.api.Test;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import static org.assertj.core.api.Assertions.assertThat;

class TransactionConfigTest {

    @Test
    void configShouldBeConfigurationClass() {
        assertThat(TransactionConfig.class.getAnnotation(Configuration.class))
                .isNotNull();
    }

    @Test
    void configShouldHaveEnableTransactionManagement() {
        Annotation[] annotations = TransactionConfig.class.getAnnotations();
        boolean hasEnableTransactionManagement = false;

        for (Annotation annotation : annotations) {
            if (annotation instanceof EnableTransactionManagement) {
                hasEnableTransactionManagement = true;
                break;
            }
        }

        assertThat(hasEnableTransactionManagement).isTrue();
    }

    @Test
    void configShouldHavePrimaryTransactionManagerBean() {
        Method[] methods = TransactionConfig.class.getDeclaredMethods();
        boolean hasPrimaryBean = false;

        for (Method method : methods) {
            if (method.isAnnotationPresent(Bean.class) && method.isAnnotationPresent(Primary.class)) {
                hasPrimaryBean = true;
                break;
            }
        }

        assertThat(hasPrimaryBean).isTrue();
    }

    @Test
    void configClassShouldExist() {
        assertThat(TransactionConfig.class).isNotNull();
    }
}
