package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.Conversation;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class ConversationRepositoryTest {

    @Autowired
    private ConversationRepository underTest;

    @Test
    void testFindById_returnsConversation() {
        Conversation conversation = new Conversation();
        conversation.setTitle("Test");
        conversation.setUserId("user1");
        underTest.save(conversation);

        Conversation found = underTest.findById(conversation.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("Test", found.getTitle());
    }

    @Test
    void testFindByUserIdOrderByUpdatedAtDesc_returnsSortedConversations() {
        String userId = "user1";
        Conversation conv1 = new Conversation();
        conv1.setUserId(userId);
        conv1.setTitle("First");
        underTest.save(conv1);

        Conversation conv2 = new Conversation();
        conv2.setUserId(userId);
        conv2.setTitle("Second");
        underTest.save(conv2);

        List<Conversation> result = underTest.findByUserIdOrderByUpdatedAtDesc(userId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Second", result.get(0).getTitle());
        assertEquals("First", result.get(1).getTitle());
    }

    @Test
    void testFindByUserIdAndTitleContainingIgnoreCaseOrderByUpdatedAtDesc() {
        String userId = "user1";
        Conversation conv1 = new Conversation();
        conv1.setUserId(userId);
        conv1.setTitle("Project Alpha");
        underTest.save(conv1);

        Conversation conv2 = new Conversation();
        conv2.setUserId(userId);
        conv2.setTitle("Project Beta");
        underTest.save(conv2);

        Conversation conv3 = new Conversation();
        conv3.setUserId(userId);
        conv3.setTitle("Other Topic");
        underTest.save(conv3);

        List<Conversation> result = underTest.findByUserIdAndTitleContainingIgnoreCaseOrderByUpdatedAtDesc(
                userId, "project");

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Project Beta", result.get(0).getTitle());
        assertEquals("Project Alpha", result.get(1).getTitle());
    }

    @Test
    void testFindByUserId_returnsEmptyList_whenNoConversations() {
        List<Conversation> result = underTest.findByUserIdOrderByUpdatedAtDesc("nonexistent");

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        Conversation conversation = new Conversation();
        conversation.setTitle("To Delete");
        conversation.setUserId("user1");

        Conversation saved = underTest.save(conversation);
        assertNotNull(saved.getId());

        underTest.delete(saved);
        assertFalse(underTest.findById(saved.getId()).isPresent());
    }
}
