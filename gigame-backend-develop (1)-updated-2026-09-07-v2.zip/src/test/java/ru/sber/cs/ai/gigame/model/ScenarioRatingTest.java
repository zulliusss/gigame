package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * Unit tests for {@link ScenarioRating} and its nested {@link ScenarioRating.Key} class.
 */
class ScenarioRatingTest {

    // -------------------------------------------------------------------------
    // ScenarioRating.Key — constructor & fields
    // -------------------------------------------------------------------------

    @Test
    void keyConstructor_setsFields() {
        UUID scenarioId = UUID.randomUUID();
        String userId = "test-user";

        ScenarioRating.Key key = new ScenarioRating.Key(scenarioId, userId);

        assertEquals(scenarioId, key.getScenarioId());
        assertEquals(userId, key.getUserId());
    }

    @Test
    void keyNoArgsConstructor_createsEmptyKey() {
        ScenarioRating.Key key = new ScenarioRating.Key();

        assertNotNull(key);
        // At least one of the fields should be null (not yet set)
        assertFalse(key.getScenarioId() != null && key.getUserId() != null);
    }

    // -------------------------------------------------------------------------
    // ScenarioRating.Key — equals
    // -------------------------------------------------------------------------
    @Test
    void keyEquals_withDifferentScenarioId() {
        UUID scenarioId1 = UUID.randomUUID();
        UUID scenarioId2 = UUID.randomUUID();
        String userId = "user-1";

        ScenarioRating.Key key1 = new ScenarioRating.Key(scenarioId1, userId);
        ScenarioRating.Key key2 = new ScenarioRating.Key(scenarioId2, userId);

        assertNotEquals(key1, key2);
        assertNotEquals(key2, key1);
    }

    @Test
    void keyEquals_withDifferentUserId() {
        UUID scenarioId = UUID.randomUUID();
        String userId1 = "user-1";
        String userId2 = "user-2";

        ScenarioRating.Key key1 = new ScenarioRating.Key(scenarioId, userId1);
        ScenarioRating.Key key2 = new ScenarioRating.Key(scenarioId, userId2);

        assertNotEquals(key1, key2);
        assertNotEquals(key2, key1);
    }

    @Test
    void keyEquals_withDifferentScenarioIdAndUserId() {
        ScenarioRating.Key key1 = new ScenarioRating.Key(UUID.randomUUID(), "user-1");
        ScenarioRating.Key key2 = new ScenarioRating.Key(UUID.randomUUID(), "user-2");

        assertNotEquals(key1, key2);
    }

    @Test
    void keyEquals_withSameValues_returnsTrue() {
        UUID scenarioId = UUID.randomUUID();
        String userId = "user-1";

        ScenarioRating.Key key1 = new ScenarioRating.Key(scenarioId, userId);
        ScenarioRating.Key key2 = new ScenarioRating.Key(scenarioId, userId);

        assertEquals(key1, key2);
        assertEquals(key2, key1);
    }

    @Test
    void keyEquals_withNullFields_throwsNPE() {
        // The Key.equals implementation does not guard against null UUID,
        // so calling equals between two different keys with null scenarioId throws NPE.
        // Self-equals is safe due to the `this == o` guard.
        ScenarioRating.Key key1 = new ScenarioRating.Key(null, "user-a");
        ScenarioRating.Key key2 = new ScenarioRating.Key(null, "user-b");

        // equals throws NPE because scenarioId is null and .equals() is called on it
        org.junit.jupiter.api.Assertions.assertThrows(
                NullPointerException.class, () -> key1.equals(key2));
    }

    @Test
    void keyEquals_withDifferentNullFields() {
        ScenarioRating.Key key1 = new ScenarioRating.Key(UUID.randomUUID(), null);
        ScenarioRating.Key key2 = new ScenarioRating.Key(null, null);

        assertNotEquals(key1, key2);
    }

    // -------------------------------------------------------------------------
    // ScenarioRating.Key — hashCode
    // -------------------------------------------------------------------------

    @Test
    void keyHashCode_consistentAcrossCalls() {
        UUID scenarioId = UUID.randomUUID();
        String userId = "user-1";
        ScenarioRating.Key key = new ScenarioRating.Key(scenarioId, userId);

        int hash1 = key.hashCode();
        int hash2 = key.hashCode();

        assertEquals(hash1, hash2);
    }

    @Test
    void keyHashCode_equalKeysHaveEqualHash() {
        UUID scenarioId = UUID.randomUUID();
        String userId = "user-1";

        ScenarioRating.Key key1 = new ScenarioRating.Key(scenarioId, userId);
        ScenarioRating.Key key2 = new ScenarioRating.Key(scenarioId, userId);

        assertEquals(key1.hashCode(), key2.hashCode());
    }

    @Test
    void keyHashCode_differentKeysHaveDifferentHash() {
        ScenarioRating.Key key1 = new ScenarioRating.Key(UUID.randomUUID(), "user-1");
        ScenarioRating.Key key2 = new ScenarioRating.Key(UUID.randomUUID(), "user-2");

        // Note: hash collision is theoretically possible but practically impossible
        assertNotEquals(key1.hashCode(), key2.hashCode());
    }

    @Test
    void keyHashCode_withNullFields_throwsNPE() {
        // The Key.hashCode implementation does not guard against null UUID,
        // so calling hashCode on a key with null scenarioId throws NPE
        ScenarioRating.Key key = new ScenarioRating.Key(null, null);

        org.junit.jupiter.api.Assertions.assertThrows(
                NullPointerException.class, key::hashCode);
    }

    @Test
    void keyHashCode_contract_withEquals() {
        UUID scenarioId = UUID.randomUUID();

        ScenarioRating.Key keyA = new ScenarioRating.Key(scenarioId, "alice");
        ScenarioRating.Key keyB = new ScenarioRating.Key(scenarioId, "alice");
        ScenarioRating.Key keyC = new ScenarioRating.Key(scenarioId, "bob");

        // equal => same hash
        assertEquals(keyA, keyB);
        assertEquals(keyA.hashCode(), keyB.hashCode());

        // not equal => possibly different hash
        assertNotEquals(keyA, keyC);
        assertNotEquals(keyA.hashCode(), keyC.hashCode());
    }

    // -------------------------------------------------------------------------
    // ScenarioRating — entity getters / setters
    // -------------------------------------------------------------------------

    @Test
    void scenarioRatingNoArgsConstructor_createsEntity() {
        ScenarioRating rating = new ScenarioRating();

        assertNotNull(rating);
    }

    @Test
    void scenarioRatingSettersAndGetters() {
        ScenarioRating rating = new ScenarioRating();
        UUID scenarioId = UUID.randomUUID();
        String userId = "user-123";
        Integer ratingVal = 4;
        OffsetDateTime updatedAt = OffsetDateTime.now();

        rating.setScenarioId(scenarioId);
        rating.setUserId(userId);
        rating.setRating(ratingVal);
        rating.setUpdatedAt(updatedAt);

        assertEquals(scenarioId, rating.getScenarioId());
        assertEquals(userId, rating.getUserId());
        assertEquals(ratingVal, rating.getRating());
        assertEquals(updatedAt, rating.getUpdatedAt());
    }

    @Test
    void scenarioRatingRatingField_canStoreAllValues() {
        for (int val = 1; val <= 5; val++) {
            ScenarioRating rating = new ScenarioRating();
            rating.setRating(val);
            assertEquals(val, rating.getRating());
        }
    }

    // -------------------------------------------------------------------------
    // ScenarioRating.Key — general contract helpers
    // -------------------------------------------------------------------------

    @Test
    void keyHashCode_nullPointerHandling() {
        // hashCode throws NPE when scenarioId is null (by design in implementation)
        ScenarioRating.Key key = new ScenarioRating.Key();
        key.setScenarioId(null);
        key.setUserId(null);

        org.junit.jupiter.api.Assertions.assertThrows(
                NullPointerException.class, key::hashCode);
    }

    @Test
    void keyEquals_transitive() {
        UUID scenarioId = UUID.randomUUID();
        String userId = "user-trans";

        ScenarioRating.Key key1 = new ScenarioRating.Key(scenarioId, userId);
        ScenarioRating.Key key2 = new ScenarioRating.Key(scenarioId, userId);
        ScenarioRating.Key key3 = new ScenarioRating.Key(scenarioId, userId);

        assertEquals(key1, key2);
        assertEquals(key2, key3);
        assertEquals(key1, key3);
    }

    @Test
    void scenarioRating_entity_fields_allNullableByDefault() {
        ScenarioRating rating = new ScenarioRating();

        assertNull(rating.getScenarioId());
        assertNull(rating.getUserId());
        assertNull(rating.getRating());
        assertNull(rating.getUpdatedAt());
    }

    @Test
    void scenarioRating_key_equals_withSetFieldsAfterConstruction() {
        ScenarioRating.Key key = new ScenarioRating.Key();
        UUID scenarioId = UUID.randomUUID();
        String userId = "user-lazy";

        key.setScenarioId(scenarioId);
        key.setUserId(userId);

        ScenarioRating.Key other = new ScenarioRating.Key(scenarioId, userId);

        assertEquals(key, other);
        assertEquals(key.hashCode(), other.hashCode());
    }

    @Test
    void scenarioRating_key_equals_selfAfterFieldMutation() {
        UUID scenarioId = UUID.randomUUID();
        String userId = "user-mutate";

        ScenarioRating.Key key = new ScenarioRating.Key(scenarioId, userId);

        // Setting same values should still be equal
        key.setScenarioId(scenarioId);
        key.setUserId(userId);

        assertEquals(key, new ScenarioRating.Key(scenarioId, userId));
    }

    @Test
    void scenarioRating_key_hashCode_neutralWithNullFields_throwsNPE() {
        // When fields are null, hashCode throws NPE (implementation doesn't guard)
        ScenarioRating.Key key = new ScenarioRating.Key();
        key.setScenarioId(null);
        key.setUserId(null);

        org.junit.jupiter.api.Assertions.assertThrows(
                NullPointerException.class, key::hashCode);
    }
}
