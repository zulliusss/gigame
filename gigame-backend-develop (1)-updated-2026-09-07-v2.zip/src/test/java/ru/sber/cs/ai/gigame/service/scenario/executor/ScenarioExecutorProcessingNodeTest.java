package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ScenarioExecutorProcessingNodeTest {

    private GigaChatClient gigaChatClient;
    private EmbeddingService embeddingService;
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    /**
     * Input string long enough (>= 200 chars) for {@code substring(0, DETAILS_MAX_LENGTH)}.
     */
    private static final String LONG_INPUT = "This is a long input text that provides enough characters for the substring operation with the DETAILS_MAX_LENGTH limit of two hundred characters to ensure that the test will not fail with a StringIndexOutOfBoundsException when running executor.";

    @BeforeEach
    void setUp() {
        gigaChatClient = mock(GigaChatClient.class);
        embeddingService = mock(EmbeddingService.class);
    }

    // ================================================================
    // Constructor
    // ================================================================

    @Test
    void testConstructor_withoutServices() {
        var graph = createGraph("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node);
        assertNotNull(executor);
    }

    @Test
    void testConstructor_withServices() {
        var graph = createGraph("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        assertNotNull(executor);
    }

    // ================================================================
    // execute - simple input (parent is not loop)
    // ================================================================

    @Test
    void testExecute_simpleInput_callsGigaChat() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Processed result");
        var graph = createGraphWithParent("process-1", null, "Analyze this");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("Processed result"));
        verify(gigaChatClient, times(1)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_simpleInput_storesOutputInNode() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Output text");
        var graph = createGraphWithParent("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        executor.execute(sink);

        assertFalse(node.getOutput().isEmpty());
        assertEquals("Output text", node.getOutput().get(0));
    }

    @Test
    void testExecute_simpleInput_passesOutputToChildNodes() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result");
        var inputDto = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(0, 100))
                .build();
        var processDto = NodeDto.builder()
                .id("process-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Proc").prompt("prompt").build())
                .position(new PositionDto(100, 100))
                .build();
        var outputDto = NodeDto.builder()
                .id("output-1")
                .type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Output").build())
                .position(new PositionDto(200, 100))
                .build();
        var gd = new GraphDataDto(List.of(inputDto, processDto, outputDto),
                List.of(
                        new EdgeDto("e-in", "input-1", "process-1", new EdgeDataDto(null)),
                        new EdgeDto("e-out", "process-1", "output-1", new EdgeDataDto(null))
                ));
        var graph = new ScenarioRunGraph(gd);
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        executor.execute(sink);

        var child = graph.getNodeMap().get("output-1");
        assertFalse(child.getInput().isEmpty());
        assertTrue(child.getInput().get(0).contains("Proc"));
    }

    // ================================================================
    // execute - process doc list
    // ================================================================

    @Test
    void testExecute_withDocuments_processesEachDoc() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Doc result");
        var graph = createGraphWithParent("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        graph.addDocs(List.of("Doc 1 text", "Doc 2 text"), List.of("f1.pdf", "f2.pdf"));
        node.getDocList().addAll(List.of("DOC_1", "DOC_2"));
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    // ================================================================
    // execute - input list (parent is LOOP_NODE)
    // ================================================================

    @Test
    void testExecute_inputList_fromLoopNode() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Loop item result");
        var loopDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Loop").build())
                .position(new PositionDto(100, 100))
                .build();
        var processDto = NodeDto.builder()
                .id("process-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Proc").prompt("prompt").build())
                .position(new PositionDto(200, 100))
                .build();
        var gd = new GraphDataDto(List.of(loopDto, processDto),
                List.of(new EdgeDto("e1", "loop-1", "process-1", new EdgeDataDto(null))));
        var graph = new ScenarioRunGraph(gd);
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    // ================================================================
    // execute - with RAG (knowledge base)
    // ================================================================

    @Test
    void testExecute_withRag_kbChunksIncludedInPrompt() {
        float[] embedding = new float[1024];
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenReturn(List.of(embedding));
        when(embeddingService.hybridSearch(eq("kb"), any(UUID.class), any(), anyString()))
                .thenReturn(List.of("RAG chunk 1", "RAG chunk 2"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("RAG result");

        var graph = createGraphWithParent("process-1", kbId, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        ReflectionTestUtils.setField(executor, "ragQueryMaxLength", 800);
        ReflectionTestUtils.setField(executor, "cacheShortQueryLength", 200);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("RAG result"));
        verify(gigaChatClient, times(1)).getEmbeddings(anyList());
        verify(embeddingService, times(1)).hybridSearch(eq("kb"), any(UUID.class), any(), anyString());
    }

    @Test
    void testExecute_withRagSearchFailure_fallsBackGracefully() {
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenThrow(new RuntimeException("Embedding failed"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result without RAG");

        var graph = createGraphWithParent("process-1", kbId, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("Result without RAG"));
    }

    @Test
    void testExecute_withRagSearch_WithEmptyQuery() {
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenThrow(new RuntimeException("Embedding failed"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result without RAG");

        var graph = createGraphWithParent("process-1", kbId, "");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        assertNotNull(result);
        assertTrue(result.contains("Result without RAG"));
    }

    @Test
    void testExecute_withRag_embeddingsAreCached() {
        float[] embedding = new float[1024];
        String kbId = UUID.randomUUID().toString();
        when(gigaChatClient.getEmbeddings(anyList())).thenReturn(List.of(embedding));
        when(embeddingService.hybridSearch(eq("kb"), any(UUID.class), any(), anyString()))
                .thenReturn(List.of("cached chunk"));
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Result");

        var graph = createGraphWithParent("process-1", kbId, "prompt");
        var node = graph.getNodeMap().get("process-1");
        node.getInput().add(LONG_INPUT);
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        ReflectionTestUtils.setField(executor, "ragQueryMaxLength", 800);
        ReflectionTestUtils.setField(executor, "cacheShortQueryLength", 200);

        executor.execute(sink);

        verify(gigaChatClient, times(1)).getEmbeddings(anyList());
        verify(embeddingService, times(1)).hybridSearch(eq("kb"), any(UUID.class), any(), anyString());
    }

    // ================================================================
    // setConfiguration
    // ================================================================

    @Test
    void testSetConfiguration() {
        var graph = createGraph("process-1", null, "prompt");
        var node = graph.getNodeMap().get("process-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        executor.setConfiguration(500, 100);

        assertEquals(500, ReflectionTestUtils.getField(executor, "ragQueryMaxLength"));
        assertEquals(100, ReflectionTestUtils.getField(executor, "cacheShortQueryLength"));
    }

    // ================================================================
    // Helpers
    // ================================================================

    // ================================================================
    // execute - agent mode (function calling, документы через инструменты)
    // ================================================================

    @Test
    void testExecute_agentMode_pipelinePlanNotebookValidationFinal() {
        // план (#1) -> ReWOO-запросы (#2) -> тетрадь (tools) -> валидация -> финал (#3)
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Найти НМЦ\"]")
                .thenReturn("[{\"запрос\": \"НМЦ\"}]")
                .thenReturn("Итог: НМЦ = 511464226");
        String notebook = "{\"записи\": [{\"пункт\": 1, \"название\": \"НМЦ\", "
                + "\"значение\": \"511464226\", \"цитата\": \"НМЦД 511464226 руб\", "
                + "\"документ\": \"извещение.pdf\"}]}";
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(notebook, Map.of()));
        var graph = createAgentGraph("agent-1", "Выпиши НМЦ из извещения. Верни JSON.");
        var node = graph.getNodeMap().get("agent-1");
        graph.addDocs(List.of("Текст извещения с НМЦД 511464226 руб."), List.of("извещение.pdf"));
        node.getDocList().add("DOC_1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        // финал + аудиторский след источников из проверенной тетради
        assertTrue(result.startsWith("Итог: НМЦ = 511464226"));
        assertTrue(result.contains("=== ИСТОЧНИКИ (аудит) ==="));
        assertTrue(result.contains("НМЦД 511464226 руб"));
        ArgumentCaptor<List<Map<String, String>>> messages = ArgumentCaptor.forClass(List.class);
        ArgumentCaptor<List<org.springframework.ai.tool.ToolCallback>> tools =
                ArgumentCaptor.forClass(List.class);
        // план покрыт (пункт 1 закрыт) — добора нет, tool-цикл ровно один
        verify(gigaChatClient, times(1))
                .chatCompletionWithTools(messages.capture(), tools.capture(), any(), any());
        String allMessages = messages.getValue().stream()
                .map(m -> m.get("content")).reduce("", String::concat);
        assertTrue(allMessages.contains("Выпиши НМЦ"));
        assertTrue(allMessages.contains("Найти НМЦ"));
        // инструменты: поиск, чтение, think-tool, write_file
        assertEquals(4, tools.getValue().size());
        // план + ReWOO-запросы + финал; всё ПОДТВЕРЖДЕНО дословно —
        // гладкий прогон, рефлексия узла не генерируется (вызова нет)
        assertTrue(allMessages.contains("ПРЕДВАРИТЕЛЬНО СОБРАННЫЕ ФРАГМЕНТЫ"));
        ArgumentCaptor<List<Map<String, String>>> plain = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(3)).chatCompletion(plain.capture(), any(), any());
        String finalPrompt = plain.getAllValues().get(2).get(0).get("content");
        assertTrue(finalPrompt.contains(ru.sber.cs.ai.gigame.service.scenario.executor
                .AgentEvidence.CONFIRMED));
    }

    @Test
    void testExecute_agentMode_uncoveredPlanItemTriggersSecondLoop() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Найти НМЦ\", \"Найти технологии\"]")
                .thenReturn("Финальный ответ");
        String notebook1 = "{\"записи\": [{\"пункт\": 1, \"название\": \"НМЦ\", "
                + "\"значение\": \"1\", \"цитата\": \"НМЦД 1\", \"документ\": \"извещение.pdf\"}]}";
        String notebook2 = "{\"записи\": [{\"пункт\": 2, \"название\": \"технологии\", "
                + "\"значение\": \"не указано\", \"цитата\": \"\", \"документ\": \"\"}]}";
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(notebook1, Map.of()))
                .thenReturn(new GigaChatClient.ChatResult(notebook2, Map.of()));
        var graph = createAgentGraph("agent-1", "Задание");
        var node = graph.getNodeMap().get("agent-1");
        graph.addDocs(List.of("НМЦД 1"), List.of("извещение.pdf"));
        node.getDocList().add("DOC_1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        // финал + блок вопросов («не указано» по пункту 2 — повод спросить пользователя)
        assertTrue(result.startsWith("Финальный ответ"));
        // пункт 2 не был закрыт первым циклом — добор вторым tool-циклом
        verify(gigaChatClient, times(2)).chatCompletionWithTools(anyList(), anyList(), any(), any());
    }

    @Test
    void testExecute_agentMode_memoryLessonsInPromptAndQuestionsSaved() {
        var memory = mock(ru.sber.cs.ai.gigame.service.AgentMemoryService.class);
        when(memory.lessonsForScenario(any(), any()))
                .thenReturn(List.of("дата публикации = дата начала срока подачи заявок"));
        when(memory.findPlan(any())).thenReturn(null);
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Найти дату\"]")
                .thenReturn("Финал");
        // значение с цитатой, которой нет в документе -> вопрос пользователю
        String notebook = "{\"записи\": [{\"пункт\": 1, \"название\": \"Дата\", "
                + "\"значение\": \"01.01.2020\", \"цитата\": \"выдуманная цитата\", "
                + "\"документ\": \"извещение.pdf\"}]}";
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(notebook, Map.of()));
        var graph = createAgentGraph("agent-1", "Найди дату");
        graph.setRunId(UUID.randomUUID());
        graph.setScenarioId(UUID.randomUUID());
        var node = graph.getNodeMap().get("agent-1");
        graph.addDocs(List.of("настоящий текст извещения"), List.of("извещение.pdf"));
        node.getDocList().add("DOC_1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        executor.setAgentMemory(memory);

        String result = executor.execute(sink);

        // урок из памяти попал в системный промпт tool-цикла; отклонённая
        // запись больше не закрывает пункт плана — запускается добор (2-й цикл)
        ArgumentCaptor<List<Map<String, String>>> messages = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(2))
                .chatCompletionWithTools(messages.capture(), anyList(), any(), any());
        assertTrue(messages.getAllValues().get(0).get(0).get("content")
                .contains("дата публикации = дата начала срока подачи заявок"));
        // неподтверждённая цитата -> вопрос сохранён и виден в результате
        verify(memory).saveQuestions(any(), any(), any(), anyList());
        assertTrue(result.contains("АГЕНТ ПРОСИТ УТОЧНИТЬ"));
    }

    @Test
    void testExecute_agentMode_planFromMemorySkipsPlannerCall() {
        var memory = mock(ru.sber.cs.ai.gigame.service.AgentMemoryService.class);
        when(memory.lessonsForScenario(any(), any())).thenReturn(List.of());
        when(memory.findPlan(any())).thenReturn(List.of("Пункт из памяти"));
        String notebook = "{\"записи\": [{\"пункт\": 1, \"название\": \"Пункт из памяти\", "
                + "\"значение\": \"не указано\", \"цитата\": \"\", \"документ\": \"\"}]}";
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(notebook, Map.of()));
        // #1 — ReWOO-запросы (плановый вызов пропущен), #2 — финал
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[{\"запрос\": \"пункт\"}]")
                .thenReturn("Финал");
        var graph = createAgentGraph("agent-1", "Повторное задание");
        var node = graph.getNodeMap().get("agent-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        executor.setAgentMemory(memory);

        executor.execute(sink);

        // план взят из памяти: плановый вызов («чек-лист») пропущен,
        // остались ReWOO-запросы, финал и рефлексия узла («не указано» —
        // отклонение, рефлексия генерируется)
        ArgumentCaptor<List<Map<String, String>>> plain = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(3)).chatCompletion(plain.capture(), any(), any());
        for (var call : plain.getAllValues()) {
            assertFalse(call.get(0).get("content").contains("чек-лист"));
        }
        String reflectionPrompt = plain.getAllValues().get(2).get(0).get("content");
        assertTrue(reflectionPrompt.contains("рефлексию"));
        // рефлексия привязана к конкретному отклонению, а не к прогону вообще
        assertTrue(reflectionPrompt.contains("значение не найдено (не указано)"));
    }

    @Test
    void testExecute_agentMode_reformatsNonNotebookFinal() {
        String notebook = "{\"записи\": [{\"пункт\": 1, \"название\": \"НМЦ\", "
                + "\"значение\": \"100\", \"цитата\": \"НМЦД 100 руб\", "
                + "\"документ\": \"извещение.pdf\"}]}";
        // порядок: план, ReWOO (не распознан), переформат финала в тетрадь, финал
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Найти НМЦ\"]")
                .thenReturn("нет")
                .thenReturn(notebook)
                .thenReturn("Итог");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("НМЦ равен 100 (текст без тетради)", Map.of()));
        var graph = createAgentGraph("agent-1", "Выпиши НМЦ");
        var node = graph.getNodeMap().get("agent-1");
        graph.addDocs(List.of("Извещение: НМЦД 100 руб."), List.of("извещение.pdf"));
        node.getDocList().add("DOC_1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        // переформатированная тетрадь прошла валидацию — финал (+источники), не сырой текст
        assertTrue(result.startsWith("Итог"));
        ArgumentCaptor<List<Map<String, String>>> plain = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(4)).chatCompletion(plain.capture(), any(), any());
        assertTrue(plain.getAllValues().get(2).get(0).get("content").contains("рабочей тетради"));
    }

    @Test
    void testExecute_agentMode_bloatedMemoryPlanIgnored() {
        var memory = mock(ru.sber.cs.ai.gigame.service.AgentMemoryService.class);
        when(memory.lessonsForScenario(any(), any())).thenReturn(List.of());
        var bloated = new java.util.ArrayList<String>();
        for (int i = 1; i <= 21; i++) {
            bloated.add("Пункт " + i);
        }
        when(memory.findPlan(any())).thenReturn(bloated);
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Пункт\"]")
                .thenReturn("Финал");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("текст без тетради", Map.of()));
        var graph = createAgentGraph("agent-1", "Задание");
        var node = graph.getNodeMap().get("agent-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        executor.setAgentMemory(memory);

        executor.execute(sink);

        // раздутый план из памяти (21 пункт) проигнорирован — планировщик вызван
        ArgumentCaptor<List<Map<String, String>>> plain = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(3)).chatCompletion(plain.capture(), any(), any());
        assertTrue(plain.getAllValues().get(0).get(0).get("content").contains("чек-лист"));
    }

    @Test
    void testExecute_agentMode_seesWorkingFilesOfPreviousNodes() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Пункт\"]");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("текст без тетради", Map.of()));
        var graph = createAgentGraph("agent-1", "Задание");
        graph.addDocs(List.of("текст извещения"), List.of("извещение.pdf"));
        // рабочий файл, записанный агентом предыдущего узла
        graph.addWorkingDoc("конспект-правил.md", "НМЦ = 100");
        var node = graph.getNodeMap().get("agent-1");
        node.getDocList().add("DOC_1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        executor.execute(sink);

        // рабочий файл виден агенту в списке документов, хотя его нет в docList
        ArgumentCaptor<List<Map<String, String>>> messages = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, org.mockito.Mockito.atLeastOnce())
                .chatCompletionWithTools(messages.capture(), anyList(), any(), any());
        String system = messages.getAllValues().get(0).get(0).get("content");
        assertTrue(system.contains("конспект-правил.md"));
        assertTrue(system.contains("write_file"));
    }

    @Test
    void testExecute_agentReviewMode_reportWithoutNotebookValidation() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Сверить сумму акта\"]")
                .thenReturn("нет");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(
                        "Сумма акта совпадает: 27 080 240,00 (Акт №1)", Map.of()));
        var graph = createAgentGraph("agent-1", "Проверь суммы отчёта", "agent_review");
        var node = graph.getNodeMap().get("agent-1");
        graph.addDocs(List.of("Итого с НДС 27 080 240,00"), List.of("акт.pdf"));
        node.getDocList().add("DOC_1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        // отчёт ревизора и есть результат: без тетради, валидации, добора и финала
        assertEquals("Сумма акта совпадает: 27 080 240,00 (Акт №1)", result);
        ArgumentCaptor<List<Map<String, String>>> messages = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(1))
                .chatCompletionWithTools(messages.capture(), anyList(), any(), any());
        // только план + ReWOO; переформата и финального вызова нет
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
        String system = messages.getValue().get(0).get("content");
        assertTrue(system.contains("ПРОВЕРЯЮЩИЙ"));
        assertFalse(system.contains("рабочая тетрадь"));
    }

    @Test
    void testExecute_agentGroupMode_agentPerGroupWithCommonDocs() {
        // план/ReWOO/финал/рефлексия зовутся на каждую группу — единый стаб
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Пункт\"]");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("текст без тетради", Map.of()));
        var nodeDto = NodeDto.builder()
                .id("agent-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Агент по группам")
                        .prompt("По каждой заявке выпиши акты")
                        .mode("agent_group")
                        .value("(?iu)заявк\\D{0,4}(\\d+)")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(nodeDto), List.of()));
        var node = graph.getNodeMap().get("agent-1");
        graph.addDocs(List.of("текст заявки 4", "текст акта 4", "текст заявки 5",
                        "текст извещения"),
                List.of("Заявка №4.pdf", "Акт к заявке 4 №1.pdf", "Заявка №5.pdf",
                        "Извещение.docx"));
        node.getDocList().addAll(List.of("DOC_1", "DOC_2", "DOC_3", "DOC_4"));
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        // две группы (4 и 5) — два агентских tool-цикла
        ArgumentCaptor<List<Map<String, String>>> messages = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(2))
                .chatCompletionWithTools(messages.capture(), anyList(), any(), any());
        String sys1 = messages.getAllValues().get(0).get(0).get("content");
        String sys2 = messages.getAllValues().get(1).get(0).get("content");
        // группа 4: свои документы + общее извещение, БЕЗ документов группы 5
        assertTrue(sys1.contains("Заявка №4.pdf") && sys1.contains("Акт к заявке 4 №1.pdf"));
        assertTrue(sys1.contains("Извещение.docx"));
        assertFalse(sys1.contains("Заявка №5.pdf"));
        // группа 5: свои + общее извещение
        assertTrue(sys2.contains("Заявка №5.pdf") && sys2.contains("Извещение.docx"));
        assertTrue(result.contains("=== Группа 4 ===") && result.contains("=== Группа 5 ==="));
    }

    @Test
    void testExecute_agentGroupMode_failureKeepsCompletedGroupsInCheckpoint() {
        // сбой на второй группе не должен терять результат первой:
        // чекпойнт узла обязан содержать готовые группы (resume отдаст их
        // рабочим файлом, перебор не начнётся с нуля)
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Пункт\"]");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("итог группы 4", Map.of()))
                .thenThrow(new RuntimeException("Не удалось выполнить запрос к GigaChat"));
        var nodeDto = NodeDto.builder()
                .id("agent-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Агент по группам")
                        .prompt("По каждой заявке выпиши акты")
                        .mode("agent_group")
                        .value("(?iu)заявк\\D{0,4}(\\d+)")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(nodeDto), List.of()));
        var node = graph.getNodeMap().get("agent-1");
        graph.addDocs(List.of("текст заявки 4", "текст заявки 5"),
                List.of("Заявка №4.pdf", "Заявка №5.pdf"));
        node.getDocList().addAll(List.of("DOC_1", "DOC_2"));
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        assertThrows(RuntimeException.class, () -> executor.execute(sink));

        assertNotNull(executor.getCheckpoint());
        assertTrue(executor.getCheckpoint().contains("=== Группа 4 ==="),
                "готовая группа 4 должна пережить сбой группы 5: " + executor.getCheckpoint());
        assertTrue(executor.getCheckpoint().contains("итог группы 4"));
    }

    @Test
    void testExecute_agentMode_cancelledRunAborts() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("[\"Пункт\"]");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("текст", Map.of()));
        var graph = createAgentGraph("agent-1", "Задание");
        graph.requestCancel();
        var node = graph.getNodeMap().get("agent-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void testExecute_agentMode_degradesWhenNotebookNotRecognized() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Пункт\"]");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("простой текст без тетради", Map.of()));
        var graph = createAgentGraphWithChild("agent-1", "next-1", "Собери сводку.");
        var node = graph.getNodeMap().get("agent-1");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        // деградация: тетрадь не распознана — сырой ответ цикла, без финального вызова
        assertEquals("простой текст без тетради", result);
        var child = graph.getNodeMap().get("next-1");
        assertTrue(child.getInput().get(0).contains("простой текст без тетради"));
    }

    private static ScenarioRunGraph contractGraph(String rules) {
        var inputDto = NodeDto.builder()
                .id("i0").type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Вход").build())
                .position(new PositionDto(0, 0)).build();
        var nodeDto = NodeDto.builder()
                .id("p1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Строки")
                        .prompt("Собери строки")
                        .rules(rules)
                        .build())
                .position(new PositionDto(200, 0))
                .build();
        return new ScenarioRunGraph(new GraphDataDto(List.of(inputDto, nodeDto),
                List.of(new EdgeDto("e1", "i0", "p1", new EdgeDataDto(null)))));
    }

    @Test
    void testExecute_outputContract_repairsInvalidOutput() {
        var graph = contractGraph("{\"контракт\": {\"тип\": \"json_массив\", "
                + "\"обязательные_ключи\": [\"сумма_итого\"], \"мин_элементов\": 1}}");
        var node = graph.getNodeMap().get("p1");
        node.getInput().add("данные");
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("вот таблица: [{\"акт\": \"№1\"}]")
                .thenReturn("[{\"акт\": \"№1\", \"сумма_итого\": 100.0}]");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        String result = executor.execute(sink);

        // нарушение контракта (нет ключа) → repair-вызов вернул корректный массив
        assertTrue(result.contains("сумма_итого"));
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_outputContract_failsWhenRepairAlsoInvalid() {
        var graph = contractGraph("{\"контракт\": {\"тип\": \"json_массив\", "
                + "\"мин_элементов\": 2}}");
        var node = graph.getNodeMap().get("p1");
        node.getInput().add("данные");
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[{\"а\": 1}]");
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);

        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    private static ScenarioRunGraph createAgentGraph(String nodeId, String intent) {
        return createAgentGraph(nodeId, intent, "agent");
    }

    private static ScenarioRunGraph createAgentGraph(String nodeId, String intent, String mode) {
        var nodeDto = NodeDto.builder()
                .id(nodeId)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Агент")
                        .prompt(intent)
                        .mode(mode)
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var gd = new GraphDataDto(List.of(nodeDto), List.of());
        return new ScenarioRunGraph(gd);
    }

    private static ScenarioRunGraph createAgentGraphWithChild(String nodeId, String childId, String intent) {
        var agentDto = NodeDto.builder()
                .id(nodeId)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Агент").prompt(intent).mode("agent").build())
                .position(new PositionDto(0, 0))
                .build();
        var childDto = NodeDto.builder()
                .id(childId)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Следующий").prompt("p").build())
                .position(new PositionDto(200, 0))
                .build();
        var gd = new GraphDataDto(List.of(agentDto, childDto),
                List.of(new EdgeDto("e1", nodeId, childId, new EdgeDataDto(null))));
        return new ScenarioRunGraph(gd);
    }

    private static ScenarioRunGraph createGraph(String nodeId, String kbId, String prompt) {
        var nodeDto = NodeDto.builder()
                .id(nodeId)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Process")
                        .prompt(prompt)
                        .knowledgeBaseId(kbId)
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var gd = new GraphDataDto(List.of(nodeDto), List.of());
        return new ScenarioRunGraph(gd);
    }

    /**
     * Creates a graph with an input node as parent of the processing node.
     * This ensures {@code node.getParentNodeList().get(0)} does not throw.
     */
    private static ScenarioRunGraph createGraphWithParent(String processNodeId, String kbId, String prompt) {
        var inputDto = NodeDto.builder()
                .id("dummy-input")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("DummyInput").build())
                .position(new PositionDto(0, 0))
                .build();
        var processDto = NodeDto.builder()
                .id(processNodeId)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Process")
                        .prompt(prompt)
                        .knowledgeBaseId(kbId)
                        .build())
                .position(new PositionDto(200, 0))
                .build();
        var gd = new GraphDataDto(List.of(inputDto, processDto),
                List.of(new EdgeDto("e1", "dummy-input", processNodeId, new EdgeDataDto(null))));
        return new ScenarioRunGraph(gd);
    }
}