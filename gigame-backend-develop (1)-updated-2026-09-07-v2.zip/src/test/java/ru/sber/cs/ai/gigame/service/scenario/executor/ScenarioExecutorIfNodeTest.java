package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import static org.junit.jupiter.params.provider.Arguments.arguments;

class ScenarioExecutorIfNodeTest {

    private ScenarioRunGraph structure;

    @BeforeEach
    void setUp() {
        NodeDto inputNode = NodeDto.builder()
                .id("input-1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Input").build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto ifNode = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder().label("If").build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto trueBranch = NodeDto.builder()
                .id("true-branch")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("True Branch").build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto falseBranch = NodeDto.builder()
                .id("false-branch")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("False Branch").build())
                .position(new PositionDto(100, 100))
                .build();
        EdgeDto edge1 = new EdgeDto("e1", "input-1", "if-1", new EdgeDataDto(null));
        EdgeDto edge2 = new EdgeDto("e2", "if-1", "true-branch", new EdgeDataDto("true"));
        EdgeDto edge3 = new EdgeDto("e3", "if-1", "false-branch", new EdgeDataDto("false"));

        GraphDataDto graphData = new GraphDataDto(
                List.of(inputNode, ifNode, trueBranch, falseBranch),
                List.of(edge1, edge2, edge3)
        );
        structure = new ScenarioRunGraph(graphData);
    }

    private ScenarioRunNode getIfNode() {
        return structure.getNodeMap().get("if-1");
    }

    // ================================================================
    // Constructor
    // ================================================================

    @Test
    void testConstructor() {
        var node = getIfNode();
        var executor = new ScenarioExecutorIfNode(node);
        assertNotNull(executor);
    }

    // ================================================================
    // execute - contains operator (default)
    // ================================================================

    @Test
    void testExecute_containsOperator_match() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If")
                        .operator("contains")
                        .value("test")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("This is a test");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertFalse(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertTrue(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    // ================================================================
    // execute - no match tests (parameterized)
    // ================================================================

    static Stream<Arguments> noMatchProvider() {
        return Stream.of(
                arguments("contains", "nomatch", "Different content"),
                arguments("less_than", "5", "Value: 10"),
                arguments("greater_than", "5", "No numbers here"),
                arguments("equals", "exact", "not exact"),
                arguments("not_contains", "test", "This is a test"),
                arguments("greater_than", "15", "Value: 10")
        );
    }

    @ParameterizedTest
    @MethodSource("noMatchProvider")
    void testExecute_noMatch(String operator, String value, String input) {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If")
                        .operator(operator)
                        .value(value)
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add(input);
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertTrue(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    // ================================================================
    // execute - parameterized match tests
    // ================================================================

    static Stream<Arguments> matchOperatorProvider() {
        return Stream.of(
                arguments("equals", "exact", "exact"),
                arguments("not_contains", "nomatch", "This is a test"),
                arguments("greater_than", "5", "Value: 10"),
                arguments("less_than", "15", "Value: 10")
        );
    }

    @ParameterizedTest
    @MethodSource("matchOperatorProvider")
    void testExecute_operator_match(String operator, String value, String input) {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If")
                        .operator(operator)
                        .value(value)
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto tb = NodeDto.builder()
                .id("true-branch")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("True Branch").build())
                .position(new PositionDto(200, 100))
                .build();
        NodeDto fb = NodeDto.builder()
                .id("false-branch")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("False Branch").build())
                .position(new PositionDto(300, 100))
                .build();
        EdgeDto e2 = new EdgeDto("e2", "if-1", "true-branch", new EdgeDataDto("true"));
        EdgeDto e3 = new EdgeDto("e3", "if-1", "false-branch", new EdgeDataDto("false"));
        GraphDataDto gd = new GraphDataDto(List.of(ifDto, tb, fb), List.of(e2, e3));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add(input);
        var executor = new ScenarioExecutorIfNode(ifNode);

        executor.execute(null);

        assertFalse(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertTrue(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    // ================================================================
    // execute - less_than / greater_than operators
    // ================================================================

    @Test
    void testExecute_lessThanOperator_noMatch() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").operator("less_than").value("5")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("Value: 10");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertTrue(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    @Test
    void testExecute_numericComparison_nonNumericText_goesToFalse() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").operator("greater_than").value("5")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("No numbers here");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertTrue(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    // ================================================================
    // execute - field filtering
    // ================================================================

    @Test
    void testExecute_fieldFiltering_matchesSpecificField() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").field("field_name").operator("contains").value("value")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("field_name: value\nother: data");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertFalse(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertTrue(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    @Test
    void testExecute_fieldFiltering_noMatch_goesToFalse() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").field("field_name").operator("contains").value("nomatch")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("field_name: value\nother: data");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertTrue(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    @Test
    void testExecute_fieldFiltering_missingField_goesToFalse() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").field("missing_field").operator("contains").value("value")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("some: thing\nother: data");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertTrue(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("false-branch").getInput().isEmpty());
    }

    // ================================================================
    // execute - skip propagation
    // ================================================================

    @Test
    void testExecute_marksUnmatchedBranchAsSkipped() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").operator("contains").value("match")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("match this text");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertFalse(graph.getNodeMap().get("true-branch").getSkip());
        assertTrue(graph.getNodeMap().get("false-branch").getSkip());
    }

    @Test
    void testExecute_marksBothBranchesNotSkipped_whenBothReceiveData() {
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").operator("contains").value("match")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var tb = makeBranchNode("true-branch", 200);
        var fb = makeBranchNode("false-branch", 300);
        var gd = new GraphDataDto(List.of(ifDto, tb, fb),
                List.of(edge("if-1", "true-branch", "true"), edge("if-1", "false-branch", "false")));
        var graph = new ScenarioRunGraph(gd);
        var ifNode = graph.getNodeMap().get("if-1");
        ifNode.getInput().add("match this");
        ifNode.getInput().add("something else entirely");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertFalse(graph.getNodeMap().get("true-branch").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("false-branch").getInput().isEmpty());
        assertFalse(graph.getNodeMap().get("true-branch").getSkip());
        assertFalse(graph.getNodeMap().get("false-branch").getSkip());
    }

    // ================================================================
    // execute - stores output
    // ================================================================

    @Test
    void testExecute_storesOutputInNode() {
        var node = getIfNode();
        node.getInput().add("test content");
        new ScenarioExecutorIfNode(node).execute(null);
        assertFalse(node.getOutput().isEmpty());
    }

    // ================================================================
    // execute - classifyStrict mode (parent is loop node with classify strict)
    // ================================================================

    @Test
    void testExecute_classifyStrict_filterDocsByClass() {
        var loopDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Loop").classifyStrict("true").classes("ТЗ,КП").build())
                .position(new PositionDto(100, 100))
                .build();
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").field("docClass").operator("equals").value("ТЗ")
                        .build())
                .position(new PositionDto(200, 100))
                .build();
        var tb = makeBranchNode("true-branch", 300);
        var fb = makeBranchNode("false-branch", 400);
        var edges = List.of(
                edge("loop-1", "if-1", null),
                edge("if-1", "true-branch", "true"),
                edge("if-1", "false-branch", "false")
        );
        var gd = new GraphDataDto(List.of(loopDto, ifDto, tb, fb), edges);
        var graph = new ScenarioRunGraph(gd);
        graph.addDocs(List.of("Text of doc 1", "Text of doc 2"), List.of("doc1.pdf", "doc2.pdf"));
        graph.getDocMap().get("DOC_1").setDocClass("ТЗ");
        graph.getDocMap().get("DOC_2").setDocClass("КП");
        graph.getNodeMap().get("loop-1").getDocList().addAll(List.of("DOC_1", "DOC_2"));
        var ifNode = graph.getNodeMap().get("if-1");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertTrue(graph.getNodeMap().get("true-branch").getDocList().contains("DOC_1"));
        assertFalse(graph.getNodeMap().get("true-branch").getDocList().contains("DOC_2"));
        assertTrue(graph.getNodeMap().get("false-branch").getDocList().contains("DOC_2"));
        assertFalse(graph.getNodeMap().get("false-branch").getDocList().contains("DOC_1"));
    }

    @Test
    void testExecute_classifyStrict_noMatchingDocs_marksBranchSkipped() {
        var loopDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(NodeDataDto.builder().label("Loop").classifyStrict("true").classes("ТЗ,КП").build())
                .position(new PositionDto(100, 100))
                .build();
        var ifDto = NodeDto.builder()
                .id("if-1")
                .type(ScenarioNodeType.IF_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("If").field("docClass").operator("equals").value("NONEXISTENT")
                        .build())
                .position(new PositionDto(200, 100))
                .build();
        var tb = makeBranchNode("true-branch", 300);
        var fb = makeBranchNode("false-branch", 400);
        var edges = List.of(
                edge("loop-1", "if-1", null),
                edge("if-1", "true-branch", "true"),
                edge("if-1", "false-branch", "false")
        );
        var gd = new GraphDataDto(List.of(loopDto, ifDto, tb, fb), edges);
        var graph = new ScenarioRunGraph(gd);
        graph.addDocs(List.of("Text of doc 1"), List.of("doc1.pdf"));
        graph.getDocMap().get("DOC_1").setDocClass("ТЗ");
        graph.getNodeMap().get("loop-1").getDocList().add("DOC_1");
        var ifNode = graph.getNodeMap().get("if-1");
        new ScenarioExecutorIfNode(ifNode).execute(null);
        assertTrue(graph.getNodeMap().get("true-branch").getSkip());
        assertFalse(graph.getNodeMap().get("false-branch").getDocList().isEmpty());
    }

    // ================================================================
    // Helpers
    // ================================================================

    private static NodeDto makeBranchNode(String id, int x) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label(id).build())
                .position(new PositionDto(x, 100))
                .build();
    }

    private static EdgeDto edge(String src, String tgt, String label) {
        return new EdgeDto(src + "-" + tgt, src, tgt, new EdgeDataDto(label));
    }
}