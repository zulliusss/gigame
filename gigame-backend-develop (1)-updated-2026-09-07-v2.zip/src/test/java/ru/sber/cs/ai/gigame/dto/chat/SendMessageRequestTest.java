package ru.sber.cs.ai.gigame.dto.chat;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class SendMessageRequestTest {

    @Test
    void testConstruction_withContent() {
        var dto = new SendMessageRequest("Hello message");
        assertEquals("Hello message", dto.content());
    }

    @Test
    void testConstruction_withNullContent() {
        var dto = new SendMessageRequest(null);
        assertNull(dto.content());
    }
}