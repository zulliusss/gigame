package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

class ScenarioExecutorWaitNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private NodeDto inputNode;
    private NodeDto waitNodeEmpty;
    private NodeDto waitNode;
    private NodeDto waitNodeMax;
    private NodeDto outputNode;
    private EdgeDto edge1;
    private EdgeDto edge2;

    private static NodeDto createNode(String id, ScenarioNodeType type, String label, String value, int x, int y) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).value(value).build())
                .position(new PositionDto(x, y))
                .build();
    }

    @BeforeEach
    void setUp() {
        inputNode = createNode("input-1", ScenarioNodeType.INPUT_NODE, "Input", null, 100, 100);
        waitNodeEmpty = createNode("wait-1", ScenarioNodeType.WAIT_NODE, "wait", null, 300, 100);
        waitNode = createNode("wait-1", ScenarioNodeType.WAIT_NODE, "wait", "1,5", 300, 100);
        waitNodeMax = createNode("wait-1", ScenarioNodeType.WAIT_NODE, "wait", "303", 300, 100);
        outputNode = createNode("output-1", ScenarioNodeType.OUTPUT_NODE, "Output", null, 300, 100);
        edge1 = new EdgeDto("edge-1", "input-1", "wait-1", new EdgeDataDto(null));
        edge2 = new EdgeDto("edge-2", "wait-1", "output-1", new EdgeDataDto(null));
    }

    @Test
    void testExecute_withEmptyWaitTime() {
        var graphData = new GraphDataDto(List.of(inputNode, waitNodeEmpty, outputNode), List.of(edge1, edge2));
        var node = ScenarioRunNode.fromDto(1, waitNodeEmpty, new ScenarioRunGraph(graphData));
        var executor = new ScenarioExecutorWaitNode(node);
        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void testExecute_withWaitTime() {
        var graphData = new GraphDataDto(List.of(inputNode, waitNode, outputNode), List.of(edge1, edge2));
        var node = ScenarioRunNode.fromDto(1, waitNode, new ScenarioRunGraph(graphData));
        var executor = new ScenarioExecutorWaitNode(node);
        String result = executor.execute(sink);
        assertEquals("⏸ Пауза 1 с", result);
    }

    @Test
    void testExecute_withMaxWaitTime() {
        var graphData = new GraphDataDto(List.of(inputNode, waitNodeMax, outputNode), List.of(edge1, edge2));
        var node = ScenarioRunNode.fromDto(1, waitNodeMax, new ScenarioRunGraph(graphData));
        var executor = new ScenarioExecutorWaitNode(node);
        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }
}