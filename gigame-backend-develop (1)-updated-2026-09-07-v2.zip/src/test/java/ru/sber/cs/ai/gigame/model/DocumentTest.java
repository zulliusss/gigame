package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class DocumentTest {

    @Test
    void testDocumentDefaultValues() {
        Document document = new Document();
        assertNull(document.getId());
        assertNull(document.getFilename());
        assertNull(document.getContentType());
        assertNull(document.getExtractedText());
        assertNull(document.getSizeBytes());
        assertNull(document.getUserId());
        assertNull(document.getCreatedAt());
        assertNull(document.getUpdatedAt());
    }

    @Test
    void testDocumentWithAllFields() {
        UUID id = UUID.randomUUID();
        OffsetDateTime createdAt = OffsetDateTime.now();

        Document document = new Document();
        document.setId(id);
        document.setFilename("test.pdf");
        document.setContentType("pdf");
        document.setExtractedText("Extracted text content");
        document.setSizeBytes(1024);
        document.setUserId("user123");
        document.setCreatedAt(createdAt);

        assertEquals(id, document.getId());
        assertEquals("test.pdf", document.getFilename());
        assertEquals("pdf", document.getContentType());
        assertEquals("Extracted text content", document.getExtractedText());
        assertEquals(Integer.valueOf(1024), document.getSizeBytes());
        assertEquals("user123", document.getUserId());
        assertEquals(createdAt, document.getCreatedAt());
    }

    @Test
    void testDocumentWithNullExtractedText() {
        Document document = new Document();
        document.setExtractedText(null);

        assertNull(document.getExtractedText());
    }

    @Test
    void testDocumentEmptyFilename() {
        Document document = new Document();
        document.setFilename("");

        assertEquals("", document.getFilename());
    }

    @Test
    void testDocumentLongText() {
        Document document = new Document();
        String longText = "A".repeat(10000);
        document.setExtractedText(longText);

        assertEquals(longText, document.getExtractedText());
        assertEquals(longText.length(), document.getExtractedText().length());
    }

    @Test
    void testToString() {
        Document document = new Document();
        String str = document.toString();
        assertNotNull(str);
        assertTrue(str.contains("Document"));
    }
}
