package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRating;
import ru.sber.cs.ai.gigame.repository.ScenarioRatingRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.UserUtils;

import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScenarioServiceRateTest {

    @Mock
    private ScenarioRepository scenarioRepository;

    @Mock
    private ScenarioRatingRepository scenarioRatingRepository;

    @Captor
    private ArgumentCaptor<ScenarioRating> ratingCaptor;

    private String userId;
    private UUID scenarioId;
    private Scenario scenario;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID().toString();
        scenarioId = UUID.randomUUID();
        scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setUserId(userId);
        scenario.setName("Test Scenario");
        scenario.setShared(true);
        scenario.setCreatedAt(OffsetDateTime.now());
        scenario.setUpdatedAt(OffsetDateTime.now());
    }

    // -------------------------------------------------------------------------
    // rateScenario logic (mirrors ScenarioService.rateScenario)
    // -------------------------------------------------------------------------

    /**
     * Mirror of the service method for testing logic in isolation.
     * In production, this logic lives in ScenarioService.rateScenario.
     */
    private void rateScenario(UUID id, int rating) {
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Оценка должна быть от 1 до 5");
        }
        Scenario scenarioLoc = scenarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Scenario not found: " + id));
        String user = CurrentUserHolder.getCurrentUser();
        String uid = user == null || user.isBlank() ? "anonymous" : user;
        if (!Boolean.TRUE.equals(scenarioLoc.getShared())) {
            UserUtils.checkUserId(user, scenarioLoc.getUserId());
        }
        ScenarioRating vote = new ScenarioRating();
        vote.setScenarioId(id);
        vote.setUserId(uid);
        vote.setRating(rating);
        scenarioRatingRepository.save(vote);
    }

    // -------------------------------------------------------------------------
    // Tests
    // -------------------------------------------------------------------------

    @Test
    void testRateScenario_success() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 5); return null; });

        verify(scenarioRatingRepository).save(ratingCaptor.capture());
        ScenarioRating captured = ratingCaptor.getValue();
        assertEquals(scenarioId, captured.getScenarioId());
        assertEquals(userId, captured.getUserId());
        assertEquals(5, captured.getRating());
    }

    @Test
    void testRateScenario_sharedScenario_otherUser() {
        Scenario sharedScenario = new Scenario();
        sharedScenario.setId(scenarioId);
        sharedScenario.setUserId("other-user");
        sharedScenario.setShared(true);
        sharedScenario.setName("Shared Scenario");
        sharedScenario.setCreatedAt(OffsetDateTime.now());
        sharedScenario.setUpdatedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(sharedScenario));

        CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 3); return null; });

        verify(scenarioRatingRepository).save(ratingCaptor.capture());
        assertEquals(scenarioId, ratingCaptor.getValue().getScenarioId());
        assertEquals(userId, ratingCaptor.getValue().getUserId());
    }

    @Test
    void testRateScenario_privateScenario_owner() {
        scenario.setShared(false);
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 4); return null; });

        verify(scenarioRatingRepository).save(ratingCaptor.capture());
        assertEquals(4, ratingCaptor.getValue().getRating());
    }

    @Test
    void testRateScenario_privateScenario_otherUser_throws() {
        Scenario privateScenario = new Scenario();
        privateScenario.setId(scenarioId);
        privateScenario.setUserId("other-user");
        privateScenario.setShared(false);
        privateScenario.setName("Private Scenario");
        privateScenario.setCreatedAt(OffsetDateTime.now());
        privateScenario.setUpdatedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(privateScenario));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 3); return null; }));
    }

    @Test
    void testRateScenario_ratingBelowRange_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 0); return null; }));
    }

    @Test
    void testRateScenario_ratingAboveRange_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 6); return null; }));
    }

    @Test
    void testRateScenario_notFound_throws() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 3); return null; }));
    }

    @Test
    void testRateScenario_replacesPreviousRating() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 5); return null; });
        CurrentUserHolder.withUser(userId, () -> { rateScenario(scenarioId, 3); return null; });

        // Both saves are called — replace happens at DB level
        verify(scenarioRatingRepository, org.mockito.Mockito.times(2)).save(any());
    }

    @Test
    void testRateScenario_anonymousUser() {
        Scenario privateScenario = new Scenario();
        privateScenario.setId(scenarioId);
        privateScenario.setUserId("anonymous");
        privateScenario.setShared(false);

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(privateScenario));

        CurrentUserHolder.withUser(null, () -> { rateScenario(scenarioId, 4); return null; });

        verify(scenarioRatingRepository).save(ratingCaptor.capture());
        assertEquals("anonymous", ratingCaptor.getValue().getUserId());
    }

    // -------------------------------------------------------------------------
    // Shared visibility tests
    // -------------------------------------------------------------------------

    @Test
    void testRateScenario_sharedVisibleToAll() {
        // shared = true: любой может оценить
        Scenario shared = new Scenario();
        shared.setId(scenarioId);
        shared.setUserId("creator");
        shared.setShared(true);
        shared.setCreatedAt(OffsetDateTime.now());
        shared.setUpdatedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(shared));

        // User1, User2, User3 — все оценивают
        CurrentUserHolder.withUser("user1", () -> { rateScenario(scenarioId, 5); return null; });
        CurrentUserHolder.withUser("user2", () -> { rateScenario(scenarioId, 3); return null; });
        CurrentUserHolder.withUser("user3", () -> { rateScenario(scenarioId, 4); return null; });

        verify(scenarioRatingRepository, org.mockito.Mockito.times(3)).save(any());
    }

    @Test
    void testRateScenario_privateOnlyOwner() {
        // shared = false: только владелец
        Scenario privateScenario = new Scenario();
        privateScenario.setId(scenarioId);
        privateScenario.setUserId("owner");
        privateScenario.setShared(false);
        privateScenario.setCreatedAt(OffsetDateTime.now());
        privateScenario.setUpdatedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(privateScenario));

        // Владелец может
        CurrentUserHolder.withUser("owner", () -> { rateScenario(scenarioId, 5); return null; });

        // Другие не могут
        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("other", () -> { rateScenario(scenarioId, 3); return null; }));
    }
}
