package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ScenarioTest {

    @Test
    void testScenarioDefaultValues() {
        Scenario scenario = new Scenario();
        assertNull(scenario.getId());
        assertNull(scenario.getName());
        assertNull(scenario.getDescription());
        assertNull(scenario.getGraphData());
        assertNull(scenario.getUserId());
        assertNull(scenario.getCreatedAt());
        assertNull(scenario.getUpdatedAt());
        assertTrue(scenario.getRuns().isEmpty());
    }

    @Test
    void testScenarioWithAllFields() {
        UUID id = UUID.randomUUID();
        OffsetDateTime createdAt = OffsetDateTime.now();

        Scenario scenario = new Scenario();
        scenario.setId(id);
        scenario.setName("Test Scenario");
        scenario.setDescription("Test description");
        scenario.setGraphData(Map.of("nodes", List.of(), "edges", List.of()));
        scenario.setUserId("user123");
        scenario.setCreatedAt(createdAt);

        assertEquals(id, scenario.getId());
        assertEquals("Test Scenario", scenario.getName());
        assertEquals("Test description", scenario.getDescription());
        assertNotNull(scenario.getGraphData());
        assertEquals("user123", scenario.getUserId());
        assertEquals(createdAt, scenario.getCreatedAt());
    }

    @Test
    void testScenarioWithEmptyGraphData() {
        Scenario scenario = new Scenario();
        scenario.setGraphData(Map.of());

        assertNotNull(scenario.getGraphData());
        assertTrue(scenario.getGraphData().isEmpty());
    }

    @Test
    void testScenarioAddRun() {
        Scenario scenario = new Scenario();
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());

        scenario.getRuns().add(run);

        assertEquals(1, scenario.getRuns().size());
    }

    @Test
    void testScenarioRemoveRun() {
        Scenario scenario = new Scenario();
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenario.getId());
        scenario.getRuns().add(run);

        assertEquals(1, scenario.getRuns().size());
        scenario.getRuns().remove(run);
        assertTrue(scenario.getRuns().isEmpty());
    }

    @Test
    void testScenarioEmptyName() {
        Scenario scenario = new Scenario();
        scenario.setName("");

        assertEquals("", scenario.getName());
    }

    @Test
    void testToString() {
        Scenario scenario = new Scenario();
        String str = scenario.toString();
        assertNotNull(str);
        assertTrue(str.contains("Scenario"));
    }
}
