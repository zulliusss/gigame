package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.io.Resource;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRating;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.model.ScenarioVersion;
import ru.sber.cs.ai.gigame.repository.ScenarioRatingRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.io.IOException;
import java.io.InputStream;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ScenarioServiceTest {

    @Mock
    private ScenarioRepository scenarioRepository;

    @Mock
    private ScenarioRunRepository scenarioRunRepository;

    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;

    @Mock
    private ScenarioVersionRepository scenarioVersionRepository;

    @Mock
    private ScenarioRatingRepository scenarioRatingRepository;

    @Mock
    private DocumentService documentService;

    @Mock
    private ScenarioEngine scenarioEngine;

    @InjectMocks
    private ScenarioService scenarioService;

    @Captor
    private ArgumentCaptor<Scenario> scenarioCaptor;

    private UUID userId;
    private UUID scenarioId;
    private Scenario scenario;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        scenarioId = UUID.randomUUID();
        scenario = new Scenario();
        scenario.setId(scenarioId);
        scenario.setUserId(userId.toString());
        scenario.setName("Test Scenario");
        scenario.setDescription("Test description");
        scenario.setCreatedAt(OffsetDateTime.now());
        scenario.setUpdatedAt(OffsetDateTime.now());

        NodeDto node1 = NodeDto.builder()
                .id("node1")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Node 1")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        NodeDto node2 = NodeDto.builder()
                .id("node2")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Node 2")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        EdgeDto edge = new EdgeDto(
                "edge-1",
                "node-1",
                "node-2",
                new EdgeDataDto("edge-1")
        );
        GraphDataDto graphData = new GraphDataDto(
                List.of(node1, node2),
                List.of(edge)
        );
        scenario.setGraphData(GraphDataMapper.fromDto(graphData));
        ReflectionTestUtils.setField(scenarioService, "self", new AtomicReference<>(scenarioService));

    }

    // -------------------------------------------------------------------------
    // Helper methods for creating mock test data
    // -------------------------------------------------------------------------

    private FilePart createMockFilePart(String filename, String content) {
        FilePart mockFile = mock(FilePart.class);
        when(mockFile.filename()).thenReturn(filename);
        byte[] bytes = content.getBytes();
        when(mockFile.content()).thenReturn(Flux.just(new DefaultDataBufferFactory().wrap(bytes)));
        return mockFile;
    }

    // -------------------------------------------------------------------------
    // Tests for getDocumentsText method
    // -------------------------------------------------------------------------

    @Test
    void testGetDocumentsText_withMultipleFiles_success() throws IOException {
        // Given
        FilePart file1 = createMockFilePart("file1.pdf", "PDF content");
        FilePart file2 = createMockFilePart("file2.docx", "DOCX content");

        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenReturn("PDF extracted text");
        when(documentService.parseText(any(InputStream.class), eq("docx")))
                .thenReturn("DOCX extracted text");

        List<FilePart> files = List.of(file1, file2);
        List<ServerSentEvent<Map<String, Object>>> uploadEvents = new ArrayList<>();

        // When
        var result = scenarioService.getDocumentsText(files, uploadEvents);

        // Then
        assertNotNull(result);
        assertTrue(result.contains("PDF extracted text"));
        assertTrue(result.contains("DOCX extracted text"));
        assertEquals(3, uploadEvents.size());
        var lastEventData = uploadEvents.get(2).data();
        assertNotNull(lastEventData);
        assertEquals("upload_done", lastEventData.get("type"));
        assertEquals(2, lastEventData.get("count"));
    }

    @Test
    void testGetDocumentsText_withNullUploadEvents_success() throws IOException {
        // Given
        FilePart file1 = createMockFilePart("file1.txt", "TXT content");

        when(documentService.parseText(any(InputStream.class), eq("txt")))
                .thenReturn("TXT extracted text");

        List<FilePart> files = List.of(file1);

        // When
        var result = scenarioService.getDocumentsText(files, null);

        // Then
        assertNotNull(result);
        assertEquals("TXT extracted text", result.get(0));
    }

    @Test
    void testGetDocumentsText_withFileParsingError_marksDocumentForManualReview() throws IOException {
        // Given: нечитаемый файл не роняет загрузку — документ получает маркер ручной проверки
        FilePart file = createMockFilePart("file.pdf", "content");

        when(documentService.parseText(any(InputStream.class), eq("pdf")))
                .thenThrow(new RuntimeException("Parse error"));

        List<FilePart> files = List.of(file);
        List<ServerSentEvent<Map<String, Object>>> uploadEvents = new ArrayList<>();

        // When
        List<String> texts = scenarioService.getDocumentsText(files, uploadEvents);

        // Then
        assertEquals(1, texts.size());
        assertTrue(texts.get(0).contains("[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]"));
        assertTrue(texts.get(0).contains("file.pdf"));
        assertTrue(uploadEvents.stream().anyMatch(e -> e.data() != null
                && String.valueOf(e.data().get("message")).contains("не обработан")));
    }

    @Test
    void testGetDocumentsText_withSingleFile_success() throws IOException {
        // Given
        FilePart file = createMockFilePart("single.xlsx", "XLSX content");

        when(documentService.parseText(any(InputStream.class), eq("xlsx")))
                .thenReturn("XLSX extracted text");

        List<FilePart> files = List.of(file);

        // When
        var result = scenarioService.getDocumentsText(files, null);

        // Then
        assertNotNull(result);
        assertEquals("XLSX extracted text", result.get(0));
    }

    // -------------------------------------------------------------------------
    // Tests for extractToDocx method
    // -------------------------------------------------------------------------

    @Test
    void testExtractToDocx_withProcessingOutputNode_generatesDocx() {
        // Given
        UUID runId = UUID.randomUUID();

        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(new ScenarioRun()));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        // When
        ResponseEntity<Resource> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.extractToDocx(runId, true));

        // Then
        assertNotNull(result);
        assertEquals(200, result.getStatusCode().value());
    }

    @Test
    void testExtractToDocx_withProcessingOutputNode_generatesXlsx() {

        // Given
        UUID runId = UUID.randomUUID();
        ScenarioRunStep stepInput = new ScenarioRunStep();
        stepInput.setRunId(runId);
        stepInput.setNodeId("node1");
        stepInput.setNodeType("input");
        ScenarioRunStep stepOutput = new ScenarioRunStep();
        stepOutput.setRunId(runId);
        stepOutput.setNodeId("node2");
        stepOutput.setNodeType("output");

        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(OffsetDateTime.now());
        run.setSteps(Arrays.asList(stepInput, stepOutput));

        ScenarioRunStep step1 = new ScenarioRunStep();
        step1.setRunId(runId);
        step1.setNodeId("node1");
        ScenarioRunStep step2 = new ScenarioRunStep();
        step2.setRunId(runId);
        step2.setNodeId("node2");
        List<ScenarioRunStep> stepResponses = List.of(step1, step2);

        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any())).thenReturn(stepResponses);

        // When
        ResponseEntity<Resource> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.extractToDocx(runId, true));

        // Then
        assertNotNull(result);
        assertEquals(200, result.getStatusCode().value());
    }

    @Test
    void testExtractToDocx_withScenarioNotFound_throwsException() {
        // Given
        UUID runId = UUID.randomUUID();

        when(scenarioRunRepository.findById(runId)).thenReturn(Optional.of(new ScenarioRun()));

        // When & Then
        var userIdStr = userId.toString();
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.extractToDocx(runId, true)));
    }

    // -------------------------------------------------------------------------
    // Tests for runScenario method
    // -------------------------------------------------------------------------

    @Test
    void testRunScenario_withStepModeEnabled_success() {
        UUID runId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(OffsetDateTime.now());
        // Given
        when(scenarioRepository.findById(scenarioId))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.save(any())).thenReturn(run);
        when(scenarioEngine.executeScenario(any(), any(), any()))
                .thenReturn(Flux.empty());

        // When
        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.runScenario(scenarioId, true));

        // Then
        assertNotNull(result);
    }

    @Test
    void testRunScenario_withStepModeDisabled_success() {
        // Given
        when(scenarioRepository.findById(scenarioId))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any()))
                .thenReturn(Flux.empty());

        // When
        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.runScenario(scenarioId, false));

        // Then
        assertNotNull(result);
    }

    @Test
    void testRunScenario_withNullStepMode_success() {
        // Given
        when(scenarioRepository.findById(scenarioId))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));
        when(scenarioEngine.executeScenario(any(), any(), any()))
                .thenReturn(Flux.empty());

        // When
        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.runScenario(scenarioId, null));

        // Then
        assertNotNull(result);
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRunScenario_withScenarioNotFound_throwsException() {
        // Given
        UUID nonExistentId = UUID.randomUUID();
        when(scenarioRepository.findById(nonExistentId))
                .thenReturn(Optional.empty());

        // When & Then
        assertThrows(ResponseStatusException.class, () ->
                CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.runScenario(nonExistentId, false)));
    }

    // -------------------------------------------------------------------------
    // Tests for saveScenarioRun method
    // -------------------------------------------------------------------------

    @Test
    void testSaveScenarioRun_success() {
        // Given
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(scenarioId);
        run.setStatus("pending");
        run.setStartedAt(OffsetDateTime.now());

        ScenarioRun savedRun = new ScenarioRun();
        savedRun.setId(UUID.randomUUID());
        savedRun.setScenarioId(scenarioId);
        savedRun.setStatus("pending");
        savedRun.setStartedAt(OffsetDateTime.now());

        when(scenarioRunRepository.save(any())).thenReturn(savedRun);

        // When
        ScenarioRun result = scenarioService.saveScenarioRun(run);

        // Then
        assertNotNull(result);
        assertNotNull(result.getId());
        assertEquals(scenarioId, result.getScenarioId());
        verify(scenarioRunRepository).save(run);
    }

    @Test
    void testSaveScenarioRun_withMinimalData_success() {
        // Given
        ScenarioRun run = new ScenarioRun();
        // Only scenarioId is set, other fields use defaults

        ScenarioRun savedRun = new ScenarioRun();
        savedRun.setId(UUID.randomUUID());
        savedRun.setScenarioId(scenarioId);

        when(scenarioRunRepository.save(any())).thenReturn(savedRun);

        // When
        ScenarioRun result = scenarioService.saveScenarioRun(run);

        // Then
        assertNotNull(result);
        assertNotNull(result.getId());
    }

    @Test
    void testGetScenarios() {
        var rating = new ScenarioRating();
        rating.setScenarioId(scenario.getId());
        rating.setRating(5);
        when(scenarioRepository.findAllByUserIdOrSharedTrueOrderByUpdatedAtDesc(userId.toString()))
                .thenReturn(List.of(scenario));
        when(scenarioRatingRepository.findByScenarioIdIn(List.of(scenarioId)))
                .thenReturn(List.of(rating));
        List<ScenarioResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarios());

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Scenario", result.get(0).name());
    }

    @Test
    void testGetScenario_withExistingScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));

        ScenarioDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenario(scenarioId));

        assertNotNull(result);
        assertEquals("Test Scenario", result.name());
    }

    @Test
    void testGetScenario_withNonExistingScenario_throwsNotFoundException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.getScenario(uuid)));
    }

    @Test
    void testCreateScenario() {
        GraphDataDto graphData = new GraphDataDto(
                List.of(),
                List.of()
        );

        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "New Scenario", "Description", graphData));

        assertNotNull(result);
        verify(scenarioRepository).save(scenarioCaptor.capture());
        assertEquals("New Scenario", scenarioCaptor.getValue().getName());
        assertEquals("Description", scenarioCaptor.getValue().getDescription());
    }

    @Test
    void testUpdateScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        GraphDataDto graphData = new GraphDataDto(
                List.of(),
                List.of()
        );

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, "Updated Scenario", "Updated description", graphData));

        assertNotNull(result);
        assertEquals("Updated Scenario", scenario.getName());
    }

    @Test
    void testUpdateScenario_withNullGraphData() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, "Updated Scenario", null, null));

        assertNotNull(result);
    }

    @Test
    void testDuplicateScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenAnswer(inv -> {
            Scenario s = inv.getArgument(0);
            s.setId(UUID.randomUUID());
            return s;
        });

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.duplicateScenario(scenarioId));

        assertNotNull(result);
        assertEquals("Test Scenario (копия)", result.name());
    }

    @Test
    void testDeleteScenario() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        doNothing().when(scenarioRepository).delete(any());

        assertDoesNotThrow(() -> CurrentUserHolder.withUser(userId.toString(),
                () -> {
                    scenarioService.deleteScenario(scenarioId);
                    return null;
                }));

        verify(scenarioRepository).delete(scenario);
    }

    @Test
    void testGetScenarioRuns() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenario.getId());
        run.setStatus("completed");
        run.setStartedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(scenario.getId()))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(any()))
                .thenReturn(List.of(run));

        List<ScenarioRunResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("completed", result.get(0).status());
    }

    @Test
    void testGetScenarioRun_withSteps() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        run.setStartedAt(OffsetDateTime.now());

        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(run.getId());
        step.setNodeId("node1");
        step.setNodeType("input");
        when(scenarioRepository.findById(any()))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any()))
                .thenReturn(Optional.of(run));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any()))
                .thenReturn(List.of(step));

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(run.getId()));

        assertNotNull(result);
        assertEquals(1, result.steps().size());
    }

    @Test
    void testGetScenarioRun_withNonExistingRun_throwsException() {
        lenient().when(scenarioRepository.findById(scenario.getId()))
                .thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any()))
                .thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.getScenarioRun(uuid)));
    }

    // -------------------------------------------------------------------------
    // Edge cases for CRUD operations
    // -------------------------------------------------------------------------

    @Test
    void testCreateScenario_withNullGraphData() {
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "New", "Desc", null));

        assertNotNull(result);
        verify(scenarioRepository).save(scenarioCaptor.capture());
        assertEquals("New", scenarioCaptor.getValue().getName());
        assertEquals("Desc", scenarioCaptor.getValue().getDescription());
    }

    @Test
    void testCreateScenario_withEmptyName() {
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "", "Desc", new GraphDataDto(List.of(), List.of())));

        assertNotNull(result);
    }

    @Test
    void testCreateScenario_withDuplicateName() {
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.createScenario(
                        "Test Scenario", "Desc", new GraphDataDto(List.of(), List.of())));

        assertNotNull(result);
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testUpdateScenario_withNonExistingScenario_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.updateScenario(
                                scenarioId, "Updated", "Updated", new GraphDataDto(List.of(), List.of()))));
    }

    @Test
    void testUpdateScenario_withOnlyNameChange() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRepository.save(any())).thenReturn(scenario);

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.updateScenario(
                        scenarioId, "Only Name", null, null));

        assertNotNull(result);
        assertEquals("Only Name", result.name());
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testDuplicateScenario_withNonExistingScenario_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.duplicateScenario(scenarioId)));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testDeleteScenario_withNonExistingScenario_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> {
                            scenarioService.deleteScenario(scenarioId);
                            return null;
                        }));
    }

    // -------------------------------------------------------------------------
    // Scenario run edge cases
    // -------------------------------------------------------------------------

    @Test
    void testGetScenarioRuns_withEmptyResults() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(any()))
                .thenReturn(List.of());

        List<ScenarioRunResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertNotNull(result);
        assertEquals(0, result.size());
    }

    @Test
    void testGetScenarioRuns_withMultipleRuns() {
        ScenarioRun run1 = new ScenarioRun();
        run1.setId(UUID.randomUUID());
        run1.setScenarioId(scenarioId);
        run1.setStatus("completed");
        run1.setStartedAt(OffsetDateTime.now());

        ScenarioRun run2 = new ScenarioRun();
        run2.setId(UUID.randomUUID());
        run2.setScenarioId(scenarioId);
        run2.setStatus("failed");
        run2.setStartedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(any()))
                .thenReturn(List.of(run1, run2));

        List<ScenarioRunResponse> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRuns(scenarioId));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("completed", result.get(0).status());
        assertEquals("failed", result.get(1).status());
    }

    @Test
    void testGetScenarioRuns_withScenarioNotFound_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userIdStr,
                        () -> scenarioService.getScenarioRuns(scenarioId)));
    }

    @Test
    void testGetScenarioRun_withMultipleSteps() {
        ScenarioRun run = new ScenarioRun();
        run.setId(UUID.randomUUID());
        run.setScenarioId(scenarioId);
        run.setStatus("completed");
        run.setStartedAt(OffsetDateTime.now());

        ScenarioRunStep step1 = new ScenarioRunStep();
        step1.setRunId(run.getId());
        step1.setNodeId("node1");
        step1.setNodeType("input");

        ScenarioRunStep step2 = new ScenarioRunStep();
        step2.setRunId(run.getId());
        step2.setNodeId("node2");
        step2.setNodeType("processing");

        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(run));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(any()))
                .thenReturn(List.of(step1, step2));

        ScenarioRunDetailResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getScenarioRun(run.getId()));

        assertNotNull(result);
        assertEquals(2, result.steps().size());
        assertEquals("input", result.steps().get(0).nodeType());
        assertEquals("processing", result.steps().get(1).nodeType());
    }

    // -------------------------------------------------------------------------
    // Versioning tests
    // -------------------------------------------------------------------------

    @Test
    @SuppressWarnings("java:S5778")
    void testGetVersions_withScenarioNotFound_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.getVersions(scenarioId)));
    }

    @Test
    void testGetVersions_withMultipleVersions() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdOrderByVersionNoDesc(any()))
                .thenReturn(List.of());

        List<Map<String, Object>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.getVersions(scenarioId));

        assertNotNull(result);
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRestoreVersion_withNonExistingVersion_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdAndVersionNo(any(), anyInt()))
                .thenReturn(Optional.empty());

        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.restoreVersion(scenarioId, 99)));
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testRestoreVersion_withScenarioNotFound_throwsException() {
        when(scenarioRepository.findById(any())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.restoreVersion(scenarioId, 1)));
    }

    @Test
    void testRestoreVersion_success() {
        int versionNo = 2;
        String versionName = "v2";
        String versionDescription = "Version 2 description";
        Map<String, Object> versionGraphData = Map.of("nodes", List.of(), "edges", List.of());

        ScenarioVersion version = new ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenarioId);
        version.setVersionNo(versionNo);
        version.setName(versionName);
        version.setDescription(versionDescription);
        version.setGraphData(versionGraphData);
        version.setCreatedAt(OffsetDateTime.now());

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdAndVersionNo(scenarioId, versionNo))
                .thenReturn(Optional.of(version));
        // snapshotVersion: no existing version → next = 1 (it doesn't matter for restore)
        when(scenarioVersionRepository.findFirstByScenarioIdOrderByVersionNoDesc(scenarioId))
                .thenReturn(Optional.empty());
        when(scenarioRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        ScenarioResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.restoreVersion(
                        scenarioId, versionNo));

        assertNotNull(result);
        assertEquals(versionName, scenario.getName());
        assertEquals(versionDescription, scenario.getDescription());
        assertEquals(versionGraphData, scenario.getGraphData());

        verify(scenarioVersionRepository).save(any(ScenarioVersion.class));
        verify(scenarioRepository).save(scenarioCaptor.capture());
        assertEquals(scenarioId, scenarioCaptor.getValue().getId());
    }

    @Test
    void testRestoreVersion_savesSnapshotBeforeRestore() {
        int versionNo = 1;

        ScenarioVersion version = new ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenarioId);
        version.setVersionNo(versionNo);
        version.setName("v1");
        version.setGraphData(Map.of("key", "data"));

        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));
        when(scenarioVersionRepository.findByScenarioIdAndVersionNo(scenarioId, versionNo))
                .thenReturn(Optional.of(version));
        // snapshotVersion: no existing version → next version = 1
        when(scenarioVersionRepository.findFirstByScenarioIdOrderByVersionNoDesc(scenarioId))
                .thenReturn(Optional.empty());
        when(scenarioRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.restoreVersion(scenarioId, versionNo));

        // restoreVersion calls snapshotVersion internally — verify a snapshot was saved
        verify(scenarioVersionRepository).save(any(ScenarioVersion.class));
    }

    @Test
    void testResumeScenarioRun_withExistingRun_success() {
        ScenarioRun oldRun = new ScenarioRun();
        oldRun.setId(UUID.randomUUID());
        oldRun.setScenarioId(scenarioId);
        oldRun.setStatus("failed");
        oldRun.setStartedAt(OffsetDateTime.now());

        when(scenarioRunRepository.findById(any())).thenReturn(Optional.of(oldRun));
        when(scenarioRepository.findById(any())).thenReturn(Optional.of(scenario));
        when(scenarioEngine.resumeScenario(any(), any(), any(), any())).thenReturn(Flux.empty());

        Flux<ServerSentEvent<Map<String, Object>>> result = CurrentUserHolder.withUser(userId.toString(),
                () -> scenarioService.resumeScenarioRun(
                        oldRun.getId()));

        assertNotNull(result);
    }

    @Test
    @SuppressWarnings("java:S5778")
    void testResumeScenarioRun_withNonExistingRun_throwsException() {
        when(scenarioRunRepository.findById(any())).thenReturn(Optional.empty());
        assertThrows(IllegalArgumentException.class,
                () -> CurrentUserHolder.withUser(userId.toString(),
                        () -> scenarioService.resumeScenarioRun(UUID.randomUUID())));
    }
}
