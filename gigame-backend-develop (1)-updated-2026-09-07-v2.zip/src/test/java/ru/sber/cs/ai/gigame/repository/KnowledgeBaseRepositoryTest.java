package ru.sber.cs.ai.gigame.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.jdbc.Sql;
import ru.sber.cs.ai.gigame.config.TestDataSourceConfig;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
@TestPropertySource(properties = {
        "spring.liquibase.enabled=false",
        "spring.jpa.hibernate.ddl-auto=create-drop"
}, locations = "classpath:test-application.yaml")
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Import(TestDataSourceConfig.class)
@Sql(scripts = "classpath:db/test-schema.sql")
class KnowledgeBaseRepositoryTest {

    @Autowired
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Test
    void testFindById_returnsKnowledgeBase() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("Test KB");
        kb.setUserId("user1");
        knowledgeBaseRepository.save(kb);

        KnowledgeBase found = knowledgeBaseRepository.findById(kb.getId()).orElse(null);

        assertNotNull(found);
        assertEquals("Test KB", kb.getName());
    }

    @Test
    void testFindAllByUserIdOrderByUpdatedAtDesc_returnsSortedKBs() {
        String userId = "user1";
        KnowledgeBase kb1 = new KnowledgeBase();
        kb1.setUserId(userId);
        kb1.setName("First KB");
        knowledgeBaseRepository.save(kb1);

        KnowledgeBase kb2 = new KnowledgeBase();
        kb2.setUserId(userId);
        kb2.setName("Second KB");
        knowledgeBaseRepository.save(kb2);

        List<KnowledgeBase> result = knowledgeBaseRepository.findAllByUserIdOrderByUpdatedAtDesc(userId);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Second KB", result.get(0).getName());
        assertEquals("First KB", result.get(1).getName());
    }

    @Test
    void testFindByUserIdAndNameContainingIgnoreCaseOrderByUpdatedAtDesc() {
        String userId = "user1";
        KnowledgeBase kb1 = new KnowledgeBase();
        kb1.setUserId(userId);
        kb1.setName("Project Alpha");
        knowledgeBaseRepository.save(kb1);

        KnowledgeBase kb2 = new KnowledgeBase();
        kb2.setUserId(userId);
        kb2.setName("Project Beta");
        knowledgeBaseRepository.save(kb2);

        KnowledgeBase kb3 = new KnowledgeBase();
        kb3.setUserId(userId);
        kb3.setName("Other Topic");
        knowledgeBaseRepository.save(kb3);

        List<KnowledgeBase> result = knowledgeBaseRepository.findByUserIdAndNameContainingIgnoreCaseOrderByUpdatedAtDesc(
                userId, "project");

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Project Beta", result.get(0).getName());
        assertEquals("Project Alpha", result.get(1).getName());
    }

    @Test
    void testFindByUserId_returnsEmptyList_whenNoKBs() {
        List<KnowledgeBase> result = knowledgeBaseRepository.findAllByUserIdOrderByUpdatedAtDesc("nonexistent");

        assertTrue(result.isEmpty());
    }

    @Test
    void testSaveAndDelete() {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setName("To Delete");
        kb.setUserId("user1");

        KnowledgeBase saved = knowledgeBaseRepository.save(kb);
        assertNotNull(saved.getId());

        knowledgeBaseRepository.delete(saved);
        assertFalse(knowledgeBaseRepository.findById(saved.getId()).isPresent());
    }
}
