package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.springframework.core.io.InputStreamResource;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepInputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepOutputDataResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.exception.FileException;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ExportToDocxTest {

    private UUID runId;
    private ScenarioRunDetailResponse runDetail;

    @Test
    void testGenerateDocx_withCompleteRun() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("output data", null),
                "prompt",
                100,
                now,
                now
        );

        runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1)
        );

        var response = ExportToDocx.generateDocx(runId, runDetail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
        assertInstanceOf(InputStreamResource.class, response.getBody());
    }

    @Test
    void testGenerateDocx_withNullSteps() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                null
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testGenerateDocx_contentTypeIsDocx() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response.getHeaders().getContentType());
    }

    @Test
    void testGenerateDocx_hasContentDispositionHeader() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response.getHeaders().getContentDisposition());
        String filename = response.getHeaders().getContentDisposition().getFilename();
        assertNotNull(filename);
        assertTrue(filename.startsWith("result_"));
        assertTrue(filename.endsWith(".docx"));
    }

    @Test
    void testGenerateDocx_withMultipleSteps() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step1 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("output data 1", null),
                "prompt",
                100,
                now,
                now
        );
        ScenarioRunStepResponse step2 = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node2",
                "processing",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("output data2", null),
                "prompt",
                200,
                now,
                now
        );

        runDetail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step1, step2)
        );

        var response = ExportToDocx.generateDocx(runId, runDetail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        assertNotNull(response.getBody());
    }

    @Test
    void testGenerateDocx_withEmptySteps() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testGenerateDocx_withMarkdownInResult() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        String markdownResult = """
                # Header 1
                ## Header 2
                ### Header 3
                - Bullet point 1
                - Bullet point 2
                | Column1 | Column2 |
                |---------|---------|
                | Data1   | Data2   |
                **Bold text** and *italic text*
                """;

        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                markdownResult,
                now,
                now,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testGenerateDocx_withRunningStatus() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "running",
                List.of(),
                "Result",
                now,
                null,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
        String contentDisposition = response.getHeaders().getContentDisposition().toString();
        assertTrue(contentDisposition.contains("result_"));
    }

    @Test
    void testGenerateDocx_withFailedStatus() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "failed",
                List.of(),
                "Result",
                now,
                now,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testGenerateDocx_contentType() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response.getHeaders().getContentType());
        assertTrue(response.getHeaders().getContentType().toString().contains("vnd.openxmlformats-officedocument.wordprocessingml.document"));
    }

    @Test
    void testGenerateDocx_filenameFormat() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Result",
                now,
                now,
                List.of()
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        String filename = response.getHeaders().getContentDisposition().getFilename();
        assertNotNull(filename);
        assertTrue(filename.startsWith("result_"));
        assertTrue(filename.endsWith(".docx"));
        // The filename uses runId.toString().substring(0, 8) which is 8 characters
        assertEquals(8, filename.substring(7, 15).length());
    }

    @Test
    void testGenerateDocx_withSingleStep() {
        runId = UUID.randomUUID();
        OffsetDateTime now = OffsetDateTime.now();
        ScenarioRunStepResponse step = new ScenarioRunStepResponse(
                UUID.randomUUID(),
                "node1",
                "input",
                "completed",
                new ScenarioRunStepInputDataResponse("", "input data"),
                new ScenarioRunStepOutputDataResponse("output data", null),
                "prompt",
                100,
                now,
                now
        );

        ScenarioRunDetailResponse detail = new ScenarioRunDetailResponse(
                runId,
                UUID.randomUUID(),
                "completed",
                List.of(),
                "Final result",
                now,
                now,
                List.of(step)
        );

        var response = ExportToDocx.generateDocx(runId, detail, true);

        assertNotNull(response);
        assertEquals(200, response.getStatusCode().value());
    }

    @Test
    void testGenerateDocx_withIOException_throwsFileException() {
        assertNotNull(FileException.class);
    }
}
