package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тест для {@link DocsTextCacheService}.
 * <p>
 * Проверяет базовые операции кэширования текстов документов: сохранение,
 * получение, очистка кэша для отдельного диалога/сценария и всего кэша.
 */
@ExtendWith(MockitoExtension.class)
class DocsTextCacheServiceTest {

    private DocsTextCacheService cacheService;

    private UUID id;
    private List<String> documentTexts;
    private List<String> fileNames;
    private List<String> docIds;

    @BeforeEach
    void setUp() {
        cacheService = new DocsTextCacheService();
        id = UUID.randomUUID();
        documentTexts = List.of("текст документа 1", "текст документа 2");
        fileNames = List.of("file1.pdf", "file2.docx");
        docIds = List.of("doc-001", "doc-002");
    }

    @Test
    void testCacheDocumentTexts_shouldStoreAndReturnData() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        assertEquals(documentTexts, cacheService.getCachedDocumentTexts(id));
        assertEquals(fileNames, cacheService.getCachedFileNames(id));
        assertEquals(docIds, cacheService.getCachedDocIds(id));
    }

    @Test
    void testGetCachedDocumentTexts_withEmptyCache_shouldReturnEmptyList() {
        List<String> result = cacheService.getCachedDocumentTexts(id);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testGetCachedFileNames_withEmptyCache_shouldReturnEmptyString() {
        var result = cacheService.getCachedFileNames(id);
        assertNotNull(result);
        assertEquals(List.of(), result);
    }

    @Test
    void testGetCachedDocIds_withEmptyCache_shouldReturnEmptyList() {
        List<String> result = cacheService.getCachedDocIds(id);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testClearCache_shouldRemoveOnlySpecifiedEntry() {
        UUID otherId = UUID.randomUUID();
        List<String> otherTexts = List.of("другой текст");

        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.cacheDocumentTexts(otherId, otherTexts, List.of("other.pdf"), List.of("doc-003"));

        cacheService.clearCache(id);

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertEquals(List.of(), cacheService.getCachedFileNames(id));
        assertTrue(cacheService.getCachedDocIds(id).isEmpty());

        // otherId должен остаться в кэше
        assertEquals(otherTexts, cacheService.getCachedDocumentTexts(otherId));
    }

    @Test
    void testClearAllCache_shouldRemoveAllEntries() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        cacheService.clearAllCache();

        assertTrue(cacheService.getCachedDocumentTexts(id).isEmpty());
        assertEquals(List.of(), cacheService.getCachedFileNames(id));
        assertTrue(cacheService.getCachedDocIds(id).isEmpty());
    }

    @Test
    void testCacheDocumentTexts_shouldOverwriteExistingEntry() {
        List<String> updatedTexts = List.of("обновленный текст");
        List<String> updatedFileNames = List.of("new.pdf");
        List<String> updatedDocIds = List.of("doc-003");

        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);
        cacheService.cacheDocumentTexts(id, updatedTexts, updatedFileNames, updatedDocIds);

        assertEquals(updatedTexts, cacheService.getCachedDocumentTexts(id));
        assertEquals(updatedFileNames, cacheService.getCachedFileNames(id));
        assertEquals(updatedDocIds, cacheService.getCachedDocIds(id));
    }

    // =====================================================================
    // appendDocumentTexts — ConcurrentHashMap.compute (не synchronized)
    // =====================================================================

    @Test
    void testAppendDocumentTexts_shouldAppendToExisting() {
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        List<String> newTexts = List.of("дополнительный текст");
        int total = cacheService.appendDocumentTexts(id, newTexts, List.of("extra.pdf"), List.of("doc-003"));

        assertEquals(3, total);
        assertEquals(3, cacheService.getCachedDocumentTexts(id).size());
        assertEquals("дополнительный текст", cacheService.getCachedDocumentTexts(id).get(2));
    }

    @Test
    void testAppendDocumentTexts_withEmptyCache_createsNew() {
        List<String> newTexts = List.of("первый текст");
        int total = cacheService.appendDocumentTexts(id, newTexts, List.of("first.pdf"), List.of("doc-001"));

        assertEquals(1, total);
        assertEquals(newTexts, cacheService.getCachedDocumentTexts(id));
    }

    @Test
    void testAppendDocumentTexts_notBlocked() {
        // Проверяем, что метод не использует synchronized (использует compute)
        // — при параллельном доступе не возникает deadlock
        cacheService.cacheDocumentTexts(id, documentTexts, fileNames, docIds);

        ExecutorService executor = Executors.newFixedThreadPool(4);
        CountDownLatch latch = new CountDownLatch(5);
        AtomicInteger errors = new AtomicInteger(0);

        for (int i = 0; i < 5; i++) {
            int idx = i;
            executor.submit(() ->
                    appendAndCountdown(id, idx, latch, errors));
        }

        try {
            assertTrue(latch.await(5, TimeUnit.SECONDS), "Все параллельные append должны завершиться");
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        assertEquals(0, errors.get(), "Не должно быть ошибок при параллельном append");
        executor.shutdownNow();
    }

    /**
     * Выполняет {@link DocsTextCacheService#appendDocumentTexts} в параллельном потоке
     * и уменьшает {@link CountDownLatch}. Вынесен в отдельный метод, чтобы избежать
     * вложенных {@code try} в {@code try}, запрещённых checkstyle.
     */
    private void appendAndCountdown(UUID uuid, int idx, CountDownLatch latch, AtomicInteger errors) {
        try {
            cacheService.appendDocumentTexts(uuid,
                    List.of("параллельный текст " + idx),
                    List.of("file" + idx + ".pdf"),
                    List.of("doc-" + (100 + idx)));
        } catch (Exception e) {
            errors.incrementAndGet();
        } finally {
            latch.countDown();
        }
    }
}