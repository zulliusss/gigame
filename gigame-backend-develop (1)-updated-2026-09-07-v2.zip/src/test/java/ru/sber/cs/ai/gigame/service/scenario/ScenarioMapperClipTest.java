package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;

import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты усечения строковых полей шага в подробном отчёте прогона: корп. прокси
 * валидирует ответ по схеме с потолком 500 000 символов на поле, и больший
 * ответ блокируется целиком — поля режутся при отдаче с явной пометкой.
 */
class ScenarioMapperClipTest {

    private static final int LIMIT = 200_000;

    private static ScenarioRunStep step(String result, String documentsText) {
        ScenarioRunStep step = new ScenarioRunStep();
        step.setId(UUID.randomUUID());
        step.setNodeId("h1");
        step.setNodeType("input");
        step.setStatus("completed");
        step.setOutputData(Map.of("result", result));
        step.setInputData(Map.of("documents_text", documentsText));
        return step;
    }

    @Test
    void longFieldsAreClippedWithMarker() {
        String huge = "х".repeat(LIMIT + 100);

        ScenarioRunStepResponse response = ScenarioMapper.toStepResponse(step(huge, huge));

        String result = String.valueOf(response.outputData().result());
        assertTrue(result.length() < huge.length());
        assertTrue(result.contains("показаны первые " + LIMIT));
        String documents = String.valueOf(response.inputData().documentsText());
        assertTrue(documents.contains("показаны первые " + LIMIT));
    }

    @Test
    void shortFieldsPassUnchanged() {
        ScenarioRunStepResponse response =
                ScenarioMapper.toStepResponse(step("короткий результат", "короткий вход"));

        assertEquals("короткий результат", response.outputData().result());
        assertEquals("короткий вход", response.inputData().documentsText());
    }
}
