package ru.sber.cs.ai.gigame.model;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class EmbeddingTest {

    @Test
    void testEmbeddingDefaultValues() {
        Embedding embedding = new Embedding();
        assertNull(embedding.getId());
        assertNull(embedding.getCollectionType());
        assertNull(embedding.getCollectionId());
        assertNull(embedding.getSourceDocumentId());
        assertNull(embedding.getChunkIndex());
        assertNull(embedding.getChunkText());
        assertNull(embedding.getVector());
    }

    @Test
    void testEmbeddingWithAllFields() {
        UUID id = UUID.randomUUID();
        UUID collId = UUID.randomUUID();
        UUID sourceDocId = UUID.randomUUID();
        float[] vector = new float[1024];
        for (int i = 0; i < 1024; i++) {
            vector[i] = (float) Math.random();
        }

        Embedding embedding = new Embedding();
        embedding.setId(id);
        embedding.setCollectionType("doc");
        embedding.setCollectionId(collId);
        embedding.setSourceDocumentId(sourceDocId);
        embedding.setChunkIndex(5);
        embedding.setChunkText("Test chunk text");
        embedding.setVector(vector);

        assertEquals(id, embedding.getId());
        assertEquals("doc", embedding.getCollectionType());
        assertEquals(collId, embedding.getCollectionId());
        assertEquals(sourceDocId, embedding.getSourceDocumentId());
        assertEquals(Integer.valueOf(5), embedding.getChunkIndex());
        assertEquals("Test chunk text", embedding.getChunkText());
        assertArrayEquals(vector, embedding.getVector(), 0.001f);
    }

    @Test
    void testEmbeddingWithKBType() {
        Embedding embedding = new Embedding();
        embedding.setCollectionType("kb");
        embedding.setCollectionId(UUID.randomUUID());

        assertEquals("kb", embedding.getCollectionType());
    }

    @Test
    void testEmbeddingNullSourceDocumentId() {
        Embedding embedding = new Embedding();
        embedding.setSourceDocumentId(null);

        assertNull(embedding.getSourceDocumentId());
    }

    @Test
    void testEmbeddingVectorLength() {
        float[] vector = new float[1024];
        Embedding embedding = new Embedding();
        embedding.setVector(vector);

        assertEquals(1024, embedding.getVector().length);
    }

    @Test
    void testToString() {
        Embedding embedding = new Embedding();
        String str = embedding.toString();
        assertNotNull(str);
        assertTrue(str.contains("Embedding"));
    }
}
