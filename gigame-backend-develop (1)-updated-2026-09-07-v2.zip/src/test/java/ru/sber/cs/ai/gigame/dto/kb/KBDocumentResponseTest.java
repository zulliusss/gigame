package ru.sber.cs.ai.gigame.dto.kb;

import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class KBDocumentResponseTest {

    @Test
    void testConstruction_withAllFields() {
        var id = UUID.randomUUID();
        var docId = UUID.randomUUID();
        var now = OffsetDateTime.now();
        var dto = new KBDocumentResponse(id, docId, "doc.pdf", "application/pdf",
                2048, 10, "ready", null, now);
        assertEquals(id, dto.id());
        assertEquals(docId, dto.documentId());
        assertEquals("doc.pdf", dto.filename());
        assertEquals("application/pdf", dto.contentType());
        assertEquals(2048, dto.sizeBytes());
        assertEquals(10, dto.chunkCount());
        assertEquals("ready", dto.status());
        assertNull(dto.errorMessage());
        assertEquals(now, dto.createdAt());
    }

    @Test
    void testConstruction_withError() {
        var now = OffsetDateTime.now();
        var dto = new KBDocumentResponse(null, null, "doc.pdf", "text/plain",
                100, 1, "error", "Failed to process", now);
        assertEquals("error", dto.status());
        assertEquals("Failed to process", dto.errorMessage());
    }

    @Test
    void testConstruction_withDefaults() {
        var dto = new KBDocumentResponse(null, null, null, null, 0, 0, null, null, null);
        assertNull(dto.id());
        assertNull(dto.filename());
        assertNull(dto.status());
        assertEquals(0, dto.sizeBytes());
        assertEquals(0, dto.chunkCount());
    }
}