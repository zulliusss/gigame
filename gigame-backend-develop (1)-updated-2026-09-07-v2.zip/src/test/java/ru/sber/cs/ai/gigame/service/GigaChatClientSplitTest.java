package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты вспомогательных методов деления запроса при 422 «context too long»:
 * распознавание ошибки по цепочке причин и суммирование usage двух половин.
 */
class GigaChatClientSplitTest {

    @Test
    void detectsContextTooLongInCauseChain() {
        RuntimeException cause = new RuntimeException(
                "HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 190108\"}");
        GigaChatException wrapped = new GigaChatException("Не удалось выполнить запрос", cause);

        assertTrue(GigaChatClient.isContextTooLong(wrapped));
    }

    @Test
    void ignoresOtherErrors() {
        assertFalse(GigaChatClient.isContextTooLong(
                new RuntimeException("HTTP 429 - Too Many Requests")));
        assertFalse(GigaChatClient.isContextTooLong(new RuntimeException((String) null)));
    }

    @Test
    void mergesUsageBySummingCounters() {
        Map<String, Object> merged = GigaChatClient.mergeUsage(
                Map.of("prompt_tokens", 100, "completion_tokens", 20),
                Map.of("prompt_tokens", 50, "completion_tokens", 7));

        assertEquals(150L, merged.get("prompt_tokens"));
        assertEquals(27L, merged.get("completion_tokens"));
    }

    @Test
    void emptyUsageFallsBackToOther() {
        Map<String, Object> usage = Map.of("prompt_tokens", 5);

        assertEquals(usage, GigaChatClient.mergeUsage(Map.of(), usage));
        assertEquals(usage, GigaChatClient.mergeUsage(usage, null));
    }
}
