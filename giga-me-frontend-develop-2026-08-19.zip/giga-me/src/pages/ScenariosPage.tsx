import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  createScenario,
  duplicateScenario,
  getScenarios,
  rateScenario,
  updateScenario,
} from '@/api/scenarios';

/**
 * Pre-made scenario templates covering the most common
 * procurement analysis tasks. Each template uses only the 6
 * core node types: input, processing, loop, switch, if_node, output.
 *
 * Templates that rely on a knowledge base (RAG) leave
 * knowledge_base_id empty — the user must pick their own KB
 * after the scenario is created.
 */
const TEMPLATES = [
  // ─────────────────────────────────────────────────────────────
  // 1. Сравнение коммерческих предложений
  // Loop extracts from each КП → Processing builds table + finds
  // discrepancies across price, terms, completeness, warranty,
  // delivery conditions and hidden exclusions.
  // ─────────────────────────────────────────────────────────────
  {
    name: 'Сравнение КП',
    description:
      'Сводная таблица по КП и поиск расхождений: цены, сроки, комплектность, гарантии, скрытые исключения',
    icon: '📊',
    graph_data: {
      nodes: [
        {
          id: 'node_0',
          type: 'input',
          position: { x: 260, y: 30 },
          data: { label: 'Коммерческие предложения' },
        },
        {
          id: 'node_1',
          type: 'loop',
          position: { x: 260, y: 180 },
          data: {
            label: 'Извлечение параметров КП',
            prompt:
              'Ты анализируешь коммерческое предложение (КП). Извлеки и верни в структурированном виде:\n\n' +
              '1. Поставщик (название, ИНН если есть)\n' +
              '2. Общая стоимость (точная сумма с НДС/без НДС с копейками)\n' +
              '3. Срок поставки / оказания услуг\n' +
              '4. Комплектность — полный перечень позиций с количеством и ценой за единицу\n' +
              '5. Условия оплаты (предоплата, постоплата, рассрочка)\n' +
              '6. Условия поставки / базис (EXW, FCA, DDP и т.д.)\n' +
              '7. Гарантия (срок, условия)\n' +
              '8. СКРЫТЫЕ ИСКЛЮЧЕНИЯ и оговорки — внимательно выдели все условия, которые ограничивают ответственность поставщика или могут привести к удорожанию (франшиза, минимальные партии, исключения из гарантии, условия изменения цены и т.п.)\n' +
              '9. Срок действия КП\n\n' +
              'Ничего не выдумывай. Если какого-то параметра в документе нет — явно напиши "не указано".',
          },
        },
        {
          id: 'node_2',
          type: 'processing',
          position: { x: 260, y: 380 },
          data: {
            label: 'Сводная таблица и расхождения',
            prompt:
              'На основе извлечённых параметров всех КП (результат предыдущего шага) сделай следующее:\n\n' +
              '## 1. Сводная таблица\n' +
              'Составь markdown-таблицу: строки — поставщики, столбцы — цена, срок поставки, комплектность (кратко), условия оплаты, гарантия, ключевые исключения.\n\n' +
              '## 2. Расхождения по цене\n' +
              '- Минимальная и максимальная цена (с указанием поставщиков)\n' +
              '- Разница в рублях и процентах\n' +
              '- Если цены нельзя сравнить напрямую (разная комплектность / с НДС vs без) — явно об этом напиши\n\n' +
              '## 3. Расхождения по срокам\n' +
              '- Самый быстрый и самый долгий срок\n' +
              '- Разница в днях\n\n' +
              '## 4. Расхождения по комплектности\n' +
              '- Какие позиции есть у всех, какие — только у части поставщиков\n' +
              '- Несоответствия в количестве или характеристиках одинаковых позиций\n\n' +
              '## 5. Отличия в условиях поставки и оплаты\n' +
              'Нетипичные или обременительные условия.\n\n' +
              '## 6. ⚠️ Скрытые исключения и риски\n' +
              'Отдельно перечисли все исключения, оговорки, ограничения ответственности, потенциально невыгодные условия. Укажи, у каких поставщиков они обнаружены.\n\n' +
              '## 7. Предварительный ранжир\n' +
              'Ранжируй поставщиков с обоснованием (не только по цене — учитывай комплектность, риски, условия). Прямо укажи, какое КП выглядит наиболее выгодным и почему.',
          },
        },
        {
          id: 'node_3',
          type: 'output',
          position: { x: 260, y: 620 },
          data: { label: 'Отчёт по КП' },
        },
      ],
      edges: [
        { id: 'e0', source: 'node_0', target: 'node_1' },
        { id: 'e1', source: 'node_1', target: 'node_2' },
        { id: 'e2', source: 'node_2', target: 'node_3' },
      ],
    },
  },

  // ─────────────────────────────────────────────────────────────
  // 2. Проверка соответствия требованиям
  // Loop strict-classifies ТЗ vs КП → Switch routes each to its
  // own branch → extracts requirements / offer → merge does the
  // compliance check.
  // ─────────────────────────────────────────────────────────────
  {
    name: 'Соответствие требованиям',
    description:
      'Сопоставление КП с требованиями ТЗ: соответствует / частично / не соответствует, с указанием пробелов',
    icon: '✓',
    graph_data: {
      nodes: [
        {
          id: 'node_0',
          type: 'input',
          position: { x: 400, y: 30 },
          data: { label: 'ТЗ + КП' },
        },
        {
          id: 'node_1',
          type: 'loop',
          position: { x: 400, y: 170 },
          data: {
            label: 'Классификация документов',
            classify_strict: 'true',
            classes: 'ТЗ, КП',
            prompt: '',
          },
        },
        {
          id: 'node_2',
          type: 'switch',
          position: { x: 400, y: 340 },
          data: {
            label: 'Маршрутизация по типу',
            rules: JSON.stringify([
              { value: 'ТЗ', operator: 'contains', label: 'ТЗ' },
              { value: 'КП', operator: 'contains', label: 'КП' },
            ]),
          },
        },
        {
          id: 'node_3',
          type: 'processing',
          position: { x: 150, y: 510 },
          data: {
            label: 'Извлечение требований ТЗ',
            prompt:
              'Ты работаешь с техническим заданием (ТЗ) на закупку. Извлеки все требования в структурированном виде, с нумерацией. Для каждого требования укажи:\n\n' +
              '- Номер и название позиции / раздела\n' +
              '- Точную формулировку требования\n' +
              '- Обязательное (shall) или желательное (should)\n' +
              '- Измеримые параметры (количество, характеристики, сроки)\n\n' +
              'Ничего не добавляй от себя — только то, что явно написано в ТЗ.',
          },
        },
        {
          id: 'node_4',
          type: 'processing',
          position: { x: 650, y: 510 },
          data: {
            label: 'Извлечение предложения КП',
            prompt:
              'Ты работаешь с коммерческим предложением (КП). Извлеки что именно предлагает поставщик:\n\n' +
              '- Поставщик\n' +
              '- Перечень позиций (название, характеристики, количество, цена)\n' +
              '- Сроки поставки\n' +
              '- Условия поставки / оплаты / гарантии\n' +
              '- Все оговорки и ограничения\n\n' +
              'Только факты из документа, без интерпретации.',
          },
        },
        {
          id: 'node_5',
          type: 'processing',
          position: { x: 400, y: 730 },
          data: {
            label: 'Проверка соответствия',
            prompt:
              'Ты — эксперт по закупочной документации. На основе данных из ТЗ и КП (результаты предыдущих шагов) проверь соответствие предложения требованиям.\n\n' +
              'Для КАЖДОГО требования из ТЗ вынеси вердикт:\n' +
              '- ✅ СООТВЕТСТВУЕТ — предложение полностью покрывает требование\n' +
              '- ⚠️ ЧАСТИЧНО СООТВЕТСТВУЕТ — покрывает, но с оговорками или отклонениями (укажи какими)\n' +
              '- ❌ НЕ СООТВЕТСТВУЕТ — не покрывает или противоречит требованию\n' +
              '- ➖ НЕ ПРОВЕРЕНО — данных в КП недостаточно (укажи, что именно нужно уточнить)\n\n' +
              '## Формат ответа\n\n' +
              '### Таблица соответствия\n' +
              '| № | Требование ТЗ | Предложение КП | Статус | Комментарий |\n' +
              '|---|---|---|---|---|\n' +
              '| 1 | ... | ... | ✅/⚠️/❌/➖ | ... |\n\n' +
              '### Итоги\n' +
              '- Всего требований: N\n' +
              '- Соответствует: N (N%)\n' +
              '- Частично: N\n' +
              '- Не соответствует: N\n' +
              '- Не проверено: N\n\n' +
              '### Критические пробелы\n' +
              'Перечень требований со статусом ❌ — эти позиции блокируют закупку.\n\n' +
              '### Рекомендация\n' +
              'Готово к заключению / Требует доработки КП / Отклонить — с обоснованием.',
          },
        },
        {
          id: 'node_6',
          type: 'output',
          position: { x: 400, y: 950 },
          data: { label: 'Заключение' },
        },
      ],
      edges: [
        { id: 'e0', source: 'node_0', target: 'node_1' },
        { id: 'e1', source: 'node_1', target: 'node_2' },
        { id: 'e2', source: 'node_2', target: 'node_3', data: { label: 'ТЗ' } },
        { id: 'e3', source: 'node_2', target: 'node_4', data: { label: 'КП' } },
        { id: 'e4', source: 'node_3', target: 'node_5' },
        { id: 'e5', source: 'node_4', target: 'node_5' },
        { id: 'e6', source: 'node_5', target: 'node_6' },
      ],
    },
  },

  // ─────────────────────────────────────────────────────────────
  // 3. Сравнение с историческими закупками (RAG)
  // Processing extracts key params of current deal → Processing
  // with knowledge_base_id (historical purchases KB) compares
  // against past deals via similarity search.
  // ─────────────────────────────────────────────────────────────
  {
    name: 'Сравнение с историей (RAG)',
    description:
      'Сопоставление с прошлыми закупками из базы знаний: нетипичные цены, сроки, условия. Нужно указать БЗ.',
    icon: '📚',
    graph_data: {
      nodes: [
        {
          id: 'node_0',
          type: 'input',
          position: { x: 260, y: 30 },
          data: { label: 'Документы сделки' },
        },
        {
          id: 'node_1',
          type: 'processing',
          position: { x: 260, y: 180 },
          data: {
            label: 'Параметры текущей сделки',
            prompt:
              'Извлеки ключевые параметры текущей закупки из предоставленных документов:\n\n' +
              '- Предмет закупки (что покупается)\n' +
              '- Категория / ОКПД2 (если указано)\n' +
              '- Объём / количество\n' +
              '- Цена (общая и за единицу)\n' +
              '- Поставщик\n' +
              '- Срок поставки\n' +
              '- Регион / площадка\n' +
              '- Особые условия\n\n' +
              'Верни в структурированном виде. Это будет использовано как поисковый запрос к базе исторических закупок.',
          },
        },
        {
          id: 'node_2',
          type: 'processing',
          position: { x: 260, y: 380 },
          data: {
            label: 'Сравнение с историей',
            knowledge_base_id: '',
            prompt:
              '🚨 ПРАВИЛА ПЕРЕД ОТВЕТОМ:\n' +
              '1. Ниже ПО СПЕЦИАЛЬНЫМ МАРКЕРАМ могут быть переданы «Релевантные фрагменты из базы знаний» — это реальные данные по прошлым сделкам.\n' +
              '2. Если секции «Релевантные фрагменты из базы знаний» ниже НЕТ — значит, база знаний НЕ подключена к узлу. В этом случае твой ответ должен быть ТОЛЬКО:\n' +
              '   «⚠️ База знаний не подключена к узлу «Сравнение с историей». Сравнение невозможно. Настройте узел: выберите базу знаний с историческими закупками в панели конфигурации узла.»\n' +
              '   НЕ придумывай никаких аналогов, цен, поставщиков, номеров сделок. НЕ используй свои общие знания о рынке.\n' +
              '3. Если секция есть, но в ней 0 фрагментов, или в её фрагментах нет подходящих аналогов — честно напиши: «В базе знаний не найдено релевантных аналогов для данной закупки» и НЕ выдумывай.\n' +
              '4. Разрешено использовать ТОЛЬКО факты, явно содержащиеся в «Результате предыдущего шага» и во фрагментах базы знаний ниже. Никаких «в среднем по рынку», «обычно такая техника стоит», «по нашим данным» — это ЗАПРЕЩЕНО.\n\n' +
              '━━━━━━━━━━━━━━━━━━━━━━\n\n' +
              'Если правила выше соблюдены и фрагменты базы есть, выполни сравнительный анализ по этой структуре:\n\n' +
              '## 1. Найденные аналоги\n' +
              'Перечисли КАЖДЫЙ фрагмент из базы знаний как отдельную сделку. Для каждой укажи: номер/идентификатор (как в документе), предмет, объём, поставщика, цену, срок, дату. Оцени степень похожести с текущей сделкой: высокая / средняя / низкая.\n' +
              'ВАЖНО: используй ТОЛЬКО цифры и названия, которые явно присутствуют в фрагментах. Если какого-то параметра в фрагменте нет — пиши «не указано».\n\n' +
              '## 2. Цена\n' +
              '- Средняя / минимум / максимум / медиана по найденным фрагментам (только по тем, где цена указана)\n' +
              '- Текущая цена vs средняя: разница в рублях и процентах\n' +
              '- Вердикт: 🟢 типично (отклонение <5%) / 🟡 требует уточнения (5–15%) / 🔴 аномально (>15%)\n\n' +
              '## 3. Сроки поставки\n' +
              '- Диапазон сроков по аналогам\n' +
              '- Текущий срок vs типичный\n' +
              '- Вердикт: 🟢 / 🟡 / 🔴\n\n' +
              '## 4. Поставщик\n' +
              '- Присутствует ли предлагаемый поставщик в найденных фрагментах? (да/нет — только на основании фрагментов, без домыслов)\n' +
              '- Если да — какие цены/сроки давал, были ли задержки или проблемы (из текста фрагментов)\n' +
              '- Если нет в истории — так и напиши «в представленных исторических сделках этот поставщик не встречается»\n\n' +
              '## 5. Особые условия\n' +
              'Сравни условия оплаты/гарантии/прочее в текущей сделке с фрагментами истории.\n\n' +
              '## 6. Выводы и рекомендации\n' +
              '- Что в норме, что требует внимания\n' +
              '- Общий вердикт: 🟢 можно согласовать / 🟡 требуется обсуждение / 🔴 нужны дополнительные обоснования',
          },
        },
        {
          id: 'node_3',
          type: 'output',
          position: { x: 260, y: 620 },
          data: { label: 'Отчёт-сравнение' },
        },
      ],
      edges: [
        { id: 'e0', source: 'node_0', target: 'node_1' },
        { id: 'e1', source: 'node_1', target: 'node_2' },
        { id: 'e2', source: 'node_2', target: 'node_3' },
      ],
    },
  },

  // ─────────────────────────────────────────────────────────────
  // 4. Нормализация каталога и номенклатуры (RAG)
  // Loop extracts items per document → Processing with
  // knowledge_base_id (corporate catalog KB) normalizes names,
  // merges duplicates, maps to canonical entries.
  // ─────────────────────────────────────────────────────────────
  {
    name: 'Нормализация каталога (RAG)',
    description:
      'Приведение наименований к корпоративному справочнику, объединение дублей. Нужно указать БЗ каталога.',
    icon: '🏷️',
    graph_data: {
      nodes: [
        {
          id: 'node_0',
          type: 'input',
          position: { x: 260, y: 30 },
          data: { label: 'Документы с позициями' },
        },
        {
          id: 'node_1',
          type: 'loop',
          position: { x: 260, y: 180 },
          data: {
            label: 'Извлечение позиций',
            prompt:
              'Из этого документа извлеки ВСЕ товарные позиции или услуги. Для каждой:\n\n' +
              '- Исходное наименование (как написано в документе)\n' +
              '- Производитель / бренд (если указан)\n' +
              '- Модель / артикул\n' +
              '- Технические характеристики\n' +
              '- Единица измерения\n' +
              '- Количество\n' +
              '- Цена за единицу\n\n' +
              'Верни в виде пронумерованного списка. Ничего не придумывай, если какого-то поля нет — пиши "не указано".',
          },
        },
        {
          id: 'node_2',
          type: 'processing',
          position: { x: 260, y: 380 },
          data: {
            label: 'Сопоставление с каталогом',
            knowledge_base_id: '',
            prompt:
              '🚨 ПРАВИЛА ПЕРЕД ОТВЕТОМ:\n' +
              '1. Ниже могут быть переданы «Релевантные фрагменты из базы знаний» — это реальные записи корпоративного справочника номенклатуры.\n' +
              '2. Если секции «Релевантные фрагменты из базы знаний» НЕТ — значит, справочник не подключён к узлу. В этом случае твой ответ должен быть ТОЛЬКО:\n' +
              '   «⚠️ Корпоративный справочник не подключён к узлу «Сопоставление с каталогом». Нормализация невозможна. Настройте узел: выберите базу знаний со справочником номенклатуры в панели конфигурации узла.»\n' +
              '   НЕ придумывай коды, артикулы, канонические наименования — даже если ты «знаешь», как они могут выглядеть.\n' +
              '3. Если секция есть, но конкретной позиции в ней нет — пометь её статусом «не найдено в справочнике». НЕ выдумывай коды/артикулы.\n' +
              '4. Разрешены ТОЛЬКО канонические наименования и коды, явно присутствующие во фрагментах справочника ниже.\n\n' +
              '━━━━━━━━━━━━━━━━━━━━━━\n\n' +
              'Если правила выше соблюдены и справочник подключён, выполни для КАЖДОЙ извлечённой позиции:\n\n' +
              '## 1. Сопоставление с каталогом\n' +
              'Найди во фрагментах справочника подходящую каноническую позицию. Укажи:\n' +
              '- Исходное наименование (как в заявке)\n' +
              '- Каноническое наименование из справочника (СТРОГО из фрагментов)\n' +
              '- Код / артикул (СТРОГО из фрагментов)\n' +
              '- Уверенность: высокая (точное совпадение) / средняя (похожее по ключевым параметрам) / низкая (только категория) / нет в справочнике\n\n' +
              '## 2. Объединение дублей\n' +
              'Если несколько исходных позиций ссылаются на один и тот же товар — объедини их:\n' +
              '- Каноническое наименование\n' +
              '- Список исходных написаний\n' +
              '- Суммарное количество\n' +
              '- Разброс цен\n\n' +
              '## 3. Неопознанные позиции\n' +
              'Отдельный список позиций, которых НЕТ в справочнике. Для каждой укажи, какую категорию она напоминает (если видно из фрагментов).\n\n' +
              '## 4. Сводная таблица\n' +
              '| № | Каноническое наименование | Код | Кол-во | Цена ед. | Уверенность | Источники (исходные написания) |\n' +
              '|---|---|---|---|---|---|---|\n\n' +
              '## 5. Итоги\n' +
              '- Всего исходных позиций: N\n' +
              '- Объединено дублей: N\n' +
              '- Сопоставлено со справочником: N (N%)\n' +
              '- Не опознано: N',
          },
        },
        {
          id: 'node_3',
          type: 'output',
          position: { x: 260, y: 620 },
          data: { label: 'Нормализованный список' },
        },
      ],
      edges: [
        { id: 'e0', source: 'node_0', target: 'node_1' },
        { id: 'e1', source: 'node_1', target: 'node_2' },
        { id: 'e2', source: 'node_2', target: 'node_3' },
      ],
    },
  },
];

/** Кликабельные звёзды рейтинга: жёлтые — средний рейтинг, рамка — своя оценка. */
function RatingStars({
  avg,
  my,
  onRate,
}: {
  avg: number | null | undefined;
  my: number | null | undefined;
  onRate: (rating: number) => void;
}) {
  return (
    <span className="inline-flex items-center gap-0.5" title={my ? `Ваша оценка: ${my}` : 'Оценить'}>
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          onClick={(e) => {
            e.stopPropagation();
            onRate(star);
          }}
          className={`text-sm leading-none ${
            (avg ?? 0) >= star - 0.25 ? 'text-yellow-500' : 'text-muted-foreground/40'
          } hover:scale-125 transition-transform`}
        >
          ★
        </button>
      ))}
    </span>
  );
}

export function ScenariosPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: scenarios } = useQuery({
    queryKey: ['scenarios'],
    queryFn: getScenarios,
  });
  const [sharedSearch, setSharedSearch] = useState('');
  const sharedQuery = sharedSearch.trim().toLowerCase();
  const allShared = (scenarios ?? []).filter((s) => s.shared);
  const sharedScenarios = allShared.filter(
    (s) =>
      !sharedQuery ||
      s.name.toLowerCase().includes(sharedQuery) ||
      (s.description ?? '').toLowerCase().includes(sharedQuery),
  );

  const rateMut = useMutation({
    mutationFn: ({ id, rating }: { id: string; rating: number }) => rateScenario(id, rating),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['scenarios'] }),
  });

  const cloneMut = useMutation({
    mutationFn: (id: string) => duplicateScenario(id),
    onSuccess: (s) => {
      queryClient.invalidateQueries({ queryKey: ['scenarios'] });
      navigate(`/scenarios/${s.id}/edit`);
    },
  });

  const createFromTemplateMut = useMutation({
    mutationFn: async (template: typeof TEMPLATES[number]) => {
      const s = await createScenario(template.name);
      await updateScenario(s.id, { graph_data: template.graph_data });
      return s;
    },
    onSuccess: (s) => {
      queryClient.invalidateQueries({ queryKey: ['scenarios'] });
      navigate(`/scenarios/${s.id}/edit`);
    },
  });

  return (
    <div className="flex flex-col items-center justify-start h-full p-8 overflow-y-auto">
      <div className="w-20 h-20 rounded-full bg-[#21a038]/10 flex items-center justify-center mb-6 mt-8">
        <svg
          width="36"
          height="36"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#21a038"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="3" />
          <path d="M12 1v6m0 6v6" />
          <path d="m17.66 6.34-4.24 4.24m-2.84 2.84-4.24 4.24" />
          <path d="M23 12h-6m-6 0H5" />
          <path d="m17.66 17.66-4.24-4.24m-2.84-2.84L6.34 6.34" />
        </svg>
      </div>
      <h1 className="text-xl font-semibold mb-2 text-foreground">Сценарии</h1>
      <p className="text-sm text-muted-foreground mb-8 text-center max-w-md">
        Выберите сценарий в сайдбаре или создайте новый из готового шаблона
      </p>

      {allShared.length > 0 && (
        <div className="w-full max-w-4xl mb-8">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">
            Общие сценарии
          </div>
          <input
            value={sharedSearch}
            onChange={(e) => setSharedSearch(e.target.value)}
            placeholder="Поиск по общим сценариям (название и описание)…"
            className="w-full text-sm border border-border rounded-lg px-3 py-2 bg-background mb-3"
          />
          {sharedScenarios.length === 0 && (
            <div className="text-sm text-muted-foreground text-center py-4">
              По запросу ничего не найдено
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {sharedScenarios.map((s) => (
              <div
                key={s.id}
                onClick={() => navigate(`/scenarios/${s.id}/edit`)}
                className="text-left border border-border rounded-xl p-4 bg-card hover:border-[#21a038]/30 transition-all cursor-pointer"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-foreground mb-1 truncate">
                      {s.name}
                      {s.is_owner && (
                        <span className="ml-2 text-[10px] font-normal text-[#21a038] border border-[#21a038]/40 rounded px-1">
                          мой
                        </span>
                      )}
                    </div>
                    {s.description && (
                      <div className="text-xs text-muted-foreground leading-relaxed line-clamp-2">
                        {s.description}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center justify-between mt-3 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-2">
                    <RatingStars
                      avg={s.rating_avg}
                      my={s.my_rating}
                      onRate={(rating) => rateMut.mutate({ id: s.id, rating })}
                    />
                    <span>
                      {s.rating_avg != null ? s.rating_avg.toFixed(1) : '—'}
                      {` (${s.rating_count ?? 0})`}
                      {s.my_rating != null && (
                        <span className="text-[#21a038]">{` · ваша: ${s.my_rating}`}</span>
                      )}
                    </span>
                    <span title="Количество запусков">▶ {s.runs_count ?? 0}</span>
                  </span>
                  <span className="inline-flex gap-2">
                    {s.is_owner === false && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          cloneMut.mutate(s.id);
                        }}
                        disabled={cloneMut.isPending}
                        title="Чужой общий сценарий нельзя редактировать — клонирование создаёт вашу собственную копию, которую можно менять"
                        className="text-[#21a038] hover:underline disabled:opacity-50"
                      >
                        Клонировать себе
                      </button>
                    )}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="w-full max-w-4xl">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">
          Готовые шаблоны
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {TEMPLATES.map((t) => (
            <button
              key={t.name}
              onClick={() => createFromTemplateMut.mutate(t)}
              disabled={createFromTemplateMut.isPending}
              className="text-left border border-border rounded-xl p-4 hover:bg-accent/50 hover:border-[#21a038]/30 transition-all disabled:opacity-50 bg-card group"
            >
              <div className="flex items-start gap-3">
                <div className="text-2xl flex-shrink-0">{t.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground mb-1 group-hover:text-[#21a038] transition-colors">
                    {t.name}
                  </div>
                  <div className="text-xs text-muted-foreground leading-relaxed">
                    {t.description}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground mt-4 text-center">
          Шаблоны с пометкой <span className="font-medium">(RAG)</span> используют базу знаний —
          после создания выберите нужную БЗ в настройках узла «Обработка»
        </p>
      </div>
    </div>
  );
}
