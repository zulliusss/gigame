import { useEffect, useRef, useState, useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  getConversation,
  updateConversation,
  type ConversationPatch,
  type Message,
  type RagSource,
  type StreamOptions,
  streamMessages,
} from "@/api/chat";
import { MessageBubble } from "./MessageBubble";
import { MessageInput } from "./MessageInput";
import { KBSelector } from "./KBSelector";
import { ChatSettings } from "./ChatSettings";
import { toast } from "@/components/ui/toast";

interface ChatWindowProps {
  conversationId: string;
}

export function ChatWindow({ conversationId }: ChatWindowProps) {
  const queryClient = useQueryClient();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortedRef = useRef(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [streamingSources, setStreamingSources] = useState<RagSource[] | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [lastUsage, setLastUsage] = useState<{ total_tokens: number } | null>(
    null
  );

  const { data: conversation, isLoading } = useQuery({
    queryKey: ["conversation", conversationId],
    queryFn: () => getConversation(conversationId),
  });

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages, streamingContent, scrollToBottom]);

  useEffect(() => {
    setLastUsage(null);
  }, [conversationId]);

  useEffect(() => {
    abortedRef.current = false;
    return () => {
      abortedRef.current = true;
    };
  }, [conversationId]);

  // Обновление настроек диалога (базы знаний, модель, температура)
  const settingsMut = useMutation({
    mutationFn: (patch: ConversationPatch) =>
      updateConversation(conversationId, patch),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["conversation", conversationId],
      });
      queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
    onError: () => toast("Не удалось сохранить настройки диалога", "error"),
  });

  // Общее ядро стриминга для отправки/регенерации/редактирования
  const runStream = useCallback(
    async (content: string, files?: File[], options?: StreamOptions) => {
      const hasFiles = files && files.length > 0;
      setIsStreaming(true);
      setStreamingContent(
        hasFiles ? `Обработка ${files!.length} документ(ов)...` : ""
      );
      setStreamingSources(null);
      setLastUsage(null);

      try {
        abortedRef.current = false;
        const stream = streamMessages(conversationId, content, files, {
          ...options,
          onUploadProgress: hasFiles
            ? (percent) =>
                setStreamingContent(
                  percent < 100
                    ? `Загрузка ${files!.length} файл(ов)... ${percent}%`
                    : `Обработка ${files!.length} документ(ов)...`
                )
            : undefined,
        });
        let full = "";
        for await (const event of stream) {
          if (abortedRef.current) break;
          if (event.error) {
            throw new Error(event.error);
          }
          if (event.content) {
            if (!full) setStreamingContent("");
            full += event.content;
            setStreamingContent(full);
          }
          if (event.sources) {
            setStreamingSources(event.sources);
          }
          if (event.usage) {
            setLastUsage(event.usage);
          }
        }

        await queryClient.invalidateQueries({
          queryKey: ["conversation", conversationId],
        });
        await queryClient.invalidateQueries({ queryKey: ["conversations"] });
      } catch (err) {
        console.error("Stream error:", err);
        toast("Ошибка при получении ответа", "error");
        await queryClient.invalidateQueries({
          queryKey: ["conversation", conversationId],
        });
      } finally {
        setIsStreaming(false);
        setStreamingContent("");
        setStreamingSources(null);
      }
    },
    [conversationId, queryClient]
  );

  const handleSend = useCallback(
    (content: string, files?: File[]) => {
      const hasFiles = files && files.length > 0;
      queryClient.setQueryData(
        ["conversation", conversationId],
        (old: typeof conversation) => {
          if (!old) return old;
          return {
            ...old,
            messages: [
              ...old.messages,
              {
                id: crypto.randomUUID(),
                conversation_id: conversationId,
                role: "user" as const,
                content,
                document_ids: hasFiles ? ["pending"] : [],
                created_at: new Date().toISOString(),
              },
            ],
          };
        }
      );
      void runStream(content, files);
    },
    [conversationId, queryClient, runStream, conversation]
  );

  // Регенерация последнего ответа: убираем хвостовые ответы ассистента из кэша
  const handleRegenerate = useCallback(() => {
    queryClient.setQueryData(
      ["conversation", conversationId],
      (old: typeof conversation) => {
        if (!old) return old;
        const msgs = [...old.messages];
        while (msgs.length > 0 && msgs[msgs.length - 1].role === "assistant") {
          msgs.pop();
        }
        return { ...old, messages: msgs };
      }
    );
    void runStream("", undefined, { action: "regenerate" });
  }, [conversationId, queryClient, runStream, conversation]);

  // Редактирование сообщения пользователя: обновляем текст, отрезаем хвост
  const handleEdit = useCallback(
    (messageId: string, newContent: string) => {
      queryClient.setQueryData(
        ["conversation", conversationId],
        (old: typeof conversation) => {
          if (!old) return old;
          const idx = old.messages.findIndex((m: Message) => m.id === messageId);
          if (idx < 0) return old;
          const msgs = old.messages.slice(0, idx + 1).map((m: Message, i: number) =>
            i === idx ? { ...m, content: newContent } : m
          );
          return { ...old, messages: msgs };
        }
      );
      void runStream(newContent, undefined, { action: "edit", messageId });
    },
    [conversationId, queryClient, runStream, conversation]
  );

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center text-muted-foreground">
        Загрузка...
      </div>
    );
  }

  const messages: Message[] = conversation?.messages || [];
  const lastMessage = messages[messages.length - 1];
  const kbIds =
    conversation?.knowledge_base_ids ??
    (conversation?.knowledge_base_id ? [conversation.knowledge_base_id] : []);

  return (
    <div className="flex flex-col h-full">
      <div className="bg-card border-b border-border px-5 py-3 flex items-center justify-between shadow-sm">
        <h2 className="text-base font-semibold text-foreground">
          {conversation?.title}
        </h2>
        <div className="flex items-center gap-4">
          {lastUsage && (
            <span className="text-[10px] text-muted-foreground bg-accent rounded-lg px-2 py-1">
              {lastUsage.total_tokens} токенов
            </span>
          )}
          <ChatSettings
            model={conversation?.model ?? null}
            temperature={conversation?.temperature ?? null}
            onChange={({ model, temperature }) =>
              settingsMut.mutate({ model, temperature })
            }
            disabled={isStreaming || settingsMut.isPending}
          />
          <KBSelector
            value={kbIds}
            onChange={(ids) => settingsMut.mutate({ knowledge_base_ids: ids })}
            disabled={isStreaming || settingsMut.isPending}
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5">
        {messages.length === 0 && !streamingContent && (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-3">
            <div className="w-16 h-16 rounded-full bg-[#21a038]/10 flex items-center justify-center">
              <svg
                width="28"
                height="28"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#21a038"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
              </svg>
            </div>
            <p className="text-sm">Начните диалог, отправив сообщение</p>
            {/* Стартовые подсказки */}
            <div className="flex flex-wrap justify-center gap-2 max-w-lg mt-2">
              {[
                "Сравни требования двух документов и выдели расхождения",
                "Сделай краткое резюме приложенного документа",
                "Извлеки ключевые суммы и сроки из договора",
                "Составь чек-лист проверки заявки по 223-ФЗ",
              ].map((prompt) => (
                <button
                  key={prompt}
                  onClick={() => handleSend(prompt)}
                  disabled={isStreaming}
                  className="text-xs text-foreground bg-card border border-border rounded-xl px-3 py-2 hover:border-[#21a038]/60 hover:bg-accent transition-colors text-left max-w-[240px]"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}
        {messages.map((msg, idx) => (
          <MessageBubble
            key={msg.id}
            role={msg.role}
            content={msg.content}
            documentCount={(msg.document_ids || []).length}
            sources={msg.sources}
            messageId={msg.id}
            onEdit={msg.role === "user" && !isStreaming ? handleEdit : undefined}
            onRegenerate={
              msg.role === "assistant" &&
              idx === messages.length - 1 &&
              !isStreaming &&
              lastMessage?.role === "assistant"
                ? handleRegenerate
                : undefined
            }
            actionsDisabled={isStreaming}
          />
        ))}
        {streamingContent && (
          <MessageBubble
            role="assistant"
            content={streamingContent}
            sources={streamingSources}
          />
        )}
        <div ref={messagesEndRef} />
      </div>

      <MessageInput
        conversationId={conversationId}
        onSend={handleSend}
        disabled={isStreaming}
      />
    </div>
  );
}
