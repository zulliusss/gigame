import { useEffect, useRef, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getKnowledgeBases } from '@/api/knowledge-bases';

interface KBSelectorProps {
  value: string[];
  onChange: (kbIds: string[]) => void;
  disabled?: boolean;
}

// Мультиселект баз знаний диалога: выпадающий список с чекбоксами.
// Изменения применяются сразу через onChange (PUT диалога).
export function KBSelector({ value, onChange, disabled }: KBSelectorProps) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  const { data: knowledgeBases = [] } = useQuery({
    queryKey: ['knowledge-bases'],
    queryFn: () => getKnowledgeBases(),
  });

  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open]);

  if (knowledgeBases.length === 0) return null;

  const toggle = (kbId: string) => {
    if (value.includes(kbId)) {
      onChange(value.filter((id) => id !== kbId));
    } else {
      onChange([...value, kbId]);
    }
  };

  const label =
    value.length === 0
      ? 'Без базы знаний'
      : value.length === 1
      ? knowledgeBases.find((kb) => kb.id === value[0])?.name || '1 база знаний'
      : `Базы знаний: ${value.length}`;

  return (
    <div ref={rootRef} className="relative">
      <button
        onClick={() => !disabled && setOpen((v) => !v)}
        disabled={disabled}
        className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
        title="Базы знаний для RAG-поиска в этом диалоге"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#21a038" strokeWidth="2">
          <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>
        </svg>
        <span className="max-w-[180px] truncate">{label}</span>
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1.5 z-30 w-64 max-h-72 overflow-y-auto bg-card border border-border rounded-xl shadow-lg py-1.5">
          <div className="px-3 py-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">
            Базы знаний диалога
          </div>
          {knowledgeBases.map((kb) => (
            <label
              key={kb.id}
              className="flex items-center gap-2.5 px-3 py-1.5 text-xs text-foreground hover:bg-accent cursor-pointer"
            >
              <input
                type="checkbox"
                checked={value.includes(kb.id)}
                onChange={() => toggle(kb.id)}
                className="accent-[#21a038]"
              />
              <span className="truncate">{kb.name}</span>
              {kb.shared && (
                <span
                  className="ml-auto flex-shrink-0 text-[9px] uppercase tracking-wide text-[#21a038] bg-[#21a038]/10 rounded-full px-1.5 py-0.5"
                  title={kb.is_owner ? 'Ваша общая база' : 'Общая база другого пользователя'}
                >
                  общая
                </span>
              )}
            </label>
          ))}
          {value.length > 0 && (
            <button
              onClick={() => onChange([])}
              className="w-full text-left px-3 py-1.5 text-xs text-muted-foreground hover:bg-accent hover:text-destructive"
            >
              Отвязать все
            </button>
          )}
        </div>
      )}
    </div>
  );
}
