import { useState, type ReactNode } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import 'highlight.js/styles/github.css';

interface MarkdownProps {
  children: string;
  className?: string;
}

/**
 * Код-блок с плашкой языка и кнопкой копирования.
 * react-markdown отдаёт <pre><code class="language-...">, поэтому
 * перехватываем rendering на уровне <pre>.
 */
function CodeBlock({ children }: { children?: ReactNode }) {
  const [copied, setCopied] = useState(false);

  // Достаём язык и текст из вложенного <code>
  let language = '';
  let codeText = '';
  const child = Array.isArray(children) ? children[0] : children;
  if (child && typeof child === 'object' && 'props' in child) {
    const props = (child as { props: { className?: string; children?: ReactNode } }).props;
    const match = /language-(\w+)/.exec(props.className || '');
    language = match ? match[1] : '';
    codeText = extractText(props.children);
  }

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(codeText);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* буфер обмена недоступен */
    }
  };

  return (
    <div className="md-codeblock group/code relative my-2 rounded-lg border border-border overflow-hidden">
      <div className="flex items-center justify-between bg-muted px-3 py-1 text-[10px] text-muted-foreground">
        <span className="uppercase tracking-wide">{language || 'код'}</span>
        <button
          onClick={copy}
          className="flex items-center gap-1 hover:text-foreground transition-colors"
          title="Копировать код"
        >
          {copied ? (
            <>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#21a038" strokeWidth="2">
                <polyline points="20 6 9 17 4 12" />
              </svg>
              Скопировано
            </>
          ) : (
            <>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2" />
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
              </svg>
              Копировать
            </>
          )}
        </button>
      </div>
      <pre className="overflow-x-auto bg-card p-3 text-xs leading-relaxed m-0">{children}</pre>
    </div>
  );
}

function extractText(node: ReactNode): string {
  if (node == null || typeof node === 'boolean') return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(extractText).join('');
  if (typeof node === 'object' && 'props' in node) {
    return extractText((node as { props: { children?: ReactNode } }).props.children);
  }
  return '';
}

/**
 * Shared markdown renderer with GitHub Flavored Markdown support
 * (tables, strikethrough, autolinks, task lists) and syntax highlighting.
 *
 * Типографика задаётся классом .md-body (см. index.css) — плагин
 * @tailwindcss/typography не используется.
 */
export function Markdown({ children, className = '' }: MarkdownProps) {
  return (
    <div className={`md-body max-w-none ${className}`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[[rehypeHighlight, { ignoreMissing: true, detect: false }]]}
        components={{
          pre: CodeBlock,
          table: (props) => (
            <div className="md-table-wrap">
              <table {...props} />
            </div>
          ),
          a: (props) => <a {...props} target="_blank" rel="noopener noreferrer" />,
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}
