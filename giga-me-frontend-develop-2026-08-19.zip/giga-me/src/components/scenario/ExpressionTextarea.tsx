import { useMemo, useRef, type ReactNode } from "react";
import type { Node, Edge } from "@xyflow/react";
import { cn } from "@/lib/utils";

/**
 * Редактор промпта с подсветкой выражений {{output:Метка}} / {{json:Метка:путь}}.
 *
 * Зелёный — метка указывает на предшественника текущего узла (значение будет
 * определено к моменту выполнения). Янтарный — узел есть в графе, но НЕ является
 * предшественником: его результата может ещё не быть. Красный — узел с такой
 * меткой/id в графе не найден.
 *
 * Техника: под прозрачным textarea лежит div с тем же шрифтом и переносами,
 * в котором выражения обёрнуты в цветные span'ы; скролл синхронизируется.
 */

// зеркало backend ExpressionResolver.EXPR
const EXPR_RE = /\{\{\s*(output|json)\s*:\s*([^:}]+?)\s*(?::\s*([^}]+?)\s*)?\}\}/g;

export type ExprStatus = "ok" | "warn" | "missing";

export interface ExprToken {
  raw: string;
  label: string;
  status: ExprStatus;
}

/** Транзитивные предшественники узла по рёбрам графа. */
function ancestorIds(nodeId: string, edges: Edge[]): Set<string> {
  const parents = new Map<string, string[]>();
  for (const e of edges) {
    const list = parents.get(e.target) ?? [];
    list.push(e.source);
    parents.set(e.target, list);
  }
  const seen = new Set<string>();
  const stack = [...(parents.get(nodeId) ?? [])];
  while (stack.length) {
    const id = stack.pop()!;
    if (seen.has(id)) continue;
    seen.add(id);
    for (const p of parents.get(id) ?? []) stack.push(p);
  }
  return seen;
}

/** Статус метки выражения: как backend — сначала по id, затем по метке (без регистра). */
function labelStatus(
  label: string,
  nodes: Node[],
  ancestors: Set<string>
): ExprStatus {
  const want = label.trim().toLowerCase();
  const matches = nodes.filter((n) => {
    if (n.id === label.trim()) return true;
    const nodeLabel = String((n.data as Record<string, string>)?.label ?? "").trim();
    return nodeLabel.toLowerCase() === want && nodeLabel !== "";
  });
  if (matches.length === 0) return "missing";
  return matches.some((n) => ancestors.has(n.id)) ? "ok" : "warn";
}

/** Разбор текста на токены с их статусами (экспортирован для подсказок под Input). */
export function tokenizeExpressions(
  text: string,
  nodes: Node[],
  edges: Edge[],
  currentNodeId: string
): ExprToken[] {
  const ancestors = ancestorIds(currentNodeId, edges);
  const tokens: ExprToken[] = [];
  for (const m of text.matchAll(EXPR_RE)) {
    tokens.push({
      raw: m[0],
      label: m[2].trim(),
      status: labelStatus(m[2], nodes, ancestors),
    });
  }
  return tokens;
}

const STATUS_CLASS: Record<ExprStatus, string> = {
  ok: "bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300",
  warn: "bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300",
  missing: "bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-300",
};

const STATUS_TITLE: Record<ExprStatus, string> = {
  ok: "узел найден среди предшественников — значение будет определено",
  warn: "узел есть в графе, но не является предшественником: к моменту выполнения его результата может не быть",
  missing: "узел с такой меткой или id в графе не найден",
};

/** Общая типографика textarea и подложки — переносы и метрики должны совпадать. */
const SHARED_TEXT =
  "px-2.5 py-2 text-base md:text-sm whitespace-pre-wrap break-words font-[inherit] leading-[inherit]";

export function ExpressionTextarea({
  value,
  onChange,
  placeholder,
  nodes,
  edges,
  currentNodeId,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  nodes: Node[];
  edges: Edge[];
  currentNodeId: string;
  className?: string;
}) {
  const backdropRef = useRef<HTMLDivElement>(null);

  const { parts, tokens } = useMemo(() => {
    const ancestors = ancestorIds(currentNodeId, edges);
    const out: ReactNode[] = [];
    const found: ExprToken[] = [];
    let last = 0;
    let key = 0;
    for (const m of value.matchAll(EXPR_RE)) {
      const idx = m.index ?? 0;
      if (idx > last) out.push(value.slice(last, idx));
      const status = labelStatus(m[2], nodes, ancestors);
      found.push({ raw: m[0], label: m[2].trim(), status });
      out.push(
        <span key={key++} className={cn("rounded-sm", STATUS_CLASS[status])} title={STATUS_TITLE[status]}>
          {m[0]}
        </span>
      );
      last = idx + m[0].length;
    }
    if (last < value.length) out.push(value.slice(last));
    // хвостовой перенос строки должен занимать высоту и в подложке
    out.push("​");
    return { parts: out, tokens: found };
  }, [value, nodes, edges, currentNodeId]);

  const syncScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    if (backdropRef.current) {
      backdropRef.current.scrollTop = e.currentTarget.scrollTop;
      backdropRef.current.scrollLeft = e.currentTarget.scrollLeft;
    }
  };

  const counts = tokens.reduce(
    (acc, t) => ((acc[t.status] += 1), acc),
    { ok: 0, warn: 0, missing: 0 } as Record<ExprStatus, number>
  );

  return (
    <div>
      <div className={cn("relative rounded-lg border border-input overflow-hidden focus-within:border-ring focus-within:ring-3 focus-within:ring-ring/50 transition-colors", className)}>
        <div
          ref={backdropRef}
          aria-hidden
          className={cn(
            SHARED_TEXT,
            "absolute inset-0 overflow-hidden text-foreground pointer-events-none select-none"
          )}
        >
          {parts}
        </div>
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onScroll={syncScroll}
          placeholder={value ? undefined : placeholder}
          spellCheck={false}
          className={cn(
            SHARED_TEXT,
            "relative block w-full min-h-[140px] max-h-[420px] resize-y bg-transparent outline-none",
            "text-transparent placeholder:text-muted-foreground"
          )}
          style={{ caretColor: "var(--foreground, #111)" }}
        />
      </div>
      {tokens.length > 0 && (
        <p className="text-[10px] mt-1 leading-relaxed">
          <span className="text-muted-foreground">Выражения: </span>
          {counts.ok > 0 && (
            <span className="text-green-700 dark:text-green-400">{counts.ok} ✓ определено </span>
          )}
          {counts.warn > 0 && (
            <span className="text-amber-700 dark:text-amber-400" title={STATUS_TITLE.warn}>
              {counts.warn} ⚠ не предшественник{" "}
            </span>
          )}
          {counts.missing > 0 && (
            <span className="text-red-700 dark:text-red-400">
              {counts.missing} ✗ не найдено:{" "}
              {tokens.filter((t) => t.status === "missing").map((t) => `«${t.label}»`).join(", ")}
            </span>
          )}
        </p>
      )}
    </div>
  );
}

/** Компактные подсказки для однострочных полей (if/control) с выражениями. */
export function ExpressionHints({
  text,
  nodes,
  edges,
  currentNodeId,
}: {
  text: string;
  nodes: Node[];
  edges: Edge[];
  currentNodeId: string;
}) {
  const tokens = useMemo(
    () => tokenizeExpressions(text, nodes, edges, currentNodeId),
    [text, nodes, edges, currentNodeId]
  );
  if (tokens.length === 0) return null;
  return (
    <p className="text-[10px] mt-1 leading-relaxed flex flex-wrap gap-1">
      {tokens.map((t, i) => (
        <span key={i} className={cn("rounded px-1", STATUS_CLASS[t.status])} title={STATUS_TITLE[t.status]}>
          {t.status === "ok" ? "✓" : t.status === "warn" ? "⚠" : "✗"} {t.label}
        </span>
      ))}
    </p>
  );
}
