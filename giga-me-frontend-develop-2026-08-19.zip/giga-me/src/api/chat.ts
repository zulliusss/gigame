import { fetchApi } from './client';
import { BASE_URL } from './constants';
import { getWebSocketClient, type StreamEvent } from './websocket';

export interface Conversation {
  id: string;
  title: string;
  knowledge_base_id: string | null;
  knowledge_base_ids: string[] | null;
  model: string | null;
  temperature: number | null;
  created_at: string;
  updated_at: string;
}

export interface RagSource {
  document_id?: string;
  document_name?: string;
  snippet?: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  document_ids: string[];
  sources?: RagSource[] | null;
  created_at: string;
}

export interface ConversationWithMessages extends Conversation {
  messages: Message[];
}

export function getConversations(search?: string): Promise<Conversation[]> {
  const params = search ? `?q=${encodeURIComponent(search)}` : '';
  return fetchApi(`/conversations${params}`);
}

export function getConversation(id: string): Promise<ConversationWithMessages> {
  return fetchApi(`/conversations/${id}`);
}

export function createConversation(
  title?: string,
  knowledgeBaseId?: string,
): Promise<Conversation> {
  return fetchApi('/conversations', {
    method: 'POST',
    body: JSON.stringify({
      title: title || null,
      knowledge_base_id: knowledgeBaseId || null,
    }),
  });
}

// Частичное обновление настроек диалога: null/отсутствующие поля не меняются;
// пустой список knowledge_base_ids отвязывает базы; model: "" и temperature: -1
// сбрасывают значения на глобальные.
export interface ConversationPatch {
  title?: string;
  knowledge_base_ids?: string[];
  model?: string;
  temperature?: number;
}

export function updateConversation(
  id: string,
  patch: string | ConversationPatch,
): Promise<Conversation> {
  const body = typeof patch === 'string' ? { title: patch } : patch;
  return fetchApi(`/conversations/${id}`, {
    method: 'PUT',
    body: JSON.stringify(body),
  });
}

export function deleteConversation(id: string): Promise<void> {
  return fetchApi(`/conversations/${id}`, { method: 'DELETE' });
}


// Upload files to the server and return document IDs.
// XMLHttpRequest вместо fetch — ради события progress при загрузке.
function uploadFiles(
  conversationId: string,
  files: File[],
  onProgress?: (percent: number) => void,
): Promise<void> {
  const formData = new FormData();
  formData.append('content', ''); // Empty content placeholder
  for (const file of files) {
    formData.append('files', file);
  }

  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', BASE_URL + `/conversations/${conversationId}/upload`);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) {
        onProgress(Math.round((e.loaded / e.total) * 100));
      }
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve();
      } else {
        reject(new Error(`Upload error: ${xhr.status}`));
      }
    };
    xhr.onerror = () => reject(new Error('Upload network error'));
    xhr.send(formData);
  });
}

// Параметры стрима: обычная отправка (send), регенерация последнего ответа
// (regenerate) или редактирование сообщения пользователя (edit + messageId).
export interface StreamOptions {
  action?: 'send' | 'regenerate' | 'edit';
  messageId?: string;
  /** Прогресс загрузки прикреплённых файлов, 0-100 */
  onUploadProgress?: (percent: number) => void;
}

// WebSocket-based streaming for sending messages
// Returns an async generator that yields StreamEvent objects
export async function* streamMessages(
  conversationId: string,
  content: string,
  files?: File[],
  options?: StreamOptions,
): AsyncGenerator<StreamEvent> {
  const client = getWebSocketClient();

  let cleanupDone = false;

  // Set up handlers before connecting
  const queue: StreamEvent[] = [];

  const handleMessage = (event: StreamEvent) => {
    if (event.done || event.error) {
      if (cleanupDone) return;
      cleanupDone = true;
      queue.push(event);
      // Cleanup after queue is drained
      (async () => {
        await new Promise(resolve => setTimeout(resolve, 100)); // Small delay to drain queue
        client.setOnMessage(null);
        client.disconnect();
      })();
    } else {
      queue.push(event);
    }
  };

  client.setOnMessage(handleMessage);

  // Connect if not already connected
  client.connect();

  // Wait for connection to be established
  const waitConnection = new Promise<void>((resolve, reject) => {
    const checkConnection = () => {
      if (client.isConnected()) {
        resolve();
      } else if (client.getWs() === null) {
        reject(new Error('WebSocket connection closed before established'));
      } else {
        setTimeout(checkConnection, 10);
      }
    };
    checkConnection();
  });

  try {
    await waitConnection;
  } catch (error) {
    console.error('WebSocket connect error:', error);
    client.setOnMessage(null);
    throw new Error('Failed to connect to server');
  }

  try {
    const finalContent = content;

    // Upload files if provided
    if (files && files.length > 0) {
      await uploadFiles(conversationId, files, options?.onUploadProgress);
    }

    // Send the message via WebSocket
    client.send({
      conversation_id: conversationId,
      content: finalContent,
      ...(options?.action && options.action !== 'send'
        ? { action: options.action, message_id: options.messageId }
        : {}),
    });

    // Yield events as they arrive
    while (!cleanupDone || queue.length > 0) {
      if (queue.length > 0) {
        const event = queue.shift()!;
        yield event;
        if (event.done || event.error) {
          cleanupDone = true;
        }
      } else {
        // Wait a bit before checking again
        await new Promise((resolve) => setTimeout(resolve, 10));
      }
    }
  } catch (error) {
    console.error('Stream error:', error);
    if (!cleanupDone) {
      client.setOnMessage(null);
      client.disconnect();
      cleanupDone = true;
    }
    throw error;
  } finally {
    // Ensure cleanup happens
    if (!cleanupDone) {
      try {
        client.setOnMessage(null);
        client.disconnect();
      } catch (e) {
        // Ignore errors during cleanup
      }
      cleanupDone = true;
    }
  }
}