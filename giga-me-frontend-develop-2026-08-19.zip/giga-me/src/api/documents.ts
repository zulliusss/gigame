import { fetchApi } from './client';

export interface DocumentView {
  id: string;
  filename: string;
  content_type: string | null;
  size_bytes: number | null;
  extracted_text: string | null;
  created_at: string;
}

// Просмотр документа (метаданные + извлечённый текст) — переход к источнику RAG
export function getDocument(id: string): Promise<DocumentView> {
  return fetchApi(`/documents/${id}`);
}
