import { fetchApi } from './client';

/** Промпт из базы промптов со статистикой. */
export interface Prompt {
  id: string;
  title: string;
  description: string | null;
  text: string;
  model: string | null;
  shared: boolean;
  is_owner: boolean;
  usage_count: number;
  rating_avg: number | null;
  rating_count: number;
  my_rating: number | null;
  updated_at: string;
}

export function getPrompts(): Promise<Prompt[]> {
  return fetchApi('/prompts');
}

export function createPrompt(data: {
  title: string;
  description?: string;
  text: string;
  model?: string;
  shared?: boolean;
}): Promise<Prompt> {
  return fetchApi('/prompts', { method: 'POST', body: JSON.stringify(data) });
}

export function updatePrompt(
  id: string,
  data: { title?: string; description?: string; text?: string; model?: string; shared?: boolean },
): Promise<Prompt> {
  return fetchApi(`/prompts/${id}`, { method: 'PUT', body: JSON.stringify(data) });
}

export function deletePrompt(id: string): Promise<void> {
  return fetchApi(`/prompts/${id}`, { method: 'DELETE' });
}

export function ratePrompt(id: string, rating: number): Promise<void> {
  return fetchApi(`/prompts/${id}/rating`, {
    method: 'POST',
    body: JSON.stringify({ rating }),
  });
}

/** Инкремент счётчика использований; возвращает текст промпта. */
export function usePromptText(id: string): Promise<{ text: string }> {
  return fetchApi(`/prompts/${id}/use`, { method: 'POST' });
}
