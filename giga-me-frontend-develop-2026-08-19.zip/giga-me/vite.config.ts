import path from "path"
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { federation } from '@module-federation/vite'

import { name } from './package.json'

export default defineConfig({
  plugins: [react(), tailwindcss(), federation({
    name: name,
    filename: 'assets/remoteEntry.js',
    manifest: true,
    exposes: {
        './RemoteApp': './src/RemoteApp',
    },
    dts: false,
    bundleAllCSS: true,
}),
],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
})