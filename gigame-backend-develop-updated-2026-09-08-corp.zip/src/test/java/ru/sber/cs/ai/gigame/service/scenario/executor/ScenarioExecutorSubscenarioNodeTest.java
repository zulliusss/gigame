package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ScenarioExecutorSubscenarioNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private NodeDto inputNode;
    private NodeDto subScenNodeEmpty;
    private NodeDto subScenNode;
    private NodeDto outputNode;
    private EdgeDto edge1;
    private EdgeDto edge2;

    private static NodeDto createNode(String id, ScenarioNodeType type, String label, String value, int x, int y) {
        return NodeDto.builder()
                .id(id)
                .type(type.toString())
                .data(NodeDataDto.builder().label(label).value(value).build())
                .position(new PositionDto(x, y))
                .build();
    }

    @BeforeEach
    void setUp() {
        inputNode = createNode("input-1", ScenarioNodeType.INPUT_NODE, "Input", null, 100, 100);
        subScenNodeEmpty = createNode("subscen-1", ScenarioNodeType.SUBSCENARIO_NODE, "wait", null, 300, 100);
        subScenNode = createNode("subscen-1", ScenarioNodeType.SUBSCENARIO_NODE, "wait", "SubScenario", 300, 100);
        outputNode = createNode("output-1", ScenarioNodeType.OUTPUT_NODE, "Output", null, 300, 100);
        edge1 = new EdgeDto("edge-1", "input-1", "subscen-1", new EdgeDataDto(null));
        edge2 = new EdgeDto("edge-2", "subscen-1", "output-1", new EdgeDataDto(null));
    }

    @Test
    void testExecute_withEmptyWaitTime() {
        var graphData = new GraphDataDto(List.of(inputNode, subScenNodeEmpty, outputNode), List.of(edge1, edge2));
        var graph = new ScenarioRunGraph(graphData);
        graph.setRunnerUserId("user-1");
        var node = ScenarioRunNode.fromDto(1, subScenNodeEmpty, graph);
        var executor = new ScenarioExecutorSubscenarioNode(node, mock(ScenarioEngine.class));
        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void testExecute_withWaitTime() {
        var graphData = new GraphDataDto(List.of(inputNode, subScenNode, outputNode), List.of(edge1, edge2));
        var graph = new ScenarioRunGraph(graphData);
        graph.setRunnerUserId("user-1");
        var node = ScenarioRunNode.fromDto(1, subScenNode, graph);
        var engine = mock(ScenarioEngine.class);
        var expected = "Подсценарий отработал";
        when(engine.executeSubScenarioInline(any(), any(), any())).thenReturn(expected);
        var executor = new ScenarioExecutorSubscenarioNode(node, engine);
        String result = executor.execute(sink);
        assertEquals(expected, result);
    }

}