package ru.sber.cs.ai.gigame.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты типизированных DTO-запросов памяти агента: тела запросов
 * десериализуются из snake_case JSON без Map (требование СОВЫ).
 */
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {AgentMemoryController.class, TestConfiguration.class})
@WebFluxTest(controllers = AgentMemoryController.class)
// холодный старт контекста на нагруженной машине превышает дефолтные 5с
@AutoConfigureWebTestClient(timeout = "30000")
class AgentMemoryControllerTest {

    @Autowired
    private WebTestClient webClient;
    @MockitoBean
    private AgentMemoryService memoryService;
    @MockitoBean
    private ScenarioRunRepository runRepository;
    @MockitoBean
    private ScenarioRunStepRepository stepRepository;

    private String userId;
    private AgentLesson lessonEntity;

    @BeforeEach
    void setUp() {
        userId = "test-user";
        lessonEntity = new AgentLesson();
        lessonEntity.setId(UUID.randomUUID());
        lessonEntity.setLesson("Суммы брать из УПД");
    }

    @Test
    void addLesson_ShouldParseSnakeCaseBody() {
        UUID scenarioId = UUID.randomUUID();
        when(memoryService.addLesson(scenarioId,
                "Суммы брать из УПД", AgentLesson.SOURCE_USER))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"" + scenarioId + "\", \"lesson\": \"Суммы брать из УПД\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).addLesson(scenarioId,
                "Суммы брать из УПД", AgentLesson.SOURCE_USER);
    }

    @Test
    void addLesson_ShouldTreatBlankScenarioIdAsGlobal() {
        when(memoryService.addLesson(isNull(),
                eq("Общий урок"), eq(AgentLesson.SOURCE_USER)))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"\", \"lesson\": \"Общий урок\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).addLesson(isNull(),
                eq("Общий урок"), eq(AgentLesson.SOURCE_USER));
    }

    @Test
    void updateLesson_ShouldParseLessonBody() {
        UUID id = UUID.randomUUID();
        when(memoryService.updateLesson(id, "Новый текст"))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.put()
                .uri("/api/agent/lessons/{id}", id)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"lesson\": \"Новый текст\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).updateLesson(id, "Новый текст");
    }

    @Test
    void answerQuestion_ShouldParseAnswerBody() {
        UUID id = UUID.randomUUID();
        when(memoryService.answerQuestion(id, "Дата — из штампа ЭП"))
                .thenReturn(new AgentQuestion());

        webClient.post()
                .uri("/api/agent/questions/{id}/answer", id)
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"answer\": \"Дата — из штампа ЭП\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).answerQuestion(id, "Дата — из штампа ЭП");
    }

    @Test
    void getLessons_ShouldReturnListByScenario() {
        UUID scenarioId = UUID.randomUUID();
        when(memoryService.getLessons(scenarioId))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/lessons")
                        .queryParam("scenario_id", scenarioId).build())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getLessons(scenarioId);
    }

    @Test
    void getLessons_ShouldReturnGlobalWhenNoScenario() {
        when(memoryService.getLessons(isNull()))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.get()
                .uri("/api/agent/lessons")
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getLessons(isNull());
    }

    @Test
    void deleteLesson_ShouldCallService() {
        UUID id = UUID.randomUUID();

        webClient.delete()
                .uri("/api/agent/lessons/{id}", id)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).deleteLesson(id);
    }

    @Test
    void approveLesson_ShouldCallService() {
        UUID id = UUID.randomUUID();
        when(memoryService.approveLesson(id))
                .thenReturn(AgentLessonResponseDto.from(lessonEntity));

        webClient.post()
                .uri("/api/agent/lessons/{id}/approve", id)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).approveLesson(id);
    }

    @Test
    void compressLessons_ShouldCallService() {
        UUID scenarioId = UUID.randomUUID();
        when(memoryService.compressLessons(scenarioId))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.post()
                .uri("/api/agent/lessons/compress")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"scenario_id\": \"" + scenarioId + "\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).compressLessons(scenarioId);
    }

    @Test
    void getPlans_ShouldCallService() {
        UUID scenarioId = UUID.randomUUID();
        AgentPlan plan = new AgentPlan();
        plan.setScenarioId(scenarioId);
        when(memoryService.getPlans(scenarioId)).thenReturn(List.of(plan));

        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/plans")
                        .queryParam("scenario_id", scenarioId).build())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getPlans(scenarioId);
    }

    @Test
    void deletePlan_ShouldCallService() {
        UUID id = UUID.randomUUID();

        webClient.delete()
                .uri("/api/agent/plans/{id}", id)
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).deletePlan(id);
    }

    @Test
    void extractLessons_ShouldCollectStepOutputs() {
        UUID runId = UUID.randomUUID();
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        ScenarioRunStep step = new ScenarioRunStep();
        step.setRunId(runId);
        step.setNodeId("critic");
        step.setNodeType("processing");
        step.setOutputData(Map.of("result", "РАСХОЖДЕНИЕ: сумма акта"));

        when(runRepository.findById(runId)).thenReturn(Optional.of(run));
        when(stepRepository.findByRunIdOrderByStartedAtAsc(runId)).thenReturn(List.of(step));
        when(memoryService.extractLessonsFromRun(scenarioId,
                Map.of("critic (processing)", "РАСХОЖДЕНИЕ: сумма акта")))
                .thenReturn(List.of(AgentLessonResponseDto.from(lessonEntity)));

        webClient.post()
                .uri("/api/agent/lessons/extract")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"run_id\": \"" + runId + "\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).extractLessonsFromRun(scenarioId,
                Map.of("critic (processing)", "РАСХОЖДЕНИЕ: сумма акта"));
    }

    @Test
    void extractLessons_ShouldSkipBlankStepResults() {
        UUID runId = UUID.randomUUID();
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun run = new ScenarioRun();
        run.setId(runId);
        run.setScenarioId(scenarioId);
        ScenarioRunStep blankStep = new ScenarioRunStep();
        blankStep.setNodeId("input");
        blankStep.setNodeType("input");
        blankStep.setOutputData(Map.of("result", " "));
        ScenarioRunStep nullOut = new ScenarioRunStep();
        nullOut.setNodeId("note");
        nullOut.setNodeType("note");

        when(runRepository.findById(runId)).thenReturn(Optional.of(run));
        when(stepRepository.findByRunIdOrderByStartedAtAsc(runId))
                .thenReturn(List.of(blankStep, nullOut));
        when(memoryService.extractLessonsFromRun(scenarioId, Map.of()))
                .thenReturn(List.of());

        webClient.post()
                .uri("/api/agent/lessons/extract")
                .header("X-UserId", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"run_id\": \"" + runId + "\"}")
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).extractLessonsFromRun(scenarioId, Map.of());
    }

    @Test
    void getQuestions_ShouldCallService() {
        UUID runId = UUID.randomUUID();
        AgentQuestion q = new AgentQuestion();
        q.setRunId(runId);
        when(memoryService.getQuestionsByRun(runId)).thenReturn(List.of(q));

        webClient.get()
                .uri(uriBuilder -> uriBuilder.path("/api/agent/questions")
                        .queryParam("run_id", runId).build())
                .header("X-UserId", userId)
                .exchange()
                .expectStatus().isOk();

        verify(memoryService).getQuestionsByRun(runId);
    }
}
