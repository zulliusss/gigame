package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

/**
 * Тесты всех операций узла «Трансформация».
 */
class ScenarioExecutorTransformNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    // ---------------------------------------------------------------
    // Helper — строит одноузловой граф с правилами
    // ---------------------------------------------------------------

    private static ScenarioRunNode node(String rules, String... inputs) {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Трансформ")
                        .rules(rules)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("t1");
        for (String in : inputs) {
            node.getInput().add(in);
        }
        return node;
    }

    // ---------------------------------------------------------------
    // extractRegex — all / withGroup / onlyFirst
    // ---------------------------------------------------------------

    private static Stream<Arguments> extractRegexTestCases() {
        return Stream.of(
                Arguments.of(
                        "regular",
                        "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"}]}",
                        "Номер: 12345, Номер: 67890",
                        "12345\n67890"
                ),
                Arguments.of(
                        "withGroup",
                        "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"№ (\\\\d+)\", \"группа\": 1}]}",
                        "№ 777, № 888",
                        "777\n888"
                ),
                Arguments.of(
                        "allFalseOnlyFirst",
                        "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\", \"все\": false}]}",
                        "a1 b2 c3",
                        "1"
                )
        );
    }

    @MethodSource("extractRegexTestCases")
    @ParameterizedTest(name = "extractRegex: {0}")
    void testExtractRegex_allModes(String label, String rules, String input, String expected) {
        var node = node(rules, input);
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals(expected, result.trim());
    }

    // ---------------------------------------------------------------
    // replace (plain / regex / default empty)
    // ---------------------------------------------------------------

    private static Stream<Arguments> replaceTestCases() {
        return Stream.of(
                Arguments.of(
                        "plain",
                        "{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"старое\", \"на\": \"новое\"}]}",
                        "старое слово",
                        "новое слово"
                ),
                Arguments.of(
                        "regex",
                        "{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"\\\\d+\", \"на\": \"ЧИСЛО\", \"regex\": true}]}",
                        "abc 123 def",
                        "abc ЧИСЛО def"
                ),
                Arguments.of(
                        "defaultEmptyReplacement",
                        "{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"лишнее\"}]}",
                        "удалить лишнее слово",
                        "удалить  слово"
                )
        );
    }

    @MethodSource("replaceTestCases")
    @ParameterizedTest(name = "replace: {0}")
    @SuppressWarnings("java:S4144")
    void testReplace_allModes(String label, String rules, String input, String expected) {
        var node = node(rules, input);
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals(expected, result.trim());
    }

    // ---------------------------------------------------------------
    // filterLines — keep / remove
    // ---------------------------------------------------------------

    private static Stream<Arguments> filterLinesTestCases() {
        return Stream.of(
                Arguments.of(
                        "keepLines",
                        "{\"операции\": [{\"оп\": \"оставить_строки\", \"шаблон\": \"ERROR\"}]}",
                        "INFO: ok\nERROR: fail\nDEBUG: skip",
                        "ERROR: fail"
                ),
                Arguments.of(
                        "removeLines",
                        "{\"операции\": [{\"оп\": \"удалить_строки\", \"шаблон\": \"\\\\[INFO\\\\]\"}]}",
                        "[INFO] start\n[WARN] middle\n[INFO] end",
                        "[WARN] middle"
                )
        );
    }

    @MethodSource("filterLinesTestCases")
    @ParameterizedTest(name = "filterLines: {0}")
    @SuppressWarnings("java:S4144")
    void testFilterLines(String label, String rules, String input, String expected) {
        var node = node(rules, input);
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals(expected, result.trim());
    }

    // ---------------------------------------------------------------
    // jsonField — простой путь и вложенный
    // ---------------------------------------------------------------

    private static Stream<Arguments> jsonFieldTestCases() {
        return Stream.of(
                Arguments.of(
                        "simpleField",
                        "{\"операции\": [{\"оп\": \"json_поле\", \"путь\": \"name\"}]}",
                        "{\"name\": \"Alice\", \"age\": 30}",
                        "Alice"
                ),
                Arguments.of(
                        "nestedPath",
                        "{\"операции\": [{\"оп\": \"json_поле\", \"путь\": \"address.city\"}]}",
                        "{\"address\": {\"city\": \"Moscow\"}}",
                        "Moscow"
                )
        );
    }

    @MethodSource("jsonFieldTestCases")
    @ParameterizedTest(name = "jsonField: {0}")
    void testJsonField_allPaths(String label, String rules, String input, String expected) {
        var node = node(rules, input);
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals(expected, result);
    }

    // ---------------------------------------------------------------
    // substring — взять_символы: defaults / range / clamp
    // ---------------------------------------------------------------

    private static Stream<Arguments> substringTestCases() {
        return Stream.of(
                Arguments.of(
                        "defaultsToFull",
                        "{\"операции\": [{\"оп\": \"взять_символы\"}]}",
                        "Hello World",
                        "Hello World",
                        null, null
                ),
                Arguments.of(
                        "range",
                        "{\"операции\": [{\"оп\": \"взять_символы\", \"от\": 0, \"до\": 5}]}",
                        "Hello World",
                        "Hello",
                        0, 5
                ),
                Arguments.of(
                        "clampsToBounds",
                        "{\"операции\": [{\"оп\": \"взять_символы\", \"от\": -5, \"до\": 200}]}",
                        "Short",
                        "Short",
                        -5, 200
                )
        );
    }

    @MethodSource("substringTestCases")
    @ParameterizedTest(name = "substring: {0}")
    void testSubstring(String label, String rules, String input, String expected, Integer from, Integer to) {
        var node = node(rules, input);
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals(expected, result);
    }

    // ---------------------------------------------------------------
    // headTail — первые / последние / defaultN
    // ---------------------------------------------------------------

    private static Stream<Arguments> headTailTestCases() {
        return Stream.of(
                Arguments.of(
                        "firstLines",
                        "{\"операции\": [{\"оп\": \"первые_строки\", \"n\": 2}]}",
                        "a\nb\nc\nd",
                        "a\nb"
                ),
                Arguments.of(
                        "lastLines",
                        "{\"операции\": [{\"оп\": \"последние_строки\", \"n\": 2}]}",
                        "a\nb\nc\nd",
                        "c\nd"
                ),
                Arguments.of(
                        "defaultN",
                        "{\"операции\": [{\"оп\": \"первые_строки\"}]}",
                        "a\nb\nc\nd\ne\nf\ng\nh\ni\nj\nk\nl",
                        "a\nb\nc\nd\ne\nf\ng\nh\ni\nj"
                )
        );
    }

    @MethodSource("headTailTestCases")
    @ParameterizedTest(name = "headTail: {0}")
    @SuppressWarnings("java:S4144")
    void testHeadTail(String label, String rules, String input, String expected) {
        var node = node(rules, input);
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals(expected, result);
    }

    // ---------------------------------------------------------------
    // chain / docList — уникальные сценарии
    // ---------------------------------------------------------------

    private static Stream<Arguments> advancedTestCases() {
        return Stream.of(
                Arguments.of(
                        "chainedOperations",
                        "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"},{\"оп\": \"заменить\", \"найти\": \"123\", \"на\": \"999\"}]}",
                        "id: 123",
                        "999",
                        false, null
                ),
                Arguments.of(
                        "usesDocListWhenDocIdsPresent",
                        "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"\\\\d+\"}]}",
                        null,
                        "12345",
                        true, "doc1"
                )
        );
    }

    @MethodSource("advancedTestCases")
    @ParameterizedTest(name = "advanced: {0}")
    void testAdvanced(String label, String rules, String input, String expected, boolean useDocList, String docId) {
        ScenarioRunNode node;
        if (useDocList && docId != null) {
            var dto = NodeDto.builder()
                    .id("t1")
                    .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                    .data(NodeDataDto.builder()
                            .label("Док")
                            .rules(rules)
                            .build())
                    .position(new PositionDto(0, 0))
                    .build();
            var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
            graph.setRunnerUserId("user-1");
            node = graph.getNodeMap().get("t1");
            node.getDocList().add(docId);
            graph.getDocMap().put(docId, new ScenarioRunDoc("file.txt", "Текст с номером 12345"));
        } else {
            node = node(rules, input);
        }
        var exec = new ScenarioExecutorTransformNode(node);
        String result = exec.execute(sink);

        assertEquals(expected, result.trim());
    }

    // ---------------------------------------------------------------
    // error cases → ScenarioException
    // ---------------------------------------------------------------

    private static Stream<Arguments> errorCases() {
        return Stream.of(
                Arguments.of(
                        "unknownOperation",
                        "{\"операции\": [{\"оп\": \"неизвестная\"}]}"
                ),
                Arguments.of(
                        "emptyOperations",
                        "{\"операции\": []}"
                ),
                Arguments.of(
                        "noOperations",
                        "{}"
                ),
                Arguments.of(
                        "badRegex",
                        "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"[\"}]}"
                )
        );
    }

    @MethodSource("errorCases")
    @ParameterizedTest(name = "error: {0}")
    void testErrorCases_throwsScenarioException(String label, String rules) {
        var node = node(rules, "текст");
        var exec = new ScenarioExecutorTransformNode(node);

        assertThrows(ScenarioException.class, () -> exec.execute(sink));
    }
}