package ru.sber.cs.ai.gigame.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import ru.sber.cs.ai.gigame.TestConfiguration;
import ru.sber.cs.ai.gigame.dto.kb.KBCreate;
import ru.sber.cs.ai.gigame.dto.kb.KBDetailResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.exception.ApplicationErrorHandler;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.service.DocumentIndexService;
import ru.sber.cs.ai.gigame.service.KBService;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {
        KnowledgeBaseController.class,
        DocumentIndexService.class,
        TestConfiguration.class,
        ApplicationErrorHandler.class
})
@WebFluxTest(controllers = KnowledgeBaseController.class)
@SuppressWarnings("unused")
class KnowledgeBaseControllerTest {

    @Autowired
    private WebTestClient webClient;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private KBService kbService;

    @MockitoBean
    private DocumentIndexService indexService;

    private UUID userId;
    private UUID kbId;
    private UUID docId;
    private KBResponse kbResponse;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        docId = UUID.randomUUID();
        kbResponse = new KBResponse(
                kbId,
                "Test KB",
                "Description",
                false,
                true,
                OffsetDateTime.now(),
                OffsetDateTime.now()
        );
    }

    @Test
    void testListKnowledgeBases() {
        when(kbService.getKnowledgeBases("")).thenReturn(List.of(kbResponse));

        webClient.get()
                .uri("/api/knowledge-bases")
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(List.class);
    }

    @Test
    void testListKnowledgeBases_withSearch() {
        when(kbService.getKnowledgeBases("test")).thenReturn(List.of(kbResponse));

        webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/api/knowledge-bases")
                        .queryParam("q", "test")
                        .build())
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void testCreateKnowledgeBase() {
        KBCreate body = new KBCreate("New KB", "New description", null);
        when(kbService.createKnowledgeBase("New KB", "New description", null))
                .thenReturn(kbResponse);

        webClient.post()
                .uri("/api/knowledge-bases")
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(KBResponse.class);
    }

    @Test
    void testGetKnowledgeBase() {
        KBDetailResponse result = new KBDetailResponse(
                kbId,
                "Test KB",
                "Description",
                false,
                true,
                OffsetDateTime.now(),
                OffsetDateTime.now(),
                List.of()
        );

        when(kbService.getKnowledgeBase(kbId)).thenReturn(result);

        webClient.get()
                .uri("/api/knowledge-bases/{id}", kbId)
                .header("X-UserId", userId.toString())
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(KBDetailResponse.class);
    }

    @Test
    void testUpdateKnowledgeBase() {
        KBCreate body = new KBCreate("Updated KB", "Updated description", null);
        when(kbService.updateKnowledgeBase(kbId, "Updated KB", "Updated description", null))
                .thenReturn(kbResponse);

        webClient.put()
                .uri("/api/knowledge-bases/{id}", kbId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(body)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(KBResponse.class);
    }

    @Test
    void testDeleteKnowledgeBase() {
        doNothing().when(kbService).deleteKnowledgeBase(kbId);

        webClient.delete()
                .uri("/api/knowledge-bases/{id}", kbId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isNoContent();
    }

    @Test
    void testUploadDocumentToKB_success() {
        UUID kbDocId = UUID.randomUUID();
        KBDocumentResponse result = new KBDocumentResponse(
                kbDocId,
                docId,
                "test.pdf",
                "application/pdf",
                1024,
                5,
                "processing",
                null,
                OffsetDateTime.now()
        );

        when(kbService.addDocumentToKB(eq(kbId), any()))
                .thenReturn(result);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new ByteArrayResource("test content".getBytes()) {
            @Override
            public String getFilename() {
                return "test.pdf";
            }
        });

        webClient.post()
                .uri("/api/knowledge-bases/{id}/documents", kbId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(KBDocumentResponse.class);
    }

    @Test
    void testUploadDocumentToKB_notFound() {
        when(kbService.addDocumentToKB(eq(kbId), any()))
                .thenThrow(new NotFoundException("Knowledge base not found: " + kbId));

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new ByteArrayResource("test content".getBytes()) {
            @Override
            public String getFilename() {
                return "test.pdf";
            }
        });

        webClient.post()
                .uri("/api/knowledge-bases/{id}/documents", kbId)
                .header("X-UserId", userId.toString())
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(body))
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void testReindexDocument_success() {
        UUID kbDocId = UUID.randomUUID();
        KBDocumentResponse result = new KBDocumentResponse(
                kbDocId,
                docId,
                "test.pdf",
                "application/pdf",
                1024,
                10,
                "ready",
                null,
                OffsetDateTime.now()
        );

        when(indexService.reindexDocument(kbId, docId))
                .thenReturn(result);

        webClient.post()
                .uri("/api/knowledge-bases/{id}/documents/{docId}/reindex", kbId, docId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(KBDocumentResponse.class);
    }

    @Test
    void testReindexDocument_notFound() {
        when(indexService.reindexDocument(kbId, docId))
                .thenThrow(new NotFoundException(
                        "Документ базы знаний не найден: kbId=" + kbId + " docId=" + docId));

        webClient.post()
                .uri("/api/knowledge-bases/{id}/documents/{docId}/reindex", kbId, docId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void testRemoveDocumentFromKB_success() {
        doNothing().when(kbService).removeDocumentFromKB(kbId, docId);

        webClient.delete()
                .uri("/api/knowledge-bases/{id}/documents/{docId}", kbId, docId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isNoContent();
    }

    @Test
    void testRemoveDocumentFromKB_notFound() {
        doThrow(new NotFoundException(
                "Документ базы знаний не найден: kbId=" + kbId + " docId=" + docId))
                .when(kbService).removeDocumentFromKB(kbId, docId);

        webClient.delete()
                .uri("/api/knowledge-bases/{id}/documents/{docId}", kbId, docId)
                .header("X-UserId", userId.toString())
                .exchange()
                .expectStatus().isNotFound();
    }
}
