package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ScenarioExecutorLoopNodeTest {

    private GigaChatClient gigaChatClient;

    @BeforeEach
    void setUp() {
        gigaChatClient = mock(GigaChatClient.class);
    }

    // ================================================================
    // Helpers
    // ================================================================

    private ScenarioRunGraph createGraphWithDocs(NodeDataDtoBuilder builder,
                                                 List<String> docTexts,
                                                 List<String> filenames) {
        var dto = builder.build();
        var nodeDto = NodeDto.builder()
                .id("loop-1")
                .type(ScenarioNodeType.LOOP_NODE.toString())
                .data(dto)
                .position(new PositionDto(100, 100))
                .build();
        var graphData = new GraphDataDto(
                List.of(nodeDto), List.of()
        );
        var graph = new ScenarioRunGraph(graphData);
        graph.setRunnerUserId("user-1");
        if (docTexts != null && !docTexts.isEmpty()) {
            graph.addDocs(docTexts, filenames);
            var node = graph.getNodeMap().get("loop-1");
            for (int i = 0; i < docTexts.size(); i++) {
                node.getDocList().add("DOC_" + (i + 1));
            }
        }
        return graph;
    }

    private ScenarioRunGraph createGraphWithClassifyStrict(List<String> docTexts,
                                                           List<String> filenames) {
        return createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .classifyStrict("true").classes("ТЗ,КП"),
                docTexts, filenames);
    }

    private static class NodeDataDtoBuilder {
        private String label;
        private String mode;
        private String prompt;
        private String classifyStrict;
        private String classes;
        private String value;

        NodeDataDtoBuilder label(String v) {
            this.label = v;
            return this;
        }

        NodeDataDtoBuilder mode(String v) {
            this.mode = v;
            return this;
        }

        NodeDataDtoBuilder prompt(String v) {
            this.prompt = v;
            return this;
        }

        NodeDataDtoBuilder classifyStrict(String v) {
            this.classifyStrict = v;
            return this;
        }

        NodeDataDtoBuilder classes(String v) {
            this.classes = v;
            return this;
        }

        NodeDataDtoBuilder value(String v) {
            this.value = v;
            return this;
        }

        NodeDataDto build() {
            return NodeDataDto.builder()
                    .label(label).mode(mode).prompt(prompt)
                    .classifyStrict(classifyStrict).classes(classes)
                    .value(value)
                    .build();
        }
    }

    // ================================================================
    // Constructor
    // ================================================================

    @Test
    void testConstructor_withGigaChatClient() {
        var graph = createGraphWithClassifyStrict(List.of("text"), List.of("f.pdf"));
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);
        assertNotNull(executor);
    }

    @Test
    void testConstructor_withoutGigaChatClient() {
        var graph = createGraphWithClassifyStrict(List.of("text"), List.of("f.pdf"));
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node);
        assertNotNull(executor);
    }

    // ================================================================
    // setDelayBetweenIterations
    // ================================================================

    @Test
    void testSetDelayBetweenIterations() {
        var graph = createGraphWithClassifyStrict(List.of("text"), List.of("f.pdf"));
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);
        ReflectionTestUtils.setField(executor, "delayBetweenIterations", 500);
        assertEquals(500, ReflectionTestUtils.getField(executor, "delayBetweenIterations"));
    }

    // ================================================================
    // execute - classify_strict = true
    // ================================================================

    @Test
    void testExecute_classifyStrictWithDocs() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ТЗ");
        var graph = createGraphWithClassifyStrict(
                List.of("Text of doc 1", "Text of doc 2"),
                List.of("doc1.pdf", "doc2.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("<<<DOC_1|CLASS:ТЗ>>>"));
        assertTrue(result.contains("<<<DOC_2|CLASS:ТЗ>>>"));
        assertTrue(result.contains("Text of doc 1"));
        assertTrue(result.contains("Text of doc 2"));
        assertTrue(result.contains("<<<END_DOC_1>>>"));
        assertTrue(result.contains("<<<END_DOC_2>>>"));
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_classifyStrict_setsDocClassOnDocuments() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ТЗ");
        var graph = createGraphWithClassifyStrict(
                List.of("Some procurement text"),
                List.of("doc1.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        executor.execute(null);

        ScenarioRunDoc doc = graph.getDocMap().get("DOC_1");
        assertNotNull(doc);
        assertEquals("ТЗ", doc.getDocClass());
    }

    @ParameterizedTest
    @MethodSource("classifyStrictFallbackTestCaseProvider")
    void testExecute_classifyStrict_fallbackCases(String gigaChatResponse, String expectedClass) {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn(gigaChatResponse);
        var graph = createGraphWithClassifyStrict(
                List.of("Some text"),
                List.of("doc1.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1|CLASS:" + expectedClass + ">>>"));
    }

    static Stream<Arguments> classifyStrictFallbackTestCaseProvider() {
        return Stream.of(
                Arguments.of("Этот документ относится к классу Техническое Задание (ТЗ)", "ТЗ"),
                Arguments.of("Some random response that doesnt match any class", "UNKNOWN"),
                Arguments.of("", "UNKNOWN"),
                Arguments.of(null, "UNKNOWN")
        );
    }

    @Test
    void testExecute_classifyStrict_includesUserPromptInClassificationPrompt() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ТЗ");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .prompt("Пользовательская инструкция")
                        .classifyStrict("true").classes("ТЗ,КП"),
                List.of("Some text"),
                List.of("doc1.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        executor.execute(null);

        verify(gigaChatClient).chatCompletion(anyList(), any(), any());
    }

    // ================================================================
    // execute - classify_strict = false (full analysis mode)
    // ================================================================

    @Test
    void testExecute_analysisModeWithDocs() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Analysis result content");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .prompt("Analyze this document").classifyStrict(""),
                List.of("Doc one content", "Doc two content"),
                List.of("file1.pdf", "file2.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("Документ DOC_1:"));
        assertTrue(result.contains("Документ DOC_2:"));
        assertTrue(result.contains("Analysis result content"));
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_analysisMode_singleDoc() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Single analysis");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .prompt("Analyze").classifyStrict("false"),
                List.of("Only one doc"),
                List.of("single.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertTrue(result.contains("Документ DOC_1:"));
        assertTrue(result.contains("Single analysis"));
        verify(gigaChatClient, times(1)).chatCompletion(anyList(), any(), any());
    }

    // ================================================================
    // execute - empty doc list (analyzeSimple path)
    // ================================================================

    @Test
    void testExecute_analyzeSimple_whenNoDocsAndInputPresent() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Simple result");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .prompt("Process input").classifyStrict("false"),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        node.getInput().add("Input text content");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("Simple result"));
        verify(gigaChatClient, times(1)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_analyzeSimple_whenNoDocsAndNoInput() {
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .prompt("Process").classifyStrict("false"),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(gigaChatClient, times(0)).chatCompletion(anyList(), any(), any());
    }

    // ================================================================
    // execute - output propagation
    // ================================================================

    @Test
    void testExecute_storesOutputInNode() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ТЗ");
        var graph = createGraphWithClassifyStrict(
                List.of("Some text"),
                List.of("doc1.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        executor.execute(null);

        assertFalse(node.getOutput().isEmpty());
        assertTrue(node.getOutput().get(0).contains("<<<DOC_1|CLASS:ТЗ>>>"));
    }

    @Test
    void testExecute_passesOutputToChildNodes() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("RESULT");
        var graph = createGraphWithClassifyStrict(
                List.of("Some text"),
                List.of("doc1.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        var childNode = ScenarioRunNode.fromDto(1, childDto, graph);
        graph.getNodeMap().put("child-1", childNode);
        node.getChildNodeList().add(childNode);

        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        executor.execute(null);

        assertFalse(childNode.getInput().isEmpty());
        assertTrue(childNode.getInput().get(0).contains("Loop"));
    }

    // ================================================================
    // execute - classify_strict with various class matching
    // ================================================================

    @Test
    void testExecute_classifyStrictWithEmptyClassesHint() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("ТЗ");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .classifyStrict("true").classes(""),
                List.of("Some text"),
                List.of("doc1.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);
        String result = executor.execute(null);
        assertTrue(result.contains("<<<DOC_1|CLASS:>>>"));
    }

    @ParameterizedTest
    @MethodSource("classifyStrictTestCaseProvider")
    void testExecute_classifyStrict_withVariousCases(String gigaChatResponse, String expectedClass) {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn(gigaChatResponse);
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .classifyStrict("true").classes("ТЗ,КП"),
                List.of("Some text"),
                List.of("doc1.pdf")
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertTrue(result.contains("<<<DOC_1|CLASS:" + expectedClass + ">>>"));
    }

    static Stream<Arguments> classifyStrictTestCaseProvider() {
        return Stream.of(
                Arguments.of("техническое задание (тз)", "ТЗ"),
                Arguments.of("КП (коммерческое предложение)", "КП"),
                Arguments.of("", "UNKNOWN")
        );
    }

    // ================================================================
    // execute - analysis mode on empty doc list
    // ================================================================

    @Test
    void testExecute_analysisMode_emptyDocs() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("Analysis");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("all")
                        .prompt("Analyze").classifyStrict(""),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // ================================================================
    // execute - list mode (executeOverList)
    // ================================================================

    @Test
    void testExecute_listMode_withMultipleItems() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("res-1", "res-2");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("list")
                        .prompt("Process items").classifyStrict("false"),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        // Input is joined by \n\n, then splitItems splits by default delimiter "---"
        node.getInput().add("Item A\n---\nItem B");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertNotNull(result);
        assertTrue(result.contains("Элемент 1:\nres-1"), "Expected first item in result");
        assertTrue(result.contains("Элемент 2:\nres-2"), "Expected second item in result");
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_listMode_with_singleItem() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("single-result");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("list")
                        .prompt("Process").classifyStrict("false"),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        node.getInput().add("Only one item");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertTrue(result.contains("Элемент 1:\nsingle-result"));
        verify(gigaChatClient, times(1)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_listMode_withCustomDelimiter() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("custom-1", "custom-2");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("list")
                        .prompt("Process").value("~~").classifyStrict("false"),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        node.getInput().add("First part~~Second part");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        String result = executor.execute(null);

        assertTrue(result.contains("Элемент 1:\ncustom-1"));
        assertTrue(result.contains("Элемент 2:\ncustom-2"));
        verify(gigaChatClient, times(2)).chatCompletion(anyList(), any(), any());
    }

    @Test
    void testExecute_listMode_storesOutputInNode() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("processed-item");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("list")
                        .prompt("Process").classifyStrict("false"),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        node.getInput().add("Test item");
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        executor.execute(null);

        assertFalse(node.getOutput().isEmpty(), "Node output should be populated");
        assertTrue(node.getOutput().get(0).contains("Элемент 1:\nprocessed-item"),
                "Output should contain processed item");
    }

    @Test
    void testExecute_listMode_passesOutputToChildNodes() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("result");
        var graph = createGraphWithDocs(
                new NodeDataDtoBuilder().label("Loop").mode("list")
                        .prompt("Process").classifyStrict("false"),
                List.of(), List.of()
        );
        var node = graph.getNodeMap().get("loop-1");
        node.getInput().add("Input");

        var childDto = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        var childNode = ScenarioRunNode.fromDto(1, childDto, graph);
        graph.getNodeMap().put("child-1", childNode);
        node.getChildNodeList().add(childNode);
        var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);

        executor.execute(null);

        assertFalse(childNode.getInput().isEmpty(), "Child node should receive input");
        assertTrue(childNode.getInput().get(0).contains("Loop"),
                "Child should receive the loop results in context");
    }
}