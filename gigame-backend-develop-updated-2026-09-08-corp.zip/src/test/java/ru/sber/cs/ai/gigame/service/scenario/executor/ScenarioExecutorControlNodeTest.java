package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.mockito.Mockito.mock;

/**
 * Тесты узла «Контроль» — детерминированная проверка условия с остановкой
 * сценария при нарушении.
 */
class ScenarioExecutorControlNodeTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    // ---------------------------------------------------------------
    // Constructor
    // ---------------------------------------------------------------

    @Test
    void testConstructor() {
        var node = makeNode("Сontrol", null, "contains", "value", null);
        var executor = new ScenarioExecutorControlNode(node);
        assertNotNull(executor);
    }

    // ---------------------------------------------------------------
    // condition met → passes through (all operators)
    // ---------------------------------------------------------------

    static Stream<Arguments> matchProvider() {
        return Stream.of(
                arguments("contains", "test", "This is a test"),
                arguments("contains", "ТЕСТ", "кириллица ТЕСТ"), // case-insensitive
                arguments("contains", "", "anything → always OK"),
                arguments("equals", "exact", "exact"),
                arguments("not_contains", "nomatch", "This is a test"),
                arguments("greater_than", "5", "Value: 10"),
                arguments("less_than", "15", "Value: 10")
        );
    }

    @ParameterizedTest
    @MethodSource("matchProvider")
    void testConditionMet_passesThrough(String operator, String value, String input) {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .operator(operator)
                        .value(value)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        node.getInput().add(input);

        String result = new ScenarioExecutorControlNode(node).execute(sink);

        assertTrue(result.startsWith("✓"), "Should indicate passed check: " + result);
        assertFalse(node.getOutput().isEmpty());
    }

    // ---------------------------------------------------------------
    // condition NOT met → throws ScenarioException
    // ---------------------------------------------------------------

    static Stream<Arguments> failProvider() {
        return Stream.of(
                arguments("contains", "nomatch", "Different text"),
                arguments("not_contains", "test", "This is a test"),
                arguments("equals", "exact", "not exact"),
                arguments("greater_than", "15", "Value: 10"),
                arguments("less_than", "5", "Value: 10")
        );
    }

    @ParameterizedTest
    @MethodSource("failProvider")
    void testConditionNotMet_throws(String operator, String value, String input) {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .operator(operator)
                        .value(value)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        node.getInput().add(input);
        var executor = new ScenarioExecutorControlNode(node);
        assertThrows(ScenarioException.class, () -> executor.execute(sink),
                "Should throw «КОНТРОЛЬ: ...» when condition fails");
    }

    // ---------------------------------------------------------------
    // custom error message from prompt field
    // ---------------------------------------------------------------

    @Test
    void testCustomErrorMessage_usesPrompt() {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .prompt("Ручной режим отключён!")
                        .operator("contains")
                        .value("АВТОМАТ")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        // "ручной" не содержит "АВТОМАТ" → control fails с кастомным сообщением
        node.getInput().add("ручной режим");
        var executor = new ScenarioExecutorControlNode(node);
        var e = assertThrows(ScenarioException.class, () -> executor.execute(sink));
        assertTrue(e.getMessage().contains("Ручной режим отключён!"),
                "Should include custom message: " + e.getMessage());
    }

    @Test
    void testDefaultMessage_whenPromptIsBlank() {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .operator("contains")
                        .value("missing")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        node.getInput().add("test");
        var executor = new ScenarioExecutorControlNode(node);
        var e = assertThrows(ScenarioException.class, () -> executor.execute(sink));
        assertTrue(e.getMessage().contains("Контроль не пройден"),
                "Should use default message: " + e.getMessage());
    }

    // ---------------------------------------------------------------
    // field filtering — проверка по полю
    // ---------------------------------------------------------------

    @Test
    void testFieldFiltering_matches_ok() {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .field("status")
                        .operator("contains")
                        .value("OK")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        node.getInput().add("status: OK\nother: data");

        String result = new ScenarioExecutorControlNode(node).execute(sink);
        assertTrue(result.startsWith("✓"));
    }

    @Test
    void testFieldFiltering_missing_throws() {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .field("status")
                        .operator("contains")
                        .value("ERROR")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        node.getInput().add("status: OK\nother: data");
        var executor = new ScenarioExecutorControlNode(node);
        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    // ---------------------------------------------------------------
    // numeric comparison edge cases
    // ---------------------------------------------------------------

    @Test
    void testNumericComparison_noNumbers_returnsFalse() {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .operator("greater_than")
                        .value("5")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        node.getInput().add("No numbers at all");
        var executor = new ScenarioExecutorControlNode(node);
        assertThrows(ScenarioException.class, () -> executor.execute(sink));
    }

    @Test
    void testNumeric_decimalComma() {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .operator("greater_than")
                        .value("10")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        node.getInput().add("Сумма: 10,5");

        // 10,5 < 10 → false (val=10.5 > 10 → true)
        // Actually 10.5 > 10 is true → doesn't throw
        assertDoesNotThrow(() -> new ScenarioExecutorControlNode(node).execute(sink));
    }

    // ---------------------------------------------------------------
    // input propagation — вход передаётся детям
    // ---------------------------------------------------------------

    @Test
    void testInputPropagatedToChildNodes_onPass() {
        var parent = NodeDto.builder()
                .id("parent")
                .type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Parent").build())
                .position(new PositionDto(0, 0))
                .build();
        var ctrl = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .operator("contains")
                        .value("test")
                        .build())
                .position(new PositionDto(100, 100))
                .build();
        var child = NodeDto.builder()
                .id("child-1")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Child").build())
                .position(new PositionDto(200, 100))
                .build();
        var edges = List.of(
                new EdgeDto("e0", "parent", "ctrl-1", new EdgeDataDto(null)),
                new EdgeDto("e1", "ctrl-1", "child-1", new EdgeDataDto(null))
        );
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(parent, ctrl, child), edges));
        graph.setRunnerUserId("user-1");
        var ctrlNode = graph.getNodeMap().get("ctrl-1");
        ctrlNode.getInput().add("test content");

        String result = new ScenarioExecutorControlNode(ctrlNode).execute(sink);
        assertTrue(result.startsWith("✓"));

        // Input should be propagated to child
        var childNode = graph.getNodeMap().get("child-1");
        assertFalse(childNode.getInput().isEmpty(),
                "Child should receive input from control node");
        assertEquals("test content", childNode.getInput().get(0),
                "Child input should match control node input");
    }

    // ---------------------------------------------------------------
    // docList handling — empty input + docs
    // ---------------------------------------------------------------

    @Test
    void testUsesDocsWhenInputEmpty() {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Контроль")
                        .operator("contains")
                        .value("документ")
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("ctrl-1");
        // No input, but has docList → uses docMap
        graph.getDocMap().put("DOC_1", new ScenarioRunDoc("file.txt", "текст из документа"));
        node.getDocList().add("DOC_1");

        String result = new ScenarioExecutorControlNode(node).execute(sink);
        assertTrue(result.startsWith("✓"),
                "Should read from docMap when input is empty: " + result);
    }

    // ---------------------------------------------------------------
    // Helper — минимальный узел
    // ---------------------------------------------------------------

    private static ScenarioRunNode makeNode(String label, String field,
                                            String operator, String value,
                                            String prompt) {
        var dto = NodeDto.builder()
                .id("ctrl-1")
                .type(ScenarioNodeType.CONTROL_NODE.toString())
                .data(NodeDataDto.builder()
                        .label(label)
                        .field(field)
                        .operator(operator)
                        .value(value)
                        .prompt(prompt)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(
                new GraphDataDto(List.of(dto), List.of())
        );
        graph.setRunnerUserId("user-1");
        return graph.getNodeMap().get("ctrl-1");
    }
}