package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Тесты новых операций узла «Трансформация»: пустые массивы и дедупликация
 * в «слить_json_массивы», «проверить_цитаты», «сверить_суммы»,
 * «извлечь_из_документов».
 */
class ScenarioExecutorTransformNodeOpsTest {

    private static final String EXCLUDE_RULES = "{\"операции\": [{\"оп\": \"слить_json_массивы\", "
            + "\"исключить_типы\": {\"по_узлу\": \"Способ закупки\", "
            + "\"если_не_содержит\": \"единственн|неконкурентн\", "
            + "\"типы\": [\"обоснование выбора единственного поставщика\"]}}]}";

    private static final String EP_FINDINGS = """
            [{"номер": 1, "тип": "обоснование выбора единственного поставщика", "цитата": "ЕП-цитата"},
             {"номер": 2, "тип": "расхождение сумм между документами", "цитата": "суммы"}]
            """;

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private static ScenarioRunGraph graph(String rules) {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Трансформация")
                        .rules(rules)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        return graph;
    }

    @Test
    void mergeAcceptsEmptyArrays() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("{\"находки\": []} и ещё {\"находки\": []}");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("[ ]", result.trim().replaceAll("\\s+", " "));
    }

    @Test
    void mergeDeduplicatesByConfiguredKeys() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\", "
                + "\"дедуп_по\": [\"тип\", \"цитата\"]}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "бренд", "цитата": "HP 100"}]
                [{"номер": 2, "тип": "Бренд", "цитата": " hp 100 "},
                 {"номер": 3, "тип": "сроки", "цитата": "7 дней"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals(2, result.split("\"цитата\"").length - 1);
        assertTrue(result.contains("7 дней"));
    }

    @Test
    void verifyCitationsMarksFoundAndAbsenceFindings() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(
                List.of("Техническое задание. Поставка серверов HP ProLiant 380 в сборе."),
                List.of("ТЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "бренд", "цитата": "Поставка серверов HP ProLiant 380"},
                 {"номер": 2, "тип": "нмц", "цитата": "Отсутствует обоснование НМЦ"},
                 {"номер": 3, "тип": "фантом", "цитата": "Все участники обязаны молчать о ценах"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"точно\""));
        assertTrue(result.contains("ТЗ.docx"));
        assertTrue(result.contains("н/п (об отсутствии)"));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void compareAmountsReportsValuesPerDocument() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_суммы\", \"метка\": \"НМЦД?\"}]}");
        graph.addDocs(
                List.of("Пояснительная. НМЦД составляет 289523339,14 руб.",
                        "Раздел обоснования. НМЦД: 349669037,34 руб."),
                List.of("ПЗ.docx", "Обоснование.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("289523339.14"));
        assertTrue(result.contains("349669037.34"));
        assertTrue(result.contains("Различных значений: 2"));
    }

    @Test
    void extractFromDocsPrefersMatchingFilenames() {
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", "
                + "\"имя\": \"ПЗ|[Ии]звещени\", "
                + "\"шаблон\": \"Способ закупки[\\\\s:|]*\\\\n?\\\\s*([^\\\\n|>]{4,120})\"}]}");
        graph.addDocs(
                List.of("Протокол 2022. Способ закупки\nЗакупка у единственного поставщика",
                        "ПЗ текущая. Способ закупки\nАдресный запрос предложений"),
                List.of("Протокол-2022.pdf", "ПЗ рамка.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Адресный запрос предложений"));
        assertTrue(result.contains("ПЗ рамка.docx"));
        assertFalse(result.contains("единственного"));
    }

    @Test
    void extractFromDocsFallsBackToOtherDocuments() {
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", "
                + "\"имя\": \"[Ии]звещени\", "
                + "\"шаблон\": \"Способ закупки[\\\\s:|]*\\\\n?\\\\s*([^\\\\n|>]{4,120})\"}]}");
        graph.addDocs(
                List.of("Документация. Способ закупки\nОткрытый конкурс"),
                List.of("Документация.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Открытый конкурс"));
    }

    @Test
    void checkPercentagesFlagsMismatchAndAcceptsCorrectValue() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_проценты\"}]}");
        graph.addDocs(
                List.of("НМЦ закупки составляет 1770719375,04 рублей. "
                        + "Размер обеспечения договора не более 1 % от НМЦ договора – "
                        + "2 500 000,00 руб. "
                        + "Аванс составляет 10 % от цены договора: 177 071 937,50 руб."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // 1% от 1,77 млрд = 17,7 млн, а указано 2,5 млн — расхождение попадает в отчёт
        assertTrue(result.contains("расхождение"));
        assertTrue(result.contains("17707193.75"));
        // корректный аванс (ровно 10%) расхождением не считается
        assertFalse(result.contains("177071937.50, но"));
    }

    @Test
    void checkPercentagesSkipsWhenBaseMissing() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_проценты\"}]}");
        graph.addDocs(List.of("Обеспечение 5 % — 100 000,00 руб., базы нет."),
                List.of("Письмо.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("проверка пропущена"));
    }

    @Test
    void compareDatesFlagsContractSignedAfterServicePeriodStart() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\"}]}");
        graph.addDocs(
                List.of("Был заключен новый договор № 72/5619206 от 12.05.2026 на оказание "
                                + "услуг на период с 01.01.2026 по 31.05.2026.",
                        "Договор № 7 от 10.01.2026, срок оказания услуг с 15.01.2026."),
                List.of("ПЗ.docx", "Договор7.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("12.05.2026"));
        assertTrue(result.contains("раньше заключения договора"));
        // корректный договор (подписан до начала услуг) в отчёт не попадает
        assertFalse(result.contains("Договор7.docx"));
    }

    @Test
    void compareDatesHandlesReversedPhraseOrder() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\"}]}");
        graph.addDocs(
                List.of("Ввиду необходимости непрерывности оказания услуг на период "
                        + "с 01.01.2026г. по 31.05.2026 (на время подготовки документов) "
                        + "с поставщиком был заключен новый договор № 72/5619206 от 12.05.2026."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // период упомянут ДО договора — обратный порядок фраз тоже распознаётся
        assertTrue(result.contains("12.05.2026"));
        assertTrue(result.contains("01.01.2026"));
        assertTrue(result.contains("раньше заключения договора"));
    }

    @Test
    void compareDatesEmitsFindingsJsonForMergeNode() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\", "
                + "\"формат\": \"json_находки\"}]}");
        graph.addDocs(
                List.of("Договор № 72 от 12.05.2026 на оказание услуг, "
                        + "период оказания услуг с 01.01.2026 по 31.05.2026."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // формат «json_находки» — готовый вход для «слить_json_массивы» (свод)
        assertTrue(result.trim().startsWith("{"));
        assertTrue(result.contains("\"находки\""));
        assertTrue(result.contains("услуги до оформления договора"));
        assertTrue(result.contains("ПЗ.docx"));
    }

    @Test
    void mergeLimitsFindingsPerConfiguredType() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\", "
                + "\"лимит_типов\": {\"НМЦД против опроса рынка\": 1}}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "НМЦД против опроса рынка", "цитата": "первая"},
                 {"номер": 2, "тип": "НМЦД против опроса рынка", "цитата": "вторая"},
                 {"номер": 3, "тип": "сроки", "цитата": "третья"},
                 {"номер": 4, "тип": "сроки", "цитата": "четвёртая"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // лимитированный тип обрезан до одного вхождения, остальные не тронуты
        assertTrue(result.contains("первая"));
        assertFalse(result.contains("вторая"));
        assertTrue(result.contains("третья"));
        assertTrue(result.contains("четвёртая"));
    }

    /** Граф из transform-узла t1 и узла-донора с меткой «Способ закупки» и готовым выходом. */
    private static ScenarioRunGraph graphWithDonor(String rules, String donorOutput) {
        var transform = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Трансформация").rules(rules).build())
                .position(new PositionDto(0, 0))
                .build();
        var donor = NodeDto.builder()
                .id("t4")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Способ закупки").rules("{}").build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(transform, donor), List.of()));
        graph.getNodeMap().get("t4").getOutput().add(donorOutput);
        return graph;
    }

    @Test
    void mergeDropsExcludedTypesWhenDonorLacksCondition() {
        // способ закупки конкурентный — находка о единственном поставщике отбрасывается кодом
        var graph = graphWithDonor(EXCLUDE_RULES, "Адресный запрос предложений");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add(EP_FINDINGS);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertFalse(result.contains("ЕП-цитата"));
        assertTrue(result.contains("суммы"));
    }

    @Test
    void mergeKeepsExcludedTypesWhenDonorMatchesCondition() {
        // закупка у единственного поставщика — ЕП-находки уместны и остаются
        var graph = graphWithDonor(EXCLUDE_RULES, "Закупка у единственного поставщика");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add(EP_FINDINGS);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("ЕП-цитата"));
        assertTrue(result.contains("суммы"));
    }

    @Test
    void verifyCitationsChecksConfiguredFieldWithShortValues() {
        // таблица критериев: проверяется поле «значение», короткие даты допускаются мин_длиной 6
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\", \"поле\": \"значение\", \"мин_длина\": \"6\"}]}");
        graph.addDocs(List.of("12. Дата начала срока подачи заявок 17.09.2025. НМЦД 161560083 руб."),
                List.of("Извещение.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"критерий": "Дата начала срока подачи заявок", "значение": "17.09.2025"},
                 {"критерий": "Дата окончания срока подачи заявок", "значение": "23.04.2026"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // дата из документа найдена, выдуманная — помечена
        assertTrue(result.contains("\"17.09.2025\",\"документ\":\"Извещение.docx\"")
                || result.contains("\"точно\""));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void removeObjectsDropsAbsenceFindingsAfterCitationCheck() {
        // «отсутствие информации» с цитатой «нет информации» получает достоверность «об отсутствии» и отсекается кодом
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}, "
                + "{\"оп\": \"удалить_объекты\", \"поле\": \"достоверность\", \"шаблон\": \"об отсутствии\"}]}");
        graph.addDocs(List.of("Срок подачи заявок 5 дней с даты публикации извещения."), List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "сроки", "цитата": "Срок подачи заявок 5 дней с даты публикации"},
                 {"номер": 2, "тип": "гарантия", "цитата": "нет информации о независимой гарантии"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Срок подачи заявок"));
        assertFalse(result.contains("нет информации"));
    }

    @Test
    void removeObjectsHonoursAndCondition() {
        // строка риска без подтверждённой цитаты удаляется, строка паспорта с тем же признаком — остаётся
        var graph = graph("{\"операции\": [{\"оп\": \"удалить_объекты\", \"поле\": \"достоверность\", "
                + "\"шаблон\": \"НЕ НАЙДЕНА|коротка\", \"и_поле\": \"з4\", "
                + "\"и_шаблон\": \"^(ВЫСОКИЙ|СРЕДНИЙ|НИЗКИЙ)$\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"з1": "1", "з2": "Выдуманный риск", "з4": "ВЫСОКИЙ", "достоверность": "НЕ НАЙДЕНА"},
                 {"з1": "2", "з2": "Реальный риск", "з4": "СРЕДНИЙ", "достоверность": "точно"},
                 {"з1": "—", "з2": "Способ закупки: конкурс", "з4": "ПАСПОРТ", "достоверность": "цитата слишком коротка"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertFalse(result.contains("Выдуманный риск"));
        assertTrue(result.contains("Реальный риск"));
        assertTrue(result.contains("Способ закупки: конкурс"));
    }

    @Test
    void extractFromDocsCollectsAllMatches() {
        // НМЦД по лотам и итог из одной пояснительной записки — все суммы по порядку, без повторов
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", \"имя\": \"ПЗ\", "
                + "\"шаблон\": \"(\\\\d[\\\\d ]{5,20}[,.]\\\\d{2})\\\\s*руб\", \"группа\": 1, "
                + "\"все\": true, \"разделитель\": \"; \"}]}");
        graph.addDocs(List.of("НМЦД по Лоту 1 – 125486266,74 руб.; по Лоту 2 - 164037072,40 руб. "
                + "Итоговая сумма закупки составит: не более 289523339,14 руб., включая НДС; повтор 289523339,14 руб."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("125486266,74; 164037072,40; 289523339,14 [источник: ПЗ.docx]", result);
    }

    @Test
    void verifyCitationsRespectsDocumentNameFilter() {
        // цитата есть только в файле строк, который исключён из сверки — находка не подтверждается
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\", \"документы\": \"^(?!строки)\"}]}");
        graph.addDocs(List.of("Срок подачи заявок 5 дней с даты публикации извещения.",
                "[{\"цитата\": \"Исполнитель не вправе привлекать третьих лиц\"}]"),
                List.of("ПЗ.docx", "строки.txt"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "сроки", "цитата": "Срок подачи заявок 5 дней с даты публикации"},
                 {"номер": 2, "тип": "договор", "цитата": "Исполнитель не вправе привлекать третьих лиц"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"достоверность\" : \"точно\"") || result.contains("\"достоверность\":\"точно\""));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void setFieldTagsPassportRowsByRegex() {
        // строки паспорта, которым модель не поставила метку, получают з4=ПАСПОРТ кодом
        var graph = graph("{\"операции\": [{\"оп\": \"установить_поле\", \"поле\": \"з4\", "
                + "\"значение\": \"ПАСПОРТ\", \"если_поле\": \"з2\", \"шаблон\": \"^(Способ закупки|НМЦ/НМЦД):\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"з1": "—", "з2": "Способ закупки: конкурс", "з4": "—"},
                 {"з1": "1", "з2": "Короткий срок подачи заявок", "з4": "СРЕДНИЙ"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("ПАСПОРТ"));
        assertFalse(result.contains("\"з4\" : \"—\""));
        assertTrue(result.contains("СРЕДНИЙ"));
    }

    @Test
    void setFieldTakesValueFromDonorNodeUnlessExcluded() {
        // способ закупки в строке паспорта подставляется из узла-донора; при «не найдено» строка не трогается
        String rules = "{\"операции\": [{\"оп\": \"установить_поле\", \"поле\": \"з2\", "
                + "\"значение\": \"Способ закупки: \", \"значение_из_узла\": \"Способ закупки\", "
                + "\"кроме_значений\": \"не найдено\", \"если_поле\": \"з2\", \"шаблон\": \"^Способ закупки:\"}]}";
        var graph = graphWithDonor(rules, "Адресный запрос предложений [источник: ПЗ.docx]");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("[{\"з1\": \"—\", \"з2\": \"Способ закупки: закупка у ЕП\", \"з4\": \"ПАСПОРТ\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Способ закупки: Адресный запрос предложений [источник: ПЗ.docx]"));
        assertFalse(result.contains("закупка у ЕП"));

        var graph2 = graphWithDonor(rules, "не найдено");
        var node2 = graph2.getNodeMap().get("t1");
        node2.getInput().add("[{\"з1\": \"—\", \"з2\": \"Способ закупки: закупка у ЕП\", \"з4\": \"ПАСПОРТ\"}]");

        assertTrue(new ScenarioExecutorTransformNode(node2).execute(sink).contains("закупка у ЕП"));
    }

    @Test
    void mergeDedupStripsRegexBeforeComparing() {
        // одно требование из ПЗ и из формы документации («… (форма 4 Раздела 4)») схлопывается в одну строку
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\", \"дедуп_по\": [\"з2\"], "
                + "\"дедуп_регекс\": \"\\\\s*\\\\([^)]*\\\\)\\\\s*$\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"з1": "1", "з2": "Требование эксклюзивности к участникам закупки"},
                 {"з1": "10", "з2": "Требование эксклюзивности к участникам закупки (форма 4 Раздела 4)"},
                 {"з1": "2", "з2": "Требование к опыту работы на рынке"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertFalse(result.contains("форма 4 Раздела 4"));
        assertTrue(result.contains("Требование к опыту работы на рынке"));
    }

    @Test
    void verifyCitationsIgnoresExplanationAfterQuotedCore() {
        // находка кодовой проверки процентов: цитата в «…» + пояснение «, но 1% от базы = …» — подтверждается по ядру
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(List.of("Размер обеспечения договора составляет – не более 1% от начальной (максимальной) "
                + "цены договора – 2500000,00 рублей."), List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "расхождение процента и суммы",
                  "цитата": "«обеспечения … 1% … 2500000,00», но 1% от базы = 17707193.75 руб. — расхождение, проверить"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("по фрагментам"));
    }

    @Test
    void verifyCitationsAcceptsEllipsisFragmentsInOrder() {
        // составная цитата кодовой проверки процентов подтверждается по фрагментам, обратный порядок — нет
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(List.of("Размер обеспечения договора составляет – не более 1% от начальной (максимальной) "
                + "цены договора – 2500000,00 рублей."), List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "проценты", "цитата": "«обеспечения … 1% … 2500000,00»"},
                 {"номер": 2, "тип": "проценты", "цитата": "2500000,00 … обеспечения … 1%"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("по фрагментам"));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }
}
