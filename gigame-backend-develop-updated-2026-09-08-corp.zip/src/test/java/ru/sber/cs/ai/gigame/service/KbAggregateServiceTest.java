package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class KbAggregateServiceTest {

    @Mock
    private KBDocumentRepository kbDocumentRepository;

    @Mock
    private GigaChatClient gigaChatClient;

    private KbAggregateService service;

    private final UUID kbId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        service = new KbAggregateService(kbDocumentRepository, gigaChatClient);
        ReflectionTestUtils.setField(service, "enabled", true);
        ReflectionTestUtils.setField(service, "maxDocs", 200);
        ReflectionTestUtils.setField(service, "docCharLimit", 30000);
        ReflectionTestUtils.setField(service, "parallelism", 2);
    }

    private KBDocument kbDoc(String filename, String text) {
        Document doc = new Document();
        doc.setId(UUID.randomUUID());
        doc.setFilename(filename);
        doc.setExtractedText(text);
        KBDocument kbDocument = new KBDocument();
        kbDocument.setDocument(doc);
        kbDocument.setDocumentId(doc.getId());
        return kbDocument;
    }

    // ================================================================
    // Детектор интента
    // ================================================================

    @Test
    void testSumIntent_matchesAggregateQuestions() {
        assertTrue(KbAggregateService.isSumIntent("какая общая сумма по договорам?"));
        assertTrue(KbAggregateService.isSumIntent("посчитай суммарную стоимость всех договоров"));
        assertTrue(KbAggregateService.isSumIntent("сумма по всем актам"));
    }

    @Test
    void testSumIntent_ignoresPointQuestions() {
        assertFalse(KbAggregateService.isSumIntent("какая сумма в договоре 4373770?"));
        assertFalse(KbAggregateService.isSumIntent("что сказано про неустойку?"));
    }

    @Test
    void testListIntent_matchesCountAndListQuestions() {
        assertTrue(KbAggregateService.isListIntent("сколько всего договоров загружено?"));
        assertTrue(KbAggregateService.isListIntent("перечисли все документы"));
        assertTrue(KbAggregateService.isListIntent("какие документы есть в базе?"));
    }

    // ================================================================
    // tryAggregate — маршрутизация
    // ================================================================

    @Test
    void testTryAggregate_pointQuestion_returnsNull() {
        assertNull(service.tryAggregate(List.of(kbId), "что в договоре 5 про сроки?"));
    }

    @Test
    void testTryAggregate_disabled_returnsNull() {
        ReflectionTestUtils.setField(service, "enabled", false);
        assertNull(service.tryAggregate(List.of(kbId), "общая сумма по договорам"));
    }

    @Test
    void testTryAggregate_listQuestion_answersFromMetadataWithoutLlm() {
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(kbId))
                .thenReturn(List.of(kbDoc("договор1.pdf", "т1"), kbDoc("договор2.pdf", "т2")));

        var result = service.tryAggregate(List.of(kbId), "сколько всего договоров в базе?");

        assertTrue(result.context().contains("Всего документов: 2"));
        assertTrue(result.context().contains("договор1.pdf"));
        verify(gigaChatClient, never()).chatCompletion(anyList());
    }

    @Test
    void testTryAggregate_tooManyDocs_honestRefusal() {
        ReflectionTestUtils.setField(service, "maxDocs", 1);
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(kbId))
                .thenReturn(List.of(kbDoc("a.pdf", "т"), kbDoc("b.pdf", "т")));

        var result = service.tryAggregate(List.of(kbId), "общая сумма по договорам");

        assertTrue(result.context().contains("АГРЕГАЦИЯ НЕДОСТУПНА"));
        assertTrue(result.context().contains("сценарий"));
        verify(gigaChatClient, never()).chatCompletion(anyList());
    }

    // ================================================================
    // Map-reduce с цитатной валидацией
    // ================================================================

    @Test
    void testTryAggregate_sum_confirmedValuesSummedByCode() {
        String text1 = "Договор поставки. Цена договора составляет 1 000 000,50 руб. с НДС.";
        String text2 = "Договор услуг. Общая стоимость: 2 500 000,00 рублей.";
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(kbId))
                .thenReturn(List.of(kbDoc("д1.pdf", text1), kbDoc("д2.pdf", text2)));
        when(gigaChatClient.chatCompletion(argThat(msgs ->
                msgs != null && msgs.get(0).get("content").contains("д1.pdf"))))
                .thenReturn("{\"число\": 1000000.50, \"цитата\": \"Цена договора составляет 1 000 000,50 руб.\"}");
        when(gigaChatClient.chatCompletion(argThat(msgs ->
                msgs != null && msgs.get(0).get("content").contains("д2.pdf"))))
                .thenReturn("{\"число\": 2500000.00, \"цитата\": \"Общая стоимость: 2 500 000,00 рублей\"}");

        var result = service.tryAggregate(List.of(kbId), "какая общая сумма по договорам?");

        assertTrue(result.context().contains("ИТОГО: 3500000.50"),
                "итог должен быть посчитан кодом: " + result.context());
        assertEquals(2, result.sources().size());
    }

    @Test
    void testTryAggregate_sum_fabricatedQuoteRejected() {
        // модель выдумала число — цитаты нет в документе, значение отброшено
        String text = "Договор без сумм, реквизиты и предмет.";
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(kbId))
                .thenReturn(List.of(kbDoc("пустой.pdf", text)));
        when(gigaChatClient.chatCompletion(anyList()))
                .thenReturn("{\"число\": 999999, \"цитата\": \"Сумма 999 999 руб.\"}");

        var result = service.tryAggregate(List.of(kbId), "общая сумма по договорам");

        // ни одного подтверждённого значения — честное «не дала результата»,
        // а не вводящее в заблуждение «ИТОГО: 0»
        assertTrue(result.context().contains("НЕ ДАЛА РЕЗУЛЬТАТА"));
        assertFalse(result.context().contains("ИТОГО:"));
        assertEquals(0, result.sources().size());
    }

    @Test
    void testTryAggregate_sum_partialExtraction_missingListedHonestly() {
        String text1 = "Цена договора составляет 100,00 руб.";
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(kbId))
                .thenReturn(List.of(kbDoc("ок.pdf", text1), kbDoc("скан.pdf", "")));
        when(gigaChatClient.chatCompletion(anyList()))
                .thenReturn("{\"число\": 100.00, \"цитата\": \"Цена договора составляет 100,00 руб.\"}");

        var result = service.tryAggregate(List.of(kbId), "общая сумма по договорам");

        assertTrue(result.context().contains("ИТОГО: 100.00"));
        assertTrue(result.context().contains("НЕ извлечено"));
        assertTrue(result.context().contains("скан.pdf"));
    }

    // ================================================================
    // Парсеры и валидация
    // ================================================================

    @Test
    void testTryAggregate_sum_brokenPdfNumberConfirmedByDigits() {
        // PDFBox рвёт числа переносами: дословная цитата не совпадает,
        // но цифры числа идут подряд в потоке цифр документа
        String text = "АКТ №1. Итого: 1 808 9\n20,00 руб. с НДС.";
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(kbId))
                .thenReturn(List.of(kbDoc("разорванный.pdf", text)));
        when(gigaChatClient.chatCompletion(anyList()))
                .thenReturn("{\"число\": 1808920.00, \"цитата\": \"Итого: 1 808 920,00 руб.\"}");

        var result = service.tryAggregate(List.of(kbId), "общая сумма по актам");

        assertTrue(result.context().contains("ИТОГО: 1808920.00"),
                "цифровой фолбэк должен подтвердить разорванное число: " + result.context());
    }

    @Test
    void testDigitsConfirm_requiresFiveDigitsAndContiguousMatch() {
        assertTrue(KbAggregateService.digitsConfirm("Итого 1 808 9\n20,00", new BigDecimal("1808920.00")));
        // короткое число фолбэком не подтверждается (слишком легко совпасть)
        assertFalse(KbAggregateService.digitsConfirm("порядковый 1234", new BigDecimal("1234")));
        assertFalse(KbAggregateService.digitsConfirm("нет такого числа 555", new BigDecimal("99999.11")));
    }

    @Test
    void testParseNumber_decimalCommaAndSpaces() {
        assertEquals(new BigDecimal("1234567.89"),
                KbAggregateService.parseNumber("{\"число\": \"1 234 567,89\", \"цитата\": \"x\"}"));
        assertNull(KbAggregateService.parseNumber("{\"число\": null, \"цитата\": \"\"}"));
    }

    @Test
    void testQuoteConfirms_whitespaceNormalizedAndDigitsChecked() {
        String text = "Итого по договору:\n  1 808 920,00   руб.";
        assertTrue(KbAggregateService.quoteConfirms(text,
                "Итого по договору: 1 808 920,00 руб.", new BigDecimal("1808920.00")));
        // цитата есть, но число другое — не подтверждает
        assertFalse(KbAggregateService.quoteConfirms(text,
                "Итого по договору: 1 808 920,00 руб.", new BigDecimal("999.00")));
        // цитаты нет в тексте
        assertFalse(KbAggregateService.quoteConfirms(text,
                "Сумма 1 808 920,00", new BigDecimal("1808920.00")));
    }
}
