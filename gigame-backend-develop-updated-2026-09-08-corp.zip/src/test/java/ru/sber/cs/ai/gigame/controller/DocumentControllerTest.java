package ru.sber.cs.ai.gigame.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;
import ru.sber.cs.ai.gigame.dto.document.DocumentViewResponse;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.ApplicationErrorHandler;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.service.KBService;

import java.time.OffsetDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@Import({DocumentController.class, ApplicationErrorHandler.class})
@WebFluxTest(controllers = DocumentController.class)
@SuppressWarnings("unused")
class DocumentControllerTest {

    @Autowired
    private WebTestClient webClient;

    @Autowired
    private ObjectMapper objectMapper;

    @MockitoBean
    private KBService kbService;

    private String userId;
    private UUID docId;
    private DocumentViewResponse docResponse;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID().toString();
        docId = UUID.randomUUID();
        docResponse = new DocumentViewResponse(
                docId,
                "test.pdf",
                "pdf",
                10240,
                "Извлечённый текст из документа",
                OffsetDateTime.now()
        );
    }

    // -------------------------------------------------------------------------
    // getDocument — success
    // -------------------------------------------------------------------------

    @Test
    void getDocument_ShouldReturnDocument_WhenOwner() {
        // Given
        when(kbService.getDocumentView(docId))
                .thenReturn(docResponse);

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", docId)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(DocumentViewResponse.class)
                .value(response -> {
                    assertEquals(docId, response.id());
                    assertEquals("test.pdf", response.filename());
                    assertEquals(10240, response.sizeBytes());
                    assertEquals("Извлечённый текст из документа", response.extractedText());
                });
    }

    @Test
    void getDocument_ShouldReturnDocument_WhenSharedKB() {
        // Given — владелец другой, но документ в общей KB
        String otherUserId = "OWNER123";
        when(kbService.getDocumentView(docId))
                .thenReturn(docResponse);

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", docId)
                .header("X-UserId", otherUserId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(DocumentViewResponse.class);
    }

    @Test
    void getDocument_ShouldReturnDocument_WhenAnonymousHeaderEmpty() {
        // Given
        when(kbService.getDocumentView(docId))
                .thenReturn(docResponse);

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", docId)
                .header("X-UserId", "")
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(DocumentViewResponse.class);
    }

    // -------------------------------------------------------------------------
    // getDocument — not found
    // -------------------------------------------------------------------------

    @Test
    void getDocument_ShouldReturnNotFound_WhenDocumentNotFound() {
        // Given
        when(kbService.getDocumentView(docId))
                .thenThrow(new NotFoundException("Document not found: " + docId));

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", docId)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isNotFound()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.message")
                .isEqualTo("Document not found: " + docId);
    }

    @Test
    void getDocument_ShouldReturnBadRequest_WhenUuidIsInvalid() {
        // When & Then — невалидный UUID
        webClient.get()
                .uri("/api/documents/{id}", "not-a-uuid")
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isBadRequest();
    }

    // -------------------------------------------------------------------------
    // getDocument — access denied
    // -------------------------------------------------------------------------

    @Test
    void getDocument_ShouldReturnForbidden_WhenNoAccess() {
        // Given — пользователь не владелец и документ не в общей KB
        String strangerId = "STRANGER";
        when(kbService.getDocumentView(docId))
                .thenThrow(new AccessDeniedException("Нет доступа к документу " + docId));

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", docId)
                .header("X-UserId", strangerId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isForbidden()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody()
                .jsonPath("$.message")
                .isEqualTo("Нет доступа к документу " + docId);
    }

    @Test
    void getDocument_ShouldReturnForbidden_WhenPrivateDocAndNonOwner() {
        // Given — приватный документ, пользователь не владелец
        String nonOwner = "NONOWNER";
        when(kbService.getDocumentView(docId))
                .thenThrow(new AccessDeniedException("Нет доступа к документу " + docId));

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", docId)
                .header("X-UserId", nonOwner)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isForbidden();
    }

    // -------------------------------------------------------------------------
    // getDocument — response field validation
    // -------------------------------------------------------------------------

    @Test
    void getDocument_ShouldReturnAllFieldsCorrectly() {
        // Given
        UUID id = UUID.randomUUID();
        DocumentViewResponse expected = new DocumentViewResponse(
                id,
                "договор.docx",
                "docx",
                20480,
                "Полный текст договора",
                OffsetDateTime.of(2025, 1, 15, 10, 30, 0, 0, java.time.ZoneOffset.UTC)
        );
        when(kbService.getDocumentView(id))
                .thenReturn(expected);

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", id)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(DocumentViewResponse.class)
                .value(response -> {
                    assertNotNull(response);
                    assertEquals(id, response.id());
                    assertEquals("договор.docx", response.filename());
                    assertEquals("docx", response.contentType());
                    assertEquals(20480, response.sizeBytes());
                    assertEquals("Полный текст договора", response.extractedText());
                    assertNotNull(response.createdAt());
                });
    }

    @Test
    void getDocument_ShouldReturnDocumentWithEmptyText() {
        // Given — документ с пустым извлечённым текстом (напр. скан без текста)
        UUID id = UUID.randomUUID();
        DocumentViewResponse expected = new DocumentViewResponse(
                id,
                "scan.pdf",
                "pdf",
                5120,
                "",
                OffsetDateTime.now()
        );
        when(kbService.getDocumentView(id))
                .thenReturn(expected);

        // When & Then
        webClient.get()
                .uri("/api/documents/{id}", id)
                .header("X-UserId", userId)
                .accept(MediaType.APPLICATION_JSON)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON)
                .expectBody(DocumentViewResponse.class)
                .value(response -> {
                    assertNotNull(response);
                    assertEquals("", response.extractedText());
                });
    }
}
