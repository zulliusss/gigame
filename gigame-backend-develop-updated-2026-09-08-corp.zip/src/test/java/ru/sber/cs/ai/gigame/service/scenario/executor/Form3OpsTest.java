package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты кодовых операций Формы 3: реестр документов ЭДО и строки формы.
 */
class Form3OpsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final String UPD_SIGNED = """
            Товар (груз) передал Электронная подпись [12] Дата отгрузки, передачи (сдачи) " 21 " июля 2025 г. [13]
            Универсальный передаточный документ
            Счет­фактура N 0000118724 от 21.07.2025 (1)
            Продавец: ООО "Датафьюжн" (2)
            Покупатель: ПАО Сбербанк (6)
            Информационное поле по документу: Договор 4652269 от 05.07.2023 (050004652269)
            Всего к оплате (9) 1063178,54 × без НДС 1063178,54 Руководитель организации Электронная подпись Молодцов
            Товар (груз) получил [17] Дата получения (приёмки) " 24 " июля 2025 г. [18]
            Ответственный за правильность оформления факта хозяйственной жизни Пользователь АС УВХД Электронная подпись Кузьмин Иван Юрьевич [20]
            """;

    private static final String UPD_UNSIGNED = """
            Счет-фактура N 556 от 31.03.2025 (1)
            Продавец: ООО "ТОТ" (2)
            Покупатель: ПАО Сбербанк (6)
            Основание передачи (сдачи) / получения (приёмки) Договор 4622976 (050004622976) 4600024537 от 30.05.2023 [10]
            Всего к оплате (9) 1264585,60 × 252917,12 1517502,72 Руководитель организации
            Дата получения (приёмки) " " 20 г. [18]
            Ответственный за правильность оформления факта хозяйственной жизни [20]
            """;

    private static final String SPEC_A = """
            Спецификация на разработку программного обеспечения № 5374642
            к Договору №4652269 на разработку/модификацию программного обеспечения от «05» июля 2023 г.
            4. Стоимость работ: Стоимость работ составляет 1063178,54 (Один миллион) рублей.
            Главный разработчик Java (back end) (Москва) 47 22620,82 1063 178,54
            Подпись банка Кузьмин 26.06.2025 17:37:40 Подпись поставщика Молодцов 27.06.2025 14:39:02
            """;

    private static final String SPEC_B = """
            Спецификация работ на разработку ПО № 5284130 к Договору № 4652269
            Итого по Этапу №1, руб. 1063178,54 Итого по Этапу №2, руб. 1538215,76 Python DevOps
            Подпись банка 27.03.2025 10:00:00 Подпись поставщика 28.03.2025 11:00:00
            """;

    private static final String CRITERIA = """
            Критерий | Значение | Источник | Найдено
            Период опыта участника по квалификационным требованиям — календарные даты | с 08.04.2023 по 08.04.2026 | расчёт | НЕ НАЙДЕНА
            Период опыта по методике оценки — календарные даты | с 08.04.2025 по 08.04.2026 | расчёт | НЕ НАЙДЕНА
            ЛОТ №1 (Квалификационные требования) | | |
            Технология 1 | Java | Раздел 2 | точно
            Технология 2 | Go (Golang) | Раздел 2 | точно
            Технология 3 | Python | Раздел 2 | точно
            """;

    @Test
    void registryParsesUpdFields() throws Exception {
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("ON_NSCHFDOPPR_1.pdf", UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_A)));
        Map<?, ?> registry = MAPPER.readValue(json, Map.class);
        List<?> upds = (List<?>) registry.get("упд");
        Map<?, ?> upd = (Map<?, ?>) upds.get(0);

        assertEquals(1, upds.size());
        assertEquals("0000118724", upd.get("номер"));
        assertEquals("21.07.2025", upd.get("дата"));
        assertEquals("ООО \"Датафьюжн\"", upd.get("продавец"));
        assertEquals("ПАО Сбербанк", upd.get("покупатель"));
        assertEquals("4652269", upd.get("договор"));
        assertEquals("05.07.2023", upd.get("договор_дата"));
        assertEquals("1063178.54", upd.get("сумма"));
        assertEquals("24.07.2025", upd.get("дата_приёмки"));
        assertEquals(Boolean.TRUE, upd.get("подпись_заказчика"));
        Map<?, ?> spec = (Map<?, ?>) ((List<?>) registry.get("спецификации")).get(0);
        assertEquals("5374642", spec.get("номер"));
        assertEquals("4652269", spec.get("договор"));
        assertEquals("27.06.2025", spec.get("дата"));
        assertTrue(((List<?>) spec.get("суммы")).contains("1063178.54"));
    }

    @Test
    void registryTakesSpecNumberFromFileNameAndDetectsMissingSignature() throws Exception {
        // УПД ТОТ: номера спецификации в тексте нет — берётся из имени файла; подписи заказчика нет
        String json = Form3Ops.registry(List.of(
                new Form3Ops.Source("УПД 556_4622976_5265609_1 517 502,72.pdf", UPD_UNSIGNED)));
        Map<?, ?> upd = (Map<?, ?>) ((List<?>) MAPPER.readValue(json, Map.class).get("упд")).get(0);

        assertEquals("5265609", upd.get("спецификация"));
        assertEquals("1517502.72", upd.get("сумма"));
        assertEquals("", upd.get("дата_приёмки"));
        assertEquals(Boolean.FALSE, upd.get("подпись_заказчика"));
    }

    @Test
    void rowsMatchSpecByStageSumListingAllCandidates() throws Exception {
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_SIGNED),
                new Form3Ops.Source("specA.pdf", SPEC_A), new Form3Ops.Source("specB.pdf", SPEC_B)));

        String json = Form3Ops.rows(Map.of(), registry, CRITERIA);
        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(json, List.class).get(0);

        assertEquals("ПАО Сбербанк", row.get("к3"));
        assertEquals("договор 4652269 от 05.07.2023", row.get("к4"));
        assertTrue(String.valueOf(row.get("к5")).contains("5374642 от 27.06.2025 или 5284130 от 28.03.2025"));
        assertEquals("УПД 0000118724 от 21.07.2025", row.get("к6"));
        assertEquals("24.07.2025", row.get("к7"));
        assertEquals("1063178.54", row.get("к8"));
        assertEquals("1063178.54", row.get("к9"));
        assertEquals("зачтено", row.get("к10"));
        assertEquals("Java, Python", row.get("к11"));
        String audit = String.valueOf(row.get("к12"));
        assertTrue(audit.contains("период квалификации: соответствует"));
        assertTrue(audit.contains("период методики: соответствует"));
        assertTrue(audit.contains("лот 1: найдено Java, Python; не найдено Go (Golang)"));
        assertTrue(audit.contains("заказчик: в рейтинге"));
        assertTrue(audit.contains("несколько кандидатов"));
    }

    @Test
    void rowsMarkUnsignedActAndMissingPeriod() throws Exception {
        String registry = Form3Ops.registry(List.of(
                new Form3Ops.Source("УПД 556_4622976_5265609.pdf", UPD_UNSIGNED)));

        String json = Form3Ops.rows(Map.of(), registry, "Критерий | Значение\nТехнология 1 | Java | Раздел 2 | точно");
        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(json, List.class).get(0);

        assertEquals("0", row.get("к9"));
        assertEquals("акт не подписан заказчиком", row.get("к10"));
        assertEquals("не сопоставлена", row.get("к5"));
        assertEquals("31.03.2025", row.get("к7"));
        assertTrue(String.valueOf(row.get("к12")).contains("проверить вручную (в критериях нет календарных дат)"));
    }

    @Test
    void registryKeepsReportsApartAndRowsDedupeCandidates() throws Exception {
        // отчёт «К Спецификации № N» — не спецификация; два документа с одним номером дают одного кандидата
        String report = "ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ К Спецификации на модификацию № 5374642 от 27.06.2025 "
                + "к договору № 4652269 Стоимость 1063178,54";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_SIGNED),
                new Form3Ops.Source("Отчет_5374642.pdf", report), new Form3Ops.Source("specA.pdf", SPEC_A),
                new Form3Ops.Source("specA-копия.pdf", SPEC_A)));
        Map<?, ?> parsed = MAPPER.readValue(registry, Map.class);

        assertEquals(1, ((List<?>) parsed.get("отчёты")).size());
        assertEquals(2, ((List<?>) parsed.get("спецификации")).size());
        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA), List.class).get(0);
        assertEquals("5374642 от 27.06.2025", row.get("к5"));
    }

    @Test
    void technologySearchUsesWordBoundariesAndAlternatives() {
        assertTrue(Form3Ops.containsTechnology("используется Golang и Postgres", "Go (Golang)"));
        assertFalse(Form3Ops.containsTechnology("Google Cloud", "Go (Golang)"));
        assertTrue(Form3Ops.containsTechnology("javascript (front end)", "JavaScript"));
        assertFalse(Form3Ops.containsTechnology("Java (back end)", "JavaScript"));
        assertTrue(Form3Ops.containsTechnology("процедуры PL/SQL", "PL/SQL"));
    }
}
