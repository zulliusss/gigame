package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitProcessingProgressEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitRagSearchEvent;

@Slf4j
@SuppressWarnings("java:S1192") // String literals should not be duplicated
public class ScenarioExecutorProcessingNode extends AbstractScenarioExecutor {
    private static final int DETAILS_MAX_LENGTH = 200;

    /**
     * Режим data.mode: документы обрабатываются группами, один LLM-вызов на группу.
     */
    static final String MODE_GROUP = "group";

    /**
     * Режим data.mode: агент — модель получает простое задание (намерение)
     * и сама читает документы инструментами (function calling), вместо
     * вставки полных текстов в промпт. Пользователю не нужен
     * профессиональный промпт-инжиниринг.
     */
    static final String MODE_AGENT = "agent";
    /**
     * Агент-ревизор: сверка входных данных с документами БЕЗ цитатной
     * валидации и добора. Выводы проверяющего («совпадает», «расхождение») —
     * вердикты, а не выписки: дословных цитат для них в документах не
     * существует, тетрадь их всегда браковала, и узел делал двойную работу.
     */
    static final String MODE_AGENT_REVIEW = "agent_review";
    /**
     * Агент по группам: docList разбивается по ключу из имени файла (регэксп
     * как в {@link #MODE_GROUP}), и на КАЖДУЮ группу выполняется отдельный
     * агентский конвейер; документы без совпадения (извещение, договор) —
     * общий контекст каждой группы. Сценарий не фиксирует число сущностей
     * (заявок, договоров) — универсален к составу комплекта, а каждый агент
     * работает с малым набором документов (закон масштаба агентного узла).
     */
    static final String MODE_AGENT_GROUP = "agent_group";
    /** Максимум пунктов плана агента: длиннее — перебор вместо работы. */
    static final int MAX_PLAN_ITEMS = 12;
    /** Разбор контрактов выхода узла (guardrails). */
    private static final ObjectMapper CONTRACT_MAPPER = new ObjectMapper();

    /**
     * Дефолтный ключ группы: номер договора из пути/имени файла.
     */
    static final String DEFAULT_GROUP_REGEX = "(?iu)(?:договор|contract)\\s*[№#]?\\s*(\\d{5,})";

    private final GigaChatClient gigaChatClient;
    private final EmbeddingService embeddingService;
    private int ragQueryMaxLength;
    private int cacheShortQueryLength;
    private int groupParallelism = 1;
    /** Память агента (уроки/планы/вопросы); null — фичи памяти выключены. */
    private AgentMemoryService agentMemory;

    @SuppressWarnings("unused")
    protected ScenarioExecutorProcessingNode(ScenarioRunNode node) {
        super(node);
        this.embeddingService = null;
        this.gigaChatClient = null;
        this.ragQueryMaxLength = 800;
        this.cacheShortQueryLength = 200;
    }

    protected ScenarioExecutorProcessingNode(ScenarioRunNode node,
                                             GigaChatClient gigaChatClient,
                                             EmbeddingService embeddingService) {
        super(node);
        this.embeddingService = embeddingService;
        this.gigaChatClient = gigaChatClient;
        this.ragQueryMaxLength = 800;
        this.cacheShortQueryLength = 200;
    }

    /**
     * Sets configuration values from Spring properties.
     * Called by ScenarioExecutorFactory after bean creation.
     */
    protected void setConfiguration(int pRagQueryMaxLength, int pCacheShortQueryLength) {
        this.ragQueryMaxLength = pRagQueryMaxLength;
        this.cacheShortQueryLength = pCacheShortQueryLength;
    }

    /**
     * Параллельность LLM-вызовов групп в режиме group (1 — последовательно).
     */
    protected void setGroupParallelism(int parallelism) {
        this.groupParallelism = Math.max(1, parallelism);
    }

    /** Внедряет память агента (вызывается фабрикой). */
    protected void setAgentMemory(AgentMemoryService memory) {
        this.agentMemory = memory;
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] ProcessingNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        // Узел обработки (с опциональным RAG)
        // Если предыдущий узел Switch отфильтровал документы для этого узла, использовать отфильтрованный набор
        var docs = node.getDocList();
        List<String> resultList;
        if (MODE_AGENT.equals(node.getMode()) || MODE_AGENT_REVIEW.equals(node.getMode())) {
            resultList = new ArrayList<>(processAgent(sink, docs));
        } else if (MODE_AGENT_GROUP.equals(node.getMode())) {
            resultList = new ArrayList<>(processAgentGroups(sink, docs));
        } else if (!docs.isEmpty() && MODE_GROUP.equals(node.getMode())) {
            // режим группировки: один LLM-вызов на группу документов (перекрёстные проверки)
            resultList = new ArrayList<>(processDocGroups(sink, docs));
        } else {
            resultList = new ArrayList<>(processDocList(sink, docs));
            if (docs.isEmpty()) {
                if (node.getParentNodeList().get(0).getType().equals(ScenarioNodeType.LOOP_NODE)) {
                    resultList.addAll(processInputList(sink));
                } else {
                    resultList.addAll(processSimpleInput(sink));
                }
            }
        }
        resultList = applyOutputContract(sink, resultList);
        node.getOutput().addAll(resultList);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return String.join("\n\n", resultList);
    }

    /**
     * Агентский режим — конвейер «план → исполнение → цитатная валидация →
     * добор → финал»:
     * <ol>
     *     <li>ПЛАН: из задания строится нумерованный чек-лист пунктов
     *     (Plan-and-Execute — покрытие полей не зависит от настроения модели);</li>
     *     <li>ИСПОЛНЕНИЕ: tool-цикл ({@link AgentDocumentTools}: поиск, чтение,
     *     БЗ, think-tool) заполняет РАБОЧУЮ ТЕТРАДЬ — по каждому пункту значение
     *     с дословной цитатой и документом-источником;</li>
     *     <li>ВАЛИДАЦИЯ: код ({@link AgentEvidence}) детерминированно проверяет,
     *     что каждая цитата действительно входит в текст документа —
     *     grounding by construction, «тихая выдумка» не проходит;</li>
     *     <li>ДОБОР: пункты плана без записей закрываются одним дополнительным
     *     tool-циклом;</li>
     *     <li>ФИНАЛ: ответ в формате задания собирается из ПРОВЕРЕННОЙ тетради;
     *     неподтверждённые значения помечаются.</li>
     * </ol>
     * Полные тексты документов в промпт не вставляются — лимиты размера
     * запроса агентскому узлу не страшны.
     */
    private List<String> processAgent(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        var tools = buildAgentTools(docs);
        // живая трассировка: каждое действие агента — строка в лог прогона,
        // прогон перестаёт быть чёрным ящиком
        tools.setProgress(msg -> emitProcessingProgressEvent(sink, node,
                Math.max(1, tools.callCount()), AgentDocumentTools.MAX_TOOL_CALLS, msg));
        // остановка прогона: инструменты сворачиваются на ближайшем вызове
        tools.setRunCancelled(() -> node.getGraph().isCancelRequested());
        String task = buildAgentTask();
        assert gigaChatClient != null;
        List<String> plan = buildAgentPlan(task);
        agentTrace(sink, tools, "🧭 план (" + plan.size() + " пунктов): "
                + StringUtils.abbreviate(String.join("; ", plan), 700));
        boolean kbConfigured = ObjectUtils.isNotEmpty(node.getKnowledgeBaseId());
        List<String> lessons = agentLessons();
        if (!lessons.isEmpty()) {
            agentTrace(sink, tools, "🧠 применяю уроки памяти: " + lessons.size());
        }
        String system = buildAgentSystemPrompt(tools.documentSummary(), kbConfigured, plan, lessons);
        prompt = system + "\n\n=== ЗАДАНИЕ ===\n" + task;

        String taskWithData = taskWithPrefetch(sink, task, plan, tools);
        try {
            String answer = runAgentLoop(system, taskWithData, tools);
            if (node.getGraph().isCancelRequested()) {
                throw new ScenarioException("Прогон остановлен пользователем");
            }
            String result;
            if (MODE_AGENT_REVIEW.equals(node.getMode())) {
                // ревизор: ответ-отчёт и есть результат, тетрадь не требуется
                agentTrace(sink, tools, "🧾 режим сверки: отчёт ревизора без цитатной валидации");
                rememberPlan(task, plan);
                result = answer;
            } else {
                result = validateAndCompose(sink, tools, system, task, plan, answer);
            }
            emitProcessingProgressEvent(sink, node, 1, 1, agentDetails(plan, tools));
            return List.of(result);
        } catch (Exception e) {
            // чекпойнт: собранные наблюдения переживут сбой — resume отдаст их
            // агенту рабочим файлом, цикл не начнётся с нуля
            checkpoint = tools.observationsSummary();
            throw e;
        }
    }

    /** Дополняет задание предвыборкой ReWOO по плану (если она что-то нашла). */
    private String taskWithPrefetch(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                    String task, List<String> plan, AgentDocumentTools tools) {
        String prefetched = rewooPrefetch(task, plan, tools);
        if (prefetched.isBlank()) {
            return task;
        }
        agentTrace(sink, tools, "⚡ предвыборка по плану: " + prefetched.length()
                + " символов фрагментов собрано без участия модели");
        return task + "\n\n=== ПРЕДВАРИТЕЛЬНО СОБРАННЫЕ ФРАГМЕНТЫ "
                + "(по плану; используй их, инструментами добирай только недостающее) ===\n"
                + prefetched;
    }

    /** Валидация тетради (с переформатом при сбое формата) и финальный ответ. */
    private String validateAndCompose(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                      AgentDocumentTools tools, String system, String task,
                                      List<String> plan, String answer) {
        var evidence = AgentEvidence.parse(answer);
        if (evidence.isEmpty() && !answer.isBlank()) {
            // финал не в формате тетради — один дешёвый переформат перед деградацией
            agentTrace(sink, tools, "🩹 финал не в формате тетради — переформатирую");
            evidence = reformatToNotebook(answer);
        }
        if (evidence.isEmpty()) {
            // тетрадь не распознана — деградация к прежнему поведению
            agentTrace(sink, tools, "⚠️ рабочая тетрадь не распознана — отдаю ответ без валидации");
            return answer;
        }
        var validated = AgentEvidence.validate(evidence, tools.docsSnapshot());
        agentTrace(sink, tools, "🧪 цитатная валидация: " + verdictSummary(validated));
        validated = coverPlanGaps(sink, system, plan, validated, tools);
        agentTrace(sink, tools, "📝 собираю финальный ответ из проверенной тетради");
        String result = composeFinalAnswer(task, validated);
        emitNodeReflection(sink, tools, plan, validated);
        result = appendAgentQuestions(sink, result, plan, validated);
        result = result + evidenceAppendix(validated);
        rememberPlan(task, plan);
        return result;
    }

    /**
     * Аудиторский след: компактная таблица источников из проверенной тетради
     * дописывается к результату узла — узлы ниже по цепочке (сводка, строки
     * формы) могут выносить источник каждого значения в отчёт/Excel.
     */
    private static String evidenceAppendix(List<AgentEvidence.Entry> validated) {
        StringBuilder sb = new StringBuilder("\n\n=== ИСТОЧНИКИ (аудит) ===\n");
        int rows = 0;
        for (AgentEvidence.Entry e : validated) {
            if (e.quote() == null || e.quote().isBlank()) {
                continue;
            }
            sb.append("- ").append(StringUtils.abbreviate(e.name(), 60)).append(" = ")
                    .append(StringUtils.abbreviate(String.valueOf(e.value()), 60))
                    .append(" | ").append(e.doc())
                    .append(" | «").append(StringUtils.abbreviate(e.quote(), 120))
                    .append("» | ").append(e.verdict()).append('\n');
            rows++;
        }
        return rows == 0 ? "" : sb.toString();
    }

    /**
     * Выходной контракт узла (guardrails): в {@code data.rules} узла обработки
     * можно объявить {"контракт": {"тип": "json_массив",
     * "обязательные_ключи": ["..."], "мин_элементов": N}} — выход проверяется
     * КОДОМ, при нарушении делается один repair-вызов с текстом ошибки,
     * повторное нарушение роняет узел (on_error решает дальнейшее).
     */
    private List<String> applyOutputContract(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             List<String> resultList) {
        var contract = readOutputContract();
        if (contract == null || gigaChatClient == null) {
            return resultList;
        }
        String joined = String.join("\n\n", resultList);
        String violation = contractViolation(contract, joined);
        if (violation == null) {
            return resultList;
        }
        emitProcessingProgressEvent(sink, node, 1, 1,
                "📐 контракт выхода нарушен (" + violation + ") — запрашиваю исправление");
        String repaired = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                "Твой ответ не прошёл проверку формата: " + violation + ". Исправь и верни "
                        + "ПОЛНЫЙ ответ в требуемом формате, не теряя данных. Верни ТОЛЬКО "
                        + "исправленный ответ.\n\n=== ТВОЙ ОТВЕТ ===\n" + joined)),
                node.getModel(), node.getTemperature());
        String again = contractViolation(contract, repaired);
        if (again != null) {
            throw new ScenarioException("Выход узла не соответствует контракту: " + again);
        }
        return List.of(repaired);
    }

    /** Контракт из rules узла или {@code null}, если не объявлен/не распознан. */
    private JsonNode readOutputContract() {
        String rules = node.getRules();
        if (rules == null || rules.isBlank()) {
            return null;
        }
        try {
            var parsed = CONTRACT_MAPPER.readTree(rules).path("контракт");
            return parsed.isMissingNode() || parsed.isNull() ? null : parsed;
        } catch (Exception e) {
            return null;
        }
    }

    /** Текст нарушения контракта или {@code null}, если выход корректен. */
    private static String contractViolation(JsonNode contract, String text) {
        if (!"json_массив".equals(contract.path("тип").asText())) {
            return null;
        }
        String block = lastJsonArray(text);
        if (block == null) {
            return "в ответе нет корректного JSON-массива";
        }
        JsonNode rows;
        try {
            rows = CONTRACT_MAPPER.readTree(block);
        } catch (Exception e) {
            return "JSON-массив не разбирается: " + e.getMessage();
        }
        int min = contract.path("мин_элементов").asInt(0);
        if (rows.size() < min) {
            return "элементов " + rows.size() + ", требуется не менее " + min;
        }
        for (JsonNode key : contract.path("обязательные_ключи")) {
            for (int i = 0; i < rows.size(); i++) {
                if (!rows.get(i).has(key.asText())) {
                    return "у элемента " + (i + 1) + " нет обязательного ключа «"
                            + key.asText() + "»";
                }
            }
        }
        return null;
    }

    /** Последний сбалансированный JSON-массив в тексте или {@code null}. */
    private static String lastJsonArray(String text) {
        for (int i = text.lastIndexOf('['); i >= 0; i = text.lastIndexOf('[', i - 1)) {
            int end = JsonCalcUtils.balancedEnd(text, i);
            if (end > i) {
                return text.substring(i, end + 1);
            }
            if (i == 0) {
                break;
            }
        }
        return null;
    }

    /** Строка трассировки конвейера агента в лог прогона. */
    private void agentTrace(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                            AgentDocumentTools tools, String message) {
        emitProcessingProgressEvent(sink, node,
                Math.max(1, tools.callCount()), AgentDocumentTools.MAX_TOOL_CALLS, message);
    }

    /**
     * Рефлексия узла (Reflexion в миниатюре): генерируется только при
     * отклонениях и только о них — общие слова запрещены промптом.
     * На гладком прогоне рефлексировать не о чем — пропуск без вызова.
     * Сбой рефлексии не влияет на результат узла.
     */
    private void emitNodeReflection(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                    AgentDocumentTools tools, List<String> plan,
                                    List<AgentEvidence.Entry> validated) {
        List<String> deviations = reflectionDeviations(plan, validated);
        if (deviations.isEmpty()) {
            return;
        }
        try {
            String reflection = gigaChatClient.chatCompletion(List.of(Map.of("role", "user",
                    "content", "Ты выполнил задание агентом, часть пунктов прошла НЕ гладко:\n- "
                            + String.join("\n- ", deviations)
                            + "\nДай рефлексию в 2-4 предложениях от первого лица ТОЛЬКО об этих "
                            + "отклонениях: почему не нашлось или не подтвердилось и какое "
                            + "конкретное правило помогло бы в следующий раз. Общие слова "
                            + "(«прошло гладко», «стоит быть внимательнее») запрещены.\n"
                            + "Журнал действий:\n"
                            + StringUtils.abbreviate(String.join("\n", tools.callLog()), 3000))),
                    node.getModel(), node.getTemperature());
            agentTrace(sink, tools, "🪞 рефлексия: " + StringUtils.abbreviate(reflection, 600));
        } catch (Exception e) {
            log.warn("[{}] Рефлексия узла не удалась: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /** Отклонения прогона для рефлексии: всё, что прошло не гладко. */
    private static List<String> reflectionDeviations(List<String> plan,
                                                     List<AgentEvidence.Entry> validated) {
        List<String> deviations = new ArrayList<>();
        for (var e : validated) {
            boolean notSpecified = AgentEvidence.NOT_SPECIFIED
                    .equalsIgnoreCase(String.valueOf(e.value()).strip());
            if (!AgentEvidence.CONFIRMED.equals(e.verdict()) || notSpecified) {
                deviations.add("пункт " + e.item() + " «" + e.name() + "» — "
                        + (notSpecified ? "значение не найдено (не указано)" : e.verdict()));
            }
        }
        for (Integer i : AgentEvidence.uncoveredItems(plan.size(), validated)) {
            deviations.add("пункт " + i + " плана остался незакрытым");
        }
        return deviations;
    }

    /** Сводка вердиктов валидации для трассировки. */
    private String verdictSummary(List<AgentEvidence.Entry> validated) {
        long confirmed = validated.stream()
                .filter(e -> AgentEvidence.CONFIRMED.equals(e.verdict())).count();
        long calculated = validated.stream()
                .filter(e -> AgentEvidence.CALCULATED.equals(e.verdict())).count();
        long rejected = validated.size() - confirmed - calculated;
        return confirmed + " подтверждено, " + calculated + " расчётных, "
                + rejected + " отклонено";
    }

    /** Уроки из памяти агента (частные сценария + одобренные общие). */
    private List<String> agentLessons() {
        if (agentMemory == null) {
            return List.of();
        }
        try {
            return agentMemory.lessonsForScenario(node.getGraph().getScenarioId(),
                    node.getGraph().getRunnerUserId());
        } catch (Exception e) {
            log.warn("[{}] Уроки агента недоступны: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    /**
     * Сохраняет план успешного прогона в память планов. Раздутые планы
     * не запоминаются: развёрнутый по сущностям чек-лист (21 пункт на
     * 3 заявки) на повторе превращался в механический перебор поисков
     * дословными формулировками пунктов.
     */
    private void rememberPlan(String task, List<String> plan) {
        if (agentMemory != null && plan.size() > 1 && plan.size() <= MAX_PLAN_ITEMS) {
            agentMemory.savePlan(node.getGraph().getScenarioId(), task, plan);
        }
    }

    /**
     * Переформат ответа, отданного не в формате тетради: один дешёвый вызов
     * без инструментов — иначе узел уходил в деградацию без цитатной
     * валидации при верных, но неструктурированных данных.
     *
     * @return распознанная тетрадь или пустой список — деградация как раньше
     */
    private List<AgentEvidence.Entry> reformatToNotebook(String answer) {
        try {
            String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                    "Переложи свой ответ ниже СТРОГО в JSON рабочей тетради: {\"записи\": "
                            + "[{\"пункт\": N, \"название\": \"...\", \"значение\": \"...\", "
                            + "\"цитата\": \"дословная цитата из ответа\", \"документ\": "
                            + "\"имя файла\"}]}. Ничего не добавляй от себя, значения и цитаты "
                            + "бери только из ответа. Верни ТОЛЬКО JSON.\n\n=== ОТВЕТ ===\n"
                            + StringUtils.abbreviate(answer, 12000))),
                    node.getModel(), node.getTemperature());
            return AgentEvidence.parse(raw);
        } catch (Exception e) {
            log.warn("[{}] Переформат тетради не удался: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    /**
     * Асинхронный human-in-the-loop: спорные записи тетради (значение без
     * подтверждённой цитаты) и ненайденные данные превращаются в вопросы
     * пользователю. Прогон НЕ останавливается: вопросы сохраняются в память
     * (ответ станет уроком сценария) и дублируются блоком в результате узла.
     */
    private String appendAgentQuestions(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                        String result, List<String> plan,
                                        List<AgentEvidence.Entry> validated) {
        List<String> questions = AgentEvidence.buildQuestions(plan, validated);
        if (questions.isEmpty()) {
            return result;
        }
        emitProcessingProgressEvent(sink, node, 1, 1,
                "❓ вопросов пользователю: " + questions.size()
                        + " (ответы в карточке прогона станут уроками)");
        if (agentMemory != null && node.getGraph().getRunId() != null) {
            try {
                agentMemory.saveQuestions(node.getGraph().getRunId(),
                        node.getGraph().getScenarioId(), node.getLabel(), questions);
            } catch (Exception e) {
                log.warn("[{}] Вопросы агента не сохранены: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            }
        }
        StringBuilder sb = new StringBuilder(result)
                .append("\n\n=== АГЕНТ ПРОСИТ УТОЧНИТЬ ")
                .append("(ответьте в карточке прогона — ответы сохранятся в память сценария) ===\n");
        for (int i = 0; i < questions.size(); i++) {
            sb.append(i + 1).append(". ").append(questions.get(i)).append('\n');
        }
        return sb.toString();
    }

    private AgentDocumentTools buildAgentTools(List<String> docs) {
        // docList раздаёт только input-узел своим детям; агент-узлы дальше по
        // цепочке (например, критик после аналитика) без этого работали бы
        // вслепую — при пустом docList агент получает ВСЕ документы прогона
        List<ScenarioRunDoc> selected =
                docs.isEmpty()
                        ? new ArrayList<>(node.getGraph().getDocMap().values())
                        : docs.stream()
                                .map(id -> node.getGraph().getDocMap().get(id))
                                .collect(Collectors.toCollection(ArrayList::new));
        // рабочие файлы прошлых агент-узлов видимы всегда (общая ФС прогона)
        for (var doc : node.getGraph().getDocMap().values()) {
            if (doc.isWorkNote() && !selected.contains(doc)) {
                selected.add(doc);
            }
        }
        List<AgentDocumentTools.DocEntry> entries = selected.stream()
                .map(d -> new AgentDocumentTools.DocEntry(d.getFilename(), d.getText()))
                .toList();
        boolean kbConfigured = ObjectUtils.isNotEmpty(node.getKnowledgeBaseId());
        var tools = new AgentDocumentTools(entries,
                kbConfigured ? q -> ragSearchForNode(q, "", node.getKnowledgeBaseId()) : null);
        for (var doc : selected) {
            if (doc.isWorkNote()) {
                tools.markWorkNote(doc.getFilename());
            }
        }
        tools.setWriteSink((name, text) -> node.getGraph().addWorkingDoc(name, text));
        return tools;
    }

    /**
     * План-чеклист из задания: один дешёвый вызов без инструментов.
     * При нераспознанном ответе — деградация к плану из одного пункта.
     */
    private List<String> buildAgentPlan(String task) {
        if (agentMemory != null) {
            try {
                List<String> remembered = agentMemory.findPlan(task);
                if (remembered != null && !remembered.isEmpty()
                        && remembered.size() <= MAX_PLAN_ITEMS) {
                    log.info("[{}] Агент: план из памяти ({} пунктов)", CurrentUserHolder.getCurrentUser(), remembered.size());
                    return remembered;
                }
            } catch (Exception e) {
                log.warn("[{}] Память планов недоступна: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            }
        }
        try {
            String raw = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content",
                            "Разбей задание на чек-лист конкретных пунктов-вопросов к документам "
                                    + "(от 3 до " + MAX_PLAN_ITEMS + ", каждый пункт — одно "
                                    + "проверяемое значение или маленькая группа связанных "
                                    + "значений). Несколько однотипных сущностей (заявки, акты, "
                                    + "договоры) НЕ разворачивай в отдельные пункты по каждой — "
                                    + "делай один обобщённый пункт «для каждой …». Пункты — только "
                                    + "ДАННЫЕ из документов (значения, числа, даты, списки); НЕ "
                                    + "включай пункты-проверки процесса («проверить наличие», "
                                    + "«убедиться в корректности/полноте») — наличие и полнота "
                                    + "видны по самим найденным данным. Верни ТОЛЬКО "
                                    + "JSON-массив строк без пояснений.\n\n=== ЗАДАНИЕ ===\n" + task)
            ), node.getModel(), node.getTemperature());
            List<String> plan = AgentEvidence.parsePlan(raw);
            if (!plan.isEmpty()) {
                return plan;
            }
        } catch (Exception e) {
            log.warn("[{}] План агента не построен ({}), работаю без чек-листа", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
        return List.of("Выполнить задание целиком");
    }

    /**
     * ReWOO-предвыборка: один вызов планирует поисковые запросы по пунктам
     * плана (с целевыми документами), код исполняет их пакетом БЕЗ модели —
     * основной цикл стартует с уже собранными фрагментами и делает в разы
     * меньше round-trip'ов (боль больших комплектов и нестабильной сети).
     * Любой сбой фазы — тихая деградация к обычному циклу.
     */
    private String rewooPrefetch(String task, List<String> plan, AgentDocumentTools tools) {
        try {
            StringBuilder planText = new StringBuilder();
            for (int i = 0; i < plan.size(); i++) {
                planText.append(i + 1).append(". ").append(plan.get(i)).append('\n');
            }
            String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                    "По плану и заданию составь поисковые запросы к документам: на каждый пункт "
                            + "1-2 КОРОТКИХ ключевых слова/термина (и число, если ищется число). "
                            + "Укажи целевые документы подстроками их имён, если очевидно из "
                            + "задания. Верни ТОЛЬКО JSON-массив объектов "
                            + "{\"запрос\": \"...\", \"документы\": [\"...\"]} без пояснений.\n\n"
                            + "=== ДОКУМЕНТЫ ===\n" + String.join("\n", tools.documentSummary())
                            + "\n\n=== ПЛАН ===\n" + planText
                            + "\n=== ЗАДАНИЕ ===\n" + StringUtils.abbreviate(task, 4000))),
                    node.getModel(), node.getTemperature());
            var queries = AgentEvidence.parseSearchPlan(raw);
            if (queries.isEmpty()) {
                return "";
            }
            return tools.prefetch(queries);
        } catch (Exception e) {
            log.warn("[{}] ReWOO-предвыборка не удалась ({}), обычный цикл", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return "";
        }
    }

    /** Основной tool-цикл с добивающим вызовом при пустом финале. */
    private String runAgentLoop(String system, String task, AgentDocumentTools tools) {
        var chat = gigaChatClient.chatCompletionWithTools(List.of(
                Map.of("role", "system", "content", system),
                Map.of("role", "user", "content", task)
        ), tools.callbacks(), node.getModel(), node.getTemperature());
        String answer = chat.text();
        if (answer == null || answer.isBlank()) {
            answer = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content",
                            task + "\n\n=== ДАННЫЕ, СОБРАННЫЕ ИЗ ДОКУМЕНТОВ ===\n"
                                    + tools.observationsSummary()
                                    + "\nСформулируй рабочую тетрадь (формат из задания) строго "
                                    + "по этим данным. Чего в данных нет — 'не указано'.")
            ), node.getModel(), node.getTemperature());
        }
        return answer;
    }

    /**
     * Добор: пункты плана без записей закрываются одним дополнительным
     * tool-циклом; его тетрадь валидируется и подшивается к основной.
     */
    private List<AgentEvidence.Entry> coverPlanGaps(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                                    String system, List<String> plan,
                                                    List<AgentEvidence.Entry> validated,
                                                    AgentDocumentTools tools) {
        var uncovered = AgentEvidence.uncoveredItems(plan.size(), validated);
        if (uncovered.isEmpty()) {
            return validated;
        }
        agentTrace(sink, tools, "🩹 добор незакрытых пунктов плана: " + uncovered);
        StringBuilder gaps = new StringBuilder("Не закрыты пункты плана:\n");
        for (int i : uncovered) {
            gaps.append(i).append(". ").append(plan.get(i - 1)).append('\n');
        }
        gaps.append("Найди в документах данные ИМЕННО по этим пунктам и верни рабочую "
                + "тетрадь ТОЛЬКО по ним (тот же JSON-формат «записи», номера пунктов сохрани). "
                + "ЦИТАТА — только ДОСЛОВНО скопированный фрагмент документа (не пересказ, "
                + "не переформулировка): прочитай нужное место (read_document) и скопируй. "
                + "Если данных нет — запись со значением 'не указано' и пустой цитатой.");
        try {
            var chat = gigaChatClient.chatCompletionWithTools(List.of(
                    Map.of("role", "system", "content", system),
                    Map.of("role", "user", "content", gaps.toString())
            ), tools.callbacks(), node.getModel(), node.getTemperature());
            var extra = AgentEvidence.parse(chat.text());
            if (!extra.isEmpty()) {
                var merged = new ArrayList<>(validated);
                merged.addAll(AgentEvidence.validate(extra, tools.docsSnapshot()));
                return merged;
            }
        } catch (Exception e) {
            log.warn("[{}] Добор незакрытых пунктов не удался: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
        return validated;
    }

    /** Финал: ответ в формате задания собирается из проверенной тетради. */
    private String composeFinalAnswer(String task, List<AgentEvidence.Entry> validated) {
        return gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content",
                        task + "\n\n=== ПРОВЕРЕННАЯ РАБОЧАЯ ТЕТРАДЬ "
                                + "(поле 'проверка' — вердикт кода, цитаты сверены с документами) ===\n"
                                + AgentEvidence.toJson(validated)
                                + "\n\nСобери финальный ответ строго по заданию из этой тетради. "
                                + "Значения с проверкой '" + AgentEvidence.CONFIRMED + "' и '"
                                + AgentEvidence.CALCULATED
                                + "' используй как факты. Значения с другими вердиктами НЕ выдавай "
                                + "за факты: пиши 'не указано' или явно помечай '(не подтверждено "
                                + "документами)'. Ничего не добавляй сверх тетради.")
        ), node.getModel(), node.getTemperature());
    }

    /** Детали шага для UI: план, статистика инструментов, журнал. */
    private String agentDetails(List<String> plan, AgentDocumentTools tools) {
        StringBuilder sb = new StringBuilder("агент: план из ").append(plan.size())
                .append(" пунктов, ").append(tools.callCount()).append(" обращений к инструментам\n");
        for (int i = 0; i < plan.size(); i++) {
            sb.append(i + 1).append(". ").append(plan.get(i)).append('\n');
        }
        sb.append(StringUtils.abbreviate(String.join("\n", tools.callLog()), 1200));
        return sb.toString();
    }

    /**
     * Задание агенту: намерение пользователя (промпт узла с поддержкой
     * выражений) плюс результаты предыдущих узлов как контекст.
     */
    private String buildAgentTask() {
        String intent = node.getPrompt();
        if (ExpressionResolver.hasExpressions(intent)) {
            intent = ExpressionResolver.resolve(intent, node.getGraph().getNodeMap());
        }
        String contextInput = String.join("\n\n", node.getInput());
        if (contextInput.isBlank()) {
            return intent;
        }
        if (contextInput.length() > getDocCharLimit()) {
            contextInput = contextInput.substring(0, getDocCharLimit()) + "\n[... обрезано ...]";
        }
        return intent + "\n\n=== РЕЗУЛЬТАТЫ ПРЕДЫДУЩИХ ШАГОВ (контекст) ===\n" + contextInput;
    }

    /**
     * Системный промпт агента: инструменты, план-чеклист, методика, правила
     * качества и формат РАБОЧЕЙ ТЕТРАДИ (значение + дословная цитата +
     * документ) — цитаты затем детерминированно сверяются кодом.
     */
    private String buildAgentSystemPrompt(List<String> docSummary, boolean kbConfigured,
                                          List<String> plan, List<String> lessons) {
        StringBuilder sb = new StringBuilder();
        sb.append("Ты — ИИ-агент по анализу документов. ")
                .append("Тебе дано задание пользователя и документы. ")
                .append("Полные тексты документов НЕ приложены — читай их инструментами:\n")
                .append("- search_documents — поиск по всем документам: короткие ключевые ")
                .append("термины из задания, их синонимы и части слов; ")
                .append("числа можно искать как есть — разделители разрядов учитываются;\n")
                .append("- read_document — чтение документа фрагментами (offset, next_offset);\n")
                .append("- note_thought — запиши короткое рассуждение перед сменой пункта плана;\n")
                .append("- write_file — сохрани рабочий файл (конспект, промежуточную таблицу) ")
                .append("для агентов следующих узлов; рабочие файлы не являются источниками ")
                .append("цитат.\n");
        if (kbConfigured) {
            sb.append("- search_knowledge_base — семантический поиск по базе знаний.\n");
        }
        sb.append("\nДОСТУПНЫЕ ДОКУМЕНТЫ:\n");
        for (String doc : docSummary) {
            sb.append("- ").append(doc).append('\n');
        }
        sb.append("\nПЛАН (чек-лист, закрой КАЖДЫЙ пункт):\n");
        for (int i = 0; i < plan.size(); i++) {
            sb.append(i + 1).append(". ").append(plan.get(i)).append('\n');
        }
        if (!lessons.isEmpty()) {
            sb.append("\nУРОКИ ИЗ ПРОШЛЫХ ПРОГОНОВ (обязательно учитывай):\n");
            for (String lesson : lessons) {
                sb.append("- ").append(lesson).append('\n');
            }
        }
        sb.append("\nМЕТОДИКА: иди по плану пункт за пунктом: поиск по коротким ключевым ")
                .append("словам (пробуй синонимы и части слов) → точечное чтение нужных мест. ")
                .append("note_thought вызывай ТОЛЬКО на настоящей развилке — когда что-то пошло ")
                .append("не по плану: не нашёл и меняю формулировку (какую и почему); вычисляю ")
                .append("значение из найденного (приведи расчёт); противоречие между документами ")
                .append("(какое); сдаюсь и помечаю «не указано» (что перепробовал). В мысли — ")
                .append("конкретные значения и причина решения, её видит пользователь. Если ")
                .append("результат ожидаем — мысль НЕ пиши, просто работай дальше. ")
                .append("БЮДЖЕТ: обращения к инструментам ограничены (")
                .append(AgentDocumentTools.MAX_TOOL_CALLS)
                .append(") — распределяй по всем пунктам и документам, большие документы НЕ читай ")
                .append("целиком подряд.\n");
        if (MODE_AGENT_REVIEW.equals(node.getMode())) {
            appendReviewFormat(sb);
        } else {
            appendNotebookFormat(sb);
        }
        return sb.toString();
    }

    /** Формат финала ревизора: отчёт сверки вместо рабочей тетради. */
    private void appendReviewFormat(StringBuilder sb) {
        sb.append("\nТы — ПРОВЕРЯЮЩИЙ: сверяй данные из задания с документами. ")
                .append("ФИНАЛЬНЫЙ ОТВЕТ — отчёт по заданию обычным текстом (НЕ JSON): по каждому ")
                .append("проверенному пункту вердикт «совпадает» или «РАСХОЖДЕНИЕ: в задании X, ")
                .append("в документе Y», с найденным инструментами значением и именем документа. ")
                .append("Значения бери ТОЛЬКО из результатов инструментов этого разговора, ")
                .append("по памяти не дополняй; не смог проверить — так и напиши.");
    }

    /** Формат рабочей тетради и правила цитирования (часть системного промпта). */
    private void appendNotebookFormat(StringBuilder sb) {
        sb.append("\nФИНАЛЬНЫЙ ОТВЕТ — ТОЛЬКО рабочая тетрадь, JSON строго такого вида:\n")
                .append("{\"записи\": [\n")
                .append("  {\"пункт\": 1, \"название\": \"<пункт плана>\", ")
                .append("\"значение\": \"<извлечённое значение>\", ")
                .append("\"цитата\": \"<ДОСЛОВНАЯ выдержка из документа, подтверждающая значение, ")
                .append("10-200 символов, копируй как в документе>\", ")
                .append("\"документ\": \"<имя документа из списка выше>\"},\n")
                .append("  ...\n]}\n")
                .append("По пункту может быть несколько записей (несколько значений). ")
                .append("Цитаты будут АВТОМАТИЧЕСКИ сверены с текстами документов — цитата, ")
                .append("которой нет в документе дословно, аннулирует значение. Поэтому копируй ")
                .append("цитаты точно из результатов инструментов, не пересказывай. ")
                .append("Если значения нет в документах: \"значение\": \"не указано\", \"цитата\": \"\".\n")
                .append("\nПРАВИЛА: значения бери ТОЛЬКО из результатов инструментов этого разговора, ")
                .append("списки по памяти не дополняй; числа в поле «значение» — без пробелов, дробная ")
                .append("часть через точку (в цитате — как в документе); даты — ДД.ММ.ГГГГ; ")
                .append("производные значения (порог из процента и НМЦ, период из даты и срока) ")
                .append("вычисляй и в цитате давай исходные данные расчёта.");
    }

    /**
     * Режим группировки документов: docList разбивается на группы по ключу
     * из имени файла (первая capture-группа регэкспа из {@code data.value};
     * при пустом значении — {@link #DEFAULT_GROUP_REGEX}, номер договора из пути).
     * Все документы группы попадают в один LLM-вызов (с именами файлов) —
     * это позволяет сверять документы группы между собой (договор ↔ спецификация ↔ акт).
     * Документ без совпадения с регэкспом образует отдельную группу по своему имени.
     */
    private List<String> processDocGroups(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        Pattern pattern = compileGroupPattern();
        Map<String, List<String>> groups = new LinkedHashMap<>();
        for (String docId : docs) {
            var doc = node.getGraph().getDocMap().get(docId);
            String key = extractGroupKey(pattern, doc.getFilename());
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(docId);
        }
        // промпты групп строятся последовательно в основном потоке (детерминизм,
        // RAG-события в sink); LLM-вызовы — параллельно (groupParallelism > 1)
        List<GroupCall> calls = new ArrayList<>();
        for (var entry : groups.entrySet()) {
            String groupKey = entry.getKey();
            String docsBlock = buildGroupDocsBlock(groupKey, entry.getValue());
            var contextInput = String.join("\n\n", node.getInput());
            prompt = buildPrompt(contextInput, docsBlock,
                    getKbChunks(sink, "", docsBlock), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            calls.add(new GroupCall(groupKey, entry.getValue().size(), prompt));
        }
        assert gigaChatClient != null;
        return groupParallelism <= 1 || calls.size() <= 1
                ? runGroupsSequentially(sink, calls)
                : runGroupsInParallel(sink, calls);
    }

    /**
     * Подготовленный LLM-вызов одной группы.
     */
    private record GroupCall(String groupKey, int docCount, String prompt) {
    }

    private Pattern compileGroupPattern() {
        String regex = node.getValue().isBlank() ? DEFAULT_GROUP_REGEX : node.getValue();
        try {
            return Pattern.compile(regex);
        } catch (PatternSyntaxException e) {
            throw new ScenarioException("Некорректный регэксп группировки документов: " + regex, e);
        }
    }

    /**
     * Агент по группам: отдельный агентский конвейер на каждую группу
     * документов (ключ — первая capture-группа регэкспа по имени файла);
     * документы без совпадения — общий контекст, добавляются каждой группе.
     * Групп нет вовсе (ни один документ не совпал) — обычный агентский
     * прогон по всем документам.
     */
    private List<String> processAgentGroups(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                            List<String> docs) {
        List<String> scope = docs.isEmpty()
                ? new ArrayList<>(node.getGraph().getDocMap().keySet()) : docs;
        Pattern pattern = compileGroupPattern();
        Map<String, List<String>> groups = new LinkedHashMap<>();
        List<String> common = new ArrayList<>();
        for (String docId : scope) {
            var doc = node.getGraph().getDocMap().get(docId);
            var m = pattern.matcher(doc.getFilename());
            if (m.find() && m.groupCount() >= 1 && m.group(1) != null) {
                groups.computeIfAbsent(m.group(1), k -> new ArrayList<>()).add(docId);
            } else {
                common.add(docId);
            }
        }
        if (groups.isEmpty()) {
            return processAgent(sink, scope);
        }
        List<String> results = new ArrayList<>();
        int i = 0;
        for (var entry : groups.entrySet()) {
            i++;
            emitProcessingProgressEvent(sink, node, i, groups.size(),
                    "🧩 группа «" + entry.getKey() + "»: " + entry.getValue().size()
                            + " док. + " + common.size() + " общих");
            List<String> groupDocs = new ArrayList<>(entry.getValue());
            groupDocs.addAll(common);
            try {
                results.add("=== Группа " + entry.getKey() + " ===\n"
                        + processAgent(sink, groupDocs).get(0));
                // чекпойнт узла: ГОТОВЫЕ группы переживают сбой следующих —
                // resume отдаст их рабочим файлом, а не начнёт перебор с нуля
                checkpoint = String.join("\n\n", results);
            } catch (Exception e) {
                // processAgent уже положил в checkpoint тетрадь упавшей группы —
                // дополняем её результатами завершённых групп
                String failedNotes = checkpoint != null && !checkpoint.isBlank()
                        && !checkpoint.startsWith("=== Группа")
                        ? "\n\n=== тетрадь группы " + entry.getKey()
                                + " (прервана сбоем) ===\n" + checkpoint
                        : "";
                checkpoint = String.join("\n\n", results) + failedNotes;
                throw e;
            }
        }
        return results;
    }

    private List<String> runGroupsSequentially(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                               List<GroupCall> calls) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < calls.size(); i++) {
            var call = calls.get(i);
            String result = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", call.prompt())
            ), node.getModel(), node.getTemperature());
            resultList.add("=== Группа " + call.groupKey() + " ===\n" + result);
            emitProcessingProgressEvent(sink, node, i + 1, calls.size(),
                    "Группа " + call.groupKey() + " (" + call.docCount() + " док.)");
        }
        return resultList;
    }

    /**
     * Параллельные LLM-вызовы групп: пул на {@code groupParallelism} потоков.
     * Учёт токенов: кадр учёта ({@code beginUsageCapture}) привязан к потоку
     * движка, поэтому воркеры возвращают usage вместе с результатом, а в кадр
     * он добавляется здесь, в потоке движка. Порядок результатов — как у групп;
     * события прогресса — по мере завершения. Ошибка любой группы отменяет
     * остальные и роняет узел (как и при последовательном выполнении).
     */
    private List<String> runGroupsInParallel(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             List<GroupCall> calls) {
        var pool = Executors.newFixedThreadPool(
                Math.min(groupParallelism, calls.size()));
        try {
            var completion = new ExecutorCompletionService<int[]>(pool);
            var results = new String[calls.size()];
            var usages = new ConcurrentHashMap<Integer, Map<String, Object>>();
            for (int i = 0; i < calls.size(); i++) {
                final int index = i;
                completion.submit(() -> {
                    var chat = gigaChatClient.chatCompletionResult(List.of(
                            Map.of("role", "user", "content", calls.get(index).prompt())
                    ), node.getModel(), node.getTemperature());
                    results[index] = chat.text();
                    if (chat.usage() != null) {
                        usages.put(index, chat.usage());
                    }
                    return new int[]{index};
                });
            }
            for (int done = 1; done <= calls.size(); done++) {
                int index = completion.take().get()[0];
                var call = calls.get(index);
                emitProcessingProgressEvent(sink, node, done, calls.size(),
                        "Группа " + call.groupKey() + " (" + call.docCount() + " док.)");
            }
            // usage воркеров — в кадр учёта потока движка
            usages.values().forEach(GigaChatClient::addCapturedUsage);
            List<String> resultList = new ArrayList<>();
            for (int i = 0; i < calls.size(); i++) {
                resultList.add("=== Группа " + calls.get(i).groupKey() + " ===\n" + results[i]);
            }
            return resultList;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ScenarioException("Обработка групп прервана", e);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            if (cause instanceof RuntimeException runtime) {
                throw runtime;
            }
            throw new ScenarioException("Ошибка обработки группы: " + cause.getMessage(), cause);
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * Собирает блок документов группы, укладываясь в {@code docCharLimit}.
     * <p>
     * Общая обрезка блока срезала бы документы, попавшие в конец (обычно акты —
     * самые важные для проверки). Вместо этого бюджет распределяется жадно:
     * документы обходятся по возрастанию длины, каждому выделяется его доля
     * остатка бюджета — короткие (акты, УПД) входят целиком, а излишек уходит
     * длинным (договор обрезается по остаточному бюджету с маркером обрезки).
     */
    private String buildGroupDocsBlock(String groupKey, List<String> docIds) {
        // запас на заголовки документов и маркеры, чтобы buildPrompt не обрезал блок повторно
        int overhead = 200 + docIds.size() * 150;
        int budget = Math.max(getDocCharLimit() - overhead, 1000);
        Map<String, Integer> caps = new HashMap<>();
        List<String> byLength = new ArrayList<>(docIds);
        byLength.sort(Comparator.comparingInt(
                id -> node.getGraph().getDocMap().get(id).getText().length()));
        int remaining = byLength.size();
        for (String docId : byLength) {
            int share = budget / Math.max(remaining, 1);
            int len = node.getGraph().getDocMap().get(docId).getText().length();
            int use = Math.min(len, share);
            caps.put(docId, use);
            budget -= use;
            remaining--;
        }
        StringBuilder docsBlock = new StringBuilder("Группа документов: " + groupKey);
        for (String docId : docIds) {
            var doc = node.getGraph().getDocMap().get(docId);
            String text = doc.getText();
            int cap = caps.getOrDefault(docId, text.length());
            if (text.length() > cap) {
                text = text.substring(0, cap) + "\n[... документ обрезан по лимиту контекста ...]";
            }
            docsBlock.append("\n\n<<<Документ: ").append(doc.getFilename()).append(">>>\n")
                    .append(text)
                    .append("\n<<<КОНЕЦ ДОКУМЕНТА>>>");
        }
        return docsBlock.toString();
    }

    private String extractGroupKey(Pattern pattern, String filename) {
        var matcher = pattern.matcher(filename);
        if (matcher.find()) {
            String key = matcher.groupCount() >= 1 ? matcher.group(1) : matcher.group();
            if (key != null && !key.isBlank()) {
                return key;
            }
        }
        return filename;
    }

    private List<String> processSimpleInput(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> resultList = new ArrayList<>();
        var input = String.join("\n\n", node.getInput());
        prompt = buildPrompt(input, "", getKbChunks(sink, input, ""), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
        assert gigaChatClient != null;
        resultList.add(gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content", prompt)
        ), node.getModel(), node.getTemperature()));
        var details = node.getInput().stream()
                .map(s -> StringUtils.abbreviate(s, DETAILS_MAX_LENGTH))
                .collect(Collectors.joining("\n\n"));
        emitProcessingProgressEvent(sink,
                node,
                1,
                1,
                details);
        return resultList;
    }

    private List<String> processInputList(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < node.getInput().size(); i++) {
            var input = node.getInput().get(i);
            prompt = buildPrompt(input, "", getKbChunks(sink, input, ""), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            assert gigaChatClient != null;
            resultList.add(gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", prompt)
            ), node.getModel(), node.getTemperature()));
            emitProcessingProgressEvent(sink,
                    node,
                    i + 1,
                    node.getInput().size(),
                    StringUtils.abbreviate(input, DETAILS_MAX_LENGTH));
        }
        return resultList;
    }

    private List<String> processDocList(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < docs.size(); i++) {
            var docId = docs.get(i);
            var doc = node.getGraph().getDocMap().get(docId);
            var docText = doc.getText();
            // Результаты предыдущих узлов включаются в контекст наряду с документами узла
            var contextInput = String.join("\n\n", node.getInput());
            prompt = buildPrompt(contextInput, docText, getKbChunks(sink, "", docText), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            assert gigaChatClient != null;
            resultList.add(gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", prompt)
            ), node.getModel(), node.getTemperature()));
            emitProcessingProgressEvent(sink,
                    node,
                    i + 1,
                    node.getDocList().size(),
                    docId + " - " + doc.getFilename());
        }
        return resultList;
    }

    private List<String> getKbChunks(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                     String input,
                                     String docText) {
        List<String> kbChunks = List.of();
        if (ObjectUtils.isNotEmpty(node.getKnowledgeBaseId())) {
            try {
                kbChunks = ragSearchForNode(input, docText, node.getKnowledgeBaseId());
            } catch (Exception e) {
                log.error("[{}] RAG не удался для узла {} {}", CurrentUserHolder.getCurrentUser(), node.getId(), e.getMessage());
                kbChunks = List.of();
            }
            emitRagSearchEvent(sink, node, kbChunks.size());
        }
        return kbChunks;
    }

    /**
     * Выполняет RAG-поиск для узла по базе знаний.
     * <p>
     * Собирает запрос из предыдущего вывода или промпта узла.
     * Кэширует эмбеддинги в рамках одного выполнения.
     *
     * @param previousOutput предыдущий вывод
     * @param documentText   текст документа
     * @param kbId           идентификатор базы знаний
     * @return список релевантных фрагментов из базы знаний
     */
    private List<String> ragSearchForNode(String previousOutput,
                                          String documentText,
                                          UUID kbId) {
        String query = buildRagQuery(previousOutput, documentText);
        if (query.isEmpty()) {
            return List.of();
        }
        try {
            float[] embedding = embeddingForQuery(query);
            assert embeddingService != null;
            List<String> chunks = embeddingService.hybridSearch("kb", kbId, embedding, query);
            log.info("[{}] RAG: found {} chunks in KB {} for node {}", CurrentUserHolder.getCurrentUser(), chunks.size(), kbId, node.getId());
            return chunks;
        } catch (Exception e) {
            log.error("[{}] RAG search failed for KB {}", CurrentUserHolder.getCurrentUser(), kbId, e);
            return List.of();
        }
    }

    /**
     * Запрос RAG-поиска: предыдущий вывод, иначе промпт узла, иначе текст
     * документа; обрезается до {@code ragQueryMaxLength}.
     */
    private String buildRagQuery(String previousOutput, String documentText) {
        String query = previousOutput;
        if (query.isEmpty()) {
            query = node.getPrompt();
        }
        if (query.isEmpty()) {
            query = documentText;
        }
        if (query.length() > ragQueryMaxLength) {
            query = query.substring(0, ragQueryMaxLength);
        }
        return query;
    }

    /**
     * Эмбеддинг запроса с кэшированием в рамках одного выполнения сценария.
     */
    private float[] embeddingForQuery(String query) {
        String cacheKey = query.length() <= cacheShortQueryLength ? query : String.valueOf(query.hashCode());
        var embeddingCache = node.getGraph().getEmbeddingCache();
        if (embeddingCache != null && embeddingCache.containsKey(cacheKey)) {
            return embeddingCache.get(cacheKey);
        }
        assert gigaChatClient != null;
        float[] embedding = gigaChatClient.getEmbeddings(List.of(query)).get(0);
        if (embeddingCache != null) {
            embeddingCache.put(cacheKey, embedding);
        }
        return embedding;
    }
}
