package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * WebSocket обработчик для сценариев.
 * <p>
 * Реализует WebFlux WebSocket Handler для управления выполнением сценариев
 * с потоковой передачей событий в реальном времени через WebSocket.
 * <p>
 * Принимает команды от клиентов для управления выполнением сценариев.
 * Обрабатывает команды: run (по умолчанию) и resume.
 * <p>
 * Формат входящих сообщений:
 * {
 * "type": "run|resume",              // необязательно, по умолчанию run
 * "scenario_id": "uuid",             // для run
 * "step_mode": true|false,           // для run, необязательно
 * "run_id": "uuid"                   // для resume — id упавшего прогона
 * }
 * <p>
 * Файлы для прогона загружаются заранее REST-запросом
 * POST /api/scenarios/{id}/upload — WS-команда run использует кэш загрузки.
 * <p>
 * Формат исходящих сообщений:
 * {
 * "type": "event_type",
 * "data": { ... }
 * }
 *
 * @see WebSocketSessionManager
 * @see ScenarioEngine
 */
@Component
@RequiredArgsConstructor
@Slf4j
@SuppressWarnings("unused")
public class ScenarioWebSocketHandler implements WebSocketHandler {

    private final ScenarioService scenarioService;
    private final ScenarioEngine scenarioEngine;
    private final WebSocketSessionManager sessionManager;
    private final ObjectMapper objectMapper;
    private final ScenarioUploadTaskService scenarioUploadTaskService;

    @Override
    @NonNull
    public Mono<Void> handle(@NonNull WebSocketSession session) {
        try {
            return doHandle(session);
        } finally {
            CurrentUserHolder.clear();
        }
    }

    private Mono<Void> doHandle(WebSocketSession session) {
        var userId = WebSocketSessionManager.extractUserIdFromWebSocketSession(session);
        log.info("[{}] connected, sessionId={}", userId, session.getId());
        sessionManager.addSession(session);

        return Mono.defer(() ->
                session.receive()
                        .doOnNext(msg -> log.info("[{}] Received WebSocket message, payload: {}", userId, msg.getPayloadAsText()))
                        .flatMap(message -> handleIncomingMessage(session, message, userId))
                        .then()
                        .doOnTerminate(() -> {
                            sessionManager.removeSession(session);
                            log.info("[{}] WebSocket scenario run connection closed: sessionId={}", userId, session.getId());
                        })).subscribeOn(Schedulers.boundedElastic());
    }

    private Mono<Void> handleIncomingMessage(WebSocketSession session,
                                             WebSocketMessage message,
                                             String userId) {
        String payload = message.getPayloadAsText();
        log.info("[{}] Received scenario run message: sessionId={}, payload={}", userId, session.getId(), payload);

        try {
            ScenarioMessage scenarioMessage = objectMapper.readValue(
                    payload,
                    ScenarioMessage.class
            );

            return processScenarioMessage(scenarioMessage, session.getId(), userId)
                    .then(Mono.empty());
        } catch (Exception e) {
            log.error("Error handling message: sessionId={}", session.getId(), e);
            return sendErrorMessage(session, "Ошибка обработки сообщения: " + e.getMessage());
        }
    }

    private Mono<Void> processScenarioMessage(ScenarioMessage message, String sessionId, String userId) {
        String type = message.type() == null || message.type().isBlank() ? "run" : message.type();
        log.info("[{}] Processing scenario message: sessionId={}, type={}, scenarioId={}, runId={}, stepMode={}",
                userId, sessionId, type, message.scenarioId(), message.runId(), message.stepMode());
        CurrentUserHolder.setCurrentUser(userId);
        WebSocketSession wsSession = sessionManager.getSession(sessionId);
        if (wsSession == null || !wsSession.isOpen()) {
            log.warn("[{}] WebSocket session not found or closed: sessionId={}", userId, sessionId);
            return Mono.empty();
        }
        Flux<ServerSentEvent<Map<String, Object>>> stream;
        if ("resume".equals(type)) {
            stream = scenarioService.resumeScenarioRun(UUID.fromString(message.runId()));
        } else {
            UUID scenarioId = UUID.fromString(message.scenarioId());
            if (scenarioUploadTaskService.isProcessing(scenarioId)) {
                // асинхронная загрузка ещё разбирает документы — кэш прогона не полон
                return sendErrorMessage(wsSession, "Документы сценария ещё обрабатываются "
                        + "(асинхронная загрузка) — дождитесь завершения по GET upload-status "
                        + "и запустите прогон снова");
            }
            stream = scenarioService.runScenario(
                    scenarioId,
                    message.stepMode());
        }
        return Flux.from(stream
                        .map(serverSentEvent -> CurrentUserHolder.withUser(userId, () -> createStreamEvent(serverSentEvent.data())))
                        .doOnNext(event -> log.info("[{}] Sending to client: {}",userId, event))
                        .doOnComplete(() -> log.info("[{}] Scenario stream completed for sessionId={}", userId, sessionId)))
                .map(wsSession::textMessage)
                .delayElements(Duration.ofMillis(10))
                .as(wsSession::send)
                .then();
    }

    /**
     * Преобразует данные SSE в формат StreamEvent.
     *
     * @param data данные SSE
     * @return Map в формате StreamEvent
     */
    private String createStreamEvent(Map<String, Object> data) {
        Map<String, Object> event = new HashMap<>();
        if (data != null) {
            Object type = data.get("type");
            if (type != null) {
                event.put("type", type);
            }
            Map<String, Object> dataCopy = new HashMap<>(data);
            dataCopy.remove("type");
            event.put("data", dataCopy);
        }
        try {
            return objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            log.error("Error serializing StreamEvent", e);
            return "{}";
        }
    }

    private Mono<Void> sendErrorMessage(WebSocketSession session, String errorMessage) {
        if (session != null && session.isOpen()) {
            try {
                Map<String, Object> errorEvent = Map.of(
                        "session_id", session.getId(),
                        "error", errorMessage
                );
                String json = objectMapper.writeValueAsString(errorEvent);
                return session.send(Flux.just(json).map(session::textMessage));
            } catch (Exception e) {
                log.error("Error serializing error message", e);
                return Mono.error(e);
            }
        }
        return Mono.empty();
    }

    /**
     * Входное сообщение для управления прогоном сценария.
     *
     * @param type       команда: run (по умолчанию) или resume
     * @param scenarioId идентификатор сценария (для run)
     * @param stepMode   флаг пошагового режима (для run, необязательно)
     * @param runId      идентификатор упавшего прогона (для resume)
     */
    public record ScenarioMessage(
            @JsonProperty("type")
            String type,
            @JsonProperty("scenario_id")
            String scenarioId,
            @JsonProperty("step_mode")
            Boolean stepMode,
            @JsonProperty("run_id")
            String runId
    ) {
    }
}
