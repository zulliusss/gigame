package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioOutputSupportService;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitFileOutputEvent;


@Slf4j
public class ScenarioExecutorOutputNode extends AbstractScenarioExecutor {

    private ScenarioOutputSupportService outputSupport;
    private ScenarioRun run;

    protected ScenarioExecutorOutputNode(ScenarioRunNode node) {
        super(node);
    }

    /**
     * Контекст прогона для доп. возможностей rules output-узла
     * («накапливать», «в_базу_знаний»). Без контекста узел работает как раньше.
     *
     * @param supportService сервис накопления/реестра
     * @param scenarioRun           текущий прогон
     */
    public void setRunContext(ScenarioOutputSupportService supportService, ScenarioRun scenarioRun) {
        this.outputSupport = supportService;
        this.run = scenarioRun;
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] OutputNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        List<String> inputs = node.getInput();
        node.getOutput().addAll(inputs);
        var result = String.join("\n\n", inputs);
        if (outputSupport != null && run != null) {
            // нарастающий итог: строки предыдущих прогонов дописываются перед текущими
            result = outputSupport.accumulateIfConfigured(run, node, result);
        }
        // Отправка результата как файл через SSE, если это необходимо
        emitFileOutputEvent(sink, node);
        if (outputSupport != null && run != null) {
            // реестр: результат сохраняется документом в базу знаний (для RAG-кросс-проверок)
            outputSupport.saveToKnowledgeBaseIfConfigured(run, node, result);
        }
        return result;
    }
}
