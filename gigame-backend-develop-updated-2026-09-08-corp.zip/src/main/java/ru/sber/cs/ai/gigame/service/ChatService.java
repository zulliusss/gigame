package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.chat.ConversationCreate;
import ru.sber.cs.ai.gigame.dto.chat.ConversationResponse;
import ru.sber.cs.ai.gigame.dto.chat.ConversationWithMessages;
import ru.sber.cs.ai.gigame.dto.chat.MessageResponse;
import ru.sber.cs.ai.gigame.dto.chat.RagSource;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.ConversationRepository;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.repository.MessageRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.UserUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Сервис для управления диалогами и потоковой передачи ответов AI.
 * <p>
 * Основные функции:
 * <ul>
 *   <li>Создание и управление диалогами (CRUD, настройки модели/температуры)</li>
 *   <li>Сохранение сообщений пользователей и ответов AI</li>
 *   <li>Потоковая передача ответов через SSE (Server-Sent Events)</li>
 *   <li>Регенерация последнего ответа и редактирование сообщений пользователя</li>
 *   <li>Поддержка RAG через встроенные документы и несколько баз знаний
 *       с возвратом источников</li>
 *   <li>Скользящее окно истории + суммаризация вытесненной части</li>
 *   <li>Автоматическая генерация заголовков диалогов</li>
 * </ul>
 * <p>
 * Использует GigaChat API для генерации ответов и pgvector для поиска похожих фрагментов.
 *
 * @see Conversation
 * @see Message
 * @see EmbeddingService
 * @see GigaChatClient
 */
@Service
@Slf4j
public class ChatService {

    /**
     * Маркер окончания блока документа в системном контексте.
     */
    public static final String END_DOCUMENT = "\n--- КОНЕЦ ДОКУМЕНТА ";
    /**
     * Маркер начала блока документа в системном контексте.
     */
    public static final String DOCUMENT = "--- ДОКУМЕНТ ";
    /**
     * Сообщение об ошибке при отсутствии диалога.
     */
    public static final String CONVERSATION_NOT_FOUND = "Conversation not found: ";
    /**
     * Ключ для содержимого сообщения в SSE-событиях.
     */
    public static final String CONTENT = "content";
    public static final String SYSTEM = "system";
    public static final String ROLE = "role";
    public static final String USAGE = "usage";
    public static final String DONE = "done";
    public static final String ERROR = "error";
    /**
     * Ключ для источников RAG в SSE-событиях.
     */
    public static final String SOURCES = "sources";
    private static final String ROLE_USER = "user";
    private final ConversationRepository conversationRepository;
    private final MessageRepository messageRepository;
    private final GigaChatClient gigaChatClient;
    private final EmbeddingService embeddingService;
    private final MessageService messageService;
    private final DocumentRepository documentRepository;
    private final KnowledgeBaseRepository knowledgeBaseRepository;
    private final KbAggregateService kbAggregateService;

    /**
     * Self-injection для вызова @Transactional-методов через AOP-прокси.
     * Без этого вызов {@code this.createConversation(...)} внутри того же бина
     * не создаёт транзакцию, аннотация игнорируется.
     */
    private final AtomicReference<ChatService> self = new AtomicReference<>();

    /**
     * Максимальная длина текста документа для включения полного содержимого в промпт.
     * Документы длиннее этого лимита обрабатываются через поиск релевантных фрагментов.
     */
    @Value("${app.chat.context-char-limit:200000}")
    private int contextCharLimit;
    /**
     * Максимальное количество сообщений истории, включаемых в промпт.
     * Более старые сообщения вытесняются и попадают в суммаризацию.
     */
    @Value("${app.chat.max-history-messages:20}")
    private int maxHistoryMessages;
    /**
     * Максимальная длина автогенерируемого заголовка.
     */
    @Value("${app.chat.max-auto-title-length:100}")
    private int maxAutoTitleLength;
    /**
     * Включена ли фоновая суммаризация истории, вытесненной из контекстного окна.
     */
    @Value("${app.chat.summary-enabled:true}")
    private boolean summaryEnabled;
    /**
     * Целевая максимальная длина краткого содержания истории (символов).
     */
    @Value("${app.chat.summary-max-chars:2000}")
    private int summaryMaxChars;
    /**
     * Относительный фильтр релевантности RAG на уровне баз знаний: база, чей
     * лучший фрагмент хуже глобального лучшего более чем на эту дельту
     * косинусного расстояния, отсекается целиком (не попадает ни в контекст,
     * ни в источники). Значение 0 или меньше отключает фильтр.
     */
    @Value("${app.embedding.distance-delta:0.08}")
    private double ragDistanceDelta;
    /**
     * Абсолютный порог релевантности RAG: фрагменты с косинусным расстоянием
     * больше порога отсекаются независимо от лучшего результата.
     * Значение 0 или меньше отключает порог.
     */
    @Value("${app.embedding.max-distance:0}")
    private double ragMaxDistance;
    /**
     * Включён ли LLM-роутинг баз знаний: перед RAG-поиском по нескольким БЗ
     * модель по названиям и описаниям баз определяет, каких из них касается
     * вопрос, и поиск идёт только по ним. При ошибке или неуверенности
     * роутера поиск выполняется по всем базам (fail-open).
     */
    @Value("${app.chat.rag-router-enabled:true}")
    private boolean ragRouterEnabled;
    /**
     * Модель GigaChat для LLM-роутинга баз знаний.
     * Пустая строка — глобальная модель по умолчанию.
     */
    @Value("${app.chat.rag-router-model:}")
    private String ragRouterModel;
    /**
     * Вопрос короче этого порога считается репликой-продолжением: RAG-запрос
     * дополняется предыдущим вопросом пользователя (анафора «а по второму?»).
     */
    @Value("${app.chat.rag-short-query-chars:60}")
    private int ragShortQueryChars;

    public ChatService(ConversationRepository conversationRepository,
                       MessageRepository messageRepository,
                       GigaChatClient gigaChatClient,
                       EmbeddingService embeddingService,
                       MessageService messageService,
                       DocumentRepository documentRepository,
                       KnowledgeBaseRepository knowledgeBaseRepository,
                       KbAggregateService kbAggregateService) {
        this.conversationRepository = conversationRepository;
        this.messageRepository = messageRepository;
        this.gigaChatClient = gigaChatClient;
        this.embeddingService = embeddingService;
        this.messageService = messageService;
        this.documentRepository = documentRepository;
        this.knowledgeBaseRepository = knowledgeBaseRepository;
        this.kbAggregateService = kbAggregateService;
    }

    @Autowired
    public void setSelf(@Lazy ChatService self) {
        this.self.set(self);
    }

    /**
     * Возвращает все диалоги пользователя с возможной фильтрацией.
     * Поиск выполняется по заголовку диалога И по содержимому сообщений.
     *
     * @param search поисковый запрос (опционально)
     * @return список диалогов пользователя
     */
    public List<ConversationResponse> getConversations(String search) {
        log.info("[{}] getConversations, search='{}'", CurrentUserHolder.getCurrentUser(), search);
        List<Conversation> conversations;
        if (search != null && !search.isBlank()) {
            conversations = conversationRepository.searchByTitleOrMessageContent(
                    CurrentUserHolder.getCurrentUser(), search);
        } else {
            conversations = conversationRepository.findByUserIdOrderByUpdatedAtDesc(CurrentUserHolder.getCurrentUser());
        }
        return conversations.stream().map(this::toConversationResponse).toList();
    }

    // -------------------------------------------------------------------------
    // CRUD диалогов
    // -------------------------------------------------------------------------

    /**
     * Возвращает один диалог с полной историей сообщений.
     * Выбрасывает исключение, если диалог не найден.
     *
     * @param id UUID диалога
     * @return диалог с сообщениями
     */
    @Transactional(readOnly = true)
    public ConversationWithMessages getConversation(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getConversation, id={}", userId, id);
        Conversation conv = conversationRepository.findById(id)
                .orElseThrow(() -> {
                    log.error(CONVERSATION_NOT_FOUND + "{}", id);
                    return new NotFoundException(CONVERSATION_NOT_FOUND + id);
                });
        UserUtils.checkUserId(userId, conv.getUserId());
        // Прямой запрос для избежания LazyInitializationException (open-in-view=false)
        List<MessageResponse> msgs = messageRepository.findByConversationIdOrderByCreatedAtAsc(id).stream()
                .map(this::toMessageResponse)
                .toList();
        return new ConversationWithMessages(
                conv.getId(),
                conv.getTitle(),
                conv.getKnowledgeBaseId() != null ? conv.getKnowledgeBaseId().toString() : null,
                effectiveKbIdsAsStrings(conv),
                conv.getModel(),
                conv.getTemperature(),
                conv.getCreatedAt(),
                conv.getUpdatedAt(),
                msgs
        );
    }

    /**
     * Создаёт новый диалог.
     *
     * @param title           заголовок диалога (по умолчанию "Новый диалог")
     * @param knowledgeBaseId UUID базы знаний для RAG (опционально)
     * @return созданный диалог
     */
    @Transactional
    public ConversationResponse createConversation(String title, String knowledgeBaseId) {
        log.info("[{}] createConversation, title='{}'", CurrentUserHolder.getCurrentUser(), title);
        return self.get().createConversation(
                new ConversationCreate(title, knowledgeBaseId, null, null, null));
    }

    /**
     * Создаёт новый диалог со всеми настройками (несколько БЗ, модель, температура).
     *
     * @param body параметры создания
     * @return созданный диалог
     */
    @Transactional
    public ConversationResponse createConversation(ConversationCreate body) {
        log.info("[{}] createConversation, title='{}', model={}", CurrentUserHolder.getCurrentUser(), body.title(), body.model());
        Conversation conv = new Conversation();
        conv.setTitle(body.title() != null && !body.title().isBlank() ? body.title() : "Новый диалог");
        conv.setUserId(CurrentUserHolder.getCurrentUser());
        List<String> kbIds = normalizeKbIds(body.knowledgeBaseIds(), body.knowledgeBaseId());
        if (kbIds != null) {
            applyKbIds(conv, kbIds);
        }
        if (body.model() != null && !body.model().isBlank()) {
            conv.setModel(body.model().strip());
        }
        if (body.temperature() != null && body.temperature() >= 0) {
            conv.setTemperature(body.temperature());
        }
        conv = conversationRepository.save(conv);
        return toConversationResponse(conv);
    }

    /**
     * Обновляет заголовок диалога (обратная совместимость).
     *
     * @param id    UUID диалога
     * @param title новый заголовок
     * @return обновлённый диалог
     */
    @Transactional
    public ConversationResponse updateConversation(UUID id, String title) {
        log.info("[{}] updateConversation, id={}", CurrentUserHolder.getCurrentUser(), id);
        return self.get().updateConversation(id,
                new ConversationCreate(title, null, null, null, null));
    }

    /**
     * Обновляет настройки диалога: заголовок, привязанные базы знаний,
     * модель и температуру.
     * <p>
     * Семантика частичного обновления: {@code null}-поля не меняются;
     * пустой список БЗ отвязывает все базы; пустая строка модели и
     * отрицательная температура сбрасывают значения на глобальные.
     *
     * @param id   UUID диалога
     * @param body новые данные
     * @return обновлённый диалог
     */
    @Transactional
    public ConversationResponse updateConversation(UUID id, ConversationCreate body) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] updateConversation, id={}", userId, id);
        Conversation conv = conversationRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(CONVERSATION_NOT_FOUND + id));
        UserUtils.checkUserId(userId, conv.getUserId());
        if (body.title() != null && !body.title().isBlank()) {
            conv.setTitle(body.title());
        }
        List<String> kbIds = normalizeKbIds(body.knowledgeBaseIds(), body.knowledgeBaseId());
        if (kbIds != null) {
            applyKbIds(conv, kbIds);
        }
        if (body.model() != null) {
            conv.setModel(body.model().isBlank() ? null : body.model().strip());
        }
        if (body.temperature() != null) {
            conv.setTemperature(body.temperature() < 0 ? null : body.temperature());
        }
        conv = conversationRepository.save(conv);
        return toConversationResponse(conv);
    }

    /**
     * Удаляет диалог по идентификатору.
     *
     * @param id UUID диалога
     */
    @Transactional
    public void deleteConversation(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] deleteConversation, id={}", userId, id);
        Conversation conv = conversationRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(CONVERSATION_NOT_FOUND + id));
        UserUtils.checkUserId(userId, conv.getUserId());
        conversationRepository.delete(conv);
    }

    /**
     * Приводит пару (новый список, устаревшее одиночное поле) к единому списку.
     * Возвращает {@code null}, если ни одно из полей не задано (не менять).
     */
    private List<String> normalizeKbIds(List<String> kbIds, String legacyKbId) {
        if (kbIds != null) {
            return kbIds.stream().filter(s -> s != null && !s.isBlank()).toList();
        }
        if (legacyKbId != null) {
            return legacyKbId.isBlank() ? List.of() : List.of(legacyKbId);
        }
        return new ArrayList<>();
    }

    /**
     * Записывает список БЗ в сущность, поддерживая устаревшее одиночное поле
     * синхронным (первый элемент списка) для обратной совместимости.
     * Привязать можно только доступные пользователю базы (свои или общие).
     */
    private void applyKbIds(Conversation conv, List<String> kbIds) {
        // Валидация формата UUID до записи
        List<String> valid = kbIds.stream().map(s -> UUID.fromString(s).toString()).toList();
        for (String id : valid) {
            KnowledgeBase kb = knowledgeBaseRepository.findById(UUID.fromString(id))
                    .orElseThrow(() -> new NotFoundException("Knowledge base not found: " + id));
            if (!kb.isShared()) {
                UserUtils.checkUserId(conv.getUserId(), kb.getUserId());
            }
        }
        conv.setKnowledgeBaseIds(valid);
        conv.setKnowledgeBaseId(valid.isEmpty() ? null : UUID.fromString(valid.get(0)));
    }

    /**
     * Доступна ли база знаний пользователю: своя или общая.
     * Используется при RAG-поиске — база могла стать личной после привязки.
     */
    private boolean hasKbAccess(String ownerUserId, UUID kbId) {
        return knowledgeBaseRepository.findById(kbId)
                .map(kb -> kb.isShared() || ownerUserId.equals(kb.getUserId()))
                .orElse(false);
    }

    /**
     * Действующий список баз знаний диалога: новый JSONB-список, а при его
     * отсутствии — устаревшее одиночное поле.
     */
    private List<UUID> effectiveKbIds(Conversation conv) {
        if (conv.getKnowledgeBaseIds() != null) {
            return conv.getKnowledgeBaseIds().stream().map(UUID::fromString).toList();
        }
        if (conv.getKnowledgeBaseId() != null) {
            return List.of(conv.getKnowledgeBaseId());
        }
        return List.of();
    }

    private List<String> effectiveKbIdsAsStrings(Conversation conv) {
        return effectiveKbIds(conv).stream().map(UUID::toString).toList();
    }

    /**
     * Отправляет сообщение пользователя и потоково передаёт ответ ассистента через SSE.
     * <p>
     * Алгоритм работы:
     * <ol>
     *   <li>Загружает диалог (выбрасывает исключение, если не найден)</li>
     *   <li>Сохраняет сообщение пользователя в БД</li>
     *   <li>Формирует список сообщений GigaChat (системный контекст + краткое
     *       содержание вытесненной истории + последние сообщения + текущее)</li>
     *   <li>Потоково получает ответ от GigaChat (модель/температура диалога)</li>
     *   <li>Сохраняет сообщение ассистента по завершении</li>
     *   <li>Генерирует заголовок, если это первый обмен; обновляет суммаризацию</li>
     *   <li>Выдаёт SSE-события: {content}, {usage}, {sources}, {done: true}</li>
     * </ol>
     *
     * @param conversationId UUID диалога
     * @param content        текст сообщения пользователя
     * @param documentIds    список UUID прикреплённых документов (опционально)
     * @param documentTexts  тексты документов, встроенные в запрос (опционально)
     * @return Flux SSE-событий
     */
    public Flux<ServerSentEvent<Map<String, Object>>> sendMessageStream(
            UUID conversationId,
            String content,
            List<String> documentIds,
            List<String> documentTexts) {
        var userId = CurrentUserHolder.getCurrentUser();
        // Все блокирующие операции (JPA, обновление токена GigaChat) должны выполняться
        // на boundedElastic, а не на Netty event loop
        return Flux.defer(() -> {
            CurrentUserHolder.setCurrentUser(userId);
            log.info("[{}] sendMessageStream, conversationId={}, chars={}",
                    userId, conversationId,
                    content == null ? 0 : content.length());
            Conversation conversation = conversationRepository.findById(conversationId)
                    .orElseThrow(() -> new NotFoundException(CONVERSATION_NOT_FOUND + conversationId));
            UserUtils.checkUserId(userId, conversation.getUserId());
            Message userMessage = new Message();
            userMessage.setConversation(conversation);
            userMessage.setRole(ROLE_USER);
            userMessage.setContent(content);
            userMessage.setDocumentIds(documentIds);
            userMessage = messageRepository.save(userMessage);

            return generateReplyFlux(conversation, userMessage, documentIds, documentTexts);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Перегенерирует последний ответ ассистента: ответы после последнего
     * сообщения пользователя удаляются, генерация выполняется заново.
     *
     * @param conversationId UUID диалога
     * @param documentIds    UUID документов из кэша диалога (опционально)
     * @param documentTexts  тексты документов из кэша диалога (опционально)
     * @return Flux SSE-событий
     */
    public Flux<ServerSentEvent<Map<String, Object>>> regenerateStream(
            UUID conversationId,
            List<String> documentIds,
            List<String> documentTexts) {

        return Flux.defer(() -> {
            var userId = CurrentUserHolder.getCurrentUser();
            log.info("[{}] regenerateStream, conversationId={}", CurrentUserHolder.getCurrentUser(), conversationId);
            Conversation conversation = conversationRepository.findById(conversationId)
                    .orElseThrow(() -> new NotFoundException(CONVERSATION_NOT_FOUND + conversationId));
            UserUtils.checkUserId(userId, conversation.getUserId());
            List<Message> all = messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId);
            int lastUserIdx = -1;
            for (int i = all.size() - 1; i >= 0; i--) {
                if (ROLE_USER.equals(all.get(i).getRole())) {
                    lastUserIdx = i;
                    break;
                }
            }
            if (lastUserIdx < 0) {
                throw new NotFoundException("Нет сообщения пользователя для регенерации в диалоге " + conversationId);
            }
            List<Message> tail = all.subList(lastUserIdx + 1, all.size());
            if (!tail.isEmpty()) {
                messageRepository.deleteAll(tail);
            }
            Message userMessage = all.get(lastUserIdx);
            List<String> docIds = documentIds != null ? documentIds : userMessage.getDocumentIds();
            return generateReplyFlux(conversation, userMessage, docIds, documentTexts);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Редактирует сообщение пользователя и перегенерирует ответ:
     * все сообщения после редактируемого удаляются, текст заменяется,
     * генерация выполняется заново.
     *
     * @param conversationId UUID диалога
     * @param messageId      UUID редактируемого сообщения (роль user)
     * @param newContent     новый текст сообщения
     * @param documentIds    UUID документов из кэша диалога (опционально)
     * @param documentTexts  тексты документов из кэша диалога (опционально)
     * @return Flux SSE-событий
     */
    public Flux<ServerSentEvent<Map<String, Object>>> editMessageStream(
            UUID conversationId,
            UUID messageId,
            String newContent,
            List<String> documentIds,
            List<String> documentTexts) {

        return Flux.defer(() -> {
            var userId = CurrentUserHolder.getCurrentUser();
            log.info("[{}] editMessageStream, conversationId={}, messageId={}",
                    CurrentUserHolder.getCurrentUser(), conversationId, messageId);
            Conversation conversation = findAndVerifyConversation(userId, conversationId);
            List<Message> all = loadMessagesOrdered(conversationId);
            int editIdx = findMessageIndexById(all, messageId);
            if (editIdx < 0) {
                throw new NotFoundException("Message not found: " + messageId);
            }
            Message userMessage = all.get(editIdx);
            validateUserRole(userMessage, messageId);
            userMessage = updateMessageContentIfProvided(userMessage, newContent);
            deleteMessagesAfterIndex(all, editIdx);
            List<String> docIds = resolveDocumentIds(documentIds, userMessage);
            return generateReplyFlux(conversation, userMessage, docIds, documentTexts);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    // -------------------------------------------------------------------------
    // Потоковая передача чата
    // -------------------------------------------------------------------------

    /**
     * Общее ядро генерации ответа ассистента для отправки/регенерации/редактирования.
     * Формирует промпт, вызывает GigaChat с настройками диалога, сохраняет ответ
     * с источниками, эмитит события content/usage/sources/done.
     */
    private Flux<ServerSentEvent<Map<String, Object>>> generateReplyFlux(
            Conversation conversation,
            Message userMessage,
            List<String> documentIds,
            List<String> documentTexts) {

        PromptBuild build = buildChatMessages(conversation, userMessage, documentIds, documentTexts);
        // Накопитель полного ответа для сохранения в историю
        StringBuilder fullResponse = new StringBuilder();
        AtomicReference<Map<String, Object>> usageRef = new AtomicReference<>();

        return gigaChatClient.chatCompletionStreamResult(
                        build.messages(), conversation.getModel(), conversation.getTemperature())
                .map(chunk -> {
                    fullResponse.append(chunk.text());
                    if (chunk.usage() != null) {
                        usageRef.set(chunk.usage());
                    }
                    Map<String, Object> event = new HashMap<>();
                    event.put(CONTENT, chunk.text());
                    return ServerSentEvent.<Map<String, Object>>builder()
                            .data(event).build();
                })
                .concatWith(Flux.defer(() -> {
                    messageService.saveAssistantMessage(conversation, fullResponse.toString(), build.sources());
                    autoGenerateTitle(conversation, userMessage.getContent());
                    scheduleSummaryUpdate(conversation.getId());
                    List<ServerSentEvent<Map<String, Object>>> tail = new ArrayList<>();
                    if (usageRef.get() != null) {
                        tail.add(ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of(USAGE, usageRef.get())).build());
                    }
                    if (build.sources() != null && !build.sources().isEmpty()) {
                        tail.add(ServerSentEvent.<Map<String, Object>>builder()
                                .data(Map.of(SOURCES, build.sources())).build());
                    }
                    Map<String, Object> doneEvent = new HashMap<>();
                    doneEvent.put("done", true);
                    tail.add(ServerSentEvent.<Map<String, Object>>builder()
                            .data(doneEvent).build());
                    return Flux.fromIterable(tail);
                }));
    }

    /**
     * Результат сборки промпта: сообщения для GigaChat и источники RAG.
     */
    private record PromptBuild(List<Map<String, String>> messages, List<Map<String, String>> sources) {
    }

    /**
     * Формирует полный список сообщений для GigaChat: системный контекст
     * (документы или RAG по базам знаний), краткое содержание вытесненной
     * истории, последние {@code maxHistoryMessages} сообщений и текущее
     * сообщение пользователя.
     *
     * @param conversation  диалог
     * @param userMessage   текущее сообщение пользователя (уже сохранено в БД)
     * @param documentIds   список UUID прикреплённых документов
     * @param documentTexts встроенные тексты документов
     * @return сообщения в формате {@code {role, content}} + источники RAG
     */
    private PromptBuild buildChatMessages(
            Conversation conversation,
            Message userMessage,
            List<String> documentIds,
            List<String> documentTexts) {

        List<Map<String, String>> messages = new ArrayList<>();
        List<RagSource> sources = buildSystemContext(messages, conversation, userMessage, documentIds, documentTexts);
        addHistorySummary(messages, conversation);
        addRecentHistory(messages, conversation, userMessage);
        messages.add(Map.of(ROLE, ROLE_USER, CONTENT, userMessage.getContent()));
        List<Map<String, String>> ragSources = convertSourcesToMap(sources);
        return new PromptBuild(messages, ragSources);
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы для editMessageStream
    // -------------------------------------------------------------------------

    /**
     * Загружает диалог и проверяет права пользователя.
     *
     * @param userId         идентификатор пользователя
     * @param conversationId UUID диалога
     * @return сущность диалога
     */
    private Conversation findAndVerifyConversation(String userId, UUID conversationId) {
        Conversation conversation = conversationRepository.findById(conversationId)
                .orElseThrow(() -> new NotFoundException(CONVERSATION_NOT_FOUND + conversationId));
        UserUtils.checkUserId(userId, conversation.getUserId());
        return conversation;
    }

    /**
     * Загружает все сообщения диалога, отсортированные по возрастанию created_at.
     *
     * @param conversationId UUID диалога
     * @return список сообщений
     */
    private List<Message> loadMessagesOrdered(UUID conversationId) {
        return messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId);
    }

    /**
     * Находит индекс сообщения по его UUID в списке.
     *
     * @param messages  список сообщений
     * @param messageId UUID искомого сообщения
     * @return индекс или -1, если не найдено
     */
    private int findMessageIndexById(List<Message> messages, UUID messageId) {
        for (int i = 0; i < messages.size(); i++) {
            if (messages.get(i).getId().equals(messageId)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Проверяет, что сообщение имеет роль user.
     *
     * @param message   сообщение
     * @param messageId UUID сообщения (для сообщения об ошибке)
     */
    private void validateUserRole(Message message, UUID messageId) {
        if (!ROLE_USER.equals(message.getRole())) {
            throw new NotFoundException("Редактировать можно только сообщения пользователя: " + messageId);
        }
    }

    /**
     * Обновляет содержимое сообщения, если передан новый непустой текст.
     *
     * @param message    сообщение для обновления
     * @param newContent новый текст (может быть null или пустым)
     * @return обновлённое сообщение (сохранённое в БД) или исходное
     */
    private Message updateMessageContentIfProvided(Message message, String newContent) {
        if (newContent != null && !newContent.isBlank()) {
            message.setContent(newContent);
            return messageRepository.save(message);
        }
        return message;
    }

    /**
     * Удаляет все сообщения после указанного индекса.
     *
     * @param allMessages полный список сообщений
     * @param index       индекс, после которого удалять
     */
    private void deleteMessagesAfterIndex(List<Message> allMessages, int index) {
        List<Message> tail = allMessages.subList(index + 1, allMessages.size());
        if (!tail.isEmpty()) {
            messageRepository.deleteAll(tail);
        }
    }

    /**
     * Выбирает идентификаторы документов: из запроса или из сообщения.
     *
     * @param documentIds идентификаторы из запроса (опционально)
     * @param message     сообщение пользователя (содержит сохранённые docIds)
     * @return список UUID документов
     */
    private List<String> resolveDocumentIds(List<String> documentIds, Message message) {
        return documentIds != null ? documentIds : message.getDocumentIds();
    }

    // -------------------------------------------------------------------------
    // Построение сообщений
    // -------------------------------------------------------------------------

    /**
     * Формирует системный контекст: прикреплённые документы или RAG по базам знаний.
     * Добавляет системное сообщение в переданный список и возвращает источники RAG.
     */
    private List<RagSource> buildSystemContext(
            List<Map<String, String>> messages,
            Conversation conversation,
            Message userMessage,
            List<String> documentIds,
            List<String> documentTexts) {

        String userContent = userMessage.getContent();

        if (documentTexts != null && !documentTexts.isEmpty()) {
            List<String> ids = documentIds != null ? documentIds : List.of();
            String docContext = buildDocumentsContext(ids, documentTexts, userContent);
            messages.add(Map.of(ROLE, SYSTEM, CONTENT, docContext));
            return List.of();
        }

        List<UUID> kbIds = effectiveKbIds(conversation).stream()
                .filter(kbId -> hasKbAccess(conversation.getUserId(), kbId))
                .toList();
        if (!kbIds.isEmpty()) {
            // агрегирующие вопросы («общая сумма по договорам», «сколько всего
            // документов») топ-K RAG заваливает — их обрабатывает полный проход
            var aggregate = kbAggregateService.tryAggregate(kbIds, userContent);
            if (aggregate != null) {
                messages.add(Map.of(ROLE, SYSTEM, CONTENT, aggregate.context()));
                return aggregate.sources();
            }
            String ragQuery = ragQueryWithHistory(conversation, userMessage);
            RagResult rag = buildRagContext(routeKbsByLlm(kbIds, ragQuery), ragQuery, userContent);
            if (rag != null) {
                messages.add(Map.of(ROLE, SYSTEM, CONTENT, rag.context()));
                return rag.sources();
            }
        }
        return List.of();
    }

    /**
     * Запрос для RAG-поиска: короткая реплика-продолжение («а по второму
     * договору?») сама по себе даёт мусорный векторный поиск — при вопросе
     * короче порога к нему добавляется предыдущий вопрос пользователя.
     */
    private String ragQueryWithHistory(Conversation conversation, Message userMessage) {
        String current = userMessage.getContent();
        if (current == null || current.length() >= ragShortQueryChars) {
            return current;
        }
        List<Message> recent = messageRepository.findByConversationIdOrderByCreatedAtDesc(
                conversation.getId(), PageRequest.of(0, maxHistoryMessages));
        return recent.stream()
                .filter(m -> ROLE_USER.equals(m.getRole()) && !m.getId().equals(userMessage.getId()))
                .filter(m -> m.getContent() != null && !m.getContent().isBlank())
                .findFirst()
                .map(prev -> prev.getContent() + "\n" + current)
                .orElse(current);
    }

    /**
     * Добавляет краткое содержание вытесненной истории диалога, если оно есть.
     */
    private void addHistorySummary(List<Map<String, String>> messages, Conversation conversation) {
        if (conversation.getSummary() != null && !conversation.getSummary().isBlank()) {
            messages.add(Map.of(ROLE, SYSTEM, CONTENT,
                    "Краткое содержание более ранней части этого диалога "
                            + "(используй как контекст):\n" + conversation.getSummary()));
        }
    }

    /**
     * Добавляет последние {@code maxHistoryMessages} сообщений истории,
     * исключая текущее сообщение пользователя.
     */
    private void addRecentHistory(
            List<Map<String, String>> messages,
            Conversation conversation,
            Message userMessage) {

        List<Message> recent = messageRepository.findByConversationIdOrderByCreatedAtDesc(
                conversation.getId(),
                PageRequest.of(0, maxHistoryMessages + 1));
        List<Message> history = new ArrayList<>(recent);
        Collections.reverse(history);
        history.removeIf(msg -> msg.getId().equals(userMessage.getId())
                || (msg.getCreatedAt() != null && userMessage.getCreatedAt() != null
                && msg.getCreatedAt().isAfter(userMessage.getCreatedAt())));
        if (history.size() > maxHistoryMessages) {
            history = history.subList(history.size() - maxHistoryMessages, history.size());
        }
        for (Message msg : history) {
            messages.add(Map.of(ROLE, msg.getRole(), CONTENT, msg.getContent()));
        }
    }

    /**
     * Преобразует список источников RAG в формат {@code {document_id, document_name, snippet}}.
     */
    private List<Map<String, String>> convertSourcesToMap(List<RagSource> sources) {
        return sources.stream()
                .map(s -> {
                    Map<String, String> source = new LinkedHashMap<>();
                    source.put("document_id", s.documentId().toString());
                    source.put("document_name", s.documentName());
                    source.put("snippet", s.snippet());
                    return source;
                }).toList();
    }

    /**
     * Формирует системный контекст из прикреплённых документов.
     * <p>
     * Стратегия: маленькие документы (&lt; contextCharLimit) включаются полностью.
     * Большие документы обрабатываются через поиск релевантных фрагментов.
     *
     * @param documentIds   список UUID документов
     * @param documentTexts тексты документов
     * @param query         запрос пользователя (для поиска)
     * @return системный контекст
     */
    private String buildDocumentsContext(List<String> documentIds, List<String> documentTexts, String query) {
        String combined = String.join("\n\n", documentTexts);
        if (combined.length() <= contextCharLimit) {
            return buildFullDocumentsContext(documentTexts);
        }
        return buildMixedDocumentsContext(documentIds, documentTexts, query);
    }

    /**
     * Формирует контекст, включающий полные тексты всех документов.
     */
    private String buildFullDocumentsContext(List<String> documentTexts) {
        StringBuilder sb = new StringBuilder();
        sb.append("Пользователь загрузил ").append(documentTexts.size())
                .append(" документ(ов). Используй их содержимое для ответа на вопросы.\n\n");
        for (int i = 0; i < documentTexts.size(); i++) {
            sb.append(DOCUMENT).append(i + 1).append(" ---\n")
                    .append(documentTexts.get(i))
                    .append(END_DOCUMENT).append(i + 1).append(" ---\n\n");
        }
        return sb.toString();
    }

    /**
     * Формирует контекст смешанного типа: маленькие документы целиком, большие — через поиск фрагментов.
     */
    private String buildMixedDocumentsContext(List<String> documentIds, List<String> documentTexts, String query) {
        List<String> parts = new ArrayList<>();
        int budget = contextCharLimit;
        float[] queryEmbedding = null;

        for (int i = 0; i < documentTexts.size() && budget > 0; i++) {
            String docId = i < documentIds.size() ? documentIds.get(i) : null;
            String text = documentTexts.get(i);
            int docNum = i + 1;

            String part = processDocumentPart(docId, text, docNum, query, queryEmbedding);
            if (queryEmbedding == null && part.contains("релевантные фрагменты")) {
                queryEmbedding = fetchQueryEmbedding(query);
            }
            if (!part.isEmpty()) {
                int partLength = calculatePartLength(part);
                if (partLength <= budget) {
                    parts.add(part);
                    budget -= partLength;
                }
            }
        }

        return formatDocumentsContextHeader(documentTexts.size()) + String.join("\n\n", parts);
    }

    /**
     * Обрабатывает одну часть документа в зависимости от его размера и наличия docId.
     */
    private String processDocumentPart(String docId, String text, int docNum, String query, float[] queryEmbedding) {
        // Маленький документ — включаем полностью
        if (text.length() <= contextCharLimit / 4) {
            return buildSmallDocumentPart(docNum, text);
        } else {
            return buildLargeDocumentPart(docId, text, docNum, query, queryEmbedding);
        }
    }

    /**
     * Получает embedding для запроса. Возвращает null при ошибке.
     */
    private float[] fetchQueryEmbedding(String query) {
        try {
            return gigaChatClient.getEmbeddings(List.of(query)).get(0);
        } catch (Exception e) {
            log.error("[{}] Не удалось получить embedding для запроса", CurrentUserHolder.getCurrentUser(), e);
            return new float[0];
        }
    }

    /**
     * Формирует заголовок системного контекста с указанием количества документов.
     */
    private String formatDocumentsContextHeader(int documentCount) {
        return "Пользователь загрузил " + documentCount +
                " документ(ов). Используй их содержимое для ответа на вопросы.\n\n";
    }

    /**
     * Формирует часть контекста для маленького документа (полный текст).
     */
    private String buildSmallDocumentPart(int docNum, String text) {
        return DOCUMENT + docNum + " (полный текст) ---\n" + text
                + END_DOCUMENT + docNum + " ---";
    }

    /**
     * Формирует часть контекста для большого документа (фрагменты или обрезанный текст).
     */
    private String buildLargeDocumentPart(String docId, String text, int docNum, String query, float[] queryEmbedding) {
        if (docId != null) {
            try {
                if (queryEmbedding == null) {
                    queryEmbedding = gigaChatClient.getEmbeddings(List.of(query)).get(0);
                }
                List<String> chunks = embeddingService.hybridSearch(
                        "doc", UUID.fromString(docId), queryEmbedding, query);
                if (!chunks.isEmpty()) {
                    String joined = String.join("\n\n", chunks);
                    return DOCUMENT + docNum + " (релевантные фрагменты) ---\n" + joined
                            + END_DOCUMENT + docNum + " ---";
                }
            } catch (Exception e) {
                log.error("[{}] Поиск похожести не удался для документа {}", CurrentUserHolder.getCurrentUser(), docId, e);
            }
        }
        // Резервный вариант: обрезание
        int cutLen = Math.max(2000, contextCharLimit / 4);
        String truncated = text.substring(0, Math.min(cutLen, text.length()));
        return DOCUMENT + docNum + " (обрезан) ---\n" + truncated
                + END_DOCUMENT + docNum + " ---";
    }

    /**
     * Возвращает длину строки, игнорируя возможные проблемы с кодировкой.
     */
    private int calculatePartLength(String part) {
        return Math.min(part.length(), contextCharLimit);
    }

    /**
     * Результат RAG-поиска: системный контекст и список источников
     * {document_id, document_name, snippet}.
     */
    private record RagResult(String context, List<RagSource> sources) {
    }

    /**
     * Выполняет поиск по одной или нескольким базам знаний и формирует
     * системный контекст RAG с источниками.
     * <p>
     * Фрагменты из всех БЗ сливаются по косинусному расстоянию, берётся
     * глобальный топ-K.
     *
     * @param kbIds        список UUID баз знаний
     * @param query        текст запроса для поиска (может включать историю)
     * @param currentQuery текущая реплика пользователя (для адресации к документу)
     * @return контекст + источники или {@code null}, если фрагментов не найдено
     */
    private RagResult buildRagContext(List<UUID> kbIds, String query, String currentQuery) {
        try {
            float[] queryEmbedding = gigaChatClient.getEmbeddings(List.of(query)).get(0);
            Map<UUID, List<EmbeddingService.ChunkHit>> hitsByKb =
                    searchHitsByKb(kbIds, queryEmbedding, query);
            if (hitsByKb.isEmpty()) {
                return null;
            }
            filterRelevantKbs(hitsByKb);
            List<EmbeddingService.ChunkHit> hits = new ArrayList<>();
            hitsByKb.values().forEach(hits::addAll);
            hits.sort(Comparator.comparingDouble(EmbeddingService.ChunkHit::distance));
            // адресация: сначала по текущей реплике («а по заявке 5?»),
            // только затем по запросу с историей — иначе история тянет чужой документ
            List<EmbeddingService.ChunkHit> addressed = filterByReferencedDocument(hits, currentQuery);
            if (addressed == hits) {
                addressed = filterByReferencedDocument(hits, query);
            }
            if (addressed != hits) {
                // документ назван явно — надёжнее отдать его ПОЛНЫЙ текст,
                // чем топ-K чанков (нужная строка может не попасть в топ)
                RagResult full = addressedFullDocsContext(addressed);
                if (full != null) {
                    return full;
                }
                hits = addressed;
            }
            List<EmbeddingService.ChunkHit> top = hits.subList(0, Math.min(embeddingService.getTopK(), hits.size()));
            log.info("[{}] RAG: found {} chunks in {} of {} KB(s), distances {}", CurrentUserHolder.getCurrentUser(),
                    top.size(), hitsByKb.size(),
                    kbIds.size(), top.stream().map(h -> String.format("%.3f", h.distance())).toList());
            String joined = top.stream().map(EmbeddingService.ChunkHit::text)
                    .reduce((a, b) -> a + "\n\n---\n\n" + b).orElse("");
            String context = "Ты — ассистент с доступом к базе знаний. Используй приведённые ниже "
                    + "фрагменты для ответа на вопрос пользователя. Если информации недостаточно, "
                    + "скажи об этом.\n\n"
                    + "--- ФРАГМЕНТЫ ИЗ БАЗЫ ЗНАНИЙ ---\n"
                    + joined + "\n"
                    + "--- КОНЕЦ ФРАГМЕНТОВ ---";
            return new RagResult(context, buildSources(top));
        } catch (Exception e) {
            log.error("[{}] Поиск RAG не удался для KB {}", CurrentUserHolder.getCurrentUser(), kbIds, e);
            return null;
        }
    }

    /**
     * Адресация к документу: если в вопросе назван конкретный документ базы
     * (базовое имя файла или номер от 5 цифр из имени), остаются только его
     * фрагменты — иначе топ-K приносит похожие чанки ЧУЖИХ документов и
     * модель смешивает факты (перекрёстные галлюцинации: характеристики
     * одного устройства приписывались другому). Документ не назван или
     * фильтр опустошает выдачу — поведение прежнее (fail-open).
     */
    private List<EmbeddingService.ChunkHit> filterByReferencedDocument(
            List<EmbeddingService.ChunkHit> hits, String query) {
        String queryLower = query.toLowerCase(Locale.ROOT);
        Map<UUID, Boolean> referenced = new HashMap<>();
        for (EmbeddingService.ChunkHit hit : hits) {
            UUID docId = hit.sourceDocumentId();
            if (docId == null || referenced.containsKey(docId)) {
                continue;
            }
            referenced.put(docId, documentRepository.findById(docId)
                    .map(doc -> docReferencedInQuery(queryLower, doc.getFilename()))
                    .orElse(false));
        }
        List<EmbeddingService.ChunkHit> filtered = hits.stream()
                .filter(h -> Boolean.TRUE.equals(referenced.get(h.sourceDocumentId())))
                .toList();
        return filtered.isEmpty() ? hits : filtered;
    }

    /**
     * Контекст из полных текстов адресованных документов (не более двух и
     * в пределах лимита контекста): вопрос про конкретный документ должен
     * видеть его целиком, а не надеяться на попадание нужной строки в топ-K.
     * Условия не выполнены — {@code null}, остаёмся на чанках.
     */
    private RagResult addressedFullDocsContext(List<EmbeddingService.ChunkHit> addressed) {
        List<UUID> docIds = addressed.stream().map(EmbeddingService.ChunkHit::sourceDocumentId)
                .filter(Objects::nonNull).distinct().limit(3).toList();
        if (docIds.isEmpty() || docIds.size() > 2) {
            return null;
        }
        StringBuilder sb = new StringBuilder("Ты — ассистент с доступом к базе знаний. Вопрос "
                + "пользователя касается конкретных документов — ниже их полный текст.\n");
        List<RagSource> sources = new ArrayList<>();
        int perDocLimit = contextCharLimit / docIds.size();
        for (UUID docId : docIds) {
            var doc = documentRepository.findById(docId).orElse(null);
            if (doc == null || doc.getExtractedText() == null || doc.getExtractedText().isBlank()) {
                return null;
            }
            String text = StringUtils.abbreviate(doc.getExtractedText(), perDocLimit);
            sb.append("\n--- ДОКУМЕНТ: ").append(doc.getFilename()).append(" ---\n")
                    .append(text).append("\n--- КОНЕЦ ДОКУМЕНТА ---\n");
            sources.add(new RagSource(docId, doc.getFilename(),
                    StringUtils.abbreviate(doc.getExtractedText(), 160)));
        }
        return new RagResult(sb.toString(), sources);
    }

    /**
     * Назван ли документ в вопросе. Три сигнала (по убыванию силы):
     * длинный номер (от 5 цифр) из имени; полное базовое имя файла;
     * токенная пара — числовой токен имени отдельным словом вопроса
     * ПЛЮС буквенный токен имени (основа от 4 букв) в вопросе
     * («акте к заявке 4» ссылается на «Акт к заявке 4 от 01.07.25.pdf»).
     */
    private static boolean docReferencedInQuery(String queryLower, String filename) {
        if (filename == null || filename.isBlank()) {
            return false;
        }
        String queryDigits = queryLower.replaceAll("\\s", "");
        Matcher longNum = Pattern.compile("\\d{5,}").matcher(filename);
        while (longNum.find()) {
            if (queryDigits.contains(longNum.group())) {
                return true;
            }
        }
        String base = filename.toLowerCase(Locale.ROOT).replaceAll("\\.[a-z0-9]+$", "");
        String lastSegment = base.substring(base.lastIndexOf('/') + 1).trim();
        if (lastSegment.length() >= 5 && queryLower.contains(lastSegment)) {
            return true;
        }
        return tokenPairReferenced(queryLower, lastSegment);
    }

    /** Числовой токен имени как отдельное слово вопроса + буквенный токен имени. */
    private static boolean tokenPairReferenced(String queryLower, String nameLower) {
        boolean numberMatched = false;
        Matcher num = Pattern.compile("\\d+").matcher(nameLower);
        while (num.find()) {
            if (Pattern.compile("(?<!\\d)" + num.group() + "(?!\\d)").matcher(queryLower).find()) {
                numberMatched = true;
                break;
            }
        }
        if (!numberMatched) {
            return false;
        }
        Matcher word = Pattern.compile("[а-яёa-z]{4,}").matcher(nameLower);
        while (word.find()) {
            String stem = word.group().substring(0, Math.min(word.group().length(), 5));
            if (queryLower.contains(stem)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Ищет релевантные фрагменты по каждой базе знаний отдельно.
     * <p>
     * Ошибка поиска в отдельной БЗ логируется и не прерывает обработку
     * остальных баз.
     *
     * @param kbIds          список UUID баз знаний
     * @param queryEmbedding embedding запроса пользователя
     * @return фрагменты по базам (только базы с непустым результатом)
     */
    private Map<UUID, List<EmbeddingService.ChunkHit>> searchHitsByKb(List<UUID> kbIds,
                                                                      float[] queryEmbedding,
                                                                      String query) {
        Map<UUID, List<EmbeddingService.ChunkHit>> hitsByKb = new LinkedHashMap<>();
        for (UUID kbId : kbIds) {
            try {
                List<EmbeddingService.ChunkHit> kbHits =
                        embeddingService.hybridSearchWithSources("kb", kbId, queryEmbedding, query);
                if (ragMaxDistance > 0) {
                    kbHits = kbHits.stream().filter(h -> h.distance() <= ragMaxDistance).toList();
                }
                if (!kbHits.isEmpty()) {
                    hitsByKb.put(kbId, kbHits);
                }
            } catch (Exception e) {
                log.error("[{}] Поиск RAG не удался для KB {}", CurrentUserHolder.getCurrentUser(), kbId, e);
            }
        }
        return hitsByKb;
    }

    /**
     * LLM-роутинг баз знаний: по названиям и описаниям баз модель определяет,
     * каких из них касается вопрос пользователя, и возвращает только их.
     * <p>
     * Дополняет эмбеддинг-фильтр {@link #filterRelevantKbs}: тот сравнивает
     * вопрос с текстом фрагментов и не срабатывает, когда тема вопроса
     * (например, «оперативная память») есть только в нерелевантном документе,
     * а роутер опирается на тематику баз. Поведение fail-open: выключенный
     * роутер, одна база, ошибка вызова, ответ «все» или невнятный ответ —
     * поиск по всем базам.
     *
     * @param kbIds доступные базы знаний диалога
     * @param query текст вопроса пользователя
     * @return базы, выбранные роутером, либо исходный список
     */
    private List<UUID> routeKbsByLlm(List<UUID> kbIds, String query) {
        if (!ragRouterEnabled || kbIds.size() < 2) {
            return kbIds;
        }
        try {
            List<KnowledgeBase> kbs = kbIds.stream()
                    .map(id -> knowledgeBaseRepository.findById(id).orElse(null))
                    .filter(Objects::nonNull)
                    .toList();
            if (kbs.size() < 2) {
                return kbIds;
            }
            StringBuilder catalog = new StringBuilder();
            for (int i = 0; i < kbs.size(); i++) {
                KnowledgeBase kb = kbs.get(i);
                catalog.append(i + 1).append(". ").append(kb.getName());
                if (kb.getDescription() != null && !kb.getDescription().isBlank()) {
                    catalog.append(" — ").append(kb.getDescription().strip());
                }
                catalog.append('\n');
            }
            String answer = gigaChatClient.chatCompletion(List.of(
                    Map.of(ROLE, SYSTEM, CONTENT,
                            "Ты — маршрутизатор баз знаний. По вопросу пользователя определи, "
                                    + "в каких базах знаний может находиться ответ.\n"
                                    + "Верни ТОЛЬКО номера подходящих баз через запятую (например: 1 или 1,3). "
                                    + "Если вопрос касается нескольких баз, перечисли их все. "
                                    + "Если не уверен или вопрос общий — верни слово: все\n\n"
                                    + "Базы знаний:\n" + catalog),
                    Map.of(ROLE, ROLE_USER, CONTENT, query)
            ), ragRouterModel == null || ragRouterModel.isBlank() ? null : ragRouterModel.strip(), 0.01);
            List<UUID> routed = parseRoutedKbs(answer, kbs);
            if (routed.size() < kbs.size()) {
                log.info("[{}] RAG-роутер: вопрос направлен в {} из {} БЗ (ответ роутера: \"{}\")",
                        CurrentUserHolder.getCurrentUser(), routed.size(), kbs.size(), answer == null ? null : answer.strip());
            }
            return routed;
        } catch (Exception e) {
            log.error("[{}] LLM-роутинг БЗ не удался — поиск по всем базам", CurrentUserHolder.getCurrentUser(), e);
            return kbIds;
        }
    }

    /**
     * Разбирает ответ роутера: номера баз через запятую либо «все».
     * Любой невнятный ответ трактуется как «все базы».
     */
    private List<UUID> parseRoutedKbs(String answer, List<KnowledgeBase> kbs) {
        List<UUID> all = kbs.stream().map(KnowledgeBase::getId).toList();
        if (answer == null || answer.toLowerCase().contains("все")) {
            return all;
        }
        Set<UUID> routed = new LinkedHashSet<>();
        Matcher m = Pattern.compile("\\d+").matcher(answer);
        while (m.find()) {
            // Длинные числа (даты, id, эхо UUID в ответе) — не номера баз
            if (m.group().length() > 2) {
                continue;
            }
            int num = Integer.parseInt(m.group());
            if (num >= 1 && num <= kbs.size()) {
                routed.add(kbs.get(num - 1).getId());
            }
        }
        return routed.isEmpty() ? all : new ArrayList<>(routed);
    }

    /**
     * Относительный фильтр релевантности на уровне баз знаний: базы, чей лучший
     * фрагмент хуже глобального лучшего более чем на дельту
     * {@code app.embedding.distance-delta}, удаляются из карты целиком —
     * вместе со всеми своими фрагментами. Дельта 0 и меньше выключает фильтр.
     * <p>
     * Гранулярность именно по базам, а не по фрагментам: расстояния фрагментов
     * релевантного и нерелевантного документов перемешиваются, и по-фрагментный
     * порог отсекал бы и полезные фрагменты выигравшей базы. Если вопрос
     * касается одной БЗ — вторая отсекается целиком; если обеих — их лучшие
     * фрагменты близки, и обе остаются со всеми фрагментами.
     *
     * @param hitsByKb фрагменты по базам (каждый список отсортирован по
     *                 возрастанию расстояния); нерелевантные базы удаляются
     */
    private void filterRelevantKbs(Map<UUID, List<EmbeddingService.ChunkHit>> hitsByKb) {
        if (ragDistanceDelta <= 0 || hitsByKb.size() < 2) {
            return;
        }
        double globalBest = hitsByKb.values().stream()
                .mapToDouble(kbHits -> kbHits.get(0).distance())
                .min()
                .orElseThrow();
        hitsByKb.entrySet().removeIf(entry -> {
            double kbBest = entry.getValue().get(0).distance();
            boolean drop = kbBest > globalBest + ragDistanceDelta;
            if (drop) {
                log.info("[{}] RAG: БЗ {} отсечена фильтром релевантности — лучший фрагмент {} "
                                + "хуже глобального лучшего {} более чем на дельту {}",
                        CurrentUserHolder.getCurrentUser(), entry.getKey(), String.format("%.3f", kbBest),
                        String.format("%.3f", globalBest), ragDistanceDelta);
            }
            return drop;
        });
    }

    /**
     * Собирает список источников из найденных фрагментов: по одному на документ,
     * с именем файла и коротким сниппетом первого релевантного фрагмента.
     */
    private List<RagSource> buildSources(List<EmbeddingService.ChunkHit> hits) {
        Map<UUID, RagSource> byDoc = new LinkedHashMap<>();
        for (EmbeddingService.ChunkHit hit : hits) {
            if (hit.sourceDocumentId() == null || byDoc.containsKey(hit.sourceDocumentId())) {
                continue;
            }
            String name = documentRepository.findById(hit.sourceDocumentId())
                    .map(Document::getFilename)
                    .orElse("Документ " + hit.sourceDocumentId());
            log.info("[{}] RAG источник: {} — лучший фрагмент на расстоянии {}",
                    CurrentUserHolder.getCurrentUser(), name, String.format("%.3f", hit.distance()));
            String snippet = hit.text() == null ? ""
                    : hit.text().substring(0, Math.min(200, hit.text().length()));
            byDoc.put(hit.sourceDocumentId(), new RagSource(hit.sourceDocumentId(), name, snippet));
        }
        return new ArrayList<>(byDoc.values());
    }

    // -------------------------------------------------------------------------
    // Суммаризация вытесненной истории
    // -------------------------------------------------------------------------

    /**
     * Планирует фоновое обновление краткого содержания истории диалога.
     * Выполняется после ответа ассистента, не задерживая SSE-поток.
     *
     * @param conversationId UUID диалога
     */
    private void scheduleSummaryUpdate(UUID conversationId) {
        if (!summaryEnabled) {
            return;
        }
        Schedulers.boundedElastic().schedule(() -> {
            try {
                updateConversationSummary(conversationId);
            } catch (Exception e) {
                log.error("Не удалось обновить суммаризацию диалога {}", conversationId, e);
            }
        });
    }

    /**
     * Обновляет краткое содержание сообщений, вытесненных из контекстного окна.
     * <p>
     * Суммаризируются сообщения, не попадающие в окно последних
     * {@code maxHistoryMessages}: существующее краткое содержание дополняется
     * вновь вытесненными сообщениями отдельным вызовом GigaChat.
     * Если история сократилась (редактирование/регенерация), суммаризация
     * сбрасывается и накапливается заново.
     *
     * @param conversationId UUID диалога
     */
    void updateConversationSummary(UUID conversationId) {
        Conversation conversation = conversationRepository.findById(conversationId).orElse(null);
        if (conversation == null) {
            return;
        }
        long count = messageRepository.countByConversationId(conversationId);
        int overflow = (int) Math.max(0, count - maxHistoryMessages);
        int covered = conversation.getSummaryMessageCount();
        if (overflow == covered) {
            return;
        }
        if (overflow < covered) {
            // История сократилась — сбрасываем и копим заново
            conversation.setSummary(null);
            conversation.setSummaryMessageCount(0);
            conversationRepository.save(conversation);
            return;
        }
        // Вновь вытесненные сообщения: с позиции covered до overflow (в порядке ASC)
        List<Message> oldest = messageRepository.findByConversationIdOrderByCreatedAtAsc(
                conversationId, PageRequest.of(0, overflow));
        if (oldest.size() < overflow) {
            return;
        }
        List<Message> evicted = oldest.subList(covered, overflow);
        String summary = gigaChatClient.chatCompletion(List.of(
                Map.of(ROLE, SYSTEM, CONTENT,
                        "Ты сжимаешь историю диалога. Составь краткое содержание (не более "
                                + summaryMaxChars + " символов), сохранив ключевые факты, решения, "
                                + "имена, числа и договорённости. Верни только текст краткого содержания."),
                Map.of(ROLE, ROLE_USER, CONTENT, buildSummaryPrompt(conversation, evicted))
        ), conversation.getModel(), 0.3);
        if (summary != null && !summary.isBlank()) {
            if (summary.length() > summaryMaxChars * 2) {
                summary = summary.substring(0, summaryMaxChars * 2);
            }
            conversation.setSummary(summary.strip());
            conversation.setSummaryMessageCount(overflow);
            conversationRepository.save(conversation);
            log.info("Суммаризация диалога {} обновлена: покрыто {} сообщений", conversationId, overflow);
        }
    }

    /**
     * Формирует пользовательский промпт для суммаризации: существующее краткое
     * содержание (если есть) и вытесненные сообщения, усечённые до 2000 символов.
     *
     * @param conversation диалог
     * @param evicted      сообщения, вытесненные из контекстного окна
     * @return текст промпта для GigaChat
     */
    private String buildSummaryPrompt(Conversation conversation, List<Message> evicted) {
        StringBuilder sb = new StringBuilder();
        if (conversation.getSummary() != null && !conversation.getSummary().isBlank()) {
            sb.append("Текущее краткое содержание диалога:\n")
                    .append(conversation.getSummary())
                    .append("\n\nНовые сообщения для добавления в краткое содержание:\n");
        } else {
            sb.append("Сообщения диалога для суммаризации:\n");
        }
        for (Message msg : evicted) {
            String who = ROLE_USER.equals(msg.getRole()) ? "Пользователь" : "Ассистент";
            String text = msg.getContent();
            if (text.length() > 2000) {
                text = text.substring(0, 2000) + "…";
            }
            sb.append(who).append(": ").append(text).append("\n\n");
        }
        return sb.toString();
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы сохранения
    // -------------------------------------------------------------------------

    /**
     * Автоматически генерирует заголовок диалога после первого обмена сообщениями.
     * <p>
     * Генерация происходит только один раз для нового диалога.
     * Заголовок создаётся на основе первого сообщения пользователя через GigaChat.
     *
     * @param conversation диалог
     * @param userContent  текст первого сообщения пользователя
     */
    private void autoGenerateTitle(Conversation conversation, String userContent) {
        if (!"Новый диалог".equals(conversation.getTitle())) {
            return;
        }
        List<Message> msgs = messageRepository.findByConversationIdOrderByCreatedAtAsc(conversation.getId());
        // Автогенерация заголовка только если это первый обмен (пользователь + ассистент = 2 сообщения)
        if (msgs.size() > 2) {
            return;
        }
        try {
            String titleResponse = gigaChatClient.chatCompletion(List.of(
                    Map.of(ROLE, SYSTEM,
                            CONTENT, "Придумай короткий заголовок (3-5 слов) для диалога на основе первого сообщения пользователя. Верни только заголовок, без кавычек и пояснений."),
                    Map.of(ROLE, ROLE_USER, CONTENT, userContent)
            ));
            String newTitle = getNewTitle(titleResponse);
            if (!newTitle.isBlank()) {
                conversation.setTitle(newTitle);
                conversationRepository.save(conversation);
            }
        } catch (Exception e) {
            log.error("[{}] Не удалось автогенерировать заголовок", CurrentUserHolder.getCurrentUser(), e);
        }
    }

    private String getNewTitle(String titleResponse) {
        if (titleResponse == null || titleResponse.isBlank()) {
            return "";
        }
        String newTitle = titleResponse.strip();
        // Удаляем окружающие кавычки
        if (newTitle.startsWith("\"") || newTitle.startsWith("'")) {
            newTitle = newTitle.substring(1);
        }
        if (newTitle.endsWith("\"") || newTitle.endsWith("'")) {
            newTitle = newTitle.substring(0, newTitle.length() - 1);
        }
        if (newTitle.length() > maxAutoTitleLength) {
            newTitle = newTitle.substring(0, maxAutoTitleLength);
        }
        return newTitle;
    }

    /**
     * Преобразует сущность диалога в DTO.
     *
     * @param conv сущность Conversation
     * @return DTO диалога
     */
    private ConversationResponse toConversationResponse(Conversation conv) {
        return new ConversationResponse(
                conv.getId(),
                conv.getTitle(),
                conv.getKnowledgeBaseId() != null ? conv.getKnowledgeBaseId().toString() : null,
                effectiveKbIdsAsStrings(conv),
                conv.getModel(),
                conv.getTemperature(),
                conv.getCreatedAt(),
                conv.getUpdatedAt()
        );
    }

    // -------------------------------------------------------------------------
    // Преобразование в DTO
    // -------------------------------------------------------------------------

    /**
     * Преобразует сущность сообщения в DTO.
     *
     * @param msg сущность Message
     * @return DTO сообщения
     */
    private MessageResponse toMessageResponse(Message msg) {
        var sources = (msg.getSources() == null)
                ? new ArrayList<RagSource>()
                : msg.getSources().stream()
                .map(s ->
                        new RagSource(UUID.fromString(s.get("document_id")),
                                s.get("document_name"),
                                s.get("snippet")))
                .toList();
        return new MessageResponse(
                msg.getId(),
                msg.getConversation().getId(),
                msg.getRole(),
                msg.getContent(),
                msg.getDocumentIds(),
                sources,
                msg.getCreatedAt()
        );
    }
}
