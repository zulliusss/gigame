package ru.sber.cs.ai.gigame.service.scenario.executor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.time.Duration;
import java.util.Map;

/**
 * Узел «Пауза»: задержка на N секунд (поле value узла), вход передаётся
 * дальше без изменений. Применение — развести LLM-вызовы по времени при
 * лимитах API. Максимум — 300 секунд.
 */
@Slf4j
public class ScenarioExecutorWaitNode extends AbstractScenarioExecutor {

    private static final int MAX_WAIT_SECONDS = 300;

    protected ScenarioExecutorWaitNode(ScenarioRunNode node) {
        super(node);
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] WaitNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        int seconds;
        try {
            seconds = (int) Double.parseDouble(
                    String.valueOf(node.getValue()).replace(",", ".").trim());
        } catch (Exception e) {
            throw new ScenarioException("Узел «Пауза»: укажите длительность в секундах (поле «значение»)");
        }
        if (seconds < 0 || seconds > MAX_WAIT_SECONDS) {
            throw new ScenarioException("Узел «Пауза»: длительность 0.." + MAX_WAIT_SECONDS + " секунд");
        }
        prompt = "[пауза " + seconds + " с, без LLM]";
        try {
            Mono.delay(Duration.ofSeconds(seconds), Schedulers.boundedElastic()).block();
        } catch (Exception e) {
            Thread.currentThread().interrupt();
            throw new ScenarioException("Пауза прервана");
        }
        String result = "⏸ Пауза " + seconds + " с";
        node.getOutput().add(result);
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(node.getInput());
        }
        return result;
    }
}
