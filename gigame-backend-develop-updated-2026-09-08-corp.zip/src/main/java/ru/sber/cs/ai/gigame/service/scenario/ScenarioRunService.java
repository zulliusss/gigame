package ru.sber.cs.ai.gigame.service.scenario;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.OffsetDateTime;
import java.util.List;

@Service
@Slf4j
public class ScenarioRunService {
    private final ScenarioRunRepository scenarioRunRepository;

    public ScenarioRunService(ScenarioRunRepository scenarioRunRepository) {
        this.scenarioRunRepository = scenarioRunRepository;
    }

    public ScenarioRun setScenarioRunStatusRunning(ScenarioRun run) {
        log.info("[{}] setScenarioRunStatusRunning, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        run.setStatus(ScenarioStatus.RUNNING.getValue());
        return scenarioRunRepository.save(run);
    }

    public ScenarioRun setScenarioRunStatusFailed(ScenarioRun run) {
        log.info("[{}] setScenarioRunStatusFailed, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        run.setStatus(ScenarioStatus.FAILED.getValue());
        return scenarioRunRepository.save(run);
    }

    public ScenarioRun setScenarioRunStatusCompleted(ScenarioRun run, String finalResult) {
        log.info("[{}] setScenarioRunStatusCompleted, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        run.setStatus(ScenarioStatus.COMPLETED.getValue());
        run.setResult(finalResult);
        run.setCompletedAt(OffsetDateTime.now());
        return scenarioRunRepository.save(run);
    }

    /**
     * Восстановление после рестарта: прогоны, оставшиеся в статусе RUNNING
     * (их поток выполнения умер вместе с JVM), помечаются FAILED — иначе
     * они вечно отображаются «выполняется» в интерфейсе.
     */
    @EventListener(ApplicationReadyEvent.class)
    public void failOrphanedRunningRuns() {
        List<ScenarioRun> orphaned =
                scenarioRunRepository.findByStatus(ScenarioStatus.RUNNING.getValue());
        if (orphaned.isEmpty()) {
            return;
        }
        orphaned.forEach(run -> run.setStatus(ScenarioStatus.FAILED.getValue()));
        scenarioRunRepository.saveAll(orphaned);
        log.warn("Прогоны, прерванные рестартом сервера, помечены FAILED: {}", orphaned.size());
    }
}
