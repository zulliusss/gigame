package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.dto.chat.RagSource;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Агрегирующие вопросы чата по всему корпусу базы знаний.
 * <p>
 * Векторный RAG отвечает по топ-K фрагментам и на вопросы вида «общая сумма
 * по договорам» или «сколько всего документов» физически не может ответить
 * корректно (видит 3-5 документов из десятков). Здесь такие вопросы
 * распознаются и обрабатываются полным проходом: значение извлекается из
 * КАЖДОГО документа базы (с цитатной валидацией кодом — выдуманные числа
 * отбрасываются), а итог считается программно, не моделью. Вопросы про
 * число/перечень документов отвечаются из метаданных вообще без LLM.
 */
@Service
@Slf4j
public class KbAggregateService {

    /**
     * Вопрос о суммарном значении по всем документам корпуса. Каждая фраза —
     * отдельный короткий паттерн (снижает regex-сложность ниже порога S5843),
     * все компилируются с CANon_EQ для совпадения канонически-эквивалентных
     * Unicode-форм (S5854).
     */
    static final List<Pattern> SUM_INTENTS = List.of(
            intent("(?:общ|суммарн|итогов)\\w*\\s+(?:сумм|стоимост|цен)\\w*"),
            intent("сумм\\w*\\s+(?:по\\s+)?(?:всем|всех)"),
            intent("итого\\s+по\\s+(?:всем|всех)"),
            intent("общий\\s+итог"));
    /**
     * Вопрос о количестве или перечне документов корпуса. Аналогично SUM_INTENTS:
     * каждая фраза — свой короткий паттерн с флагами (S5843, S5854).
     */
    static final List<Pattern> LIST_INTENTS = List.of(
            intent("сколько\\s+(?:всего\\s+)?(?:договор|документ|акт|файл)\\w*"),
            intent("перечисли\\s+(?:все|всех)"),
            intent("списк\\w*\\s+(?:всех|документов|договоров)"),
            intent("какие\\s+(?:документы|договоры)\\s+(?:есть|загружен)"));
    /** Максимум имён документов в контексте перечня. */
    static final int LIST_NAMES_LIMIT = 300;
    private static final int SNIPPET_LEN = 160;

    private final KBDocumentRepository kbDocumentRepository;
    private final GigaChatClient gigaChatClient;
    /** Выключатель обработки агрегирующих вопросов чата. */
    @Value("${app.chat.aggregate-enabled:true}")
    private boolean enabled;
    /** Больше этого числа документов — честный отказ с советом сценария. */
    @Value("${app.chat.aggregate-max-docs:200}")
    private int maxDocs;
    /** Лимит символов документа для извлечения (голова + хвост). */
    @Value("${app.chat.aggregate-doc-char-limit:30000}")
    private int docCharLimit;
    /** Параллельность извлечений (агрессивнее — ловит 429 на корп. ключе). */
    @Value("${app.chat.aggregate-parallelism:2}")
    private int parallelism;

    public KbAggregateService(KBDocumentRepository kbDocumentRepository,
                              GigaChatClient gigaChatClient) {
        this.kbDocumentRepository = kbDocumentRepository;
        this.gigaChatClient = gigaChatClient;
    }

    /** Компилирует паттерн интента: регистронезависимо, Unicode-классы, CANon_EQ. */
    private static Pattern intent(String regex) {
        return Pattern.compile(regex,
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CHARACTER_CLASS | Pattern.CANON_EQ);
    }

    /** Совпадает ли запрос с одной из суммирующих фраз. */
    static boolean isSumIntent(String query) {
        return SUM_INTENTS.stream().anyMatch(p -> p.matcher(query).find());
    }

    /** Совпадает ли запрос с одной из перечисляющих фраз. */
    static boolean isListIntent(String query) {
        return LIST_INTENTS.stream().anyMatch(p -> p.matcher(query).find());
    }

    /**
     * Результат агрегации: системный контекст для модели и источники.
     */
    public record AggregateResult(String context, List<RagSource> sources) {
    }

    /**
     * Извлечённое из документа значение с подтверждающей цитатой.
     */
    record DocValue(Document doc, BigDecimal value, String quote) {
    }

    /**
     * Обрабатывает вопрос, если он агрегирующий; иначе возвращает {@code null}
     * (чат продолжает обычный RAG).
     */
    public AggregateResult tryAggregate(List<UUID> kbIds, String query) {
        if (!enabled || kbIds == null || kbIds.isEmpty() || query == null) {
            return null;
        }
        boolean sum = isSumIntent(query);
        boolean list = isListIntent(query);
        if (!sum && !list) {
            return null;
        }
        log.info("[{}] tryAggregate, sum={}, list={}, kbIds={}",
                CurrentUserHolder.getCurrentUser(), sum, list, kbIds.size());
        List<Document> docs = loadDocuments(kbIds);
        if (docs.isEmpty()) {
            return null;
        }
        if (!sum) {
            return listResult(docs);
        }
        if (docs.size() > maxDocs) {
            return new AggregateResult(tooManyContext(docs.size()), List.of());
        }
        return sumResult(docs, query);
    }

    private List<Document> loadDocuments(List<UUID> kbIds) {
        Map<UUID, Document> byId = new LinkedHashMap<>();
        for (UUID kbId : kbIds) {
            for (KBDocument kbDoc : kbDocumentRepository.findByKnowledgeBaseIdWithDocument(kbId)) {
                Document doc = kbDoc.getDocument();
                if (doc != null) {
                    byId.putIfAbsent(doc.getId(), doc);
                }
            }
        }
        return new ArrayList<>(byId.values());
    }

    /** Перечень/количество документов — из метаданных, без LLM. */
    private AggregateResult listResult(List<Document> docs) {
        StringBuilder sb = new StringBuilder("=== ДОКУМЕНТЫ БАЗЫ ЗНАНИЙ (метаданные, посчитано программно) ===\n");
        sb.append("Всего документов: ").append(docs.size()).append('\n');
        int shown = Math.min(docs.size(), LIST_NAMES_LIMIT);
        for (int i = 0; i < shown; i++) {
            sb.append(i + 1).append(". ").append(docs.get(i).getFilename()).append('\n');
        }
        if (shown < docs.size()) {
            sb.append("… и ещё ").append(docs.size() - shown).append(" документов\n");
        }
        sb.append("Отвечай пользователю строго по этому списку; число документов бери из строки «Всего документов».");
        return new AggregateResult(sb.toString(), List.of());
    }

    private String tooManyContext(int count) {
        return "=== АГРЕГАЦИЯ НЕДОСТУПНА ===\n"
                + "Вопрос требует прохода по всем документам базы (" + count
                + " шт.), это больше лимита чата (" + maxDocs + "). Честно скажи пользователю, "
                + "что точный итог по такому числу документов в чате не считается, и порекомендуй "
                + "сценарий с узлом «Агрегация» (вкладка «Сценарии»): он перебирает все документы "
                + "и считает суммы программно. Не называй никаких чисел.";
    }

    /** Map-reduce: извлечение значения из каждого документа + сумма кодом. */
    private AggregateResult sumResult(List<Document> docs, String query) {
        List<DocValue> values = extractAll(docs, query);
        values = retryMissedSequentially(values, query);
        BigDecimal total = BigDecimal.ZERO;
        List<RagSource> sources = new ArrayList<>();
        StringBuilder rows = new StringBuilder();
        StringBuilder missing = new StringBuilder();
        for (DocValue dv : values) {
            if (dv.value() != null) {
                total = total.add(dv.value());
                rows.append("- ").append(dv.doc().getFilename()).append(" = ")
                        .append(dv.value().toPlainString())
                        .append(" | «").append(StringUtils.abbreviate(dv.quote(), SNIPPET_LEN)).append("»\n");
                sources.add(new RagSource(dv.doc().getId(), dv.doc().getFilename(),
                        StringUtils.abbreviate(dv.quote(), SNIPPET_LEN)));
            } else {
                missing.append("- ").append(dv.doc().getFilename()).append('\n');
            }
        }
        if (sources.isEmpty()) {
            // ни одного подтверждённого значения — «ИТОГО: 0» ввёл бы в заблуждение
            return new AggregateResult("=== АГРЕГАЦИЯ НЕ ДАЛА РЕЗУЛЬТАТА ===\n"
                    + "Ни из одного из " + docs.size() + " документов базы не удалось извлечь "
                    + "подтверждённое значение (возможно, документы — сканы без текстового слоя "
                    + "или не содержат искомых сумм). Честно скажи об этом пользователю и не "
                    + "называй никаких чисел.", List.of());
        }
        String context = "=== АГРЕГАЦИЯ ПО ВСЕМ ДОКУМЕНТАМ БАЗЫ ЗНАНИЙ (посчитано программно) ===\n"
                + "Вопрос агрегирующий, поэтому значение извлечено из каждого документа базы ("
                + docs.size() + " шт.), итог посчитан кодом, не моделью.\n"
                + "ИТОГО: " + total.toPlainString() + "\n"
                + "По документам (значение | подтверждающая цитата):\n" + rows
                + (missing.isEmpty() ? ""
                        : "Значение НЕ извлечено (возможно скан или нет суммы) из:\n" + missing)
                + "Отвечай пользователю строго по этим данным: итог бери из строки ИТОГО, "
                + "при необходимости приведи разбивку по документам. Числа не пересчитывай и не выдумывай. "
                + "Если по части документов значение не извлечено — честно перечисли их.";
        return new AggregateResult(context, sources);
    }

    /** Параллельное извлечение значений по документам (порядок сохраняется). */
    private List<DocValue> extractAll(List<Document> docs, String query) {
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, parallelism));
        try {
            List<Future<DocValue>> futures = new ArrayList<>();
            for (Document doc : docs) {
                futures.add(pool.submit(() -> extractValue(doc, query)));
            }
            List<DocValue> values = new ArrayList<>();
            for (int i = 0; i < futures.size(); i++) {
                values.add(awaitValue(futures.get(i), docs.get(i)));
            }
            return values;
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * Второй проход по документам без значения — последовательно: волна
     * параллельных извлечений ловит 429 на корп. ключе, и часть документов
     * выпадает из итога по сетевой причине, а не по содержимому.
     */
    private List<DocValue> retryMissedSequentially(List<DocValue> values, String query) {
        List<DocValue> result = new ArrayList<>(values.size());
        for (DocValue dv : values) {
            if (dv.value() != null || dv.doc().getExtractedText() == null
                    || dv.doc().getExtractedText().isBlank()) {
                result.add(dv);
                continue;
            }
            try {
                result.add(extractValue(dv.doc(), query));
            } catch (Exception e) {
                log.warn("[{}] Агрегация: повторное извлечение из «{}» не удалось",
                        CurrentUserHolder.getCurrentUser(), dv.doc().getFilename(), e);
                result.add(dv);
            }
        }
        return result;
    }

    /** Дожидается извлечения; сбой одного документа не роняет агрегацию. */
    private DocValue awaitValue(Future<DocValue> future, Document doc) {
        try {
            return future.get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new DocValue(doc, null, "");
        } catch (Exception e) {
            log.warn("[{}] Агрегация: извлечение из «{}» не удалось", CurrentUserHolder.getCurrentUser(), doc.getFilename(), e);
            return new DocValue(doc, null, "");
        }
    }

    /** Извлечение одного значения из документа с цитатной валидацией кодом. */
    private DocValue extractValue(Document doc, String query) {
        String text = clip(doc.getExtractedText());
        if (text.isBlank()) {
            return new DocValue(doc, null, "");
        }
        String prompt = "Вопрос пользователя: «" + query + "»\n"
                + "Ниже текст документа «" + doc.getFilename() + "». Найди в нём ОДНО итоговое число, "
                + "отвечающее на вопрос применительно к этому документу (например, полную сумму/цену "
                + "договора с НДС). Верни СТРОГО JSON без пояснений: "
                + "{\"число\": 1234567.89, \"цитата\": \"дословная строка документа с этим числом\"}. "
                + "Если такого числа в документе нет: {\"число\": null, \"цитата\": \"\"}.\n\n"
                + "=== ДОКУМЕНТ ===\n" + text;
        String answer = gigaChatClient.chatCompletion(
                List.of(Map.of("role", "user", "content", prompt)));
        BigDecimal value = parseNumber(answer);
        String quote = parseQuote(answer);
        if (value == null) {
            return new DocValue(doc, null, "");
        }
        if (quoteConfirms(text, quote, value)) {
            return new DocValue(doc, value, quote);
        }
        // PDF-парсер рвёт числа переносами — дословная цитата может не
        // совпасть; цифровой фолбэк: цифры числа (от 5 цифр) идут подряд
        // в потоке цифр документа → значение расчётно подтверждено
        if (digitsConfirm(text, value)) {
            return new DocValue(doc, value, "число подтверждено цифрами документа");
        }
        return new DocValue(doc, null, "");
    }

    /** Цифры значения (мин. 5) встречаются подряд в потоке цифр документа. */
    static boolean digitsConfirm(String text, BigDecimal value) {
        String valueDigits = value.stripTrailingZeros().toPlainString().replaceAll("\\D", "");
        if (valueDigits.length() < 5) {
            return false;
        }
        return text.replaceAll("\\D", "").contains(valueDigits);
    }

    private String clip(String text) {
        if (text == null) {
            return "";
        }
        if (text.length() <= docCharLimit) {
            return text;
        }
        int half = docCharLimit / 2;
        return text.substring(0, half) + "\n…\n" + text.substring(text.length() - half);
    }

    /** Число из ответа модели: поле «число», десятичная запятая допускается. */
    static BigDecimal parseNumber(String answer) {
        if (answer == null) {
            return null;
        }
        Matcher m = Pattern.compile("\"число\"\\s*:\\s*\"?([\\d\\s]+(?:[.,]\\d+)?)\"?").matcher(answer);
        if (!m.find()) {
            return null;
        }
        try {
            return new BigDecimal(m.group(1).replaceAll("\\s", "").replace(',', '.'));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Дословная цитата из ответа модели. */
    static String parseQuote(String answer) {
        if (answer == null) {
            return "";
        }
        // possessiv-квантфикатор (*+) исключает путь перебора в альтернации,
        // убирая риск стек-переполнения (S5998): закрывающая кавычка не входит
        // в [^"], так что жадное поглощение не может «перескочить» через неё
        Matcher m = Pattern.compile("\"цитата\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*+)\"").matcher(answer);
        return m.find() ? m.group(1).replace("\\\"", "\"").trim() : "";
    }

    /**
     * Цитатная валидация кодом: цитата обязана дословно входить в документ
     * (пробелы нормализуются), а цифры числа — входить в цифры цитаты.
     * Иначе значение отбрасывается — выдуманное число хуже честного пропуска.
     */
    static boolean quoteConfirms(String text, String quote, BigDecimal value) {
        if (quote == null || quote.isBlank()) {
            return false;
        }
        String normText = text.replaceAll("\\s+", " ");
        String normQuote = quote.replaceAll("\\s+", " ").trim();
        if (!normText.toLowerCase().contains(normQuote.toLowerCase())) {
            return false;
        }
        String quoteDigits = normQuote.replaceAll("\\D", "");
        String valueDigits = value.toPlainString().replaceAll("\\D", "");
        // «2500000.00» в документе может стоять как «2 500 000» — без дробных нулей
        String strippedDigits = value.stripTrailingZeros().toPlainString().replaceAll("\\D", "");
        return quoteDigits.contains(valueDigits) || quoteDigits.contains(strippedDigits);
    }
}
