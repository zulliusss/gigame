package ru.sber.cs.ai.gigame.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.Operation;
import io.swagger.v3.oas.models.PathItem;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.responses.ApiResponse;
import io.swagger.v3.oas.models.servers.Server;
import lombok.extern.slf4j.Slf4j;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * Конфигурация OpenAPI 3.0 для документирования REST API.
 * <p>
 * Документация доступна по адресам:
 * <ul>
 *   <li>Swagger UI: <a href="http://localhost:8000/CONTEXT_PATH/swagger-ui.html">...</a> (или /gigame/swagger-ui.html)</li>
 *   <li>OpenAPI JSON: http://localhost:8000/CONTEXT_PATH/sample-api-docs</li>
 *   <li>OpenAPI YAML: http://localhost:8000/CONTEXT_PATH/api-docs.yaml</li>
 * </ul>
 */
@Configuration
@Slf4j
public class OpenApiConfig {

    private static final String API_VERSION = "1.0";
    private static final String API_TITLE = "GigaMe Backend API";
    private static final String API_DESCRIPTION = """
            GigaMe — backend-сервис для работы с искусственным интеллектом на основе GigaChat.
            
            ## Возможности
            
            - **Чат**: Диалоги с GigaChat (потоковая передачей ответов (SSE))
            - **RAG**: Поиск по фрагментам документов и базам знаний
            - **Загрузка документов**: Поддержка PDF, DOCX, XLSX, TXT
            - **Сценарии**: Графовые AI- workflow с пошаговым выполнением
            - **Базы знаний**: Постоянные коллекции документов с векторными индексами
            
            ## Использование
            
            ### Аутентификация
            
            Для вызова защищённых эндпоинтов необходимо иметь действующую учётную запись
            и соответствующие права доступа.
            
            ### Ошибки
            
            API возвращает стандартные HTTP статусы:
            - `200 OK` — успех
            - `201 Created` — ресурс создан
            - `400 Bad Request` — неверный запрос
            - `404 Not Found` — ресурс не найден
            - `500 Internal Server Error` — внутренняя ошибка сервера
            """;

    @Value("${server.port:8000}")
    private int serverPort;
    @Value("${spring.webflux.base-path:/gigame}")
    private String path;

    @Bean
    public GroupedOpenApi actuatorApi() {
        return GroupedOpenApi.builder()
                .group("actuator")
                .displayName("💀 Актуатор")
                .pathsToMatch("/actuator/**")
                .build();
    }

    @Bean
    public GroupedOpenApi chatApi() {
        return GroupedOpenApi.builder()
                .group("chat")
                .displayName("💬 Чат")
                .pathsToMatch("/api/conversations/**")
                .build();
    }

    @Bean
    public GroupedOpenApi documentApi() {
        return GroupedOpenApi.builder()
                .group("documents")
                .displayName("📁 Документы")
                .pathsToMatch("/api/documents/**")
                .build();
    }

    @Bean
    public GroupedOpenApi knowledgeBaseApi() {
        return GroupedOpenApi.builder()
                .group("knowledge-base")
                .displayName("🧠 Базы знаний")
                .pathsToMatch("/api/knowledge-bases/**")
                .build();
    }

    @Bean
    public GroupedOpenApi scenarioApi() {
        return GroupedOpenApi.builder()
                .group("scenarios")
                .displayName("⚙️ Сценарии")
                .pathsToMatch("/api/scenarios/**", "/api/scenario-runs/**")
                .build();
    }

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title(API_TITLE)
                        .description(API_DESCRIPTION)
                        .version(API_VERSION)
                        .contact(new Contact()
                                .name("Железнов Максим")
                                .email("Zheleznov.M.Yu@sberbank.ru")))
                .servers(List.of(
                        new Server()
                                .url("http://localhost:" + serverPort + path)
                                .description("Локальный сервер разработки")
                ));
    }

    @Bean
    public OpenApiCustomizer changeSomeProperties() {
        return this::customizeOpenAPI;
    }

    private void customizeOpenAPI(OpenAPI openApi) {
        changeGlobalObjectProperties(openApi);
        changeEndpointsProperties(openApi);
    }

    private void changeEndpointsProperties(OpenAPI openApi) {
        if (openApi.getPaths() != null) {
            openApi.getPaths().forEach(this::processEndpoint);
        }
    }

    private void processEndpoint(String p, PathItem item) {
        changeOperationProperties(item.getGet());
        changeOperationProperties(item.getPost());
        changeOperationProperties(item.getPut());
        changeOperationProperties(item.getDelete());
        changeOperationProperties(item.getPatch());
        changeOperationProperties(item.getOptions());
        changeOperationProperties(item.getHead());
    }

    private void changeGlobalObjectProperties(OpenAPI openApi) {
        if (openApi.getComponents() != null && openApi.getComponents().getSchemas() != null) {
            openApi.getComponents().getSchemas().values()
                    //.filter(schema -> schema instanceof ObjectSchema)
                    .forEach(this::removePropertiesFromSchema);
        }
    }

    private void changeOperationProperties(Operation operation) {
        if (operation == null) {
            return;
        }
        if (operation.getParameters() != null) {
            operation.getParameters()
                    .forEach(parameter -> removePropertiesFromSchema(parameter.getSchema()));
        }
        if (operation.getResponses() != null) {
            operation.getResponses().forEach(this::processResponseMap);
        }
    }

    @SuppressWarnings("java:S2973") // null-check + nested forEach for schema cleanup
    private void processResponseMap(String code, ApiResponse response) {
        if (response.getContent() != null) {
            response.getContent()
                    .forEach(this::removePropertiesFromMediaType);
        }
    }

    private void removePropertiesFromMediaType(String mediaType,
                                               io.swagger.v3.oas.models.media.MediaType mediaTypeObject) {
        removePropertiesFromSchema(mediaTypeObject.getSchema());
    }

    private void removePropertiesFromSchema(Schema<?> schema) {
        if (schema == null) {
            return;
        }
        log.info("Remove properties from {}", schema.getName());
        schema.setAdditionalProperties(null);
        schema.setDefault(null);
        schema.setDefaultSetFlag(false);
        schema.setUnevaluatedItems(null);
        schema.setContains(null);
        if (schema.getItems() != null) {
            removePropertiesFromSchema(schema.getItems());
        }
    }
}
