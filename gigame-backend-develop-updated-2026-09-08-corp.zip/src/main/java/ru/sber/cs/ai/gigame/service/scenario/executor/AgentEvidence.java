package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Рабочая тетрадь агента: записи «пункт плана — значение — дословная цитата —
 * документ» и их ЦИТАТНАЯ ВАЛИДАЦИЯ кодом (grounding by construction).
 * <p>
 * Модель обязана подтверждать каждое значение цитатой из документа; код
 * детерминированно проверяет, что цитата действительно входит в текст
 * указанного документа (с нормализацией пробелов и регистра). Значение без
 * подтверждённой цитаты не может попасть в финальный ответ как факт — это
 * убирает класс ошибок «тихо выдумано» по построению, а не промптом.
 */
@Slf4j
public final class AgentEvidence {

    /** Вердикты цитатной валидации. */
    public static final String CONFIRMED = "ПОДТВЕРЖДЕНО";
    public static final String CALCULATED = "РАСЧЁТНОЕ (исходные числа подтверждены)";
    public static final String QUOTE_NOT_FOUND = "ЦИТАТА НЕ НАЙДЕНА В ДОКУМЕНТЕ";
    public static final String DOC_NOT_FOUND = "ДОКУМЕНТ НЕ НАЙДЕН";
    public static final String NO_QUOTE = "БЕЗ ЦИТАТЫ";
    /** Значение-заглушка, которому цитата не нужна. */
    public static final String NOT_SPECIFIED = "не указано";
    /** Максимум вопросов пользователю с одного узла. */
    static final int MAX_QUESTIONS = 5;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private AgentEvidence() {
    }

    /**
     * Запись рабочей тетради.
     *
     * @param item    номер пункта плана (0 — вне плана)
     * @param name    название пункта
     * @param value   извлечённое значение
     * @param quote   дословная цитата-подтверждение из документа
     * @param doc     имя документа-источника
     * @param verdict вердикт цитатной валидации (заполняется кодом)
     */
    public record Entry(int item, String name, String value, String quote, String doc, String verdict) {

        Entry withVerdict(String v) {
            return new Entry(item, name, value, quote, doc, v);
        }
    }

    /**
     * Разбирает рабочую тетрадь из финального ответа агента: последний
     * JSON-объект с массивом «записи». Терпим к тексту вокруг JSON.
     *
     * @param answer финальный текст агента
     * @return записи или пустой список, если тетрадь не распознана
     */
    public static List<Entry> parse(String answer) {
        log.info("[{}] AgentEvidence.parse, answerChars={}",
                CurrentUserHolder.getCurrentUser(), answer == null ? 0 : answer.length());
        if (answer == null) {
            return List.of();
        }
        int start = answer.indexOf('{');
        int end = answer.lastIndexOf('}');
        if (start < 0 || end <= start) {
            return List.of();
        }
        try {
            JsonNode root = MAPPER.readTree(answer.substring(start, end + 1));
            JsonNode records = root.get("записи");
            if (records == null || !records.isArray()) {
                return List.of();
            }
            List<Entry> entries = new ArrayList<>();
            for (JsonNode r : records) {
                entries.add(new Entry(
                        r.path("пункт").asInt(0),
                        r.path("название").asText(""),
                        r.path("значение").asText(""),
                        r.path("цитата").asText(""),
                        r.path("документ").asText(""),
                        null));
            }
            return entries.isEmpty() ? List.of() : entries;
        } catch (Exception e) {
            log.warn("[{}] Рабочая тетрадь агента не распознана: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    /**
     * Разбирает план-чеклист: JSON-массив строк (терпимо к тексту вокруг).
     *
     * @param raw ответ модели-планировщика
     * @return пункты плана или пустой список
     */
    public static List<String> parsePlan(String raw) {
        log.info("[{}] AgentEvidence.parsePlan, rawChars={}",
                CurrentUserHolder.getCurrentUser(), raw == null ? 0 : raw.length());
        if (raw == null) {
            return List.of();
        }
        int start = raw.indexOf('[');
        int end = raw.lastIndexOf(']');
        if (start < 0 || end <= start) {
            return List.of();
        }
        try {
            JsonNode arr = MAPPER.readTree(raw.substring(start, end + 1));
            if (!arr.isArray()) {
                return List.of();
            }
            List<String> plan = new ArrayList<>();
            for (JsonNode item : arr) {
                String text = item.asText("").strip();
                if (!text.isEmpty()) {
                    plan.add(text);
                }
            }
            return plan.isEmpty() ? List.of() : plan;
        } catch (Exception e) {
            log.warn("[{}] План агента не распознан: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    /**
     * Разбирает ReWOO-план поисков: JSON-массив объектов
     * {@code {"запрос": "...", "документы": ["..."]}} (документы опциональны).
     *
     * @param raw ответ модели-планировщика запросов
     * @return поисковые запросы или пустой список
     */
    public static List<AgentDocumentTools.SearchRequest> parseSearchPlan(String raw) {
        log.info("[{}] AgentEvidence.parseSearchPlan, rawChars={}",
                CurrentUserHolder.getCurrentUser(), raw == null ? 0 : raw.length());
        if (raw == null) {
            return List.of();
        }
        int start = raw.indexOf('[');
        int end = raw.lastIndexOf(']');
        if (start < 0 || end <= start) {
            return List.of();
        }
        try {
            JsonNode arr = MAPPER.readTree(raw.substring(start, end + 1));
            if (!arr.isArray()) {
                return List.of();
            }
            List<AgentDocumentTools.SearchRequest> queries = new ArrayList<>();
            for (JsonNode item : arr) {
                AgentDocumentTools.SearchRequest request = parseSearchQuery(item);
                if (request != null) {
                    queries.add(request);
                }
            }
            return queries.isEmpty() ? List.of() : queries;
        } catch (Exception e) {
            log.warn("[{}] ReWOO-план поисков не распознан: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    private static AgentDocumentTools.SearchRequest parseSearchQuery(JsonNode item) {
        String query = item.isTextual() ? item.asText() : item.path("запрос").asText("");
        if (query.isBlank()) {
            return null;
        }
        List<String> docs = new ArrayList<>();
        for (JsonNode doc : item.path("документы")) {
            if (!doc.asText("").isBlank()) {
                docs.add(doc.asText());
            }
        }
        return new AgentDocumentTools.SearchRequest(query, docs.isEmpty() ? null : docs);
    }

    /**
     * Цитатная валидация: каждой записи проставляется вердикт — цитата
     * дословно (с нормализацией пробелов/регистра) входит в текст
     * указанного документа или нет.
     *
     * @param entries    записи тетради
     * @param docsByName документы прогона: имя — текст
     * @return записи с вердиктами
     */
    public static List<Entry> validate(List<Entry> entries, Map<String, String> docsByName) {
        log.info("[{}] AgentEvidence.validate, entries={}, docs={}",
                CurrentUserHolder.getCurrentUser(),
                entries == null ? 0 : entries.size(),
                docsByName == null ? 0 : docsByName.size());
        List<Entry> result = new ArrayList<>();
        for (Entry e : entries) {
            result.add(validatedEntry(e, docsByName));
        }
        return result;
    }

    private static Entry validatedEntry(Entry e, Map<String, String> docsByName) {
        if (e.quote() == null || e.quote().isBlank()) {
            return e.withVerdict(NOT_SPECIFIED.equalsIgnoreCase(
                    String.valueOf(e.value()).strip()) ? CONFIRMED : NO_QUOTE);
        }
        String docText = resolveDoc(e.doc(), docsByName);
        if (docText != null && normalized(docText).contains(normalized(e.quote()))) {
            return e.withVerdict(CONFIRMED);
        }
        // вычисленные значения (порог из процента и НМЦ, период из даты и
        // срока) не имеют дословной цитаты — цитата содержит исходные данные
        // расчёта; если все числа цитаты найдены в документе, значение
        // расчётное, а не выдуманное (иначе ложные вопросы пользователю)
        if (docText != null && sourceNumbersPresent(e.quote(), docText)) {
            return e.withVerdict(CALCULATED);
        }
        // спасательный поиск по ВСЕМ документам: неточное поле «документ»
        // не должно аннулировать реально существующие данные (наблюдалось:
        // эталонно верные суммы отклонены «ДОКУМЕНТ НЕ НАЙДЕН» и потеряны)
        String byQuote = docNameContaining(e.quote(), docsByName);
        if (byQuote != null) {
            return new Entry(e.item(), e.name(), e.value(), e.quote(), byQuote, CONFIRMED);
        }
        String byNumbers = singleDocWithNumbers(e.quote(), docsByName);
        if (byNumbers != null) {
            return new Entry(e.item(), e.name(), e.value(), e.quote(), byNumbers, CALCULATED);
        }
        return e.withVerdict(docText == null ? DOC_NOT_FOUND : QUOTE_NOT_FOUND);
    }

    /** Имя документа, дословно содержащего цитату (первое совпадение). */
    private static String docNameContaining(String quote, Map<String, String> docsByName) {
        String q = normalized(quote);
        for (var en : docsByName.entrySet()) {
            if (normalized(en.getValue()).contains(q)) {
                return en.getKey();
            }
        }
        return null;
    }

    /**
     * Единственный документ, содержащий ВСЕ числа цитаты. Требуется хотя бы
     * одно число от 5 цифр (короткие числа есть везде — ложные совпадения),
     * а неоднозначность (числа в нескольких документах) не спасается.
     */
    private static String singleDocWithNumbers(String quote, Map<String, String> docsByName) {
        List<String> nums = new ArrayList<>();
        Matcher m = Pattern.compile("\\d[\\d\\s\\u00A0]{2,}").matcher(quote);
        while (m.find()) {
            String digits = m.group().replaceAll("[\\s\\u00A0]", "");
            if (digits.length() >= 3) {
                nums.add(digits);
            }
        }
        if (nums.isEmpty() || nums.stream().noneMatch(n -> n.length() >= 5)) {
            return null;
        }
        String found = null;
        for (var en : docsByName.entrySet()) {
            String doc = normalized(en.getValue());
            if (nums.stream().allMatch(doc::contains)) {
                if (found != null) {
                    return null;
                }
                found = en.getKey();
            }
        }
        return found;
    }

    /**
     * Все числовые последовательности цитаты (от 3 цифр) присутствуют в
     * документе (без учёта пробелов-разрядов и регистра).
     *
     * @param quote   цитата с исходными данными расчёта
     * @param docText текст документа
     * @return {@code true}, если числа найдены (и они вообще есть)
     */
    private static boolean sourceNumbersPresent(String quote, String docText) {
        Matcher numbers = Pattern.compile("\\d[\\d\\s\\u00A0]{2,}").matcher(quote);
        String doc = normalized(docText);
        boolean found = false;
        while (numbers.find()) {
            String digits = numbers.group().replaceAll("[\\s\\u00A0]", "");
            if (digits.length() < 3) {
                continue;
            }
            found = true;
            if (!doc.contains(digits)) {
                return false;
            }
        }
        return found;
    }

    /** Точное имя, иначе единственное совпадение по подстроке. */
    private static String resolveDoc(String name, Map<String, String> docsByName) {
        if (name == null || name.isBlank()) {
            return null;
        }
        String exact = docsByName.get(name);
        if (exact != null) {
            return exact;
        }
        String needle = name.toLowerCase(Locale.ROOT);
        List<String> matches = docsByName.keySet().stream()
                .filter(k -> k.toLowerCase(Locale.ROOT).contains(needle)
                        || needle.contains(k.toLowerCase(Locale.ROOT)))
                .toList();
        return matches.size() == 1 ? docsByName.get(matches.get(0)) : null;
    }

    /** Нормализация для сверки цитат: без пробельных, в нижнем регистре, ё=е. */
    static String normalized(String s) {
        return s.replaceAll("[\\s\\u00A0]+", "")
                .toLowerCase(Locale.ROOT)
                .replace('ё', 'е')
                .replace("«", "\"").replace("»", "\"");
    }

    /**
     * Номера пунктов плана, не закрытых ни одной доказанной записью тетради.
     *
     * @param planSize количество пунктов плана (нумерация с 1)
     * @param entries  записи тетради
     * @return непокрытые номера
     */
    public static Set<Integer> uncoveredItems(int planSize, List<Entry> entries) {
        log.debug("[{}] AgentEvidence.uncoveredItems, planSize={}, entries={}",
                CurrentUserHolder.getCurrentUser(), planSize, entries == null ? 0 : entries.size());
        Set<Integer> uncovered = new LinkedHashSet<>();
        for (int i = 1; i <= planSize; i++) {
            uncovered.add(i);
        }
        for (Entry e : entries) {
            if (covers(e)) {
                uncovered.remove(e.item());
            }
        }
        return uncovered;
    }

    /**
     * Запись закрывает пункт плана, если её данные доказаны (подтверждено или
     * расчётное), честно помечены «не указано» либо ещё не проходили
     * валидацию. ОТКЛОНЁННАЯ запись пункт не закрывает: наблюдался узел, где
     * 14 отклонённых записей «закрыли» весь план — добор не запустился, и
     * финал потерял реально прочитанные данные («акты: не указаны»).
     */
    private static boolean covers(Entry e) {
        if (e.verdict() == null) {
            return true;
        }
        return CONFIRMED.equals(e.verdict()) || CALCULATED.equals(e.verdict())
                || NOT_SPECIFIED.equalsIgnoreCase(String.valueOf(e.value()).strip());
    }

    /**
     * Вопросы пользователю (асинхронный HITL) из проверенной тетради:
     * значения без подтверждённой цитаты и ненайденные данные. Механизм
     * универсален — основан только на вердиктах валидации.
     *
     * @param plan      пункты плана
     * @param validated записи с вердиктами
     * @return тексты вопросов (не более {@link #MAX_QUESTIONS})
     */
    public static List<String> buildQuestions(List<String> plan, List<Entry> validated) {
        log.debug("[{}] AgentEvidence.buildQuestions, validated={}",
                CurrentUserHolder.getCurrentUser(), validated == null ? 0 : validated.size());
        List<String> questions = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (Entry e : validated) {
            if (questions.size() >= MAX_QUESTIONS) {
                break;
            }
            String name = e.name() == null || e.name().isBlank()
                    ? planItemName(plan, e.item()) : e.name();
            String question = questionFor(e, name);
            if (question != null && seen.add(name)) {
                questions.add(question);
            }
        }
        return questions;
    }

    private static String questionFor(Entry e, String name) {
        boolean notSpecified = NOT_SPECIFIED.equalsIgnoreCase(String.valueOf(e.value()).strip());
        if (CONFIRMED.equals(e.verdict()) && notSpecified) {
            return "По пункту «" + name + "» данные в документах не найдены — "
                    + "подскажите значение или в каком документе/разделе его искать.";
        }
        if (CALCULATED.equals(e.verdict())) {
            // расчётное значение с подтверждёнными исходными — не спорное
            return null;
        }
        if (!CONFIRMED.equals(e.verdict())) {
            return "По пункту «" + name + "» значение «" + e.value()
                    + "» не удалось подтвердить цитатой из документов (" + e.verdict()
                    + ") — уточните правильное значение или где его искать.";
        }
        return null;
    }

    private static String planItemName(List<String> plan, int item) {
        return item >= 1 && item <= plan.size() ? plan.get(item - 1) : "пункт " + item;
    }

    /**
     * Тетрадь с вердиктами в виде JSON для финального вызова.
     *
     * @param entries записи с вердиктами
     * @return JSON-строка
     */
    public static String toJson(List<Entry> entries) {
        log.debug("[{}] AgentEvidence.toJson, entries={}",
                CurrentUserHolder.getCurrentUser(), entries == null ? 0 : entries.size());
        if (entries == null) {
            return "[]";
        }
        try {
            List<Map<String, Object>> rows = new ArrayList<>();
            for (Entry e : entries) {
                rows.add(Map.of(
                        "пункт", e.item(),
                        "название", e.name(),
                        "значение", e.value(),
                        "цитата", e.quote(),
                        "документ", e.doc(),
                        "проверка", String.valueOf(e.verdict())));
            }
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(rows);
        } catch (Exception e) {
            return entries.toString();
        }
    }
}
