package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Кодовые операции Формы 3 (опыт участника закупки) без участия LLM.
 * <p>
 * «реестр_документов» разбирает тексты комплекта: УПД (номер, дата, продавец,
 * покупатель, договор, сумма «Всего к оплате», дата приёмки и подпись
 * заказчика), спецификации (номер, договор, дата подписания, суммы, текст) и
 * договоры (номер, дата). «строки_формы3» по реестру и выверенным критериям
 * Шага 1 строит строки формы к1…к12: сопоставление УПД со спецификацией по
 * номеру либо по сумме этапа (все кандидаты перечисляются), периоды по датам,
 * технологии поиском слов из критериев в тексте спецификации, заказчик по
 * перечню рейтинга. Форматы взяты с УПД/спецификаций ЭДО СберКорус.
 */
final class Form3Ops {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final int TEXT_LIMIT = 30000;
    private static final int MAX_SPEC_NUMBER = 8;

    private static final Pattern UPD_HEAD = Pattern.compile(
            "Сч[её]т-?фактура\\s*[N№]\\s*(\\d+)\\s+от\\s+(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern UPD_SELLER = Pattern.compile("Продавец:\\s*(.+?)\\s*\\(2\\)");
    private static final Pattern UPD_BUYER = Pattern.compile("Покупатель:\\s*(.+?)\\s*\\(6\\)");
    private static final Pattern UPD_TOTAL = Pattern.compile("Всего к оплате\\s*\\(9\\)((?:\\s*(?:[\\d ]+[,.]\\d{2}|×|без НДС|без налога|-))+)");
    private static final Pattern UPD_ACCEPT = Pattern.compile(
            "\"\\s*(\\d{1,2})\\s*\"\\s*([а-яё]+)\\s*(\\d{4})\\s*г\\.\\s*\\[18\\]");
    private static final Pattern UPD_BUYER_SIGN = Pattern.compile("Электронная подпись\\s+[А-ЯЁ][^\\[]{3,80}?\\[20\\]");
    private static final Pattern CONTRACT_REF = Pattern.compile(
            "Договор[а-я]*\\s*№?\\s*(\\d{5,12})(?:[^\\n]{0,60}?от\\s*(\\d{2}\\.\\d{2}\\.\\d{4}))?");
    private static final Pattern SPEC_REF = Pattern.compile("Спецификаци[а-я]*[^\\n№]{0,120}?№\\s*(\\d{6,8})");
    private static final Pattern SPEC_HEAD = Pattern.compile("^\\W*\\d?\\s*Спецификаци", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SPEC_CONTRACT = Pattern.compile("к\\s+Договору\\s*№?\\s*(\\d{5,12})");
    private static final Pattern CONTRACT_HEAD = Pattern.compile("^\\W*(ДОГОВОР|Договор)\\s*№");
    private static final Pattern REPORT_HEAD = Pattern.compile("^\\W*(ОТЧ[ЕЁ]Т|Отч[её]т)\\s+о\\s+выполненн", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SIGN_STAMP = Pattern.compile("(\\d{2}\\.\\d{2}\\.\\d{4})\\s+\\d{2}:\\d{2}:\\d{2}");
    private static final Pattern AMOUNT = Pattern.compile("(?<![\\d,.])(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?![\\d])");
    private static final Pattern FILE_NUMBER = Pattern.compile("(?<!\\d)(\\d{7,8})(?!\\d)");
    private static final Pattern CONTRACT_SIGNED = Pattern.compile("Дата подписания:\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");

    private static final Pattern CRIT_PERIOD_QUAL = Pattern.compile(
            "(?m)^Период опыта участника по квалификационным требованиям\\s*[—-]\\s*календарные даты\\s*\\|\\s*с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern CRIT_PERIOD_METHOD = Pattern.compile(
            "(?m)^Период опыта по методике оценки\\s*[—-]\\s*календарные даты\\s*\\|\\s*с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern CRIT_LOT = Pattern.compile("^ЛОТ\\s*№\\s*(\\d+)\\s*\\((Квалификационн|Методическ)");
    private static final Pattern CRIT_TECH = Pattern.compile("^Технология\\s*\\d+\\s*\\|\\s*([^|]+?)\\s*\\|");
    private static final String DEFAULT_RATING = "Сбербанк|СБЕР\\b|ВТБ|Газпромбанк|Альфа-?Банк|Россельхозбанк|Открытие|Совкомбанк|"
            + "Райффайзен|Росбанк|Тинькофф|Т-Банк|Промсвязьбанк|Московский кредитный банк|МКБ|ЮниКредит|Ак Барс|Почта Банк|"
            + "Уралсиб|Банк Санкт-Петербург|Ситибанк|Хоум Банк|Русский Стандарт|ОТП Банк|Зенит|ДОМ\\.РФ|Новикомбанк|Абсолют";

    private static final Map<String, String> MONTHS = Map.ofEntries(
            Map.entry("января", "01"), Map.entry("февраля", "02"), Map.entry("марта", "03"),
            Map.entry("апреля", "04"), Map.entry("мая", "05"), Map.entry("июня", "06"),
            Map.entry("июля", "07"), Map.entry("августа", "08"), Map.entry("сентября", "09"),
            Map.entry("октября", "10"), Map.entry("ноября", "11"), Map.entry("декабря", "12"));

    private Form3Ops() {
    }

    /** Документ комплекта: имя файла и текст. */
    record Source(String name, String text) {
    }

    // ------------------------------------------------------------------ реестр

    /**
     * Реестр документов комплекта в JSON: {@code {"упд": [...], "спецификации": [...],
     * "договоры": [...], "прочее": [...]}}.
     *
     * @param sources документы комплекта
     * @return JSON реестра
     */
    static String registry(List<Source> sources) {
        List<Map<String, Object>> upds = new ArrayList<>();
        List<Map<String, Object>> specs = new ArrayList<>();
        List<Map<String, Object>> contracts = new ArrayList<>();
        List<String> reports = new ArrayList<>();
        List<String> other = new ArrayList<>();
        for (Source source : sources) {
            String text = normalize(source.text());
            if (UPD_HEAD.matcher(text).find()) {
                upds.add(parseUpd(source.name(), text));
            } else if (REPORT_HEAD.matcher(text).find()) {
                reports.add(source.name());
            } else if (SPEC_HEAD.matcher(text).find() && SPEC_REF.matcher(text).find()) {
                specs.add(parseSpec(source.name(), text));
            } else if (CONTRACT_HEAD.matcher(text).find() || CONTRACT_SIGNED.matcher(text).find()) {
                contracts.add(parseContract(source.name(), text));
            } else {
                other.add(source.name());
            }
        }
        Map<String, Object> registry = new LinkedHashMap<>();
        registry.put("упд", upds);
        registry.put("спецификации", specs);
        registry.put("договоры", contracts);
        registry.put("отчёты", reports);
        registry.put("прочее", other);
        return toJson(registry);
    }

    /**
     * Нормализация текста ЭДО-документа: неразрывные пробелы, мягкие переносы,
     * возвраты каретки.
     */
    static String normalize(String text) {
        return text == null ? "" : text.replace('\u00A0', ' ').replace("\u00AD", "").replace("\r", "");
    }

    private static Map<String, Object> parseUpd(String name, String text) {
        Map<String, Object> upd = new LinkedHashMap<>();
        upd.put("файл", name);
        Matcher head = UPD_HEAD.matcher(text);
        head.find();
        upd.put("номер", head.group(1));
        upd.put("дата", head.group(2));
        upd.put("продавец", firstGroup(UPD_SELLER, text));
        upd.put("покупатель", firstGroup(UPD_BUYER, text));
        Matcher contract = CONTRACT_REF.matcher(text);
        String contractNumber = "";
        String contractDate = "";
        if (contract.find()) {
            contractNumber = contract.group(1);
            contractDate = contract.group(2) == null ? "" : contract.group(2);
        }
        upd.put("договор", contractNumber);
        upd.put("договор_дата", contractDate);
        upd.put("сумма", totalAmount(text));
        upd.put("дата_приёмки", acceptanceDate(text));
        upd.put("подпись_заказчика", UPD_BUYER_SIGN.matcher(text).find());
        upd.put("спецификация", specReference(text, name, contractNumber));
        return upd;
    }

    private static String totalAmount(String text) {
        Matcher m = UPD_TOTAL.matcher(text);
        if (!m.find()) {
            return "";
        }
        String last = "";
        Matcher amounts = AMOUNT.matcher(m.group(1));
        while (amounts.find()) {
            last = amounts.group(1).replace(" ", "") + "." + amounts.group(2);
        }
        return last;
    }

    private static String acceptanceDate(String text) {
        Matcher m = UPD_ACCEPT.matcher(text);
        if (!m.find()) {
            return "";
        }
        String month = MONTHS.get(m.group(2).toLowerCase(Locale.ROOT));
        if (month == null) {
            return "";
        }
        return String.format("%02d.%s.%s", Integer.parseInt(m.group(1)), month, m.group(3));
    }

    private static String specReference(String text, String fileName, String contractNumber) {
        Matcher inText = SPEC_REF.matcher(text);
        if (inText.find()) {
            return inText.group(1);
        }
        Matcher inName = FILE_NUMBER.matcher(fileName);
        while (inName.find()) {
            if (!inName.group(1).equals(contractNumber) && inName.group(1).length() <= MAX_SPEC_NUMBER) {
                return inName.group(1);
            }
        }
        return "";
    }

    private static Map<String, Object> parseSpec(String name, String text) {
        Map<String, Object> spec = new LinkedHashMap<>();
        spec.put("файл", name);
        spec.put("номер", firstGroup(SPEC_REF, text));
        spec.put("договор", firstGroup(SPEC_CONTRACT, text));
        spec.put("дата", latestStamp(text));
        Set<String> amounts = new LinkedHashSet<>();
        Matcher m = AMOUNT.matcher(text);
        while (m.find()) {
            amounts.add(m.group(1).replace(" ", "") + "." + m.group(2));
        }
        spec.put("суммы", new ArrayList<>(amounts));
        spec.put("текст", text.length() > TEXT_LIMIT ? text.substring(0, TEXT_LIMIT) : text);
        return spec;
    }

    private static Map<String, Object> parseContract(String name, String text) {
        Map<String, Object> contract = new LinkedHashMap<>();
        contract.put("файл", name);
        Matcher ref = CONTRACT_REF.matcher(text);
        contract.put("номер", ref.find() ? ref.group(1) : "");
        String signed = firstGroup(CONTRACT_SIGNED, text);
        contract.put("дата", signed.isEmpty() ? latestStamp(text) : signed);
        return contract;
    }

    private static String latestStamp(String text) {
        LocalDate latest = null;
        Matcher m = SIGN_STAMP.matcher(text);
        while (m.find()) {
            LocalDate d = parseDate(m.group(1));
            if (d != null && (latest == null || d.isAfter(latest))) {
                latest = d;
            }
        }
        return latest == null ? "" : latest.format(DATE);
    }

    // ------------------------------------------------------------------ строки

    /**
     * Строки Формы 3 (к1…к12) по реестру документов и критериям Шага 1.
     *
     * @param op           конфиг операции ({@code "заказчики_в_рейтинге"} — regex)
     * @param registryJson реестр из «реестр_документов»
     * @param criteriaText текст выверенных критериев (строки «Критерий | Значение | …»)
     * @return JSON-массив строк
     */
    @SuppressWarnings("unchecked")
    static String rows(Map<String, Object> op, String registryJson, String criteriaText) {
        Map<String, Object> registry = parseRegistry(registryJson);
        List<Map<String, Object>> upds = (List<Map<String, Object>>) registry.getOrDefault("упд", List.of());
        List<Map<String, Object>> specs = (List<Map<String, Object>>) registry.getOrDefault("спецификации", List.of());
        Criteria criteria = Criteria.parse(normalize(criteriaText));
        Pattern rating = Pattern.compile(String.valueOf(op.getOrDefault("заказчики_в_рейтинге", DEFAULT_RATING)),
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        List<Map<String, Object>> rows = new ArrayList<>();
        for (Map<String, Object> upd : upds) {
            rows.add(row(upd, matchSpecs(upd, specs), criteria, rating));
        }
        return toJson(rows);
    }

    private static Map<String, Object> parseRegistry(String text) {
        int from = text.indexOf('{');
        int end = from < 0 ? -1 : JsonCalcUtils.balancedEnd(text, from);
        if (from < 0 || end < 0) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: во входе нет реестра документов");
        }
        try {
            return MAPPER.readValue(text.substring(from, end + 1), Map.class);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: реестр не разобран: " + e.getMessage());
        }
    }

    /** Кандидаты-спецификации: по номеру из УПД, иначе того же договора с равной суммой этапа. */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> matchSpecs(Map<String, Object> upd, List<Map<String, Object>> specs) {
        String number = str(upd.get("спецификация"));
        List<Map<String, Object>> byNumber = new ArrayList<>();
        List<Map<String, Object>> bySum = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (Map<String, Object> spec : specs) {
            if (!seen.add(str(spec.get("номер")))) {
                continue;
            }
            if (!number.isEmpty() && number.equals(str(spec.get("номер")))) {
                byNumber.add(spec);
            }
            boolean sameContract = str(spec.get("договор")).isEmpty() || str(upd.get("договор")).isEmpty()
                    || str(spec.get("договор")).equals(str(upd.get("договор")));
            List<String> sums = (List<String>) spec.getOrDefault("суммы", List.of());
            if (sameContract && !str(upd.get("сумма")).isEmpty() && sums.contains(str(upd.get("сумма")))) {
                bySum.add(spec);
            }
        }
        return byNumber.isEmpty() ? bySum : byNumber;
    }

    private static Map<String, Object> row(Map<String, Object> upd, List<Map<String, Object>> candidates,
                                           Criteria criteria, Pattern rating) {
        Map<String, Object> row = new LinkedHashMap<>();
        String seller = str(upd.get("продавец"));
        String buyer = str(upd.get("покупатель"));
        row.put("к1", seller);
        row.put("к2", seller);
        row.put("к3", buyer);
        row.put("к4", contractLabel(upd));
        row.put("к5", specLabel(candidates));
        row.put("к6", "УПД " + upd.get("номер") + " от " + upd.get("дата"));
        String accepted = str(upd.get("дата_приёмки"));
        row.put("к7", accepted.isEmpty() ? str(upd.get("дата")) : accepted);
        String sum = str(upd.get("сумма"));
        boolean signed = Boolean.TRUE.equals(upd.get("подпись_заказчика"));
        row.put("к8", sum);
        row.put("к9", signed ? sum : "0");
        row.put("к10", signed ? "зачтено" : "акт не подписан заказчиком");
        List<String> found = technologies(candidates, criteria.allTechnologies());
        String techLabel = found.isEmpty() ? (candidates.isEmpty() ? "нет данных" : "из требуемых не найдено")
                : String.join(", ", found);
        row.put("к11", techLabel);
        row.put("к12", audit(upd, candidates, found, criteria, rating, buyer));
        return row;
    }

    private static String contractLabel(Map<String, Object> upd) {
        String number = str(upd.get("договор"));
        if (number.isEmpty()) {
            return "нет данных";
        }
        String date = str(upd.get("договор_дата"));
        return "договор " + number + (date.isEmpty() ? "" : " от " + date);
    }

    private static String specLabel(List<Map<String, Object>> candidates) {
        if (candidates.isEmpty()) {
            return "не сопоставлена";
        }
        List<String> labels = new ArrayList<>();
        for (Map<String, Object> spec : candidates) {
            String date = str(spec.get("дата"));
            labels.add(spec.get("номер") + (date.isEmpty() ? "" : " от " + date));
        }
        String joined = String.join(" или ", labels);
        return candidates.size() == 1 ? joined
                : joined + " (сумма этапа совпадает в нескольких спецификациях — выбрать по форме)";
    }

    /** Технологии из критериев, найденные словами в тексте спецификаций-кандидатов. */
    private static List<String> technologies(List<Map<String, Object>> candidates, List<String> required) {
        List<String> found = new ArrayList<>();
        for (String tech : required) {
            for (Map<String, Object> spec : candidates) {
                if (containsTechnology(str(spec.get("текст")), tech)) {
                    found.add(tech);
                    break;
                }
            }
        }
        return found;
    }

    /** Название вида «Go (Golang)» ищется по любому из вариантов, границы — не буквы. */
    static boolean containsTechnology(String text, String technology) {
        String cleaned = technology.replace(")", "").replace("(", " ").strip();
        for (String variant : cleaned.split("\\s+|/")) {
            if (variant.length() < 2) {
                continue;
            }
            Pattern p = Pattern.compile("(?<![A-Za-zА-Яа-я0-9])" + Pattern.quote(variant) + "(?![A-Za-zА-Яа-я0-9])",
                    Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            if (p.matcher(text).find()) {
                return true;
            }
        }
        return false;
    }

    private static String audit(Map<String, Object> upd, List<Map<String, Object>> candidates, List<String> found,
                                Criteria criteria, Pattern rating, String buyer) {
        String actDate = str(upd.get("дата_приёмки")).isEmpty() ? str(upd.get("дата")) : str(upd.get("дата_приёмки"));
        List<String> parts = new ArrayList<>();
        parts.add("период квалификации: " + periodVerdict(actDate, criteria.qualFrom, criteria.qualTo));
        parts.add("период методики: " + periodVerdict(actDate, criteria.methodFrom, criteria.methodTo));
        for (Map.Entry<String, List<String>> lot : criteria.lots.entrySet()) {
            List<String> hit = new ArrayList<>();
            List<String> miss = new ArrayList<>();
            for (String tech : lot.getValue()) {
                (found.contains(tech) ? hit : miss).add(tech);
            }
            parts.add("лот " + lot.getKey() + ": " + (hit.isEmpty() ? "ничего не найдено" : "найдено " + String.join(", ", hit))
                    + (miss.isEmpty() ? "" : "; не найдено " + String.join(", ", miss)));
        }
        parts.add(rating.matcher(buyer).find() ? "заказчик: в рейтинге (" + buyer + ")"
                : "заказчик: не подтверждён кодом — проверить по рейтингу (" + buyer + ")");
        if (candidates.size() > 1) {
            parts.add("спецификация: несколько кандидатов по сумме этапа");
        }
        if (candidates.isEmpty()) {
            parts.add("спецификация: не найдена по номеру и сумме");
        }
        return String.join("; ", parts);
    }

    static String periodVerdict(String actDate, LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            return "проверить вручную (в критериях нет календарных дат)";
        }
        LocalDate act = parseDate(actDate);
        if (act == null) {
            return "дата акта не распознана";
        }
        boolean inside = !act.isBefore(from) && !act.isAfter(to);
        return inside ? "соответствует (акт " + actDate + " внутри с " + from.format(DATE) + " по " + to.format(DATE) + ")"
                : "не соответствует (акт " + actDate + " вне периода с " + from.format(DATE) + " по " + to.format(DATE) + ")";
    }

    // ------------------------------------------------------------------ критерии

    /** Выверенные критерии Шага 1: периоды и технологии по лотам. */
    static final class Criteria {
        private LocalDate qualFrom;
        private LocalDate qualTo;
        private LocalDate methodFrom;
        private LocalDate methodTo;
        private final Map<String, List<String>> lots = new LinkedHashMap<>();
        private final Map<String, List<String>> methodLots = new LinkedHashMap<>();

        static Criteria parse(String text) {
            Criteria c = new Criteria();
            Matcher q = CRIT_PERIOD_QUAL.matcher(text);
            if (q.find()) {
                c.qualFrom = parseDate(q.group(1));
                c.qualTo = parseDate(q.group(2));
            }
            Matcher m = CRIT_PERIOD_METHOD.matcher(text);
            if (m.find()) {
                c.methodFrom = parseDate(m.group(1));
                c.methodTo = parseDate(m.group(2));
            }
            c.parseLots(text);
            return c;
        }

        private void parseLots(String text) {
            String lot = null;
            boolean qualification = true;
            for (String line : text.split("\n")) {
                Matcher head = CRIT_LOT.matcher(line.strip());
                if (head.find()) {
                    lot = head.group(1);
                    qualification = head.group(2).startsWith("Квалификац");
                    continue;
                }
                Matcher tech = CRIT_TECH.matcher(line.strip());
                if (lot != null && tech.find() && !tech.group(1).toLowerCase(Locale.ROOT).startsWith("не указано")) {
                    (qualification ? lots : methodLots).computeIfAbsent(lot, k -> new ArrayList<>()).add(tech.group(1));
                }
            }
            for (Map.Entry<String, List<String>> e : methodLots.entrySet()) {
                lots.putIfAbsent(e.getKey(), e.getValue());
            }
        }

        List<String> allTechnologies() {
            Set<String> all = new LinkedHashSet<>();
            lots.values().forEach(all::addAll);
            return new ArrayList<>(all);
        }
    }

    // ------------------------------------------------------------------ утилиты

    private static String firstGroup(Pattern p, String text) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1).strip() : "";
    }

    private static LocalDate parseDate(String value) {
        try {
            return LocalDate.parse(value, DATE);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }

    private static String str(Object value) {
        return value == null ? "" : String.valueOf(value).strip();
    }

    private static String toJson(Object value) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать результат: " + e.getMessage());
        }
    }
}
