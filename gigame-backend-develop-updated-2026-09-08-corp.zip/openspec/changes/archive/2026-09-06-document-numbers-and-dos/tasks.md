# Tasks: Склейка разрядов чисел и защита от ZIP-бомб/DoS

## Склейка чисел
- [x] `normalizeNumberGroups` применяется в `parseText` после извлечения текста
- [x] `GROUPED_NUMBER` — корректно сгруппированные по 3 (пробел/неразрывные)
- [x] `TORN_NUMBER` — рваные куски 1–3, обязательная дробь, possessive-квантор `++`
- [x] `WRAPPED_NUMBER` / `WRAPPED_AFTER_COMMA` — разрыв переносом строки (голова 4+, хвост 1–2 с дробью)
- [x] `glueMatches` — замена совпадений с удалением разделителей (`Matcher.quoteReplacement`)

## Лимиты структуры
- [x] `app.document.max-file-size` → `maxFileSizeBytes`; проверка в `uploadDocument` до парсинга
- [x] `max-sheets` / `max-total-rows` → `parseWorkbook`
- [x] `max-xml-nodes` → `childElements`/`collectXmlText`
- [x] `FEATURE_SECURE_PROCESSING` + пустые `ACCESS_EXTERNAL_DTD`/`ACCESS_EXTERNAL_SCHEMA`

## Сопутствующее
- [x] Обработка ошибок чтения файла отделена от ошибок парсинга
- [x] userId в `DocumentService` из `CurrentUserHolder` вместо `UserUtils.getUserId`

## Тесты
- [x] `DocumentServiceNumbersTest` (4 паттерна + негатив `2025 100 000,00` + null/пусто)
- [x] `DocumentServiceTest` обновлён под новые лимиты/передачу userId