# Design: Склейка разрядов чисел и защита от ZIP-бомб/DoS

## Паттерны склейки (последовательно в normalizeNumberGroups)

```
GROUPED_NUMBER   (?<![\d,.]) \d{1,3} (?:[ \u00A0\u202F\u2009]\d{3})+ (?:[.,]\d{1,2})? (?!\d)
                 → "9 750 986,34" -> 9750986,34   (не матч: "2025 100 000,00")

TORN_NUMBER      (?<![\d,.]) \d{1,3} (?:[ \u00A0\u202F\u2009]\d{1,3})++ [.,]\d{1,2} (?!\d)
                 possessive ++ (анти-S5998); обязательная дробь
                 → "975 09 86,34" -> 9750986,34

WRAPPED_NUMBER   (?<![\d,.]) \d{4,} [\r\n]+ \d{1,2}[.,]\d{1,2} (?!\d)
                 → "394134\n3,56" -> 3941343,56

WRAPPED_AFTER_COMMA  (?<![\d,.]) \d{4,},[\r\n]+\d{1,2} (?![,.])
                 → "384553,\n94" -> 384553,94
```

`glueMatches(pattern, text, separators)`:
```
Matcher m = pattern.matcher(text);
while (m.find()) m.appendReplacement(sb, quoteReplacement(separators.matcher(m.group()).replaceAll("")));
m.appendTail(sb);
```

## Лимиты структуры

```
parseText ──► normalizeNumberGroups
uploadDocument: maxFileSizeBytes (50МБ) до parseText

parseWorkbook:
  sheetsToParse = min(numberOfSheets, maxSheets)        // листы
  totalRows > maxTotalRows (100000) -> FileException     // строки по всем листам

XML parse / childElements / collectXmlText:
  min(children.getLength(), maxXmlNodes) + счётчик узлов // maxXmlNodes (10000)
  FEATURE_SECURE_PROCESSING=true, ACCESS_EXTERNAL_DTD="", ACCESS_EXTERNAL_SCHEMA=""
```

## Конфиг (application.yaml)

```
app.document:
  max-file-size:   ${DOCUMENT_MAX_FILE_SIZE:52428800}     # 50МБ
  max-sheets:      ${DOCUMENT_MAX_SHEETS:100}
  max-total-rows:  ${DOCUMENT_MAX_TOTAL_ROWS:100000}
  max-xml-nodes:   ${DOCUMENT_MAX_XML_NODES:10000}
```

## Инварианты (rules.design / 03-architecture.md)

- Склейка чисел не должна слипать самостоятельные целые числа (для `TORN`/`WRAPPED` обязательна дробная часть).
- Парсинг — узкое место; лимиты — барьер перед распаковкой/обходом, `FileException` на превышение.
- Ужесточение XML сохраняет легитимные документы (только внешние DTD/схемы запрещены).