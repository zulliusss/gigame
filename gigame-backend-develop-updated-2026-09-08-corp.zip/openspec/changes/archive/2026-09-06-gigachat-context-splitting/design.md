# Design: Деление длинного контекста при 422

## Схема рекурсивного деления

```
chatCompletionResult(messages, model, temp)
  └─► chatCompletionSplitting(messages, model, temp, depth=0)
         try chatCompletionOnce(...)
         catch RuntimeException e:
           if depth >= 3  || !isContextTooLong(e)   → throw e
           idx = аргумент с max content.length
           if idx < 0 || max < 20_000               → throw e
           cut = lastIndexOf('\n', len/2); if cut < max/4 → cut = len/2
           r1 = callWithReplacedContent(messages, idx, content[0..cut],   ..., depth)
           r2 = callWithReplacedContent(messages, idx, content[cut..],    ..., depth)
           return ChatResult(r1.text + "\n\n" + r2.text, mergeUsage(r1.usage, r2.usage))
```

```
callWithReplacedContent(messages, idx, part, ..., depth)
  copy[i] = i==idx ? {role, content:part} : messages[i]
  return chatCompletionSplitting(copy, ..., depth+1)
```

## Дерево деления (глубина)

```
depth0 1 часть
 ├─ depth1 2 части
 │   ├─ depth2 4 части
 │   │   ├─ depth3 8 частей (стоп на depth>=3)
```

## Распознавание 422

```
isContextTooLong(e): по всей цепочке getCause()
  msg = e.getMessage().toLowerCase()
  true if msg.contains("context too long")
       or (msg.contains("422") and msg.contains("invalid params"))
```

## usage

- каждый `chatCompletionOnce` = отдельный `addCapturedUsage` (внешний кадр)
- результат несёт `mergeUsage(r1, r2)`: поэлементное суммирование числовых полей (long) по ключам `a`→`b`; пустая/`null` сторона отдаёт парную.