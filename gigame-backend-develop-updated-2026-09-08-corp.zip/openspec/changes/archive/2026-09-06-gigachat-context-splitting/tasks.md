# Tasks: Деление длинного контекста при 422

## Основной механизм
- [x] Рефакторинг тела `chatCompletionResult` → `chatCompletionOnce` (одиночный вызов)
- [x] `chatCompletionSplitting` — рекурсивная обёртка с делением пополам
- [x] Выбор самого длинного сообщения; стоп: `depth>=3`, `<20_000` символов, не-422
- [x] `callWithReplacedContent` — копия списка, замена content у idx
- [x] Склейка ответов `r1 + "\n\n" + r2`; `mergeUsage` суммирование usage

## Распознавание 422
- [x] `isContextTooLong` по `getCause()`-цепочке (`context too long` или `422`+`invalid params`)

## Сопутствующее
- [x] `getEmbeddings(null)` → `List.of()` (без NPE)
- [x] Снятие `r.responseData() != null` перед сравнением с `COMPACT_MIN_CHARS` в compaction

## Тесты
- [x] `GigaChatClientSplitTest` (глубина, склейка, usage, распознавание 422 обёрнутой ошибки)