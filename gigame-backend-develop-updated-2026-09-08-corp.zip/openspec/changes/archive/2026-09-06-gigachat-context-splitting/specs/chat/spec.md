---
capability: chat
---

# Дельта: деление длинного контекста при 422 «context too long»

## Purpose

Зафиксировать устойчивость `GigaChatClient.chatCompletionResult` к переполнению контекстного окна модели: рекурсивное деление самого длинного сообщения и склейка ответов с суммированием usage.

## ADDED Requirements

### Requirement: Деление контекста на части при 422

Система SHALL при ошибке 422 «context too long» делить самое длинное сообщение пополам и объединять ответы частей.

#### Scenario: Рекурсивное деление длинного сообщения

- **WHEN** `chatCompletionResult(messages, model, temperature)` бросил исключение, распознанное как `context too long` (`isContextTooLong` по цепочке `getCause()`: содержит `"context too long"` или `("422" и "invalid params")`)
- **AND** глубина `depth < 3` и самое длинное сообщение ≥ `20_000` символов
- **THEN** выбирается сообщение с максимальным `content.length()`
- **AND** точка разреза — последний `\n` в первой половине (иначе ровно `length()/2`, если перенос ближе `max/4`)
- **AND** две половины обрабатываются отдельными вызовами (`callWithReplacedContent`, роль сохраняется, остальные сообщения — без изменений)
- **AND** ответы склеиваются: `r1.text() + "\n\n" + r2.text()`

#### Scenario: Глубина деления ограничена

- **WHEN** `depth >= 3` (максимум 3 уровня, до 8 частей) или сообщение короче `20_000` символов или ошибка не про 422
- **THEN** деление не выполняется, ошибка возвращается как есть (`throw e`)

#### Scenario: Суммирование usage частей

- **WHEN** части успешно завершились
- **THEN** `mergeUsage(r1.usage(), r2.usage())` суммирует числовые поля по ключам (long), пустые/`null` usage подменяются парным
- **AND** каждый `chatCompletionOnce` внутри также добавляет свои токены во внешний `ThreadLocal`-кадр (`addCapturedUsage`)

### Requirement: Устойчивость getEmbeddings к null

Система SHALL не падать при `getEmbeddings(null)`.

#### Scenario: Пустой ввод

- **WHEN** `GigaChatClient.getEmbeddings(null)`
- **THEN** возвращается пустой список `List.of()` без NPE