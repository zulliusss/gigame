# Design: Поток-локальный контекст пользователя

## Поток userId без явной проброски

```
REST (X-UserId)  ──┐
                   ▼
Controller  Mono.fromCallable(() ->
              CurrentUserHolder.withUser(userId, () -> service.method(...)))
                   │  withUser: set(userId) → action → finally clear()
                   ▼
Service.method()   userId = CurrentUserHolder.getCurrentUser()
                   ... вызывает другие сервисы (та же цепочка, ThreadLocal виден)
                   ▼
Внутренний вызов    getCurrentUser() / entity.setUserId(getCurrentUser())
```

```
WebSocket handshake (X-UserId)
      │  WebSocketSessionManager.extractUserIdFromWebSocketSession()
      ▼
handle()  try { doHandle(session) } finally { CurrentUserHolder.clear(); }
      sessionId ── map ──► userId
      setCurrentUser(userId) в processMessage + withUser вокруг сервисных вызовов
```

```
Воркер-поток (пул)               вызывающий поток
      ├── executor.submit(() -> CurrentUserHolder.withUser(userId, () -> runTask(...)))
      ▼
      userId захвачен до submit, контекст достигает потока пула
```

## Реактивный стек

- Все блокирующие вызовы обёрнуты в `Mono.fromCallable(...).subscribeOn(Schedulers.boundedElastic())`; `CurrentUserHolder` заполняется **внутри** callable, а не в WebFilter, чтобы исключить влияние смены потоков реактивного конвейера.
- `AbstractScenarioExecutor.currentUser()`: `runnerUserId` из `ScenarioRunGraph` — первоисточник; ThreadLocal — запасной и пишется обратно при отсутствии.

## Инварианты (rules.design / 03-architecture.md)

- Не нарушать мультитенантность: `user_id` на root-сущностях заполняется из контекста.
- `withUser` — единая точка входа/выхода контекста, очистка гарантирована через `finally`.
- Асинхронные границы (`@Async`, пулы, `Schedulers`) переносят контекст явно там, где это необходимо.