---
capability: api
---

# Дельта: поток-локальный контекст пользователя (CurrentUserHolder)

## Purpose

Зафиксировать переход на ThreadLocal-контекст `CurrentUserHolder` для передачи текущего пользователя вместо явной проброски `userId` параметром через сервисные методы, и связанную нормализацию логирования.

> **Примечание**: внешние контракты REST (`X-UserId`-заголовок) и WS-handshake не меняются. Устаревшее упоминание `UserUtils.getUserId()` в этой capability расходится с кодом — метод удалён; fallback на `"anonymous"` перенесён в `CurrentUserHolder`.

## ADDED Requirements

### Requirement: Поток-локальный контекст текущего пользователя

Система SHALL предоставлять поток-локальный контекст `CurrentUserHolder`, заполняемый на границе синхронных сервисных методов, гарантированно очищаемый после завершения.

#### Scenario: withUser устанавливает и очищает контекст

- **WHEN** контроллер вызывает `CurrentUserHolder.withUser(userId, () -> service.method(...))`
- **AND** `service.method` читает `CurrentUserHolder.getCurrentUser()` во внутренней цепочке вызовов (на том же потоке)
- **THEN** `getCurrentUser()` возвращает `userId` внутри `withUser`
- **AND** после завершения (включая исключение) хранилище очищается через `finally { clear(); }`
- **AND** пустой/null `userId` нормализуется в `"anonymous"`

### Requirement: Удаление userId из сигнатур сервисов

Система SHALL перевести внутренние сервисные методы на чтение пользователя из контекста вместо параметра `String userId`.

#### Scenario: Сервисный метод без параметра userId

- **WHEN** вызывается `chatService.getConversations(search)` (ранее `getConversations(userId, search)`), `documentService.uploadDocument(file)`, `kbService.getKnowledgeBase(id)`, `promptService.getPrompts()`, `scenarioService.getScenario(id)`, `memoryService.addLesson(scenarioId, lesson, "user")`
- **THEN** пользователь берётся из `CurrentUserHolder.getCurrentUser()`
- **AND** внутренние вызовы должны исполняться внутри `CurrentUserHolder.withUser(...)` (или после `setCurrentUser`), иначе сервис прочитает `null`/чужие значения

#### Scenario: WebSocket извлекает userId из handshake

- **WHEN** открывается WS-соединение `/ws/chat` или `/ws/scenario`
- **THEN** `WebSocketSessionManager.addSession` извлекает userId из handshake (`X-UserId`, null → `"anonymous"`) в карту `sessionIdToUserId`
- **AND** очищает запись в `removeSession`
- **AND** хэндлеры оборачивают `handle()` в `try { ... } finally { CurrentUserHolder.clear(); }`

### Requirement: Единообразное логирование userId

Система SHALL логировать операции с префиксом `[userId]` через `CurrentUserHolder.getCurrentUser()` и уровнем `info` (вместо разрозненных `debug` по userId).

#### Scenario: Лог-запись сервисов

- **WHEN** выполняется метод сервиса/контроллера, ранее логировавший `log.debug("... userId=...")`
- **THEN** теперь выполняется `log.info("[{}] <описание>", CurrentUserHolder.getCurrentUser(), ...)`
- **AND** фоновые задачи (ScenarioEngine, ScenarioUploadTaskService) переносят контекст на воркер-поток и логируют `[userId]`

### Requirement: UserUtils не содержит getUserId

Система SHALL НЕ предоставлять `UserUtils.getUserId(...)` и `UserUtils.extractUserIdFromWebSocketSession(...)` — логика вынесена в `CurrentUserHolder`/`WebSocketSessionManager`.

#### Scenario: Удалённые методы недоступны

- **WHEN** код ссылается на `UserUtils.getUserId(...)` или `UserUtils.extractUserIdFromWebSocketSession(...)`
- **THEN** метод отсутствует (compile error у вызовов)
- **AND** `UserUtils.checkUserId(...)` сам нормализует null/пустое в `"anonymous"` перед сравнением

### Requirement: Защита от null и утечки контекста

Система SHALL устранять null-возвраты и защищать границы асинхронности, чтобы токен/идентичность пользователя корректно достигали потребителей.

#### Scenario: Отказ от null в agent-парсерах

- **WHEN** `AgentEvidence.parse/parsePlan/parseSearchPlan` не распознают вход
- **THEN** возвращают пустой список `List.of()` (а не `null`)
- **AND** потребители (ProcessingNode, AgentMemoryService) сравнивают `isEmpty()` вместо `== null`

#### Scenario: Null-безопасность ScenarioEngine

- **WHEN** `validateGraph` получает `graphData == null`
- **THEN** выбрасывается `ScenarioException("Ошибка валидации графа: отсутствуют данные графа")`
- **AND** `topologicalSort`/`getNodeIds`/`getDisconnectedNodes` при null возвращают пустые коллекции

#### Scenario: Вложенные транзакции AgentMemoryService через self-прокси

- **WHEN** `answerQuestion` вызывает `addLesson` для порождения урока
- **THEN** вызов идёт через self-прокси (`self.get().addLesson(...)`), чтобы внешний транзакционный прокси применился корректно