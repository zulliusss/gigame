---
capability: scenario-engine
---

# Дельта: контекст пользователя и null-безопасность движка

## Purpose

Зафиксировать внедрение `CurrentUserHolder` вокруг исполнения прогона в `ScenarioEngine`, защитные null-проверки графа и корректную передачу `runnerUserId` в воркер-потоки.

## ADDED Requirements

### Requirement: Контекст пользователя вокруг прогона

Система SHALL устанавливать текущего пользователя в `CurrentUserHolder` на время исполнения прогона, чтобы узлы и логи видели идентичность запустившего.

#### Scenario: Запуск прогона

- **WHEN** `ScenarioEngine.executeScenario` выполняется
- **THEN** тело `doExecute` и колбэк `sink.onCancel` (для `cleanupRun`) оборачиваются в `CurrentUserHolder.withUser(userId, () -> ...)`
- **AND** `executeGraph` делает `CurrentUserHolder.setCurrentUser(userId)` в начале
- **AND** узел в параллельной волне запускается через `withUser(userId, () -> runNodeBody(...))` — `userId` захватывается до `submit`

#### Scenario: Воркер-поток видит runnerUserId

- **WHEN** исполнитель узла логирует пользователя через `AbstractScenarioExecutor.currentUser()`
- **THEN** первичный источник — `node.getGraph().getRunnerUserId()`, ThreadLocal — запасной (если не дошёл до потока)
- **AND** `currentUser()` пишет значение обратно в `CurrentUserHolder`, если его не было

### Requirement: Обработка отсутствующего графа

Система SHALL обрабатывать отсутствующие данные графа без NPE.

#### Scenario: Валидация пустого графа

- **WHEN** `validateGraph` получает `graphData == null`
- **THEN** выбрасывается `ScenarioException("Ошибка валидации графа: отсутствуют данные графа")`
- **WHEN** `topologicalSort`/`getNodeIds`/`getDisconnectedNodes` получают `graphData == null`
- **THEN** возвращаются пустые коллекции (`List.of()`/`Set.of()`) без исключения