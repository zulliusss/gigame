# Tasks: Поток-локальный контекст пользователя

## Контекст пользователя
- [x] Добавить `CurrentUserHolder` (`setCurrentUser`/`getCurrentUser`/`clear`/`withUser`), нормализация `"anonymous"`
- [x] Обернуть контроллеры в `CurrentUserHolder.withUser(userId, ...)`: Conversation, Document, KnowledgeBase, Prompt, Scenario, AgentMemory
- [x] Убрать `userId` из сервисных сигнатур: ChatService, DocumentService, KBService, PromptService, AgentMemoryService, ScenarioService
- [x] Перенести извлечение userId из WS-handshake в `WebSocketSessionManager` (`sessionIdToUserId`, `extractUserIdFromWebSocketSession`)
- [x] `try{}finally{clear()}` в `handle()` WS-хэндлеров (Chat, Scenario)

## Логирование
- [x] Перевести `log.debug` по userId → `log.info` с префиксом `[userId]` во всех контроллерах/сервисах/исполнителях

## Асинхронность / null
- [x] Перенос контекста на воркер-потоки в ScenarioEngine, ScenarioUploadTaskService
- [x] `AbstractScenarioExecutor.currentUser()` (runnerUserId как первоисточник)
- [x] `AgentEvidence`/`AgentDocumentTools`: null → `List.of()`/`Map.of()`
- [x] Null-проверки графа в ScenarioEngine
- [x] Self-прокси AgentMemoryService для вложенных `@Transactional`

## Тесты
- [x] Обновлены тесты контроллеров/сервисов/WS под новый способ передачи userId
- [x] `AgentEvidenceTest`, `WebSocketSessionManagerTest`, `UserUtilsTest` (удалён неактуальный)