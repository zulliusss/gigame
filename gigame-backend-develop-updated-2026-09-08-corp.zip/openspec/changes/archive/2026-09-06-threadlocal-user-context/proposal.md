# Proposal: Поток-локальный контекст пользователя (CurrentUserHolder) вместо явной проброски userId

## Проблема

Во всём бэкенде `userId` прокидывался явным параметром через всю цепочку: контроллер → сервис → внутренние вызовы. Это раздувало сигнатуры десятков методов, а логирование сессий дублировало userId в каждом `log.debug`. В WebSocket-хэндлерах не было единообразного способа достать пользователя из handshake, а `@Async`-методы и воркер-потоки пулов теряли значение `userId`.

## Цель

- Ввести единый поток-локальный контекст `CurrentUserHolder` (ThreadLocal), заполняемый на границе синхронных сервисных методов, с гарантированной очисткой после завершения.
- Убрать `userId` из публичных сигнатур сервисных методов: внутренние вызовы читают `CurrentUserHolder.getCurrentUser()`.
- Единообразно перевести логирование userId (`log.debug` → `log.info` с префиксом `[userId]`).
- Переместить извлечение userId из WebSocket-handshake в `WebSocketSessionManager` (новая статическая `extractUserIdFromWebSocketSession` + карта `sessionIdToUserId`).
- Устранить null/U+риски утечки контекста в асинхронных и фоновых потоках.

## Область

| В области | Вне области |
|---|---|
| Новый класс `CurrentUserHolder` (`setCurrentUser`/`getCurrentUser`/`clear`/`withUser`) | Изменение внешних REST/WS-контрактов (`X-UserId`-заголовок, WS-handshake сохранены) |
| Удаление `userId` из сервисных методов Chat, Document, KB, Prompt, AgentMemory, Scenario | Изменение структуры ответов DTO |
| `UserUtils`: удаление `getUserId`/`extractUserIdFromWebSocketSession`, нормализация `checkUserId` | Миграции БД |
| WebSocket: userId из handshake в `WebSocketSessionManager` | Смена модели/параметров GigaChat |
| `ScenarioEngine`: null-проверки графа, self-прокси `AgentMemoryService`, отказ от `null` в `AgentEvidence`/`AgentDocumentTools` | Новые endpoint-ы |
| Массовое `log.info` с `[userId]` во всех сервисах/контроллерах/исполнителях | Реализация feature-поведения (transform-операции, XLSX, 422-деление) |

## Заметки по дизайну

- Контекст заполняется на границе **синхронных** сервисных методов внутри `Mono.fromCallable(...).subscribeOn(Schedulers.boundedElastic())`, а не в WebFilter, чтобы исключить влияние реактивного стека (синхронная цепочка на одном потоке видит ThreadLocal).
- Паттерн контроллера: `Mono.fromCallable(() -> CurrentUserHolder.withUser(userId, () -> service.method(...)))`; для `void` — `Mono.fromRunnable(() -> CurrentUserHolder.withUser(userId, () -> { ...; return null; }))`.
- Воркер-потоки (ScenarioEngine, ScenarioUploadTaskService) захватывают `userId = getCurrentUser()` до `submit` и оборачивают тело в `withUser`.
- `AbstractScenarioExecutor.currentUser()`: первичный источник — `runnerUserId` из `ScenarioRunGraph`, ThreadLocal — запасной (исполнители бегают в пулах потоков).
- `AgentMemoryService` — self-прокси для корректных вложенных `@Transactional` при «ответ → создание урока».

## Риски

1. **Потеря контекста в `@Async` (`indexDocumentAsync`).** `getCurrentUser()` может вернуть `null` внутри async-потока (нет `TaskDecorator`). Не падение (userId только в логе), но контекст не долетает — при полной фиксации нужен `TaskDecorator` или перенос userId до `@Async`.
2. **`setCurrentUser` без локальной пары `clear` в WS.** Очистка опирается на внешний `finally { clear(); }` в `handle()` — при исключении до `return doHandle(...)` возможна утечка «чужого» userId в пуле.
3. **`getCurrentUser()` возвращает `null` вне контекста.** `KBService` использует `getCurrentUser().equals(...)` — NPE при вызове вне `withUser`; штатно все пути оборачиваются (`anonymous`). `AgentMemoryController.getLessons` логирует `null` (нет `X-UserId`).