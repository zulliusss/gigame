# Tasks: Обогащение формы, сверка чисел и блоки в XLSX-экспорте

## Обогащение формы
- [x] `enrichAgainstForm(dataList, rulesJson, enrichmentLines)` — оверлей данных поверх строк исходной формы
- [x] Сопоставление по ключу (`ключ_данных` ↔ первый гроуп `ключ_регекс`), очередь FIFO для нескольких актов
- [x] Заглушки для несопоставленных строк формы; данные без пары — `sourceColumn="нет в исходной форме"`
- [x] `expandSourceColumn` для `развернуть_исходную`: динамические колонки `к0_01…`, шапка строкой данных

## Сверка чисел
- [x] `ScenarioService.referenceNumbers` — эталоны из узла `из_узла` по `REFERENCE_NUMBER`
- [x] `fixNumbersAgainstReference` / `fixRowValue` — восстановление по удалению 1–3 разрядов; каноническое сравнение
- [x] Неоднозначность (≥2 кандидатов) — значение не трогается

## Блоки
- [x] `BlockConfig.parse`, `BlockContext`, `writeBlockRows`, `mergeRowAcross`
- [x] `createTemplatedXlsx` с опциональными верхним/нижним блоками; относительная адресация строк (`startRow`)
- [x] `createTemplateHeader`/`createGroupRow`/`mergeAdjacentGroups` на `startRow`

## Обрезка длинных значений
- [x] `ScenarioService.clip` (name 64, description 255) при create/update
- [x] `ScenarioMapper.clipString` (поля отчёта 200k) + пометка об усечении

## Тесты
- [x] `ScenarioResultToXlsxEnrichTest` (обогащение, разворачивание, сверка чисел)
- [x] `ScenarioResultToXlsxBlocksTest` (блоки верх/низ, отсутствие конфига)
- [x] `ScenarioMapperClipTest` (клип длинных и коротких полей)