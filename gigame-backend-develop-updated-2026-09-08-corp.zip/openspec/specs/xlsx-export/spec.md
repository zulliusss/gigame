# XLSX Export Enhancement

## Purpose

Extends XLSX export (`ScenarioResultToXlsx`) with dynamic column expansion, section highlighting, and cell value-based highlighting for output node templates.

## Requirements

### Requirement: Dynamic Columns via key_prefix

A column definition with `key_prefix` (instead of `key`) SHALL expand into separate columns for each unique data key starting with that prefix at execution time.

#### Scenario: Dynamic column expansion

- **WHEN** rules contain `{"key_prefix": "technology_", "header_prefix": "Technology: "}`
- **AND** data contains keys: `technology_a`, `technology_b`, `technology_c`
- **THEN** three columns are created with headers: "Technology: a", "Technology: b", "Technology: c"
- **THEN** columns appear in order of first key discovery in data

#### Scenario: Static and dynamic columns coexist

- **WHEN** rules contain both `"key": "criterion"` and `"key_prefix": "tech_"`
- **THEN** the static column appears first, followed by expanded dynamic columns

#### Scenario: Dynamic column with no matches

- **WHEN** a prefix column has no matching keys in data
- **THEN** no columns are expanded for that prefix

### Requirement: Section Highlighting

When rules contain `{"highlight_sections": true}`, rows where only the first column has a value (others empty) SHALL receive the header font style (bold).

#### Scenario: Section row highlighted

- **WHEN** `"highlight_sections": true` is set
- **AND** a row has a value only in the first column, empty in others
- **THEN** the row uses the header cell style (bold font)
- **THEN** normal data rows use normal style (non-bold)

#### Scenario: Section highlighting disabled

- **WHEN** `"highlight_sections"` is not set or `false`
- **THEN** all data rows use normal data style

#### Scenario: Section row not recognized

- **WHEN** a row has values in multiple columns (not a section pattern)
- **THEN** it uses normal data style even when section highlighting is enabled

### Requirement: Cell Value-Based Highlighting

A column definition MAY contain a `"highlight": {"value": "color"}` mapping. When a cell value matches the key, it SHALL receive colored fill.

#### Scenario: Green for "Matches"

- **WHEN** rules contain `"highlight": {"Matches": "green"}`
- **AND** cell value is `"Matches"` (case-insensitive comparison)
- **THEN** cell receives LIGHT_GREEN fill (`IndexedColors.LIGHT_GREEN`)

#### Scenario: Red for "Not matches"

- **WHEN** rules contain `"highlight": {"Not matches": "red"}`
- **AND** cell value is `"Not matches"` (case-insensitive comparison)
- **THEN** cell receives ROSE fill (`IndexedColors.ROSE`)

#### Scenario: Unrecognized color name

- **WHEN** color name is unrecognized ("green", "red", "yellow", etc.)
- **THEN** fill is not applied (falls back to default data style)

#### Scenario: Bilingual highlight colors

- **WHEN** value key matches a Russian or English color name
- **THEN** both are supported: "green"/"зелёный" → LIGHT_GREEN, "red"/"красный" → ROSE, "yellow"/"желтый" → LIGHT_YELLOW

#### Scenario: Highlight styles are cached

- **WHEN** multiple cells require the same highlight
- **THEN** a single `CellStyle` is created and reused (Excel style limit safety)

### Requirement: Empty Array with Template

When data is an empty JSON array `[]` but a template is specified, export SHALL create an XLSX with only the header row.

#### Scenario: Empty data produces header-only workbook

- **WHEN** data is `[]` and rules specify columns
- **THEN** a workbook with one header row is created
- **THEN** no data rows are created
- **THEN** no exception is thrown

### Requirement: extractJson Visibility

The `extractJson()` method SHALL be package-private (accessible in `scenario` package) to support accumulation logic in `ScenarioOutputSupportService`.

#### Scenario: extractJson used by accumulation

- **WHEN** `ScenarioOutputSupportService.parseRows()` needs to extract JSON from a node result
- **THEN** it can call `ScenarioResultToXlsx.extractJson()` (same package)

### Requirement: Обогащение формы (обогащение_формы)

Когда в rules выходного узла есть `обогащение_формы`, экспорт SHALL строить выход поверх исходной формы участника: каждая строка формы сохраняется, сопоставленные с данными анализа строки получают данные, несопоставленные — заглушки.

#### Scenario: Оверлей строк формы данными анализа

- **WHEN** `обогащение_формы` содержит `из_узла`, `ключ_регекс`, `ключ_данных`, `колонка_исходной`, `заглушки`
- **AND** строка данных совпадает со строкой формы по ключу (`ключ_данных` ↔ первый гроуп `ключ_регекс`)
- **THEN** выходная строка = копия данных плюс `sourceColumn` (исходная строка формы), `matched++`
- **AND** строка формы без совпадения → заглушки из `заглушки`, `stubbed++`
- **AND** порядок выходных строк соответствует порядку строк исходной формы
- **AND** данные без пары в форме дописываются в конец с `sourceColumn="нет в исходной форме"`

#### Scenario: Несколько актов на один ключ

- **WHEN** несколько строк данных имеют одинаковый ключ спецификации
- **THEN** они копятся в очередь FIFO и сопоставляются строкам формы в порядке поступления

#### Scenario: Пусто/отсутствие конфига

- **WHEN** `обогащение_формы` отсутствует или `enrichmentLines` пуст
- **THEN** экспорт возвращает `dataList` без изменений

### Requirement: Разворачивание исходной строки (развернуть_исходную)

Когда `обогащение_формы.развернуть_исходную=true`, склеенная исходная строка формы (`поле | поле | …`) SHALL разворачиваться в отдельные динамические колонки `к0_01…`, а первая строка формы без ключа (шапка) добавляется строкой данных как подписи колонок.

#### Scenario: Разворачивание строк формы

- **WHEN** `развернуть_исходную=true` и `разделитель` (default `"|"`)
- **THEN** первая непустая строка формы без ключа (шапка) добавляется первой строкой данных (в `sourceColumn` кладётся сама строка) и впоследствии тоже разворачивается по полям
- **AND** у каждой строки выхода исходная колонка `sourceColumn` удаляется, а её значение режется по `разделитель` (`split(Pattern.quote(sep), -1)` — пустые хвосты сохраняются)
- **AND** каждое поле попадает в колонку `sourceColumn + "_" + String.format("%02d", i+1)` (например `к0_01`, `к0_02`)
- **AND** после обработки исходная колонка `к0` отсутствует (заменена набором `к0_01…`)

### Requirement: Сверка чисел (сверка_чисел)

Когда в rules есть `сверка_чисел`, экспорт SHALL восстанавливать значения колонок, потерявших от 1 до 3 разрядов, по единственному кодовому эталону из узла-донора.

#### Scenario: Сбор эталонов из узла-донора

- **WHEN** `сверка_чисел` содержит `из_узла` и `колонки`
- **THEN** `ScenarioService.referenceNumbers` находит узел графа по метке `из_узла`, читает результат его шага
- **AND** regex `REFERENCE_NUMBER` собирает эталоны (≥2 цифры с дробью `,/.` или целое 4+), нормализуя `,`→`.`

#### Scenario: Восстановление единственного кандидата

- **WHEN** значение колонки из `колонки` не совпадает с эталоном (точно и канонически), но получается из эталона удалением 1–3 разрядов
- **THEN** значение заменяется на эталон (порядок цифр сохраняется, `isSubsequence`)
- **AND** при точном/каноническом совпадении (`1945390.20`↔`1945390.2`) значение не трогается
- **AND** при неоднозначности (≥2 подходящих эталона) значение остаётся нетронутым

### Requirement: XLSX-блоки (блоки)

Когда в rules есть `блоки`, экспорт SHALL выносить служебные строки (паспорт закупки, выводы) из таблицы в отдельные блоки над/под ней.

#### Scenario: Верхний и нижний блок

- **WHEN** `блоки` содержит `ключ`, `верх`, `низ`, `текст`, `заголовок_верх`, `заголовок_низ`
- **THEN** строки, где `row[ключ] ∈ верх`, пишутся блоком над таблицей (заголовок блока + строки из `текст`, merged на ширину)
- **AND** строки, где `row[ключ] ∈ низ`, пишутся под таблицей
- **AND** остальные строки (`tableRows`) остаются в таблице; при отсутствии конфига `блоки` — прежняя плоская раскладка (шапка в row0, все строки в таблице)

#### Scenario: Относительная адресация строк

- **WHEN** верхний блок присутствует
- **THEN** шапка таблицы начинается после верхнего блока (`startRow = блок + 1`), нижний блок — после `headerRows + tableRows.size() + 1`

### Requirement: Обрезка name/description сценария

Система SHALL мягко обрезать `name` (лимит 64) и `description` (лимит 255) сценария по схеме OpenAPI.

#### Scenario: Мягкая обрезка длинного поля

- **WHEN** длина `name`/`description` превышает лимит
- **THEN** значение обрезается до `max-1` символов + символ `…` (итог ≤ лимита)
- **AND** применяется при создании и при непустом обновлении сценария
