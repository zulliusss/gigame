---
capability: executors
---

# Executors Specification

## Purpose

Define 12 scenario node executors (not 16 as previously stated). All implement `AbstractScenarioExecutor` and are created via `ScenarioExecutorFactory` by `ScenarioNodeType`.

## NodeType Enum (12 значений)

| Enum Value | Класс | Значение в графе |
|------------|-------|-----------------|
| `INPUT_NODE` | `ScenarioExecutorInputNode` | `"input"` |
| `OUTPUT_NODE` | `ScenarioExecutorOutputNode` | `"output"` |
| `PROCESSING_NODE` | `ScenarioExecutorProcessingNode` | `"processing"` |
| `LOOP_NODE` | `ScenarioExecutorLoopNode` | `"loop"` |
| `SWITCH_NODE` | `ScenarioExecutorSwitchNode` | `"switch"` |
| `IF_NODE` | `ScenarioExecutorIfNode` | `"if_node"` |
| `CALC_NODE` | `ScenarioExecutorCalcNode` | `"calc"` |
| `AGGREGATE_NODE` | `ScenarioExecutorAggregateNode` | `"aggregate"` |
| `TRANSFORM_NODE` | `ScenarioExecutorTransformNode` | `"transform"` |
| `SUBSCENARIO_NODE` | `ScenarioExecutorSubscenarioNode` | `"subscenario"` |
| `CONTROL_NODE` | `ScenarioExecutorControlNode` | `"control"` |
| `WAIT_NODE` | `ScenarioExecutorWaitNode` | `"wait"` |

## Requirements

### Requirement: 12 executor-типов по NodeType Enum
Система SHALL содержать ровно 12 типов узлов сценариев, определяемых `ScenarioNodeType` enum, и 12 соответствующих классов-исполнителей через `ScenarioExecutorFactory`.

#### Scenario: Перечень executor-типов
- **WHEN** рассматривается `ScenarioNodeType` enum
- **THEN** присутствуют значения: `PROCESSING_NODE`, `IF_NODE`, `SWITCH_NODE`, `LOOP_NODE`, `INPUT_NODE`, `OUTPUT_NODE`, `CALC_NODE`, `AGGREGATE_NODE`, `TRANSFORM_NODE`, `SUBSCENARIO_NODE`, `CONTROL_NODE`, `WAIT_NODE`
- **THEN** каждое значение маппится на отдельный класс `ScenarioExecutorXxxNode extends AbstractScenarioExecutor`

### Requirement: InputNode — проброс документов
`ScenarioExecutorInputNode` SHALL передавать текст документов как есть на следующий узел без вызова LLM.

#### Scenario: Выполнение InputNode
- **WHEN** `INPUT_NODE` выполняется
- **THEN** возвращает `documentsText` — конкатенацию текстов всех входных `ScenarioRunDoc`
- **THEN** узел помечается `COMPLETED`

### Requirement: OutputNode — объединение предшественников
`ScenarioExecutorOutputNode` SHALL объединять выходы всех предшественников и поддерживать типы `TEXT_FILE`/`EXCEL`.

#### Scenario: Объединение текстового вывода
- **WHEN** `OUTPUT_NODE` выполняется с `OUTPUT_TYPE=TEXT_FILE`
- **THEN** конкатенирует все поля `previousOutput` от предшественников

#### Scenario: Экспорт в Excel
- **WHEN** `OUTPUT_NODE` имеет тип `EXCEL`
- **THEN** вызывается `ScenarioResultToXlsx.jsonToXlsx(jsonData, rules)`
- **THEN** эмитируется `type="file_output"` с `mime_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"`

### Requirement: ProcessingNode — вызов LLM с RAG
`ScenarioExecutorProcessingNode` SHALL вызывать GigaChat с промптом, RAG-контекстом (через `buildPrompt`), разрешением выражений (`{{output:label}}`) и групповым режимом.

#### Scenario: RAG-контекст в промпте
- **WHEN** `PROCESSING_NODE` выполняется с `buildPrompt(input, documents, kbChunks, rag)`
- **THEN** RAG-контекст, тексты документов и чанки БЗ добавляются в промпт
- **THEN** `{{output:prev_node_label}}` разрешается через `ExpressionResolver`

#### Scenario: Групповой режим sequential
- **WHEN** `group_mode="sequential"` установлен
- **THEN** каждый документ обрабатывается последовательно
- **THEN** `group-parallelism` = 1 (один LLM-вызов за раз)

### Requirement: LoopNode — classify strict / full analysis
`ScenarioExecutorLoopNode` SHALL обрабатывать каждый документ через GigaChat в режиме `classify_strict` или `full analysis`.

#### Scenario: Строгая классификация
- **WHEN** `loop_mode="classify_strict"` и `classes=["positive", "negative", "neutral"]`
- **THEN** каждый документ классифицируется GigaChat однословным ответом
- **THEN** `mode="classify_strict"` → ответ — одно из `["positive", "negative", "neutral"]`

#### Scenario: Полный анализ
- **WHEN** `loop_mode="full analysis"`
- **THEN** каждый документ анализируется полным промптом GigaChat
- **THEN** на каждой итерации эмитируются `type="node_status"` и `type="loop_progress"`

### Requirement: SwitchNode — маршрутизация по классификации
`ScenarioExecutorSwitchNode` SHALL направлять выполнение на основе классификации узла или правил.

#### Scenario: Ветвь по умолчанию
- **WHEN** ни одно правило не совпало
- **THEN** используется `defaultLabelSet`
- **THEN** эмитируется `type="switch_result"`, `matched_rule="default"`

### Requirement: IfNode — условное ветвление
`ScenarioExecutorIfNode` SHALL вычислять условия с операторами: `contains`, `equals`, `greater_than`, `less_than`, `startsWith`.

#### Scenario: Проверка contains
- **WHEN** `IF_NODE` с `operator="contains"`, `field="output.text"`, `value="error"`
- **THEN** вычисляется условие: `output.text.contains("error")`
- **THEN** эмитируется `type="if_result"`, `condition_met=true/false`

### Requirement: CalcNode — вычисление формул
`ScenarioExecutorCalcNode` SHALL вычислять формулы через `FormulaEvaluator` с BigDecimal и поддержкой функций.

#### Scenario: Простая формула
- **WHEN** `formula="SUM(A1:A10)"`
- **THEN** `FormulaEvaluator` вычисляет с агрегацией
- **THEN** результат — `BigDecimal`

### Requirement: AggregateNode — агрегация данных
`ScenarioExecutorAggregateNode` SHALL агрегировать данные по ключу группы с опциональной фильтрацией.

#### Scenario: Группировка
- **WHEN** `AGGREGATE_NODE` с `groupKey="category"`
- **THEN** данные группируются по полю `category`
- **THEN** `SUM/AVG` вычисляются по каждой группе

### Requirement: TransformNode — преобразования текста
`ScenarioExecutorTransformNode` SHALL поддерживать преобразования текста: `regex_replace`, `substring`, `split`, `join`, `upper`, `lower`, `trim`, `replace`.

#### Scenario: Замена по регулярному выражению
- **WHEN** `TRANSFORM_NODE` с `operation="regex_replace"`, `pattern="\d+"`, `replacement="NUMBER"`
- **THEN** все цифры в выходе заменяются на "NUMBER"

### Requirement: SubscenarioNode — рекурсивное выполнение
`ScenarioExecutorSubscenarioNode` SHALL поддерживать рекурсивное выполнение подсценария с максимальной глубиной 2.

#### Scenario: Простая рекурсия
- **WHEN** `SUBSCENARIO_NODE` с `subScenarioId`
- **THEN** дочерний сценарий выполняется с теми же входными документами
- **THEN** максимальная глубина рекурсии = 2 (соответствует `MAX_SUB_DEPTH = 2` в `ScenarioEngine`)

### Requirement: ControlNode — валидация
`ScenarioExecutorControlNode` SHALL проверять предусловия и останавливать выполнение при ошибке.

#### Scenario: Ошибка валидации
- **WHEN** `CONTROL_NODE` вычисляет условие = false
- **THEN** срабатывает `on_error="stop"`
- **THEN** выбрасывается `ScenarioException(400)`

### Requirement: WaitNode — ожидание
`ScenarioExecutorWaitNode` SHALL поддерживать настраиваемую задержку.

#### Scenario: Ожидание
- **WHEN** `WAIT_NODE` с `duration_ms=5000`
- **THEN** поток засыпает на 5 секунд

### Requirement: Кодовая сверка сумм (сверить_суммы)
Система SHALL позволять transform-узлу собирать по всем документам прогона суммы рядом с меткой и выдавать сводку группировкой по значению.

#### Scenario: Сводка сумм по метке
- **WHEN** операция `сверить_суммы` с параметрами `метка` (default `"НМЦД?"`) и `окно` (default `80`)
- **THEN** по regex `(метка)[^0-9]{0,окно}?(\d[\d\s\u00A0]{3,17}(?:[.,]\d{1,2})?)` собираются суммы
- **AND** значения `NaN` и `< 10_000` отбрасываются (шум: проценты, номера пунктов)
- **AND** суммы группируются по значению (`%.2f`) с именами файлов
- **THEN** результат — текстовый отчёт `СВЕРКА СУММ ПО МЕТКЕ «…»:` и строка `Различных значений: N`
- **AND** при отсутствии находок — «упоминаний сумм рядом с меткой не найдено»

### Requirement: Кодовая проверка процентов (проверить_проценты)
Система SHALL позволять пересчитывать процентные значения от базовой суммы (НМЦ) и сообщать о расхождении сверх допуска.

#### Scenario: Сверка X% от базы
- **WHEN** операция `проверить_проценты` задана (параметры `база_метка`, `допуск` default `0.3`, `формат`)
- **THEN** `base = maxAmountNearLabel(база_метка)` берётся по всем документам; при `base <= 0` — проверка пропущена
- **AND** для конструкции `(\d{1,2}...)\s*%[^0-9%]{0,120}(\d... ,\d{2})` парсятся процент и сумма
- **AND** при `|amount - base*percent/100| / expected > допуск` — в отчёт расхождение
- **AND** при `формат="json_находки"` — JSON-свод `{"находки":[...]}`, иначе текстовый отчёт

### Requirement: Кодовая сверка дат (сверить_даты)
Система SHALL выявлять договоры, заключённые позже начала периода услуг («услуги задним числом»).

#### Scenario: Расхождение дат договора и периода
- **WHEN** операция `сверить_даты` c `минимум_дней` (default `15`) и `формат`
- **THEN** ищутся пары «дата договора / дата начала периода» (прямой и обратный порядок паттернов `dd.MM.yyyy`)
- **AND** если `ChronoUnit.DAYS.between(start, signed) >= минимум_дней` — в отчёт «услуги начинаются на N дн. раньше заключения договора»
- **AND** непарсибельные даты пропускаются (`DateTimeParseException`)
- **AND** при `формат="json_находки"` — JSON-свод типа «услуги до оформления договора»

### Requirement: Кодовая проверка цитат (проверить_цитаты)
Система SHALL дополнять каждую находку свода полями `документ` и `достоверность` по совпадению с текстами документов прогона.

#### Scenario: Классификация цитаты
- **WHEN** операция `проверить_цитаты` обрабатывает JSON-массив находок
- **THEN** цитата, начинающаяся с `"нет "`, `"отсутств"`, `"не устано"`, `"не указан"` → `достоверность="н/п (об отсутствии)"`, `документ="—"`
- **AND** цитата короче 12 символов → `"цитата слишком коротка"`
- **AND** точное подстроковое вхождение в нормализованный текст документа → `"точно"` + имя документа
- **AND** иначе `coverage >= 0.8` (LCS-подобное пословное покрытие в окне вокруг якорного слова) → `"нечётко"` + документ
- **AND** иначе → `достоверность="НЕ НАЙДЕНА"`, `документ="—"`

### Requirement: Извлечение из документов по имени файла (извлечь_из_документов)
Система SHALL извлекать regex-ом значение из документов, отфильтрованных по регулярному выражению имени файла, с указанием источника.

#### Scenario: Двухпроходное извлечение
- **WHEN** операция `извлечь_из_документов` с `имя`, `шаблон`, `группа`, `строго`
- **THEN** сначала обходятся документы, чьё имя соответствует `имя` (`preferred=true`), затем остальные
- **AND** при `строго=true` после первого подходящего документа проход прекращается
- **AND** результат — `значение + " [источник: <имя файла>]"`, либо строка `"не найдено"`

### Requirement: Уникальные строки (уникальные_строки)
Система SHALL удалять повторяющиеся строки с сохранением порядка первых вхождений и отбрасыванием пустых.

#### Scenario: Схлопывание дубликатов строк
- **WHEN** операция `уникальные_строки`
- **THEN** каждая строка `strip()`-ится; пустые отбрасываются
- **AND** результат — строки, соединённые `"\n"`, без повторов (`LinkedHashSet`)

### Requirement: Дедупликация и лимиты в слить_json_массивы
Система SHALL поддерживать в `слить_json_массивы` параметры `дедуп_по` и `лимит_типов`.

#### Scenario: Дедуп по ключам
- **WHEN** `дедуп_по: ["тип","цитата"]`
- **THEN** сигнатура = конкатенация значений ключей, нормализованных `strip()+toLowerCase()` (разделитель `\u0001`)
- **AND** повторы схлопываются до первого вхождения (порядок сохраняется)

#### Scenario: Лимит по типам
- **WHEN** `лиmit_типов: {"<тип>": N}`
- **THEN** для типа находки (ключ `"тип"`, lowercase) остаются только первые N вхождений
- **AND** типы без лимита проходят без изменений

### Requirement: Пустой массив — валидный вклад
Система SHALL НЕ падать при пустых JSON-массивах в `слить_json_массивы` («находок нет»).

#### Scenario: Пустые массивы дают []
- **WHEN** на вход `слить_json_массивы` приходят `{"находки": []}` и ещё `{"находки": []}`
- **THEN** результатом является `[ ]` без исключения
- **AND** узел завершается `COMPLETED`
