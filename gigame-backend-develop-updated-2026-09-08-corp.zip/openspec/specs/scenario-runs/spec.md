---
capability: scenario-runs
---

# Scenario Runs Specification

## Purpose

Define the lifecycle of scenario runs: `RUNNING → COMPLETED / FAILED`, pause/resume, step-mode timeout eviction. Run triggering is via WebSocket (`/ws/scenario`), not REST.

## Requirements

### Requirement: Жизненный цикл прогона сценария
Система SHALL отслеживать прогоны сценариев с переходами статуса: `RUNNING → COMPLETED / FAILED`, с поддержкой `step_mode`.

> **Важно**: Запуск сценария происходит через WebSocket (`/ws/scenario`), не через REST `POST /api/scenarios/{id}/run`.

#### Scenario: Запуск прогона через WebSocket
- **WHEN** пользователь отправляет через WebSocket `/ws/scenario` сообщение `{"scenario_id": "uuid", "step_mode": false}`
- **THEN** `ScenarioWebSocketHandler.handle()` направляет в `scenarioService.runScenario()`
- **THEN** создаётся `ScenarioRun` со `status="RUNNING"`, `user_id`
- **THEN** граф сценария выполняется через `ScenarioEngine.doExecute()`
- **THEN** SSE-события эмитируются в реальном времени

#### Scenario: Завершение прогона
- **WHEN** все узлы выполнились успешно
- **THEN** `status` устанавливается в `"COMPLETED"`, заполняется `result`
- **THEN** устанавливается `completed_at`

### Requirement: Возобновление упавшего прогона
Система SHALL позволять возобновлять прогон со статусом `FAILED` с последнего успешного узла.

#### Scenario: Возобновление после ошибки
- **WHEN** `POST /api/scenarios/runs/{runId}/continue` на прогоне со статусом `FAILED`
- **THEN** вызывается `ScenarioEngine.resumeExecution()`
- **THEN** завершённые LLM-узлы восстанавливаются через `restoreLlmNode()`
- **THEN** выполнение продолжается с упавшего узла

### Requirement: Таймаут пошагового режима
Система SHALL очищать зависшие сессии пошагового режима после 30-минутного таймаута через `@Scheduled`.

#### Scenario: Очистка зависшей сессии
- **WHEN** пошаговый режим находится на паузе дольше 30 минут
- **THEN** `@Scheduled(fixedRate = 60000)` → `evictExpiredStepEvents()`
- **THEN** `CompletableFuture` отменяется
- **THEN** прогон помечается `FAILED`

### Requirement: Усечение полей отчёта до 200k
Система SHALL усекать длинные текстовые поля шага прогона в `ScenarioMapper` до лимита `REPORT_FIELD_LIMIT = 200_000` символов с явной пометкой об усечении.

#### Scenario: Длинное поле обрезается с пометкой
- **WHEN** поле шага (`promptUsed`, `result`, `error`, `documents_text`, `previous_output`) длиннее `200_000` символов
- **THEN** значение обрезается до первых `200_000` символов
- **AND** добавляется суффикс `\n\n…[показаны первые 200000 из N символов — полный текст доступен в файловых выгрузках узлов]`

#### Scenario: Короткие поля не меняются
- **WHEN** значение поля не превышает лимит или равно `null`
- **THEN** возвращается без изменений
