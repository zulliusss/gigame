---
capability: documents
---

# Documents Specification

## Purpose

Define document upload, text extraction, and OCR for PDF/DOCX/XLSX/TXT files up to 30MB.

## Requirements

### Requirement: Загрузка документа
Система SHALL принимать загрузку файлов (PDF, DOCX, XLSX, TXT) до 30MB на файл, извлекать текст и сохранять в базе данных.

#### Scenario: Успешная загрузка PDF
- **WHEN** пользователь отправляет `POST /api/documents` с multipart-файлом `report.pdf` (10MB, `application/pdf`)
- **THEN** PDFBox 3.0.7 извлекает текст из PDF
- **THEN** запись в `documents` содержит `filename="report.pdf"`, `content_type="application/pdf"`, `size_bytes=10485760`, `extracted_text`, `user_id`
- **THEN** ответ — `DocumentViewResponse(id, filename, content_type, size_bytes, extracted_text, created_at)` с HTTP 201

#### Scenario: Неподдерживаемый формат
- **WHEN** пользователь загружает `image.png`
- **THEN** выбрасывается `FileException(422)`: "Unsupported file format: png"

### Requirement: Извлечение текста из разных форматов
Система SHALL поддерживать извлечение текста из PDF (PDFBox 3.0.7), DOCX/XLSX (Apache POI 5.5.1), TXT (прямое чтение) и plain-text вариантов.

#### Scenario: Извлечение текста из DOCX
- **WHEN** пользователь загружает `document.docx`
- **THEN** Apache POI XWPF парсит параграфы в текст
- **THEN** `extracted_text` содержит объединённый текст параграфов

#### Scenario: Извлечение текста из XLSX
- **WHEN** пользователь загружает `spreadsheet.xlsx`
- **THEN** Apache POI XSSF обходит все строки и ячейки
- **THEN** `extracted_text` содержит значения ячеек, объединённые переносами строк

### Requirement: OCR для отсканированных PDF
Система SHALL опционально выполнять OCR для отсканированных PDF (извлечено <40 символов) через GigaChat Files API.

#### Scenario: Запуск OCR
- **WHEN** PDF даёт меньше `minParsedChars=40` символов и `ocr-via-gigachat=true`
- **THEN** PDF отправляется в GigaChat Files API для распознавания
- **THEN** `extracted_text` заменяется результатом OCR
- **THEN** настройки OCR: `ocr-model`, `ocr-max-tokens=8000`

### Requirement: Склейка разрядов чисел (normalizeNumberGroups)
Система SHALL после извлечения текста склеивать числа, разорванные экстрактором на разряды пробелами, переносами строк или запятой между частями.

#### Scenario: Сгруппированные по 3 разряда
- **WHEN** текст содержит `9 750 986,34` (разделители: пробел, `\u00A0`, `\u202F`, `\u2009`)
- **THEN** склейка удаляет разделители: `9750986,34`

#### Scenario: Рваные куски (PDFBox)
- **WHEN** текст содержит `975 09 86,34` (куски 1–3 цифры) с обязательной дробью
- **THEN** склейка даёт `9750986,34`
- **AND** изолированные целые числа (без дроби) не склеиваются (чтобы не слипаться с соседними)

#### Scenario: Разрыв переносом строки
- **WHEN** текст содержит `394134\n3,56` или `384553,\n94` (длинная голова 4+ цифр + дробный хвост 1–2 цифры)
- **THEN** склейка удаляет перенос и получает `3941343,56` / `384553,94`
- **AND** значение с некорректной группой головы (например `2025 100 000,00`) не слипается

#### Scenario: Отсутствие разрывов
- **WHEN** число записано без разрывов или текст пуст/`null`
- **THEN** текст возвращается без изменений

### Requirement: Лимиты структуры документа
Система SHALL ограничивать размер файла и структуру XLSX/XML для защиты от DoS/ZIP-бомб.

#### Scenario: Лимит размера файла
- **WHEN** загружаемый файл превышает `max-file-size` (default `52428800` = 50МБ, `DOCUMENT_MAX_FILE_SIZE`)
- **THEN** выбрасывается `FileException` до парсинга текста

#### Scenario: Лимит листов и строк XLSX
- **WHEN** книга содержит больше `max-sheets` (default `100`) листов
- **THEN** обрабатываются только первые `max-sheets` листов (лишние игнорируются)
- **AND** при суммарном числе обработанных строк по всем листам больше `max-total-rows` (default `100000`) выбрасывается `FileException("Превышено максимальное число строк...")`

#### Scenario: Лимит XML-узлов и запрет XXE
- **WHEN** XML-парсинг встречает более `max-xml-nodes` (default `10000`) узлов в списке дочерних / в обходе
- **THEN** обработка ограничивается (`Math.min(children.getLength(), maxXmlNodes)` / счётчик посещённых узлов)
- **AND** включён `FEATURE_SECURE_PROCESSING`, внешние DTD/схемы пусты (`ACCESS_EXTERNAL_DTD=""`, `ACCESS_EXTERNAL_SCHEMA=""`)
