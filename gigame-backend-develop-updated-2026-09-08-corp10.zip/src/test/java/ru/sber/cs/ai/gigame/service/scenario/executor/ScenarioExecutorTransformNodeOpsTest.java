package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Тесты новых операций узла «Трансформация»: пустые массивы и дедупликация
 * в «слить_json_массивы», «проверить_цитаты», «сверить_суммы»,
 * «извлечь_из_документов».
 */
class ScenarioExecutorTransformNodeOpsTest {

    private static final String EXCLUDE_RULES = "{\"операции\": [{\"оп\": \"слить_json_массивы\", "
            + "\"исключить_типы\": {\"по_узлу\": \"Способ закупки\", "
            + "\"если_не_содержит\": \"единственн|неконкурентн\", "
            + "\"типы\": [\"обоснование выбора единственного поставщика\"]}}]}";

    private static final String EP_FINDINGS = """
            [{"номер": 1, "тип": "обоснование выбора единственного поставщика", "цитата": "ЕП-цитата"},
             {"номер": 2, "тип": "расхождение сумм между документами", "цитата": "суммы"}]
            """;

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private static ScenarioRunGraph graph(String rules) {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Трансформация")
                        .rules(rules)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        return graph;
    }

    @Test
    void mergeAcceptsEmptyArrays() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("{\"находки\": []} и ещё {\"находки\": []}");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("[ ]", result.trim().replaceAll("\\s+", " "));
    }

    @Test
    void mergeDeduplicatesByConfiguredKeys() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\", "
                + "\"дедуп_по\": [\"тип\", \"цитата\"]}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "бренд", "цитата": "HP 100"}]
                [{"номер": 2, "тип": "Бренд", "цитата": " hp 100 "},
                 {"номер": 3, "тип": "сроки", "цитата": "7 дней"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals(2, result.split("\"цитата\"").length - 1);
        assertTrue(result.contains("7 дней"));
    }

    @Test
    void verifyCitationsMarksFoundAndAbsenceFindings() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(
                List.of("Техническое задание. Поставка серверов HP ProLiant 380 в сборе."),
                List.of("ТЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "бренд", "цитата": "Поставка серверов HP ProLiant 380"},
                 {"номер": 2, "тип": "нмц", "цитата": "Отсутствует обоснование НМЦ"},
                 {"номер": 3, "тип": "фантом", "цитата": "Все участники обязаны молчать о ценах"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"точно\""));
        assertTrue(result.contains("ТЗ.docx"));
        assertTrue(result.contains("н/п (об отсутствии)"));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void compareAmountsReportsValuesPerDocument() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_суммы\", \"метка\": \"НМЦД?\"}]}");
        graph.addDocs(
                List.of("Пояснительная. НМЦД составляет 289523339,14 руб.",
                        "Раздел обоснования. НМЦД: 349669037,34 руб."),
                List.of("ПЗ.docx", "Обоснование.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("289523339.14"));
        assertTrue(result.contains("349669037.34"));
        assertTrue(result.contains("Различных значений: 2"));
    }

    @Test
    void extractFromDocsPrefersMatchingFilenames() {
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", "
                + "\"имя\": \"ПЗ|[Ии]звещени\", "
                + "\"шаблон\": \"Способ закупки[\\\\s:|]*\\\\n?\\\\s*([^\\\\n|>]{4,120})\"}]}");
        graph.addDocs(
                List.of("Протокол 2022. Способ закупки\nЗакупка у единственного поставщика",
                        "ПЗ текущая. Способ закупки\nАдресный запрос предложений"),
                List.of("Протокол-2022.pdf", "ПЗ рамка.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Адресный запрос предложений"));
        assertTrue(result.contains("ПЗ рамка.docx"));
        assertFalse(result.contains("единственного"));
    }

    @Test
    void extractFromDocsFallsBackToOtherDocuments() {
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", "
                + "\"имя\": \"[Ии]звещени\", "
                + "\"шаблон\": \"Способ закупки[\\\\s:|]*\\\\n?\\\\s*([^\\\\n|>]{4,120})\"}]}");
        graph.addDocs(
                List.of("Документация. Способ закупки\nОткрытый конкурс"),
                List.of("Документация.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Открытый конкурс"));
    }

    @Test
    void checkPercentagesFlagsMismatchAndAcceptsCorrectValue() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_проценты\"}]}");
        graph.addDocs(
                List.of("НМЦ закупки составляет 1770719375,04 рублей. "
                        + "Размер обеспечения договора не более 1 % от НМЦ договора – "
                        + "2 500 000,00 руб. "
                        + "Аванс составляет 10 % от цены договора: 177 071 937,50 руб."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // 1% от 1,77 млрд = 17,7 млн, а указано 2,5 млн — расхождение попадает в отчёт
        assertTrue(result.contains("расхождение"));
        assertTrue(result.contains("17707193.75"));
        // корректный аванс (ровно 10%) расхождением не считается
        assertFalse(result.contains("177071937.50, но"));
    }

    @Test
    void checkPercentagesSkipsWhenBaseMissing() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_проценты\"}]}");
        graph.addDocs(List.of("Обеспечение 5 % — 100 000,00 руб., базы нет."),
                List.of("Письмо.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("проверка пропущена"));
    }

    @Test
    void compareDatesFlagsContractSignedAfterServicePeriodStart() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\"}]}");
        graph.addDocs(
                List.of("Был заключен новый договор № 72/5619206 от 12.05.2026 на оказание "
                                + "услуг на период с 01.01.2026 по 31.05.2026.",
                        "Договор № 7 от 10.01.2026, срок оказания услуг с 15.01.2026."),
                List.of("ПЗ.docx", "Договор7.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("12.05.2026"));
        assertTrue(result.contains("раньше заключения договора"));
        // корректный договор (подписан до начала услуг) в отчёт не попадает
        assertFalse(result.contains("Договор7.docx"));
    }

    @Test
    void compareDatesHandlesReversedPhraseOrder() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\"}]}");
        graph.addDocs(
                List.of("Ввиду необходимости непрерывности оказания услуг на период "
                        + "с 01.01.2026г. по 31.05.2026 (на время подготовки документов) "
                        + "с поставщиком был заключен новый договор № 72/5619206 от 12.05.2026."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // период упомянут ДО договора — обратный порядок фраз тоже распознаётся
        assertTrue(result.contains("12.05.2026"));
        assertTrue(result.contains("01.01.2026"));
        assertTrue(result.contains("раньше заключения договора"));
    }

    @Test
    void compareDatesEmitsFindingsJsonForMergeNode() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\", "
                + "\"формат\": \"json_находки\"}]}");
        graph.addDocs(
                List.of("Договор № 72 от 12.05.2026 на оказание услуг, "
                        + "период оказания услуг с 01.01.2026 по 31.05.2026."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // формат «json_находки» — готовый вход для «слить_json_массивы» (свод)
        assertTrue(result.trim().startsWith("{"));
        assertTrue(result.contains("\"находки\""));
        assertTrue(result.contains("услуги до оформления договора"));
        assertTrue(result.contains("ПЗ.docx"));
    }

    @Test
    void mergeLimitsFindingsPerConfiguredType() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\", "
                + "\"лимит_типов\": {\"НМЦД против опроса рынка\": 1}}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "НМЦД против опроса рынка", "цитата": "первая"},
                 {"номер": 2, "тип": "НМЦД против опроса рынка", "цитата": "вторая"},
                 {"номер": 3, "тип": "сроки", "цитата": "третья"},
                 {"номер": 4, "тип": "сроки", "цитата": "четвёртая"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // лимитированный тип обрезан до одного вхождения, остальные не тронуты
        assertTrue(result.contains("первая"));
        assertFalse(result.contains("вторая"));
        assertTrue(result.contains("третья"));
        assertTrue(result.contains("четвёртая"));
    }

    /** Граф из transform-узла t1 и узла-донора с меткой «Способ закупки» и готовым выходом. */
    private static ScenarioRunGraph graphWithDonor(String rules, String donorOutput) {
        var transform = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Трансформация").rules(rules).build())
                .position(new PositionDto(0, 0))
                .build();
        var donor = NodeDto.builder()
                .id("t4")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Способ закупки").rules("{}").build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(transform, donor), List.of()));
        graph.getNodeMap().get("t4").getOutput().add(donorOutput);
        return graph;
    }

    @Test
    void mergeDropsExcludedTypesWhenDonorLacksCondition() {
        // способ закупки конкурентный — находка о единственном поставщике отбрасывается кодом
        var graph = graphWithDonor(EXCLUDE_RULES, "Адресный запрос предложений");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add(EP_FINDINGS);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertFalse(result.contains("ЕП-цитата"));
        assertTrue(result.contains("суммы"));
    }

    @Test
    void mergeKeepsExcludedTypesWhenDonorMatchesCondition() {
        // закупка у единственного поставщика — ЕП-находки уместны и остаются
        var graph = graphWithDonor(EXCLUDE_RULES, "Закупка у единственного поставщика");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add(EP_FINDINGS);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("ЕП-цитата"));
        assertTrue(result.contains("суммы"));
    }

    @Test
    void verifyCitationsChecksConfiguredFieldWithShortValues() {
        // таблица критериев: проверяется поле «значение», короткие даты допускаются мин_длиной 6
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\", \"поле\": \"значение\", \"мин_длина\": \"6\"}]}");
        graph.addDocs(List.of("12. Дата начала срока подачи заявок 17.09.2025. НМЦД 161560083 руб."),
                List.of("Извещение.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"критерий": "Дата начала срока подачи заявок", "значение": "17.09.2025"},
                 {"критерий": "Дата окончания срока подачи заявок", "значение": "23.04.2026"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // дата из документа найдена, выдуманная — помечена
        assertTrue(result.contains("\"17.09.2025\",\"документ\":\"Извещение.docx\"")
                || result.contains("\"точно\""));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void removeObjectsDropsAbsenceFindingsAfterCitationCheck() {
        // «отсутствие информации» с цитатой «нет информации» получает достоверность «об отсутствии» и отсекается кодом
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}, "
                + "{\"оп\": \"удалить_объекты\", \"поле\": \"достоверность\", \"шаблон\": \"об отсутствии\"}]}");
        graph.addDocs(List.of("Срок подачи заявок 5 дней с даты публикации извещения."), List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "сроки", "цитата": "Срок подачи заявок 5 дней с даты публикации"},
                 {"номер": 2, "тип": "гарантия", "цитата": "нет информации о независимой гарантии"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Срок подачи заявок"));
        assertFalse(result.contains("нет информации"));
    }

    @Test
    void removeObjectsHonoursAndCondition() {
        // строка риска без подтверждённой цитаты удаляется, строка паспорта с тем же признаком — остаётся
        var graph = graph("{\"операции\": [{\"оп\": \"удалить_объекты\", \"поле\": \"достоверность\", "
                + "\"шаблон\": \"НЕ НАЙДЕНА|коротка\", \"и_поле\": \"з4\", "
                + "\"и_шаблон\": \"^(ВЫСОКИЙ|СРЕДНИЙ|НИЗКИЙ)$\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"з1": "1", "з2": "Выдуманный риск", "з4": "ВЫСОКИЙ", "достоверность": "НЕ НАЙДЕНА"},
                 {"з1": "2", "з2": "Реальный риск", "з4": "СРЕДНИЙ", "достоверность": "точно"},
                 {"з1": "—", "з2": "Способ закупки: конкурс", "з4": "ПАСПОРТ", "достоверность": "цитата слишком коротка"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertFalse(result.contains("Выдуманный риск"));
        assertTrue(result.contains("Реальный риск"));
        assertTrue(result.contains("Способ закупки: конкурс"));
    }

    @Test
    void extractFromDocsCollectsAllMatches() {
        // НМЦД по лотам и итог из одной пояснительной записки — все суммы по порядку, без повторов
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", \"имя\": \"ПЗ\", "
                + "\"шаблон\": \"(\\\\d[\\\\d ]{5,20}[,.]\\\\d{2})\\\\s*руб\", \"группа\": 1, "
                + "\"все\": true, \"разделитель\": \"; \"}]}");
        graph.addDocs(List.of("НМЦД по Лоту 1 – 125486266,74 руб.; по Лоту 2 - 164037072,40 руб. "
                + "Итоговая сумма закупки составит: не более 289523339,14 руб., включая НДС; повтор 289523339,14 руб."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("125486266,74; 164037072,40; 289523339,14 [источник: ПЗ.docx]", result);
    }

    @Test
    void verifyCitationsRespectsDocumentNameFilter() {
        // цитата есть только в файле строк, который исключён из сверки — находка не подтверждается
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\", \"документы\": \"^(?!строки)\"}]}");
        graph.addDocs(List.of("Срок подачи заявок 5 дней с даты публикации извещения.",
                "[{\"цитата\": \"Исполнитель не вправе привлекать третьих лиц\"}]"),
                List.of("ПЗ.docx", "строки.txt"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "сроки", "цитата": "Срок подачи заявок 5 дней с даты публикации"},
                 {"номер": 2, "тип": "договор", "цитата": "Исполнитель не вправе привлекать третьих лиц"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"достоверность\" : \"точно\"") || result.contains("\"достоверность\":\"точно\""));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void setFieldTagsPassportRowsByRegex() {
        // строки паспорта, которым модель не поставила метку, получают з4=ПАСПОРТ кодом
        var graph = graph("{\"операции\": [{\"оп\": \"установить_поле\", \"поле\": \"з4\", "
                + "\"значение\": \"ПАСПОРТ\", \"если_поле\": \"з2\", \"шаблон\": \"^(Способ закупки|НМЦ/НМЦД):\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"з1": "—", "з2": "Способ закупки: конкурс", "з4": "—"},
                 {"з1": "1", "з2": "Короткий срок подачи заявок", "з4": "СРЕДНИЙ"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("ПАСПОРТ"));
        assertFalse(result.contains("\"з4\" : \"—\""));
        assertTrue(result.contains("СРЕДНИЙ"));
    }

    @Test
    void sectionFromHeadersTagsRowsWithLastHeader() {
        // строки критериев получают секцию по последнему заголовку лота — правило «весь блок квалифов = нет» опирается на неё
        var graph = graph("{\"операции\": [{\"оп\": \"секция_из_заголовков\"}, "
                + "{\"оп\": \"установить_поле\", \"поле\": \"значение\", \"значение\": \"нет\", "
                + "\"если_поле\": \"секция\", \"шаблон\": \"Квалификационн\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"критерий": "Количество лотов закупки", "значение": "2", "источник": "п. 9"},
                 {"критерий": "ЛОТ №1 (Квалификационные требования)", "значение": "", "источник": ""},
                 {"критерий": "Технология 1", "значение": "Java", "источник": "Раздел 6"},
                 {"критерий": "Наличие квалификационных требований", "значение": "Да", "источник": "Раздел 5"},
                 {"критерий": "ЛОТ №1 (Методические требования)", "значение": "", "источник": ""},
                 {"критерий": "Технология 1", "значение": "Java", "источник": "Раздел 6"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"секция\" : \"ЛОТ №1 (Квалификационные требования)\""));
        assertTrue(result.contains("\"секция\" : \"ЛОТ №1 (Методические требования)\""));
        assertTrue(result.contains("\"значение\" : \"2\""));
        assertFalse(result.contains("\"значение\" : \"Да\""));
        assertEquals(1, result.split("\"значение\" : \"Java\"", -1).length - 1);
        // строка-заголовок секции не тронута: значение у неё остаётся пустым
        assertEquals(2, result.split("\"значение\" : \"\"", -1).length - 1);
    }

    @Test
    void sequenceBuildsLotListFromCountWhenInputIsEmpty() {
        // документация без упоминаний «Лот N»: список лотов строится по строке «Количество лотов закупки | 3» общего блока
        String rules = "{\"операции\": [{\"оп\": \"последовательность\", \"из_узла\": \"Способ закупки\", "
                + "\"шаблон\": \"Количество лотов закупки\\\\s*\\\\|\\\\s*(\\\\d+)\"}]}";
        var graph = graphWithDonor(rules, "Категория закупки | работы | п. 3\nКоличество лотов закупки | 3 | п. 9");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("[]");

        assertEquals("[\"1\",\"2\",\"3\"]", new ScenarioExecutorTransformNode(node).execute(sink).strip());

        var kept = graphWithDonor(rules, "Количество лотов закупки | 3").getNodeMap().get("t1");
        kept.getInput().add("[\"1\",\"2\"]");
        assertTrue(new ScenarioExecutorTransformNode(kept).execute(sink).contains("[\"1\",\"2\"]"));

        var noNumber = graphWithDonor(rules, "Количество лотов закупки | не указано").getNodeMap().get("t1");
        noNumber.getInput().add("[]");
        assertEquals("[]", new ScenarioExecutorTransformNode(noNumber).execute(sink).strip());
    }

    @Test
    void sequenceAlwaysBuildsWhenIfEmptyFalseAndCapsAtMaximum() {
        // «если_пусто: false» — список строится и при непустом входе; «максимум» обрезает число донора
        String always = "{\"операции\": [{\"оп\": \"последовательность\", \"из_узла\": \"Способ закупки\", "
                + "\"шаблон\": \"лотов\\\\s*\\\\|\\\\s*(\\\\d+)\", \"если_пусто\": \"false\", \"максимум\": \"2\"}]}";
        var node = graphWithDonor(always, "Количество лотов | 5").getNodeMap().get("t1");
        node.getInput().add("[\"7\"]");

        assertEquals("[\"1\",\"2\"]", new ScenarioExecutorTransformNode(node).execute(sink).strip());
    }

    @Test
    void sequenceLeavesInputWhenDonorUnknownOrGroupNotNumeric() {
        // узел-донор отсутствует в графе — вход не меняется и узел не падает
        String missing = "{\"операции\": [{\"оп\": \"последовательность\", \"из_узла\": \"Нет такого узла\"}]}";
        var node = graphWithDonor(missing, "Количество лотов | 3").getNodeMap().get("t1");
        node.getInput().add("[]");
        assertEquals("[]", new ScenarioExecutorTransformNode(node).execute(sink).strip());

        // шаблон без группы: совпадение «3 лота» — не число, NumberFormatException не выбрасывается
        String noGroup = "{\"операции\": [{\"оп\": \"последовательность\", \"из_узла\": \"Способ закупки\", \"шаблон\": \"\\\\d+ лота\"}]}";
        var text = graphWithDonor(noGroup, "всего 3 лота").getNodeMap().get("t1");
        text.getInput().add("[]");
        assertEquals("[]", new ScenarioExecutorTransformNode(text).execute(sink).strip());

        // шаблон без группы, но совпадение — число целиком
        String whole = "{\"операции\": [{\"оп\": \"последовательность\", \"из_узла\": \"Способ закупки\", \"шаблон\": \"\\\\d+\"}]}";
        var digits = graphWithDonor(whole, "всего 2 лота").getNodeMap().get("t1");
        digits.getInput().add("");
        assertEquals("[\"1\",\"2\"]", new ScenarioExecutorTransformNode(digits).execute(sink).strip());
    }

    @Test
    void sequenceKeepsNumericItemsAndAttachIgnoresHugeNumbers() {
        // числа в массиве остаются числами после отсечения; «№ 32514567890» в ответе агента — не номер строки
        String rules = "{\"операции\": [{\"оп\": \"последовательность\", \"из_узла\": \"Способ закупки\", "
                + "\"шаблон\": \"лотов\\\\s*\\\\|\\\\s*(\\\\d+)\"}]}";
        var node = graphWithDonor(rules, "Количество лотов | 2").getNodeMap().get("t1");
        node.getInput().add("[1, 2, 12]");
        assertEquals("[1,2]", new ScenarioExecutorTransformNode(node).execute(sink).replaceAll("\\s", ""));

        String attach = "{\"операции\": [{\"оп\": \"прикрепить_по_номеру\", \"из_узла\": \"Способ закупки\", \"поле\": \"к21\", "
                + "\"шаблон\": \"№\\\\s*(\\\\d+)\\\\s*:\\\\s*(.*)\", \"только_номера_из_узла\": \"Нет такого узла\"}]}";
        var big = graphWithDonor(attach, "Извещение № 32514567890: срок 5 дней\nНАХОДКА №1: ПОДТВЕРЖДАЮ").getNodeMap().get("t1");
        big.getInput().add("[{\"к15\": \"зачтено\"}]");
        assertFalse(new ScenarioExecutorTransformNode(big).execute(sink).contains("к21"));
    }

    @Test
    void sequenceDropsNumbersAboveDonorCount() {
        // «по лоту 12.05.2026» дало ложный номер 12 — при двух лотах по донору он отбрасывается
        String rules = "{\"операции\": [{\"оп\": \"последовательность\", \"из_узла\": \"Способ закупки\", "
                + "\"шаблон\": \"лотов\\\\s*\\\\|\\\\s*(\\\\d+)\"}]}";
        var node = graphWithDonor(rules, "Количество лотов | 2").getNodeMap().get("t1");
        node.getInput().add("[\"1\",\"2\",\"12\"]");
        assertEquals("[\"1\",\"2\"]", new ScenarioExecutorTransformNode(node).execute(sink).strip());

        String keep = rules.replace("(\\\\d+)\"", "(\\\\d+)\", \"отсечь_лишние\": \"false\"");
        var raw = graphWithDonor(keep, "Количество лотов | 2").getNodeMap().get("t1");
        raw.getInput().add("[\"1\",\"2\",\"12\"]");
        assertTrue(new ScenarioExecutorTransformNode(raw).execute(sink).contains("\"12\""));
    }

    @Test
    void checkSectionsWithoutDonorOrWithEmptyDonorExplainsUnknownExpected() {
        String noDonor = "{\"операции\": [{\"оп\": \"проверить_секции\", \"шаблон_секции\": \"^ЛОТ\\\\s*№\\\\s*(\\\\d+)\"}]}";
        var node = graph(noDonor).getNodeMap().get("t1");
        node.getInput().add("[{\"критерий\": \"ЛОТ №1 (Квалификационные требования)\", \"значение\": \"\"}]");
        String result = new ScenarioExecutorTransformNode(node).execute(sink);
        assertTrue(result.contains("ожидаемое число лотов неизвестно"));
        assertTrue(result.contains("не задан узел-донор"));

        String withDonor = "{\"операции\": [{\"оп\": \"проверить_секции\", \"ожидаемо_из_узла\": \"Способ закупки\"}]}";
        var empty = graphWithDonor(withDonor, "").getNodeMap().get("t1");
        empty.getInput().add("[{\"критерий\": \"ЛОТ №1\", \"значение\": \"\"}]");
        String out = new ScenarioExecutorTransformNode(empty).execute(sink);
        assertTrue(out.contains("выход узла-донора «Способ закупки» пуст"));
        assertTrue(out.contains("найдено секций: 1 (1)"));
    }

    @Test
    void checkSectionsCountsDistinctLotsWhenHeadersRepeat() {
        // два заголовка «ЛОТ №1» и ни одного «ЛОТ №2»: найден один лот из двух, повтор — лишняя секция
        String rules = "{\"операции\": [{\"оп\": \"проверить_секции\", \"ожидаемо_из_узла\": \"Способ закупки\", "
                + "\"поле_заголовка\": \"название\", \"шаблон_секции\": \"^ЛОТ\\\\s*№\\\\s*(\\\\d+)\"}]}";
        var node = graphWithDonor(rules, "[\"1\",\"2\"]").getNodeMap().get("t1");
        node.getInput().add("[{\"название\": \"ЛОТ №1\"}, {\"название\": \"ЛОТ №01\"}]");
        String result = new ScenarioExecutorTransformNode(node).execute(sink);
        assertTrue(result.contains("извлечено 1 из 2"), result);
        assertTrue(result.contains("не извлечены лоты: 2; лишние секции: 1"), result);

        // шаблон без группы — номером служит весь заголовок
        String whole = "{\"операции\": [{\"оп\": \"проверить_секции\", \"ожидаемо_из_узла\": \"Способ закупки\", \"шаблон_секции\": \"^ЛОТ\"}]}";
        var headers = graphWithDonor(whole, "ЛОТ А\nЛОТ Б").getNodeMap().get("t1");
        headers.getInput().add("[{\"критерий\": \"ЛОТ А\"}, {\"критерий\": \"ЛОТ Б\"}]");
        assertTrue(new ScenarioExecutorTransformNode(headers).execute(sink).contains("извлечено 2 из 2 — полно"));
    }

    @Test
    void arrayOpsPreferNonEmptyObjectArrayAndNumberingDefaultsField() {
        // перед массивом строк — пустой «[]» узла «Номера лотов»: строки нумеруются, а не пропадают
        String rules = "{\"операции\": [{\"оп\": \"нумеровать\", \"поле\": \"\"}]}";
        var node = graph(rules).getNodeMap().get("t1");
        node.getInput().add("=== РЕЗУЛЬТАТ ОТ \"Номера лотов\" ===\n[]\n\n[{\"критерий\": \"Технология 1\", \"значение\": \"Java\"}]");
        String result = new ScenarioExecutorTransformNode(node).execute(sink);
        assertTrue(result.contains("\"№\""), result);
        assertTrue(result.contains("Java"), result);

        var onlyEmpty = graph(rules).getNodeMap().get("t1");
        onlyEmpty.getInput().add("[]");
        assertEquals("[]", new ScenarioExecutorTransformNode(onlyEmpty).execute(sink).replaceAll("\s", ""));
    }

    @Test
    void lotElementsCarryOnlyOwnLotRowsAndLotTechnologyCheckDropsForeignOnes() {
        // строки таблиц лота 2 (двух видов ячеек и строка текста) попадают в элемент лота 2, чужие — нет
        String section = "Раздел 2.\n[ < Лот №1 | опыт: Java и Hadoop > / < Лот №2 | опыт: UniData или Tibco > ]\n"
                + "Порог:\n[ < Лот | НМЦД > / < 1 | 511 > / < 2 | 272 > ]\nЛот №2 требует MDM.\nЛот 12 не лот 2.";
        String rules = "{\"операции\": [{\"оп\": \"элементы_лотов\", \"номера_из_узла\": \"Способ закупки\", "
                + "\"разделы\": [{\"метка\": \"Требования лота\", \"из_узла\": \"Способ закупки\"}]}]}";
        var graph = graphWithDonor(rules, section);
        var node = graph.getNodeMap().get("t1");
        // вход узла — с заголовком результата предыдущего узла: номера берутся из массива, а не из заголовка
        node.getInput().add("=== РЕЗУЛЬТАТ ОТ \"Номера лотов\" ===\n[\"1\",\"2\"]");

        String elements = new ScenarioExecutorTransformNode(node).execute(sink);
        assertFalse(elements.contains("РЕЗУЛЬТАТ ОТ"), elements);
        assertTrue(elements.contains("Номер лота: 2\\nТребования лота:\\n< Лот №2 | опыт: UniData или Tibco >\\n< 2 | 272 >\\nЛот №2 требует MDM."), elements);
        assertFalse(elements.contains("Лот 12"), elements);
        assertTrue(elements.contains("Номер лота: 1\\nТребования лота:\\n< Лот №1 | опыт: Java и Hadoop >\\n< 1 | 511 >"), elements);
        assertEquals(List.of(), ScenarioExecutorTransformNode.lotRows(section, "7"));

        // технология лота 2 «Java» — из строк лота 1: помечается и убирается, UniData остаётся
        String check = "{\"операции\": [{\"оп\": \"проверить_технологии_лотов\", \"элементы_из_узла\": \"Список\", \"удалять\": \"true\"}]}";
        var g2 = graphWithDonor(check, "");
        var list = NodeDto.builder().id("t5").type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Список").rules("{}").build()).position(new PositionDto(0, 0)).build();
        g2.getNodeMap().put("t5", new ScenarioRunGraph(new GraphDataDto(List.of(list), List.of())).getNodeMap().get("t5"));
        g2.getNodeMap().get("t5").getOutput().add(elements);
        var n2 = g2.getNodeMap().get("t1");
        n2.getInput().add("[{\"критерий\": \"Технология 1\", \"значение\": \"UniData\", \"секция\": \"ЛОТ №2 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"Технология 2\", \"значение\": \"Java\", \"секция\": \"ЛОТ №2 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"Наличие квалификационных требований\", \"значение\": \"Да\", \"секция\": \"ЛОТ №2 (Квалификационные требования)\"}]");
        String result = new ScenarioExecutorTransformNode(n2).execute(sink);
        assertTrue(result.contains("UniData"), result);
        assertFalse(result.contains("\"Java\""), result);
        assertTrue(result.contains("Наличие квалификационных требований"), result);

    }

    @Test
    void lotTechnologyCheckUsesSectionBlocksAndCommonText() {
        var g2 = graphWithDonor("{\"операции\": [{\"оп\": \"проверить_технологии_лотов\", \"элементы_из_узла\": \"Список\", \"удалять\": \"true\"}]}", "");
        var list = NodeDto.builder().id("t5").type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Список").rules("{}").build()).position(new PositionDto(0, 0)).build();
        g2.getNodeMap().put("t5", new ScenarioRunGraph(new GraphDataDto(List.of(list), List.of())).getNodeMap().get("t5"));
        var n2 = g2.getNodeMap().get("t1");
        // блоки по разделам: квалификационная секция сверяется с блоком Раздела 2 (строк нет — не проверяется),
        // методическая — с блоком Раздела 6
        String element = "Номер лота: 1\nТребования лота (строки Раздела 2 для этого лота):\n(строк этого лота в разделе нет — требования общие для всех лотов)\n"
                + "Методика лота (строки Раздела 6 для этого лота):\n< 1 | Hadoop и Python >";
        assertEquals("< 1 | Hadoop и Python >\n", ScenarioExecutorTransformNode.lotBlock(element, "ЛОТ №1 (Методические требования)"));
        assertTrue(ScenarioExecutorTransformNode.lotBlock(element, "ЛОТ №1 (Квалификационные требования)").contains("строк этого лота в разделе нет"));
        assertEquals("весь элемент", ScenarioExecutorTransformNode.lotBlock("весь элемент", "ЛОТ №1 (Методические требования)"));
        g2.getNodeMap().get("t5").getOutput().add("[\"" + element.replace("\n", "\\n") + "\"]");
        n2.getInput().add("[{\"критерий\": \"Технология 1\", \"значение\": \"Java\", \"секция\": \"ЛОТ №1 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"Технология 1\", \"значение\": \"Python\", \"секция\": \"ЛОТ №1 (Методические требования)\"}, "
                + "{\"критерий\": \"Технология 2\", \"значение\": \"PL/SQL\", \"секция\": \"ЛОТ №1 (Методические требования)\"}]");
        String checked = new ScenarioExecutorTransformNode(n2).execute(sink);
        assertTrue(checked.contains("\"Java\"") && checked.contains("\"Python\""), checked);
        assertFalse(checked.contains("PL/SQL"), checked);

        // технология «для всех лотов» (Приложение 3: Java общая, в строках лотов только суммы) — законна для лота 1,
        // а технология лишь из строки другого лота — нет
        String common = "Раздел 2.\nОпыт с Java и JavaScript для всех лотов.\n[ < 1 | 23 000 000 > / < 2 | 48 000 000 > / < Лот №2 | опыт UniData > ]";
        assertEquals("Раздел 2.\nОпыт с Java и JavaScript для всех лотов.\n[   /   /   ]", ScenarioExecutorTransformNode.lotFreeText(common));
        String checkCommon = "{\"операции\": [{\"оп\": \"проверить_технологии_лотов\", \"элементы_из_узла\": \"Список\", \"удалять\": \"true\", "
                + "\"общий_текст_из_узлов\": [\"Способ закупки\"]}]}";
        var g3 = graphWithDonor(checkCommon, common);
        g3.getNodeMap().put("t5", g2.getNodeMap().get("t5"));
        g3.getNodeMap().get("t5").getOutput().clear();
        g3.getNodeMap().get("t5").getOutput().add("[\"Номер лота: 1\\nТребования лота (строки Раздела 2 для этого лота):\\n< 1 | 23 000 000 >\"]");
        var n3 = g3.getNodeMap().get("t1");
        n3.getInput().add("[{\"критерий\": \"Технология 1\", \"значение\": \"Java\", \"секция\": \"ЛОТ №1 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"Технология 2\", \"значение\": \"UniData\", \"секция\": \"ЛОТ №1 (Квалификационные требования)\"}]");
        String commonChecked = new ScenarioExecutorTransformNode(n3).execute(sink);
        assertTrue(commonChecked.contains("\"Java\""), commonChecked);
        assertFalse(commonChecked.contains("UniData"), commonChecked);
    }

    @Test
    void addRequiredRowsInsertsMissingCriteriaAfterEachLotSection() {
        // у лота 1 модель пропустила «Минимальный объём … (в рублях)», у лота 2 — обе строки объёма; общий блок не трогается
        String rules = "{\"операции\": [{\"оп\": \"дополнить_строки\", \"секция_шаблон\": \"^ЛОТ\\\\s*№\", "
                + "\"обязательные\": [\"Наличие квалификационных требований\", \"Минимальный объём сопоставимого опыта (в рублях)\"], "
                + "\"значение\": \"не извлечено\"}]}";
        var node = graph(rules).getNodeMap().get("t1");
        node.getInput().add("[{\"критерий\": \"Категория закупки\", \"значение\": \"работы\", \"секция\": \"Общая информация\"}, "
                + "{\"критерий\": \"ЛОТ №1 (Квалификационные требования)\", \"значение\": \"\", \"секция\": \"ЛОТ №1 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"Наличие квалификационных требований\", \"значение\": \"Да\", \"секция\": \"ЛОТ №1 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"ЛОТ №2 (Квалификационные требования)\", \"значение\": \"\", \"секция\": \"ЛОТ №2 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"Технология 1\", \"значение\": \"Java\", \"секция\": \"ЛОТ №2 (Квалификационные требования)\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);
        List<?> arr;
        try {
            arr = new com.fasterxml.jackson.databind.ObjectMapper().readValue(result, List.class);
        } catch (Exception e) {
            throw new AssertionError(result, e);
        }
        List<String> keys = arr.stream().map(o -> String.valueOf(((Map<?, ?>) o).get("критерий")) + "@" + ((Map<?, ?>) o).get("секция")).toList();
        assertEquals(8, arr.size(), result);
        assertEquals("Минимальный объём сопоставимого опыта (в рублях)@ЛОТ №1 (Квалификационные требования)", keys.get(3));
        assertEquals("Наличие квалификационных требований@ЛОТ №2 (Квалификационные требования)", keys.get(6));
        assertEquals("Минимальный объём сопоставимого опыта (в рублях)@ЛОТ №2 (Квалификационные требования)", keys.get(7));
        assertTrue(result.contains("добавлено кодом — модель строку пропустила"), result);
        assertFalse(keys.stream().anyMatch(k -> k.endsWith("@Общая информация") && k.startsWith("Наличие")), result);
    }

    @Test
    void attachByNumberHonoursAllowedNumbersFromDonorList() {
        // агент на пустой список проблемных строк выдумал «НАХОДКА №1..№3» — без номеров в узле-списке ничего не прикрепляется
        String rules = "{\"операции\": [{\"оп\": \"прикрепить_по_номеру\", \"из_узла\": \"Способ закупки\", \"поле\": \"к21\", "
                + "\"шаблон\": \"НАХОДКА\\\\s*№\\\\s*(\\\\d+)\\\\s*:\\\\s*(.*)\", \"только_номера_из_узла\": \"Список\"}]}";
        String rows = "[{\"к15\": \"зачтено\"}, {\"к15\": \"акт/УПД не найден\"}, {\"к15\": \"зачтено\"}]";
        String agent = "НАХОДКА №1: ПОДТВЕРЖДАЮ — нет строк\nНАХОДКА №2: ВОЗРАЖАЮ — акт найден\nНАХОДКА №3: ПОДТВЕРЖДАЮ — нет строк";
        var graph = graphWithDonor(rules, agent);
        var list = NodeDto.builder().id("t5").type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Список").rules("{}").build()).position(new PositionDto(0, 0)).build();
        graph.getNodeMap().put("t5", new ScenarioRunGraph(
                new GraphDataDto(List.of(list), List.of())).getNodeMap().get("t5"));
        graph.getNodeMap().get("t5").getOutput().add("[{\"№\": \"2\", \"к15\": \"акт/УПД не найден\"}]");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add(rows);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);
        assertTrue(result.contains("ВОЗРАЖАЮ — акт найден"), result);
        assertFalse(result.contains("нет строк"), result);

        graph.getNodeMap().get("t5").getOutput().clear();
        graph.getNodeMap().get("t5").getOutput().add("[ ]");
        var empty = graph.getNodeMap().get("t1");
        empty.getInput().clear();
        empty.getInput().add(rows);
        assertFalse(new ScenarioExecutorTransformNode(empty).execute(sink).contains("к21"));
    }

    @Test
    void attachByNumberRewritesFalseDiscrepancyWhenAgentValueEqualsRow() {
        // агент «исправляет» вычисленные даты на те же самые — это подтверждение, а не расхождение
        String rules = "{\"операции\": [{\"оп\": \"прикрепить_по_номеру\", \"из_узла\": \"Способ закупки\", \"поле\": \"мнение\", "
                + "\"шаблон\": \"НАХОДКА\\\\s*№\\\\s*(\\\\d+)\\\\s*:\\\\s*(.*)\", \"поле_значения\": \"значение\"}]}";
        String agent = "НАХОДКА №1: РАСХОЖДЕНИЕ — правильно: «с 17.03.2025 по 17.09.2025»; основание: «за последние 6 месяцев» (Раздел 6)\n"
                + "НАХОДКА №2: РАСХОЖДЕНИЕ — правильно: «Python»; основание: «Python» (Раздел 6)\n"
                + "НАХОДКА №3: ПОДТВЕРЖДАЮ — совпадает";
        var node = graphWithDonor(rules, agent).getNodeMap().get("t1");
        node.getInput().add("[{\"значение\": \"с 17.03.2025 по 17.09.2025\"}, {\"значение\": \"Java\"}, {\"значение\": \"x\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);
        assertTrue(result.contains("ПОДТВЕРЖДАЮ — значение совпадает (агент указал то же: с 17.03.2025 по 17.09.2025); основание: «за последние 6 месяцев» (Раздел 6)"), result);
        assertTrue(result.contains("РАСХОЖДЕНИЕ — правильно: «Python»"), result);
        assertTrue(result.contains("ПОДТВЕРЖДАЮ — совпадает"), result);
        assertEquals("РАСХОЖДЕНИЕ — правильно: «2»", ScenarioExecutorTransformNode.reconcileAgentText("РАСХОЖДЕНИЕ — правильно: «2»", null));
        assertEquals("РАСХОЖДЕНИЕ — без значения", ScenarioExecutorTransformNode.reconcileAgentText("РАСХОЖДЕНИЕ — без значения", "2"));
    }

    @Test
    void setFieldOnlyEmptyKeepsExistingValuesAndRemoveFieldsDropsKeys() {
        String rules = "{\"операции\": [{\"оп\": \"установить_поле\", \"поле\": \"к21\", \"значение\": \"НЕ ПРОВЕРЕНО — агент не ответил\", "
                + "\"если_поле\": \"к15\", \"шаблон\": \"не найден\", \"только_пустые\": \"true\"}, "
                + "{\"оп\": \"удалить_поля\", \"поля\": \"исходная_строка, к2\"}]}";
        var node = graph(rules).getNodeMap().get("t1");
        node.getInput().add("[{\"к2\": \"x\", \"к15\": \"акт/УПД не найден\", \"к21\": \"ПОДТВЕРЖДАЮ — верно\", \"исходная_строка\": \"a | b\"}, "
                + "{\"к2\": \"y\", \"к15\": \"акт/УПД не найден\", \"исходная_строка\": \"c | d\"}, {\"к15\": \"зачтено\"}, "
                + "{\"к2\": null, \"к15\": \"технология не найдена\", \"к21\": null}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);
        assertTrue(result.contains("ПОДТВЕРЖДАЮ — верно"), result);
        // null в поле — пусто: запасной текст ставится и туда
        assertEquals(2, result.split("НЕ ПРОВЕРЕНО — агент не ответил", -1).length - 1, result);
        assertFalse(result.contains("исходная_строка"), result);
        assertFalse(result.contains("\"к2\""), result);
    }

    @Test
    void arrayOpsSkipForeignBracketsBeforeTheArray() {
        // перед массивом — текст блока квалификационных требований с таблицей документации «[ < … > ]»
        String junk = "=== РЕЗУЛЬТАТ ОТ \"Блок\" ===\nИные квалификационные требования\n\n[ < Наличие опыта | Подтверждается > ]\n\n";
        String array = "[{\"критерий\": \"Технология 1\", \"значение\": \"Java\", \"источник\": \"Раздел 6\", \"секция\": \"ЛОТ №1\"}]";
        var check = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\", \"поле\": \"значение\", \"мин_длина\": \"4\"}]}");
        check.getNodeMap().get("t1").getInput().add(junk + array);
        String verified = new ScenarioExecutorTransformNode(check.getNodeMap().get("t1")).execute(sink);
        assertTrue(verified.contains("\"достоверность\""));
        assertFalse(verified.contains("Наличие опыта"));

        var drop = graph("{\"операции\": [{\"оп\": \"удалить_объекты\", \"поле\": \"значение\", \"шаблон\": \"^Python$\"}]}");
        drop.getNodeMap().get("t1").getInput().add(junk + array);
        assertTrue(new ScenarioExecutorTransformNode(drop.getNodeMap().get("t1")).execute(sink).contains("Java"));

        String rules = "{\"операции\": [{\"оп\": \"установить_поле\", \"поле\": \"значение\", \"значение\": \"нет\", "
                + "\"если_поле\": \"секция\", \"шаблон\": \"ЛОТ\", \"значение_из_узла\": \"Способ закупки\", \"кроме_значений\": \"\\\\S\"}]}";
        var skip = graphWithDonor(rules, "блок не пуст");
        skip.getNodeMap().get("t1").getInput().add(junk + array);
        String kept = new ScenarioExecutorTransformNode(skip.getNodeMap().get("t1")).execute(sink);
        assertTrue(kept.contains("Java"));
        assertFalse(kept.contains("Наличие опыта"));
    }

    @Test
    void setFieldTakesValueFromDonorNodeUnlessExcluded() {
        // способ закупки в строке паспорта подставляется из узла-донора; при «не найдено» строка не трогается
        String rules = "{\"операции\": [{\"оп\": \"установить_поле\", \"поле\": \"з2\", "
                + "\"значение\": \"Способ закупки: \", \"значение_из_узла\": \"Способ закупки\", "
                + "\"кроме_значений\": \"не найдено\", \"если_поле\": \"з2\", \"шаблон\": \"^Способ закупки:\"}]}";
        var graph = graphWithDonor(rules, "Адресный запрос предложений [источник: ПЗ.docx]");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("[{\"з1\": \"—\", \"з2\": \"Способ закупки: закупка у ЕП\", \"з4\": \"ПАСПОРТ\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Способ закупки: Адресный запрос предложений [источник: ПЗ.docx]"));
        assertFalse(result.contains("закупка у ЕП"));

        var graph2 = graphWithDonor(rules, "не найдено");
        var node2 = graph2.getNodeMap().get("t1");
        node2.getInput().add("[{\"з1\": \"—\", \"з2\": \"Способ закупки: закупка у ЕП\", \"з4\": \"ПАСПОРТ\"}]");

        assertTrue(new ScenarioExecutorTransformNode(node2).execute(sink).contains("закупка у ЕП"));
    }

    @Test
    void mergeDedupStripsRegexBeforeComparing() {
        // одно требование из ПЗ и из формы документации («… (форма 4 Раздела 4)») схлопывается в одну строку
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\", \"дедуп_по\": [\"з2\"], "
                + "\"дедуп_регекс\": \"\\\\s*\\\\([^)]*\\\\)\\\\s*$\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"з1": "1", "з2": "Требование эксклюзивности к участникам закупки"},
                 {"з1": "10", "з2": "Требование эксклюзивности к участникам закупки (форма 4 Раздела 4)"},
                 {"з1": "2", "з2": "Требование к опыту работы на рынке"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertFalse(result.contains("форма 4 Раздела 4"));
        assertTrue(result.contains("Требование к опыту работы на рынке"));
    }

    @Test
    void verifyCitationsIgnoresExplanationAfterQuotedCore() {
        // находка кодовой проверки процентов: цитата в «…» + пояснение «, но 1% от базы = …» — подтверждается по ядру
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(List.of("Размер обеспечения договора составляет – не более 1% от начальной (максимальной) "
                + "цены договора – 2500000,00 рублей."), List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "расхождение процента и суммы",
                  "цитата": "«обеспечения … 1% … 2500000,00», но 1% от базы = 17707193.75 руб. — расхождение, проверить"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("по фрагментам"));
    }

    @Test
    void verifyCitationsAcceptsEllipsisFragmentsInOrder() {
        // составная цитата кодовой проверки процентов подтверждается по фрагментам, обратный порядок — нет
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(List.of("Размер обеспечения договора составляет – не более 1% от начальной (максимальной) "
                + "цены договора – 2500000,00 рублей."), List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "проценты", "цитата": "«обеспечения … 1% … 2500000,00»"},
                 {"номер": 2, "тип": "проценты", "цитата": "2500000,00 … обеспечения … 1%"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("по фрагментам"));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void verifyCitationsIgnoresSpacingBetweenDigitsAndUnits() {
        // в документе «289523339,14руб.» без пробела, в цитате судьи «289523339,14 руб.» — это одна и та же фраза
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(List.of("Итоговая сумма закупки составит: не более 289523339,14руб., с учётом НДС."), List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("[{\"номер\": 1, \"тип\": \"суммы\", \"цитата\": \"не более 289523339,14 руб.\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("точно"));
        assertFalse(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void normFromBaseFillsFieldByRequisite() {
        var graph = graph("{\"операции\": [{\"оп\": \"норма_из_базы\", \"реквизит_из\": \"з9\", \"поле\": \"з10\", "
                + "\"база\": \"11111111-1111-1111-1111-111111111111\", \"макс_символов\": 120}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("[{\"з1\": \"1\", \"з9\": \"п. 2 ч. 1 ст. 3 223-ФЗ (равноправие); ст. 164 НК РФ\"}, {\"з1\": \"2\", \"з9\": \"—\"}]");
        var executor = new ScenarioExecutorTransformNode(node);
        executor.setNormIndexLoader(id -> NormIndex.build(Map.of(
                "223-ФЗ статья 3 Принципы.txt", "Статья 3.\n1. Принципы:\n1) открытость;\n2) равноправие, справедливость;\n2. Иное.",
                "НК РФ статья 164 Налоговые ставки.txt", "Статья 164. Налоговые ставки\n1. Налогообложение производится по ставке 0 процентов.")));

        String result = executor.execute(sink);

        assertTrue(result.contains("п. 2 ч. 1 ст. 3 223-ФЗ (равноправие): «1. Принципы: 2) равноправие, справедливость"));
        assertTrue(result.contains("справедливость;» [223-ФЗ статья 3 Принципы] | ст. 164 НК РФ: «Статья 164. Налоговые ставки 1. Налогообложение производится по ставке 0 процентов.» [НК РФ статья 164 Налоговые ставки]"));
        assertFalse(result.contains("открытость"));
        assertFalse(result.contains("\"з1\" : \"2\",\n  \"з9\" : \"—\",\n  \"з10\""));
    }

    @Test
    void runOperationExecutesCheckAndReportsErrorsAsText() {
        var graph = graph("{\"операции\": []}");
        graph.addDocs(List.of("Пояснительная. НМЦД составляет 289523339,14 руб.", "Обоснование. НМЦД: 349669037,34 руб."),
                List.of("ПЗ.docx", "Обоснование.docx"));
        var executor = new ScenarioExecutorTransformNode(graph.getNodeMap().get("t1"));

        String amounts = executor.runOperation("сверить_суммы", Map.of("метка", "НМЦД?"), "");
        String quote = executor.runOperation("проверить_цитаты", Map.of("поле", "цитата"),
                "[{\"цитата\": \"НМЦД составляет 289523339,14 руб.\"}]");
        String unknown = executor.runOperation("нет_такой", Map.of(), "");

        assertTrue(amounts.contains("Различных значений: 2"));
        assertTrue(quote.contains("\"точно\"") && quote.contains("ПЗ.docx"));
        assertTrue(unknown.startsWith("ОШИБКА:"));
    }

    @Test
    void attachByNumberJoinsAgentLinesToFindings() {
        var donor = NodeDto.builder().id("a1").type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Агент нормы 223-ФЗ").build()).position(new PositionDto(0, 0)).build();
        var t1 = NodeDto.builder().id("t1").type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Трансформация").rules("{\"операции\": [{\"оп\": \"прикрепить_по_номеру\", "
                        + "\"из_узла\": \"Агент нормы 223-ФЗ\", \"поле\": \"норма_агент\"}]}").build())
                .position(new PositionDto(0, 0)).build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(donor, t1), List.of()));
        graph.setRunnerUserId("user-1");
        graph.getNodeMap().get("a1").getOutput().add("НАХОДКА №1: п. 2 ч. 1 ст. 3 223-ФЗ: «равноправие» — применимо\n"
                + "НАХОДКА №3: ст. 164 НК РФ (цитата в базе не найдена)\nНАХОДКА №1: дубль игнорируется");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("[{\"номер\": 1, \"тип\": \"участники\"}, {\"номер\": 2, \"тип\": \"НМЦД\"}, {\"номер\": 3, \"тип\": \"НДС\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"норма_агент\" : \"п. 2 ч. 1 ст. 3 223-ФЗ: «равноправие» — применимо\""));
        assertTrue(result.contains("\"норма_агент\" : \"ст. 164 НК РФ (цитата в базе не найдена)\""));
        assertEquals(2, result.split("норма_агент").length - 1);
    }

    @Test
    void numberObjectsAssignsPositionsFromOne() {
        // номера строк свода проставляются кодом по позиции в массиве, прежнее значение перезаписывается
        var graph = graph("{\"операции\": [{\"оп\": \"нумеровать\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"№": "9", "критерий": "Количество лотов закупки", "значение": "2"},
                 {"критерий": "ЛОТ №1 (Квалификационные требования)", "значение": ""},
                 {"критерий": "Технология 1", "значение": "Java"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"№\" : \"1\""));
        assertTrue(result.contains("\"№\" : \"2\""));
        assertTrue(result.contains("\"№\" : \"3\""));
        assertFalse(result.contains("\"№\" : \"9\""));
        assertEquals(3, result.split("\"№\" : ", -1).length - 1);

        // своё имя поля
        var graph2 = graph("{\"операции\": [{\"оп\": \"нумеровать\", \"поле\": \"з1\"}]}");
        var node2 = graph2.getNodeMap().get("t1");
        node2.getInput().add("[{\"з1\": \"—\", \"з2\": \"Способ закупки: конкурс\"}, {\"з1\": \"—\", \"з2\": \"Риск\"}]");

        String result2 = new ScenarioExecutorTransformNode(node2).execute(sink);

        assertTrue(result2.contains("\"з1\" : \"1\""));
        assertTrue(result2.contains("\"з1\" : \"2\""));
        assertFalse(result2.contains("\"з1\" : \"—\""));
    }

    @Test
    void checkSectionsReportsMissingLotsAgainstDonor() {
        // донор перечисляет лоты 1..3, заголовки квалифов есть только у лотов 1 и 03 — код фиксирует нехватку лота 2
        String rules = "{\"операции\": [{\"оп\": \"проверить_секции\", "
                + "\"шаблон_секции\": \"^ЛОТ\\\\s*№\\\\s*(\\\\d+)\\\\s*\\\\(Квалификационн\", "
                + "\"ожидаемо_из_узла\": \"Способ закупки\"}]}";
        var graph = graphWithDonor(rules, "1\n2\n3");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"критерий": "Количество лотов закупки", "значение": "3", "источник": "п. 9"},
                 {"критерий": "ЛОТ №1 (Квалификационные требования)", "значение": "", "источник": ""},
                 {"критерий": "Технология 1", "значение": "Java", "источник": "Раздел 6"},
                 {"критерий": "ЛОТ №1 (Методические требования)", "значение": "", "источник": ""},
                 {"критерий": "ЛОТ № 03 (Квалификационные требования)", "значение": "", "источник": ""}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"критерий\" : \"Проверка полноты лотов (код)\""));
        assertTrue(result.contains("\"значение\" : \"извлечено 2 из 3\""));
        assertTrue(result.contains("не извлечены лоты: 2"));
        assertTrue(result.contains("\"достоверность\" : \"проверка кодом\""));
        // строка проверки добавлена в конец, исходные строки не тронуты
        assertEquals(6, result.split("\"критерий\" : ", -1).length - 1);
        assertTrue(result.lastIndexOf("Проверка полноты") > result.lastIndexOf("ЛОТ № 03"));
    }

    @Test
    void checkSectionsConfirmsCompleteExtractionFromJsonDonor() {
        // все лоты донора (JSON-массив строк) имеют заголовок — «полно», своё имя критерия
        String rules = "{\"операции\": [{\"оп\": \"проверить_секции\", "
                + "\"шаблон_секции\": \"^ЛОТ\\\\s*№\\\\s*(\\\\d+)\", \"критерий_проверки\": \"Полнота лотов\", "
                + "\"ожидаемо_из_узла\": \"Способ закупки\"}]}";
        var graph = graphWithDonor(rules, "[\"1\", \"2\"]");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"критерий": "ЛОТ №1 (Квалификационные требования)", "значение": "", "источник": ""},
                 {"критерий": "Технология 1", "значение": "Java", "источник": "Раздел 6"},
                 {"критерий": "ЛОТ №2 (Квалификационные требования)", "значение": "", "источник": ""}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"критерий\" : \"Полнота лотов\""));
        assertTrue(result.contains("\"значение\" : \"извлечено 2 из 2 — полно\""));
        assertTrue(result.contains("\"источник\" : \"лоты: 1, 2\""));
    }

    @Test
    void checkSectionsReportsExtraSectionsAndUnknownDonor() {
        // секций больше, чем лотов у донора — «лишние секции»; без донора — ожидаемое число неизвестно
        String rules = "{\"операции\": [{\"оп\": \"проверить_секции\", "
                + "\"шаблон_секции\": \"^ЛОТ\\\\s*№\\\\s*(\\\\d+)\", \"ожидаемо_из_узла\": \"Способ закупки\"}]}";
        String rows = "[{\"критерий\": \"ЛОТ №1 (Квалификационные требования)\", \"значение\": \"\"}, "
                + "{\"критерий\": \"ЛОТ №2 (Квалификационные требования)\", \"значение\": \"\"}]";
        var graph = graphWithDonor(rules, "1");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add(rows);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // M — найденные ожидаемые лоты (один), вторая секция — лишняя
        assertTrue(result.contains("\"значение\" : \"извлечено 1 из 1\""), result);
        assertTrue(result.contains("лишние секции: 2"));

        var graph2 = graph(rules);
        var node2 = graph2.getNodeMap().get("t1");
        node2.getInput().add(rows);

        String result2 = new ScenarioExecutorTransformNode(node2).execute(sink);

        assertTrue(result2.contains("ожидаемое число лотов неизвестно"));
        assertTrue(result2.contains("не найден"));
        assertTrue(result2.contains("найдено секций: 2 (1, 2)"));
    }

    @Test
    void rublesFromPercentFillsLotThresholdFromNmcd() {
        // Комплект 5: у лота 2 модель написала «Нет» при «100% от НМЦД» — код считает из «НМЦД лота №2» общего блока
        String rules = "{\"операции\": [{\"оп\": \"рубли_из_процента\", \"секция_шаблон\": \"^ЛОТ\\\\s*№\\\\s*(\\\\d+)\"}]}";
        var node = graph(rules).getNodeMap().get("t1");
        node.getInput().add("[{\"критерий\": \"НМЦД лота №2\", \"значение\": \"43553218,80 руб.\", \"источник\": \"РАЗДЕЛ 1, пункт 10\", "
                + "\"секция\": \"Общая информация по закупке для всех лотов\"}, "
                + "{\"критерий\": \"Минимальный объём сопоставимого опыта (процент)\", \"значение\": \"100% от НМЦД\", "
                + "\"секция\": \"ЛОТ №2 (Квалификационные требования)\"}, "
                + "{\"критерий\": \"Минимальный объём сопоставимого опыта (в рублях)\", \"значение\": \"Нет\", "
                + "\"секция\": \"ЛОТ №2 (Квалификационные требования)\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"значение\" : \"43553218,80 руб.\""), result);
        assertTrue(result.contains("расчёт кодом: 100% от НМЦД лота №2 (РАЗДЕЛ 1, пункт 10)"), result);
        assertTrue(result.contains("\"достоверность\" : \"рассчитано кодом\""), result);
    }

    @Test
    void monthsFromDatesRebuildsAbbreviatedList() {
        // Приложение 3 (45 месяцев): «01.2021, 02.2021, ..., 09.2024» — код строит перечень из «календарные даты»
        String rules = "{\"операции\": [{\"оп\": \"месяцы_из_дат\"}]}";
        var node = graph(rules).getNodeMap().get("t1");
        node.getInput().add("[{\"критерий\": \"Период опыта по методике оценки — календарные даты\", \"значение\": \"с 01.01.2021 по 09.09.2024\"}, "
                + "{\"критерий\": \"Период опыта по методике оценки — допустимые месяцы\", \"значение\": \"01.2021, 02.2021, ..., 09.2024\"}]");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("01.2021, 02.2021, 03.2021, 04.2021"), result);
        assertTrue(result.contains("07.2024, 08.2024, 09.2024\""), result);
        assertFalse(result.contains("..."), result);
        assertTrue(result.contains("\"достоверность\" : \"рассчитано кодом\""), result);
    }
}
