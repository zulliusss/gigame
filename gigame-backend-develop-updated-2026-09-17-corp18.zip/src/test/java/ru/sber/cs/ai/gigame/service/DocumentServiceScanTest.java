package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты постраничного детектора скана: страница-штамп ЭДО с текстом подписей
 * не должна скрывать скан, а текстовый документ не должен уходить в OCR —
 * в том числе из-за пустых страниц без изображений.
 */
class DocumentServiceScanTest {

    private static final String LONG_TEXT = "Document signed and transferred via EDO operator, registration number 12345";
    private final DocumentService service = new DocumentService(null, null, null);

    private static byte[] pdf(String... pages) throws IOException {
        return TestPdf.of(pages);
    }

    @Test
    void textDocumentIsNotScan() throws IOException {
        assertFalse(service.isScanPdf(pdf(LONG_TEXT, LONG_TEXT), LONG_TEXT + "\n" + LONG_TEXT));
    }

    @Test
    void scanWithEdoStampPageIsScan() throws IOException {
        // две страницы-картинки акта и страница-штамп с текстом подписей: текст выше порога, но это скан
        assertTrue(service.isScanPdf(pdf(TestPdf.IMAGE, TestPdf.IMAGE, LONG_TEXT), LONG_TEXT));
    }

    @Test
    void blankPagesWithoutImagesAreNotScan() throws IOException {
        // договор p8 (16.09.2026): пустая страница машиночитаемого документа отправляла его в OCR
        byte[] withBlankPages = pdf(LONG_TEXT, TestPdf.BLANK, TestPdf.BLANK);

        assertFalse(service.isScanPdf(withBlankPages, LONG_TEXT));
        assertEquals(List.of(), service.textlessPages(withBlankPages));
    }

    @Test
    void imagePagesAreFoundInResourcesFormsAndInlineImages() throws IOException {
        byte[] content = pdf(LONG_TEXT, TestPdf.IMAGE, TestPdf.BLANK, TestPdf.FORM_IMAGE, TestPdf.INLINE_IMAGE, TestPdf.SELF_FORM);

        assertEquals(List.of(2, 4, 5), service.textlessPages(content));
        assertTrue(service.isScanPdf(content, LONG_TEXT));
        assertTrue(service.textlessPages("not a pdf".getBytes()).isEmpty());
    }

    @Test
    void shortTextIsScanWithoutPageCheck() {
        assertTrue(service.isScanPdf(new byte[0], "  \n "));
    }

    @Test
    void unreadablePdfWithLongTextIsNotScan() {
        assertFalse(service.isScanPdf("not a pdf".getBytes(), LONG_TEXT));
    }

    @Test
    void recognizedTextKeepsParsedStamp() {
        assertEquals("[РАСПОЗНАНО] акт\n\nштамп ЭДО", DocumentService.withParsed("[РАСПОЗНАНО] акт", " штамп ЭДО \n"));
        assertEquals("[РАСПОЗНАНО] акт", DocumentService.withParsed("[РАСПОЗНАНО] акт", "  "));
    }
}
