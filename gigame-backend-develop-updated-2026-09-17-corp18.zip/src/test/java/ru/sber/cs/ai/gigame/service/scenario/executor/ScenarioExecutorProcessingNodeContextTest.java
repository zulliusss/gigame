package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.AgentContextOverflowException;
import ru.sber.cs.ai.gigame.service.AgentContextBudget;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Задание и финал агента в пределах бюджета контекста модели: выходы, подставленные через {@code {{output:…}}}, не
 * дублируются блоком результатов предыдущих шагов, подстановки и блок усекаются долей бюджета с пометкой, переполнение
 * контекста в tool-цикле — финальный ответ без инструментов с пометкой в результате.
 */
class ScenarioExecutorProcessingNodeContextTest {

    private static final String OVERFLOW_PREFIX = "Контекст агента усечён по лимиту модели (запрос 142410 токенов при максимуме "
            + "130048) — результат может быть неполным\n\n";

    private GigaChatClient gigaChatClient;
    private EmbeddingService embeddingService;
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    @BeforeEach
    void setUp() {
        gigaChatClient = mock(GigaChatClient.class);
        embeddingService = mock(EmbeddingService.class);
    }

    @Test
    void outputSubstitutedSourcesAreNotRepeatedInContextBlock() {
        stubAgentAnswer("отчёт");
        var graph = agentGraph("Проверь находки:\n{{output:Находки s9}}\nКонец инструкции.", "agent_review");
        graph.getNodeMap().get("s9").getOutput().add("НАХОДКА-S9");
        var node = graph.getNodeMap().get("h3");
        node.addInputs("s9", List.of("=== РЕЗУЛЬТАТ ОТ \"Находки s9\" ===\nНАХОДКА-S9"));
        node.addInputs("r4", List.of("=== РЕЗУЛЬТАТ ОТ \"r4\" ===\nБЛОК-R4"));

        executor(node).execute(sink);

        String task = toolLoopTask();
        assertEquals(1, task.split("НАХОДКА-S9", -1).length - 1, task);
        assertTrue(task.contains("Конец инструкции.\n\n=== РЕЗУЛЬТАТЫ ПРЕДЫДУЩИХ ШАГОВ (контекст) ===\n"
                + "=== РЕЗУЛЬТАТ ОТ \"r4\" ===\nБЛОК-R4"), task);
        assertEquals(List.of("=== РЕЗУЛЬТАТ ОТ \"r4\" ===\nБЛОК-R4"), node.getInputExcluding(Set.of("s9")));
        // {{json:…}} подставляет только поле — вклад узла остаётся в блоке
        assertEquals(Set.of("s9"), ExpressionResolver.outputSources("{{output:Находки s9}} {{json:r4:поле}} {{output:нет}}",
                graph.getNodeMap()));
    }

    @Test
    void substitutionsAreCutToTaskBudgetKeepingInstruction() {
        stubAgentAnswer("отчёт");
        var graph = agentGraph("Инструкция {{output:Находки s9}} хвост инструкции", "agent_review");
        graph.getNodeMap().get("s9").getOutput().add("Б".repeat(5000));
        var node = graph.getNodeMap().get("h3");
        node.addInputs("s9", List.of("Б".repeat(5000)));
        var executor = executor(node);
        // бюджет 1000 символов, на задание — 600; инструкция вне выражения — 28 символов
        executor.setAgentContextBudget(new AgentContextBudget(1000, 1.0));

        executor.execute(sink);

        String task = toolLoopTask();
        assertEquals("Инструкция " + "Б".repeat(572) + ExpressionResolver.TRUNCATED_MARKER + " хвост инструкции", task);
        assertTrue(details().contains("⚠ текст подстановок выражений в задании агента обрезан: 572 из 5000 символов"), details().toString());
    }

    @Test
    void contextBlockGetsRemainderOfTaskBudget() {
        stubAgentAnswer("отчёт");
        var graph = agentGraph("Сверь данные.", "agent_review");
        var node = graph.getNodeMap().get("h3");
        node.addInputs("r4", List.of("Ж".repeat(2000)));
        var executor = executor(node);
        executor.setAgentContextBudget(new AgentContextBudget(1000, 1.0));

        executor.execute(sink);

        assertEquals("Сверь данные.\n\n=== РЕЗУЛЬТАТЫ ПРЕДЫДУЩИХ ШАГОВ (контекст) ===\n" + "Ж".repeat(587) + "\n[... обрезано ...]",
                toolLoopTask());
        assertTrue(details().contains("⚠ результат предыдущих шагов в задании агента обрезан: 587 из 2000 символов"), details().toString());
    }

    @Test
    void contextOverflowGivesFinalAnswerWithoutToolsWithPrefix() {
        // ревизору план не строится: ReWOO-запросы и финальный ответ без инструментов
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[]").thenReturn("ответ по наблюдениям");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any())).thenThrow(overflow());
        var graph = agentGraph("Сверь данные.", "agent_review");
        var node = graph.getNodeMap().get("h3");
        node.addInputs("r4", List.of("вход"));

        String result = executor(node).execute(sink);

        assertEquals(OVERFLOW_PREFIX + "ответ по наблюдениям", result);
        verify(gigaChatClient, times(1)).chatCompletionWithTools(anyList(), anyList(), any(), any());
        String finalPrompt = plainPrompts(2).get(1);
        assertTrue(finalPrompt.startsWith("Сверь данные.\n\n=== РЕЗУЛЬТАТЫ ПРЕДЫДУЩИХ ШАГОВ (контекст) ===\nвход"), finalPrompt);
        assertTrue(finalPrompt.contains("\n\n=== ДАННЫЕ, СОБРАННЫЕ ИЗ ДОКУМЕНТОВ ===\n"), finalPrompt);
        assertTrue(finalPrompt.contains("Инструменты недоступны: контекст превысил лимит модели."), finalPrompt);
        assertTrue(details().contains("✂ контекст агента больше окна модели (запрос 142410 токенов при максимуме 130048) — "
                + "финальный ответ без инструментов по собранным наблюдениям"), details().toString());
    }

    @Test
    void finalAnswerWithoutToolsCutsTaskToBudgetInNotebookMode() {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn("[\"Пункт\"]").thenReturn("[]").thenReturn("ответ без тетради");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any())).thenThrow(overflow());
        var graph = agentGraph("Задание: " + "з".repeat(100), "agent");
        var node = graph.getNodeMap().get("h3");
        node.addInputs("r4", List.of("вход"));
        var executor = executor(node);
        executor.setAgentContextBudget(new AgentContextBudget(100, 1.0));

        String result = executor.execute(sink);

        assertTrue(result.startsWith(OVERFLOW_PREFIX), result);
        String finalPrompt = plainPrompts(4).get(2);
        assertTrue(finalPrompt.startsWith("Задание: " + "з".repeat(51) + "\n[... задание усечено по бюджету контекста агента ...]"),
                finalPrompt);
    }

    @Test
    void factoryPassesAgentContextSettingsToProcessingNode() {
        @SuppressWarnings("unchecked")
        var factory = new ScenarioExecutorFactory(gigaChatClient, embeddingService,
                mock(ObjectProvider.class), mock(ObjectProvider.class), mock(ObjectProvider.class));
        ReflectionTestUtils.setField(factory, "agentMaxContextTokens", 1000);
        ReflectionTestUtils.setField(factory, "agentCharsPerToken", 2.0);

        var executor = factory.createExecutor(agentGraph("задание", "agent").getNodeMap().get("h3"));

        var budget = (AgentContextBudget) ReflectionTestUtils.getField(executor, "contextBudget");
        assertEquals(2000, budget.maxChars());
        assertEquals(1200, budget.taskChars());
    }

    @Test
    void fairCapLetsShortValuesInWhole() {
        assertEquals(390, ExpressionResolver.fairCap(List.of("a".repeat(10), "b".repeat(1000), "c".repeat(100)), 500));
        assertEquals(Integer.MAX_VALUE, ExpressionResolver.fairCap(List.of("a", "b"), 10));
        assertEquals(0, ExpressionResolver.fairCap(List.of("a"), 0));
    }

    @Test
    void kbFragmentsSummaryListsKnowledgeBaseChunksWithinLimit() {
        var tools = new AgentDocumentTools(List.of(new AgentDocumentTools.DocEntry("a.txt", "текст")),
                query -> List.of("Статья 5. Норма " + "н".repeat(200)));
        assertEquals("", tools.kbFragmentsSummary(1000));

        tools.searchKnowledgeBase(new AgentDocumentTools.KbSearchRequest("норма"));

        assertTrue(tools.kbFragmentsSummary(1000).startsWith("[база знаний: норма #1]\nСтатья 5. Норма нн"));
        String cut = tools.kbFragmentsSummary(50);
        assertEquals(50, cut.length());
        assertTrue(cut.endsWith("…"), cut);
    }

    private void stubAgentAnswer(String answer) {
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("[\"Пункт\"]").thenReturn("[]");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(answer, Map.of()));
    }

    private static AgentContextOverflowException overflow() {
        return new AgentContextOverflowException(142410, 130048, new RuntimeException(
                "HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 142410, maximum allowed context is 130048\"}"));
    }

    private ScenarioExecutorProcessingNode executor(ScenarioRunNode node) {
        var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
        executor.setDocCharLimit(200_000);
        return executor;
    }

    @SuppressWarnings("unchecked")
    private String toolLoopTask() {
        ArgumentCaptor<List<Map<String, String>>> messages = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, atLeastOnce()).chatCompletionWithTools(messages.capture(), anyList(), any(), any());
        return messages.getAllValues().get(0).get(1).get("content");
    }

    @SuppressWarnings("unchecked")
    private List<String> plainPrompts(int calls) {
        ArgumentCaptor<List<Map<String, String>>> messages = ArgumentCaptor.forClass(List.class);
        verify(gigaChatClient, times(calls)).chatCompletion(messages.capture(), any(), any());
        return messages.getAllValues().stream().map(m -> m.get(0).get("content")).toList();
    }

    @SuppressWarnings("unchecked")
    private List<String> details() {
        ArgumentCaptor<ServerSentEvent<Map<String, Object>>> captor = ArgumentCaptor.forClass(ServerSentEvent.class);
        verify(sink, atLeastOnce()).next(captor.capture());
        return captor.getAllValues().stream().map(ev -> String.valueOf(ev.data().get("detail"))).toList();
    }

    private static ScenarioRunGraph agentGraph(String prompt, String mode) {
        var graph = new ScenarioRunGraph(new GraphDataDto(
                List.of(node("s9", "Находки s9", "p", null), node("r4", "r4", "p", null), node("h3", "Агент h3", prompt, mode)),
                List.of(new EdgeDto("e1", "s9", "h3", new EdgeDataDto(null)), new EdgeDto("e2", "r4", "h3", new EdgeDataDto(null)))));
        graph.setRunnerUserId("user-1");
        return graph;
    }

    private static NodeDto node(String id, String label, String prompt, String mode) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label(label).prompt(prompt).mode(mode).build())
                .position(new PositionDto(0, 0))
                .build();
    }
}
