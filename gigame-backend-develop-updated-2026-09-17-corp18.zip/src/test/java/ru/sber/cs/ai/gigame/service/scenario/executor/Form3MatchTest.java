package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Тесты номера акта/УПД в реквизитах формы — граница правил 1 и 2 Егоровой (реальные реквизиты комплектов 1, 3, 6, 8, 9).
 */
class Form3MatchTest {

    @Test
    void signWithoutDigitsIsNotActNumber() {
        // «№ от», «№_ от» — знак номера без цифр: номер акта не указан, строка идёт по правилу 2
        assertEquals("", Form3Match.formNumber("Акт № от 08.04.2025"));
        assertEquals("", Form3Match.formNumber("Акт №_ от 08.04.2025"));
    }

    @Test
    void actNumberWithoutSignIsRecognizedButDateIsNot() {
        assertEquals("12", Form3Match.formNumber("Акт 12 от 30.06.2025"));
        assertEquals("", Form3Match.formNumber("Акт от 12.01.2026"));
    }

    @Test
    void orderContractAndZnzoNumbersAreNotActNumber() {
        // Комплект 3: номер заявки и договора в реквизитах акта — не номер акта
        assertEquals("", Form3Match.formNumber("Акт сдачи-приемки работ по Заявке №10 от 08.04.2024 г. к Договору № ШТ-2023 от 21.04.2023 г."));
        assertEquals("1", Form3Match.formNumber("АКТ №1 сдачи-приемки работ по Заявке №10 от 08.04.2024 г. к Договору № ШТ-2023 от 21.04.2023 г."));
        // Комплект 6: номер ЗНЗО отчёта после номера УПД
        assertEquals("101604", Form3Match.formNumber("УПД № 0000101604 от 14.04.2025 Отчет о выполненных работах к ЗНЗО № 100000037040."));
    }

    @Test
    void noNumberMarksAreRecognizedInAnySpelling() {
        assertEquals("", Form3Match.formNumber("б\\н от 10.06.2025 (Этап 1)"));
        assertEquals("", Form3Match.formNumber("Б/Н от 10.06.2025"));
        assertEquals("", Form3Match.formNumber("б/н от 24.03.2025"));
        assertEquals("", Form3Match.formNumber("б.н. от 24.03.2025"));
        assertEquals("104227011", Form3Match.formNumber("№ 104227011 от 20.06.2025 (Этап 1)"));
        assertEquals("328", Form3Match.formNumber("№ 328 от 31.03.2025"));
    }
}
