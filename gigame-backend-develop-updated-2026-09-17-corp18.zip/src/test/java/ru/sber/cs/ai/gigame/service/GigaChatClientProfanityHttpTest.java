package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatModel;
import chat.giga.springai.GigaChatOptions;
import chat.giga.springai.api.GigaChatApiProperties;
import chat.giga.springai.api.GigaChatInternalProperties;
import chat.giga.springai.api.auth.GigaChatApiScope;
import chat.giga.springai.api.auth.GigaChatAuthProperties;
import chat.giga.springai.api.auth.bearer.SimpleGigaAuthToken;
import chat.giga.springai.api.chat.GigaChatApi;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClient;
import org.springframework.web.reactive.function.client.WebClient;
import ru.sber.cs.ai.gigame.exception.GigaChatRefusedException;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Сквозная проверка на реальных {@link GigaChatModel} и {@link GigaChatApi} spring-ai-gigachat против фейкового
 * HTTP-сервера GigaChat: фильтр вызывается {@code POST /v1/filter/check} клиентом бина GigaChatApi (тот же токен),
 * в теле чата уходит {@code "profanity_check":false} после чистого входа и {@code true} при 404 фильтра, откат
 * настройками не шлёт ни поля, ни запросов к фильтру, finish_reason=blacklist распознаётся как отказ цензора.
 */
class GigaChatClientProfanityHttpTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final String TRIGGER = "Наличие инструкции о мерах пожарной безопасности, с учетом специфики "
            + "пожароопасных помещений в указанных зданиях, сооружениях.";

    private final List<String> chatBodies = new CopyOnWriteArrayList<>();
    private final List<String> filterBodies = new CopyOnWriteArrayList<>();
    private final List<String> filterAuth = new CopyOnWriteArrayList<>();
    private volatile int filterStatus = 200;
    private HttpServer server;
    private GigaChatApi api;
    private GigaFilterGuard guard;
    private GigaChatClient client;

    @BeforeEach
    void setUp() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/", this::handle);
        server.start();
        String base = "http://127.0.0.1:" + server.getAddress().getPort();
        GigaChatAuthProperties auth = new GigaChatAuthProperties();
        auth.setScope(GigaChatApiScope.GIGACHAT_API_CORP);
        auth.setUnsafeSsl(true);
        GigaChatAuthProperties.Bearer bearer = new GigaChatAuthProperties.Bearer();
        bearer.setUrl(base + "/oauth");
        bearer.setApiKey("ZmFrZTpmYWtl");
        auth.setBearer(bearer);
        GigaChatInternalProperties internal = new GigaChatInternalProperties();
        internal.setConnectTimeout(Duration.ofSeconds(5));
        internal.setReadTimeout(Duration.ofSeconds(30));
        api = new GigaChatApi(new GigaChatApiProperties(base + "/v1", auth, internal), new SimpleGigaAuthToken(auth.getApiKey()),
                RestClient.builder(), WebClient.builder(), new GigaChatResponseErrorHandler(), null, null);
        GigaChatModel model = GigaChatModel.builder().gigaChatApi(api)
                .defaultOptions(GigaChatOptions.builder().model("GigaChat-2-Max").temperature(0.7).build())
                .internalProperties(internal).build();
        @SuppressWarnings("unchecked")
        ObjectProvider<GigaChatApi> provider = Mockito.mock(ObjectProvider.class);
        Mockito.when(provider.getIfAvailable()).thenReturn(api);
        guard = new GigaFilterGuard(new GigaFilterTransport(provider));
        client = new GigaChatClient(model, Mockito.mock(EmbeddingModel.class), provider);
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 1);
        client.setProfanityGuard(guard);
    }

    @AfterEach
    void tearDown() {
        GigaChatClient.clearRunCancelCheck();
        server.stop(0);
    }

    @Test
    void cleanInputSendsProfanityCheckFalseAndFilterUsesSameToken() throws IOException {
        String text = client.chatCompletion(List.of(Map.of("role", "user", "content", "Срок оказания услуг: 45 дней.")));

        assertEquals("Срок: 45 календарных дней", text);
        assertEquals(1, chatBodies.size());
        assertTrue(chatBodies.get(0).contains("\"profanity_check\":false"), chatBodies.get(0));
        assertEquals(2, filterBodies.size(), "вход и ответ");
        JsonNode input = MAPPER.readTree(filterBodies.get(0));
        assertEquals("GigaFilter", input.get("model").asText());
        assertEquals("Срок оказания услуг: 45 дней.", input.get("messages").get(0).get("content").asText());
        assertEquals("{\"neuro\":true,\"blacklist\":true,\"whitelist\":true,\"unnormalized_history\":false,\"safety\":\"safe\"}",
                input.get("settings").toString());
        assertEquals("Срок: 45 календарных дней", MAPPER.readTree(filterBodies.get(1)).get("messages").get(0).get("content").asText());
        assertEquals(List.of("Bearer FAKE-TOKEN", "Bearer FAKE-TOKEN"), filterAuth);
        assertNotNull(GigaFilterTransport.restClientOf(api));
    }

    @Test
    void filterNotFoundKeepsCensorOnAndStopsCallingFilter() {
        filterStatus = 404;

        client.chatCompletion(List.of(Map.of("role", "user", "content", "Вопрос о закупке")));
        client.chatCompletion(List.of(Map.of("role", "user", "content", "Другой вопрос")));

        assertEquals(2, chatBodies.size());
        assertTrue(chatBodies.get(0).contains("\"profanity_check\":true"), chatBodies.get(0));
        assertTrue(chatBodies.get(1).contains("\"profanity_check\":true"), chatBodies.get(1));
        assertEquals(1, filterBodies.size(), "404 «No such model» — автомат открыт");
    }

    @Test
    void rollbackSettingsSendNoProfanityCheckAndNoFilterCalls() {
        ReflectionTestUtils.setField(guard, "input", false);
        ReflectionTestUtils.setField(guard, "output", false);
        ReflectionTestUtils.setField(guard, "agent", true);

        client.chatCompletion(List.of(Map.of("role", "user", "content", TRIGGER)), "GigaChat-2-Pro", 0.2);

        assertEquals(1, chatBodies.size());
        assertFalse(chatBodies.get(0).contains("profanity_check"), chatBodies.get(0));
        assertTrue(filterBodies.isEmpty());
    }

    @Test
    void blacklistFinishReasonFromApiIsCensorRefusalInNode() {
        ReflectionTestUtils.setField(guard, "input", false);
        ReflectionTestUtils.setField(guard, "output", false);
        GigaChatClient.setRunCancelCheck(() -> false);

        var e = assertThrows(GigaChatRefusedException.class, () -> client.chatCompletion(
                List.of(Map.of("role", "user", "content", "Выпиши дословно текст: " + TRIGGER)), null, null));

        assertTrue(chatBodies.get(0).contains("\"profanity_check\":false"), "input=false явно — цензор выключен");
        assertTrue(e.getMessage().contains("«Как и любая языковая модель, GigaChat не обладает собственным мнением"),
                e.getMessage());
    }

    private void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        int status = 200;
        String answer;
        if (path.endsWith("/oauth")) {
            answer = "{\"access_token\":\"FAKE-TOKEN\",\"expires_at\":" + (System.currentTimeMillis() + 1_800_000L) + "}";
        } else if (path.endsWith("/filter/check")) {
            filterBodies.add(body);
            filterAuth.add(String.valueOf(exchange.getRequestHeaders().getFirst("Authorization")));
            status = filterStatus;
            answer = status == 200 ? "{\"is_profane\":false,\"usage\":{\"filter_tokens\":12}}"
                    : "{\"status\":404,\"message\":\"No such model\"}";
        } else {
            chatBodies.add(body);
            answer = chatAnswer(body.contains("пожароопасных помещений"));
        }
        byte[] bytes = answer.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "application/json");
        exchange.getResponseHeaders().add("x-request-id", "req-" + chatBodies.size());
        exchange.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String chatAnswer(boolean refused) {
        String content = refused
                ? "Как и любая языковая модель, GigaChat не обладает собственным мнением и не транслирует мнение своих "
                        + "разработчиков. Во избежание неправильного толкования, разговоры на некоторые темы временно ограничены."
                : "Срок: 45 календарных дней";
        return "{\"choices\":[{\"message\":{\"role\":\"assistant\",\"content\":\"" + content + "\"},\"index\":0,"
                + "\"finish_reason\":\"" + (refused ? "blacklist" : "stop") + "\"}],\"created\":1,\"model\":\"GigaChat-2-Max:2.0\","
                + "\"object\":\"chat.completion\",\"usage\":{\"prompt_tokens\":10,\"completion_tokens\":5,\"total_tokens\":15}}";
    }
}
