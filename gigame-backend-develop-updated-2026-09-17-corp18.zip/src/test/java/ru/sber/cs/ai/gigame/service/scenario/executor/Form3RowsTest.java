package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты правил зачёта Формы 3: технологии по типам документов, мобильная
 * разработка, только тестирование, рейтинг заказчика, период методики.
 */
class Form3RowsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final String CONTRACT = """
            ДОГОВОР № 4652269 на разработку/модификацию программного обеспечения
            Дата подписания: 05.07.2023
            Исполнитель выполняет работы с использованием технологий Java, Python и методологии DevOps.
            """;

    private static final String REPORT = """
            ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ к ЗНЗО № 100000039435 от 10.06.2025
            Договор № 4652269 от 05.07.2023
            Выполнена разработка сервисов на Go (Golang). Сумма 1063178,54
            """;

    private static final String UPD_WITH_ZNZO = Form3OpsTest.UPD_SIGNED
            + "Наименование: работы по ЗНЗО № 100000039435 от 10.06.2025\n";

    private static final String SPEC_TESTING = """
            Спецификация на оказание услуг № 5374642 к Договору №4652269
            1. Предмет Спецификации: Исполнитель оказывает услуги по функциональному и регрессионному тестированию ППО «Карты».
            Стоимость 1063178,54 Подпись банка 26.06.2025 17:37:40
            """;

    private static final String SPEC_MOBILE = """
            Спецификация на разработку программного обеспечения № 5374642 к Договору №4652269
            1. Предмет Спецификации: Исполнитель выполняет работы по разработке мобильного приложения СберБанк Онлайн (iOS, Android) на Java.
            Стоимость 1063178,54 Подпись банка 26.06.2025 17:37:40
            """;

    private static final String FORM_LINE = "ООО \"Датафьюжн\" | ООО \"Датафьюжн\" | не применимо | нет | ПАО Сбербанк | не применимо"
            + " | ПАО Сбербанк | 4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025"
            + " | 30.06.2025 | да | нет | 2495000 | не применимо | не применимо | Раздел 5";

    /** Критерии комплекта 16.09.2026: периоды шире дат комплекта, требуемая технология — Hadoop. */
    private static final String CRITERIA_HADOOP = """
            Критерий | Значение | Источник | Найдено
            Период опыта участника по квалификационным требованиям — календарные даты | с 01.01.2024 по 31.12.2026 | расчёт | НЕ НАЙДЕНА
            Период опыта по методике оценки — календарные даты | с 01.01.2025 по 31.12.2026 | расчёт | НЕ НАЙДЕНА
            Признак «Мобильная разработка» | стоимость работ по всей спецификации/заказу не засчитывается | Раздел 6 | точно
            ЛОТ №1 (Квалификационные требования) | | |
            Технология 1 | Hadoop | Раздел 2 | точно
            """;

    /** Рамочный договор письма Егоровой «Ошибки с поиском технологий»: ставки ролей Hadoop, GreenPlum, Python. */
    private static final String CONTRACT_THREE = """
            ДОГОВОР № 4652269 на разработку/модификацию программного обеспечения
            Дата подписания: 05.07.2023
            Ставки: Главный разработчик Hadoop, Ведущий разработчик GreenPlum, Разработчик Python.
            """;

    /** Строка формы участника с реквизитами договора, спецификации, акта, датой подписания и суммой. */
    private static String formLine(String contract, String spec, String act, String date, String amount) {
        return FORM_LINE.replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                contract + " | " + spec + " | " + act + " | " + date).replace("2495000", amount);
    }

    @Test
    void formRowWithoutActNumberIsMatchedBySignDateAndAmount() throws Exception {
        // правило 2: строка «б/н от 24.03.2025» без номера — совпали дата подписания по штампу ЭДО (25.03) и сумма до копейки
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025.pdf", Form3OpsTest.UPD_NO_NUMBER)));
        String line = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025",
                "б/н от 24.03.2025", "25.03.2025", "3,400,940.77");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals("25.03.2025", row.get("к7"));
        assertEquals("3400940.77", row.get("к10"));
        assertEquals("3400940.77", row.get("к14"));
        assertEquals("-", row.get("к15"));
        assertEquals("да", row.get("т_Hadoop"));
        assertTrue(String.valueOf(row.get("к20")).contains("правило 2"), String.valueOf(row.get("к20")));
        // источник даты подписания документа — в аудите
        assertTrue(String.valueOf(row.get("к20")).contains("дата подписания — да (штамп ЭДО 25.03.2025), сумма — да"),
                String.valueOf(row.get("к20")));
        assertEquals("", row.get("агенту"));
    }

    @Test
    void rule2SignDateIsTakenOnlyFromFormColumn() throws Exception {
        // правило 2 не обходится подстановкой дат: графа «Дата подписания» пуста или «да» — дата из реквизитов акта
        // («Акт от 08.04.2025») признаком не становится, хотя у акта Сбера без штампа ЭДО дата документа та же
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("4787401 Акт Э2.docx", Form3ActsTest.SBER_ACT)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String base = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо", "Договор №4286515 от 09.09.2022 | Спецификация №4787401 от 17.11.2023")
                .replace("2495000", "1712787");
        String form = base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт от 08.04.2025 | ")
                + "\n" + base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт от 08.04.2025 | да");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, form, Form3FormTest.HEADER), List.class);

        for (Object item : rows) {
            Map<?, ?> row = (Map<?, ?>) item;
            assertEquals(Form3Rows.REASON_NO_DOCS, row.get("к15"), String.valueOf(row.get("к20")));
            assertEquals("0", row.get("к14"));
        }
    }

    @Test
    void formRowWithoutActNumberIsNotMatchedByActDateAndAmountAlone() throws Exception {
        // правило 2: дата акта из формы — не признак. Первая строка: в графе даты подписания дата акта (24.03), штамп ЭДО — 25.03;
        // вторая: дата подписания совпала, сумма отличается на копейки. Запасной ход «УПД по сумме и дате» строкам без номера не полагается
        // (допуск «любая подпись штампа» выключен: 24.03 — дата подписи исполнителя, см. rule2FirstStampSignatureIsToleranceForAgent)
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025.pdf", Form3OpsTest.UPD_NO_NUMBER)));
        String byActDate = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025",
                "б/н от 24.03.2025", "24.03.2025", "3,400,940.77");
        String bySignDate = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025",
                "б.н. от 24.03.2025", "25.03.2025", "3,400,940.00");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.BN_ANY_SIGNATURE, "false"), registry, CRITERIA_HADOOP,
                byActDate + "\n" + bySignDate, Form3FormTest.HEADER), List.class);

        for (Object item : rows) {
            Map<?, ?> row = (Map<?, ?>) item;
            assertEquals("0", row.get("к14"), String.valueOf(row.get("к20")));
            assertEquals(Form3Rows.REASON_NO_DOCS, row.get("к15"));
            assertEquals(Form3Rows.REASON_NO_DOCS, row.get("к18"));
            assertTrue(String.valueOf(row.get("к20")).contains("акт/УПД по номеру, сумме и дате не найден"), String.valueOf(row.get("к20")));
        }
        // почему не найден: у первой строки сумма совпала, а дата подписания нет — в аудите обе даты с источником
        assertTrue(String.valueOf(((Map<?, ?>) rows.get(0)).get("к20")).contains("сумма совпала, но дата подписания не совпала (правило 2: "
                + "дата подписания в форме 24.03.2025, документ — штамп ЭДО 25.03.2025)"), String.valueOf(((Map<?, ?>) rows.get(0)).get("к20")));
        assertTrue(!String.valueOf(((Map<?, ?>) rows.get(1)).get("к20")).contains("сумма совпала"), String.valueOf(((Map<?, ?>) rows.get(1)).get("к20")));
    }

    @Test
    void shortFormRowWithExactUpdNumberIsMatchedWithoutAmountAndSignDate() throws Exception {
        // короткая форма Комплекта 7: графы суммы и даты подписания — «не применимо»/«да», но номер УПД точный
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Опыт.zip/УПД 0000118724.pdf", Form3OpsTest.UPD_SIGNED)));
        String line = formLine("Договор № 4652269 от 05.07.2023", "Спец. №5281780 от 28.03.2025г.",
                "УПД №0000118724 от 21.07.2025г., Отчёт к УПД №0000118724", "да", "не применимо");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertTrue(String.valueOf(row.get("к6")).contains("0000118724"), String.valueOf(row.get("к6")));
        assertEquals("1063178.54", row.get("к10"));
        assertTrue(String.valueOf(row.get("к20")).contains("по точному номеру"), String.valueOf(row.get("к20")));
        assertTrue(!Form3Rows.REASON_NO_DOCS.equals(row.get("к15")), String.valueOf(row.get("к15")));
    }

    @Test
    void fullFormRowWithExactNumberButOtherAmountAndSignDateIsNotFound() throws Exception {
        // оговорка «точный номер достаточен» — только для короткой формы: в полной форме номер и дата УПД совпали,
        // а сумма (999999,99 против 1063178,54) и дата подписания (23.07 против приёмки 24.07) нет — 1 из 3, не найден
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Опыт.zip/УПД 0000118724.pdf", Form3OpsTest.UPD_SIGNED)));
        String line = formLine("Договор № 4652269 от 05.07.2023", "Спец. №5281780 от 28.03.2025г.",
                "УПД №0000118724 от 21.07.2025", "23.07.2025", "999999,99");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals(Form3Rows.REASON_NO_DOCS, row.get("к15"));
        assertTrue(String.valueOf(row.get("к20")).contains("точный номер совпал, но не совпали сумма и дата подписания (правило 1: "
                + "дата подписания в форме 23.07.2025, документ — дата приёмки УПД 24.07.2025, штампа нет; сумма формы 999999.99, "
                + "документ — 1063178.54)"), String.valueOf(row.get("к20")));
    }

    @Test
    void rowWhoseExactDocumentIsTakenByAnotherRowGetsNoFalseMismatchNote() throws Exception {
        // один УПД на две строки формы: первая строка забрала документ (3 из 3), у второй точный номер тот же, а сумма часть УПД —
        // в аудите не «сумма/дата подписания не совпали» (дата совпала), а «документ уже отнесён к другой строке формы»
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Опыт.zip/УПД 0000118724.pdf", Form3OpsTest.UPD_SIGNED)));
        String form = formLine("Договор № 4652269 от 05.07.2023", "не применимо", "УПД №0000118724 от 21.07.2025", "24.07.2025", "1063178,54")
                + "\n" + formLine("Договор № 4652269 от 05.07.2023", "не применимо", "УПД №0000118724 от 21.07.2025", "24.07.2025", "500000,00");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, form, Form3FormTest.HEADER), List.class);

        assertEquals("УПД 0000118724 от 21.07.2025", ((Map<?, ?>) rows.get(0)).get("к6"), String.valueOf(((Map<?, ?>) rows.get(0)).get("к20")));
        String audit = String.valueOf(((Map<?, ?>) rows.get(1)).get("к20"));
        assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) rows.get(1)).get("к15"), audit);
        assertTrue(audit.contains("документ «Опыт.zip/УПД 0000118724.pdf»: точный номер совпал, но документ уже отнесён к другой строке формы"),
                audit);
        assertTrue(!audit.contains("не совпал"), audit);
    }

    @Test
    void numberedRowRepeatingNumberOfAnotherRowExplainsMatchedDateAndAmount() throws Exception {
        // Комплект 6: у строк 1 и 2 один номер «УПД № 0000101604»; документ второй строки — УПД 0000118359 от 18.07.2025 на
        // 4 614 647,28 (дата УПД и сумма совпали, дата подписания в форме 15.07.2025, штамп ЭДО 21.07.2025) — 1 из 3, не найден,
        // в аудите — почему
        String upd = Form3OpsTest.UPD_SIGNED.replace("0000118724", "0000118359").replace("21.07.2025", "18.07.2025")
                .replace("1063178,54", "4614647,28") + "Документ подписан и передан через оператора ООО \"СберКорус\"\n"
                + "18.07.2025 10:12:40  Подпись соответствует файлу документа\n21.07.2025 09:05:11  Подпись соответствует файлу документа\n";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("ON_NSCHFDOPPR_2BK-7707083893-667102008-1027700132195_2BK-9709070357-"
                + "6766351_20250718_0_0.pdf", upd)));
        String form = formLine("Договор № 4652269 от 05.07.2023", "Спецификация 5287362 от 01.04.2025", "УПД № 0000101604 от 14.04.2025",
                "16.04.2025", "2100000,00") + "\n" + formLine("Договор № 4652269 от 05.07.2023", "Спецификация 5287362 от 01.04.2025",
                "УПД № 0000101604 от 18.07.2025  Отчет о выполненных работах к ЗНЗО № 100000037040 от 18.07.2025", "15.07.2025", "4614647,28");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, form, Form3FormTest.HEADER), List.class);

        String audit = String.valueOf(((Map<?, ?>) rows.get(1)).get("к20"));
        assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) rows.get(1)).get("к15"), audit);
        assertTrue(audit.contains("дата акта/УПД и сумма совпали, но номер в форме «101604» не совпал с номером документа «118359»; "
                + "номер повторяет строку 1 формы («УПД № 0000101604 от 14.04.2025») (правило 1: дата подписания в форме 15.07.2025, "
                + "документ — штамп ЭДО 21.07.2025)"), audit);
        assertTrue(!String.valueOf(((Map<?, ?>) rows.get(0)).get("к20")).contains("номер повторяет"));
    }

    @Test
    void numberedRowIsNotFoundByOneFeatureWithActDateOrSpecification() throws Exception {
        // правило 1 без запасных ходов «УПД по сумме и дате» / «акт по спецификации и сумме»: чужой номер при совпавших
        // сумме и дате УПД (дата подписания 23.07 против приёмки 24.07) и акт №77 с чужой датой при совпавших спецификации
        // и сумме — один признак из трёх, документ не найден
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Опыт.zip/УПД 0000118724.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("4787401 Акт Э2.docx", Form3ActsTest.SBER_ACT)));
        String upd = formLine("Договор № 4652269 от 05.07.2023", "не применимо", "УПД №999 от 21.07.2025", "23.07.2025", "1063178,54");
        String act = formLine("Договор №4286515 от 09.09.2022", "Спецификация №4787401 от 17.11.2023", "Акт №77 от 01.02.2025",
                "01.02.2025", "1712787");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, upd + "\n" + act, Form3FormTest.HEADER),
                List.class);

        for (Object item : rows) {
            assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) item).get("к15"), String.valueOf(((Map<?, ?>) item).get("к20")));
        }
    }

    @Test
    void fnsUpdIsFoundByRule1DirectlyAndFolderSpecificationGoesToFallbackForAgent() throws Exception {
        // Комплект 6: имя печатной формы УПД ФНС («…-6766351_2025071…») номера спецификации не содержит — документы находятся
        // правилом 1 напрямую, агенту не уходят. Два УПД с одной суммой: документ достаётся строке по правилу 1, а не «первый по
        // сумме и дате» (прежний ход менял их местами)
        String name = "ON_NSCHFDOPPR_2BK-7707083893-667102008-1027700132195_2BK-9709070357-6766351_2025071%s_0_0.pdf";
        String second = Form3OpsTest.UPD_SIGNED.replace("0000118724", "0000117729").replace("21.07.2025", "16.07.2025")
                .replace("\" 24 \" июля 2025", "\" 17 \" июля 2025").replace("1063178,54", "1538215,76") + "Разработка сервисов на Java\n";
        String first = Form3OpsTest.UPD_SIGNED.replace("0000118724", "0000118141").replace("21.07.2025", "17.07.2025")
                .replace("\" 24 \" июля 2025", "\" 23 \" июля 2025").replace("1063178,54", "1538215,76") + "Разработка сервисов на Java\n";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(String.format(name, "6"), second),
                new Form3Ops.Source(String.format(name, "7"), first)));
        String form = formLine("Договор № 4652269 от 05.07.2023", "Спецификация 5284130 от 27.03.2025",
                "УПД № 0000118141 от 17.07.2025", "23.07.2025", "1538215,76")
                + "\n" + formLine("Договор № 4652269 от 05.07.2023", "Спецификация 5283471 от 28.03.2025",
                "УПД № 0000117729 от 16.07.2025", "17.07.2025", "1538215,76");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form, Form3FormTest.HEADER), List.class);

        assertEquals("УПД 0000118141 от 17.07.2025", ((Map<?, ?>) rows.get(0)).get("к6"));
        assertEquals("УПД 0000117729 от 16.07.2025", ((Map<?, ?>) rows.get(1)).get("к6"));
        for (Object item : rows) {
            Map<?, ?> row = (Map<?, ?>) item;
            String audit = String.valueOf(row.get("к20"));
            assertEquals("1538215.76", row.get("к14"), audit);
            assertEquals("-", row.get("к15"));
            assertEquals("", row.get("агенту"), audit);
            assertTrue(audit.contains("правило 1: документ найден по признакам «2 из 3» (3 из 3)") && !audit.contains("запасной ход"), audit);
        }

        // папка чужой спецификации в пути к файлу: правило 1 выполнено, номер из пути не совпал — запасной ход с пометкой, агенту
        String folders = Form3Ops.registry(List.of(new Form3Ops.Source("комплект.zip/Договор 4652269/6766351/УПД 0000117729.pdf", second),
                new Form3Ops.Source("комплект.zip/Договор 4652269/6766351/УПД 0000118141.pdf", first)));
        List<?> fallback = MAPPER.readValue(Form3Ops.rows(Map.of(), folders, Form3OpsTest.CRITERIA, form, Form3FormTest.HEADER), List.class);
        for (Object item : fallback) {
            Map<?, ?> row = (Map<?, ?>) item;
            String audit = String.valueOf(row.get("к20"));
            assertEquals("1538215.76", row.get("к14"), audit);
            assertEquals("да", row.get("агенту"));
            assertTrue(audit.contains("запасной ход: правило 1: документ найден по признакам «2 из 3» (3 из 3)"), audit);
            assertTrue(audit.contains("номер спецификации документа («6766351», из пути к файлу) не совпал со спецификацией строки"), audit);
        }
    }

    @Test
    void updMatchingRowsOfDifferentSpecificationsIsNotIdentifiedByRulesAndByFallback() throws Exception {
        // правило 3 не обходится запасным ходом: один УПД полностью совпал (3 из 3) со строками спецификаций 5284130 и 5283471 —
        // и при имени УПД ФНС (правила 1–3), и в папке чужой спецификации 6766351 (запасной ход) обе строки не идентифицированы
        String upd = Form3OpsTest.UPD_SIGNED + "Разработка сервисов на Java\n";
        String form = formLine("Договор № 4652269 от 05.07.2023", "Спецификация 5284130 от 27.03.2025", "УПД № 0000118724 от 21.07.2025",
                "24.07.2025", "1063178,54") + "\n" + formLine("Договор № 4652269 от 05.07.2023", "Спецификация 5283471 от 28.03.2025",
                "УПД № 0000118724 от 21.07.2025", "24.07.2025", "1063178,54");
        List<String> names = List.of("ON_NSCHFDOPPR_2BK-7707083893-667102008-1027700132195_2BK-9709070357-6766351_20250721_0_0.pdf",
                "комплект.zip/Договор 4652269/6766351/УПД 0000118724.pdf");

        for (String name : names) {
            String registry = Form3Ops.registry(List.of(new Form3Ops.Source(name, upd)));
            List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form, Form3FormTest.HEADER), List.class);
            for (Object item : rows) {
                Map<?, ?> row = (Map<?, ?>) item;
                assertEquals(Form3Rows.REASON_UNIDENTIFIED, row.get("к15"), name + ": " + row.get("к20"));
                assertEquals("0", row.get("к14"));
                assertEquals("да", row.get("агенту"));
            }
        }
    }

    @Test
    void updWithUnparsedAlphanumericContractTakesContractFromFormRow() throws Exception {
        // УПД Диадока МЕТРО: «Договор № CN_…» в тексте есть, но номером не разбирается; договор-скан в комплекте есть —
        // строка должна получить «договор 1», а не «Подтверждающие документы не найдены» при опции «без договора не засчитывать»
        // (технология Hadoop — в самом УПД: договор технологию строки не засчитывает)
        String upd = Form3OpsTest.UPD_SIGNED.replace("Информационное поле по документу: Договор 4652269 от 05.07.2023 (050004652269)",
                "Основание передачи: Договор № CN_1090_IT_19_134108_037544 от 22.07.2019\nУслуги разработки ПО (Hadoop)");
        String contract = "[РАСПОЗНАНО ИЗ СКАНА] Документ «договор.pdf»:\n--- страница 1 ---\nДоговор по разработке программного "
                + "обеспечения № \n\nCN 1090 1Т 19 134108 037544 \n\nг. Москва 22.07.2019\nразработка мобильных приложений (Java, Hadoop)\n";
        String registry = Form3Ops.registry(List.of(
                new Form3Ops.Source("МЕТРО.zip/2025/УПД №0000118724 от 21.07.25 - подписан.pdf", upd),
                new Form3Ops.Source("МЕТРО.zip/Договор Метро № CN_1090_IT_19_134108_03 7544 .pdf", contract)));
        String line = formLine("Договор № CN_1090_IT_19_134108_037544 от 22.07.2019 г.", "не применимо",
                "УПД №0000118724 от 21.07.2025", "24.07.2025", "1063178,54");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of("без_договора_не_засчитывать", "true"), registry,
                CRITERIA_HADOOP, line, Form3FormTest.HEADER), List.class).get(0);

        assertEquals("1", row.get(Form3Rows.CONTRACTS), String.valueOf(row.get("к20")));
        assertTrue(!Form3Rows.REASON_NO_DOCS.equals(row.get("к15")), String.valueOf(row.get("к15")));
        assertEquals("1063178.54", row.get("к14"));
    }

    @Test
    void scannedContractWithAlphanumericNumberIsRecognizedByFileNameAndMatchedByDigits() throws Exception {
        // договор МЕТРО (письмо 16.09.2026): скан без заголовка в начале распознанного текста,
        // номер CN_1090_IT_19_134108_037544 — с подчёркиваниями; в строке формы из тех же реквизитов берётся «134108»
        String text = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены автоматическим распознаванием] Документ «договор.pdf»:\n"
                + "--- страница 1 ---\nДоговор по разработке программного обеспечения и услугам консультирования № \n\n"
                + "CN 1090 1Т 19 134108 037544 \n\nг. Москва \n\n22.07.2019 \n\nООО «МЕТРО Кэш ЭНД Керри», именуемое в дальнейшем "
                + "\"Заказчик\", и ООО «Амбрелла Альянс», именуемое в дальнейшем \"Исполнитель\", заключили настоящий Договор.\n";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "Подтверждение опыта ООО МЕТРО.zip/Подтверждение опыта ООО МЕТРО/Договор Метро № CN_1090_IT_19_134108_03 7544 .pdf", text)));

        List<?> contracts = (List<?>) MAPPER.readValue(registry, Map.class).get("договоры");

        assertEquals(1, contracts.size(), registry);
        String number = String.valueOf(((Map<?, ?>) contracts.get(0)).get("номер"));
        assertEquals("134108", Form3Rows.contractKey(number), number);
        assertEquals("134108", Form3Rows.contractKey(Form3Rows.contractNumber("Договор № CN_1090_IT_19_134108_037544 от 22.07.2019 г.")));
    }

    @Test
    void duplicateActOfAnotherSpecificationIsNotTakenByForeignRow() throws Exception {
        // в комплекте 16.09.2026 акт этапа 1 спецификации 5330247 — побайтовый дубль акта 5330241:
        // он принадлежит чужой спецификации, поэтому строка 5330247 остаётся без подтверждающих документов
        String stageOne = Form3OpsTest.UPD_NO_NUMBER.replace("050005270341", "050005330241").replace("24.03.2025", "10.06.2025")
                .replace("25.03.2025 15:20:32", "11.06.2025 15:20:32").replace("\" 25 \" марта", "\" 11 \" июня")
                .replace("283411\n7,31\n×\n566823,\n46\n340094\n0,77", "783960,\n59\n×\n156792,\n12\n940752,\n71");
        String registry = Form3Ops.registry(List.of(
                new Form3Ops.Source("комплект.zip/Договор 5028839 от 07.08.2024/5330241/Акт от 10.06.2025 (09, Этап 1).pdf", stageOne),
                new Form3Ops.Source("комплект.zip/Договор 5028839 от 07.08.2024/5330247/Акт от 10.06.2025 (08, этап 1).pdf", stageOne)));
        String own = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5330241 от 16.05.2025",
                "б/н от 10.06.2025 (Этап 1)", "11.06.2025", "940 752,71");
        String foreign = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5330247 от 16.05.2025",
                "б/н от 10.06.2025 (Этап 1)", "11.06.2025", "2 297 186,85");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, own + "\n" + foreign,
                Form3FormTest.HEADER), List.class);

        assertEquals("940752.71", ((Map<?, ?>) rows.get(0)).get("к14"));
        assertEquals("2297186.85", ((Map<?, ?>) rows.get(1)).get("к10"));
        assertEquals("0", ((Map<?, ?>) rows.get(1)).get("к14"));
        assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) rows.get(1)).get("к15"));
        assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) rows.get(1)).get("к18"));
    }

    @Test
    void documentFullyMatchingRowsOfDifferentSpecificationsIsNotIdentified() throws Exception {
        // правило 3: УПД без ссылки на спецификацию полностью совпал (2 из 2) со строками двух спецификаций одного договора —
        // документ не достаётся никому, обе строки «Не удалось идентифицировать акт», в аудите — претенденты
        String upd = Form3OpsTest.UPD_NO_NUMBER.replace("Дог 050005270341_AGR_Договор вн. №_5028839_от 07.08.2024",
                "Договор 5028839 от 07.08.2024");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор 5028839 от 07.08.2024/Акт от 24.03.2025.pdf", upd)));
        String first = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025",
                "б/н от 24.03.2025", "25.03.2025", "3,400,940.77");
        String second = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5330247 от 16.05.2025",
                "б/н от 24.03.2025 (Этап 2)", "25.03.2025", "3,400,940.77");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, first + "\n" + second,
                Form3FormTest.HEADER), List.class);

        assertEquals(2, rows.size());
        for (Object item : rows) {
            Map<?, ?> row = (Map<?, ?>) item;
            String audit = String.valueOf(row.get("к20"));
            assertEquals("0", row.get("к14"), audit);
            assertEquals(Form3Rows.REASON_UNIDENTIFIED, row.get("к15"));
            assertEquals(Form3Rows.REASON_UNIDENTIFIED, row.get("к18"));
            assertEquals("да", row.get("агенту"));
            assertEquals("3400940.77", row.get("к10"));
            assertTrue(audit.contains("правило 3") && audit.contains("не идентифицирован"), audit);
            assertTrue(audit.contains("спецификация 5270341") && audit.contains("спецификация 5330247"), audit);
        }
    }

    @Test
    void documentFullyMatchingRowsOfSameSpecificationGoesToOneRow() throws Exception {
        // те же признаки у двух строк одной спецификации и договора — обычная ничья: документ получает первая строка
        String upd = Form3OpsTest.UPD_NO_NUMBER.replace("Дог 050005270341_AGR_Договор вн. №_5028839_от 07.08.2024",
                "Договор 5028839 от 07.08.2024");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор 5028839 от 07.08.2024/Акт от 24.03.2025.pdf", upd)));
        String first = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025",
                "б/н от 24.03.2025", "25.03.2025", "3,400,940.77");
        String second = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025",
                "б/н от 24.03.2025 (Этап 2)", "25.03.2025", "3,400,940.77");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, first + "\n" + second,
                Form3FormTest.HEADER), List.class);

        assertEquals("3400940.77", ((Map<?, ?>) rows.get(0)).get("к14"), String.valueOf(((Map<?, ?>) rows.get(0)).get("к20")));
        assertEquals("-", ((Map<?, ?>) rows.get(0)).get("к15"));
        assertEquals("0", ((Map<?, ?>) rows.get(1)).get("к14"));
        assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) rows.get(1)).get("к15"));
    }

    @Test
    void documentFullyMatchingRowsOfDifferentContractsIsNotIdentified() throws Exception {
        // правило 3 для разных договоров: в информационном поле УПД названы два договора, строки формы по каждому из них
        // (спецификация не указана) полностью совпали с УПД — акт не идентифицирован у обеих строк
        String upd = Form3OpsTest.UPD_NO_NUMBER.replace("Дог 050005270341_AGR_Договор вн. №_5028839_от 07.08.2024",
                "Договор 5028839 от 07.08.2024, Договор 5031177 от 12.09.2024");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("комплект.zip/Акт от 24.03.2025.pdf", upd)));
        String form = formLine("Договор № 5028839 от 07.08.2024", "не применимо", "б/н от 24.03.2025", "25.03.2025", "3,400,940.77")
                + "\n" + formLine("Договор № 5031177 от 12.09.2024", "не применимо", "б/н от 24.03.2025", "25.03.2025", "3,400,940.77");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, form, Form3FormTest.HEADER), List.class);

        for (Object item : rows) {
            Map<?, ?> row = (Map<?, ?>) item;
            String audit = String.valueOf(row.get("к20"));
            assertEquals(Form3Rows.REASON_UNIDENTIFIED, row.get("к15"), audit);
            assertEquals("0", row.get("к14"));
            assertTrue(audit.contains("договор 5028839") && audit.contains("договор 5031177"), audit);
        }
    }

    @Test
    void unidentifiedDocumentIsNotGivenToRowWithPartialMatch() throws Exception {
        // правило 3: документ не идентифицирован у строк спецификаций 5270341 и 5330247 (2 из 2); третья строка «Акт №9»
        // совпала с ним лишь частично (дата акта и дата подписания, сумма иная — 2 из 3) — документ ей тоже не достаётся
        String upd = Form3OpsTest.UPD_NO_NUMBER.replace("Дог 050005270341_AGR_Договор вн. №_5028839_от 07.08.2024",
                "Договор 5028839 от 07.08.2024");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("комплект.zip/Договор 5028839 от 07.08.2024/Акт от 24.03.2025.pdf", upd)));
        String form = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025", "б/н от 24.03.2025",
                "25.03.2025", "3,400,940.77") + "\n" + formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5330247 от 16.05.2025",
                "б/н от 24.03.2025", "25.03.2025", "3,400,940.77") + "\n" + formLine("Договор № 5028839 от 07.08.2024",
                "Спецификация № 5270341 от 17.03.2025", "Акт №9 от 24.03.2025", "25.03.2025", "3,400,000.00");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, form, Form3FormTest.HEADER), List.class);

        assertEquals(Form3Rows.REASON_UNIDENTIFIED, ((Map<?, ?>) rows.get(0)).get("к15"));
        assertEquals(Form3Rows.REASON_UNIDENTIFIED, ((Map<?, ?>) rows.get(1)).get("к15"));
        Map<?, ?> partial = (Map<?, ?>) rows.get(2);
        assertEquals(Form3Rows.REASON_NO_DOCS, partial.get("к15"), String.valueOf(partial.get("к20")));
        assertEquals("0", partial.get("к14"));
    }

    @Test
    void documentFullyMatchingNumberedRowsOfDifferentSpecificationsIsNotIdentifiedAndReasonStaysSingle() throws Exception {
        // правило 3 для строк с номером: «Акт №5» и «Акт №6» с одной датой, штампом и суммой против УПД без номера — 3 из 3
        // у строк разных спецификаций; с опцией «без договора не засчитывать» причина остаётся одна
        String upd = Form3OpsTest.UPD_NO_NUMBER.replace("Дог 050005270341_AGR_Договор вн. №_5028839_от 07.08.2024",
                "Договор 5028839 от 07.08.2024");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("комплект.zip/Договор 5028839 от 07.08.2024/Акт от 24.03.2025.pdf", upd)));
        String form = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025", "Акт №5 от 24.03.2025",
                "25.03.2025", "3,400,940.77") + "\n" + formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5330247 от 16.05.2025",
                "Акт №6 от 24.03.2025", "25.03.2025", "3,400,940.77");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.WITHOUT_CONTRACT, "true"), registry, CRITERIA_HADOOP, form,
                Form3FormTest.HEADER), List.class);

        for (Object item : rows) {
            Map<?, ?> row = (Map<?, ?>) item;
            assertEquals(Form3Rows.REASON_UNIDENTIFIED, row.get("к15"), String.valueOf(row.get("к20")));
            assertEquals("0", row.get(Form3Rows.CONTRACTS));
            assertEquals("0", row.get("к14"));
        }
    }

    @Test
    void fullRule2MatchOutranksPartialRule1MatchOfEarlierRow() throws Exception {
        // ранг — сначала полнота совпадения: строка «Акт №5» (номер и дата не совпали, 2 из 3) раньше в форме, но документ
        // достаётся строке «б/н» с полным совпадением 2 из 2
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025.pdf", Form3OpsTest.UPD_NO_NUMBER)));
        String form = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025", "Акт №5 от 20.03.2025",
                "25.03.2025", "3,400,940.77") + "\n" + formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025",
                "б/н от 23.03.2025", "25.03.2025", "3,400,940.77");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, form, Form3FormTest.HEADER), List.class);

        assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) rows.get(0)).get("к15"), String.valueOf(((Map<?, ?>) rows.get(0)).get("к20")));
        assertEquals("3400940.77", ((Map<?, ?>) rows.get(1)).get("к14"), String.valueOf(((Map<?, ?>) rows.get(1)).get("к20")));
    }

    @Test
    void rowWithOwnFullCandidateIsNotClaimantOfSharedDocument() throws Exception {
        // правило 3 только для строк, у которых документ — лучший полный кандидат: строка спецификации 5330247 полностью
        // совпала и со своим УПД (ссылка на 5330247), и с «безадресным» УПД; строка 5270341 — только с безадресным.
        // Документы расходятся по строкам, «Не удалось идентифицировать акт» не ставится
        String shared = Form3OpsTest.UPD_NO_NUMBER.replace("Дог 050005270341_AGR_Договор вн. №_5028839_от 07.08.2024",
                "Договор 5028839 от 07.08.2024");
        String own = Form3OpsTest.UPD_NO_NUMBER.replace("050005270341", "050005330247").replace("N б.н. от", "N 77 от");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("комплект.zip/Акт от 24.03.2025.pdf", shared),
                new Form3Ops.Source("комплект.zip/5330247/Акт от 24.03.2025.pdf", own)));
        String form = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025", "б/н от 24.03.2025",
                "25.03.2025", "3,400,940.77") + "\n" + formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5330247 от 16.05.2025",
                "б/н от 24.03.2025", "25.03.2025", "3,400,940.77");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, form, Form3FormTest.HEADER), List.class);

        for (Object item : rows) {
            assertEquals("3400940.77", ((Map<?, ?>) item).get("к14"), String.valueOf(((Map<?, ?>) item).get("к20")));
        }
        assertEquals("УПД б.н. от 24.03.2025", ((Map<?, ?>) rows.get(0)).get("к6"));
        assertEquals("УПД 77 от 24.03.2025", ((Map<?, ?>) rows.get(1)).get("к6"));
    }

    @Test
    void shortFormRowsOfDifferentSpecificationsWithSameExactNumberAreNotIdentified() throws Exception {
        // правило 3 и для короткой формы: один «УПД №0000118724 от 21.07.2025» у строк спецификаций 5281780 и 5374642
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Опыт.zip/УПД 0000118724.pdf", Form3OpsTest.UPD_SIGNED)));
        String form = formLine("Договор № 4652269 от 05.07.2023", "Спец. №5281780 от 28.03.2025г.", "УПД №0000118724 от 21.07.2025г.",
                "да", "не применимо") + "\n" + formLine("Договор № 4652269 от 05.07.2023", "Спец. №5374642 от 27.06.2025г.",
                "УПД №0000118724 от 21.07.2025г.", "да", "не применимо");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, form, Form3FormTest.HEADER), List.class);

        for (Object item : rows) {
            assertEquals(Form3Rows.REASON_UNIDENTIFIED, ((Map<?, ?>) item).get("к15"), String.valueOf(((Map<?, ?>) item).get("к20")));
        }
    }

    @Test
    void scanNoteIsNotSetWhenContractHasDocumentsWithText() throws Exception {
        // пометка «документ-скан не распознан» — только если у строки нет ни одного документа с текстом по её договору:
        // акт договора распознан (текст есть), но строке не подошёл — пометка ввела бы в заблуждение
        String scan = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены автоматическим распознаванием] Документ «Акт №104227011 от 20.06.2025.pdf»:\n";
        String textAct = Form3ActsTest.SBER_ACT.replace("4286515", "32514746233");
        String line = formLine("Договор № 32514746233 от 04.06.2025", "не применимо", "№ 104227999 от 21.06.2025 (Этап 1)", "21.06.2025",
                "5,885,794.33");
        String onlyScan = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор №32514746233 от 04.06.2025/Акт №104227011 от 20.06.2025.pdf", scan)));
        String withText = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор №32514746233 от 04.06.2025/Акт №104227011 от 20.06.2025.pdf", scan),
                new Form3Ops.Source("комплект.zip/Договор №32514746233 от 04.06.2025/Акт Э1.docx", textAct)));

        Map<?, ?> noted = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), onlyScan, CRITERIA_HADOOP, line, Form3FormTest.HEADER),
                List.class).get(0);
        Map<?, ?> silent = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), withText, CRITERIA_HADOOP, line, Form3FormTest.HEADER),
                List.class).get(0);

        assertTrue(String.valueOf(noted.get("к20")).contains("документ-скан не распознан"), String.valueOf(noted.get("к20")));
        assertTrue(!String.valueOf(silent.get("к20")).contains("документ-скан не распознан"), String.valueOf(silent.get("к20")));
        assertEquals(Form3Rows.REASON_NO_DOCS, silent.get("к15"));
    }

    @Test
    void scannedActWithoutTextLayerIsFoundByFileNameOnlyWhenEnabled() throws Exception {
        // 8 актов договора 32514746233 — сканы без текстового слоя. По умолчанию (вопрос 2 письма: сканы распознаёт модель)
        // документ не найден, в аудите пометка; параметр «сканы_по_имени_файла» включает реквизиты из имени файла и пути
        String scan = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены автоматическим распознаванием] "
                + "Документ «Акт №104227011 от 20.06.2025.pdf»:\n";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор №32514746233 от 04.06.2025/Акт №104227011 от 20.06.2025.pdf", scan)));
        String line = formLine("Договор № 32514746233 от 04.06.2025", "не применимо",
                "№ 104227011 от 20.06.2025 (Этап 1)", "20.06.2025", "5,885,794.33");

        Map<?, ?> denied = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, line,
                Form3FormTest.HEADER), List.class).get(0);
        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.SCANS_BY_NAME, "true"), registry,
                CRITERIA_HADOOP, line, Form3FormTest.HEADER), List.class).get(0);

        assertEquals("0", denied.get("к14"));
        assertEquals(Form3Rows.REASON_NO_DOCS, denied.get("к15"));
        assertTrue(String.valueOf(denied.get("к20")).contains("документ-скан не распознан (распознавание моделью выключено или не удалось)"),
                String.valueOf(denied.get("к20")));
        assertEquals("20.06.2025", row.get("к7"));
        assertEquals("5885794.33", row.get("к10"));
        assertEquals("технология не найдена", row.get("к15"));
        assertTrue(String.valueOf(row.get("к20")).contains("реквизиты по имени файла, текст не распознан"),
                String.valueOf(row.get("к20")));
        assertEquals("да", row.get("агенту"));
    }

    @Test
    void scanWithoutTextLayerIsNotFoundByFileNameForRowWithoutNumber() throws Exception {
        // строка «б/н»: по правилу 2 документ опознаётся только по дате подписания и сумме, имя файла даёт лишь дату акта —
        // ход «по имени файла» ей не полагается и при включённом параметре (Комплект 5: «Заявка №104 Акт №б-н от 27.04.24.pdf»)
        String scan = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены автоматическим распознаванием] Документ «Заявка №104 Акт №б-н от 27.04.24.pdf»:\n";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Договор №АБ-С-ИТ-2020/Заявка №104 Акт №б-н от 27.04.24.pdf", scan)));
        String line = formLine("Договор №АБ-С-ИТ-2020 от 03.02.2020", "Заявка 104 от 15.04.2024", "Акт от 27.04.2024", "27.04.2024",
                "22849905");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.SCANS_BY_NAME, "true"), registry, CRITERIA_HADOOP, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals(Form3Rows.REASON_NO_DOCS, row.get("к15"), String.valueOf(row.get("к20")));
    }

    private static Map<?, ?> firstRow(String criteria, Form3Ops.Source... sources) throws Exception {
        String registry = Form3Ops.registry(List.of(sources));
        return (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria), List.class).get(0);
    }

    @Test
    void technologiesAreLocatedInContractAndReportLinkedByLongNumber() throws Exception {
        // спецификации нет: договор найден по номеру, отчёт — по общему номеру ЗНЗО с УПД
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", UPD_WITH_ZNZO),
                new Form3Ops.Source("Договор.pdf", CONTRACT), new Form3Ops.Source("Отчет.pdf", REPORT));

        // Java и Python — только в договоре (к16): столбцы технологий их не засчитывают; Go — в отчёте к УПД, наравне с актом
        assertEquals("не сопоставлена", row.get("к5"));
        assertEquals("нет", row.get("т_Java"));
        assertEquals("да", row.get("т_Go (Golang)"));
        assertEquals("нет", row.get("т_Python"));
        assertEquals("да: Java, Python", row.get("к16"));
        assertEquals("нет", row.get("к17"));
        assertEquals("нет", row.get("к18"));
        assertEquals("да: Go (Golang)", row.get("к19"));
        assertEquals("1063178.54", row.get("к14"));
        assertEquals("-", row.get("к15"));
        assertTrue(String.valueOf(row.get("к20")).contains("договор 1, спецификаций 0, отчётов 1"));

        // параметр «отчёт_как_акт» = false: отчёт технологию не засчитывает — ни одной технологии в спецификации/акте
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_WITH_ZNZO),
                new Form3Ops.Source("Договор.pdf", CONTRACT), new Form3Ops.Source("Отчет.pdf", REPORT)));
        Map<?, ?> withoutReport = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.REPORT_AS_ACT, "false"), registry,
                Form3OpsTest.CRITERIA), List.class).get(0);
        assertEquals("нет", withoutReport.get("т_Go (Golang)"));
        assertEquals("да: Go (Golang)", withoutReport.get("к19"));
        assertEquals("0", withoutReport.get("к14"));
        assertEquals(Form3Rows.REASON_NO_TECH, withoutReport.get("к15"));
    }

    /** Критерии письма Егоровой «Ошибки с поиском технологий»: Hadoop, GreenPlum, Python. */
    private static String criteriaLetter() {
        return CRITERIA_HADOOP.replace("Технология 1 | Hadoop | Раздел 2 | точно", "Технология 1 | Hadoop | Раздел 2 | точно"
                + System.lineSeparator() + "Технология 2 | GreenPlum | Раздел 2 | точно" + System.lineSeparator()
                + "Технология 3 | Python | Раздел 2 | точно");
    }

    @Test
    void technologiesComeFromSpecificationAndActNotFromContract() throws Exception {
        // письмо 2, пример 1: договор — Hadoop, GreenPlum, Python; спецификация — GreenPlum, Python; акт — нет данных
        String spec = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end)", "Главный разработчик GreenPlum, Python");
        Map<?, ?> row = firstRow(criteriaLetter(), new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", spec), new Form3Ops.Source("Договор.pdf", CONTRACT_THREE));

        assertEquals("нет", row.get("т_Hadoop"));
        assertEquals("да", row.get("т_GreenPlum"));
        assertEquals("да", row.get("т_Python"));
        assertEquals("да: Hadoop, GreenPlum, Python", row.get("к16"));
        assertEquals("да: GreenPlum, Python", row.get("к17"));
        assertEquals("нет", row.get("к18"));
        assertEquals("1063178.54", row.get("к14"), String.valueOf(row.get("к20")));
        assertEquals("-", row.get("к15"));
    }

    @Test
    void contractAndActWithoutTechnologiesGiveNoCredit() throws Exception {
        // письмо 2, пример 2 и письмо 3: договор — 3 технологии, акт — ни одной, спецификации нет → все «нет», зачтено 0
        Map<?, ?> row = firstRow(criteriaLetter(), new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Договор.pdf", CONTRACT_THREE));

        assertEquals("нет", row.get("т_Hadoop"));
        assertEquals("нет", row.get("т_GreenPlum"));
        assertEquals("нет", row.get("т_Python"));
        assertEquals("да: Hadoop, GreenPlum, Python", row.get("к16"));
        assertEquals("0", row.get("к14"));
        assertEquals(Form3Rows.REASON_NO_TECH, row.get("к15"));
        assertEquals("да", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("технологии найдены только в договоре (Hadoop, GreenPlum, Python) — "
                + "в спецификации и акте нет, опыт не засчитан"), String.valueOf(row.get("к20")));
    }

    @Test
    void technologiesNotClaimedByParticipantAreStillYesWhenFoundInSpecification() throws Exception {
        // участник заявил в форме только Python (GreenPlum — «нет»), спецификация называет GreenPlum и Python — оба «да»;
        // расхождение с формой — пометкой в аудите
        String spec = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end)", "Главный разработчик GreenPlum, Python");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", spec), new Form3Ops.Source("Договор.pdf", CONTRACT_THREE)));
        String header = Form3FormTest.HEADER.replace("технологии Java", "технологии GreenPlum");
        String line = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025 | да | нет",
                "Договор № 4652269 от 05.07.2023 | Спецификация № 5374642 от 27.06.2025 | УПД № 0000118724 от 21.07.2025 | 24.07.2025 | нет | да")
                .replace("2495000", "1063178,54");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteriaLetter(), line, header), List.class).get(0);

        assertEquals("да", row.get("т_GreenPlum"));
        assertEquals("да", row.get("т_Python"));
        assertEquals("нет", row.get("т_Hadoop"));
        assertEquals("1063178.54", row.get("к14"), String.valueOf(row.get("к20")));
        assertTrue(String.valueOf(row.get("к20")).contains("по форме участника не заявлено, но найдено в спецификации/акте: GreenPlum"),
                String.valueOf(row.get("к20")));
    }

    @Test
    void testingOnlySpecificationBlocksCredit() throws Exception {
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_TESTING));

        assertEquals("да", row.get("к13"));
        assertEquals("0", row.get("к14"));
        assertEquals("технология не найдена; только тестирование", row.get("к15"));
    }

    @Test
    void mobileDevelopmentBlocksCreditUnlessProcurementIsMobile() throws Exception {
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_MOBILE));
        assertEquals("да", row.get("к12"));
        assertEquals("мобильная разработка", row.get("к15"));

        String mobileCriteria = Form3OpsTest.CRITERIA.replace(
                "стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        Map<?, ?> allowed = firstRow(mobileCriteria, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_MOBILE));
        assertEquals("-", allowed.get("к15"));
        assertTrue(String.valueOf(allowed.get("к20")).contains("не стоп-фактор"));

        // мобильная закупка, а в документах строки мобильной разработки нет — не засчитывается
        Map<?, ?> noMobile = firstRow(mobileCriteria, new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", Form3OpsTest.SPEC_A));
        assertEquals("нет", noMobile.get("к12"));
        assertEquals("нет мобильной разработки", noMobile.get("к15"));
    }

    @Test
    void customerOutsideRatingAndActOutsidePeriodAreListedAsReasons() throws Exception {
        String upd = Form3OpsTest.UPD_SIGNED.replace("ПАО Сбербанк", "ООО \"Ромашка\"")
                .replace("\" 24 \" июля 2025", "\" 24 \" июля 2024");
        Map<?, ?> row = firstRow(Form3OpsTest.CRITERIA, new Form3Ops.Source("upd.pdf", upd),
                new Form3Ops.Source("Спецификация № 5374642.pdf", Form3OpsTest.SPEC_A));

        // заказчик не в рейтинге — стоп-фактор: остальные проверки не выполняются (прочерк), причина одна
        assertEquals("нет", row.get("к11"));
        assertEquals("-", row.get("к8"));
        assertEquals("-", row.get("к9"));
        assertEquals("-", row.get("т_Java"));
        assertEquals("Заказчик не в рейтинге", row.get("к15"));
        assertEquals("0", row.get("к14"));
    }

    private static List<Map<?, ?>> formRows(String registry, String form) throws Exception {
        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form, Form3FormTest.HEADER),
                List.class);
        return rows.stream().<Map<?, ?>>map(r -> (Map<?, ?>) r).toList();
    }

    @Test
    void formRowWithoutDocumentsGetsVerdictFromFormData() throws Exception {
        // форма первична: акт без документов в комплекте получает периоды, рейтинг и причину, а не пропадает
        Map<?, ?> row = formRows(Form3Ops.registry(List.of()), FORM_LINE).get(0);

        assertEquals("ПАО Сбербанк", row.get("к3"));
        assertEquals("Акт №7 выполненных работ от 30.06.2025", row.get("к6"));
        assertEquals("30.06.2025", row.get("к7"));
        assertEquals("да", row.get("к8"));
        assertEquals("да", row.get("к9"));
        assertEquals("2495000.00", row.get("к10"));
        assertEquals("да", row.get("к11"));
        assertEquals("0", row.get("к14"));
        // исход 1 письма Егоровой: документ не найден — причина одна, обработка строки на этом заканчивается
        assertEquals("Подтверждающие документы не найдены", row.get("к15"));
        assertEquals("Подтверждающие документы не найдены", row.get("к18"));
        assertEquals("нет", row.get("т_Java"));
        assertTrue(String.valueOf(row.get("к20")).contains("заявлено участником в форме, в спецификации/акте не подтверждено: Java"));
        assertEquals(FORM_LINE, row.get("исходная_строка"));
    }

    @Test
    void formRowIsLinkedToAcceptanceActBySpecificationNumberAndDate() throws Exception {
        // акт Сбера без структуры УПД: найден по дате акта из формы и номеру спецификации, технологии — из акта
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("4787401 Акт Э2.docx", Form3ActsTest.SBER_ACT),
                new Form3Ops.Source("4787401 Акт Э1.docx", Form3ActsTest.SBER_ACT.replace("«08» апреля 2025", "«10» января 2025"))));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String line = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                "Договор №4286515 от 09.09.2022 | Спецификация №4787401 от 17.11.2023 | Акт от 08.04.2025 | 08.04.2025")
                .replace("2495000", "1712787");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("Акт от 08.04.2025", row.get("к6"));
        assertEquals("08.04.2025", row.get("к7"));
        assertEquals("1712787.00", row.get("к10"));
        assertEquals("ПАО Сбербанк", row.get("к3"));
        assertEquals("да", row.get("т_Android"));
        assertEquals("да: Android", row.get("к18"));
        assertEquals("-", row.get("к15"));
        assertTrue(String.valueOf(row.get("к20")).contains("акт «4787401 Акт Э2.docx»"));
        assertTrue(String.valueOf(row.get("к20")).contains("штампом ЭДО не подтверждена"));
        // штампа ЭДО у акта docx нет: признак «дата подписания» сравнён с датой документа, источник — в аудите
        assertTrue(String.valueOf(row.get("к20")).contains("правило 2 (номер акта не указан): дата подписания — да (дата документа 08.04.2025, штампа нет)"),
                String.valueOf(row.get("к20")));
    }

    @Test
    void exactMatchesAreResolvedBeforeFallbacksAndFormDateDrivesPeriod() throws Exception {
        // два акта одной спецификации: первая строка без номера («Акт от 01.10.2025», акт датирован 05.10.2025) по правилу 2
        // документа не получает — дата подписания не совпала, а по номеру спецификации и сумме она акт второй строки
        // не забирает; у УПД дата периода — заявленная в форме (дата УПД), а не дата приёмки
        String actOctober = Form3ActsTest.SBER_ACT.replace("«08» апреля 2025", "«05» октября 2025").replace("1 712 787,00", "2 729 995,22");
        String actDecember = Form3ActsTest.SBER_ACT.replace("«08» апреля 2025", "«20» декабря 2025");
        String upd = Form3OpsTest.UPD_SIGNED.replace("21.07.2025", "24.03.2025").replace("\" 24 \" июля 2025", "\" 26 \" марта 2025");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Акт Э2.docx", actOctober),
                new Form3Ops.Source("Акт Э3.docx", actDecember), new Form3Ops.Source("upd.pdf", upd)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String base = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо", "Договор №4286515 от 09.09.2022 | Спецификация №4787401 от 17.11.2023");
        String form = base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт от 01.10.2025 | 01.10.2025").replace("2495000", "2729995,22")
                + "\n" + base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт от 20.12.2025 | 20.12.2025").replace("2495000", "1712787")
                + "\n" + base.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "УПД 118724 от 24.03.2025 | 24.03.2025").replace("2495000", "1063178,54");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, form, Form3FormTest.HEADER), List.class);

        assertEquals("Акт от 01.10.2025", ((Map<?, ?>) rows.get(0)).get("к6"));
        assertEquals(Form3Rows.REASON_NO_DOCS, ((Map<?, ?>) rows.get(0)).get("к15"));
        assertEquals("Акт от 20.12.2025", ((Map<?, ?>) rows.get(1)).get("к6"));
        assertEquals("-", ((Map<?, ?>) rows.get(1)).get("к15"));
        assertEquals("24.03.2025", ((Map<?, ?>) rows.get(2)).get("к7"));
        assertEquals("нет", ((Map<?, ?>) rows.get(2)).get("к9"));

        // параметр «б/н_допуски», допуск (б): акт Сбера без штампа ЭДО находится по номеру спецификации и сумме — на проверку агенту
        List<?> tolerant = MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.BN_TOLERANCES, "true"), registry, criteria, form,
                Form3FormTest.HEADER), List.class);
        Map<?, ?> first = (Map<?, ?>) tolerant.get(0);
        assertEquals("Акт от 05.10.2025", first.get("к6"), String.valueOf(first.get("к20")));
        assertEquals("2729995.22", first.get("к10"));
        assertEquals("да", first.get("агенту"));
        assertTrue(String.valueOf(first.get("к20")).contains("б/н допуск (б): совпали номер спецификации/заявки строки и сумма"),
                String.valueOf(first.get("к20")));
        assertEquals("-", ((Map<?, ?>) tolerant.get(1)).get("к15"));
    }

    @Test
    void bnToleranceAcceptsActDateInSignColumnOnlyWhenEnabledAndCandidateIsSingle() throws Exception {
        // Комплект 5/9: участник пишет в графу подписания дату акта (24.03), штамп ЭДО — 25.03. По правилу 2 не найден;
        // допуск (а) параметра «б/н_допуски» находит документ, если он единственный с этой суммой (спецификация в строке
        // не указана — допуск (б) по спецификации и сумме неприменим)
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025.pdf", Form3OpsTest.UPD_NO_NUMBER)));
        String twoDocs = Form3Ops.registry(List.of(
                new Form3Ops.Source("комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025.pdf", Form3OpsTest.UPD_NO_NUMBER),
                new Form3Ops.Source("комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025 (копия).pdf",
                        Form3OpsTest.UPD_NO_NUMBER.replace("24.03.2025 17:28:43", "20.03.2025 17:28:43"))));
        String line = formLine("Договор № 5028839 от 07.08.2024", "не применимо", "б/н от 24.03.2025", "24.03.2025", "3,400,940.77");
        // 24.03.2025 — ещё и дата подписи исполнителя в штампе: допуск «любая подпись штампа» выключен, чтобы проверить допуск (а)
        Map<String, Object> option = Map.of(Form3Rows.BN_TOLERANCES, "true", Form3Rows.BN_ANY_SIGNATURE, "false");

        Map<?, ?> strict = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.BN_ANY_SIGNATURE, "false"), registry, CRITERIA_HADOOP,
                line, Form3FormTest.HEADER), List.class).get(0);
        Map<?, ?> tolerant = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(option, registry, CRITERIA_HADOOP, line, Form3FormTest.HEADER),
                List.class).get(0);
        Map<?, ?> ambiguous = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(option, twoDocs, CRITERIA_HADOOP, line, Form3FormTest.HEADER),
                List.class).get(0);

        assertEquals(Form3Rows.REASON_NO_DOCS, strict.get("к15"));
        assertEquals("3400940.77", tolerant.get("к14"), String.valueOf(tolerant.get("к20")));
        assertEquals("да", tolerant.get("агенту"));
        assertTrue(String.valueOf(tolerant.get("к20")).contains("б/н допуск (а): дата в графе подписания формы 24.03.2025 равна дате акта, "
                + "дата подписания документа — штамп ЭДО 25.03.2025"), String.valueOf(tolerant.get("к20")));
        assertEquals(Form3Rows.REASON_NO_DOCS, ambiguous.get("к15"), String.valueOf(ambiguous.get("к20")));
    }

    @Test
    void rule2FirstStampSignatureIsToleranceForAgent() throws Exception {
        // пример методолога к правилу 2 (Комплект 9): в графе подписания — дата подписи исполнителя (24.03.2025), заказчик подписал
        // 25.03.2025. По ответу на вопрос 4 (последняя подпись) строгое правило 2 документ не находит; допуск «любая подпись штампа»
        // (по умолчанию включён) находит его с пометкой и отправляет строку агенту
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source(
                "комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025.pdf", Form3OpsTest.UPD_NO_NUMBER)));
        String line = formLine("Договор № 5028839 от 07.08.2024", "Спецификация № 5270341 от 17.03.2025", "б/н от 24.03.2025 (Этап 1)",
                "24.03.2025", "3,400,940.77");

        Map<?, ?> tolerant = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA_HADOOP, line, Form3FormTest.HEADER),
                List.class).get(0);
        Map<?, ?> strict = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.BN_ANY_SIGNATURE, "false"), registry, CRITERIA_HADOOP,
                line, Form3FormTest.HEADER), List.class).get(0);

        String audit = String.valueOf(tolerant.get("к20"));
        assertEquals("3400940.77", tolerant.get("к14"), audit);
        assertEquals("да", tolerant.get("агенту"));
        assertTrue(audit.contains("допуск подписи штампа: дата в графе подписания формы 24.03.2025 — дата одной из подписей штампа ЭДО "
                + "(24.03.2025, 25.03.2025), а не последней (штамп ЭДО 25.03.2025); сумма совпала, документ единственный — на проверку"), audit);
        assertEquals(Form3Rows.REASON_NO_DOCS, strict.get("к15"), String.valueOf(strict.get("к20")));
    }

    @Test
    void ocrStampWithoutColonsGivesSignDateAndActDateIsNotSubstituted() throws Exception {
        // Комплект 5: распознанный скан «Заявка №104 Акт №б-н от 27.04.24.pdf», штамп Контура без двоеточий — подписи 02.05.2024
        // (исполнитель) и 14.05.2024 (заказчик). Строка б/н с датой акта 27.04 в графе подписания не найдена (дата документа штамп
        // не подменяет), с 14.05 — найдена правилом 2, с 02.05 — допуском «любая подпись штампа» на проверку агенту
        String text = Form3ActsTest.ALFA_ACT_OCR.replace("14.05.2024 Подпись соответствует файлу документа", "") + Form3ActsTest.KONTUR_OCR_STAMP;
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf", text)));
        String line = alfaLine("Акт от 27.04.2024 | 27.04.2024");

        Map<?, ?> actDate = alfaRow(registry, line);
        Map<?, ?> last = alfaRow(registry, alfaLine("Акт от 27.04.2024 | 14.05.2024"));
        Map<?, ?> first = alfaRow(registry, alfaLine("Акт от 27.04.2024 | 02.05.2024"));

        assertEquals(Form3Rows.REASON_NO_DOCS, actDate.get("к15"), String.valueOf(actDate.get("к20")));
        assertTrue(String.valueOf(actDate.get("к20")).contains("сумма совпала, но дата подписания не совпала (правило 2: дата подписания в форме "
                + "27.04.2024, документ — штамп ЭДО 14.05.2024)"), String.valueOf(actDate.get("к20")));
        assertEquals("22849905.00", last.get("к14"), String.valueOf(last.get("к20")));
        assertEquals("14.05.2024", last.get("к7"));
        assertTrue(String.valueOf(last.get("к20")).contains("правило 2 (номер акта не указан): дата подписания — да (штамп ЭДО 14.05.2024)"),
                String.valueOf(last.get("к20")));
        assertEquals("22849905.00", first.get("к14"), String.valueOf(first.get("к20")));
        assertEquals("да", first.get("агенту"));
        assertTrue(String.valueOf(first.get("к20")).contains("допуск подписи штампа"), String.valueOf(first.get("к20")));

        // штамп в тексте есть, дата подписи не разобрана — дата документа 27.04 его не подменяет, в аудите «штамп ЭДО не разобран»
        String unparsed = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf",
                Form3ActsTest.ALFA_ACT_OCR.replace("14.05.2024 Подпись", "дата неразборчива Подпись"))));
        Map<?, ?> noDate = alfaRow(unparsed, line);
        assertEquals(Form3Rows.REASON_NO_DOCS, noDate.get("к15"), String.valueOf(noDate.get("к20")));
        assertTrue(String.valueOf(noDate.get("к20")).contains("дата подписания в форме 27.04.2024, документ — штамп ЭДО не разобран"),
                String.valueOf(noDate.get("к20")));
    }

    /** Строка формы Комплекта 5 (Альфа-Банк, заявка 104) с реквизитами акта и датой подписания «Акт от … | дата». */
    private static String alfaLine(String actAndSignDate) {
        return FORM_LINE.replace("ПАО Сбербанк", "АО «АЛЬФА-БАНК»")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "Договор №АБ-С-ИТ-2020 от 03.02.2020 | Заявка 104 от 15.04.2024 | " + actAndSignDate)
                .replace("2495000", "22849905");
    }

    /** Первая строка заключения для строки Комплекта 5: критерии с Android, мобильная закупка, период методики с 2024 года. */
    private static Map<?, ?> alfaRow(String registry, String line) throws Exception {
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка")
                .replace("с 08.04.2025 по 08.04.2026", "с 01.01.2024 по 08.04.2026");
        return (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class).get(0);
    }

    @Test
    void actAmountMatchesTotalOrLabeledStageTotalButNotAnyNumberOfText() throws Exception {
        // признак «сумма» у акта — итог («Следует к оплате по Акту») или итог этапа с явной меткой («… составляет»),
        // но не ставка позиции таблицы (24 823,00)
        String act = Form3ActsTest.SBER_ACT.replace("Следует к оплате по Акту 1 712 787,00", "Следует к оплате по Акту 3 000 000,00");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("4787401 Акт Э2.docx", act)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String base = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо", "Договор №4286515 от 09.09.2022 | Спецификация №4787401 от 17.11.2023")
                .replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт от 08.04.2025 | 08.04.2025");

        Map<?, ?> stage = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, base.replace("2495000", "1712787"),
                Form3FormTest.HEADER), List.class).get(0);
        Map<?, ?> rate = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, base.replace("2495000", "24823"),
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals("1712787.00", stage.get("к10"), String.valueOf(stage.get("к20")));
        assertTrue(String.valueOf(stage.get("к20")).contains("сумма — да (итог этапа с меткой итога в тексте акта; итог акта 3000000.00)"),
                String.valueOf(stage.get("к20")));
        assertTrue(String.valueOf(stage.get("к20")).contains("дата подписания — да (дата документа 08.04.2025, штампа нет)"),
                String.valueOf(stage.get("к20")));
        assertEquals(Form3Rows.REASON_NO_DOCS, rate.get("к15"), String.valueOf(rate.get("к20")));
    }

    @Test
    void actFoundByNumberDateAndSignDateTakesActTotalWhenFormAmountIsOnlyRateOfText() throws Exception {
        // акт найден правилом 1 по номеру/дате акта и дате подписания (2 из 3), сумма формы 24 823,00 — ставка позиции таблицы,
        // а не итог акта: зачтённая сумма — итог акта с пометкой, как и признак «сумма — нет» в аудите
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("4787401 Акт Э2.docx", Form3ActsTest.SBER_ACT)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String line = FORM_LINE.replace("4652269 от 05.07.2023 | не применимо", "Договор №4286515 от 09.09.2022 | Спецификация №4787401 от 17.11.2023")
                .replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "Акт №5 от 08.04.2025 | 08.04.2025").replace("2495000", "24823");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class).get(0);

        String audit = String.valueOf(row.get("к20"));
        assertTrue(audit.contains("правило 1: документ найден по признакам «2 из 3» (2 из 3)") && audit.contains("сумма — нет"), audit);
        assertEquals("1712787.00", row.get("к10"), audit);
        assertEquals("1712787.00", row.get("к14"), audit);
        assertTrue(audit.contains("сумма формы 24823.00 в акте не найдена, взята сумма акта"), audit);
    }

    @Test
    void partialClaimOfUpdTakesFormAmountWithNote() throws Exception {
        // участник заявляет часть УПД (профильные позиции): сумма формы меньше итога — берётся сумма формы
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("УПД №970 от 23.12.25.pdf",
                Form3OpsTest.UPD_SIGNED.replace("0000118724", "970").replace("21.07.2025", "23.12.2025"))));
        String line = FORM_LINE.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "УПД от 23.12.2025 №970 | 24.07.2025")
                .replace("2495000", "288640");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals("УПД 970 от 23.12.2025", row.get("к6"));
        assertEquals("288640.00", row.get("к10"));
        assertTrue(String.valueOf(row.get("к20")).contains("сумма по форме участника 288640.00 (итог УПД 1063178.54)"));
    }

    @Test
    void scannedActTakesAmountFromFormWithNote() throws Exception {
        // регрессия Комплекта 5 (v6.4): распознанный скан «Заявка №104 Акт №б-н» — модель ошиблась в цифрах суммы. Допуск
        // распознавания (технический): дата подписания (штамп ЭДО 14.05.2024 в графе формы) и номер заявки совпали — акт найден,
        // сумма из формы с пометкой, агенту
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf",
                Form3ActsTest.ALFA_ACT_OCR.replace("22 849 905,00", "6 961 205,00"))));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка")
                .replace("с 08.04.2025 по 08.04.2026", "с 01.01.2024 по 08.04.2026");
        String line = FORM_LINE.replace("ПАО Сбербанк", "АО «АЛЬФА-БАНК»")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "Договор №АБ-С-ИТ-2020 от 03.02.2020 | Заявка 104 от 15.04.2024 | Акт от 27.04.2024 | 14.05.2024")
                .replace("2495000", "22849905");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line,
                Form3FormTest.HEADER), List.class).get(0);
        Map<?, ?> otherOrder = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria,
                line.replace("Заявка 104 от 15.04.2024", "Заявка 105 от 15.04.2024"), Form3FormTest.HEADER), List.class).get(0);

        assertEquals("22849905.00", row.get("к10"));
        assertEquals("22849905.00", row.get("к14"), String.valueOf(row.get("к20")));
        assertEquals("да", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("в распознанном скане акта не найдена, скан даёт 6961205.00"));
        assertTrue(String.valueOf(row.get("к20")).contains("допуск распознавания: распознанный скан найден по дате подписания (штамп ЭДО "
                + "14.05.2024)"), String.valueOf(row.get("к20")));
        // без совпадения номера заявки допуск не действует
        assertEquals(Form3Rows.REASON_NO_DOCS, otherOrder.get("к15"), String.valueOf(otherOrder.get("к20")));
        // в графе дата акта (27.04), а не штампа: дата документа штамп не подменяет — не найден, в аудите почему
        Map<?, ?> actDate = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria,
                line.replace("27.04.2024 | 14.05.2024", "27.04.2024 | 27.04.2024"), Form3FormTest.HEADER), List.class).get(0);
        assertEquals(Form3Rows.REASON_NO_DOCS, actDate.get("к15"), String.valueOf(actDate.get("к20")));
        assertTrue(String.valueOf(actDate.get("к20")).contains("распознанный скан «Заявка №104 Акт №б-н от 27.04.24.pdf» заявки/спецификации "
                + "строки: не совпали сумма и дата подписания (правило 2: дата подписания в форме 27.04.2024, документ — штамп ЭДО 14.05.2024; "
                + "сумма формы 22849905.00, документ — 6961205.00)"), String.valueOf(actDate.get("к20")));
    }

    @Test
    void numberedScannedActTakesAmountFromFormWithNote() throws Exception {
        // правило 1: акт с номером найден по номеру и дате акта и по дате подписания, сумма скана расходится с формой —
        // берётся сумма формы с пометкой
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка №104 Акт №5 от 27.04.24.pdf",
                Form3ActsTest.ALFA_ACT_OCR.replace("22 849 905,00", "6 961 205,00"))));
        String line = FORM_LINE.replace("ПАО Сбербанк", "АО «АЛЬФА-БАНК»")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "Договор №АБ-С-ИТ-2020 от 03.02.2020 | Заявка 104 от 15.04.2024 | Акт №5 от 27.04.2024 | 14.05.2024")
                .replace("2495000", "22849905");

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, line,
                Form3FormTest.HEADER), List.class).get(0);

        assertEquals("22849905.00", row.get("к10"));
        assertTrue(String.valueOf(row.get("к20")).contains("в распознанном скане акта не найдена, скан даёт 6961205.00"));
    }

    @Test
    void actRowTakesTechnologiesFromOrderAndAct() throws Exception {
        // заявка упоминает iOS, акт — Android: оба документа доказательны
        String order = "[РАСПОЗНАНО] Документ «Заявка №10 от 08.04.2024.pdf»:\nЗаявка № 10 от 08.04.2024\n"
                + "Бизнес-требования: вывод текста на экране в АМ IOS; разработка на Android";
        String act = "АКТ №1\nсдачи-приемки работ по Заявке №10 от 08.04.2024 к Договору № ШТ-2023 от 21.04.2023\n"
                + "г. Москва 28 июня 2025 г.\nООО «Сентикор», именуемое в дальнейшем «Исполнитель», и АО «АЛЬФА-БАНК», "
                + "именуемое в дальнейшем «Заказчик»\nВыполнены работы: доработка приложения для телефонов на платформе Android\n"
                + "ИТОГО: 48 828 140,00";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка № 10 от 08.04.2024.pdf", order),
                new Form3Ops.Source("АКТ №1 по Заявке №10 от 08.04.24.pdf", act)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | iOS | Раздел 2 | точно" + System.lineSeparator()
                + "Технология 5 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String line = FORM_LINE.replace("ПАО Сбербанк", "АО «АЛЬФА-БАНК»")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "ДОГОВОР № ШТ-2023 от 21 апреля 2023 | Заявка №10 к Договору № ШТ-2023 | АКТ №1 сдачи-приемки работ по Заявке №10 | 28 июня 2025 г.")
                .replace("2495000", "48828140");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("Акт от 28.06.2025 (заявка 10)", row.get("к6"));
        assertEquals("да", row.get("т_iOS"));
        assertEquals("да", row.get("т_Android"));
        assertEquals("да: iOS, Android", row.get("к17"));
        assertEquals("да: Android", row.get("к18"));
        assertEquals("48828140.00", row.get("к10"));
        assertEquals("-", row.get("к15"));
        // мобильность доказана лишь упоминанием платформ — строка помечена для второго мнения агента
        assertEquals("да", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("только по упоминанию платформы"));
    }

    @Test
    void mobileDevelopmentRequiresDeclaredPlatformInForm() throws Exception {
        // заявка 10 Комплекта 3: платформы в тексте есть, но в форме iOS и Android — «Нет» → нет мобильной разработки
        String order = "Заявка № 10 от 08.04.2024\nДоработка мобильного приложения: вывод текста в АМ IOS; разработка на Android";
        String act = "АКТ №1\nсдачи-приемки работ по Заявке №10 от 08.04.2024 к Договору № 4652269 от 05.07.2023\n"
                + "г. Москва 30 июня 2025 г.\nВыполнены работы по заявке\nИТОГО: 2 495 000,00";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка № 10 от 08.04.2024.pdf", order),
                new Form3Ops.Source("АКТ №1 по Заявке №10 от 30.06.25.pdf", act)));
        String criteria = (Form3OpsTest.CRITERIA + "Технология 4 | iOS | Раздел 2 | точно" + System.lineSeparator()
                + "Технология 5 | Android | Раздел 2 | точно" + System.lineSeparator())
                .replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String header = Form3FormTest.HEADER.replace("технологии Java", "технологии iOS").replace("технологии Python", "технологии Android");
        String line = FORM_LINE.replace("не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025 | да | нет",
                "Заявка №10 к Договору № ШТ-2023 | АКТ №1 сдачи-приемки работ по Заявке №10 от 30.06.2025 | 30.06.2025 | нет | нет");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, header), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("нет", row.get("к12"));
        // столбец технологии — по документам (iOS есть в заявке), заявка участника в форме его не обнуляет (письмо 2 Егоровой)
        assertEquals("да", row.get("т_iOS"));
        assertTrue(String.valueOf(row.get("к15")).contains("нет мобильной разработки"), String.valueOf(row.get("к15")));
        assertTrue(String.valueOf(row.get("к20")).contains("мобильная разработка по форме не заявлена"));

        List<?> claimed = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria,
                line.replace("| нет | нет", "| нет | да"), header), List.class);
        assertEquals("да", ((Map<?, ?>) claimed.get(0)).get("к12"));
    }

    @Test
    void technologyClaimedInFormButFoundOnlyInContractIsNo() throws Exception {
        // рамочный договор (форма называет спецификацию) называет Java и Python, участник заявил Java: договор столбцы технологий
        // не заполняет (письма Егоровой 16.09.2026) — обе «нет», договор перечислен в к16, расхождение с заявкой — в аудите
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Договор.pdf", CONTRACT)));
        String line = formLine("4652269 от 05.07.2023", "Спецификация № 5374642 от 27.06.2025", "Акт №7 выполненных работ от 30.06.2025",
                "30.06.2025", "2495000");
        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, line, Form3FormTest.HEADER),
                List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("да: Java, Python", row.get("к16"));
        assertEquals("нет", row.get("т_Java"));
        assertEquals("нет", row.get("т_Python"));
        assertEquals("Подтверждающие документы не найдены", row.get("к15"));
        assertEquals("да", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("заявлено участником в форме, в спецификации/акте не подтверждено: Java"),
                String.valueOf(row.get("к20")));
    }

    /** Строка формы УПД № 0000118724 ({@link Form3OpsTest#UPD_SIGNED}) по договору 4652269 с заданной графой спецификации. */
    private static String updLine(String spec) {
        return formLine("Договор № 4652269 от 05.07.2023", spec, "УПД № 0000118724 от 21.07.2025", "24.07.2025", "1063178,54");
    }

    /** Строка заключения по реестру документов и строке формы с критериями письма «Ошибки с поиском технологий». */
    private static Map<?, ?> letterRow(String registry, String line) throws Exception {
        return (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteriaLetter(), line, Form3FormTest.HEADER), List.class).get(0);
    }

    @Test
    void nonFrameworkContractWithoutSpecificationsCountsContractTechnologies() throws Exception {
        // методика: признаки — «в рамках спецификации/заказа (рамочный договор) или договора (нерамочный договор)»; Комплект 1
        // АксТим, договор с РСХБ «спецификация — не применимо», технологии только в договоре → столбцы «да», сумма зачтена
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Договор.pdf", CONTRACT_THREE)));

        for (String spec : List.of("не применимо", "", "нет", "—", "Отсутствует.")) {
            Map<?, ?> row = letterRow(registry, updLine(spec));
            String audit = String.valueOf(row.get("к20"));

            assertEquals("да", row.get("т_Hadoop"), spec + ": " + audit);
            assertEquals("да", row.get("т_GreenPlum"), spec);
            assertEquals("да", row.get("т_Python"), spec);
            assertEquals("1063178.54", row.get("к14"), spec + ": " + audit);
            assertEquals("-", row.get("к15"), spec);
            assertEquals("да: Hadoop, GreenPlum, Python", row.get("к16"), spec);
            assertEquals("нет", row.get("к17"), spec);
            assertTrue(audit.contains(Form3Rows.NON_FRAMEWORK_NOTE), audit);
            assertFalse(audit.contains("технологии найдены только в договоре"), audit);
        }
    }

    @Test
    void frameworkContractSpecificationWithoutTechnologyKeepsContractTechnologiesUncounted() throws Exception {
        // рамочный договор: спецификация названа в форме и лежит в комплекте, но технологий не называет (R06–R08 АксТим, Hadoop
        // только в договоре) — «технология не найдена», как и без спецификации в комплекте при названной в форме спецификации
        String noTechSpec = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end) (Москва) 47 22620,82 1063 178,54\n", "");
        String withSpec = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", noTechSpec), new Form3Ops.Source("Договор.pdf", CONTRACT_THREE)));
        String withoutSpec = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Договор.pdf", CONTRACT_THREE)));
        String line = updLine("Спецификация № 5374642 от 27.06.2025");

        for (String registry : List.of(withSpec, withoutSpec)) {
            Map<?, ?> row = letterRow(registry, line);
            String audit = String.valueOf(row.get("к20"));

            assertEquals("нет", row.get("т_Hadoop"), audit);
            assertEquals("0", row.get("к14"), audit);
            assertEquals(Form3Rows.REASON_NO_TECH, row.get("к15"), audit);
            assertEquals("да: Hadoop, GreenPlum, Python", row.get("к16"));
            assertTrue(audit.contains("технологии найдены только в договоре (Hadoop, GreenPlum, Python)"), audit);
            assertFalse(audit.contains(Form3Rows.NON_FRAMEWORK_NOTE), audit);
        }
    }

    @Test
    void notApplicableSpecificationColumnKeepsRuleWhenKitHasSpecificationOfContract() throws Exception {
        // графа «не применимо», но в комплекте есть спецификация к договору строки (не привязанная к УПД: другая сумма) —
        // договор рамочный, поведение прежнее; спецификация без разобранного номера договора относится к нему по папке
        String otherStage = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end) (Москва) 47 22620,82 1063 178,54\n", "")
                .replace("1063178,54", "2000000,00");
        String byNumber = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", otherStage), new Form3Ops.Source("Договор.pdf", CONTRACT_THREE)));
        String byFolder = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Договор 4652269 от 05.07.2023/Спецификация № 5374642.pdf",
                        otherStage.replace("к Договору №4652269 на разработку", "к рамочному договору на разработку")),
                new Form3Ops.Source("Договор.pdf", CONTRACT_THREE)));

        for (String registry : List.of(byNumber, byFolder)) {
            Map<?, ?> row = letterRow(registry, updLine("не применимо"));
            String audit = String.valueOf(row.get("к20"));

            assertEquals("нет", row.get("т_GreenPlum"), audit);
            assertEquals("0", row.get("к14"), audit);
            assertEquals(Form3Rows.REASON_NO_TECH, row.get("к15"), audit);
            assertFalse(audit.contains(Form3Rows.NON_FRAMEWORK_NOTE), audit);
        }
    }

    @Test
    void formRowCountedWhenSpecificationConfirmsStageAmount() throws Exception {
        // акта этапа в комплекте нет, но спецификация того же договора содержит сумму этапа — строка засчитывается
        String spec = """
                Спецификация на разработку программного обеспечения № 5374642 к Договору №4652269 от 05.07.2023
                1. Предмет Спецификации: Исполнитель выполняет работы по разработке сервисов на Java
                Этап 2 Стоимость 2495000,00 Подпись банка 26.06.2025 17:37:40
                """;
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Спецификация № 5374642.pdf", spec)));
        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, FORM_LINE, Form3FormTest.HEADER),
                List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("2495000.00", row.get("к14"));
        assertEquals("-", row.get("к15"));
        assertEquals("да", row.get("т_Java"));
        assertEquals("", row.get("агенту"));
        assertTrue(String.valueOf(row.get("к20")).contains("акт/УПД не найден, сумма этапа подтверждена спецификацией"));
    }

    @Test
    void formRowIsLinkedToAlfaOrderAndActByNumber() throws Exception {
        // Альфа-Банк: заявка (заказ) по номеру из формы, акт — правилом 2 по дате подписи штампа ЭДО и сумме
        String order = "[РАСПОЗНАНО] Документ «Заявка №104 от 15.04.2024.pdf»:\nЗаявка № 104 от 15.04.2024 на разработку iOS-приложения";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Заявка №104 от 15.04.2024.pdf", order),
                new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf", Form3ActsTest.ALFA_ACT_OCR)));
        String criteria = Form3OpsTest.CRITERIA + "Технология 4 | iOS | Раздел 2 | точно" + System.lineSeparator()
                + "Технология 5 | Android | Раздел 2 | точно" + System.lineSeparator();
        criteria = criteria.replace("стоимость работ по всей спецификации/заказу не засчитывается", "закупается мобильная разработка");
        String line = FORM_LINE.replace("ПАО Сбербанк", "АО \"АЛЬФА-БАНК\"")
                .replace("4652269 от 05.07.2023 | не применимо | Акт №7 выполненных работ от 30.06.2025 | 30.06.2025",
                        "Договор №АБ-С-ИТ-2020 от 03.02.2020 | Заявка 104 от 15.04.2024 | Акт от 27.04.2024 | 14.05.2024")
                .replace("2495000", "22849905");

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria, line, Form3FormTest.HEADER), List.class);
        Map<?, ?> row = (Map<?, ?>) rows.get(0);

        assertEquals("Акт от 27.04.2024 (заявка 104)", row.get("к6"));
        assertEquals("заявка 104 от 15.04.2024", row.get("к5"));
        // iOS — из заявки, Android — из акта: заявка и акт равно доказательны
        assertEquals("да", row.get("т_iOS"));
        assertEquals("да", row.get("т_Android"));
        assertEquals("да: iOS", row.get("к17"));
        assertEquals("да: Android", row.get("к18"));
        assertEquals("да", row.get("к12"));
        assertEquals("нет", row.get("к9"));
        assertEquals("Акт не в периоде", row.get("к15"));
    }

    @Test
    void largeCompaniesAreInRatingButSubsidiariesAreNot() throws Exception {
        Map<?, ?> metro = formRows(Form3Ops.registry(List.of()), FORM_LINE.replace("ПАО Сбербанк", "ООО «МЕТРО Кэш энд Керри»")).get(0);
        Map<?, ?> lukoil = formRows(Form3Ops.registry(List.of()), FORM_LINE.replace("ПАО Сбербанк", "ПАО «ЛУКОЙЛ»")).get(0);
        Map<?, ?> subsidiary = formRows(Form3Ops.registry(List.of()), FORM_LINE.replace("ПАО Сбербанк", "ООО «ЛУКОЙЛ-Интер-Кард»")).get(0);

        assertEquals("да", metro.get("к11"));
        assertEquals("да", lukoil.get("к11"));
        assertEquals("нет", subsidiary.get("к11"));
    }

    @Test
    void customerOutsideRatingIsStopFactorForFormRow() throws Exception {
        String line = FORM_LINE.replace("ПАО Сбербанк", "ООО «ЛУКОЙЛ-Интер-Кард»");

        Map<?, ?> row = formRows(Form3Ops.registry(List.of()), line).get(0);

        assertEquals("нет", row.get("к11"));
        assertEquals("-", row.get("к8"));
        assertEquals("-", row.get("к10"));
        assertEquals("-", row.get("к12"));
        assertEquals("-", row.get("т_Python"));
        assertEquals("-", row.get("к19"));
        assertEquals("0", row.get("к14"));
        assertEquals("Заказчик не в рейтинге", row.get("к15"));
        assertEquals("", row.get("агенту"));
    }

    @Test
    void customerOutsideRatingKeepsSingleReasonWhenScansAreNotRecognizedAndContractsAreMissing() throws Exception {
        // письмо Егоровой «Ошибка выполнения», Комплект 4 без OCR: все документы — маркеры ручной проверки, договоров нет,
        // опция «без договора не засчитывать» включена. Заказчики вне рейтинга — причина одна, строки агенту не уходят
        String marker = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «%s» не распознан: PDF без текстового слоя (скан). "
                + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
        List<Form3Ops.Source> sources = List.of("1 Акт №132.pdf", "Акт №1.pdf", "Договор ЛИКАРД.pdf", "_Договор (1 часть).pdf").stream()
                .map(name -> new Form3Ops.Source(name, String.format(marker, name))).toList();
        String form = "ООО \"ЭЦС\" | ООО \"ЭЦС\" | не применимо | нет | ООО «ЛУКОЙЛ-Интер-Кард» | не применимо | ООО «ЛУКОЙЛ-Интер-Кард»"
                + " | № F637/45 от 30.01.2025 | не применимо | Акт №1 выполненных работ от 28.02.2025 | 28.02.2025 | да | да | 2495000,00"
                + " | не применимо | не применимо | Раздел 5 Договора (стр. 16-20), п. 5.1-5.3\n"
                + "ООО \"ЭЦС\" | ООО \"ЭЦС\" | не применимо | нет | ПАО «Группа Ренессанс Страхование» | не применимо"
                + " | ПАО «Группа Ренессанс Страхование» | Договор № 5436549272/А4 от 15.05.2025 | не применимо"
                + " | Акт сдачи-приемки выполненных работ № б/н от 05.06.2025 | 05.06.2025 | да | да | 2250000,00 | не применимо"
                + " | не применимо | Разделы 1, 2, 4.1 ТЗ (стр. 2-5, 12)";

        List<?> rows = MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.WITHOUT_CONTRACT, "true"), Form3Ops.registry(sources),
                Form3OpsTest.CRITERIA, form, Form3FormTest.HEADER), List.class);

        assertEquals(2, rows.size());
        for (Object item : rows) {
            Map<?, ?> row = (Map<?, ?>) item;
            assertEquals("нет", row.get("к11"));
            assertEquals("0", row.get(Form3Rows.CONTRACTS));
            assertEquals("0", row.get("к14"));
            assertEquals(Form3Rows.REASON_RATING, row.get("к15"));
            assertEquals("", row.get("агенту"));
        }
    }

    @Test
    void formRowsMatchUpdByNumberThenBySumAndDateAndDropUpdOutsideForm() throws Exception {
        String partial = Form3OpsTest.UPD_SIGNED.replace("0000118724", "0000118725").replace("1063178,54", "500000,00");
        String outside = Form3OpsTest.UPD_SIGNED.replace("0000118724", "0000118726");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("u1.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("u2.pdf", partial), new Form3Ops.Source("u3.pdf", outside),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A)));
        // вторая строка: номер заказа вместо номера УПД, объединённые ячейки пусты — заказчик наследуется
        String form = FORM_LINE.replace("Акт №7 выполненных работ от 30.06.2025 | 30.06.2025", "УПД № 0000118724 от 21.07.2025 | 24.07.2025")
                .replace("2495000", "1063178,54")
                + "\n |  |  |  |  |  |  |  |  | УПД № 100000049520 от 21.07.2025 | 24.07.2025 | да | нет | 500000,00 |  |  | ";

        List<Map<?, ?>> rows = formRows(registry, form);

        assertEquals(2, rows.size());
        assertEquals("УПД 0000118724 от 21.07.2025", rows.get(0).get("к6"));
        assertEquals("да", rows.get(0).get("т_Java"));
        assertEquals("-", rows.get(0).get("к15"));
        assertEquals("УПД 0000118725 от 21.07.2025", rows.get(1).get("к6"));
        assertEquals("ПАО Сбербанк", rows.get(1).get("к3"));
        assertEquals("500000.00", rows.get(1).get("к10"));
        // правило 1 для строк с номером: первая — все три признака, вторая (номер заказа вместо номера УПД) — два из трёх
        assertTrue(String.valueOf(rows.get(0).get("к20")).contains("правило 1: документ найден по признакам «2 из 3» (3 из 3)"),
                String.valueOf(rows.get(0).get("к20")));
        // штампа ЭДО у УПД нет: дата подписания сравнена с датой приёмки, источник — в аудите
        assertTrue(String.valueOf(rows.get(0).get("к20")).contains("дата подписания — да (дата приёмки УПД 24.07.2025, штампа нет)"),
                String.valueOf(rows.get(0).get("к20")));
        assertTrue(String.valueOf(rows.get(1).get("к20")).contains("правило 1: документ найден по признакам «2 из 3» (2 из 3)"),
                String.valueOf(rows.get(1).get("к20")));
    }

    @Test
    void formHintPicksSpecificationAmongCandidates() throws Exception {
        // сумма этапа совпадает в двух спецификациях; форма участника указывает одну из них — берётся она
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A), new Form3Ops.Source("specB.pdf", Form3OpsTest.SPEC_B)));
        String form = "ООО | Спецификация 5284130 от 28.03.2025 | УПД № 0000118724 от 21.07.2025 | 24.07.2025 | 1063178,54";

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form), List.class).get(0);

        assertEquals("5284130 от 28.03.2025", row.get("к5"));
        assertEquals("нет", row.get("т_Java"));
        assertEquals("да", row.get("т_Python"));
        assertTrue(String.valueOf(row.get("к20")).contains("спецификация выбрана по форме участника"));
    }

    @Test
    void formHintSuppliesSpecificationWhenSumsDoNotMatch() throws Exception {
        // частичный акт: сумма УПД не равна сумме этапа; форма (по сумме и дате УПД) называет спецификацию
        String upd = Form3OpsTest.UPD_SIGNED.replace("1063178,54", "500000,00");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", upd),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A)));
        String form = "ООО | Спецификация 5374642 от 27.06.2025 | УПД № 100000049520 от 21.07.2025 | 24.07.2025 | 500000,00";

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form), List.class).get(0);

        assertEquals("5374642 от 27.06.2025", row.get("к5"));
        assertEquals("да", row.get("т_Java"));
        assertTrue(String.valueOf(row.get("к20")).contains("взята из формы участника"));
    }

    @Test
    void rowsWithoutContractAreNotCountedWhenOptionEnabled() throws Exception {
        // Комплект 8 Егоровой «без договора»: только спецификации и акты — опыт не засчитывается
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_WITH_ZNZO), new Form3Ops.Source("Отчет.pdf", REPORT)));
        String withContract = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_WITH_ZNZO),
                new Form3Ops.Source("Договор.pdf", CONTRACT), new Form3Ops.Source("Отчет.pdf", REPORT)));
        Map<String, Object> option = Map.of("без_договора_не_засчитывать", "true");

        Map<?, ?> denied = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(option, registry, Form3OpsTest.CRITERIA), List.class).get(0);
        Map<?, ?> legacy = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA), List.class).get(0);
        Map<?, ?> counted = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(option, withContract, Form3OpsTest.CRITERIA), List.class).get(0);

        // заказчик в рейтинге — правило «без договора не засчитывать» действует как прежде
        assertEquals("да", denied.get("к11"));
        assertEquals("0", denied.get("к14"));
        assertTrue(String.valueOf(denied.get("к15")).startsWith(Form3Rows.REASON_NO_DOCS), String.valueOf(denied.get("к15")));
        assertEquals("да", denied.get("агенту"));
        assertEquals("0", denied.get(Form3Rows.CONTRACTS));
        assertEquals("1063178.54", legacy.get("к14"));
        assertEquals("1063178.54", counted.get("к14"));
        assertEquals("-", counted.get("к15"));
    }

    @Test
    void auditExplainsThatFoundDocumentIsNotCountedWithoutContract() throws Exception {
        // прогон F3-P7 (частичный архив Датафьюжн без договора): УПД 0000118724 найден «3 из 3», причина — общая
        // «Подтверждающие документы не найдены»; аудит поясняет, что незачёт из-за договора. Строка, чей УПД не найден, — без пометки
        String header = "Наименование компании | Наименование Исполниеля по договору | Потверждение взаимосвязи (аффилированости) с ведущим партнером "
                + " коллективного участника | Наименование компании заказчика | Вариант 1. Наименование рейтинга и номер позиции заказчика по договору"
                + " А. ТОП-25 Рейтинга банков по объему активов на 1 ноября 2024 года https://riarating.ru/images/63027/51/630275133.pdf"
                + " | Вариант 2.  Опыт выполнения работ для одного Заказчика  Указать наименование компании заказчика | Реквизиты договора"
                + " | Реквизиты спецификации/ заказа к договору | Реквизиты акта выполенных работ | Дата подписания акта (ов)/ выполенных работ / УПД"
                + " | В рамках выполнения работ используются инструменты и технологии Java | В рамках выполнения работ используются инструменты и технологии Javascript"
                + " | В рамках выполнения работ используются инструменты и технологии Python | В рамках выполнения работ используется методология DevOps"
                + " | В рамках выполнения работ используются инструменты и технологии Go (Golang) | Сумма выполненных работ по акту/УПД"
                + " | Наименование компании заказчика | Реквизиты договора между генеральным подрядчиком и заказчиком работ | Дополнительная информация";
        String line = "ООО \"Датафьюжн\" | ООО \"Датафьюжн\" | Выписка из ЕГРЮЛ | ПАО Сбербанк | 1 место в ТОП-25 Рейтинга банков по объему активов на 1 ноября "
                + "2024 года | Не применимо | Договор на разработку/модификацию программного обеспечения№ 4652269 от 05.07.2023 | Спецификация %1$s"
                + " | УПД № %2$s от %3$s Отчет о выполненных работах к ЗНЗО № %4$s от %3$s | %5$s | Да | Нет | Нет | Нет | Нет | %6$s | Не применимо"
                + " | Не применимо | п.2 Отчета о выполненных работах к ЗНЗО № %4$s";
        String form = String.format(line, "5374642 от 27.06.2025", "0000118724", "21.07.2025", "100000041790", "24.07.2025", "1063178,54")
                + "\n" + String.format(line, "5374245 от 30.06.2025", "0000133676", "06.10.2025", "100000045742", "07.10.2025", "4682509,74");
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Акты.zip/Акты/ON_NSCHFDOPPR_20250721.pdf", Form3OpsTest.UPD_SIGNED)));
        String note = "; документ найден (УПД 0000118724 от 21.07.2025), " + Form3Rows.WITHOUT_CONTRACT_NOTE;

        List<?> denied = MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.WITHOUT_CONTRACT, "true"), registry, Form3OpsTest.CRITERIA, form, header), List.class);
        List<?> legacy = MAPPER.readValue(Form3Ops.rows(Map.of(), registry, Form3OpsTest.CRITERIA, form, header), List.class);

        Map<?, ?> found = (Map<?, ?>) denied.get(0);
        Map<?, ?> notFound = (Map<?, ?>) denied.get(1);
        assertEquals("УПД 0000118724 от 21.07.2025", found.get("к6"));
        assertEquals("0", found.get("к14"));
        assertTrue(String.valueOf(found.get("к15")).startsWith(Form3Rows.REASON_NO_DOCS), String.valueOf(found.get("к15")));
        assertTrue(String.valueOf(found.get("к20")).endsWith(note), String.valueOf(found.get("к20")));
        assertEquals(Form3Rows.REASON_NO_DOCS, notFound.get("к15"));
        assertFalse(String.valueOf(notFound.get("к20")).contains(Form3Rows.WITHOUT_CONTRACT_NOTE), String.valueOf(notFound.get("к20")));
        assertFalse(String.valueOf(((Map<?, ?>) legacy.get(0)).get("к20")).contains(Form3Rows.WITHOUT_CONTRACT_NOTE));
    }

    @Test
    void auditNamesSpecificationWhenStageAmountIsConfirmedWithoutActAndContract() throws Exception {
        // акта нет, сумму этапа подтверждает спецификация (Комплекты 1 и 6), договора в комплекте нет — в пометке спецификация
        String spec = """
                Спецификация на разработку программного обеспечения № 5374642 к Договору №4652269 от 05.07.2023
                1. Предмет Спецификации: Исполнитель выполняет работы по разработке сервисов на Java
                Этап 2 Стоимость 2495000,00 Подпись банка 26.06.2025 17:37:40
                """;
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("Спецификация № 5374642.pdf", spec)));

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(Form3Rows.WITHOUT_CONTRACT, "true"), registry, Form3OpsTest.CRITERIA,
                FORM_LINE, Form3FormTest.HEADER), List.class).get(0);

        assertEquals("0", row.get("к14"));
        assertEquals(Form3Rows.REASON_NO_DOCS, row.get("к15"));
        assertTrue(String.valueOf(row.get("к20")).endsWith("; документ найден (спецификация " + row.get("к5") + "), " + Form3Rows.WITHOUT_CONTRACT_NOTE),
                String.valueOf(row.get("к20")));
        assertTrue(String.valueOf(row.get("к5")).startsWith("5374642"), String.valueOf(row.get("к5")));
    }

    @Test
    void contractTechnologyDoesNotCountWhenSpecificationNamesOtherRoles() throws Exception {
        // Комплект 9 Егоровой: Python есть только в ставках рамочного договора, спецификация называет «Главный разработчик GreenPlum».
        // После писем 16.09.2026 договор не засчитывает технологию и без ролей в спецификации — правило ролей противоречий не даёт,
        // остаётся пояснением в аудите
        String pythonOnly = Form3OpsTest.CRITERIA.replace("Технология 1 | Java | Раздел 2 | точно", "Технология 1 | Python | Раздел 2 | точно")
                .replace("Технология 2 | Go (Golang) | Раздел 2 | точно" + System.lineSeparator(), "")
                .replace("Технология 2 | Go (Golang) | Раздел 2 | точно\n", "")
                .replace("Технология 3 | Python | Раздел 2 | точно", "");
        String greenplumSpec = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end)", "Главный разработчик GreenPlum");
        String noRolesSpec = Form3OpsTest.SPEC_A.replace("Главный разработчик Java (back end) (Москва) 47 22620,82 1063 178,54\n", "");
        String withRoles = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация.pdf", greenplumSpec), new Form3Ops.Source("Договор.pdf", CONTRACT)));
        String withoutRoles = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("Спецификация.pdf", noRolesSpec), new Form3Ops.Source("Договор.pdf", CONTRACT)));

        Map<?, ?> denied = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), withRoles, pythonOnly), List.class).get(0);
        Map<?, ?> noRoles = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), withoutRoles, pythonOnly), List.class).get(0);

        assertEquals("0", denied.get("к14"));
        assertTrue(String.valueOf(denied.get("к15")).contains("технология не найдена"), String.valueOf(denied.get("к15")));
        assertEquals("да: Python", denied.get("к16"));
        assertTrue(String.valueOf(denied.get("к20")).contains("спецификация называет роли исполнителей (GreenPlum)"), String.valueOf(denied.get("к20")));
        assertTrue(String.valueOf(denied.get("к20")).contains("технологии найдены только в договоре (Python)"), String.valueOf(denied.get("к20")));
        assertEquals("0", noRoles.get("к14"));
        assertEquals("нет", noRoles.get("т_Python"));
        assertEquals(Form3Rows.REASON_NO_TECH, noRoles.get("к15"));
        assertTrue(String.valueOf(noRoles.get("к20")).contains("технологии найдены только в договоре (Python)"), String.valueOf(noRoles.get("к20")));
    }

    @Test
    void reportOfAnotherSpecificationIsNotLinkedBySum() throws Exception {
        // отчёт чужой спецификации с той же суммой этапа не должен приносить свои технологии
        String foreign = "ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ К Спецификации на модификацию № 5472112 от 09.10.2025 "
                + "к договору № 4652269 Выполнена разработка на JavaScript. Стоимость 1063178,54";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", Form3OpsTest.UPD_SIGNED),
                new Form3Ops.Source("specA.pdf", Form3OpsTest.SPEC_A), new Form3Ops.Source("Отчет.pdf", foreign)));
        String criteria = Form3OpsTest.CRITERIA + "Технология 4 | JavaScript | Раздел 2 | точно" + System.lineSeparator();

        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, criteria), List.class).get(0);

        assertEquals("нет", row.get("т_JavaScript"));
        assertTrue(String.valueOf(row.get("к20")).contains("отчётов 0"));
    }
}
