package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * План агента (Д3, регресс 16.09.2026): пункты-вердикты отбрасываются, пункты по находкам сводятся к номерам находок,
 * раздутый план заменяется одним пунктом, ревизору план не строится. S1-D05 (agent_review): 150 пунктов «НАХОДКА №N:
 * ПОДТВЕРЖДАЮ/РАСХОЖДЕНИЕ — …», агент их копировал (51 строка без мнения); F3-K1 (agent): 12 пунктов-вопросов — остаются;
 * ПЗД Z014/Z007 (agent h3): 15 и 41 пункт по находкам — остаются номерами находок.
 */
class ScenarioExecutorProcessingNodePlanTest {

    /** Пункты плана a2 прогона S1-D05-CTRL (дословно). */
    private static final List<String> D05_VERDICTS = List.of(
            "НАХОДКА №2: ПОДТВЕРЖДАЮ — категория закупки точно соответствует документации",
            "НАХОДКА №17: РАСХОЖДЕНИЕ — правильно: «акты/УПД подписаны не ранее 12 (двенадцати) месяцев до даты публикации "
                    + "закупочной процедуры»; основание: «Период опыта по методике оценки — календарные даты» (Расчёт кодом)",
            "НАХОДКА №21: ПОДТВЕРЖДАЮ — признак «Тестирование» точно соответствует документации",
            "НАХОДКА №38: РАСХОЖДЕНИЕ — правильно: «Нет»; основание: «Минимальный объём сопоставимого опыта (в рублях)» "
                    + "не указан в документации");

    /** План a1 прогона F3-K1 (дословно). */
    private static final List<String> F3_K1_PLAN = List.of("Для каждой проблемной строки: № строки", "Участник (к1)",
            "Заказчик (к3)", "Договор (к4)", "Спецификация/заказ (к5)", "Акт/УПД (к6)", "Дата акта (к7)", "Сумма (к10)",
            "Период опыта по методике оценки (календарные даты)", "Технология 1 (Hadoop)", "Технология 2 (GreenPlum)",
            "Технология 3 (Python)");

    private static final String NOTEBOOK = "{\"записи\": [{\"пункт\": 1, \"название\": \"НМЦ\", \"значение\": \"1\", "
            + "\"цитата\": \"НМЦД 1\", \"документ\": \"извещение.pdf\"}]}";

    private GigaChatClient gigaChatClient;
    private EmbeddingService embeddingService;
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    @BeforeEach
    void setUp() {
        gigaChatClient = mock(GigaChatClient.class);
        embeddingService = mock(EmbeddingService.class);
    }

    @Test
    void verdictItemsAreDroppedFindingsReducedAndQuestionsKept() {
        assertEquals(List.of("НАХОДКА №2", "НАХОДКА №17", "НАХОДКА №21", "НАХОДКА №38"), ScenarioExecutorProcessingNode.boundedPlan(D05_VERDICTS));
        assertEquals(F3_K1_PLAN, ScenarioExecutorProcessingNode.boundedPlan(F3_K1_PLAN));
        List<String> mixed = new ArrayList<>(verdictsWithoutNumbers());
        mixed.add("Есть ли расхождение цены договора и протокола");
        mixed.add("Находка №3: подтверждаю — совпадает с документом");
        mixed.add("НАХОДКА №3: ПОДТВЕРЖДАЮ — повтор");
        mixed.add("ВОЗРАЖАЮ: сумма акта не совпадает");
        mixed.add("Для каждой находки — номер строки");
        mixed.add("Проверить НАХОДКА №5 из свода");
        assertEquals(List.of("Есть ли расхождение цены договора и протокола", "НАХОДКА №3", "Для каждой находки — номер строки"),
                ScenarioExecutorProcessingNode.boundedPlan(mixed));
    }

    @Test
    void verdictWordsNeedCyrillicWordBoundaries() {
        // явные границы по кириллице вместо \b: с JDK 19 \b учитывает только ASCII-буквы
        assertTrue(ScenarioExecutorProcessingNode.PLAN_VERDICT.matcher("«ПОДТВЕРЖДАЮ» — сумма совпадает").find());
        assertTrue(ScenarioExecutorProcessingNode.PLAN_VERDICT.matcher("Вердикт: возражаю, дата другая").find());
        assertTrue(ScenarioExecutorProcessingNode.PLAN_VERDICT.matcher("РАСХОЖДЕНИЕ: в задании 5, в документе 6").find());
        assertFalse(ScenarioExecutorProcessingNode.PLAN_VERDICT.matcher("Подтверждающий документ (акт, УПД)").find());
        assertFalse(ScenarioExecutorProcessingNode.PLAN_VERDICT.matcher("РАСХОЖДЕНИЯ сумм договора и акта").find());
        assertFalse(ScenarioExecutorProcessingNode.PLAN_VERDICT.matcher("Найти расхождение сумм").find());
    }

    @Test
    void realPzdFindingPlansKeepEveryFinding() throws IOException {
        // ПЗД Z014 и Z007, агент h3 «Агент нормы 223-ФЗ»: план — «НАХОДКА №N: <норма>: «цитата» — применимость» по каждой
        // находке (15 и 41 пункт); прежде план сводился к «Выполнить задание целиком» и добор не видел пропущенных находок
        for (int count : new int[]{15, 41}) {
            List<String> parsed = resourceLines(count == 15 ? "regress/pzd-z014-h3-plan.txt" : "regress/pzd-z007-h3-plan.txt");
            List<String> expected = IntStream.rangeClosed(1, count).mapToObj(n -> "НАХОДКА №" + n).toList();

            assertEquals(count, parsed.size());
            assertEquals(expected, ScenarioExecutorProcessingNode.boundedPlan(parsed));
            List<String> bloated = new ArrayList<>(parsed);
            bloated.addAll(F3_K1_PLAN);
            bloated.add("Технология 4 (Java)");
            // 13 вопросов — перебор: остаются пункты по находкам
            assertEquals(expected, ScenarioExecutorProcessingNode.boundedPlan(bloated));
        }
    }

    @Test
    void planLongerThanLimitBecomesWholeTask() {
        List<String> bloated = new ArrayList<>(F3_K1_PLAN);
        bloated.add("Технология 4 (Java)");

        assertEquals(List.of(ScenarioExecutorProcessingNode.WHOLE_TASK_PLAN_ITEM), ScenarioExecutorProcessingNode.boundedPlan(bloated));
        List<String> withVerdicts = new ArrayList<>(bloated);
        withVerdicts.removeIf(item -> item.startsWith("Технология 4"));
        withVerdicts.addAll(verdictsWithoutNumbers());
        // вердикты отброшены до подсчёта: 12 вопросов — план остаётся
        assertEquals(F3_K1_PLAN, ScenarioExecutorProcessingNode.boundedPlan(withVerdicts));
    }

    @Test
    void agentModePlanFromModelWithoutReadyVerdicts() throws Exception {
        List<String> answer = new ArrayList<>(D05_VERDICTS);
        answer.add("Найти НМЦ");
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn(new ObjectMapper().writeValueAsString(answer)).thenReturn("[]").thenReturn("Итог");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(NOTEBOOK, Map.of()));

        executor("agent").execute(sink);

        ArgumentCaptor<List<Map<String, String>>> messages = captor();
        verify(gigaChatClient, atLeastOnce()).chatCompletionWithTools(messages.capture(), anyList(), any(), any());
        String system = messages.getAllValues().get(0).get(0).get("content");
        assertTrue(system.contains("ПЛАН (чек-лист, закрой КАЖДЫЙ пункт):\n1. НАХОДКА №2\n2. НАХОДКА №17\n3. НАХОДКА №21\n4. НАХОДКА №38\n"
                + "5. Найти НМЦ\n\n"), system);
        assertFalse(system.contains("ПОДТВЕРЖДАЮ"), system);
        assertFalse(system.contains("РАСХОЖДЕНИЕ — правильно"), system);
    }

    @Test
    void findingPlanIsNotRemembered() throws Exception {
        var memory = mock(AgentMemoryService.class);
        when(memory.lessonsForScenario(any(), any())).thenReturn(List.of());
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn(new ObjectMapper().writeValueAsString(D05_VERDICTS)).thenReturn("[]").thenReturn("Итог");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(NOTEBOOK, Map.of()));
        var executor = executor("agent");
        executor.setAgentMemory(memory);

        executor.execute(sink);

        verify(memory, never()).savePlan(any(), any(), anyList());
    }

    @Test
    void agentModeOnlyVerdictsGivesWholeTaskPlan() throws Exception {
        when(gigaChatClient.chatCompletion(anyList(), any(), any()))
                .thenReturn(new ObjectMapper().writeValueAsString(verdictsWithoutNumbers())).thenReturn("[]").thenReturn("Итог");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(NOTEBOOK, Map.of()));

        executor("agent").execute(sink);

        assertTrue(toolLoopSystem().contains("ПЛАН (чек-лист, закрой КАЖДЫЙ пункт):\n1. Выполнить задание целиком\n\n"));
    }

    @Test
    void rememberedPlanWithVerdictsIsFiltered() {
        var memory = mock(AgentMemoryService.class);
        when(memory.lessonsForScenario(any(), any())).thenReturn(List.of());
        List<String> remembered = new ArrayList<>(D05_VERDICTS);
        remembered.add("Найти НМЦ");
        when(memory.findPlan(any(), any())).thenReturn(remembered);
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("[]").thenReturn("Итог");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult(NOTEBOOK, Map.of()));
        var executor = executor("agent");
        executor.setAgentMemory(memory);

        executor.execute(sink);

        assertTrue(toolLoopSystem().contains("ПЛАН (чек-лист, закрой КАЖДЫЙ пункт):\n1. Найти НМЦ\n\n"));
        ArgumentCaptor<List<Map<String, String>>> plain = captor();
        verify(gigaChatClient, times(2)).chatCompletion(plain.capture(), any(), any());
        assertFalse(plain.getAllValues().get(0).get(0).get("content").contains("чек-лист"));
    }

    @Test
    void reviewerGetsNoPlanCallAndNoMemoryPlan() {
        var memory = mock(AgentMemoryService.class);
        when(memory.lessonsForScenario(any(), any())).thenReturn(List.of());
        when(gigaChatClient.chatCompletion(anyList(), any(), any())).thenReturn("[]");
        when(gigaChatClient.chatCompletionWithTools(anyList(), anyList(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("НАХОДКА №2: ПОДТВЕРЖДАЮ — НМЦД 1 (извещение.pdf)", Map.of()));
        var executor = executor("agent_review");
        executor.setAgentMemory(memory);

        String result = executor.execute(sink);

        assertEquals("НАХОДКА №2: ПОДТВЕРЖДАЮ — НМЦД 1 (извещение.pdf)", result);
        verify(memory, never()).findPlan(any(), any());
        verify(memory, never()).savePlan(any(), any(), anyList());
        ArgumentCaptor<List<Map<String, String>>> plain = captor();
        verify(gigaChatClient, times(1)).chatCompletion(plain.capture(), any(), any());
        assertTrue(plain.getValue().get(0).get("content").contains("\n=== ПЛАН ===\n1. Выполнить задание целиком\n"));
        String system = toolLoopSystem();
        assertTrue(system.contains("ПЛАН (чек-лист, закрой КАЖДЫЙ пункт):\n1. Выполнить задание целиком\n\n"), system);
        assertTrue(system.contains("ПРОВЕРЯЮЩИЙ"), system);
    }

    private ScenarioExecutorProcessingNode executor(String mode) {
        var nodeDto = NodeDto.builder()
                .id("a2")
                .type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label("Агент").prompt("Сверь находки с документацией").mode(mode).build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(nodeDto), List.of()));
        graph.setRunnerUserId("user-1");
        graph.addDocs(List.of("Извещение: НМЦД 1 руб."), List.of("извещение.pdf"));
        var node = graph.getNodeMap().get("a2");
        node.getDocList().add("DOC_1");
        return new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
    }

    /** Пункты-вердикты D05 без номеров находок: «ПОДТВЕРЖДАЮ — …», «РАСХОЖДЕНИЕ — правильно: …». */
    private static List<String> verdictsWithoutNumbers() {
        return D05_VERDICTS.stream().map(item -> item.replaceFirst("^НАХОДКА №\\d+: ", "")).toList();
    }

    private static List<String> resourceLines(String name) throws IOException {
        try (InputStream in = ScenarioExecutorProcessingNodePlanTest.class.getClassLoader().getResourceAsStream(name)) {
            assertNotNull(in, name);
            return new String(in.readAllBytes(), StandardCharsets.UTF_8).lines().filter(line -> !line.isBlank()).toList();
        }
    }

    private String toolLoopSystem() {
        ArgumentCaptor<List<Map<String, String>>> messages = captor();
        verify(gigaChatClient, times(1)).chatCompletionWithTools(messages.capture(), anyList(), any(), any());
        return messages.getValue().get(0).get("content");
    }

    @SuppressWarnings("unchecked")
    private static ArgumentCaptor<List<Map<String, String>>> captor() {
        return ArgumentCaptor.forClass(List.class);
    }
}
