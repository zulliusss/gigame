package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты операции «даты_из_периода»: календарные даты периода опыта из формулировки и даты подачи заявок.
 */
class PeriodDatesOpsTest {

    private static final String QUAL = "Период опыта участника по квалификационным требованиям";
    private static final String METHOD = "Период опыта по методике оценки";
    private static final String START = "Дата начала срока подачи заявок";
    private static final String END = "Дата окончания срока подачи заявок";

    private static Map<String, Object> row(String criterion, String value) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("критерий", criterion);
        m.put("значение", value);
        m.put("источник", "модель");
        return m;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> at(List<Object> rows, int i) {
        return (Map<String, Object>) rows.get(i);
    }

    private static List<Object> rows(String qualWording, String qualDates, String methodWording, String methodDates) {
        List<Object> rows = new ArrayList<>();
        rows.add(row(START, "17.09.2025"));
        rows.add(row(END, "24.09.2025 18-00 (время московское)"));
        rows.add(row(QUAL, qualWording));
        rows.add(row(QUAL + " — календарные даты", qualDates));
        rows.add(row(METHOD, methodWording));
        rows.add(row(METHOD + " — календарные даты", methodDates));
        return rows;
    }

    @Test
    void replacesModelDatesBySubmissionStartMinusTerm() {
        // ЗП 8100286906: модель перенесла даты из примера промпта — «с 08.04.2025 по 08.10.2025»
        List<Object> rows = rows("за последние 3 (три) года до даты публикации документации", "с 08.04.2023 по 08.04.2026",
                "за последние 6 (шесть) месяцев до даты публикации закупочной процедуры", "с 08.04.2025 по 08.10.2025");

        assertEquals(2, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 17.09.2022 по 17.09.2025", at(rows, 3).get("значение"));
        assertEquals("с 17.03.2025 по 17.09.2025", at(rows, 5).get("значение"));
        assertEquals("расчёт кодом по строке «" + METHOD + "»: 6 (шесть) месяцев до даты начала срока подачи заявок (17.09.2025)",
                at(rows, 5).get("источник"));
        assertEquals(PeriodMonthsOps.CALCULATED, at(rows, 5).get("достоверность"));
    }

    @Test
    void countsFromSubmissionEndWhenWordingSaysSo() {
        List<Object> rows = rows("нет", "нет",
                "акты подписаны не ранее 12 (двенадцати) месяцев до даты окончания срока подачи заявок", "?");

        assertEquals(1, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 24.09.2024 по 24.09.2025", at(rows, 5).get("значение"));
        assertEquals("нет", at(rows, 3).get("значение"));
    }

    @Test
    void leavesExplicitOrUnnumberedPeriodsAndMissingBaseDate() {
        List<Object> rows = rows("с 01.01.2021 по 09.09.2024", "с 01.01.2021 по 09.09.2024",
                "не указано в документации, требуется решение закупщика", "не указано в документации, требуется решение закупщика");

        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 01.01.2021 по 09.09.2024", at(rows, 3).get("значение"));
        assertNull(at(rows, 5).get("достоверность"));

        List<Object> noStart = rows("за последние 2 года до даты публикации", "?", "нет", "нет");
        noStart.remove(0);
        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), noStart));
        assertEquals("?", at(noStart, 2).get("значение"));
    }

    /** Строки Шага 1 прогона S1-PR3-CTRL (Приложение 3, ЗП 8100121866): подача заявок с 16.08.2024 по 09.09.2024. */
    private static List<Object> sinceYearRows(String wording, String modelDates) {
        List<Object> rows = new ArrayList<>();
        rows.add(row(START, "16.08.2024"));
        rows.add(row(END, "09.09.2024"));
        rows.add(row(QUAL, wording));
        rows.add(row(QUAL + " — календарные даты", modelDates));
        rows.add(row(QUAL + " — допустимые месяцы", "01.2021, 02.2021, 03.2021, 04.2021, 05.2021, 06.2021, 07.2021, 08.2021, "
                + "09.2021, 10.2021, 11.2021, 12.2021, 01.2022, 02.2022, 03.2022, 04.2022, 05.2022, 06.2022, 07.2022, 08.2022, "
                + "09.2022, 10.2022, 11.2022, 12.2022, 01.2023, 02.2023, 03.2023, 04.2023, 05.2023, 06.2023, 07.2023, 08.2023, "
                + "09.2023, 09.2024"));
        rows.add(row(METHOD, wording));
        rows.add(row(METHOD + " — календарные даты", modelDates));
        return rows;
    }

    @Test
    void sinceYearUntilNowCountsFromJanuaryFirstToSubmissionStart() {
        // S1-PR3-CTRL (16.09.2026): модель поставила «по 09.09.2024» — дату окончания подачи вместо даты начала
        List<Object> rows = sinceYearRows("в период с 2021 г. по настоящее время", "с 01.01.2021 по 09.09.2024");

        assertEquals(2, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 01.01.2021 по 16.08.2024", at(rows, 3).get("значение"));
        assertEquals("с 01.01.2021 по 16.08.2024", at(rows, 6).get("значение"));
        assertEquals("расчёт кодом по строке «" + QUAL + "»: с 2021 г. по настоящее время — с 1 января по дату начала "
                + "срока подачи заявок (16.08.2024)", at(rows, 3).get("источник"));
        assertEquals(PeriodMonthsOps.CALCULATED, at(rows, 6).get("достоверность"));

        // допустимые месяцы строит следующая операция «месяцы_из_дат» по пересчитанным датам: 01.2021–08.2024
        assertEquals(1, PeriodMonthsOps.monthsFromDates(Map.of(), rows));
        String months = String.valueOf(at(rows, 4).get("значение"));
        assertEquals(44, months.split(", ").length);
        assertTrue(months.startsWith("01.2021, 02.2021"), months);
        assertTrue(months.endsWith("07.2024, 08.2024"), months);
    }

    @Test
    void sinceYearUntilCurrentDateVariantsAndGuards() {
        List<Object> rows = sinceYearRows("с 2019 года по текущую дату", "?");
        assertEquals(2, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("с 01.01.2019 по 16.08.2024", at(rows, 3).get("значение"));

        List<Object> compact = sinceYearRows("опыт с 2021г. по настоящее время", "?");
        assertEquals(2, PeriodDatesOps.datesFromPeriod(Map.of(), compact));
        assertEquals("с 01.01.2021 по 16.08.2024", at(compact, 6).get("значение"));

        // без даты начала подачи — как раньше: значение модели не трогается
        List<Object> noStart = sinceYearRows("в период с 2021 г. по настоящее время", "с 01.01.2021 по 09.09.2024");
        noStart.remove(0);
        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), noStart));
        assertEquals("с 01.01.2021 по 09.09.2024", at(noStart, 2).get("значение"));
        assertNull(at(noStart, 2).get("достоверность"));

        // явные даты, год позже начала подачи, «по настоящее время» без года — не трогаются
        List<Object> explicit = sinceYearRows("с 2021 г. по настоящее время (с 01.01.2021 по 16.08.2024)", "?");
        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), explicit));
        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), sinceYearRows("с 2025 г. по настоящее время", "?")));
        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), sinceYearRows("с даты регистрации по настоящее время", "?")));
        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), sinceYearRows("договор с 12021 г. по настоящее время", "?")));
    }

    @Test
    void ignoresAbsurdTermsAndDigitsInsideLongNumbers() {
        List<Object> rows = rows("за последние 300 лет до даты публикации", "?",
                "опыт по договору № 1234 месяца до даты публикации", "?");

        assertEquals(0, PeriodDatesOps.datesFromPeriod(Map.of(), rows));
        assertEquals("?", at(rows, 3).get("значение"));
        assertEquals("?", at(rows, 5).get("значение"));
    }
}
