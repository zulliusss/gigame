package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatModel;
import chat.giga.springai.api.chat.GigaChatApi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.metadata.ChatResponseMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.retry.NonTransientAiException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.ResourceAccessException;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpTimeoutException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Обработка сбоев GigaChat: таймаут ответа — не больше двух повторов, 401 — один повтор, пауза 429 не меньше
 * Retry-After, 413 «Tokens limit» делит контекст, эмбеддинги при ошибке бросают исключение, удаление файла —
 * под ограничителем.
 */
class GigaChatClientFailureHandlingTest {

    private static final List<Map<String, String>> HELLO = List.of(Map.of("role", "user", "content", "Привет"));

    private final ChatModel chatModel = Mockito.mock(ChatModel.class);
    private final EmbeddingModel embeddingModel = Mockito.mock(EmbeddingModel.class);
    private GigaChatClient client;

    @BeforeEach
    void setUp() {
        client = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 3);
        ReflectionTestUtils.setField(client, "retryDelayMillis", 1L);
        ReflectionTestUtils.setField(client, "retryDelay429Millis", 1L);
        ReflectionTestUtils.setField(client, "rateLimitMaxDelayMillis", 50L);
        ReflectionTestUtils.setField(client, "unavailableMaxDelayMillis", 2L);
        ReflectionTestUtils.setField(client, "unavailableMaxWaitMillis", 60_000L);
        ReflectionTestUtils.setField(client, "unauthorizedRetryDelayMillis", 1L);
        ReflectionTestUtils.setField(client, "textMaxLength", 800);
        ReflectionTestUtils.setField(client, "batchSize", 50);
    }

    @Test
    void requestTimeoutIsRetriedAtMostTwice() {
        when(chatModel.call(any(Prompt.class))).thenThrow(requestTimeout());

        GigaChatException ex = assertThrows(GigaChatException.class, () -> client.chatCompletion(HELLO));

        verify(chatModel, times(3)).call(any(Prompt.class));
        assertTrue(ex.getMessage().startsWith(GigaChatRetryPolicy.FAILED + ": ответ не получен за таймаут запроса, "
                + "повторы исчерпаны: 2"), ex.getMessage());
    }

    @Test
    void requestTimeoutRecoversWithinTwoRetries() {
        when(chatModel.call(any(Prompt.class)))
                .thenThrow(requestTimeout())
                .thenThrow(requestTimeout())
                .thenReturn(response("ответ"));

        assertEquals("ответ", client.chatCompletion(HELLO));
        verify(chatModel, times(3)).call(any(Prompt.class));
    }

    @Test
    void connectTimeoutStaysInUnavailableBudget() {
        AtomicInteger calls = new AtomicInteger();
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            if (calls.incrementAndGet() <= 4) {
                throw new ResourceAccessException("I/O error on POST request: HTTP connect timed out",
                        new HttpConnectTimeoutException("HTTP connect timed out"));
            }
            return response("ответ");
        });

        // четыре отказа подряд — больше двух повторов таймаута ответа: соединение ждётся по бюджету недоступности
        assertEquals("ответ", client.chatCompletion(HELLO));
        assertEquals(5, calls.get());
    }

    @Test
    void hardTimeoutAndJdkTimeoutAreRequestTimeouts() {
        assertTrue(GigaChatClient.isRequestTimeout("GigaChatException: " + GigaChatClient.HARD_TIMEOUT
                + ": ответ не получен за 660 с; TimeoutException: null; "));
        assertTrue(GigaChatClient.isRequestTimeout("ResourceAccessException: I/O error: request timed out; "
                + "HttpTimeoutException: request timed out; "));
        // read-timeout Spring 6.2: HttpTimeoutException без текста (сообщение отменённого CompletableFuture — null)
        assertTrue(GigaChatClient.isRequestTimeout("ResourceAccessException: I/O error on POST request for "
                + "\"https://gigachat/api/v1/chat/completions\": null; HttpTimeoutException: null; "));
        assertFalse(GigaChatClient.isRequestTimeout("ResourceAccessException: I/O error: HTTP connect timed out; "
                + "HttpConnectTimeoutException: HTTP connect timed out; "));
        assertFalse(GigaChatClient.isRequestTimeout("TransientAiException: 503 - Service Unavailable; "));
    }

    @Test
    void unauthorizedIsRetriedOnce() {
        when(chatModel.call(any(Prompt.class))).thenThrow(unauthorized());

        GigaChatException ex = assertThrows(GigaChatException.class, () -> client.chatCompletion(HELLO));

        verify(chatModel, times(2)).call(any(Prompt.class));
        assertEquals(GigaChatRetryPolicy.FAILED + ": HTTP 401: Unauthorized", ex.getMessage());
    }

    @Test
    void unauthorizedRecoversAfterSingleRetry() {
        when(chatModel.call(any(Prompt.class))).thenThrow(unauthorized()).thenReturn(response("ответ"));

        assertEquals("ответ", client.chatCompletion(HELLO));
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    @Test
    void rateLimitPauseIsNotShorterThanRetryAfterWithinMaxDelay() {
        ReflectionTestUtils.setField(client, "rateLimitMaxDelayMillis", 5_000L);
        when(chatModel.call(any(Prompt.class))).thenThrow(tooManyRequests(1)).thenReturn(response("ответ"));

        long start = System.currentTimeMillis();
        assertEquals("ответ", client.chatCompletion(HELLO));

        assertTrue(System.currentTimeMillis() - start >= 900, "пауза должна быть не меньше Retry-After=1 с");
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    @Test
    void retryAfterIsCappedByMaxDelay() {
        // Retry-After=60 с при пределе 50 мс: без предела вызов ждал бы минуту; 30 с — запас на загруженный CPU CI
        when(chatModel.call(any(Prompt.class))).thenThrow(tooManyRequests(60)).thenReturn(response("ответ"));

        long start = System.currentTimeMillis();
        assertEquals("ответ", client.chatCompletion(HELLO));

        assertTrue(System.currentTimeMillis() - start < 30_000, "Retry-After сверх rate-limit-max-delay-millis не ждётся");
    }

    @Test
    void tokensLimit413SplitsContextLikeContextTooLong() {
        StringBuilder context = new StringBuilder();
        for (int i = 0; i < 60; i++) {
            context.append("Абзац ").append(i).append(": ").append("текст ".repeat(10)).append("\n\n");
        }
        AtomicInteger calls = new AtomicInteger();
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            if (calls.incrementAndGet() == 1) {
                throw new NonTransientAiException("HTTP 413 - {\"status\":413,\"message\":\"Tokens limit exceeded for index 1\"}");
            }
            return response("часть");
        });

        GigaChatClient.ChatResult result = client.chatCompletionSplittable("Инструкция", context.toString(), null, null, false);

        assertEquals(3, calls.get(), "полный запрос, затем две половины контекста");
        assertTrue(result.text().contains(PromptSplitter.partHeader(1, 2)), result.text());
        assertTrue(result.text().contains(PromptSplitter.partHeader(2, 2)), result.text());
    }

    @Test
    void embeddingsFailureThrowsInsteadOfZeroVectors() {
        when(embeddingModel.call(any(EmbeddingRequest.class)))
                .thenThrow(new NonTransientAiException("400 - {\"status\":400,\"message\":\"bad request\"}"));

        GigaChatException ex = assertThrows(GigaChatException.class, () -> client.getEmbeddings(List.of("текст")));

        assertTrue(ex.getMessage().startsWith(GigaChatRetryPolicy.FAILED), ex.getMessage());
    }

    @Test
    void embeddingsNullResponseThrows() {
        when(embeddingModel.call(any(EmbeddingRequest.class))).thenReturn(null);

        GigaChatException ex = assertThrows(GigaChatException.class, () -> client.getEmbeddings(List.of("текст")));

        assertTrue(ex.getMessage().contains("пустой ответ"), ex.getMessage());
    }

    @Test
    @SuppressWarnings("unchecked")
    void uploadedFileIsDeletedUnderConcurrencyLimiter() {
        GigaChatApi api = Mockito.mock(GigaChatApi.class);
        ObjectProvider<GigaChatApi> provider = Mockito.mock(ObjectProvider.class);
        when(provider.getIfAvailable()).thenReturn(api);
        CountingLimiter limiter = new CountingLimiter();
        GigaChatClient withApi = new GigaChatClient(chatModel, embeddingModel, provider);
        withApi.setConcurrencyLimiter(limiter);
        ChatResponseMetadata metadata = ChatResponseMetadata.builder()
                .keyValue(GigaChatModel.UPLOADED_MEDIA_IDS, List.of("file-1"))
                .build();
        when(chatModel.call(any(Prompt.class)))
                .thenReturn(new ChatResponse(List.of(new Generation(new AssistantMessage("распознано"))), metadata));

        GigaChatClient.ChatResult result = withApi.chatCompletionWithFile("текст", "scan.pdf", new byte[] {1},
                "application/pdf", null, null, null);

        assertEquals("распознано", result.text());
        verify(api).deleteFile("file-1");
        assertEquals(2, limiter.calls.get(), "запрос модели и удаление файла — два разрешения ограничителя");
    }

    private static ChatResponse response(String text) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(text))));
    }

    /** Таймаут ответа, как его отдаёт RestClient поверх JdkClientHttpRequest Spring 6.2: текста у причины нет. */
    private static RuntimeException requestTimeout() {
        return new ResourceAccessException("I/O error on POST request for \"https://gigachat/api/v1/chat/completions\": null",
                new HttpTimeoutException(null));
    }

    private static RuntimeException unauthorized() {
        return new NonTransientAiException("401 - {\"status\":401,\"message\":\"Unauthorized\"}");
    }

    private static RuntimeException tooManyRequests(int retryAfterSeconds) {
        return new NonTransientAiException("429 - {\"status\":429,\"message\":\"Too many requests\"}; "
                + GigaChatRetryAfter.MARKER + retryAfterSeconds);
    }

    /** Ограничитель, считающий вызовы под разрешением. */
    private static final class CountingLimiter extends GigaChatConcurrencyLimiter {

        private final AtomicInteger calls = new AtomicInteger();

        CountingLimiter() {
            super(1, true, 60_000);
        }

        @Override
        public <T> T call(Supplier<T> call, BooleanSupplier cancelled, Consumer<String> notice) {
            calls.incrementAndGet();
            return super.call(call, cancelled, notice);
        }
    }
}
