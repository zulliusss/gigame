package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты кодовых операций Формы 3: реестр документов ЭДО и строки формы.
 */
class Form3OpsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static final String UPD_SIGNED = """
            Товар (груз) передал Электронная подпись [12] Дата отгрузки, передачи (сдачи) " 21 " июля 2025 г. [13]
            Универсальный передаточный документ
            Счет­фактура N 0000118724 от 21.07.2025 (1)
            Продавец: ООО "Датафьюжн" (2)
            Покупатель: ПАО Сбербанк (6)
            Информационное поле по документу: Договор 4652269 от 05.07.2023 (050004652269)
            Всего к оплате (9) 1063178,54 × без НДС 1063178,54 Руководитель организации Электронная подпись Молодцов
            Товар (груз) получил [17] Дата получения (приёмки) " 24 " июля 2025 г. [18]
            Ответственный за правильность оформления факта хозяйственной жизни Пользователь АС УВХД Электронная подпись Кузьмин Иван Юрьевич [20]
            """;

    static final String UPD_UNSIGNED = """
            Счет-фактура N 556 от 31.03.2025 (1)
            Продавец: ООО "ТОТ" (2)
            Покупатель: ПАО Сбербанк (6)
            Основание передачи (сдачи) / получения (приёмки) Договор 4622976 (050004622976) 4600024537 от 30.05.2023 [10]
            Всего к оплате (9) 1264585,60 × 252917,12 1517502,72 Руководитель организации
            Дата получения (приёмки) " " 20 г. [18]
            Ответственный за правильность оформления факта хозяйственной жизни [20]
            """;

    static final String SPEC_A = """
            Спецификация на разработку программного обеспечения № 5374642
            к Договору №4652269 на разработку/модификацию программного обеспечения от «05» июля 2023 г.
            1. Предмет Спецификации: Исполнитель выполняет работы по разработке ППО «Карты».
            4. Стоимость работ: Стоимость работ составляет 1063178,54 (Один миллион) рублей.
            Главный разработчик Java (back end) (Москва) 47 22620,82 1063 178,54
            Подпись банка Кузьмин 26.06.2025 17:37:40 Подпись поставщика Молодцов 27.06.2025 14:39:02
            """;

    static final String SPEC_B = """
            Спецификация работ на разработку ПО № 5284130 к Договору № 4652269
            1. Предмет Спецификации: Исполнитель выполняет работы по разработке ППО.
            Итого по Этапу №1, руб. 1063178,54 Итого по Этапу №2, руб. 1538215,76 Python DevOps
            Подпись банка 27.03.2025 10:00:00 Подпись поставщика 28.03.2025 11:00:00
            """;

    /**
     * Печатная форма УПД СберКорус (акт по спецификации 5270341 комплекта 16.09.2026): счёт-фактура без номера
     * («б.н.»), итог графы 9 разорван переносами, договор и спецификация — в информационном поле.
     */
    static final String UPD_NO_NUMBER = """
            Дата получения (приёмки) " 25 " марта 2025 г. [18]
            Ответственный за правильность оформления факта хозяйственной жизни
            Пользователь АС УВХД Электронная подпись Дудина  Наталья  Владимировна [20]
            Счет-фактура N б.н. от 24.03.2025 (1)
            Продавец: ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ "АКСТИМ" (2)
            Покупатель: ПУБЛИЧНОЕ АКЦИОНЕРНОЕ ОБЩЕСТВО "СБЕРБАНК РОССИИ" (6)
            Информационное поле по документу: Дог 050005270341_AGR_Договор вн. №_5028839_от 07.08.2024
            Работы по миграции хранилища: Hadoop, GreenPlum
            Всего к оплате (9)
            283411
            7,31
            ×
            566823,
            46
            340094
            0,77
            Руководитель организации
            """ + Form3ActsTest.SBER_EDO_STAMP;

    /** Печатная форма УПД Контур (Диадок), комплект МЕТРО: титул покупателя подписан, штамп ЭДО без текстового слоя. */
    static final String UPD_DIADOC = """
            УПД Счет-фактура № 890 от 03.12.2025 (1)
            Продавец Общество с ограниченной ответственностью "Амбрелла Альянс" (2)
            Покупатель Общество с ограниченной ответственностью "МЕТРО Кэш энд Керри" (6)
            Услуги разработки ПО (Ведущий разработчик приложений) (iOS Developer: Swift, UIKit)
            Всего к оплате (9) 5 724 686,00 x x без НДС 5 724 686,00
            Основания передачи (сдачи) / получения (приемки) Договор №CN_1090_IT_19_134108_037544 от 22.07.2019 (10)
            Дата получения (приемки) 16.12.2025 (18)
            Иные сведения (19)
            Ответственный за правильность оформления факта хозяйственной жизни
            Директор по маркетингу и
            работе c клиентами
            Электронная подпись
            Должность Подпись ФИО
            Наименование экономического субъекта — составителя документа
            ООО "МЕТРО Кэш энд Керри" (21)
            """;

    /** Признак «Мобильная разработка» закупки мобильных приложений (критерии МЕТРО) и лоты только из платформ. */
    static final String CRITERIA_MOBILE = """
            Критерий | Значение | Источник | Найдено
            Период опыта по методике оценки — календарные даты | с 25.03.2025 по 25.03.2026 | расчёт | НЕ НАЙДЕНА
            Признак «Мобильная разработка» | Под разработкой понимается комплекс работ... по разработке и/или модификации \
            и/или внедрению мобильных приложений iOS и Android | Раздел 2, EDITELEMENT_8 | НЕ НАЙДЕНА
            ЛОТ №1 (Квалификационные требования) | | |
            Технология 1 | iOS | Раздел 2 | точно
            Технология 2 | Android | Раздел 2 | точно
            """;

    static final String CRITERIA = """
            Критерий | Значение | Источник | Найдено
            Период опыта участника по квалификационным требованиям — календарные даты | с 08.04.2023 по 08.04.2026 | расчёт | НЕ НАЙДЕНА
            Период опыта по методике оценки — календарные даты | с 08.04.2025 по 08.04.2026 | расчёт | НЕ НАЙДЕНА
            Признак «Мобильная разработка» | стоимость работ по всей спецификации/заказу не засчитывается | РАЗДЕЛ 2, п. 7 | точно
            ЛОТ №1 (Квалификационные требования) | | |
            Технология 1 | Java | Раздел 2 | точно
            Технология 2 | Go (Golang) | Раздел 2 | точно
            Технология 3 | Python | Раздел 2 | точно
            """;

    @Test
    void sberKorusPrintFormGivesWholeRubleTotalAndEdoSignature() throws Exception {
        String text = UPD_SIGNED.replace("Всего к оплате (9) 1063178,54 × без НДС 1063178,54", "Всего к оплате (9) 4341149")
                .replace("Электронная подпись Кузьмин Иван Юрьевич [20]", "[20]")
                + "Документ подписан и передан через оператора ООО \"СберКорус\"\nФедоткин 26.09.2024 Подпись соответствует файлу документа\n"
                + "Кубезова 26.09.2024 Подпись соответствует файлу документа\n";
        Map<?, ?> upd = (Map<?, ?>) ((List<?>) MAPPER.readValue(Form3Ops.registry(List.of(new Form3Ops.Source("упд 539.pdf", text))),
                Map.class).get("упд")).get(0);

        assertEquals("4341149.00", upd.get("сумма"));
        assertEquals(Boolean.TRUE, upd.get("подпись_заказчика"));
    }

    @Test
    void updWithoutNumberIsParsedWithEdoSignDateAndSplitTotal() throws Exception {
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("5028839/5270341/Акт от 24.03.2025.pdf", UPD_NO_NUMBER)));
        List<?> upds = (List<?>) MAPPER.readValue(json, Map.class).get("упд");
        Map<?, ?> upd = (Map<?, ?>) upds.get(0);

        assertEquals(1, upds.size());
        assertEquals("б.н.", upd.get("номер"));
        assertEquals("24.03.2025", upd.get("дата"));
        assertEquals("25.03.2025", upd.get("дата_подписания"));
        assertEquals("25.03.2025", upd.get("дата_приёмки"));
        assertEquals("3400940.77", upd.get("сумма"));
        assertEquals("5270341", upd.get("спецификация"));
        assertEquals("5028839", upd.get("договор"));
        assertEquals("07.08.2024", upd.get("договор_дата"));
        assertEquals(Boolean.TRUE, upd.get("подпись_заказчика"));
    }

    @Test
    void fnsUpdFileNameGivesNoSpecificationButFolderInPathDoes() throws Exception {
        // Комплект 6: имя печатной формы УПД ФНС содержит ЭДО-идентификатор «…-6766351_» и дату «20250714» — не спецификации;
        // Комплект 7: папка спецификации в пути к той же форме — номер спецификации из пути с признаком реестра
        String k6 = "ON_NSCHFDOPPR_2BK-7707083893-667102008-1027700132195_2BK-9709070357-6766351_20250714_954FA30E-960A-4320-8A98-7754B17DC1AB"
                + "_0_0_0_0_0_00.pdf";
        String k7 = "508374~1.ZIP/Акт/5281780/0000107935.zip/ON_NSCHFDOPPR_2BK-7707083893-667102008-1027700132195_2BK-9731055555-5412546"
                + "_20250527_EA673BDE-5C56-4DA8-8DD2-162A55F4FEBD_0_0_0_0_0_00.pdf";
        List<?> upds = (List<?>) MAPPER.readValue(Form3Ops.registry(List.of(new Form3Ops.Source(k6, UPD_SIGNED),
                new Form3Ops.Source(k7, UPD_SIGNED), new Form3Ops.Source("комплект.zip/Договор 5028839 от 07.08.2024/5270341/Акт от 24.03.2025.pdf",
                        UPD_NO_NUMBER))), Map.class).get("упд");

        assertEquals("", ((Map<?, ?>) upds.get(0)).get("спецификация"));
        assertEquals(Boolean.FALSE, ((Map<?, ?>) upds.get(0)).get(Form3Ops.SPEC_BY_NAME));
        assertEquals("5281780", ((Map<?, ?>) upds.get(1)).get("спецификация"));
        assertEquals(Boolean.TRUE, ((Map<?, ?>) upds.get(1)).get(Form3Ops.SPEC_BY_NAME));
        // спецификация из информационного поля текста — признака «из имени» нет
        assertEquals("5270341", ((Map<?, ?>) upds.get(2)).get("спецификация"));
        assertEquals(Boolean.FALSE, ((Map<?, ?>) upds.get(2)).get(Form3Ops.SPEC_BY_NAME));
        assertEquals(List.of("24.03.2025", "25.03.2025"), ((Map<?, ?>) upds.get(2)).get(Form3Acts.SIGNATURES));
    }

    @Test
    void diadocUpdIsSignedByBuyerTitleWhenStampHasNoTextLayer() throws Exception {
        // штамп Контур в этих PDF не имеет текстового слоя: подпись заказчика видна по титулу покупателя [18]/[20]
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("МЕТРО.zip/2025/УПД №890 от 03.12.25 - подписан.pdf", UPD_DIADOC)));
        Map<?, ?> upd = (Map<?, ?>) ((List<?>) MAPPER.readValue(json, Map.class).get("упд")).get(0);

        assertEquals("890", upd.get("номер"));
        assertEquals("5724686.00", upd.get("сумма"));
        assertEquals("16.12.2025", upd.get("дата_приёмки"));
        assertEquals("", upd.get("дата_подписания"));
        assertEquals(Boolean.TRUE, upd.get("подпись_заказчика"));
    }

    @Test
    void mobileProcurementIsTakenFromRequiredTechnologiesAndSignText() {
        // закупка МП: признак описывает разработку мобильных приложений, все технологии лота — платформы
        assertTrue(Form3Ops.Criteria.parse(CRITERIA_MOBILE).mobileProcurement);
        // тот же комплект без строки признака: лоты из iOS и Android сами говорят о закупке мобильной разработки
        assertTrue(Form3Ops.Criteria.parse(CRITERIA_MOBILE.replaceAll("(?m)^Признак.*\\n", "")).mobileProcurement);
        // явный запрет: «стоимость работ по всей спецификации/заказу не засчитывается»
        String denied = CRITERIA_MOBILE.replaceAll("(?m)^Признак[^|]*\\|[^|]*\\|",
                "Признак «Мобильная разработка» | стоимость работ по всей спецификации/заказу не засчитывается |");
        assertFalse(Form3Ops.Criteria.parse(denied).mobileProcurement);
        // закупка не мобильная: технологии лота — не платформы
        assertFalse(Form3Ops.Criteria.parse(CRITERIA).mobileProcurement);
    }

    @Test
    void technologySynonymsAndRatingBoundaries() {
        assertTrue(Form3Ops.containsTechnology("разработка на JS и Node", "JavaScript"));
        assertTrue(Form3Ops.containsTechnology("стек: TypeScript, TS-типизация", "TypeScript"));
        assertFalse(Form3Ops.containsTechnology("формат JSON", "JavaScript"));
        assertTrue(Form3Ops.containsTechnology("ГЛАВНЫЙ РАЗРАБОТЧИК IOS SB", "iOS"));
    }

    @Test
    void registryParsesUpdFields() throws Exception {
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("ON_NSCHFDOPPR_1.pdf", UPD_SIGNED),
                new Form3Ops.Source("Спецификация № 5374642.pdf", SPEC_A)));
        Map<?, ?> registry = MAPPER.readValue(json, Map.class);
        List<?> upds = (List<?>) registry.get("упд");
        Map<?, ?> upd = (Map<?, ?>) upds.get(0);

        assertEquals(1, upds.size());
        assertEquals("0000118724", upd.get("номер"));
        assertEquals("21.07.2025", upd.get("дата"));
        assertEquals("ООО \"Датафьюжн\"", upd.get("продавец"));
        assertEquals("ПАО Сбербанк", upd.get("покупатель"));
        assertEquals("4652269", upd.get("договор"));
        assertEquals("05.07.2023", upd.get("договор_дата"));
        assertEquals("1063178.54", upd.get("сумма"));
        assertEquals("24.07.2025", upd.get("дата_приёмки"));
        assertEquals(Boolean.TRUE, upd.get("подпись_заказчика"));
        assertTrue(((List<?>) upd.get("заказы")).isEmpty());
        Map<?, ?> spec = (Map<?, ?>) ((List<?>) registry.get("спецификации")).get(0);
        assertEquals("5374642", spec.get("номер"));
        assertEquals("4652269", spec.get("договор"));
        assertEquals("27.06.2025", spec.get("дата"));
        assertTrue(((List<?>) spec.get("суммы")).contains("1063178.54"));
    }

    @Test
    void registryTakesSpecNumberFromFileNameAndDetectsMissingSignature() throws Exception {
        // УПД ТОТ: номера спецификации в тексте нет — берётся из имени файла; подписи заказчика нет
        String json = Form3Ops.registry(List.of(
                new Form3Ops.Source("УПД 556_4622976_5265609_1 517 502,72.pdf", UPD_UNSIGNED)));
        Map<?, ?> upd = (Map<?, ?>) ((List<?>) MAPPER.readValue(json, Map.class).get("упд")).get(0);

        assertEquals("5265609", upd.get("спецификация"));
        assertEquals("1517502.72", upd.get("сумма"));
        assertEquals("", upd.get("дата_приёмки"));
        assertEquals(Boolean.FALSE, upd.get("подпись_заказчика"));
    }

    @Test
    void sellerStampRepeatedOnEveryPageIsNotCustomerSignature() throws Exception {
        // штамп ЭДО с одной подписью продавца на обеих страницах УПД — две фразы «Подпись соответствует», но подпись одна
        String text = UPD_UNSIGNED + Form3ActsTest.SELLER_ONLY_EDO_STAMP + "Страница 2\n" + Form3ActsTest.SELLER_ONLY_EDO_STAMP;
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("УПД 556_4622976_5265609_1 517 502,72.pdf", text)));
        Map<?, ?> upd = (Map<?, ?>) ((List<?>) MAPPER.readValue(json, Map.class).get("упд")).get(0);

        assertEquals(Boolean.FALSE, upd.get("подпись_заказчика"));
        assertEquals("03.04.2025", upd.get("дата_подписания"));
    }

    @Test
    void rowsMatchSpecByStageSumListingAllCandidates() throws Exception {
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_SIGNED),
                new Form3Ops.Source("specA.pdf", SPEC_A), new Form3Ops.Source("specB.pdf", SPEC_B)));

        String json = Form3Ops.rows(Map.of(), registry, CRITERIA);
        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(json, List.class).get(0);

        assertEquals("ПАО Сбербанк", row.get("к3"));
        assertEquals("договор 4652269 от 05.07.2023", row.get("к4"));
        assertTrue(String.valueOf(row.get("к5")).contains("5374642 от 27.06.2025 или 5284130 от 28.03.2025"));
        assertEquals("УПД 0000118724 от 21.07.2025", row.get("к6"));
        assertEquals("24.07.2025", row.get("к7"));
        assertEquals("да", row.get("к8"));
        assertEquals("да", row.get("к9"));
        assertEquals("1063178.54", row.get("к10"));
        assertEquals("да", row.get("к11"));
        assertEquals("нет", row.get("к12"));
        assertEquals("нет", row.get("к13"));
        assertEquals("1063178.54", row.get("к14"));
        assertEquals("-", row.get("к15"));
        assertEquals("да", row.get("т_Java"));
        assertEquals("нет", row.get("т_Go (Golang)"));
        assertEquals("да", row.get("т_Python"));
        assertEquals("нет", row.get("к16"));
        assertEquals("да: Java, Python", row.get("к17"));
        String audit = String.valueOf(row.get("к20"));
        assertTrue(audit.contains("период квалификации: да"));
        assertTrue(audit.contains("период методики: да"));
        assertTrue(audit.contains("лот 1: найдено Java (спецификация), Python (спецификация); не найдено Go (Golang)"));
        assertTrue(audit.contains("заказчик: ПАО Сбербанк"));
        assertTrue(audit.contains("несколько кандидатов"));
    }

    @Test
    void rowsMarkUnsignedActAndMissingPeriod() throws Exception {
        String registry = Form3Ops.registry(List.of(
                new Form3Ops.Source("УПД 556_4622976_5265609.pdf", UPD_UNSIGNED)));

        String json = Form3Ops.rows(Map.of(), registry, "Критерий | Значение\nТехнология 1 | Java | Раздел 2 | точно");
        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(json, List.class).get(0);

        assertEquals("0", row.get("к14"));
        assertTrue(String.valueOf(row.get("к15")).startsWith("акт не подписан заказчиком"));
        assertEquals("не сопоставлена", row.get("к5"));
        assertEquals("31.03.2025", row.get("к7"));
        assertEquals("-", row.get("к8"));
        assertEquals("проверить вручную", row.get("к9"));
        assertEquals("нет данных", row.get("к13"));
        assertTrue(String.valueOf(row.get("к20")).contains("проверить вручную (в критериях нет дат периода)"));
        assertTrue(String.valueOf(row.get("к20")).contains("квалификационные требования к периоду не предъявляются"));
    }

    @Test
    void registryKeepsReportsApartAndRowsDedupeCandidates() throws Exception {
        // отчёт «К Спецификации № N» — не спецификация; два документа с одним номером дают одного кандидата
        String report = "ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ К Спецификации на модификацию № 5374642 от 27.06.2025 "
                + "к договору № 4652269 Стоимость 1063178,54";
        String registry = Form3Ops.registry(List.of(new Form3Ops.Source("upd.pdf", UPD_SIGNED),
                new Form3Ops.Source("Отчет_5374642.pdf", report), new Form3Ops.Source("specA.pdf", SPEC_A),
                new Form3Ops.Source("specA-копия.pdf", SPEC_A)));
        Map<?, ?> parsed = MAPPER.readValue(registry, Map.class);

        List<?> reports = (List<?>) parsed.get("отчёты");
        assertEquals(1, reports.size());
        assertEquals("5374642", ((Map<?, ?>) reports.get(0)).get("спецификация"));
        assertEquals(2, ((List<?>) parsed.get("спецификации")).size());
        Map<?, ?> row = (Map<?, ?>) MAPPER.readValue(Form3Ops.rows(Map.of(), registry, CRITERIA), List.class).get(0);
        assertEquals("5374642 от 27.06.2025", row.get("к5"));
        assertTrue(String.valueOf(row.get("к20")).contains("отчётов 1"));
    }

    @Test
    void technologySearchUsesWordBoundariesAndAlternatives() {
        assertTrue(Form3Ops.containsTechnology("используется Golang и Postgres", "Go (Golang)"));
        assertFalse(Form3Ops.containsTechnology("Google Cloud", "Go (Golang)"));
        assertTrue(Form3Ops.containsTechnology("javascript (front end)", "JavaScript"));
        assertFalse(Form3Ops.containsTechnology("Java (back end)", "JavaScript"));
        assertTrue(Form3Ops.containsTechnology("процедуры PL/SQL", "PL/SQL"));
        // методология в названии должности не считается её применением; в описании принципов — считается
        assertFalse(Form3Ops.containsTechnology("Колчин В. А. Главный инженер DevOps 09.06.2025", "DevOps"));
        assertTrue(Form3Ops.containsTechnology("с использованием принципов организации производства (DevOps, Sbergile и др.)", "DevOps"));
        assertTrue(Form3Ops.containsTechnology("Главный разработчик Java (back end)", "Java"));
    }

    @Test
    void technologyWithOrIsFoundByAnyWholeAlternative() {
        // «или» делит значение на альтернативы и сам не ищется: «и/или» есть почти в любом тексте договора
        String text = "Исполнитель и/или привлечённый им соисполнитель выполняет работы на стенде заказчика для интеграции с системами";
        assertFalse(Form3Ops.containsTechnology(text, "UniData или Tibco"));
        assertTrue(Form3Ops.containsTechnology(text + ", интеграционная шина Tibco", "UniData или Tibco"));
        assertTrue(Form3Ops.containsTechnology("ведение мастер-данных в UniData", "UniData ИЛИ Tibco"));
        // служебные слова внутри альтернативы тоже не ищутся
        assertFalse(Form3Ops.containsTechnology(text, "Kotlin для Android"));
        assertTrue(Form3Ops.containsTechnology("приложение на Kotlin", "Kotlin для Android"));
        // прежние случаи: варианты через «/» и пробел
        assertTrue(Form3Ops.containsTechnology("процедуры PL/SQL", "PL/SQL"));
        assertTrue(Form3Ops.containsTechnology("интерфейс на React", "Java Spring/React"));
        assertTrue(Form3Ops.containsTechnology("сервисы Spring Boot", "Java Spring/React"));
        assertFalse(Form3Ops.containsTechnology("интерфейс на Angular", "Java Spring/React"));
    }

    @Test
    void criteriaPeriodsFallBackToStartDateAndSpanText() {
        // без строк «календарные даты» периоды считаются от даты начала подачи заявок
        String text = """
                Дата начала срока подачи заявок | 08.04.2026 | РАЗДЕЛ 1, п. 12 | точно
                Период опыта участника по квалификационным требованиям | за последние 3 (три) года до даты публикации | РАЗДЕЛ 2 | точно
                Период опыта по методике оценки | акты/УПД подписаны не ранее 12 (двенадцати) месяцев до даты публикации | РАЗДЕЛ 6 | нечётко
                Признак «Мобильная разработка» | закупается мобильная разработка, опыт засчитывается | РАЗДЕЛ 2 | точно
                """;
        Form3Ops.Criteria criteria = Form3Ops.Criteria.parse(text);

        assertEquals("08.04.2023", criteria.qualFrom.format(Form3Ops.DATE));
        assertEquals("08.04.2026", criteria.qualTo.format(Form3Ops.DATE));
        assertEquals("08.04.2025", criteria.methodFrom.format(Form3Ops.DATE));
        assertTrue(criteria.mobileProcurement);
        assertFalse(Form3Ops.Criteria.parse(CRITERIA).mobileProcurement);
    }

    @Test
    void registryPutsUnreadableDocumentsApartWithReason() throws Exception {
        // маркерный документ со словом «Акт» в имени раньше становился актом с пустой суммой
        String marker = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «Акт №3 от 01.02.2024.pdf» не распознан: "
                + "PDF без текстового слоя (скан). Автоматический анализ содержимого невозможен — проверьте документ вручную.";
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("Акт №3 от 01.02.2024.pdf", marker),
                new Form3Ops.Source("upd.pdf", UPD_SIGNED)));
        Map<?, ?> registry = MAPPER.readValue(json, Map.class);

        assertEquals(0, ((List<?>) registry.get("акты")).size());
        List<?> unreadable = (List<?>) registry.get("не_разобраны");
        assertEquals(1, unreadable.size());
        assertEquals("Акт №3 от 01.02.2024.pdf", ((Map<?, ?>) unreadable.get(0)).get("файл"));
        assertEquals("PDF без текстового слоя (скан)", ((Map<?, ?>) unreadable.get(0)).get("причина"));
        assertFalse(Form3Acts.isAct("Акт №3.pdf", marker));
        assertFalse(Form3Acts.isOrder("Заявка №3 от 01.02.2024.pdf", marker));
    }
}
