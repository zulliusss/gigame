package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Проверка regex-параметров операций до создания прогона: катастрофический, некорректный и
 * слишком длинный шаблон — отказ запуска с понятным текстом; обычные шаблоны проходят.
 */
class ScenarioRegexValidatorTest {

    /** Вложенные квантификаторы: на длинном повторе «a…a!» движок Java квадратичен (замер — сотни мс на 5 000 символов). */
    /** Экспоненциальный для движка Java шаблон: {@code (a*)*b} и {@code (a+)+$} он выполняет за квадратичное время. */
    private static final String CATASTROPHIC = "(a+a+)+b";

    /** Шаблон «оставить_строки» узла «Строки исходной формы» Формы 3 v6.4/v6.5 (без якоря). */
    private static final String FORM3_LINES = "(?=(?:[^|\\n]*\\|){3})(?=.*(?:\\d{2}\\.\\d{2}\\.\\d{4}|\\d{4}-\\d{2}-\\d{2}|УПД\\s*№|№\\s*\\d{3,}))";

    /** Флаги пробы валидатора. */
    private static final int PROBE_FLAGS = Pattern.MULTILINE | Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    private static NodeDto transform(String id, String label, String rules) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label(label).rules(rules).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static GraphDataDto graph(NodeDto... nodes) {
        return new GraphDataDto(List.of(nodes), List.of());
    }

    @Test
    void catastrophicPattern_rejectsRunBeforeItIsCreated() {
        GraphDataDto graph = graph(transform("t1", "Извлечение",
                "{\"операции\": [{\"оп\": \"извлечь_regex\", \"шаблон\": \"" + CATASTROPHIC + "\"}]}"));

        ScenarioException e = assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(graph));

        assertTrue(e.getMessage().startsWith(ScenarioRegexValidator.PREFIX), e.getMessage());
        assertTrue(e.getMessage().contains("«шаблон» операции «извлечь_regex» в узле «Извлечение»"), e.getMessage());
        assertTrue(e.getMessage().contains("слишком медленное"), e.getMessage());
        assertTrue(e.getMessage().endsWith(ScenarioRegexValidator.SUFFIX), e.getMessage());
    }

    @Test
    void invalidAndTooLongPatterns_areReported() {
        String tooLong = "a".repeat(600);
        GraphDataDto graph = graph(transform("t1", "Т",
                "{\"операции\": [{\"оп\": \"оставить_строки\", \"шаблон\": \"(\"},"
                        + " {\"оп\": \"удалить_объекты\", \"шаблон\": \"ok\", \"и_шаблон\": \"" + tooLong + "\"}]}"));

        List<String> problems = ScenarioRegexValidator.problemsOf(graph, "");

        assertTrue(problems.get(0).contains("«шаблон» операции «оставить_строки»"), problems.toString());
        assertTrue(problems.get(0).contains("некорректно"), problems.toString());
        assertTrue(problems.get(1).contains("«и_шаблон» операции «удалить_объекты»"), problems.toString());
        assertTrue(problems.get(1).contains("длиннее 512"), problems.toString());
    }

    @Test
    void ordinaryPatterns_pass() {
        GraphDataDto graph = graph(transform("t1", "Т", """
                {"операции": [
                  {"оп": "извлечь_regex", "шаблон": "№\\\\s*(\\\\d+)", "группа": 1},
                  {"оп": "заменить", "найти": "(a+)+$", "на": "x"},
                  {"оп": "сверить_суммы", "метка": "НМЦД?"},
                  {"оп": "слить_json_массивы", "исключить_типы": {"если_не_содержит": "единственн|неконкурентн"}},
                  {"оп": "извлечь_из_документов", "имя": "^ПЗ", "шаблон": "НМЦД[^\\\\d]{0,40}(\\\\d[\\\\d ]+,\\\\d{2})"},
                  {"оп": "уникальные_строки"}
                ]}
                """));

        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(graph));
        assertNull(ScenarioRegexValidator.check("^(ЛОТ\\s*№|Общая информация)"));
    }

    @Test
    void numberingConditionPattern_isChecked() {
        GraphDataDto broken = graph(transform("t1", "Нумерация",
                "{\"операции\": [{\"оп\": \"нумеровать\", \"поле\": \"з1\", \"если_поле\": \"з4\", \"шаблон\": \"(ВЫСОКИЙ\"}]}"));
        GraphDataDto ordinary = graph(transform("t1", "Нумерация",
                "{\"операции\": [{\"оп\": \"нумеровать\", \"поле\": \"з1\", \"если_поле\": \"з4\", \"шаблон\": \"^(ВЫСОКИЙ|СРЕДНИЙ|НИЗКИЙ)$\"}]}"));

        List<String> problems = ScenarioRegexValidator.problemsOf(broken, "");

        assertEquals(1, problems.size(), problems.toString());
        assertTrue(problems.get(0).contains("«шаблон» операции «нумеровать» в узле «Нумерация»"), problems.get(0));
        assertTrue(problems.get(0).contains("некорректно"), problems.get(0));
        assertTrue(ScenarioRegexValidator.problemsOf(ordinary, "").isEmpty());
    }

    @Test
    void specParameterAndValueColumns_areChecked() {
        GraphDataDto broken = graph(transform("t1", "Сверка характеристик",
                "{\"операции\": [{\"оп\": \"сверить_характеристики\", \"колонка_параметра\": \"(параметр\", \"колонка_значения\": \"" + CATASTROPHIC + "\"}]}"));
        GraphDataDto ordinary = graph(transform("t1", "Сверка характеристик",
                "{\"операции\": [{\"оп\": \"сверить_характеристики\", \"колонка_параметра\": \"параметр|показател\", \"колонка_значения\": \"^\\\\s*(?:требуем\\\\S*\\\\s+)?значени\"}]}"));

        List<String> problems = ScenarioRegexValidator.problemsOf(broken, "");

        assertEquals(2, problems.size(), problems.toString());
        assertTrue(problems.get(0).contains("«колонка_параметра» операции «сверить_характеристики» в узле «Сверка характеристик»: некорректно"), problems.get(0));
        assertTrue(problems.get(1).contains("«колонка_значения» операции «сверить_характеристики»"), problems.get(1));
        assertTrue(problems.get(1).contains("слишком медленное"), problems.get(1));
        assertTrue(ScenarioRegexValidator.problemsOf(ordinary, "").isEmpty());
    }

    @Test
    void replaceWithRegexFlag_isChecked() {
        GraphDataDto graph = graph(transform("t1", "Т",
                "{\"операции\": [{\"оп\": \"заменить\", \"найти\": \"" + CATASTROPHIC + "\", \"на\": \"\", \"regex\": true}]}"));

        assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(graph));
    }

    @Test
    void subScenarioPatterns_areCheckedToo() {
        UUID subId = UUID.randomUUID();
        Scenario sub = new Scenario();
        sub.setId(subId);
        sub.setName("Вложенный");
        sub.setGraphData(GraphDataMapper.fromDto(graph(transform("s1", "Внутри",
                "{\"операции\": [{\"оп\": \"удалить_строки\", \"шаблон\": \"" + CATASTROPHIC + "\"}]}"))));
        NodeDto subNode = NodeDto.builder()
                .id("sub")
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Под-сценарий").value(subId.toString()).build())
                .position(new PositionDto(0, 0))
                .build();
        GraphDataDto graph = graph(subNode);

        ScenarioException e = assertThrows(ScenarioException.class,
                () -> ScenarioOperationsValidator.validate(graph, UUID.randomUUID(), id -> Optional.of(sub)));

        assertTrue(e.getMessage().contains("в узле «Внутри под-сценария «Вложенный»»"), e.getMessage());
    }

    /**
     * Шаблоны действующих корп-сценариев проходят пробу: просмотр вперёд с {@code .*} по строке
     * («оставить_строки» Формы 3 v6.4) и ленивые группы по ячейкам таблицы («заменить» АЗК v3)
     * на пробе из одной строки в 4000 символов давали ложный отказ запуска.
     */
    @Test
    void deployedScenarioPatterns_pass() {
        String form3 = "(?=(?:[^|\\n]*\\|){3})(?=.*(?:\\d{2}\\.\\d{2}\\.\\d{4}|\\d{4}-\\d{2}-\\d{2}|УПД\\s*№|№\\s*\\d{3,}))";
        String azk = "[ \\t]*([^|\\n]*?ИНН\\s*(\\d+)[^|\\n]*?)[ \\t]*\\|[ \\t]*(\\d[\\d\\s]*,\\d{2})[ \\t]*\\|[ \\t]*"
                + "(\\d[\\d\\s]*,\\d{2})[ \\t]*\\|[ \\t]*(\\d[\\d\\s]*,\\d{2})[ \\t]*\\|?";
        String azkLot = "(?m)^.*?\\|\\s*(\\d[\\d\\s]*,\\d{2})\\s*\\|\\s*([^|\\n]*?[А-Яа-яЁёA-Za-z][^|\\n]*?)\\s*\\|\\s*"
                + "(\\d[\\d\\s]*,\\d{2})\\s*\\|\\s*(?=[^|\\n]*ИНН)";

        assertNull(ScenarioRegexValidator.check(form3));
        assertNull(ScenarioRegexValidator.check(azk));
        assertNull(ScenarioRegexValidator.check(azkLot));
        assertNull(ScenarioRegexValidator.check("(a+)+$"));
        assertTrue(ScenarioRegexValidator.check(CATASTROPHIC).contains("слишком медленное"));
    }

    /**
     * Письмо Егоровой 16.09 «Ошибка выполнения»: проба по настенным часам (500 мс, на corp16/17 — 200 мс) на урезанном
     * CPU через раз отклоняла запуск Формы 3 v6.4/v6.5 — «Сценарий завершился с ошибкой» без единого узла. Бюджет
     * в шагах поиска от CPU не зависит: шаги детерминированы, у шаблона Формы 3 запас больше чем в пять раз,
     * с якорем «^» он дешевле на три порядка, экспоненциальный шаблон бюджет исчерпывает.
     */
    @Test
    void probeBudget_countsStepsNotTime_withMarginForForm3() {
        long form3 = ScenarioRegexValidator.probeSteps(Pattern.compile(FORM3_LINES, PROBE_FLAGS));
        long anchored = ScenarioRegexValidator.probeSteps(Pattern.compile("^" + FORM3_LINES, PROBE_FLAGS));
        long quadratic = ScenarioRegexValidator.probeSteps(Pattern.compile("(a+)+$", PROBE_FLAGS));

        assertEquals(form3, ScenarioRegexValidator.probeSteps(Pattern.compile(FORM3_LINES, PROBE_FLAGS)));
        assertTrue(form3 < ScenarioRegexValidator.PROBE_STEPS / 5, "шагов: " + form3);
        assertTrue(anchored < 100_000, "шагов: " + anchored);
        assertTrue(quadratic < ScenarioRegexValidator.PROBE_STEPS / 3, "шагов: " + quadratic);
        assertTrue(ScenarioRegexValidator.probeSteps(Pattern.compile(CATASTROPHIC, PROBE_FLAGS)) > ScenarioRegexValidator.PROBE_STEPS);
    }

    @Test
    void verdict_isCachedByPattern() {
        String first = ScenarioRegexValidator.check(CATASTROPHIC);
        String second = ScenarioRegexValidator.check(CATASTROPHIC);

        assertTrue(first.startsWith("слишком медленное (больше 50 млн шагов"), first);
        assertSame(first, second);
    }

    /** Отклоняет бюджет шагов, а не класс сложности: не только экспоненциальный, но и кубический шаблон. */
    @Test
    void cubicPattern_isRejectedByStepBudgetToo() {
        String cubic = ".*.*.*=.*";

        long steps = ScenarioRegexValidator.probeSteps(Pattern.compile(cubic, PROBE_FLAGS));
        String verdict = ScenarioRegexValidator.check(cubic);

        assertTrue(steps > ScenarioRegexValidator.PROBE_STEPS, "шагов: " + steps);
        assertTrue(verdict.startsWith("слишком медленное"), verdict);
    }

    /** Все операции узлов «Трансформация» сценария «Форма 3 v6.5 - форма первична + агент» проходят проверку запуска. */
    @Test
    void form3V65AgentScenario_passesLaunchCheck() {
        GraphDataDto graph = graph(
                transform("v1", "Строки исходной формы",
                        "{\"операции\": [{\"оп\": \"извлечь_из_документов\", \"имя\": \"(?:^|[/\\\\\\\\])[^/\\\\\\\\]*(?:форма\\\\s*3|справк|опыт)[^/\\\\\\\\]*$\", \"строго\": \"false\", \"шаблон\": \"(?s)^"
                        + "(?=(?:[^|\\\\n]*\\\\|){3})[^\\\\n]*Наименование компании[^\\\\n]*\\\\n(.*)$\", \"группа\": 1}, {\"оп\": \"оставить_строки\", \"шаблон\": \"(?=(?:[^|\\\\n]*\\\\|){3})(?=.*(?:\\"
                        + "\\d{2}\\\\.\\\\d{2}\\\\.\\\\d{4}|\\\\d{4}-\\\\d{2}-\\\\d{2}|УПД\\\\s*№|№\\\\s*\\\\d{3,}))\"}, {\"оп\": \"заменить\", \"найти\": \"\\\\s*\\\\[источник:[^\\\\]]*\\\\]\\\\s*$\", \"на\": \"\", \"rege"
                        + "x\": \"true\"}, {\"оп\": \"заменить\", \"найти\": \"(?m)(?:\\\\s*\\\\|\\\\s*)+$\", \"на\": \"\", \"regex\": \"true\"}]}"),
                transform("v2", "Шапка исходной формы",
                        "{\"операции\": [{\"оп\": \"извлечь_из_документов\", \"имя\": \"(?:^|[/\\\\\\\\])[^/\\\\\\\\]*(?:форма\\\\s*3|справк|опыт)[^/\\\\\\\\]*$\", \"строго\": \"false\", \"шаблон\": \"(?m)^"
                        + "((?=(?:[^|\\\\n]*\\\\|){3}).*Наименование компании.*)$\", \"группа\": 1}, {\"оп\": \"заменить\", \"найти\": \"\\\\s*\\\\[источник:[^\\\\]]*\\\\]\\\\s*$\", \"на\": \"\", \"regex\": \""
                        + "true\"}, {\"оп\": \"заменить\", \"найти\": \"(?m)(?:\\\\s*\\\\|\\\\s*)+$\", \"на\": \"\", \"regex\": \"true\"}]}"),
                transform("v3", "Критерии (текст)",
                        "{\"операции\": [{\"оп\": \"извлечь_из_документов\", \"имя\": \"[Кк]ритери\", \"строго\": \"true\", \"шаблон\": \"(?s)^(.*)$\", \"группа\": 1}, {\"оп\": \"заменить\", \"найти\":"
                        + " \"(?m)^[ \\\\t]*(?![Нн]ет[ \\\\t]*\\\\|)(?!Технология[ \\\\t]*\\\\d)([^|\\\\n]*?[^|\\\\s])[ \\\\t]*\\\\|[ \\\\t]*\\\\1[ \\\\t]*\\\\|\", \"на\": \"Технология 1 | $1 |\", \"regex\": \"tr"
                        + "ue\"}]}"),
                transform("v4", "Реестр документов (код)",
                        "{\"операции\": [{\"оп\": \"реестр_документов\"}]}"),
                transform("v5", "Строки формы (код)",
                        "{\"операции\": [{\"оп\": \"строки_формы3\", \"критерии_из_узла\": \"Критерии (текст)\", \"форма_из_узла\": \"Строки исходной формы\", \"шапка_из_узла\": \"Шапка исходн"
                        + "ой формы\", \"без_договора_не_засчитывать\": \"true\"}]}"),
                transform("t1", "Строки на проверку",
                        "{\"операции\": [{\"оп\": \"нумеровать\", \"поле\": \"№\"}, {\"оп\": \"удалить_объекты\", \"поле\": \"агенту\", \"шаблон\": \"^(?!да$).*$\"}, {\"оп\": \"удалить_поля\", \"поля\": "
                        + "\"исходная_строка, к2, к8, к9, к11, к12, к13, к14, к16, к17, к18, к19\"}]}"),
                transform("t2", "Строки формы с мнением агента (код)",
                        "{\"операции\": [{\"оп\": \"прикрепить_по_номеру\", \"из_узла\": \"Второе мнение (агент)\", \"поле\": \"к21\", \"шаблон\": \"НАХОДКА\\\\s*№\\\\s*(\\\\d+)\\\\s*:\\\\s*(.*)\", \"толь"
                        + "ко_номера_из_узла\": \"Строки на проверку\"}, {\"оп\": \"установить_поле\", \"поле\": \"к21\", \"значение\": \"НЕ ПРОВЕРЕНО — агент не ответил\", \"если_поле\": \"агент"
                        + "у\", \"шаблон\": \"^да$\", \"только_пустые\": \"true\"}]}"));

        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(graph));
        assertTrue(ScenarioRegexValidator.problemsOf(graph, "").isEmpty());
    }
}
