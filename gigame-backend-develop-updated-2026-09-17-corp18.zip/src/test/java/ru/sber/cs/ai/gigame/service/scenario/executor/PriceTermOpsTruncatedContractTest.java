package ru.sber.cs.ai.gigame.service.scenario.executor;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * «сверить_цену_и_сроки» (c3 Комягина v4) на реальном выходе s4 Субботина (регресс 16.09.2026): JSON условий договора
 * оборван зациклившимся полем «объем» — объект восстанавливается до последней полной пары ({@code LlmJson.all}), цена
 * сверяется с лотом протокола, идущего после обрыва. Раньше: «JSON условий договора не найден — проверка не выполнена».
 * Обрыв не молчаливый: строка «⚠ JSON условий договора оборван …» в отчёте и предупреждение узла; текст разбирается один раз.
 */
class PriceTermOpsTruncatedContractTest {

    private static final String CONTRACT_HEADER = "=== РЕЗУЛЬТАТ ОТ \"Условия договора\" ===\n";
    private static final String PROTOCOL_HEADER = "\n\n=== РЕЗУЛЬТАТ ОТ \"Данные протокола\" ===\n";
    private static final String TRUNCATED_LINE = "⚠ JSON условий договора оборван (ответ модели зациклился или усечён): JSON-объект не закрыт "
            + "(ответ модели оборван) — обрезан до последней полной пары «срок_поставки_до» и закрыт; отброшены поле «объем» и всё после него\n";

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    @Test
    void priceIsCheckedWhenContractJsonWasCutByLoop() throws IOException {
        // выход s4 после обрезки зацикливания в GigaChatClient: шапка JSON, три повтора «объема», маркер
        String report = PriceTermOps.check(loopCutInput());

        assertFalse(report.contains("JSON условий договора не найден"), report);
        assertTrue(report.contains("Цена (лот 3): СООТВЕТСТВУЕТ — "), report);
        // срок действия договора шёл в JSON после «объема» и отброшен вместе с ним — риск сроков не оценивается, и отчёт говорит почему
        assertTrue(report.startsWith("ЦЕНА И СРОКИ (код)\n" + TRUNCATED_LINE + "Цена (лот 3)"), report);
        assertFalse(report.contains("⚠ JSON данных протокола"), report);
        assertTrue(report.contains("Срок поставки и срок действия договора: НЕ ОЦЕНИВАЕТСЯ"), report);
        assertTrue(report.endsWith("{\"цена\": \"СООТВЕТСТВУЕТ\", \"риск_сроков\": \"НЕ ОЦЕНИВАЕТСЯ\"}"), report);
    }

    @Test
    void priceIsCheckedOnOriginalRunInputWithLoopUpToTruncationMarker() throws IOException {
        String s4 = resource("regress/kom-v4-subbotin-lot3-s4-head.txt") + "10 шт.; ".repeat(2000) + "\n" + GigaChatClient.TRUNCATED_MARKER;

        String report = PriceTermOps.check(CONTRACT_HEADER + s4 + PROTOCOL_HEADER + resource("regress/kom-v4-subbotin-lot3-s5.txt"));

        assertTrue(report.contains("Цена (лот 3): СООТВЕТСТВУЕТ — "), report);
        assertTrue(report.contains("⚠ JSON условий договора оборван (ответ модели зациклился или усечён): JSON-объект не закрыт"), report);
        assertTrue(report.endsWith("{\"цена\": \"СООТВЕТСТВУЕТ\", \"риск_сроков\": \"НЕ ОЦЕНИВАЕТСЯ\"}"), report);
    }

    @Test
    void intactContractHasNoTruncationLine() throws IOException {
        String contract = "{\"тип_документа\": \"договор\", \"сумма\": \"986724.24\", \"валюта\": \"RUB\", \"ИНН_поставщика\": \"5407955500\"}";

        String report = PriceTermOps.check(CONTRACT_HEADER + contract + PROTOCOL_HEADER + resource("regress/kom-v4-subbotin-lot3-s5.txt"));

        assertTrue(report.contains("Цена (лот 3): СООТВЕТСТВУЕТ — "), report);
        assertFalse(report.contains(PriceTermOps.TRUNCATED_MARK), report);
    }

    @Test
    void transformNodeWarnsAboutTruncatedContractAndParsesTextOnce() throws IOException {
        var dto = NodeDto.builder()
                .id("c3")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder().label("Цена и сроки (код)").rules("{\"операции\": [{\"оп\": \"сверить_цену_и_сроки\"}]}").build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
        graph.setRunnerUserId("user-1");
        var node = graph.getNodeMap().get("c3");
        node.getInput().add(loopCutInput());
        Logger logger = (Logger) LoggerFactory.getLogger(LlmJson.class);
        ListAppender<ILoggingEvent> journal = new ListAppender<>();
        journal.start();
        logger.addAppender(journal);

        String result;
        try {
            result = new ScenarioExecutorTransformNode(node).execute(sink);
        } finally {
            logger.detachAppender(journal);
        }

        assertTrue(result.contains(ScenarioExecutorTransformNode.WARNINGS_HEADER + "\n- операция «сверить_цену_и_сроки»: JSON условий договора оборван "
                + "(ответ модели зациклился или усечён): JSON-объект не закрыт"), result);
        assertFalse(node.getOutput().get(0).contains(ScenarioExecutorTransformNode.WARNINGS_HEADER), node.getOutput().get(0));
        assertEquals(1, journal.list.stream().filter(e -> e.getFormattedMessage().contains("JSON-объект не закрыт")).count(),
                journal.list.toString());
    }

    private static String loopCutInput() throws IOException {
        String s4 = resource("regress/kom-v4-subbotin-lot3-s4-head.txt").substring(0, 1061) + "\n" + GigaChatClient.LOOP_MARKER;
        return CONTRACT_HEADER + s4 + PROTOCOL_HEADER + resource("regress/kom-v4-subbotin-lot3-s5.txt");
    }

    private static String resource(String name) throws IOException {
        try (InputStream in = PriceTermOpsTruncatedContractTest.class.getClassLoader().getResourceAsStream(name)) {
            assertNotNull(in, name);
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}
