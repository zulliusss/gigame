package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Тесты разбора актов сдачи-приёмки (Сбер, docx/pdf) и распознанных
 * заявок/актов Альфа-Банка (вид и реквизиты по имени файла).
 */
class Form3ActsTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    static final String SBER_ACT = """
            АКТ
            сдачи-приёмки работ по
            Спецификации на разработку программного обеспечения № 4787401 от 17.11.2023г.
            к Договору № 4286515 на разработку/модификацию программного обеспечения
            от 09.09.2022 г.
            г. Москва \t\t «08» апреля 2025 г.
            Публичное акционерное общество «Сбербанк России», ПАО Сбербанк, именуемое в дальнейшем «Заказчик», в лице Вице-президента, \
            и Общество с ограниченной ответственностью «Хинт», ООО «Хинт», именуемое в дальнейшем «Исполнитель», в лице директора, \
            заключили настоящий акт о том, что по Спецификации № 4787401 к Договору № 4286515 от «09» сентября 2022 г. \
            Исполнителем переданы, а Заказчиком приняты Результаты работ.
            Общая стоимость работ по Этапу №2 в соответствии со Спецификацией составляет 1 712 787,00 (Один миллион) рублей.
            Следует к оплате по Акту 1 712 787,00 (Один миллион) рублей за период работа с 01.01.2025 по 31.03.2025г.
            1 | Сервис Jazz. Разработка 3D режима конференции для Android | Главный разработчик Android | 69 | 24 823,00 | 1 712 787,00
            """;

    static final String ALFA_ACT_OCR = """
            [РАСПОЗНАНО ИЗ СКАНА — данные извлечены автоматическим распознаванием] Документ «Заявка №104 Акт №б-н от 27.04.24.pdf»:
            Акт сдачи-приемки работ по Заявке № 104 от 15.04.2024 к Договору № АБ-С-ИТ-2020 от 03.02.2020
            ООО «Хинт», именуемое в дальнейшем «Исполнитель», с одной стороны, и АО «АЛЬФА-БАНК», именуемое в дальнейшем «Заказчик»
            Работы по разработке мобильного приложения Android выполнены. Итого с НДС: 22 849 905,00
            Подписи получателя АКЦИОНЕРНОЕ ОБЩЕСТВО "АЛЬФА-БАНК" 14.05.2024 Подпись соответствует файлу документа
            """;

    static final String OCR_ACT = """
            [РАСПОЗНАНО ИЗ СКАНА — суммы рекомендуется перепроверить] Документ «4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf»:
            Тип документа: Акт сдачи-приемки работ
            Реквизиты:
            - Дата акта: "20" декабря 2023 г.
            - Спецификация: №4653728 от 04.07.2023 г.
            - Договор: №4412866 от 01.12.2022 г.
            Стороны:
            - Заказчик: Публичное акционерное общество «Сбербанк России», ПАО Сбербанк
            | 1 | PFMASSETS-5760, [iOS] Сделать возможность оценки недвижимости |
            Суммы:
            - Стоимость этапа №2: 2 729 995,22 рубля
            """;

    /**
     * Штамп ЭДО СберКорус (акт по спецификации 5270341 комплекта 16.09.2026): подписи исполнителя и заказчика,
     * между ними — сроки действия сертификатов, которые датой подписания не являются.
     */
    static final String SBER_EDO_STAMP = """
            Документ подписан и передан через оператора ООО "СберКорус"
            Подписант, организация Сертификат, срок действия Дата и время подписания Доверенность
            Одинаева Ирина Владимировна
            018AE6D20009B2AB9E4B9502A35A7A7103 c 14.10.2024 12:37:52 UTC по 14.01.2026 12:47:52 UTC
            24.03.2025 17:28:43  Подпись соответствует файлу документа
            Дудина Наталья Владимировна
            02E096D200DAB1E8BF409059792B4DFEBE c 28.08.2024 12:36:44 UTC по 28.11.2025 12:46:44 UTC
            25.03.2025 15:20:32  Подпись соответствует файлу документа
            Идентификатор документа: 683400413
            Номер документа: б.н.
            """;

    /**
     * Штамп ЭДО Контур (Диадок), акт МЕТРО: время без секунд и с часовым поясом, фраза якоря разорвана
     * переносом строки, рядом — сроки действия сертификата и доверенности.
     */
    static final String KONTUR_EDO_STAMP = """
            Идентификатор документа afc3ceaf-b19b-4f37-93e4-130b8b096f9c
            Документ подписан и передан через оператора ЭДО АО «ПФ «СКБ Контур»
            Подписи
            отправителя:
             ООО "АМБРЕЛЛА АЛЬЯНС"
             Не требуется для подписания 02C7327500CEB2C9854F303BA5
            50C20E85
            с 29.04.2025 09:56 по
            29.07.2026 09:56 GMT+03:00
            19.06.2025 15:17 GMT+03:00
            Подпись соответствует файлу
            документа
            Подписи
            получателя:
             Общество с ограниченной
            ответственностью "МЕТРО Кэш энд
            Керри"
            с 18.06.2025 00:00 по 17.06.2027
            23:59 GMT+03:00
            Доверенность прошла проверку
            30.06.2025 13:50 GMT+03:00
            Подпись соответствует файлу
            документа
            """;

    /**
     * Штамп Контура в распознанном скане Комплекта 5 («Заявка №104 Акт №б-н от 27.04.24.pdf»): модель теряет двоеточия
     * во времени и часовом поясе, между подписями — сроки действия сертификатов «с … по …».
     */
    static final String KONTUR_OCR_STAMP = """
            Документ подписан и передан через оператора ЭДО АО «ПФ «СКБ Контур»
            Дата и время подписания
            Подписи
            отправителя
             ООО "ХИНТ"
            Федоткин Арсений Владимирович,
            ГЕНЕРАЛЬНЫЙ ДИРЕКТОР
             Не требуется для подписания 017022780034B034934B4D0F0E0
            D2D9A1F
            с 03.07.2023 10 07 по 03.10.2024
            10 07 GMT+03 00
            02.05.2024 18 47 GMT+03 00
            Подпись соответствует файлу
            документа
            Подписи
            получателя
             АКЦИОНЕРНОЕ ОБЩЕСТВО
            "АЛЬФА-БАНК"
            Задорожный Виталий Валерьевич,
             Не требуется для подписания 01D9CF7E70B8F9E0000BD03200
            060002
            с 15.08.2023 16 43 по 15.08.2024
            16 43 GMT+03 00
            14.05.2024 11 44 GMT+03 00
            Подпись соответствует файлу
            документа
            Страница 3 из 3
            """;

    /**
     * Штамп СберКорус только с подписью продавца (как у двухстраничного УПД 556 комплекта 8, данные обезличены):
     * печатная форма повторяет его на каждой странице.
     */
    static final String SELLER_ONLY_EDO_STAMP = """
            Документ подписан и передан через оператора ООО "СберКорус"
            Подписант, организация Сертификат, срок действия Дата и время подписания Доверенность
            Продавцов Олег Иванович   01AA02BB03CC04DD05EE06FF07AA08BB09 c 19.06.2024 08:32:15 UTC по
            19.09.2025 08:32:15 UTC
            03.04.2025 10:26:59  Подпись соответствует файлу документа
            """;

    @Test
    void edoStampGivesLatestSignatureAndIgnoresCertificateValidity() {
        // дата подписания — последняя подпись (заказчика), а не срок действия сертификата 28.11.2025
        assertEquals("25.03.2025", Form3Acts.edoSignDate(SBER_EDO_STAMP));
        assertEquals(2, Form3Acts.edoSignatures(SBER_EDO_STAMP));
        assertEquals("30.06.2025", Form3Acts.edoSignDate(KONTUR_EDO_STAMP));
        assertEquals(2, Form3Acts.edoSignatures(KONTUR_EDO_STAMP));
        assertEquals("", Form3Acts.edoSignDate("АКТ сдачи-приёмки работ от 24.03.2025 без штампа ЭДО"));
    }

    @Test
    void ocrStampWithoutColonsAndDateWithoutTimeAreRead() {
        // распознанный скан: время «18 47», пояс «GMT+03 00» — подписи отправителя и получателя, последняя — 14.05.2024
        assertEquals("14.05.2024", Form3Acts.edoSignDate(KONTUR_OCR_STAMP));
        assertEquals(List.of("02.05.2024", "14.05.2024"), Form3Acts.edoSignDates(KONTUR_OCR_STAMP));
        String senderOnly = KONTUR_OCR_STAMP.substring(0, KONTUR_OCR_STAMP.indexOf("Подписи\nполучателя"));
        assertEquals("02.05.2024", Form3Acts.edoSignDate(senderOnly));
        // дата без времени прямо перед фразой штампа
        assertEquals("14.05.2024", Form3Acts.edoSignDate(ALFA_ACT_OCR));
        // конец срока сертификата сразу перед фразой — не дата подписи; слово на «с» перед датой подписи дату не отменяет
        assertEquals("", Form3Acts.edoSignDate("Сертификат с 15.08.2023 по 15.08.2024 Подпись соответствует файлу документа"));
        assertEquals("15.08.2024", Form3Acts.edoSignDate("Подписи получателя: Иванов Денис 15.08.2024 Подпись соответствует файлу документа"));
    }

    @Test
    void actRegistryKeepsAllStampSignaturesStampMarkAndLabeledTotals() {
        Map<String, Object> scan = Form3Acts.parseAct("Заявка №104 Акт №б-н от 27.04.24.pdf", ALFA_ACT_OCR + KONTUR_OCR_STAMP);
        assertEquals("14.05.2024", scan.get("дата_подписания"));
        assertEquals(List.of("02.05.2024", "14.05.2024"), scan.get(Form3Acts.SIGNATURES));
        assertEquals(Boolean.TRUE, scan.get(Form3Acts.STAMP));

        // штамп есть, дата не разобрана: признак штампа остаётся, дата подписания пуста
        Map<String, Object> unparsed = Form3Acts.parseAct("Акт.pdf", "АКТ сдачи-приёмки работ\nДата и время подписания: см. оригинал\n"
                + "Подпись соответствует файлу документа");
        assertEquals("", unparsed.get("дата_подписания"));
        assertEquals(Boolean.TRUE, unparsed.get(Form3Acts.STAMP));

        // итоги акта Сбера — «составляет» и «Следует к оплате», но не ставка позиции 24 823,00
        Map<String, Object> sber = Form3Acts.parseAct("4787401 Акт Э2.docx", SBER_ACT);
        assertEquals(List.of("1712787.00"), sber.get(Form3Acts.TOTALS));
        assertEquals(Boolean.FALSE, sber.get(Form3Acts.STAMP));
    }

    @Test
    void edoStampIsReadThroughNonBreakingSpacesAndSoftHyphens() {
        // PDFBox отдаёт печатную форму СберКорус с неразрывными пробелами и мягкими переносами
        String asPdf = SBER_EDO_STAMP.replace(' ', ' ').replace("Подпись", "Под­пись");

        assertEquals("25.03.2025", Form3Acts.edoSignDate(asPdf));
        assertEquals(2, Form3Acts.edoSignatures(asPdf));
    }

    @Test
    void edoStampRepeatedOnEveryPageCountsEachSignatureOnce() {
        String twoPages = "Страница 1\n" + SELLER_ONLY_EDO_STAMP + "Страница 2\n" + SELLER_ONLY_EDO_STAMP;
        String untimed = "Подписи отправителя ООО «Альфа» 14.05.2024 Подпись соответствует файлу документа\n"
                + "Подписи получателя ООО «Бета» 14.05.2024 Подпись соответствует файлу документа\n";

        assertEquals(1, Form3Acts.edoSignatures(twoPages));
        assertEquals("03.04.2025", Form3Acts.edoSignDate(twoPages));
        assertEquals(2, Form3Acts.edoSignatures(SBER_EDO_STAMP + "\nСтраница 2\n" + SBER_EDO_STAMP));
        assertEquals(2, Form3Acts.edoSignatures(KONTUR_OCR_STAMP + KONTUR_OCR_STAMP));
        // подписи одного дня без времени различаются текстом штампа, повтор страницы их не удваивает
        assertEquals(2, Form3Acts.edoSignatures(untimed));
        assertEquals(2, Form3Acts.edoSignatures(untimed + untimed));
    }

    @Test
    void payableTotalTakesColumnNineWhenNumberIsBrokenByLineBreak() {
        String sber = """
                Всего к оплате (9)
                283411
                7,31
                ×
                566823,
                46
                340094
                0,77
                Руководитель организации
                """;
        String bigger = "Всего к оплате (9)\n124051\n80,06\n×\n248103\n6,01\n148862\n16,07\nРуководитель организации\n";

        assertEquals("3400940.77", Form3Acts.payableTotal(sber));
        assertEquals("14886216.07", Form3Acts.payableTotal(bigger));
        // печатная форма Контур: итог одной строкой, разряды через пробел
        assertEquals("3786626.80",
                Form3Acts.payableTotal("Всего к оплате (9) 3 786 626,80 x x без НДС 3 786 626,80\nРуководитель организации"));
        assertEquals("", Form3Acts.payableTotal("Итого: 5 047 339,00"));
    }

    @Test
    void actKeepsNumberSignDateAndMarksScanWithoutText() {
        Map<String, Object> act = Form3Acts.parseAct("МЕТРО.zip/2025/Акт 452 от 17.06.2025 - подписан.pdf",
                "Акт № 452 приема-передачи исключительных прав на доработку ПО\nИтого: 3 885 047,10\n" + KONTUR_EDO_STAMP);
        Map<String, Object> scan = Form3Acts.parseAct("Договор №32514746233 от 04.06.2025/Акт №104227011 от 20.06.2025.pdf",
                "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены автоматическим распознаванием] Документ «Акт №104227011 от 20.06.2025.pdf»:\n");

        assertEquals("452", act.get("номер"));
        assertEquals("17.06.2025", act.get("дата"));
        assertEquals("30.06.2025", act.get("дата_подписания"));
        assertEquals("3885047.10", act.get("сумма"));
        assertEquals(Boolean.FALSE, act.get("без_текста"));
        assertEquals(Boolean.TRUE, scan.get("без_текста"));
        assertEquals("104227011", scan.get("номер"));
        assertEquals("20.06.2025", scan.get("дата"));
    }

    @Test
    void sberActIsRecognizedByHeadingAndParsed() {
        assertTrue(Form3Acts.isAct("4787401 Акт Э2.docx", SBER_ACT));
        assertTrue(Form3Acts.isAct("Э2.docx", SBER_ACT));
        assertFalse(Form3Acts.isOrder("4787401 Акт Э2.docx", SBER_ACT));

        Map<String, Object> act = Form3Acts.parseAct("4787401 Акт Э2.docx", SBER_ACT);

        assertEquals("4787401", act.get("спецификация"));
        assertEquals("4286515", act.get("договор"));
        assertEquals("08.04.2025", act.get("дата"));
        assertEquals("1712787.00", act.get("сумма"));
        assertEquals("ПАО Сбербанк", act.get("покупатель"));
        assertEquals("ООО «Хинт»", act.get("продавец"));
        assertEquals(Boolean.TRUE, act.get("подпись_заказчика"));
        assertTrue(String.valueOf(act.get("подпись_примечание")).contains("не подтверждена"));
    }

    @Test
    void alfaFilesAreClassifiedByNameAndDatedFromName() {
        assertTrue(Form3Acts.isAct("Заявка №104 Акт №б-н от 27.04.24.pdf", ALFA_ACT_OCR));
        assertTrue(Form3Acts.isOrder("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка на выполнение работ iOS"));
        assertFalse(Form3Acts.isAct("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка на выполнение работ iOS"));
        assertFalse(Form3Acts.isAct("_ТЗ, кал. план, спецификация, форма акта-1_merge.pdf", "Техническое задание"));

        Map<String, Object> act = Form3Acts.parseAct("Заявка №104 от 15.04.2024 Акт №б-н от 27.04.2024.pdf", ALFA_ACT_OCR);
        assertEquals("104", act.get("заявка"));
        assertEquals("27.04.2024", act.get("дата"));
        assertEquals("22849905.00", act.get("сумма"));
        assertEquals("", act.get("подпись_примечание"));
        assertEquals("АО «АЛЬФА-БАНК»", act.get("покупатель"));
        assertEquals("ООО «Хинт»", act.get("продавец"));

        Map<String, Object> order = Form3Acts.parseOrder("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка iOS");
        assertEquals("104", order.get("номер"));
        assertEquals("15.04.2024", order.get("дата"));
        assertEquals("заявка", order.get("вид"));
    }

    @Test
    void registryPutsActsAndOrdersInPlace() throws Exception {
        String json = Form3Ops.registry(List.of(new Form3Ops.Source("4787401 Акт Э2.docx", SBER_ACT),
                new Form3Ops.Source("Заявка №104 от 15.04.2024.pdf", "[РАСПОЗНАНО] Документ:\nЗаявка на Android"),
                new Form3Ops.Source("Заявка №104 Акт №б-н от 27.04.24.pdf", ALFA_ACT_OCR)));
        Map<?, ?> registry = MAPPER.readValue(json, Map.class);

        assertEquals(2, ((List<?>) registry.get("акты")).size());
        assertEquals(1, ((List<?>) registry.get("спецификации")).size());
        assertEquals(0, ((List<?>) registry.get("прочее")).size());
    }

    @Test
    void recognizedActUsesLabelDateNotSpecificationDateFromFileName() {
        assertTrue(Form3Acts.isAct("4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf", OCR_ACT));
        assertTrue(Form3Acts.isAct("скан-без-имени.pdf", OCR_ACT));

        Map<String, Object> act = Form3Acts.parseAct("4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf", OCR_ACT);

        assertEquals("20.12.2023", act.get("дата"));
        assertEquals("4653728", act.get("спецификация"));
        assertEquals("4412866", act.get("договор"));
        assertTrue(((List<?>) act.get("суммы")).contains("2729995.22"));
        assertEquals("", Form3Acts.actNameDate("4. Акт Э2 к спец.№ 4653728 от 04.07.2023.pdf"));
        assertEquals("27.04.2024", Form3Acts.actNameDate("Заявка №104 от 15.04.2024 Акт №б-н от 27.04.24.pdf"));
        assertEquals("", Form3Acts.actNameDate("АКТ №1 по Заявке №50 от 17.06.25.pdf"));
    }

    @Test
    void recognizedSpecificationAndContractAreClassifiedByTypeLine() throws Exception {
        String spec = "[РАСПОЗНАНО] Документ «3. 4801685.pdf»:\nТип документа: Спецификация\nРеквизиты документа: № 4801685\n"
                + "Основание: Договор № 4412866 от «01» декабря 2022 г.\nГлавный разработчик iOS SB | 114 | 2 550 979,14";
        String contract = "[РАСПОЗНАНО] Документ «Договор.pdf»:\nТип документа: Договор № АБ-С-ИТ-2020 от 03.02.2020\nПредмет: разработка";
        Map<?, ?> registry = MAPPER.readValue(Form3Ops.registry(List.of(new Form3Ops.Source("3. 4801685.pdf", spec),
                new Form3Ops.Source("Договор №АБ-С-ИТ-2020.pdf", contract))), Map.class);

        assertEquals(1, ((List<?>) registry.get("спецификации")).size());
        assertEquals(1, ((List<?>) registry.get("договоры")).size());
        assertEquals("4801685", ((Map<?, ?>) ((List<?>) registry.get("спецификации")).get(0)).get("номер"));
        assertEquals("АБ-С-ИТ-2020", ((Map<?, ?>) ((List<?>) registry.get("договоры")).get(0)).get("номер"));
    }

    @Test
    void contractHeadingsWithPrefixesAreClassified() throws Exception {
        String framework = "Рамочный Договор № 5147758 на разработку/модификацию программного обеспечения\nг. Москва\n"
                + "Аналитик: опыт работы с технологиями Hadoop";
        String numbered = "1 ДОГОВОР № 32514746233 на выполнение работ по разработке алгоритмов для нужд АО «Россельхозбанк»\n"
                + "на базе программного обеспечения СУБД GreenPlum";
        Map<?, ?> registry = MAPPER.readValue(Form3Ops.registry(List.of(new Form3Ops.Source("Договор 5147758.pdf", framework),
                new Form3Ops.Source("Договор №32514746233.pdf", numbered),
                new Form3Ops.Source("ДС № 04.pdf", "Дополнительное соглашение №4 к Договору № ШТ-2023 от 21 апреля 2023"))), Map.class);

        List<?> contracts = (List<?>) registry.get("договоры");
        assertEquals(2, contracts.size());
        assertEquals("5147758", ((Map<?, ?>) contracts.get(0)).get("номер"));
        assertEquals("32514746233", ((Map<?, ?>) contracts.get(1)).get("номер"));
    }

    @Test
    void headingDateIgnoresContractDateInWords() {
        assertEquals("15.11.2023", Form3Acts.headingDate("к Договору от «09» сентября 2022 г.\nг. Москва «15» ноября 2023 г."));
        assertEquals("20.12.2023", Form3Acts.headingDate("г. Москва \nг. \n«-20- » декабря 2023"));
        assertEquals("", Form3Acts.headingDate("без города «15» ноября 2023 г."));
    }

    @Test
    void namesFromArchivesAreMatchedByBaseName() {
        // путь из архива: слово «акт» в имени папки не делает актом любой файл, а «Заявка №…» узнаётся после «/»
        assertFalse(Form3Acts.isAct("Акты 2024.zip/договор.pdf", "Договор № 5 на оказание услуг"));
        assertTrue(Form3Acts.isAct("комплект.zip/Акт №б-н от 27.04.24.pdf", "текст"));
        assertTrue(Form3Acts.isOrder("комплект.zip/Заявки/Заявка №104 от 15.04.2024.pdf", "текст"));
        assertFalse(Form3Acts.isOrder("Заявка №104 от 15.04.2024/договор.pdf", "Договор"));
        assertEquals("104", Form3Acts.parseOrder("комплект.zip/Заявка №104 от 15.04.2024.pdf", "текст").get("номер"));
        assertEquals("15.04.2024", Form3Acts.parseOrder("комплект.zip/Заявка №104 от 15.04.2024.pdf", "текст").get("дата"));
        assertEquals("27.04.2024", Form3Acts.parseAct("Заявки от 01.01.2020/Заявка №104 Акт №б-н от 27.04.24.pdf", "текст").get("дата"));
    }
}
