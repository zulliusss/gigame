package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.transaction.PlatformTransactionManager;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты чистки документов-сирот (загружены в диалог, но не попали ни в одно сообщение).
 */
@ExtendWith(MockitoExtension.class)
class DocumentRetentionServiceTest {

    @Mock
    private DocumentRepository documentRepository;
    @Mock
    private EmbeddingService embeddingService;
    @Mock
    private PlatformTransactionManager transactionManager;

    private DocumentRetentionService service;

    @BeforeEach
    void setUp() {
        service = new DocumentRetentionService(transactionManager, documentRepository, embeddingService);
    }

    @Test
    void purge_disabled_deletesNothing() {
        service.setRetentionHours(0);

        assertEquals(0, service.purgeOrphans(OffsetDateTime.now()));

        verify(documentRepository, never()).findOrphanIds(any(), anyInt());
        verify(documentRepository, never()).deleteAllByIdInBatch(any());
    }

    @Test
    void purge_deletesOrphansWithEmbeddingsInBatches_untilShortBatch() {
        service.setRetentionHours(24);
        OffsetDateTime now = OffsetDateTime.of(2026, 9, 16, 12, 0, 0, 0, ZoneOffset.UTC);
        OffsetDateTime cutoff = now.minusHours(24);
        List<UUID> first = Stream.generate(UUID::randomUUID).limit(DocumentRetentionService.BATCH_SIZE).toList();
        List<UUID> second = List.of(UUID.randomUUID());
        when(documentRepository.findOrphanIds(eq(cutoff), eq(DocumentRetentionService.BATCH_SIZE)))
                .thenReturn(first, second);

        assertEquals(first.size() + 1, service.purgeOrphans(now));

        verify(documentRepository).deleteAllByIdInBatch(first);
        verify(documentRepository).deleteAllByIdInBatch(second);
        verify(documentRepository, times(2)).findOrphanIds(any(), anyInt());
        verify(embeddingService, times(first.size() + 1)).deleteDocumentChunks(any());
        verify(embeddingService).deleteDocumentChunks(second.get(0));
    }

    @Test
    void purge_nothingOrphaned_deletesNothing() {
        service.setRetentionHours(24);
        when(documentRepository.findOrphanIds(any(), anyInt())).thenReturn(List.of());

        assertEquals(0, service.purgeOrphans(OffsetDateTime.now()));

        verify(documentRepository, never()).deleteAllByIdInBatch(any());
        verify(embeddingService, never()).deleteDocumentChunks(any());
    }

    @Test
    void scheduledPurge_swallowsDatabaseErrors() {
        service.setRetentionHours(24);
        when(documentRepository.findOrphanIds(any(), anyInt())).thenThrow(new IllegalStateException("БД недоступна"));

        assertDoesNotThrow(() -> service.purgeOrphans());
    }
}
