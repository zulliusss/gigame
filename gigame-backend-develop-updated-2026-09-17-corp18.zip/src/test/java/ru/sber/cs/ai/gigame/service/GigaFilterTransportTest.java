package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.api.chat.GigaChatApi;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestClient;
import ru.sber.cs.ai.gigame.exception.GigaChatException;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * HTTP-вызов GigaFilter по контракту {@code POST /filter/check}: тело запроса (model, messages, settings), вердикт
 * is_profane, сбои — 404 модели, непонятный ответ, таймаут, отсутствие клиента GigaChat API; 429 с Retry-After;
 * прерывание ожидающего потока — отмена, а не сбой фильтра.
 */
class GigaFilterTransportTest {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final List<String> paths = new CopyOnWriteArrayList<>();
    private final List<String> bodies = new CopyOnWriteArrayList<>();
    private volatile int status = 200;
    private volatile String answer = "{\"is_profane\":true,\"usage\":{\"filter_tokens\":5}}";
    private volatile long delayMillis;
    private volatile String retryAfter;
    private HttpServer server;
    private RestClient restClient;

    @BeforeEach
    void setUp() throws IOException {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/", exchange -> {
            paths.add(exchange.getRequestURI().getPath());
            bodies.add(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            pause();
            byte[] bytes = answer.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.getResponseHeaders().add("x-request-id", "req-filter-1");
            if (retryAfter != null) {
                exchange.getResponseHeaders().add("Retry-After", retryAfter);
            }
            exchange.sendResponseHeaders(status, bytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(bytes);
            }
        });
        server.start();
        restClient = RestClient.builder().baseUrl("http://127.0.0.1:" + server.getAddress().getPort() + "/v1")
                .defaultStatusHandler(new GigaChatResponseErrorHandler()).build();
    }

    @AfterEach
    void tearDown() {
        server.stop(0);
    }

    @Test
    void sendsContractBodyAndReadsVerdict() throws IOException {
        GigaFilterTransport transport = new GigaFilterTransport(() -> restClient);
        GigaFilterCheck.Request request = new GigaFilterCheck.Request("GigaFilter",
                List.of(new GigaFilterCheck.Message("user", "Наличие инструкции о мерах пожарной безопасности")),
                new GigaFilterCheck.Settings(true, true, true, false, "safe"), null);

        GigaFilterCheck.Outcome blocked = transport.check(request);
        answer = "{\"is_profane\":false,\"usage\":{\"filter_tokens\":82},\"unknown\":1}";
        GigaFilterCheck.Outcome allowed = transport.check(request);

        assertEquals(GigaFilterCheck.Outcome.verdict(true), blocked);
        assertEquals(GigaFilterCheck.Outcome.verdict(false), allowed);
        assertEquals("/v1/filter/check", paths.get(0));
        JsonNode body = MAPPER.readTree(bodies.get(0));
        assertEquals("GigaFilter", body.get("model").asText());
        assertEquals("user", body.get("messages").get(0).get("role").asText());
        assertEquals("Наличие инструкции о мерах пожарной безопасности", body.get("messages").get(0).get("content").asText());
        assertEquals("{\"neuro\":true,\"blacklist\":true,\"whitelist\":true,\"unnormalized_history\":false,\"safety\":\"safe\"}",
                body.get("settings").toString());
        assertFalse(body.has("safety"), "safety не в корне");
    }

    @Test
    void notFoundModelIsFailureWithStatus() {
        status = 404;
        answer = "{\"status\":404,\"message\":\"No such model\"}";

        GigaFilterCheck.Outcome outcome = new GigaFilterTransport(() -> restClient).check(request());

        assertFalse(outcome.definitive());
        assertEquals(Integer.valueOf(404), outcome.status());
        assertTrue(outcome.failure().contains("No such model"), outcome.failure());
    }

    @Test
    void unrecognizedAnswerIsFailure() {
        answer = "{\"choices\":[{\"finish_reason\":\"stop\"}]}";
        GigaFilterTransport transport = new GigaFilterTransport(() -> restClient);

        GigaFilterCheck.Outcome noField = transport.check(request());
        answer = "<html>шлюз</html>";
        GigaFilterCheck.Outcome notJson = transport.check(request());

        assertEquals(Integer.valueOf(200), noField.status());
        assertTrue(noField.failure().startsWith("в ответе фильтра нет is_profane"), noField.failure());
        assertTrue(notJson.failure().startsWith("непонятный ответ фильтра"), notJson.failure());
    }

    @Test
    void slowAnswerIsTimeoutFailure() {
        delayMillis = 3_000L;
        GigaFilterTransport transport = new GigaFilterTransport(() -> restClient);
        ReflectionTestUtils.setField(transport, "timeoutMillis", 300L);

        long started = System.currentTimeMillis();
        GigaFilterCheck.Outcome outcome = transport.check(request());

        assertTrue(System.currentTimeMillis() - started < 2_500L, "ожидание не ограничено");
        assertNull(outcome.status());
        assertEquals("таймаут ответа фильтра 300 мс", outcome.failure());
        transport.shutdown();
    }

    @Test
    void rateLimitedAnswerCarriesRetryAfter() {
        status = 429;
        retryAfter = "7";
        answer = "{\"status\":429,\"message\":\"Too Many Requests\"}";

        GigaFilterCheck.Outcome outcome = new GigaFilterTransport(() -> restClient).check(request());

        assertEquals(Integer.valueOf(429), outcome.status());
        assertEquals(7_000L, outcome.retryAfterMillis());
        assertTrue(outcome.rateLimited() && outcome.retryable());
        assertFalse(GigaFilterCheck.Outcome.failed(404, "404").retryable());
        assertTrue(GigaFilterCheck.Outcome.failed(502, "502").retryable());
        assertFalse(GigaFilterCheck.Outcome.failed(null, "таймаут").retryable());
    }

    @Test
    void interruptedWaitIsCancellationNotFilterFailure() throws InterruptedException {
        delayMillis = 3_000L;
        GigaFilterTransport transport = new GigaFilterTransport(() -> restClient);
        AtomicReference<RuntimeException> thrown = new AtomicReference<>();
        Thread caller = new Thread(() -> thrown.set(assertThrows(GigaChatException.class, () -> transport.check(request()))));

        caller.start();
        Thread.sleep(300L);
        caller.interrupt();
        caller.join(2_000L);

        assertEquals(GigaFilterTransport.INTERRUPTED, thrown.get().getMessage());
        assertInstanceOf(InterruptedException.class, thrown.get().getCause());
        transport.shutdown();
    }

    @Test
    void missingGigaChatApiIsFailure() {
        @SuppressWarnings("unchecked")
        ObjectProvider<GigaChatApi> provider = Mockito.mock(ObjectProvider.class);

        GigaFilterCheck.Outcome noBean = new GigaFilterTransport(provider).check(request());
        GigaFilterCheck.Outcome failingSource = new GigaFilterTransport(() -> {
            throw new IllegalStateException("контекст закрыт");
        }).check(request());

        assertEquals("клиент GigaChat API недоступен (нет бина GigaChatApi)", noBean.failure());
        assertTrue(failingSource.failure().contains("контекст закрыт"), failingSource.failure());
        assertNull(GigaFilterTransport.restClientOf(null));
        assertTrue(paths.isEmpty());
    }

    private void pause() {
        try {
            Thread.sleep(delayMillis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static GigaFilterCheck.Request request() {
        return new GigaFilterCheck.Request("GigaFilter", List.of(new GigaFilterCheck.Message("user", "текст")),
                new GigaFilterCheck.Settings(true, true, true, false, null), null);
    }
}
