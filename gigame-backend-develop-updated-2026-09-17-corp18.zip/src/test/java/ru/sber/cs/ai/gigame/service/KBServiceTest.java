package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.dto.kb.KBDetailResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.dto.kb.KBResponse;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.IntStream;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.never;

@ExtendWith(MockitoExtension.class)
class KBServiceTest {

    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Mock
    private KBDocumentRepository kbDocumentRepository;

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private DocumentService documentService;

    @Mock
    private EmbeddingService embeddingService;

    @Mock
    private DocumentIndexService indexService;

    @Mock
    private KBUploadProcessor uploadProcessor;

    @InjectMocks
    private KBService kbService;

    @Captor
    private ArgumentCaptor<KnowledgeBase> kbCaptor;

    @Captor
    private ArgumentCaptor<KBUploadProcessor.PendingUpload> uploadCaptor;

    @Captor
    private ArgumentCaptor<Document> documentCaptor;

    private UUID userId;
    private UUID kbId;
    private KnowledgeBase knowledgeBase;
    private Document document;

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        knowledgeBase = new KnowledgeBase();
        knowledgeBase.setId(kbId);
        knowledgeBase.setUserId(userId.toString());
        knowledgeBase.setName("Test KB");
        knowledgeBase.setDescription("Description");

        document = new Document();
        document.setId(UUID.randomUUID());
        document.setFilename("test.pdf");
        document.setContentType("pdf");
        document.setSizeBytes(1024);
        document.setExtractedText("test content");
        document.setUserId(userId.toString());

        ReflectionTestUtils.setField(documentService, "charLimit", 12000);
    }

    // -------------------------------------------------------------------------
    // Шаринг: общие базы знаний
    // -------------------------------------------------------------------------

    @Test
    void testGetKnowledgeBase_sharedKb_accessibleToOtherUser() {
        knowledgeBase.setShared(true);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(any())).thenReturn(List.of());

        var result = CurrentUserHolder.withUser("OTHER1", () -> kbService.getKnowledgeBase(kbId));

        assertNotNull(result);
        assertTrue(result.shared());
        assertFalse(result.isOwner());
    }

    @Test
    void testGetKnowledgeBase_privateKb_deniedToOtherUser() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("OTHER1", () -> kbService.getKnowledgeBase(kbId)));
    }

    @Test
    void testUpdateKnowledgeBase_sharedKb_deniedToNonOwner() {
        knowledgeBase.setShared(true);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("OTHER1", () -> kbService.updateKnowledgeBase(kbId, "hacked", null, null)));
    }

    @Test
    void testUpdateKnowledgeBase_ownerTogglesShared() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.updateKnowledgeBase(kbId, null, null, true));

        assertNotNull(result);
        assertTrue(result.shared());
        assertTrue(knowledgeBase.isShared());
    }

    @Test
    void testGetDocumentView_owner() {
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));

        var result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getDocumentView(document.getId()));

        assertNotNull(result);
        assertEquals("test.pdf", result.filename());
        assertEquals("test content", result.extractedText());
    }

    @Test
    void testGetDocumentView_filenameMatchesSchemaPattern() {
        // [spec #6]: имя с macOS/Linux может содержать символы, запрещённые pattern filename
        document.setFilename("Протокол 12:30 | итог.pdf");
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));

        var result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getDocumentView(document.getId()));

        assertEquals("Протокол 12_30 _ итог.pdf", result.filename());
        assertEquals("Протокол 12:30 | итог.pdf", document.getFilename());
    }

    @Test
    void testGetKnowledgeBase_documentFilenamesMatchSchemaPattern() {
        document.setFilename("Акт: " + "ж".repeat(300) + ".docx");
        KBDocument link = new KBDocument();
        link.setId(UUID.randomUUID());
        link.setKnowledgeBase(knowledgeBase);
        link.setDocument(document);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(any())).thenReturn(List.of(link));

        KBDetailResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getKnowledgeBase(kbId));

        String filename = result.documents().get(0).filename();
        assertEquals(255, filename.length());
        assertTrue(filename.startsWith("Акт_ "), filename);
        assertTrue(filename.endsWith("….docx"), filename);
    }

    @Test
    void testGetDocumentView_clipsExtractedTextToSchemaLimit() {
        // [kb-doc #0]: extracted_text в схеме maxLength 500000, полный текст крупного закона длиннее
        document.setExtractedText("статья ".repeat(100_000));
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));

        var result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getDocumentView(document.getId()));

        assertEquals(KBService.EXTRACTED_TEXT_MAX_LENGTH, result.extractedText().length());
        assertTrue(result.extractedText().startsWith("статья статья"));
        assertTrue(result.extractedText().contains("текст документа усечён до 500000 из 700000 символов"));
        assertEquals(700_000, document.getExtractedText().length());
    }

    @Test
    void testGetDocumentView_viaSharedKb() {
        knowledgeBase.setShared(true);
        KBDocument link = new KBDocument();
        link.setKnowledgeBase(knowledgeBase);
        link.setDocumentId(document.getId());
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(any())).thenReturn(List.of(link));

        var result = CurrentUserHolder.withUser("OTHER1", () -> kbService.getDocumentView(document.getId()));

        assertNotNull(result);
        assertEquals("test.pdf", result.filename());
    }

    @Test
    void testGetDocumentView_denied_whenNoAccessibleKb() {
        KBDocument link = new KBDocument();
        // личная база другого пользователя
        link.setKnowledgeBase(knowledgeBase);
        link.setDocumentId(document.getId());
        when(documentRepository.findById(any())).thenReturn(Optional.of(document));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(any())).thenReturn(List.of(link));
        var docId = document.getId();
        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("OTHER1", () -> kbService.getDocumentView(docId)));
    }

    @Test
    void testGetKnowledgeBases_withSearch() {
        when(knowledgeBaseRepository.searchAccessible(anyString(), any()))
                .thenReturn(List.of(knowledgeBase));

        List<KBResponse> result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getKnowledgeBases("test"));

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(knowledgeBaseRepository).searchAccessible(userId.toString(), "test");
    }

    @Test
    void testGetKnowledgeBases_withoutSearch() {
        when(knowledgeBaseRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString()))
                .thenReturn(List.of(knowledgeBase));

        List<KBResponse> result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getKnowledgeBases(null));

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(knowledgeBaseRepository).findByUserIdOrSharedTrueOrderByUpdatedAtDesc(userId.toString());
    }

    @Test
    void testGetKnowledgeBase_withExistingKB() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(any()))
                .thenReturn(List.of());

        KBDetailResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getKnowledgeBase(kbId));

        assertNotNull(result);
        assertEquals("Test KB", result.name());
        assertEquals("Description", result.description());
    }

    @Test
    void testGetKnowledgeBase_withNonExistingKB_throwsNotFoundException() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> kbService.getKnowledgeBase(uuid)));
    }

    @Test
    void testCreateKnowledgeBase() {
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.createKnowledgeBase("Test KB", "Description", null));

        assertNotNull(result);
        verify(knowledgeBaseRepository).save(kbCaptor.capture());
        assertEquals("Test KB", kbCaptor.getValue().getName());
        assertEquals("Description", kbCaptor.getValue().getDescription());
        assertEquals(userId.toString(), kbCaptor.getValue().getUserId());
    }

    @Test
    void testCreateKnowledgeBase_withNullDescription() {
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.createKnowledgeBase("Test KB", null, null));

        assertNotNull(result);
        verify(knowledgeBaseRepository).save(kbCaptor.capture());
        assertEquals("Test KB", kbCaptor.getValue().getName());
        assertNull(kbCaptor.getValue().getDescription());
    }

    @Test
    void testUpdateKnowledgeBase_withValidName() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.updateKnowledgeBase(kbId, "New Name", null, null));

        assertNotNull(result);
        assertEquals("New Name", knowledgeBase.getName());
    }

    @Test
    void testUpdateKnowledgeBase_withNonExistingKB_throwsNotFoundException() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> kbService.updateKnowledgeBase(uuid, "New Name", null, null)));
    }

    @Test
    void testUpdateKnowledgeBase_withValidDescription() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.updateKnowledgeBase(kbId, null, "New Description", null));

        assertNotNull(result);
        assertEquals("New Description", knowledgeBase.getDescription());
    }

    @Test
    void testUpdateKnowledgeBase_withBothParameters() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(knowledgeBaseRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.updateKnowledgeBase(kbId, "New Name", "New Description", null));

        assertNotNull(result);
        assertEquals("New Name", knowledgeBase.getName());
        assertEquals("New Description", knowledgeBase.getDescription());
    }

    @Test
    void testDeleteKnowledgeBase_withExistingKB() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertDoesNotThrow(() -> CurrentUserHolder.withUser(userId.toString(), () -> {
            kbService.deleteKnowledgeBase(kbId);
            return null;
        }));

        verify(embeddingService).deleteKBCollection(kbId);
        verify(knowledgeBaseRepository).delete(knowledgeBase);
    }

    @Test
    void testDeleteKnowledgeBase_withNonExistingKB_throwsNotFoundException() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                    kbService.deleteKnowledgeBase(uuid);
                    return null;
                }));
    }

    private FilePart filePart(String filename) {
        FilePart file = mock(FilePart.class);
        when(file.filename()).thenReturn(filename);
        return file;
    }

    private void stubNewUpload(byte[] content) {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(documentService.readContent(any())).thenReturn(content);
        when(kbDocumentRepository.findByKbAndFileContent(any(), any(), any())).thenReturn(List.of());
        when(documentRepository.save(any())).thenAnswer(inv -> {
            Document saved = inv.getArgument(0);
            saved.setId(UUID.randomUUID());
            return saved;
        });
        doAnswer(inv -> {
            KBDocument kbDoc = inv.getArgument(0);
            kbDoc.setId(UUID.randomUUID());
            return kbDoc;
        }).when(kbDocumentRepository).save(any());
    }

    @Test
    void testAddDocumentToKB_answersProcessing_andQueuesParsingAndIndexingInBackground() {
        byte[] content = "содержимое".getBytes(StandardCharsets.UTF_8);
        stubNewUpload(content);

        KBDocumentResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> kbService.addDocumentToKB(kbId, filePart("test.txt")));

        assertEquals("processing", result.status());
        assertEquals("test.txt", result.filename());
        verify(uploadProcessor).processAsync(uploadCaptor.capture());
        KBUploadProcessor.PendingUpload upload = uploadCaptor.getValue();
        assertEquals(kbId, upload.kbId());
        assertEquals(result.documentId(), upload.documentId());
        assertEquals(result.id(), upload.kbDocId());
        assertEquals(userId.toString(), upload.userId());
        assertEquals("txt", upload.contentType());
        assertArrayEquals(content, upload.content());
        // разбор и OCR не выполняются в HTTP-запросе
        verify(documentService, never()).extractText(any(), any(), any());
        verify(documentService, never()).uploadDocument(any());
        verify(documentRepository).save(documentCaptor.capture());
        assertEquals(DocumentService.sha256Hex(content), documentCaptor.getValue().getContentSha256());
        assertEquals(content.length, documentCaptor.getValue().getSizeBytes());
        assertEquals(userId.toString(), documentCaptor.getValue().getUserId());
        assertNull(documentCaptor.getValue().getExtractedText());
    }

    @Test
    void testAddDocumentToKB_queueFull_marksErrorWithReason() {
        stubNewUpload("x".getBytes(StandardCharsets.UTF_8));
        doThrow(new TaskRejectedException("очередь заполнена")).when(uploadProcessor).processAsync(any());
        when(indexService.markIndexingFailed(eq(kbId), any(), any(), eq(KBService.QUEUE_FULL))).thenAnswer(inv -> {
            KBDocument failed = new KBDocument();
            failed.setId(inv.getArgument(2));
            failed.setKnowledgeBase(knowledgeBase);
            failed.setDocument(document);
            failed.setStatus("error");
            failed.setErrorMessage(KBService.QUEUE_FULL);
            return failed;
        });

        KBDocumentResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> kbService.addDocumentToKB(kbId, filePart("test.txt")));

        assertEquals("error", result.status());
        assertTrue(result.errorMessage().contains("очередь индексации переполнена"), result.errorMessage());
    }

    private KBDocument existingLink(String status) {
        KBDocument existing = new KBDocument();
        existing.setId(UUID.randomUUID());
        existing.setKnowledgeBase(knowledgeBase);
        existing.setDocumentId(document.getId());
        existing.setDocument(document);
        existing.setStatus(status);
        return existing;
    }

    @Test
    void testAddDocumentToKB_sameFileAlreadyIndexed_skippedWithWarning() {
        byte[] content = "содержимое".getBytes(StandardCharsets.UTF_8);
        KBDocument existing = existingLink("ready");
        existing.setChunkCount(7);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(documentService.readContent(any())).thenReturn(content);
        when(kbDocumentRepository.findByKbAndFileContent(kbId, "test.pdf", DocumentService.sha256Hex(content)))
                .thenReturn(List.of(existing));

        KBDocumentResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> kbService.addDocumentToKB(kbId, filePart("test.pdf")));

        assertEquals(existing.getId(), result.id());
        assertEquals("ready", result.status());
        assertEquals(7, result.chunkCount());
        assertEquals(KBService.DUPLICATE_SKIPPED, result.errorMessage());
        // в БД предупреждение не пишется, новый документ не создаётся, обработка не ставится в очередь
        assertNull(existing.getErrorMessage());
        verify(documentRepository, never()).save(any());
        verify(kbDocumentRepository, never()).save(any());
        verify(uploadProcessor, never()).processAsync(any());
    }

    @Test
    void testAddDocumentToKB_sameFileAfterFailure_replacedAndReprocessed() {
        byte[] content = "содержимое".getBytes(StandardCharsets.UTF_8);
        KBDocument existing = existingLink("error");
        existing.setErrorMessage("GigaChat недоступен");
        existing.setChunkCount(3);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(documentService.readContent(any())).thenReturn(content);
        when(kbDocumentRepository.findByKbAndFileContent(any(), any(), any())).thenReturn(List.of(existing));
        when(kbDocumentRepository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        KBDocumentResponse result = CurrentUserHolder.withUser(userId.toString(),
                () -> kbService.addDocumentToKB(kbId, filePart("test.pdf")));

        assertEquals(existing.getId(), result.id());
        assertEquals("processing", result.status());
        assertNull(result.errorMessage());
        assertEquals(0, result.chunkCount());
        verify(embeddingService).deleteKBDocumentChunks(kbId, document.getId());
        verify(documentRepository, never()).save(any());
        verify(uploadProcessor).processAsync(uploadCaptor.capture());
        assertEquals(existing.getId(), uploadCaptor.getValue().kbDocId());
        assertEquals(document.getId(), uploadCaptor.getValue().documentId());
    }

    @Test
    void testAddDocumentToKB_unsupportedExtension_rejectedBeforeReading() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        FilePart file = filePart("virus.exe");
        String owner = userId.toString();

        assertThrows(FileException.class, () -> CurrentUserHolder.withUser(owner, () -> kbService.addDocumentToKB(kbId, file)));

        verify(documentService, never()).readContent(any());
        verify(uploadProcessor, never()).processAsync(any());
    }

    @Test
    void testAddDocumentToKB_blankFilename_rejected() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        FilePart file = filePart("  ");
        String owner = userId.toString();

        assertThrows(FileException.class, () -> CurrentUserHolder.withUser(owner, () -> kbService.addDocumentToKB(kbId, file)));
    }

    @Test
    void testAddDocumentToKB_nonOwner_denied() {
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        FilePart file = mock(FilePart.class);

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("OTHER1", () -> kbService.addDocumentToKB(kbId, file)));

        verify(uploadProcessor, never()).processAsync(any());
    }

    // -------------------------------------------------------------------------
    // corp17: ограничения спецификации в ответах (SOWA)
    // -------------------------------------------------------------------------

    @Test
    void testGetKnowledgeBase_limitsDocumentsToSchemaMaxItems() {
        List<KBDocument> links = IntStream.range(0, 1001).mapToObj(i -> {
            KBDocument link = new KBDocument();
            link.setId(UUID.randomUUID());
            link.setKnowledgeBase(knowledgeBase);
            link.setDocument(document);
            return link;
        }).toList();
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(any())).thenReturn(links);

        KBDetailResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getKnowledgeBase(kbId));

        assertEquals(1000, result.documents().size());
        assertEquals(links.get(0).getId(), result.documents().get(0).id());
    }

    @Test
    void testGetKnowledgeBase_clipsLongErrorMessageAndDescription() {
        knowledgeBase.setDescription("о".repeat(300));
        KBDocument link = new KBDocument();
        link.setId(UUID.randomUUID());
        link.setKnowledgeBase(knowledgeBase);
        link.setDocument(document);
        link.setStatus("error");
        link.setErrorMessage("Не удалось выполнить запрос к GigaChat: " + "х".repeat(300));
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdWithDocument(any())).thenReturn(List.of(link));

        KBDetailResponse result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getKnowledgeBase(kbId));

        assertEquals(255, result.description().length());
        assertEquals(255, result.documents().get(0).errorMessage().length());
        assertTrue(result.documents().get(0).errorMessage().startsWith("Не удалось выполнить запрос к GigaChat"));
        // хранимое значение не меняется
        assertEquals(300 + "Не удалось выполнить запрос к GigaChat: ".length(), link.getErrorMessage().length());
    }

    @Test
    void testGetKnowledgeBases_limitsListToSchemaMaxItems() {
        List<KnowledgeBase> many = IntStream.range(0, 1005).mapToObj(i -> {
            KnowledgeBase kb = new KnowledgeBase();
            kb.setId(UUID.randomUUID());
            kb.setName("KB " + i);
            kb.setUserId(userId.toString());
            return kb;
        }).toList();
        when(knowledgeBaseRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(anyString())).thenReturn(many);

        List<KBResponse> result = CurrentUserHolder.withUser(userId.toString(), () -> kbService.getKnowledgeBases(null));

        assertEquals(1000, result.size());
    }

    @Test
    void testRemoveDocumentFromKB_withExistingKBDocument() {
        var kb = new KnowledgeBase();
        UUID docId = UUID.randomUUID();
        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        kbDoc.setDocument(document);

        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any()))
                .thenReturn(Optional.of(kbDoc));
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));

        assertDoesNotThrow(() -> CurrentUserHolder.withUser(userId.toString(), () -> {
            kbService.removeDocumentFromKB(kbId, docId);
            return null;
        }));

        verify(embeddingService).deleteKBDocumentChunks(kbId, docId);
        verify(kbDocumentRepository).delete(kbDoc);
    }

    @Test
    void testRemoveDocumentFromKB_withNonExistingKBDocument_throwsNotFoundException() {
        UUID docId = UUID.randomUUID();

        lenient().when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(any(), any()))
                .thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> {
                    kbService.removeDocumentFromKB(kbId, docId);
                    return null;
                }));
    }

    private KBDocument link(KnowledgeBase kb, UUID docId) {
        KBDocument kbDoc = new KBDocument();
        kbDoc.setKnowledgeBase(kb);
        kbDoc.setDocumentId(docId);
        return kbDoc;
    }

    @Test
    void testDeleteKnowledgeBase_deletesDocumentsOwnedOnlyByThisKb() {
        UUID ownDocId = UUID.randomUUID();
        UUID sharedDocId = UUID.randomUUID();
        KnowledgeBase other = new KnowledgeBase();
        other.setId(UUID.randomUUID());
        KBDocument own = link(knowledgeBase, ownDocId);
        KBDocument shared = link(knowledgeBase, sharedDocId);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseId(kbId)).thenReturn(List.of(own, shared));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(ownDocId)).thenReturn(List.of(own));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(sharedDocId))
                .thenReturn(List.of(shared, link(other, sharedDocId)));

        CurrentUserHolder.withUser(userId.toString(), () -> {
            kbService.deleteKnowledgeBase(kbId);
            return null;
        });

        verify(knowledgeBaseRepository).delete(knowledgeBase);
        verify(embeddingService).deleteDocumentChunks(ownDocId);
        verify(documentRepository).deleteById(ownDocId);
        verify(documentRepository, never()).deleteById(sharedDocId);
        verify(embeddingService, never()).deleteDocumentChunks(sharedDocId);
    }

    @Test
    void testRemoveDocumentFromKB_deletesDocumentWhenNoOtherKbUsesIt() {
        UUID docId = UUID.randomUUID();
        KBDocument kbDoc = link(knowledgeBase, docId);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(kbId, docId)).thenReturn(Optional.of(kbDoc));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(docId)).thenReturn(List.of(kbDoc));

        CurrentUserHolder.withUser(userId.toString(), () -> {
            kbService.removeDocumentFromKB(kbId, docId);
            return null;
        });

        verify(kbDocumentRepository).delete(kbDoc);
        verify(embeddingService).deleteDocumentChunks(docId);
        verify(documentRepository).deleteById(docId);
    }

    @Test
    void testRemoveDocumentFromKB_keepsDocumentUsedByAnotherKb() {
        UUID docId = UUID.randomUUID();
        KnowledgeBase other = new KnowledgeBase();
        other.setId(UUID.randomUUID());
        KBDocument kbDoc = link(knowledgeBase, docId);
        when(knowledgeBaseRepository.findById(any())).thenReturn(Optional.of(knowledgeBase));
        when(kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(kbId, docId)).thenReturn(Optional.of(kbDoc));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(docId)).thenReturn(List.of(kbDoc, link(other, docId)));

        CurrentUserHolder.withUser(userId.toString(), () -> {
            kbService.removeDocumentFromKB(kbId, docId);
            return null;
        });

        verify(kbDocumentRepository).delete(kbDoc);
        verify(documentRepository, never()).deleteById(any());
        verify(embeddingService, never()).deleteDocumentChunks(any());
    }
}
