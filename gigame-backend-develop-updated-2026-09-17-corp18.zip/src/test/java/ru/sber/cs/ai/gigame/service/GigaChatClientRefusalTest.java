package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatModel;
import chat.giga.springai.api.chat.GigaChatApi;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.metadata.ChatGenerationMetadata;
import org.springframework.ai.chat.metadata.ChatResponseMetadata;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.test.util.ReflectionTestUtils;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.exception.GigaChatRefusedException;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTimeout;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.notNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Политика отказа цензора GigaChat: распознавание по finish_reason=blacklist (основной признак) и фразам, деление
 * документа сразу (без повтора «с рамкой») с бюджетом вызовов, пометка отклонённых частей со знаками контекста,
 * уведомления по ходу деления, ошибка узла при отказе во всех частях; дочитывание, агент и OCR не принимают текст
 * отказа за ответ; обычные ответы и чат (без контекста прогона) не затронуты.
 */
class GigaChatClientRefusalTest {

    private static final String INSTRUCTION = "Ты — аналитик закупок. Извлеки из ТЗ предмет, срок и требования к "
            + "исполнителю и верни ОДИН плоский JSON-объект.";
    private static final String ANSWER = "{\"предмет\": \"аудит пожарной безопасности\", \"срок\": \"30 рабочих дней\"}";
    private static final String ARRAY_ANSWER = "[{\"критерий\": \"Технология 1\", \"значение\": \"Java\", "
            + "\"источник\": \"Раздел 6\", \"секция\": \"ЛОТ №1\"}]";
    /** Пункт чек-листа, на котором цензор отказывает (проба 16.09.2026, п.3.1.1.1). */
    private static final String SENSITIVE = "Наличие инструкции о мерах пожарной безопасности, с учетом специфики "
            + "пожароопасных помещений в указанных зданиях, сооружениях.";
    /** Текст отказа, которого нет среди фраз: распознаётся только по finish_reason. */
    private static final String UNKNOWN_REFUSAL = "Эта тема сейчас недоступна.";
    private static final String START_NOTICE = "⚠ модель отказалась (ограничение темы GigaChat) — документ делится на части "
            + "(не больше 16 запросов к модели), отклонённые фрагменты будут помечены";
    private static final String TOO_LONG = "HTTP 422 - {\"status\":422,\"message\":\"Invalid params: context too long 190108\"}";

    private final ChatModel chatModel = Mockito.mock(ChatModel.class);
    private final List<String> notices = new CopyOnWriteArrayList<>();
    private final List<String> sentTexts = new CopyOnWriteArrayList<>();
    private GigaChatClient client;

    @BeforeEach
    void setUp() {
        client = new GigaChatClient(chatModel, Mockito.mock(EmbeddingModel.class));
        ReflectionTestUtils.setField(client, "retryMaxAttempts", 1);
        ReflectionTestUtils.setField(client, "retryDelayMillis", 60_000L);
        ReflectionTestUtils.setField(client, "retryDelay429Millis", 60_000L);
        ReflectionTestUtils.setField(client, "callHardTimeoutSeconds", 0L);
        // поток узла сценария: движок ставит проверку остановки и получателя уведомлений журнала прогона
        GigaChatClient.setRunCancelCheck(() -> false);
        GigaChatClient.setRunWaitNotice(notice -> notices.add(sentTexts.size() + ":" + notice));
    }

    @AfterEach
    void tearDown() {
        GigaChatClient.clearRunCancelCheck();
        GigaChatClient.clearRunWaitNotice();
    }

    @Test
    void blacklistFinishReasonSplitsDocumentAtOnceWithoutFrameRetry() {
        modelResponds(text -> text.contains(SENSITIVE) ? blacklisted(UNKNOWN_REFUSAL) : stop(ANSWER));
        String context = twoDocuments();
        String raw = "\n\n" + context;
        String rejected = context.substring(context.indexOf("<<<Документ: ТЗ приложение 3.docx>>>"));

        String text = client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, context, false)),
                null, null);

        assertEquals("=== Часть 1/2 (запрос разделён из-за ограничения темы GigaChat) ===\n" + ANSWER + "\n\n"
                + "=== Часть 2/2 (запрос разделён из-за ограничения темы GigaChat) ===\n"
                + marker(2, 2, raw, rejected), text);
        // полный запрос и две части — повтора «с рамкой» нет
        assertEquals(3, sentTexts.size());
        assertEquals(INSTRUCTION + "\n\n" + context, sentTexts.get(0));
        assertTrue(sentTexts.get(1).startsWith(INSTRUCTION + "\n\nДокументы:"), sentTexts.get(1));
        assertTrue(sentTexts.get(2).startsWith(INSTRUCTION + "\n\n<<<Документ: ТЗ приложение 3.docx>>>"), sentTexts.get(2));
        assertEquals(List.of("1:" + START_NOTICE,
                "3:⚠ фрагмент " + span(raw, rejected) + " отклонён моделью (ограничение темы GigaChat) — помечен в ответе, "
                        + "остальные части обрабатываются",
                "3:⚠ модель отказалась (ограничение темы GigaChat) — ответ собран из 2 частей: принято 1, отклонено 1"),
                notices);
    }

    @Test
    void rejectedPartOfArrayContractNodeKeepsMergedArrayOfAcceptedParts() {
        modelResponds(text -> text.contains(SENSITIVE) ? blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL) : stop(ARRAY_ANSWER));
        String context = twoDocuments();

        String text = client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, context, true)),
                null, null);

        String rejected = context.substring(context.indexOf("<<<Документ: ТЗ приложение 3.docx>>>"));
        assertTrue(text.startsWith("=== Ответ собран из 2 частей (запрос разделён из-за ограничения темы GigaChat), "
                + "JSON-массивы частей объединены ===\n" + marker(2, 2, "\n\n" + context, rejected) + "\n["), text);
        assertEquals(1, PromptSplitter.jsonArray(text).size());
        // проверка контракта json_массив берёт последний массив объектов — маркер его не заслоняет
        assertNotNull(LlmJson.last(text, LlmJson.ARRAY_OF_OBJECTS_OR_EMPTY).first());
    }

    @Test
    void rejectedLongPartIsDividedDeeperWithNoticesOnTheWay() {
        modelResponds(text -> text.contains(SENSITIVE) ? blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL) : stop(ANSWER));
        String context = "Документы:\n" + document("ТЗ раздел 1.docx", GigaChatRefusalTest.NOTICE_LINE, 6) + "\n\n"
                + document("ТЗ раздел 2.docx", GigaChatRefusalTest.NOTICE_LINE, 6) + "\n\n"
                + document("ТЗ раздел 3.docx", GigaChatRefusalTest.NOTICE_LINE, 6) + "\n\n"
                + document("ТЗ приложение 3.docx", SENSITIVE, 14);
        String raw = "\n\n" + context;

        String text = client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, context, false)),
                null, null);

        // полный запрос, разделы 1–2 (приняты), раздел 3 + приложение (отказ), раздел 3, приложение (отказ)
        assertEquals(5, sentTexts.size(), String.join("\n-----\n", sentTexts));
        assertTrue(sentTexts.get(3).contains("ТЗ раздел 3.docx") && !sentTexts.get(3).contains(SENSITIVE));
        String appendix = context.substring(context.indexOf("<<<Документ: ТЗ приложение 3.docx>>>"));
        String tail = context.substring(context.indexOf("<<<Документ: ТЗ раздел 3.docx>>>"));
        assertTrue(text.contains("=== Часть 2/3 (запрос разделён из-за ограничения темы GigaChat) ===\n" + ANSWER), text);
        assertTrue(text.endsWith("=== Часть 3/3 (запрос разделён из-за ограничения темы GigaChat) ===\n"
                + marker(3, 3, raw, appendix)), text);
        // уведомления по ходу: об отклонённой части — до вызовов её половин, а не после сборки ответа
        assertEquals(List.of("1:" + START_NOTICE,
                "3:⚠ фрагмент " + span(raw, tail) + " отклонён моделью — делю его на 2 части",
                "5:⚠ фрагмент " + span(raw, appendix) + " отклонён моделью (ограничение темы GigaChat) — помечен в ответе, "
                        + "остальные части обрабатываются",
                "5:⚠ модель отказалась (ограничение темы GigaChat) — ответ собран из 3 частей: принято 2, отклонено 1"),
                notices);
    }

    @Test
    void refusalEverywhereOnLongDocumentStopsWithinCallBudget() {
        modelResponds(text -> blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL));
        String context = longContext(-1);
        assertTrue(context.length() >= 40_000, "длина " + context.length());

        var e = assertThrows(GigaChatRefusedException.class, () -> client.chatCompletion(
                nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, context, false)), null, null));

        // f67: 16 вызовов до ошибки (повтор с рамкой и деление до глубины 3); теперь после двух уровней без единой
        // принятой части деление прекращается — 7 вызовов
        assertEquals(7, sentTexts.size());
        assertTrue(e.getMessage().startsWith("Модель отказалась обрабатывать запрос (ограничение темы GigaChat)"));
        assertTrue(notices.get(notices.size() - 1).endsWith("ответ собран из 4 частей: принято 0, отклонено 4"), notices.toString());
    }

    @Test
    void singleTriggerInLongDocumentMarksOnlyItsFragment() {
        modelResponds(text -> text.contains(SENSITIVE) ? blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL) : stop(ANSWER));
        String context = longContext(6);

        String text = client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, context, false)),
                null, null);

        assertTrue(sentTexts.size() <= 7, "вызовов " + sentTexts.size());
        assertEquals(1, text.split("не обработана: модель отказалась", -1).length - 1, text);
        assertTrue(text.contains("документ 7.docx"), text);
        assertTrue(text.split("=== Часть ", -1).length - 1 >= 3, text);
    }

    @Test
    void severalTriggersAreLocalizedByDividingInBreadth() {
        modelResponds(text -> text.contains(SENSITIVE) ? blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL) : stop(ANSWER));
        String twoTriggers = contextWithTriggers(1, 5);

        String two = client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, twoTriggers, false)),
                null, null);
        int twoCalls = sentTexts.size();
        sentTexts.clear();
        String threeTriggers = contextWithTriggers(0, 3, 6);
        String three = client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, threeTriggers, false)),
                null, null);

        // в глубину (бюджет 8) было помечено 63 % и 87 % текста; в ширину — по документу на триггер
        assertEquals(11, twoCalls);
        assertEquals(13, sentTexts.size());
        assertTrue(markedShare(two, twoTriggers) <= 0.30, two);
        assertTrue(markedShare(three, threeTriggers) <= 0.40, three);
        assertEquals(2, two.split("не обработана: модель отказалась", -1).length - 1, two);
        assertEquals(3, three.split("не обработана: модель отказалась", -1).length - 1, three);
        assertTrue(three.contains("«<<<Документ: документ 7.docx>>>"), three);
    }

    @Test
    void refusalWithoutBoundaryOrWithShortContextFailsAtOnce() {
        modelResponds(text -> stop("Что-то в вашем вопросе меня смущает. Может, поговорим на другую тему?"));

        var noBoundary = assertThrows(GigaChatRefusedException.class, () -> client.chatCompletion(
                nodeMessage("Верни класс документа одним словом.\n\n" + SENSITIVE), null, null));
        assertEquals(1, sentTexts.size());
        var shortContext = assertThrows(GigaChatRefusedException.class, () -> client.chatCompletion(
                nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, "Документы:\n" + SENSITIVE, false)), null, null));

        assertEquals(2, sentTexts.size(), "деление невозможно — повтора нет");
        assertTrue(noBoundary.getMessage().contains("«Что-то в вашем вопросе меня смущает."), noBoundary.getMessage());
        assertTrue(shortContext.getMessage().startsWith("Модель отказалась обрабатывать запрос"));
        assertTrue(notices.isEmpty(), notices.toString());
    }

    @Test
    void refusalGoesThroughSameLimiterWithoutRetryPauses() {
        GigaChatConcurrencyLimiter limiter = Mockito.spy(new GigaChatConcurrencyLimiter(1, false, 50));
        client.setConcurrencyLimiter(limiter);
        modelResponds(text -> blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL));

        // паузы повторов выставлены в 60 с: отказ не временный сбой и не ждёт их
        assertTimeout(Duration.ofSeconds(10), () -> assertThrows(GigaChatRefusedException.class,
                () -> client.chatCompletion(nodeMessage(INSTRUCTION), null, null)));

        verify(chatModel, times(1)).call(any(Prompt.class));
        verify(limiter, times(1)).call(any(), notNull(), any());
    }

    @Test
    void contextTooLongSplitWithRefusedPartMarksIt() {
        AtomicInteger call = new AtomicInteger();
        modelResponds(text -> {
            if (call.incrementAndGet() == 1) {
                throw new RuntimeException(TOO_LONG);
            }
            return text.contains(SENSITIVE) ? blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL) : stop(ANSWER);
        });
        String context = twoDocuments();
        String rejected = context.substring(context.indexOf("<<<Документ: ТЗ приложение 3.docx>>>"));

        String text = client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION, context, false)),
                null, null);

        assertEquals("=== Часть 1/2 (запрос разделён из-за лимита контекста) ===\n" + ANSWER + "\n\n"
                + "=== Часть 2/2 (запрос разделён из-за лимита контекста) ===\n" + marker(2, 2, "\n\n" + context, rejected), text);
        // полный запрос (context too long), часть 1, часть 2 (отказ) — без повтора части
        assertEquals(3, sentTexts.size());
        assertEquals(2, notices.size(), notices.toString());
        assertTrue(notices.get(0).startsWith("3:⚠ фрагмент (знаки "), notices.get(0));
        assertTrue(notices.get(1).startsWith("3:запрос превышает контекст модели — разделён на 2 частей"), notices.get(1));
    }

    @Test
    void ordinaryAnswersInNodeAreNotTouched() {
        String longAnalysis = "Предмет закупки: " + GigaChatRefusalTest.NOTICE_LINE + ". Заказчик в протоколе: "
                + "«предпочту не отвечать на вопрос участника». " + (GigaChatRefusalTest.NOTICE_LINE + ". ").repeat(10);
        AtomicInteger call = new AtomicInteger();
        modelResponds(text -> stop(call.incrementAndGet() == 1 ? ANSWER : longAnalysis));

        assertEquals(ANSWER, client.chatCompletion(nodeMessage(GigaChatClient.splittableContent(INSTRUCTION,
                twoDocuments(), false)), null, null));
        assertEquals(longAnalysis, client.chatCompletion(nodeMessage("Проанализируй протокол."), null, null));

        assertEquals(2, sentTexts.size());
        assertTrue(notices.isEmpty(), notices.toString());
    }

    @Test
    void chatWithoutRunContextGetsRefusalAsIs() {
        // чат (ChatService) ставит получателя уведомлений, но не проверку остановки прогона
        GigaChatClient.clearRunCancelCheck();
        modelResponds(text -> blacklisted(GigaChatRefusalTest.PROBE_REFUSAL_APOLOGY));
        List<Map<String, String>> chat = List.of(
                Map.of("role", "system", "content", GigaChatClient.splittableContent("Ты — ассистент.", twoDocuments(), false)),
                Map.of("role", "user", "content", "Что проверяют при аудите пожарной безопасности?"));

        var result = client.chatCompletionResult(chat, null, null);
        var streamed = client.chatCompletionStreamResult(chat, null, null).blockFirst();

        assertEquals(GigaChatRefusalTest.PROBE_REFUSAL_APOLOGY, result.text());
        assertNotNull(streamed);
        assertEquals(GigaChatRefusalTest.PROBE_REFUSAL_APOLOGY, streamed.text());
        verify(chatModel, times(2)).call(any(Prompt.class));
        assertTrue(notices.isEmpty(), notices.toString());
    }

    @Test
    void continuationRefusedByCensorIsNotAppended() {
        AtomicInteger call = new AtomicInteger();
        modelResponds(text -> call.incrementAndGet() == 1
                ? GigaChatRefusalTest.response("[{\"строка\": 1},", "length")
                : blacklisted(GigaChatRefusalTest.INCIDENT_REFUSAL));

        String text = client.chatCompletion(nodeMessage(INSTRUCTION), null, null);

        assertEquals("[{\"строка\": 1},\n" + GigaChatClient.TRUNCATED_MARKER, text);
        assertEquals(2, sentTexts.size());
        assertEquals(List.of("2:⚠ дочитывание ответа отклонено цензором GigaChat — конец ответа отсутствует, поставлен маркер"),
                notices);
    }

    @Test
    void agentRefusalFailsNodeInRunAndIsReturnedAsIsOutsideRun() {
        modelResponds(text -> blacklisted(UNKNOWN_REFUSAL));

        var e = assertThrows(GigaChatRefusedException.class, () -> client.chatCompletionWithTools(nodeMessage(INSTRUCTION),
                List.of(), null, null));
        GigaChatClient.clearRunCancelCheck();
        var outside = client.chatCompletionWithTools(nodeMessage(INSTRUCTION), List.of(), null, null);

        assertTrue(e.getMessage().contains("«" + UNKNOWN_REFUSAL + "»"), e.getMessage());
        assertEquals(UNKNOWN_REFUSAL, outside.text());
    }

    @Test
    void fileRequestRefusalThrowsAndDeletesUpload() {
        GigaChatApi api = Mockito.mock(GigaChatApi.class);
        @SuppressWarnings("unchecked")
        ObjectProvider<GigaChatApi> provider = Mockito.mock(ObjectProvider.class);
        when(provider.getIfAvailable()).thenReturn(api);
        GigaChatClient fileClient = new GigaChatClient(chatModel, Mockito.mock(EmbeddingModel.class), provider);
        ReflectionTestUtils.setField(fileClient, "callHardTimeoutSeconds", 0L);
        ChatResponse refused = new ChatResponse(List.of(new Generation(new AssistantMessage(GigaChatRefusalTest.INCIDENT_REFUSAL),
                ChatGenerationMetadata.builder().finishReason("blacklist").build())),
                ChatResponseMetadata.builder().keyValue(GigaChatModel.UPLOADED_MEDIA_IDS, List.of("file-1")).build());
        when(chatModel.call(any(Prompt.class))).thenReturn(refused);

        assertThrows(GigaChatRefusedException.class, () -> fileClient.chatCompletionWithFile("Выпиши содержимое",
                "скан.pdf", new byte[]{1, 2, 3}, "application/pdf", null, null, null));

        verify(api).deleteFile("file-1");
        assertInstanceOf(GigaChatException.class, new GigaChatRefusedException(UNKNOWN_REFUSAL));
    }

    // -------------------------------------------------------------------------
    // helpers
    // -------------------------------------------------------------------------

    /** Модель: ответ по тексту последнего сообщения; тексты запросов запоминаются. */
    private void modelResponds(Function<String, ChatResponse> answer) {
        when(chatModel.call(any(Prompt.class))).thenAnswer(inv -> {
            Prompt prompt = inv.getArgument(0);
            var last = prompt.getInstructions().get(prompt.getInstructions().size() - 1);
            String text = ((UserMessage) last).getText();
            sentTexts.add(text);
            return answer.apply(text);
        });
    }

    private static ChatResponse stop(String text) {
        return GigaChatRefusalTest.response(text, "stop");
    }

    private static ChatResponse blacklisted(String text) {
        return GigaChatRefusalTest.response(text, "blacklist");
    }

    private static List<Map<String, String>> nodeMessage(String content) {
        return List.of(Map.of("role", "user", "content", content));
    }

    /** Маркер отклонённой части: знаки фрагмента в контексте сообщения (после границы). */
    private static String marker(int part, int total, String raw, String fragment) {
        int from = raw.indexOf(fragment) + 1;
        return GigaChatRefusal.partMarker(part, total, from, from + fragment.length() - 1, fragment);
    }

    private static String span(String raw, String fragment) {
        int from = raw.indexOf(fragment) + 1;
        return "(знаки " + from + "–" + (from + fragment.length() - 1) + " контекста)";
    }

    /** ТЗ из двух документов: общая часть (строки извещения) и приложение с чек-листом, на котором модель отказывает. */
    private static String twoDocuments() {
        String context = "Документы:\n" + document("ТЗ часть 1.docx", GigaChatRefusalTest.NOTICE_LINE, 8) + "\n\n"
                + document("ТЗ приложение 3.docx", SENSITIVE, 9);
        assertTrue(context.length() >= GigaChatClient.MIN_SPLIT_CONTEXT);
        return context;
    }

    /** Комплект из 8 документов ≈ 45 тыс. знаков; документ с номером trigger (с 0) содержит пункт-триггер. */
    private static String longContext(int trigger) {
        StringBuilder sb = new StringBuilder("Документы:");
        for (int i = 0; i < 8; i++) {
            String body = (GigaChatRefusalTest.NOTICE_LINE + "\n").repeat(29) + (i == trigger ? SENSITIVE : "");
            sb.append("\n\n").append(document("документ " + (i + 1) + ".docx", body, 1));
        }
        return sb.toString();
    }

    /** Комплект из 8 документов ≈ 45 тыс. знаков; документы с заданными номерами (с 0) содержат пункт-триггер. */
    private static String contextWithTriggers(int... triggers) {
        StringBuilder sb = new StringBuilder("Документы:");
        for (int i = 0; i < 8; i++) {
            boolean trigger = false;
            for (int t : triggers) {
                trigger |= t == i;
            }
            String body = (GigaChatRefusalTest.NOTICE_LINE + "\n").repeat(29) + (trigger ? SENSITIVE : "");
            sb.append("\n\n").append(document("документ " + (i + 1) + ".docx", body, 1));
        }
        return sb.toString();
    }

    /** Доля контекста, помеченная отклонённой: сумма знаков из маркеров частей. */
    private static double markedShare(String answer, String context) {
        Matcher m = Pattern.compile("\\[часть \\d+/\\d+ \\(знаки (\\d+)–(\\d+) контекста\\)").matcher(answer);
        long marked = 0;
        while (m.find()) {
            marked += Long.parseLong(m.group(2)) - Long.parseLong(m.group(1)) + 1;
        }
        return (double) marked / context.length();
    }

    private static String document(String name, String line, int lines) {
        return "<<<Документ: " + name + ">>>\n" + (line + "\n").repeat(lines) + "<<<КОНЕЦ ДОКУМЕНТА>>>";
    }
}
