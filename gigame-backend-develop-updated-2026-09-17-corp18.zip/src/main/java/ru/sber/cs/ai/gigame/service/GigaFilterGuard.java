package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.exception.GigaFilterBlockedException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Проверка текстов фильтром GigaFilter на входе и выходе запросов к чат-модели и решение о параметре
 * {@code profanity_check} (аналог {@code ProfanityChecker} агента коллег; требование ДКБ: цензор модели выключается
 * только тогда, когда вход прошёл GigaFilter).
 * <p>
 * Настройки {@code app.gigachat.profanity-check.*}: {@code input}/{@code output} (проверка входа/выхода, по умолчанию
 * включены), {@code agent} ({@code profanity_check} основной модели, по умолчанию false — активация отключения цензора
 * для ключа выполнена), модель и опции фильтра (neuro, blacklist, whitelist, unnormalized_history, safety). Откат без
 * пересборки: input=false, output=false, agent=true — {@link #active()} ложно, запросы идут как раньше.
 * <p>
 * Тексты проверяются фрагментами {@link GigaFilterChunker}; вердикты кэшируются ({@link GigaFilterCache}, ключ учитывает
 * опцию safety). Проход проверки одного запроса (все сообщения, контекст документов, результаты инструментов, ответ)
 * берёт ОДНО разрешение общего ограничителя GigaChat на все свои вызовы фильтра, и только если хотя бы одного вердикта
 * нет в кэше: разрешение на каждый фрагмент ставило бы проверку длинного документа в очередь за генерациями десятки раз.
 * Между вызовами проверяется остановка прогона. 429 и 5xx фильтра повторяются ({@code retry-attempts}, пауза по
 * Retry-After не дольше {@code retry-max-delay-millis}). Сбой фильтра (HTTP-ошибка, 404 модели, таймаут, непонятный
 * ответ) — «недоступен»: оставшиеся фрагменты прохода смотрятся только по кэшу (известная блокировка не теряется),
 * запрос к модели идёт с явным {@code profanity_check=true}, автомат {@link GigaFilterBreaker} после серии сбоев на время
 * перестаёт вызывать фильтр (429 — пауза без счёта сбоев). Прерывание и остановка прогона сбоем не считаются.
 * Блокировка — {@link GigaFilterBlockedException}; заблокированный фрагмент контекста документов (сообщение с границей
 * инструкция|контекст) и результат инструмента агента заменяются пометкой, если включено {@code skip-blocked-fragments}.
 */
@Component
@Slf4j
public class GigaFilterGuard {

    /** Роль сообщения проверки входа. */
    static final String ROLE_USER = "user";
    /** Предел цитаты начала заблокированного фрагмента в тексте ошибки, знаков. */
    static final int QUOTE_LIMIT = 60;
    /** Пометка вместо заблокированного результата инструмента агента. */
    static final String TOOL_BLOCKED_NOTE = "{\"error\": \"результат отклонён фильтром GigaFilter и не передан модели; "
            + "продолжай по остальным данным\"}";
    /** Пауза первого повтора вызова фильтра при 429/5xx без подсказки Retry-After, мс (дальше — кратно номеру повтора). */
    static final long RETRY_BASE_DELAY_MILLIS = 500L;
    private static final String PLACEMENT_SETTINGS = "settings";
    private static final String PLACEMENT_ROOT = "root";
    private static final String PLACEMENT_NONE = "none";
    private static final int UNPROCESSABLE = 422;
    /** Шаг ожидания паузы повтора с проверкой остановки прогона, мс. */
    private static final long SLEEP_STEP_MILLIS = 250L;
    /** Ответ 422 указывает именно на опцию safety либо на неизвестное поле тела запроса. */
    private static final Pattern SAFETY_REJECTED = Pattern.compile(
            "safety|unknown field|unrecognized field|extra (?:fields|inputs)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DOCUMENT_MARK = Pattern.compile("<<<Документ: ([^>\\n]{1,200})>>>");
    /**
     * Фильтр оказался недоступен при скрининге контекста запроса в этом потоке: следующая проверка входа того же
     * запроса смотрит вердикты только по кэшу (эмуляция на ключе стенда: 429 фильтра — два вызова подряд на один запрос).
     */
    private static final ThreadLocal<Boolean> SCREEN_UNAVAILABLE = new ThreadLocal<>();

    private final GigaFilterTransport transport;
    @Value("${app.gigachat.profanity-check.input:true}")
    private boolean input = true;
    @Value("${app.gigachat.profanity-check.output:true}")
    private boolean output = true;
    @Value("${app.gigachat.profanity-check.agent:false}")
    private boolean agent;
    @Value("${app.gigachat.profanity-check.model:GigaFilter}")
    private String model = "GigaFilter";
    @Value("${app.gigachat.profanity-check.options.neuro:true}")
    private boolean neuro = true;
    @Value("${app.gigachat.profanity-check.options.blacklist:true}")
    private boolean blacklist = true;
    @Value("${app.gigachat.profanity-check.options.whitelist:true}")
    private boolean whitelist = true;
    @Value("${app.gigachat.profanity-check.options.unnormalized-history:false}")
    private boolean unnormalizedHistory;
    @Value("${app.gigachat.profanity-check.options.safety:safe}")
    private String safety = "safe";
    @Value("${app.gigachat.profanity-check.safety-placement:settings}")
    private volatile String safetyPlacement = PLACEMENT_SETTINGS;
    @Value("${app.gigachat.profanity-check.output-role:user}")
    private String outputRole = ROLE_USER;
    @Value("${app.gigachat.profanity-check.chunk-chars:4000}")
    private int chunkChars = 4000;
    @Value("${app.gigachat.profanity-check.cache-size:5000}")
    private int cacheSize = 5000;
    @Value("${app.gigachat.profanity-check.breaker-failures:3}")
    private int breakerFailures = 3;
    @Value("${app.gigachat.profanity-check.breaker-open-seconds:300}")
    private long breakerOpenSeconds = 300;
    @Value("${app.gigachat.profanity-check.skip-blocked-fragments:true}")
    private boolean skipBlockedFragments = true;
    @Value("${app.gigachat.profanity-check.retry-attempts:2}")
    private int retryAttempts = 2;
    @Value("${app.gigachat.profanity-check.retry-max-delay-millis:3000}")
    private long retryMaxDelayMillis = 3000L;
    private volatile GigaFilterCache cache;
    private volatile GigaFilterBreaker breaker;

    /**
     * Проверка через транспорт фильтра.
     *
     * @param transport HTTP-вызов фильтра ({@code null} — фильтр недоступен)
     */
    @Autowired
    public GigaFilterGuard(GigaFilterTransport transport) {
        this.transport = transport;
    }

    /**
     * Вызов под общим ограничителем запросов к GigaChat (реализация — в {@code GigaChatClient}: без уведомлений об
     * очереди в журнал прогона, с проверкой остановки прогона).
     */
    @FunctionalInterface
    public interface Limited {

        /**
         * Выполняет вызов под разрешением ограничителя.
         *
         * @param call вызов
         * @param <T>  тип результата
         * @return результат вызова
         */
        <T> T call(Supplier<T> call);

        /**
         * Запрошена ли остановка прогона: проверка прекращается между вызовами фильтра.
         *
         * @return {@code true}, если прогон остановлен
         */
        default boolean cancelled() {
            return false;
        }
    }

    /**
     * Сообщения запроса после скрининга контекста и пометки для начала ответа.
     *
     * @param messages сообщения (заблокированные фрагменты контекста заменены маркером)
     * @param notes    пометки об удалённых фрагментах (пусто — ничего не удалено)
     */
    public record Screened(List<Map<String, String>> messages, List<String> notes) {

        /**
         * Текст ответа с пометками об удалённых фрагментах в начале.
         *
         * @param text ответ модели
         * @return пометки, пустая строка, ответ (без пометок — ответ как есть)
         */
        public String prefixed(String text) {
            return notes.isEmpty() ? text : String.join("\n", notes) + "\n\n" + text;
        }
    }

    /** Текст на проверку с подписью места (сообщение запроса, результат инструмента, ответ модели). */
    record LabeledText(String label, String text) {
    }

    /**
     * Заблокированный фрагмент текста.
     *
     * @param index номер фрагмента (с 0)
     * @param total число фрагментов текста
     * @param chunk заблокированный фрагмент
     */
    record TextVerdict(int index, int total, GigaFilterChunker.Chunk chunk) {
    }

    /** Диапазон заблокированного фрагмента контекста в тексте сообщения без служебных маркеров. */
    private record Range(int from, int to) {
    }

    /** Фрагмент на проверку: роль сообщения проверки и текст. */
    private record Piece(String role, String text) {
    }

    /** Исход вызова фильтра и место опции safety, с которым он получен (для ключа кэша). */
    private record FilterCall(GigaFilterCheck.Outcome outcome, String placement) {
    }

    /**
     * Проход проверки одного запроса или текста: вызовы фильтра под одним разрешением ограничителя; после первой
     * недоступности фильтра вердикты берутся только из кэша.
     */
    private static final class Pass {

        private final Limited limited;
        private boolean unavailable;

        Pass(Limited limited, boolean unavailable) {
            this.limited = limited;
            this.unavailable = unavailable;
        }
    }

    /**
     * Проверка выключена: вход и выход не проверяются, {@code profanity_check} не ставится — клиенты без Spring.
     *
     * @return выключенная проверка
     */
    static GigaFilterGuard disabled() {
        GigaFilterGuard guard = new GigaFilterGuard(null);
        guard.input = false;
        guard.output = false;
        guard.agent = true;
        return guard;
    }

    /**
     * Влияет ли проверка на запросы: проверка входа или выхода включена либо цензор основной модели выключается.
     *
     * @return {@code false} — прежнее поведение (input=false, output=false, agent=true)
     */
    public boolean active() {
        return input || output || !agent;
    }

    /**
     * Проверка входа запроса к чат-модели (все сообщения, включая аргументы вызовов инструментов в истории, фрагментами)
     * и значение {@code profanity_check}.
     *
     * @param instructions сообщения запроса
     * @param limited      вызов под ограничителем GigaChat
     * @return {@code FALSE} — цензор выключается (agent=false и вход прошёл фильтр либо проверка входа выключена);
     *         {@code TRUE} — цензор явно включён (вердикт хотя бы одного фрагмента неизвестен: фильтр недоступен; либо
     *         во входе непроверяемое вложение); {@code null} — поле не ставится (agent=true)
     * @throws GigaFilterBlockedException вход заблокирован фильтром (в том числе по вердикту из кэша)
     */
    public Boolean admit(List<Message> instructions, Limited limited) {
        Pass pass = new Pass(limited, Boolean.TRUE.equals(SCREEN_UNAVAILABLE.get()));
        SCREEN_UNAVAILABLE.remove();
        if (!input) {
            return agent ? null : Boolean.FALSE;
        }
        boolean known = checkTexts(texts(instructions), ROLE_USER, pass, true);
        if (agent) {
            return null;
        }
        return !known || hasMedia(instructions) ? Boolean.TRUE : Boolean.FALSE;
    }

    /**
     * Проверка ответа модели.
     *
     * @param answer  текст ответа ({@code null} или пусто — проверять нечего)
     * @param limited вызов под ограничителем GigaChat
     * @return {@code true} — ответ прошёл фильтр либо проверка не нужна; {@code false} — фильтр недоступен
     * @throws GigaFilterBlockedException ответ заблокирован фильтром
     */
    public boolean checkOutput(String answer, Limited limited) {
        return checkOutputTexts(List.of(new LabeledText("ответ модели", answer)), limited);
    }

    /**
     * Проверка ответа модели вместе с аргументами запрошенных вызовов инструментов: модель генерирует их тем же
     * запросом (с выключенным цензором), а инструмент исполняет их и пишет в журнал прогона и рабочие документы.
     *
     * @param answer  ответ модели ({@code null} — проверять нечего)
     * @param limited вызов под ограничителем GigaChat
     * @return {@code true} — ответ прошёл фильтр либо проверка не нужна; {@code false} — фильтр недоступен
     * @throws GigaFilterBlockedException текст ответа или аргументы вызова инструмента заблокированы фильтром
     */
    public boolean checkAnswer(AssistantMessage answer, Limited limited) {
        if (answer == null) {
            return true;
        }
        List<LabeledText> texts = new ArrayList<>();
        texts.add(new LabeledText("ответ модели", answer.getText()));
        addToolArguments(texts, answer, "");
        return checkOutputTexts(texts, limited);
    }

    /**
     * Скрининг контекста документов: в сообщении с границей инструкция|контекст ({@link GigaChatClient#SPLIT_BOUNDARY})
     * заблокированные фрагменты контекста заменяются маркером, в журнал прогона — уведомление, в ответ — пометка.
     * Деление на фрагменты то же, что при проверке входа, — вердикты берутся из кэша, лишних вызовов нет. Фильтр
     * недоступен на части фрагментов — уже найденные и известные по кэшу блокировки всё равно вырезаются.
     *
     * @param messages сообщения запроса
     * @param limited  вызов под ограничителем GigaChat
     * @param notice   получатель уведомлений журнала прогона
     * @return сообщения (изменённые, если фрагменты удалены) и пометки
     * @throws GigaFilterBlockedException заблокирована инструкция либо весь контекст (или удаление выключено настройкой —
     *                                    тогда блокировку сообщает проверка входа)
     */
    public Screened screenContext(List<Map<String, String>> messages, Limited limited, Consumer<String> notice) {
        SCREEN_UNAVAILABLE.remove();
        int idx = input && skipBlockedFragments ? GigaChatClient.boundaryMessage(messages) : -1;
        if (idx < 0) {
            return new Screened(messages, List.of());
        }
        String content = String.valueOf(messages.get(idx).get("content"));
        int boundary = content.indexOf(GigaChatClient.SPLIT_BOUNDARY);
        String stripped = GigaChatClient.stripSplitMarkers(content);
        List<Range> ranges = blockedContext(stripped, boundary, new Pass(limited, false));
        if (ranges.isEmpty()) {
            return new Screened(messages, List.of());
        }
        List<String> notes = new ArrayList<>();
        StringBuilder tail = new StringBuilder();
        int pos = boundary;
        for (Range range : ranges) {
            String where = contextPlace(stripped, boundary, range);
            notice.accept("⚠ " + where + " отклонён фильтром GigaFilter — не передан модели");
            notes.add("⚠ " + capitalize(where) + " не передан модели: отклонён фильтром GigaFilter.");
            tail.append(stripped, pos, range.from()).append('[').append(where).append(" удалён: отклонён фильтром GigaFilter]\n");
            pos = range.to();
        }
        log.warn("GigaFilter: из контекста запроса удалено заблокированных фрагментов: {}", ranges.size());
        tail.append(stripped.substring(pos));
        String hint = content.endsWith(GigaChatClient.MERGE_ARRAYS_HINT) ? GigaChatClient.MERGE_ARRAYS_HINT : "";
        String rebuilt = stripped.substring(0, boundary) + GigaChatClient.SPLIT_BOUNDARY + tail + hint;
        return new Screened(replaceContent(messages, idx, rebuilt), notes);
    }

    /**
     * Скрининг результатов инструментов агента: заблокированный результат заменяется пометкой
     * {@link #TOOL_BLOCKED_NOTE}, агент продолжает по остальным данным. Все результаты раунда — одним проходом.
     *
     * @param message результаты инструментов раунда
     * @param limited вызов под ограничителем GigaChat
     * @param notice  получатель уведомлений журнала прогона
     * @return результаты (изменённые, если есть заблокированные)
     */
    public ToolResponseMessage screenToolResults(ToolResponseMessage message, Limited limited, Consumer<String> notice) {
        if (!input || !skipBlockedFragments) {
            return message;
        }
        List<String> data = new ArrayList<>();
        for (ToolResponseMessage.ToolResponse response : message.getResponses()) {
            data.add(response.responseData());
        }
        List<List<GigaFilterChunker.Chunk>> chunked = chunked(data);
        Boolean[] verdicts = resolve(pieces(chunked, ROLE_USER), new Pass(limited, false), false);
        List<ToolResponseMessage.ToolResponse> responses = new ArrayList<>();
        boolean changed = false;
        int offset = 0;
        for (int i = 0; i < chunked.size(); i++) {
            ToolResponseMessage.ToolResponse response = message.getResponses().get(i);
            boolean blocked = firstBlocked(verdicts, offset, chunked.get(i).size()) >= 0;
            offset += chunked.get(i).size();
            if (blocked) {
                notice.accept("⚠ результат инструмента «" + response.name() + "» отклонён фильтром GigaFilter — "
                        + "агенту передана пометка");
            }
            responses.add(blocked ? new ToolResponseMessage.ToolResponse(response.id(), response.name(), TOOL_BLOCKED_NOTE) : response);
            changed |= blocked;
        }
        return changed ? ToolResponseMessage.builder().responses(responses).build() : message;
    }

    /**
     * Тело запроса к фильтру для одного фрагмента.
     *
     * @param text      текст фрагмента
     * @param role      роль сообщения
     * @param placement место опции safety: settings, root, none
     * @return запрос
     */
    GigaFilterCheck.Request request(String text, String role, String placement) {
        String where = normalizedPlacement(placement);
        String value = safety == null || safety.isBlank() ? null : safety.strip();
        return new GigaFilterCheck.Request(model, List.of(new GigaFilterCheck.Message(role, text)),
                new GigaFilterCheck.Settings(neuro, blacklist, whitelist, unnormalizedHistory,
                        PLACEMENT_SETTINGS.equals(where) ? value : null),
                PLACEMENT_ROOT.equals(where) ? value : null);
    }

    /**
     * Сообщения запроса на проверку: текст каждого сообщения, аргументы вызовов инструментов в истории и результаты
     * инструментов — по отдельности (GigaChatModel отправляет модели и то, и другое).
     *
     * @param messages сообщения запроса
     * @return тексты с подписями
     */
    static List<LabeledText> texts(List<Message> messages) {
        List<LabeledText> texts = new ArrayList<>();
        for (Message message : messages) {
            if (message instanceof ToolResponseMessage tool) {
                for (ToolResponseMessage.ToolResponse response : tool.getResponses()) {
                    texts.add(new LabeledText("результат инструмента «" + response.name() + "»", response.responseData()));
                }
            } else {
                texts.add(new LabeledText(label(message), message.getText()));
            }
            if (message instanceof AssistantMessage assistant) {
                addToolArguments(texts, assistant, " в истории");
            }
        }
        return texts;
    }

    /**
     * Есть ли во входе вложения (файлы): до вызова модели их id нет — фильтром не проверяются.
     *
     * @param messages сообщения запроса
     * @return {@code true}, если у сообщения пользователя есть вложения
     */
    static boolean hasMedia(List<Message> messages) {
        for (Message message : messages) {
            if (message instanceof UserMessage user && user.getMedia() != null && !user.getMedia().isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Имя документа по маркеру «&lt;&lt;&lt;Документ: имя&gt;&gt;&gt;», последнему до позиции.
     *
     * @param text текст сообщения
     * @param end  позиция (конец фрагмента)
     * @return имя документа или {@code null}
     */
    static String documentName(String text, int end) {
        Matcher matcher = DOCUMENT_MARK.matcher(text);
        String name = null;
        while (matcher.find() && matcher.start() < end) {
            name = matcher.group(1).strip();
        }
        return name;
    }

    /** Аргументы вызовов инструментов сообщения модели с подписями. */
    private static void addToolArguments(List<LabeledText> texts, AssistantMessage message, String suffix) {
        if (!message.hasToolCalls()) {
            return;
        }
        for (AssistantMessage.ToolCall call : message.getToolCalls()) {
            texts.add(new LabeledText("аргументы инструмента «" + call.name() + "»" + suffix, call.arguments()));
        }
    }

    /** Проверка текстов ответа модели одним проходом. */
    private boolean checkOutputTexts(List<LabeledText> texts, Limited limited) {
        if (!output) {
            return true;
        }
        return checkTexts(texts, outputRole, new Pass(limited, false), false);
    }

    /**
     * Проверка текстов одним проходом: заблокированный фрагмент (в том числе известный по кэшу после недоступности
     * фильтра) — исключение с местом.
     *
     * @return {@code true} — вердикты всех фрагментов известны (чисто); {@code false} — часть вердиктов неизвестна
     */
    private boolean checkTexts(List<LabeledText> texts, String role, Pass pass, boolean inputSide) {
        List<String> raw = new ArrayList<>();
        for (LabeledText text : texts) {
            raw.add(text.text());
        }
        List<List<GigaFilterChunker.Chunk>> chunked = chunked(raw);
        Boolean[] verdicts = resolve(pieces(chunked, role), pass, true);
        int offset = 0;
        for (int t = 0; t < chunked.size(); t++) {
            List<GigaFilterChunker.Chunk> chunks = chunked.get(t);
            int blocked = firstBlocked(verdicts, offset, chunks.size());
            if (blocked >= 0) {
                TextVerdict verdict = new TextVerdict(blocked, chunks.size(), chunks.get(blocked));
                throw new GigaFilterBlockedException(inputSide, location(texts.get(t), verdict, inputSide));
            }
            offset += chunks.size();
        }
        for (Boolean verdict : verdicts) {
            if (verdict == null) {
                return false;
            }
        }
        return true;
    }

    /**
     * Заблокированные фрагменты контекста (после boundary) в тексте сообщения без маркеров. Фрагмент целиком в
     * инструкции — ошибка; фрагмент на стыке — проверяется часть инструкции отдельно. Вердикт части фрагментов
     * неизвестен (фильтр недоступен) — найденные блокировки всё равно возвращаются, а проверка входа того же запроса
     * смотрит только кэш (цензор останется включённым).
     */
    private List<Range> blockedContext(String stripped, int boundary, Pass pass) {
        List<GigaFilterChunker.Chunk> chunks = GigaFilterChunker.chunks(stripped, chunkChars);
        Boolean[] verdicts = resolve(pieces(List.of(chunks), ROLE_USER), pass, false);
        List<Range> ranges = new ArrayList<>();
        int contextChunks = 0;
        int blockedChunks = 0;
        boolean unknown = false;
        for (int i = 0; i < chunks.size(); i++) {
            GigaFilterChunker.Chunk chunk = chunks.get(i);
            boolean context = chunk.end() > boundary && !stripped.substring(Math.max(boundary, chunk.start()), chunk.end()).isBlank();
            contextChunks += context ? 1 : 0;
            if (verdicts[i] == null) {
                unknown = true;
            } else if (verdicts[i] && !instructionPartAllowed(stripped, boundary, chunk, pass)) {
                throw new GigaFilterBlockedException(true, location(new LabeledText("инструкция узла", stripped),
                        new TextVerdict(i, chunks.size(), chunk), true));
            } else if (verdicts[i]) {
                blockedChunks++;
                addRange(ranges, Math.max(boundary, chunk.start()), chunk.end());
            }
        }
        if (blockedChunks > 0 && blockedChunks >= contextChunks) {
            throw new GigaFilterBlockedException(true, "контекст документов целиком: отклонены все фрагменты ("
                    + blockedChunks + ")");
        }
        if (unknown) {
            SCREEN_UNAVAILABLE.set(Boolean.TRUE);
        }
        return ranges;
    }

    /**
     * Инструкция в заблокированном фрагменте допустима: фрагмент целиком в контексте, либо на стыке и часть
     * инструкции отдельно фильтр пропускает (вердикт неизвестен — считается допустимой, решит проверка входа).
     */
    private boolean instructionPartAllowed(String stripped, int boundary, GigaFilterChunker.Chunk chunk, Pass pass) {
        if (chunk.start() >= boundary) {
            return true;
        }
        if (chunk.end() <= boundary || stripped.substring(boundary, chunk.end()).isBlank()) {
            return false;
        }
        String instructionPart = stripped.substring(chunk.start(), boundary);
        return instructionPart.isBlank()
                || !Boolean.TRUE.equals(resolve(List.of(new Piece(ROLE_USER, instructionPart)), pass, true)[0]);
    }

    /**
     * Вердикты фрагментов по порядку: сначала кэш; если вердиктов не хватает и фильтр можно вызывать — вызовы под
     * одним разрешением ограничителя на весь проход.
     *
     * @param pieces        фрагменты
     * @param pass          проход проверки
     * @param stopOnBlocked не вызывать фильтр дальше первого заблокированного фрагмента
     * @return вердикты: {@code TRUE} — заблокирован, {@code FALSE} — пропущен, {@code null} — неизвестен
     */
    private Boolean[] resolve(List<Piece> pieces, Pass pass, boolean stopOnBlocked) {
        Boolean[] verdicts = new Boolean[pieces.size()];
        boolean missing = fromCache(pieces, verdicts);
        if (!missing || pass.unavailable || (stopOnBlocked && firstBlocked(verdicts, 0, verdicts.length) >= 0)) {
            return verdicts;
        }
        if (transport == null) {
            breaker().failure(null, "транспорт фильтра не настроен");
        }
        if (transport == null || !breaker().allowsCall()) {
            pass.unavailable = true;
            return verdicts;
        }
        pass.limited.call(() -> callMissing(pieces, verdicts, pass, stopOnBlocked));
        return verdicts;
    }

    /** Вердикты из кэша (пустой фрагмент — пропущен без вызова). */
    private boolean fromCache(List<Piece> pieces, Boolean[] verdicts) {
        String placement = safetyPlacement;
        boolean missing = false;
        for (int i = 0; i < pieces.size(); i++) {
            Piece piece = pieces.get(i);
            verdicts[i] = piece.text() == null || piece.text().isBlank() ? Boolean.FALSE : cache().get(cacheKey(piece, placement));
            missing |= verdicts[i] == null;
        }
        return missing;
    }

    /** Вызовы фильтра по фрагментам без вердикта, под уже взятым разрешением; остановка прогона — между вызовами. */
    private Void callMissing(List<Piece> pieces, Boolean[] verdicts, Pass pass, boolean stopOnBlocked) {
        for (int i = 0; i < pieces.size() && !pass.unavailable; i++) {
            if (verdicts[i] != null) {
                continue;
            }
            checkCancelled(pass);
            verdicts[i] = callChunk(pieces.get(i), pass);
            if (stopOnBlocked && Boolean.TRUE.equals(verdicts[i])) {
                break;
            }
        }
        return null;
    }

    /** Вызов фильтра для фрагмента: вердикт — в кэш; сбой — проход «недоступен», автомат (429 — пауза без счёта). */
    private Boolean callChunk(Piece piece, Pass pass) {
        if (!breaker().allowsCall()) {
            pass.unavailable = true;
            return null;
        }
        FilterCall call = callFilter(piece, pass);
        GigaFilterCheck.Outcome outcome = call.outcome();
        if (outcome.definitive()) {
            breaker().success();
            cache().put(cacheKey(piece, call.placement()), outcome.profane());
            return outcome.profane();
        }
        pass.unavailable = true;
        if (outcome.rateLimited()) {
            breaker().pause(outcome.retryAfterMillis(), outcome.failure());
        } else {
            breaker().failure(outcome.status(), outcome.failure());
        }
        return null;
    }

    /**
     * Вызов фильтра с повторами 429/5xx. Ответ 422, указывающий на опцию safety, — один вызов без неё: опция
     * отключается до перезапуска, только если фильтр без неё ответил вердиктом; иначе исход — сбой, настройка не меняется.
     */
    private FilterCall callFilter(Piece piece, Pass pass) {
        String placement = safetyPlacement;
        GigaFilterCheck.Outcome outcome = checkRetrying(piece, placement, pass);
        if (!safetyRejected(outcome, placement)) {
            return new FilterCall(outcome, placement);
        }
        GigaFilterCheck.Outcome without = checkRetrying(piece, PLACEMENT_NONE, pass);
        if (!without.definitive()) {
            return new FilterCall(outcome, placement);
        }
        safetyPlacement = PLACEMENT_NONE;
        log.warn("GigaFilter: ВНИМАНИЕ — фильтр отклонил опцию safety={} ({}): {}; без опции фильтр отвечает вердиктом, "
                + "до перезапуска приложения safety не отправляется — проверьте GIGACHAT_PROFANITY_CHECK_SAFETY_PLACEMENT "
                + "и GIGACHAT_PROFANITY_CHECK_SAFETY", safety, placement, outcome.failure());
        return new FilterCall(without, PLACEMENT_NONE);
    }

    /** Вызов фильтра; 429 и 5xx — до {@code retry-attempts} повторов с паузой (разрешение ограничителя не отпускается). */
    private GigaFilterCheck.Outcome checkRetrying(Piece piece, String placement, Pass pass) {
        GigaFilterCheck.Request request = request(piece.text(), piece.role(), placement);
        GigaFilterCheck.Outcome outcome = transport.check(request);
        for (int attempt = 1; attempt <= retryAttempts && outcome.retryable(); attempt++) {
            pauseBeforeRetry(outcome, attempt, pass);
            outcome = transport.check(request);
        }
        return outcome;
    }

    /** Пауза повтора: Retry-After либо {@link #RETRY_BASE_DELAY_MILLIS} × номер, не дольше retry-max-delay-millis. */
    private void pauseBeforeRetry(GigaFilterCheck.Outcome outcome, int attempt, Pass pass) {
        long hint = outcome.retryAfterMillis() > 0 ? outcome.retryAfterMillis() : RETRY_BASE_DELAY_MILLIS * attempt;
        long end = System.currentTimeMillis() + Math.min(hint, Math.max(0L, retryMaxDelayMillis));
        while (System.currentTimeMillis() < end) {
            checkCancelled(pass);
            try {
                Thread.sleep(Math.min(SLEEP_STEP_MILLIS, Math.max(1L, end - System.currentTimeMillis())));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new GigaChatException(GigaFilterTransport.INTERRUPTED, e);
            }
        }
    }

    /** Остановка прогона — проверка прекращается (не сбой фильтра). */
    private static void checkCancelled(Pass pass) {
        if (pass.limited.cancelled()) {
            throw new GigaChatException(GigaChatClient.CANCELLED);
        }
    }

    /** Ответ 422 на запрос с опцией safety, указывающий на неё (или на неизвестное поле). */
    private boolean safetyRejected(GigaFilterCheck.Outcome outcome, String placement) {
        return Integer.valueOf(UNPROCESSABLE).equals(outcome.status()) && safetySent(placement)
                && SAFETY_REJECTED.matcher(String.valueOf(outcome.failure())).find();
    }

    private boolean safetySent(String placement) {
        return safety != null && !safety.isBlank() && !PLACEMENT_NONE.equals(normalizedPlacement(placement));
    }

    /** Ключ кэша: роль, фактическая опция safety запроса и текст фрагмента. */
    private String cacheKey(Piece piece, String placement) {
        String options = safetySent(placement) ? normalizedPlacement(placement) + "=" + safety.strip() : PLACEMENT_NONE;
        return GigaFilterCache.key(piece.role() + "\n" + options, piece.text());
    }

    private static String normalizedPlacement(String placement) {
        return placement == null ? PLACEMENT_SETTINGS : placement.strip().toLowerCase(Locale.ROOT);
    }

    /** Фрагменты текстов по порядку. */
    private List<List<GigaFilterChunker.Chunk>> chunked(List<String> texts) {
        List<List<GigaFilterChunker.Chunk>> chunked = new ArrayList<>();
        for (String text : texts) {
            chunked.add(GigaFilterChunker.chunks(text, chunkChars));
        }
        return chunked;
    }

    /** Фрагменты всех текстов подряд как элементы проверки. */
    private static List<Piece> pieces(List<List<GigaFilterChunker.Chunk>> chunked, String role) {
        List<Piece> pieces = new ArrayList<>();
        for (List<GigaFilterChunker.Chunk> chunks : chunked) {
            for (GigaFilterChunker.Chunk chunk : chunks) {
                pieces.add(new Piece(role, chunk.text()));
            }
        }
        return pieces;
    }

    /** Номер первого заблокированного фрагмента в окне [offset, offset + count) относительно offset либо -1. */
    private static int firstBlocked(Boolean[] verdicts, int offset, int count) {
        for (int i = 0; i < count; i++) {
            if (Boolean.TRUE.equals(verdicts[offset + i])) {
                return i;
            }
        }
        return -1;
    }

    /** Добавляет диапазон, сливая со смежным предыдущим. */
    private static void addRange(List<Range> ranges, int from, int to) {
        Range last = ranges.isEmpty() ? null : ranges.get(ranges.size() - 1);
        if (last != null && last.to() == from) {
            ranges.set(ranges.size() - 1, new Range(last.from(), to));
        } else {
            ranges.add(new Range(from, to));
        }
    }

    /** Подпись места фрагмента контекста: документ и знаки контекста. */
    private static String contextPlace(String stripped, int boundary, Range range) {
        String document = documentName(stripped, range.to());
        String span = "(знаки " + (range.from() - boundary + 1) + "–" + (range.to() - boundary) + " контекста)";
        return document == null ? "фрагмент контекста " + span : "фрагмент документа «" + document + "» " + span;
    }

    /** Место блокировки для текста ошибки: сообщение, фрагмент k из N, знаки, документ, начало фрагмента. */
    private static String location(LabeledText part, TextVerdict verdict, boolean quote) {
        GigaFilterChunker.Chunk chunk = verdict.chunk();
        StringBuilder sb = new StringBuilder(part.label());
        if (verdict.total() > 1) {
            sb.append(", фрагмент ").append(verdict.index() + 1).append(" из ").append(verdict.total());
        }
        sb.append(", знаки ").append(chunk.start() + 1).append('–').append(chunk.end());
        String document = documentName(part.text(), chunk.end());
        if (document != null) {
            sb.append(", документ «").append(document).append('»');
        }
        if (quote) {
            sb.append(": «").append(GigaFilterTransport.shorten(chunk.text(), QUOTE_LIMIT)).append('»');
        }
        return sb.toString();
    }

    /** Подпись сообщения запроса. */
    private static String label(Message message) {
        if (message instanceof SystemMessage) {
            return "системное сообщение";
        }
        return message instanceof AssistantMessage ? "ответ модели в истории" : "сообщение запроса";
    }

    private static String capitalize(String text) {
        return text.isEmpty() ? text : Character.toUpperCase(text.charAt(0)) + text.substring(1);
    }

    /** Копия сообщений с заменённым текстом сообщения idx. */
    private static List<Map<String, String>> replaceContent(List<Map<String, String>> messages, int idx, String content) {
        List<Map<String, String>> copy = new ArrayList<>(messages);
        copy.set(idx, Map.of("role", messages.get(idx).getOrDefault("role", "user"), "content", content));
        return copy;
    }

    private GigaFilterCache cache() {
        GigaFilterCache current = cache;
        if (current == null) {
            synchronized (this) {
                if (cache == null) {
                    cache = new GigaFilterCache(cacheSize);
                }
                current = cache;
            }
        }
        return current;
    }

    private GigaFilterBreaker breaker() {
        GigaFilterBreaker current = breaker;
        if (current == null) {
            synchronized (this) {
                if (breaker == null) {
                    breaker = new GigaFilterBreaker(breakerFailures, breakerOpenSeconds * 1000L, System::currentTimeMillis);
                }
                current = breaker;
            }
        }
        return current;
    }
}
