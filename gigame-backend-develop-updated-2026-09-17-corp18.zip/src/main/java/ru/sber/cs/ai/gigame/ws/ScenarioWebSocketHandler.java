package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioEventType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;

/**
 * WebSocket обработчик для сценариев.
 * <p>
 * Реализует WebFlux WebSocket Handler для управления выполнением сценариев
 * с потоковой передачей событий в реальном времени через WebSocket.
 * <p>
 * Принимает команды от клиентов для управления выполнением сценариев.
 * Обрабатывает команды: run (по умолчанию), resume и ping (игнорируется — только продлевает
 * таймаут простоя). Команды одной сессии обрабатываются последовательно ({@code flatMap} с
 * параллельностью 1): N команд run подряд не ставят N прогонов в очередь одновременно, а порядок
 * событий в сокете сохраняется.
 * <p>
 * Таймаут простоя {@code app.ws.idle-timeout-minutes} (env {@code WS_IDLE_TIMEOUT_MINUTES}): без входящих
 * кадров дольше N минут сессия закрывается. По умолчанию 0 — выключено: во время долгого прогона клиент
 * ничего не шлёт, а обрыв сокета прогон не останавливает; при включении клиент шлёт {@code {"type":"ping"}}
 * чаще таймаута (ping-кадры протокола Netty отвечает сам, до обработчика они не доходят).
 * <p>
 * Формат входящих сообщений:
 * {
 * "type": "run|resume|ping",         // необязательно, по умолчанию run
 * "scenario_id": "uuid",             // для run
 * "step_mode": true|false,           // для run, необязательно
 * "run_id": "uuid"                   // для resume — id упавшего прогона
 * }
 * <p>
 * Файлы для прогона загружаются заранее REST-запросом
 * POST /api/scenarios/{id}/upload — WS-команда run использует кэш загрузки.
 * <p>
 * Формат исходящих сообщений:
 * {
 * "type": "event_type",
 * "data": { ... }
 * }
 *
 * @see WebSocketSessionManager
 * @see ScenarioEngine
 */
@Component
@RequiredArgsConstructor
@Slf4j
@SuppressWarnings("unused")
public class ScenarioWebSocketHandler implements WebSocketHandler {

    /** Команда, которую сервер игнорирует: клиент шлёт её, чтобы продлить таймаут простоя. */
    static final String PING = "ping";

    private final ScenarioService scenarioService;
    private final ScenarioEngine scenarioEngine;
    private final WebSocketSessionManager sessionManager;
    private final ObjectMapper objectMapper;
    private final ScenarioUploadTaskService scenarioUploadTaskService;
    /** Таймаут простоя сессии в минутах; 0 — выключен. */
    @Value("${app.ws.idle-timeout-minutes:0}")
    private int idleTimeoutMinutes;

    @Override
    @NonNull
    public Mono<Void> handle(@NonNull WebSocketSession session) {
        try {
            return doHandle(session);
        } finally {
            CurrentUserHolder.clear();
        }
    }

    private Mono<Void> doHandle(WebSocketSession session) {
        var userId = WebSocketSessionManager.extractUserIdFromWebSocketSession(session);
        log.info("[{}] connected, sessionId={}", userId, session.getId());
        sessionManager.addSession(session);

        return Mono.defer(() ->
                withIdleTimeout(session.receive(), session, userId)
                        .doOnNext(msg -> log.info("[{}] Received WebSocket message, payload: {}", userId, msg.getPayloadAsText()))
                        // команды сессии — по одной: N команд run не ставят N прогонов в очередь разом
                        .flatMap(message -> handleIncomingMessage(session, message, userId), 1)
                        .then()
                        .doOnTerminate(() -> {
                            sessionManager.removeSession(session);
                            log.info("[{}] WebSocket scenario run connection closed: sessionId={}", userId, session.getId());
                        })).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Входящие кадры с таймаутом простоя {@code app.ws.idle-timeout-minutes}: без кадров дольше
     * таймаута поток завершается (сессия закрывается), а не падает ошибкой.
     *
     * @param incoming входящие кадры сессии
     * @param session  сессия (для лога)
     * @param userId   пользователь сессии
     * @return входящие кадры с таймаутом либо как есть при выключенном таймауте
     */
    private Flux<WebSocketMessage> withIdleTimeout(Flux<WebSocketMessage> incoming, WebSocketSession session, String userId) {
        if (idleTimeoutMinutes <= 0) {
            return incoming;
        }
        return incoming.timeout(Duration.ofMinutes(idleTimeoutMinutes))
                .onErrorResume(TimeoutException.class, e -> {
                    log.warn("[{}] WebSocket-сессия закрыта по таймауту простоя {} мин: sessionId={}",
                            userId, idleTimeoutMinutes, session.getId());
                    return Flux.empty();
                });
    }

    private Mono<Void> handleIncomingMessage(WebSocketSession session,
                                             WebSocketMessage message,
                                             String userId) {
        String payload = message.getPayloadAsText();
        log.info("[{}] Received scenario run message: sessionId={}, payload={}", userId, session.getId(), payload);

        try {
            ScenarioMessage scenarioMessage = objectMapper.readValue(
                    payload,
                    ScenarioMessage.class
            );

            return processScenarioMessage(scenarioMessage, session.getId(), userId)
                    .then(Mono.empty());
        } catch (ScenarioException e) {
            log.error("Scenario launch rejected: sessionId={}, reason={}", session.getId(), e.getMessage());
            return sendLaunchRejected(session, e.getMessage());
        } catch (Exception e) {
            log.error("Error handling message: sessionId={}", session.getId(), e);
            return sendErrorMessage(session, "Ошибка обработки сообщения: " + e.getMessage());
        }
    }

    private Mono<Void> processScenarioMessage(ScenarioMessage message, String sessionId, String userId) {
        String type = message.type() == null || message.type().isBlank() ? "run" : message.type();
        log.info("[{}] Processing scenario message: sessionId={}, type={}, scenarioId={}, runId={}, stepMode={}",
                userId, sessionId, type, message.scenarioId(), message.runId(), message.stepMode());
        if (PING.equals(type)) {
            return Mono.empty();
        }
        CurrentUserHolder.setCurrentUser(userId);
        WebSocketSession wsSession = sessionManager.getSession(sessionId);
        if (wsSession == null || !wsSession.isOpen()) {
            log.warn("[{}] WebSocket session not found or closed: sessionId={}", userId, sessionId);
            return Mono.empty();
        }
        Mono<Flux<ServerSentEvent<Map<String, Object>>>> command;
        if ("resume".equals(type)) {
            UUID runId = UUID.fromString(message.runId());
            command = callOffEventLoop(userId, () -> scenarioService.resumeScenarioRun(runId));
        } else {
            UUID scenarioId = UUID.fromString(message.scenarioId());
            if (scenarioUploadTaskService.isProcessing(scenarioId, userId)) {
                // асинхронная загрузка этого пользователя ещё разбирает документы — кэш прогона не полон
                return sendErrorMessage(wsSession, "Документы сценария ещё обрабатываются "
                        + "(асинхронная загрузка) — дождитесь завершения по GET upload-status "
                        + "и запустите прогон снова");
            }
            command = callOffEventLoop(userId, () -> scenarioService.runScenario(
                    scenarioId,
                    message.stepMode()));
        }
        return command
                .onErrorResume(e -> commandError(wsSession, e))
                .flatMap(stream -> sendStream(wsSession, stream, userId, sessionId));
    }

    /**
     * Выполняет команду прогона (run/resume) на {@link Schedulers#boundedElastic()}:
     * сервис ходит в БД через JPA и не должен блокировать поток Netty, принимающий
     * сообщения всех WebSocket-сессий. Пользователь из X-UserId handshake
     * выставляется в {@link CurrentUserHolder} потока вызова и очищается после него.
     *
     * @param userId пользователь сессии
     * @param call   вызов сервиса, возвращающий поток событий прогона
     * @return поток событий прогона, полученный вне event loop
     */
    private static Mono<Flux<ServerSentEvent<Map<String, Object>>>> callOffEventLoop(
            String userId,
            Supplier<Flux<ServerSentEvent<Map<String, Object>>>> call) {
        return Mono.fromCallable(() -> CurrentUserHolder.withUser(userId, call))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Ошибка приёма команды (доступ, сценарий не найден, прогон нельзя возобновить):
     * клиенту уходит сообщение об ошибке — как при синхронной ошибке обработки сообщения.
     *
     * @param session WebSocket-сессия
     * @param error   ошибка вызова сервиса
     * @return пустой результат после отправки сообщения об ошибке
     */
    private Mono<Flux<ServerSentEvent<Map<String, Object>>>> commandError(WebSocketSession session, Throwable error) {
        if (error instanceof ScenarioException) {
            // отказ в запуске (проверка графа, статус возобновляемого прогона): клиент выходит из фазы выполнения
            log.error("Scenario launch rejected: sessionId={}, reason={}", session.getId(), error.getMessage());
            return sendLaunchRejected(session, error.getMessage()).then(Mono.empty());
        }
        log.error("Error handling message: sessionId={}", session.getId(), error);
        return sendErrorMessage(session, "Ошибка обработки сообщения: " + error.getMessage()).then(Mono.empty());
    }

    /**
     * Отправляет события прогона клиенту в формате StreamEvent.
     *
     * @param wsSession WebSocket-сессия
     * @param stream    поток событий прогона
     * @param userId    пользователь сессии
     * @param sessionId идентификатор сессии
     * @return завершение отправки
     */
    private Mono<Void> sendStream(WebSocketSession wsSession,
                                  Flux<ServerSentEvent<Map<String, Object>>> stream,
                                  String userId,
                                  String sessionId) {
        return Flux.from(stream
                        // map выполняется в потоке прогона, вызвавшем sink.next: withUser стёр бы там пользователя
                        .map(serverSentEvent -> createStreamEvent(serverSentEvent.data()))
                        .doOnNext(event -> log.info("[{}] Sending to client: {}",userId, event))
                        .doOnComplete(() -> log.info("[{}] Scenario stream completed for sessionId={}", userId, sessionId)))
                .map(wsSession::textMessage)
                .delayElements(Duration.ofMillis(10))
                .as(wsSession::send)
                .then();
    }

    /**
     * Преобразует данные SSE в формат StreamEvent.
     *
     * @param data данные SSE
     * @return Map в формате StreamEvent
     */
    private String createStreamEvent(Map<String, Object> data) {
        Map<String, Object> event = new HashMap<>();
        if (data != null) {
            Object type = data.get("type");
            if (type != null) {
                event.put("type", type);
            }
            Map<String, Object> dataCopy = new HashMap<>(data);
            dataCopy.remove("type");
            event.put("data", dataCopy);
        }
        try {
            return objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            log.error("Error serializing StreamEvent", e);
            return "{}";
        }
    }

    private Mono<Void> sendErrorMessage(WebSocketSession session, String errorMessage) {
        if (session != null && session.isOpen()) {
            try {
                Map<String, Object> errorEvent = Map.of(
                        "session_id", session.getId(),
                        "error", errorMessage
                );
                String json = objectMapper.writeValueAsString(errorEvent);
                return session.send(Flux.just(json).map(session::textMessage));
            } catch (Exception e) {
                log.error("Error serializing error message", e);
                return Mono.error(e);
            }
        }
        return Mono.empty();
    }

    /**
     * Отказ в запуске или возобновлении прогона (проверка сценария до создания прогона).
     * <p>
     * Один кадр несёт и прежнее поле {@code error} (его ждёт клиент возобновления), и потоковое событие
     * STATUS FAILED с причиной в {@code data.error} — по нему клиент запуска выходит из фазы выполнения.
     *
     * @param session WebSocket-сессия
     * @param reason  причина отказа
     * @return отправка кадра
     */
    private Mono<Void> sendLaunchRejected(WebSocketSession session, String reason) {
        if (session == null || !session.isOpen()) {
            return Mono.empty();
        }
        LaunchRejectedMessage rejected = new LaunchRejectedMessage(session.getId(),
                "Ошибка обработки сообщения: " + reason, ScenarioEventType.STATUS.name(),
                new LaunchRejectedStatus(ScenarioStatus.FAILED.name(), reason));
        try {
            String json = objectMapper.writeValueAsString(rejected);
            return session.send(Flux.just(json).map(session::textMessage));
        } catch (JsonProcessingException e) {
            log.error("Error serializing launch rejection", e);
            return Mono.error(e);
        }
    }

    /**
     * Кадр отказа в запуске прогона.
     *
     * @param sessionId идентификатор WebSocket-сессии
     * @param error     «Ошибка обработки сообщения: причина» (прежний формат кадра ошибки)
     * @param type      тип потокового события — STATUS
     * @param data      статус FAILED и причина отказа
     */
    public record LaunchRejectedMessage(
            @JsonProperty("session_id")
            String sessionId,
            @JsonProperty("error")
            String error,
            @JsonProperty("type")
            String type,
            @JsonProperty("data")
            LaunchRejectedStatus data
    ) {
    }

    /**
     * Данные события STATUS отказа в запуске.
     *
     * @param status статус прогона — FAILED
     * @param error  причина отказа
     */
    public record LaunchRejectedStatus(
            @JsonProperty("status")
            String status,
            @JsonProperty("error")
            String error
    ) {
    }

    /**
     * Входное сообщение для управления прогоном сценария.
     *
     * @param type       команда: run (по умолчанию) или resume
     * @param scenarioId идентификатор сценария (для run)
     * @param stepMode   флаг пошагового режима (для run, необязательно)
     * @param runId      идентификатор упавшего прогона (для resume)
     */
    public record ScenarioMessage(
            @JsonProperty("type")
            String type,
            @JsonProperty("scenario_id")
            String scenarioId,
            @JsonProperty("step_mode")
            Boolean stepMode,
            @JsonProperty("run_id")
            String runId
    ) {
    }
}
