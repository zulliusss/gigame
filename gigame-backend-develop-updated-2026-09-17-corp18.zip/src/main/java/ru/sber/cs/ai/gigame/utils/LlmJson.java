package ru.sber.cs.ai.gigame.utils;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.core.io.JsonEOFException;
import com.fasterxml.jackson.core.json.JsonReadFeature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Predicate;

/**
 * Единый разбор JSON из ответов модели (и выходов узлов) — вместо расходящихся
 * эвристик узлов.
 * <p>
 * Кандидаты в порядке приоритета: содержимое блоков {@code ```json … ```} (и {@code ``` … ```}),
 * весь текст целиком, затем сбалансированные блоки {@code {…}} / {@code […]} — по индексу
 * скобок одним линейным проходом ({@link JsonCalcUtils.BracketIndex}); сначала скобки вне
 * строковых литералов, при неудаче — внутри них (как прежний посимвольный перебор).
 * Каждый кандидат разбирается строго, затем терпимо (комментарии, висячие запятые,
 * одинарные кавычки), затем с починкой недопустимых экранирований «\X» ({@link #repairEscapes}:
 * обратная косая черта из цитаты документа сохраняется дословно), затем ещё и с узкой починкой
 * десятичной запятой ({@link JsonCalcUtils#sanitizeDecimalCommas}). Принимаются только объекты и массивы.
 * <p>
 * Политики выбора ({@link Policy}) сохраняют прежнее поведение узлов: первый массив
 * объектов, последний массив объектов, все массивы, самый большой блок, только весь документ.
 */
@Slf4j
public final class LlmJson {

    /** Политика выбора блоков. */
    public enum Policy {
        /** Первый разбираемый объект или массив. */
        FIRST,
        /** Первый непустой массив объектов; если таких нет — первый пустой массив. */
        FIRST_OBJECT_ARRAY,
        /** Последний массив, содержащий объекты (или пустой), — перебор с конца. */
        LAST_OBJECT_ARRAY,
        /** Все непересекающиеся массивы объектов (и пустые) по порядку. */
        ALL_ARRAYS,
        /** Все непересекающиеся объекты по порядку. */
        ALL_OBJECTS,
        /** Самый длинный разбираемый блок. */
        LARGEST,
        /** Только весь текст целиком (либо содержимое единственного блока {@code ```json}). */
        WHOLE_DOCUMENT_ONLY
    }

    /** Любой объект или массив. */
    public static final Predicate<JsonNode> ANY = JsonNode::isContainerNode;

    /** JSON-объект. */
    public static final Predicate<JsonNode> OBJECT = JsonNode::isObject;

    /** Любой массив. */
    public static final Predicate<JsonNode> ARRAY = JsonNode::isArray;

    /** Непустой массив, первый элемент которого — объект. */
    public static final Predicate<JsonNode> OBJECT_ARRAY = n -> n.isArray() && !n.isEmpty() && n.get(0).isObject();

    /** Пустой массив. */
    public static final Predicate<JsonNode> EMPTY_ARRAY = n -> n.isArray() && n.isEmpty();

    /** Массив, среди элементов которого есть объект. */
    public static final Predicate<JsonNode> ARRAY_WITH_OBJECTS = n -> n.isArray() && hasObject(n);

    /** Массив без элементов либо только из объектов. */
    public static final Predicate<JsonNode> ARRAY_OF_OBJECTS_OR_EMPTY = n -> n.isArray() && (n.isEmpty() || allObjects(n));

    /** Массив, среди элементов которого есть объект, либо пустой массив — условие политики {@link Policy#ALL_ARRAYS}. */
    public static final Predicate<JsonNode> ARRAY_WITH_OBJECTS_OR_EMPTY = n -> ARRAY_WITH_OBJECTS.test(n) || EMPTY_ARRAY.test(n);

    private static final String FENCE = "```";

    /** Символы после «\», допустимые при терпимом разборе (кроме «u», которому нужны четыре hex-цифры). */
    private static final String VALID_ESCAPES = "\"\\/bfnrt'";

    private static final String HEX_DIGITS = "0123456789abcdefABCDEF";

    /** Сколько символов входа показывать по обе стороны от позиции ошибки разбора. */
    private static final int FRAGMENT_RADIUS = 40;

    /** Сколько оборванных объектов одного текста пробовать починить (неразбираемый, но не оборванный объект — не в счёт починки). */
    private static final int MAX_REPAIR_ATTEMPTS = 3;

    /** Начало маркеров обрыва ответа модели («[… ответ модели усечён …]», «[… ответ модели зациклился …]»). */
    private static final String CUT_MARK = "[…";

    /** Начало маркеров обрезки значений и документов («[... обрезано ...]», «[... документ обрезан ...]»). */
    private static final String CUT_MARK_ASCII = "[...";

    private static final ObjectMapper STRICT = JsonMapper.builder()
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .build();

    private static final ObjectMapper TOLERANT = JsonMapper.builder()
            .enable(DeserializationFeature.FAIL_ON_TRAILING_TOKENS)
            .enable(JsonReadFeature.ALLOW_JAVA_COMMENTS)
            .enable(JsonReadFeature.ALLOW_YAML_COMMENTS)
            .enable(JsonReadFeature.ALLOW_TRAILING_COMMA)
            .enable(JsonReadFeature.ALLOW_SINGLE_QUOTES)
            .build();

    private LlmJson() {
    }

    /**
     * Разобранный блок.
     *
     * @param node   дерево JSON
     * @param start  начало блока в тексте
     * @param end    конец блока в тексте (исключительно)
     * @param source исходный текст блока
     * @param strict блок разобран строгим парсером (исходный текст — корректный JSON)
     * @param repair пометка о починке незакрытого объекта (что восстановлено и что отброшено) либо {@code null}
     */
    public record Parsed(JsonNode node, int start, int end, String source, boolean strict, String repair) {

        /**
         * Блок без починки незакрытого объекта.
         *
         * @param node   дерево JSON
         * @param start  начало блока в тексте
         * @param end    конец блока в тексте (исключительно)
         * @param source исходный текст блока
         * @param strict блок разобран строгим парсером
         */
        public Parsed(JsonNode node, int start, int end, String source, boolean strict) {
            this(node, start, end, source, strict, null);
        }

        /**
         * Блок восстановлен из незакрытого объекта ({@link #all}): пометка для предупреждения узла.
         *
         * @return {@code true}, если объект был обрезан до последней полной пары и закрыт
         */
        public boolean repaired() {
            return repair != null;
        }

        private Parsed shifted(int offset) {
            return offset == 0 ? this : new Parsed(node, start + offset, end + offset, source, strict, repair);
        }

        /**
         * Текст блока, пригодный для повторного разбора: исходный, если он корректен,
         * иначе сериализованное дерево.
         *
         * @return JSON
         */
        public String json() {
            return strict ? source : node.toString();
        }

        /**
         * Значение блока как {@link java.util.Map} / {@link java.util.List} (изменяемые).
         *
         * @return значение
         */
        public Object value() {
            return toValue(node);
        }
    }

    /**
     * Результат выбора.
     *
     * @param blocks    блоки в порядке политики
     * @param lastError ошибка последнего неразобранного кандидата (null — кандидатов не было или все разобраны)
     */
    public record Selection(List<Parsed> blocks, String lastError) {

        /**
         * Первый блок либо null.
         *
         * @return блок
         */
        public Parsed first() {
            return blocks.isEmpty() ? null : blocks.get(0);
        }

        /**
         * Ни один блок не выбран.
         *
         * @return {@code true}, если блоков нет
         */
        public boolean isEmpty() {
            return blocks.isEmpty();
        }
    }

    /**
     * Выбор блоков по политике.
     *
     * @param text   текст
     * @param policy политика
     * @return результат
     */
    public static Selection select(String text, Policy policy) {
        return switch (policy) {
            case FIRST -> first(text, ANY);
            case FIRST_OBJECT_ARRAY -> firstObjectArray(text);
            case LAST_OBJECT_ARRAY -> last(text, n -> ARRAY_WITH_OBJECTS.test(n) || EMPTY_ARRAY.test(n));
            case ALL_ARRAYS -> all(text, ARRAY_WITH_OBJECTS_OR_EMPTY);
            case ALL_OBJECTS -> all(text, OBJECT);
            case LARGEST -> largest(text, ANY);
            case WHOLE_DOCUMENT_ONLY -> whole(text, ANY);
        };
    }

    /**
     * Первый (по приоритету кандидатов) блок, отвечающий условию.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection first(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        for (List<int[]> group : scan.groupsForward()) {
            for (int[] range : group) {
                Parsed parsed = scan.parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    return new Selection(List.of(parsed), scan.lastError);
                }
            }
        }
        return new Selection(List.of(), scan.lastError);
    }

    /**
     * Последний блок, отвечающий условию: блоки перебираются с конца текста.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection last(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        for (List<int[]> group : scan.groupsBackward()) {
            for (int[] range : group) {
                Parsed parsed = scan.parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    return new Selection(List.of(parsed), scan.lastError);
                }
            }
        }
        return new Selection(List.of(), scan.lastError);
    }

    /**
     * Все непересекающиеся блоки по порядку: принятый блок пропускается целиком
     * (вложенные в него не рассматриваются), непринятый — разбирается изнутри.
     * <p>
     * Незакрытый JSON-объект верхнего уровня (ответ модели оборван по лимиту длины или зациклился) обрезается до
     * последней полной пары «ключ: значение» и закрывается ({@link Parsed#repair()} — пометка); текст до него и после
     * места обрыва разбирается как обычно. Субботин, s4 (16.09.2026): «объем» зациклился до лимита — объект условий
     * договора не закрыт, и «сверить_цену_и_сроки» не находила ни договор, ни протокол после него.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат
     */
    public static Selection all(String text, Predicate<JsonNode> accept) {
        String rest = text == null ? "" : text;
        List<Parsed> found = new ArrayList<>();
        String lastError = null;
        int offset = 0;
        Parsed cut;
        do {
            Scan scan = new Scan(rest);
            cut = scan.truncatedObject(accept);
            Selection head = (cut == null ? scan : new Scan(rest.substring(0, cut.start()))).allBalanced(accept);
            lastError = head.lastError() == null ? lastError : head.lastError();
            for (Parsed block : head.blocks()) {
                found.add(block.shifted(offset));
            }
            if (cut != null) {
                found.add(cut.shifted(offset));
                offset += cut.end();
                rest = rest.substring(cut.end());
            }
        } while (cut != null);
        return new Selection(found.isEmpty() ? List.of() : found, lastError);
    }

    /**
     * Все непересекающиеся блоки по порядку, отвечающие условию, — только по скобкам вне строковых литералов: без
     * запасного перебора скобок внутри литералов, к которому {@link #all} переходит, если вне литералов не принят ни один
     * блок, и без починки оборванного объекта. Для разбора частей текста по отдельности (блоки вкладов родителей во
     * входе узла): переходить ли к запасному перебору, вызывающий код решает по всему тексту.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат
     */
    public static Selection allOutsideLiterals(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        List<Parsed> found = scan.accepted(scan.outsideRanges(), accept);
        return new Selection(found.isEmpty() ? List.of() : found, scan.lastError);
    }

    /**
     * Самый длинный разбираемый блок, отвечающий условию (при равенстве — первый).
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection largest(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        Parsed best = null;
        for (List<int[]> group : scan.groupsForward()) {
            for (int[] range : group) {
                if (best != null && range[1] - range[0] <= best.end() - best.start()) {
                    continue;
                }
                Parsed parsed = scan.parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    best = parsed;
                }
            }
        }
        return new Selection(best == null ? List.of() : List.of(best), scan.lastError);
    }

    /**
     * Только документ целиком: содержимое единственного блока {@code ```json} либо весь текст.
     *
     * @param text   текст
     * @param accept условие на дерево
     * @return результат (не более одного блока)
     */
    public static Selection whole(String text, Predicate<JsonNode> accept) {
        Scan scan = new Scan(text);
        List<int[]> fenced = scan.fencedRanges();
        int[] range = fenced.size() == 1 ? fenced.get(0) : scan.wholeRange();
        Parsed parsed = range == null ? null : scan.parse(range);
        boolean ok = parsed != null && accept.test(parsed.node());
        return new Selection(ok ? List.of(parsed) : List.of(), scan.lastError);
    }

    /**
     * Первый непустой массив объектов; если таких нет — первый пустой массив
     * (пустой «[]» другого узла перед массивом объектов не должен «съедать» строки).
     *
     * @param text текст
     * @return результат (не более одного блока)
     */
    public static Selection firstObjectArray(String text) {
        Selection objects = first(text, OBJECT_ARRAY);
        if (!objects.isEmpty()) {
            return objects;
        }
        Selection empty = first(text, EMPTY_ARRAY);
        return new Selection(empty.blocks(), objects.lastError() == null ? empty.lastError() : objects.lastError());
    }

    /**
     * Почему во входе не разобран ни один массив: ошибка терпимого разбора (после починки
     * экранирований) самого длинного блока «[…]», который не разбирается и не лежит внутри
     * разобранного блока, — с позицией во входе и фрагментом текста вокруг неё. Если первая «[»
     * не открывает сбалансированного блока (сбиты кавычки), проверяется охват до последней «]».
     *
     * @param text текст
     * @return описание ошибки либо null, если блоков «[…]» нет или все они разбираются
     */
    public static String arrayParseError(String text) {
        Scan scan = new Scan(text);
        TreeMap<Integer, Integer> parsed = new TreeMap<>();
        for (int[] range : scan.arrayRangesLongestFirst()) {
            Map.Entry<Integer, Integer> outer = parsed.floorEntry(range[0]);
            if (outer != null && outer.getValue() >= range[1]) {
                continue;
            }
            if (scan.parse(range) == null) {
                return scan.describeError(range);
            }
            parsed.put(range[0], range[1]);
        }
        return null;
    }

    /**
     * Починка недопустимых экранирований: «\X», где X не из набора JSON ({@code " \ / b f n r t},
     * {@code u} с четырьмя шестнадцатеричными цифрами) и не {@code '} терпимого разбора, становится «\\X».
     * После разбора обратная косая черта остаётся в значении дословно: «Java\С#», «C:\Users», «\d+».
     * Допустимые последовательности не меняются.
     *
     * @param source текст блока
     * @return текст с починенными экранированиями (тот же объект, если «\» в тексте нет)
     */
    static String repairEscapes(String source) {
        if (source.indexOf('\\') < 0) {
            return source;
        }
        StringBuilder sb = new StringBuilder(source.length() + 16);
        int i = 0;
        while (i < source.length()) {
            char c = source.charAt(i);
            if (c != '\\') {
                sb.append(c);
                i++;
            } else if (isValidEscape(source, i)) {
                sb.append(c).append(source.charAt(i + 1));
                i += 2;
            } else {
                sb.append("\\\\");
                i++;
            }
        }
        return sb.toString();
    }

    private static boolean isValidEscape(String source, int at) {
        if (at + 1 >= source.length()) {
            return false;
        }
        char next = source.charAt(at + 1);
        if (next != 'u') {
            return VALID_ESCAPES.indexOf(next) >= 0;
        }
        if (at + 6 > source.length()) {
            return false;
        }
        for (int k = at + 2; k < at + 6; k++) {
            if (HEX_DIGITS.indexOf(source.charAt(k)) < 0) {
                return false;
            }
        }
        return true;
    }

    /**
     * Позиция в исходном блоке по позиции в починенном: {@link #repairEscapes} только вставляет «\».
     *
     * @param source        исходный блок
     * @param escaped       починенный блок
     * @param escapedOffset позиция в починенном блоке
     * @return позиция в исходном блоке
     */
    private static int sourceOffset(String source, String escaped, int escapedOffset) {
        int target = Math.min(escapedOffset, escaped.length());
        int i = 0;
        for (int j = 0; j < target && i < source.length(); j++) {
            if (source.charAt(i) == escaped.charAt(j)) {
                i++;
            }
        }
        return i;
    }

    /**
     * Дерево как значение: {@link java.util.LinkedHashMap} / {@link java.util.ArrayList}
     * (изменяемые), числа — Integer/Long/Double/BigInteger.
     *
     * @param node дерево
     * @return значение
     */
    public static Object toValue(JsonNode node) {
        return STRICT.convertValue(node, Object.class);
    }

    private static boolean hasObject(JsonNode array) {
        for (JsonNode item : array) {
            if (item.isObject()) {
                return true;
            }
        }
        return false;
    }

    private static boolean allObjects(JsonNode array) {
        for (JsonNode item : array) {
            if (!item.isObject()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Незакрытый JSON-объект: потоковый терпимый разбор до места обрыва, обрезка до последней полной пары
     * «ключ: значение» верхнего уровня и закрытие «}». Пара полная, если значение — закрытая строка или закрытый
     * вложенный блок либо число, true, false, null, за которыми уже стоит запятая: «"сумма": 98672» на обрыве могло
     * быть началом «986724.24». Место обрыва — конец текста либо ошибка разбора перед маркером обрыва «[…» / «[...»
     * (перевод строки внутри незакрытой строки перед «[… ответ модели усечён …]»); текст после места обрыва
     * разбирается как обычно.
     */
    private static final class Truncation {

        private int depth;
        private int pairs;
        private long lastEnd = -1;
        private long scalarEnd = -1;
        private long errorAt;
        private String field;
        private String lastField;

        /**
         * Починка объекта, открытого скобкой без пары: разбор как есть и с починкой десятичной запятой, берётся
         * вариант с большим числом полных пар.
         *
         * @param text текст
         * @param open позиция «{» без пары
         * @return объект (конец блока — место обрыва) либо {@code null}: объект закрыт или полных пар нет
         */
        static Parsed repair(String text, int open) {
            String source = text.substring(open);
            String escaped = repairEscapes(source);
            String decimal = JsonCalcUtils.sanitizeDecimalCommas(escaped);
            Truncation plain = streamed(escaped);
            Truncation fixed = streamed(decimal);
            boolean useDecimal = fixed != null && (plain == null || fixed.lastEnd > plain.lastEnd);
            Truncation best = useDecimal ? fixed : plain;
            if (best == null || best.pairs == 0) {
                return null;
            }
            JsonNode node = readObject((useDecimal ? decimal : escaped).substring(0, (int) best.lastEnd) + "}");
            if (node == null) {
                return null;
            }
            int end = open + sourceOffset(source, escaped, (int) Math.max(best.errorAt, best.lastEnd));
            return new Parsed(node, open, end, text.substring(open, end), false, best.note());
        }

        private static Truncation streamed(String work) {
            Truncation truncation = new Truncation();
            return truncation.stream(work) ? truncation : null;
        }

        private static JsonNode readObject(String json) {
            try {
                JsonNode node = TOLERANT.readTree(json);
                return node != null && node.isObject() ? node : null;
            } catch (JsonProcessingException e) {
                return null;
            }
        }

        /**
         * Разбор до обрыва. Обрыв — конец текста внутри объекта либо ошибка разбора, за которой (через пробелы и
         * переводы строк) идёт маркер обрыва «[…» / «[...»; иная ошибка — просто неверный JSON, не обрыв.
         *
         * @param work текст от «{»
         * @return {@code true} — объект оборван, {@code false} — закрыт или неверен
         */
        private boolean stream(String work) {
            try (JsonParser parser = TOLERANT.createParser(work)) {
                depth = parser.nextToken() == JsonToken.START_OBJECT ? 1 : 0;
                while (depth > 0) {
                    JsonToken token = parser.nextToken();
                    if (token == null) {
                        errorAt = work.length();
                        return true;
                    }
                    onToken(parser, token);
                }
                return false;
            } catch (IOException e) {
                JsonLocation location = e instanceof JsonProcessingException p ? p.getLocation() : null;
                boolean eof = e instanceof JsonEOFException || location == null;
                errorAt = eof ? work.length() : Math.max(0, location.getCharOffset());
                return eof || markerAt(work, (int) errorAt);
            }
        }

        private static boolean markerAt(String work, int at) {
            int i = Math.min(at, work.length());
            while (i < work.length() && Character.isWhitespace(work.charAt(i))) {
                i++;
            }
            return work.startsWith(CUT_MARK, i) || work.startsWith(CUT_MARK_ASCII, i);
        }

        private void onToken(JsonParser parser, JsonToken token) throws IOException {
            if (token.isStructStart()) {
                depth++;
            } else if (token.isStructEnd()) {
                depth--;
                if (depth == 1) {
                    complete(parser);
                }
            } else if (depth == 1 && token == JsonToken.FIELD_NAME) {
                nextField(parser.currentName());
            } else if (depth == 1 && token == JsonToken.VALUE_STRING) {
                // строка читается до закрывающей кавычки: обрыв внутри неё — ошибка разбора здесь
                parser.getText();
                complete(parser);
            } else if (depth == 1) {
                scalarEnd = parser.currentLocation().getCharOffset();
            }
        }

        /** Имя следующего поля: запятая прочитана — скаляр перед ней полный. */
        private void nextField(String name) {
            if (scalarEnd >= 0) {
                lastEnd = scalarEnd;
                lastField = field;
                pairs++;
                scalarEnd = -1;
            }
            field = name;
        }

        private void complete(JsonParser parser) {
            lastEnd = parser.currentLocation().getCharOffset();
            lastField = field;
            field = null;
            pairs++;
            scalarEnd = -1;
        }

        private String note() {
            return "JSON-объект не закрыт (ответ модели оборван) — обрезан до последней полной пары «" + lastField + "» и закрыт"
                    + (field == null ? "" : "; отброшены поле «" + field + "» и всё после него");
        }
    }

    /** Кандидаты одного текста и их разбор. */
    private static final class Scan {

        private final String text;
        private final JsonCalcUtils.BracketIndex index;
        private String lastError;

        Scan(String text) {
            this.text = text == null ? "" : text;
            this.index = JsonCalcUtils.indexOf(this.text);
        }

        /** Группы кандидатов по приоритету: блоки ```, весь текст, скобки вне литералов, скобки внутри. */
        List<List<int[]>> groupsForward() {
            List<List<int[]>> groups = new ArrayList<>();
            groups.add(fencedRanges());
            int[] whole = wholeRange();
            groups.add(whole == null ? List.of() : List.of(whole));
            groups.addAll(balancedGroups());
            return groups;
        }

        /** То же с конца: блоки ``` и сбалансированные блоки в обратном порядке (весь текст — крайний блок). */
        List<List<int[]>> groupsBackward() {
            List<List<int[]>> groups = new ArrayList<>();
            groups.add(reversed(fencedRanges()));
            for (List<int[]> group : balancedGroups()) {
                groups.add(reversed(group));
            }
            return groups;
        }

        /** Непересекающиеся сбалансированные блоки первой группы скобок, где условие приняло хоть один блок. */
        Selection allBalanced(Predicate<JsonNode> accept) {
            for (List<int[]> group : balancedGroups()) {
                List<Parsed> found = accepted(group, accept);
                if (!found.isEmpty()) {
                    return new Selection(found, lastError);
                }
            }
            return new Selection(List.of(), lastError);
        }

        /** Непересекающиеся блоки группы, принятые условием: принятый блок пропускается целиком, непринятый — разбирается изнутри. */
        List<Parsed> accepted(List<int[]> group, Predicate<JsonNode> accept) {
            List<Parsed> found = new ArrayList<>();
            int consumedTo = 0;
            for (int[] range : group) {
                if (range[0] < consumedTo) {
                    continue;
                }
                Parsed parsed = parse(range);
                if (parsed != null && accept.test(parsed.node())) {
                    found.add(parsed);
                    consumedTo = range[1];
                }
            }
            return found;
        }

        /**
         * Первый оборванный объект верхнего уровня, который после починки ({@link Truncation#repair}) принимается
         * условием. Кандидат — «{» с ключом в кавычках вне литералов и вне разобранного блока: без пары либо, если в
         * тексте есть маркер обрыва «[…» / «[...», с парой, но неразбираемый (незакрытая кавычка оборванной строки
         * сбивает чётность кавычек, и скобка «находит пару» в следующем блоке — вход c3 Субботина). Объект внутри
         * незакрытого массива не чинится (строки оборванного массива разбираются как раньше); починка пробуется
         * не больше {@link #MAX_REPAIR_ATTEMPTS} раз.
         *
         * @param accept условие на дерево
         * @return восстановленный объект либо {@code null}
         */
        Parsed truncatedObject(Predicate<JsonNode> accept) {
            boolean marked = text.contains(CUT_MARK) || text.contains(CUT_MARK_ASCII);
            int skipTo = 0;
            int attempts = 0;
            for (int open : index.opensOutsideLiterals()) {
                int close = index.matchOf(open);
                if (text.charAt(open) == '[') {
                    if (close < 0) {
                        return null;
                    }
                    continue;
                }
                if (open < skipTo || !keyFollows(open)) {
                    continue;
                }
                if (close > open && closedObject(marked, open, close)) {
                    skipTo = close + 1;
                    continue;
                }
                attempts++;
                if (attempts > MAX_REPAIR_ATTEMPTS) {
                    return null;
                }
                Parsed repaired = Truncation.repair(text, open);
                if (repaired != null && accept.test(repaired.node())) {
                    log.warn("[{}] LlmJson: {}", CurrentUserHolder.getCurrentUser(), repaired.repair());
                    return repaired;
                }
            }
            return null;
        }

        /** Объект с парной скобкой закрыт: без маркера обрыва — по скобкам, с маркером — ещё и разбирается. */
        private boolean closedObject(boolean marked, int open, int close) {
            return !marked || parse(new int[]{open, close + 1}) != null;
        }

        /** После «{» (и пробелов) идёт ключ в кавычках — похоже на JSON-объект, а не на скобку в прозе. */
        private boolean keyFollows(int open) {
            int at = open + 1;
            while (at < text.length() && Character.isWhitespace(text.charAt(at))) {
                at++;
            }
            return at < text.length() && (text.charAt(at) == '"' || text.charAt(at) == '\'');
        }

        /** Сбалансированные блоки: сначала по скобкам вне строковых литералов, затем внутри них. */
        List<List<int[]>> balancedGroups() {
            List<int[]> first = outsideRanges();
            List<int[]> second = ranges(index.opensInsideLiterals());
            List<List<int[]>> groups = new ArrayList<>();
            groups.add(first);
            groups.add(second);
            return groups;
        }

        /** Сбалансированные блоки по скобкам вне строковых литералов (первая группа {@link #balancedGroups}). */
        List<int[]> outsideRanges() {
            return ranges(index.opensOutsideLiterals());
        }

        List<int[]> fencedRanges() {
            List<int[]> ranges = new ArrayList<>();
            int at = text.indexOf(FENCE);
            while (at >= 0) {
                int start = at + FENCE.length();
                while (start < text.length() && Character.isLetter(text.charAt(start))) {
                    start++;
                }
                int close = text.indexOf(FENCE, start);
                int end = close < 0 ? text.length() : close;
                int[] trimmed = trimmed(start, end);
                if (trimmed != null) {
                    ranges.add(trimmed);
                }
                at = close < 0 ? -1 : text.indexOf(FENCE, close + FENCE.length());
            }
            return ranges;
        }

        int[] wholeRange() {
            return trimmed(0, text.length());
        }

        private int[] trimmed(int from, int to) {
            int start = from;
            int end = to;
            while (start < end && Character.isWhitespace(text.charAt(start))) {
                start++;
            }
            while (end > start && Character.isWhitespace(text.charAt(end - 1))) {
                end--;
            }
            return start < end ? new int[]{start, end} : null;
        }

        private List<int[]> ranges(List<Integer> opens) {
            List<int[]> ranges = new ArrayList<>();
            for (int open : opens) {
                int close = index.matchOf(open);
                if (close > open) {
                    ranges.add(new int[]{open, close + 1});
                }
            }
            return ranges;
        }

        private static List<int[]> reversed(List<int[]> ranges) {
            List<int[]> copy = new ArrayList<>(ranges);
            Collections.reverse(copy);
            return copy;
        }

        /** Разбор кандидата: строго, терпимо, с починкой экранирований и десятичной запятой; null — не разобран. */
        Parsed parse(int[] range) {
            String source = text.substring(range[0], range[1]);
            char c = source.charAt(0);
            if (c != '{' && c != '[') {
                return null;
            }
            JsonNode node = read(STRICT, source);
            if (node != null) {
                return new Parsed(node, range[0], range[1], source, true);
            }
            node = tolerant(source);
            return node == null ? null : new Parsed(node, range[0], range[1], source, false);
        }

        /** Терпимый разбор: как есть, после починки экранирований «\X», затем ещё и десятичной запятой. */
        private JsonNode tolerant(String source) {
            JsonNode node = read(TOLERANT, source);
            if (node != null) {
                return node;
            }
            String escaped = repairEscapes(source);
            if (!escaped.equals(source)) {
                node = read(TOLERANT, escaped);
            }
            return node != null ? node : read(TOLERANT, JsonCalcUtils.sanitizeDecimalCommas(escaped));
        }

        /**
         * Блоки «[…]» (по скобкам вне и внутри литералов) от самого длинного к самому короткому; если первая «[»
         * не открывает сбалансированный блок — ещё и охват от неё до последней «]» ({@code unbalancedSpan}).
         */
        List<int[]> arrayRangesLongestFirst() {
            List<int[]> arrays = new ArrayList<>();
            for (List<int[]> group : balancedGroups()) {
                for (int[] range : group) {
                    if (text.charAt(range[0]) == '[') {
                        arrays.add(range);
                    }
                }
            }
            int[] span = unbalancedSpan(arrays);
            if (span != null) {
                arrays.add(span);
            }
            arrays.sort(Comparator.comparingInt(range -> range[0] - range[1]));
            return arrays;
        }

        /**
         * Охват от первой «[» до последней «]», когда первая «[» не открывает ни одного сбалансированного блока:
         * «\» в конце значения («Раздел 5\"») экранирует закрывающую кавычку, чётность кавычек сбивается,
         * и по скобкам массив уже не находится.
         */
        private int[] unbalancedSpan(List<int[]> arrays) {
            int open = text.indexOf('[');
            int close = text.lastIndexOf(']');
            if (open < 0 || close <= open || arrays.stream().anyMatch(range -> range[0] == open)) {
                return null;
            }
            return new int[]{open, close + 1};
        }

        /** Ошибка терпимого разбора блока (после починки экранирований): текст парсера, позиция во входе и фрагмент. */
        String describeError(int[] range) {
            String source = text.substring(range[0], range[1]);
            String escaped = repairEscapes(source);
            try {
                TOLERANT.readTree(escaped);
                return null;
            } catch (JsonProcessingException e) {
                int position = range[0] + sourceOffset(source, escaped, charOffset(e));
                return e.getOriginalMessage() + " (позиция " + position + "): «" + fragment(position) + "»";
            }
        }

        private static int charOffset(JsonProcessingException e) {
            JsonLocation location = e.getLocation();
            return location == null ? 0 : (int) Math.max(0, location.getCharOffset());
        }

        private String fragment(int position) {
            int from = Math.max(0, position - FRAGMENT_RADIUS);
            int to = Math.min(text.length(), position + FRAGMENT_RADIUS);
            return text.substring(from, to).replaceAll("\\s+", " ");
        }

        private JsonNode read(ObjectMapper mapper, String source) {
            try {
                JsonNode node = mapper.readTree(source);
                return node != null && node.isContainerNode() ? node : null;
            } catch (Exception e) {
                lastError = e.getMessage();
                return null;
            }
        }
    }
}
