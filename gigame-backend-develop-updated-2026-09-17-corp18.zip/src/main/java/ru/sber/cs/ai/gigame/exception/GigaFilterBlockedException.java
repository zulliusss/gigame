package ru.sber.cs.ai.gigame.exception;

/**
 * Текст отклонён фильтром GigaFilter: на входе — запрос к модели не отправлен, на выходе — ответ модели не
 * использован. Узел сценария завершается ошибкой (FAILED, текст с меткой узла), чат получает событие ошибки с этим
 * текстом; «тихого успеха» нет. Код ответа REST — как у прочих ошибок GigaChat (503).
 */
public class GigaFilterBlockedException extends GigaChatException {

    private final boolean input;

    /**
     * Исключение блокировки с указанием стороны и места.
     *
     * @param input    {@code true} — вход (промпт, документы), {@code false} — выход (ответ модели)
     * @param location место: сообщение, фрагмент, знаки, документ и начало фрагмента
     */
    public GigaFilterBlockedException(boolean input, String location) {
        super(message(input, location));
        this.input = input;
    }

    /**
     * Сторона блокировки.
     *
     * @return {@code true} — вход, {@code false} — выход
     */
    public boolean isInput() {
        return input;
    }

    /**
     * Текст ошибки блокировки.
     *
     * @param input    вход ({@code true}) либо выход
     * @param location место блокировки
     * @return «Текст отклонён фильтром GigaFilter на входе (…) — запрос к модели не отправлен; …» либо
     *         «Текст отклонён фильтром GigaFilter на выходе (…) — ответ модели не использован; …»
     */
    public static String message(boolean input, String location) {
        return input
                ? "Текст отклонён фильтром GigaFilter на входе (" + location + ") — запрос к модели не отправлен; "
                        + "исключите или переформулируйте этот фрагмент"
                : "Текст отклонён фильтром GigaFilter на выходе (" + location + ") — ответ модели не использован; "
                        + "измените промпт или входные данные";
    }
}
