package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import ru.sber.cs.ai.gigame.service.scenario.executor.PriceCheck.Verdict;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.List;

/**
 * Операция «сверить_цену_и_сроки» узла «Трансформация»: по JSON узлов «Условия договора» и «Данные протокола»
 * код сверяет цену (валюта, условие «не более», см. {@link PriceCheck}) и оценивает риск выхода срока
 * поставки за срок действия договора (см. {@link DeliveryTermCheck}).
 * <p>
 * Лот протокола выбирается по ИНН победителя, затем по номеру лота договора, затем по ближайшей цене.
 * Оборванный JSON (ответ модели зациклился или усечён, объект восстановлен до последней полной пары) сверяется
 * по уцелевшим полям, а отчёт получает строку {@link #TRUNCATED_MARK}: поля после места обрыва отброшены.
 * <pre>
 * {"оп": "сверить_цену_и_сроки"}
 * </pre>
 */
final class PriceTermOps {

    /** Начало строки отчёта об оборванном JSON (по ней узел выдаёт предупреждение). */
    static final String TRUNCATED_MARK = "⚠ JSON ";

    private PriceTermOps() {
    }

    /**
     * Отчёт по цене и срокам.
     *
     * @param text выходы предыдущих узлов (JSON договора и протокола)
     * @return отчёт с итоговым JSON
     */
    static String check(String text) {
        List<LlmJson.Parsed> blocks = JsonBlocks.parsedObjects(text);
        LlmJson.Parsed contractBlock = JsonBlocks.byDocumentType(blocks, "договор");
        LlmJson.Parsed protocolBlock = JsonBlocks.byDocumentType(blocks, "протокол");
        StringBuilder sb = new StringBuilder("ЦЕНА И СРОКИ (код)\n");
        if (contractBlock == null) {
            return sb.append("JSON условий договора не найден — проверка не выполнена\n{\"цена\": \"НЕТ ДАННЫХ\", \"риск_сроков\": \"НЕ ОЦЕНИВАЕТСЯ\"}").toString();
        }
        appendTruncation(sb, contractBlock, "условий договора");
        appendTruncation(sb, protocolBlock, "данных протокола");
        JsonNode contract = contractBlock.node();
        JsonNode protocol = protocolBlock == null ? null : protocolBlock.node();
        JsonNode lot = selectLot(protocol, contract);
        Verdict price = PriceCheck.check(contract, lot);
        Verdict term = DeliveryTermCheck.check(contract, protocol);
        sb.append("Цена").append(lot == null ? "" : " (лот " + lot.path("номер").asText("?") + ")").append(": ")
                .append(price.status()).append(" — ").append(price.text()).append('\n');
        sb.append("Срок поставки и срок действия договора: ").append(term.status()).append(" — ").append(term.text()).append('\n');
        return sb.append("{\"цена\": \"").append(price.status()).append("\", \"риск_сроков\": \"").append(term.status()).append("\"}").toString();
    }

    /**
     * Строка об оборванном JSON: поля после места обрыва отброшены, и вердикты по ним («НЕ ОЦЕНИВАЕТСЯ») — следствие
     * обрыва, а не отсутствия данных в документе (Субботин, s4: «объем» зациклился, срок действия договора потерян).
     *
     * @param sb    отчёт
     * @param block разобранный объект либо {@code null}
     * @param what  что за JSON («условий договора»)
     */
    private static void appendTruncation(StringBuilder sb, LlmJson.Parsed block, String what) {
        if (block != null && block.repaired()) {
            sb.append(TRUNCATED_MARK).append(what).append(" оборван (ответ модели зациклился или усечён): ").append(block.repair()).append('\n');
        }
    }

    /**
     * Лот протокола, к которому относится договор.
     *
     * @param protocol JSON протокола
     * @param contract JSON договора
     * @return лот либо {@code null}
     */
    static JsonNode selectLot(JsonNode protocol, JsonNode contract) {
        JsonNode lots = protocol == null ? null : protocol.path("лоты");
        if (lots == null || !lots.isArray() || lots.isEmpty()) {
            return null;
        }
        if (lots.size() == 1) {
            return lots.get(0);
        }
        JsonNode byInn = byField(lots, "ИНН_победителя", digits(contract.path("ИНН_поставщика").asText("")));
        if (byInn != null) {
            return byInn;
        }
        JsonNode byNumber = byField(lots, "номер", digits(contract.path("лот").asText("")));
        return byNumber != null ? byNumber : closestPrice(lots, PriceCheck.amount(contract.path("сумма")));
    }

    private static JsonNode byField(JsonNode lots, String field, String value) {
        if (value.isEmpty()) {
            return null;
        }
        for (JsonNode lot : lots) {
            if (value.equals(digits(lot.path(field).asText("")))) {
                return lot;
            }
        }
        return null;
    }

    private static JsonNode closestPrice(JsonNode lots, Double sum) {
        JsonNode best = lots.get(0);
        double bestDiff = Double.MAX_VALUE;
        for (JsonNode lot : lots) {
            Double price = PriceCheck.amount(lot.path("цена_победителя"));
            if (sum != null && price != null && Math.abs(price - sum) < bestDiff) {
                bestDiff = Math.abs(price - sum);
                best = lot;
            }
        }
        return best;
    }

    private static String digits(String text) {
        return text.replaceAll("\\D", "");
    }
}
