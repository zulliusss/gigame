package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;
import ru.sber.cs.ai.gigame.ws.enums.ActionType;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * WebSocket обработчик для чата.
 * <p>
 * Реализует WebFlux WebSocket Handler для потоковой передачи сообщений
 * между клиентом и сервером в реальном времени через WebSocket.
 * <p>
 * Принимает сообщения от клиентов в формате:
 * {
 * "conversation_id": "uuid",
 * "content": "text",
 * "document_ids": ["uuid1", "uuid2"]
 * }
 * и отправляет ответы в формате StreamEvent:
 * {
 * "conversation_id": "uuid",
 * "content": "text",
 * "usage": { "prompt_tokens": n, "completion_tokens": n, "total_tokens": n },
 * "document_ids": ["uuid1", "uuid2"],
 * "done": true,
 * "error": "message"
 * }
 * <p>
 * Ошибка генерации (чужой или несуществующий диалог, исчерпанные повторы GigaChat)
 * уходит клиенту кадром с полем {@code error} и причиной; сокет при этом не закрывается.
 * Команды одной сессии обрабатываются последовательно; сессия без сообщений дольше
 * {@code app.chat.ws-idle-timeout-minutes} закрывается сервером.
 *
 * @see WebSocketSessionManager
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ChatWebSocketHandler implements WebSocketHandler {

    /** Лимит длины текста ошибки в кадре: причины GigaChat с цепочкой вложенных ошибок бывают длинными. */
    static final int ERROR_MAX_LENGTH = 1000;

    private final ChatService chatService;
    private final WebSocketSessionManager sessionManager;
    private final ObjectMapper objectMapper;
    private final DocsTextCacheService documentTextCache;

    /**
     * Бездействие сессии (минуты без сообщений от клиента) до закрытия сервером;
     * идущая генерация дорабатывает. 0 — без таймаута.
     */
    @Value("${app.chat.ws-idle-timeout-minutes:30}")
    private long idleTimeoutMinutes = 30;

    /**
     * Лимит длины сообщения пользователя (maxLength поля content в SendMessageRequest спецификации).
     */
    @Value("${app.chat.max-message-chars:4096}")
    private int maxMessageChars = 4096;

    @Override
    @NonNull
    public Mono<Void> handle(@NonNull WebSocketSession session) {
        try {
            return doHandle(session);
        } finally {
            CurrentUserHolder.clear();
        }
    }

    private Mono<Void> doHandle(WebSocketSession session) {
        String sessionId = session.getId();
        var userId = WebSocketSessionManager.extractUserIdFromWebSocketSession(session);
        log.info("[{}] connected, sessionId={}", userId, sessionId);
        sessionManager.addSession(session);

        return Mono.defer(() ->
                withIdleTimeout(session.receive(), userId, sessionId)
                        .doOnNext(msg -> log.info("[{}] Received WebSocket message, payload: {}", userId, msg.getPayloadAsText()))
                        // команды одной сессии — строго по очереди: события двух генераций не перемежаются
                        .flatMap(message -> handleIncomingMessage(session, message, userId), 1)
                        .then()
                        // doFinally срабатывает и при отмене (клиент закрыл соединение посреди генерации),
                        // doOnTerminate — нет: сессия оставалась в карте до фоновой чистки
                        .doFinally(signal -> {
                            sessionManager.removeSession(session);
                            // Кэш текстов документов НЕ чистим здесь: фронтенд закрывает и
                            // переоткрывает сокет между сообщениями, и очистка по closing старой
                            // сессии затирала бы файлы, только что загруженные для следующего
                            // сообщения того же диалога (гонка). Кэш живёт по TTL/maxSize
                            // (DocsTextCacheService) и чистится при удалении диалога.
                            log.info("[{}]WebSocket chat connection closed: sessionId={}, signal={}", userId, sessionId, signal);
                        })).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Входящий поток с таймаутом бездействия: без сообщений от клиента дольше лимита
     * приём завершается, сессия закрывается после окончания текущей генерации.
     *
     * @param receive   входящие сообщения сессии
     * @param userId    идентификатор пользователя (для журнала)
     * @param sessionId идентификатор сессии (для журнала)
     * @return поток с таймаутом либо исходный при выключенном таймауте
     */
    private Flux<WebSocketMessage> withIdleTimeout(Flux<WebSocketMessage> receive, String userId, String sessionId) {
        if (idleTimeoutMinutes <= 0) {
            return receive;
        }
        return receive.timeout(Duration.ofMinutes(idleTimeoutMinutes), Flux.defer(() -> {
            log.info("[{}] WebSocket chat session idle for {} min, closing: sessionId={}", userId, idleTimeoutMinutes, sessionId);
            return Flux.empty();
        }));
    }

    private Mono<Void> handleIncomingMessage(WebSocketSession session,
                                             WebSocketMessage message,
                                             String userId) {
        CurrentUserHolder.setCurrentUser(userId);
        String payload = message.getPayloadAsText();
        log.info("[{}] Received chat message: sessionId={}, payload={}", userId, session.getId(), payload);

        try {
            ChatMessage chatMessage = objectMapper.readValue(
                    payload,
                    ChatMessage.class
            );

            return processChatMessage(chatMessage, session.getId())
                    .then(Mono.empty());
        } catch (Exception e) {
            log.error("[{}] Error handling message: sessionId={}", userId, session.getId(), e);
            return sendErrorMessage(session, "Ошибка обработки сообщения: " + e.getMessage());
        } finally {
            // пользователь уже захвачен в построенной цепочке; поток event loop не должен его хранить
            CurrentUserHolder.clear();
        }
    }

    private Mono<Void> processChatMessage(ChatMessage message, String sessionId) {
        UUID conversationId = message.conversationId();
        String content = message.content();
        var userId = CurrentUserHolder.getCurrentUser();
        String action = message.action() != null ? message.action() : "send";

        log.info("[{}] processChatMessage, conversationId={}, action={}", userId, conversationId, action);
        CurrentUserHolder.setCurrentUser(userId);
        WebSocketSession wsSession = sessionManager.getSession(sessionId);
        if (wsSession == null || !wsSession.isOpen()) {
            log.warn("WebSocket session not found or closed: sessionId={}", sessionId);
            return Mono.empty();
        }
        if (content != null && content.length() > maxMessageChars) {
            String error = "Сообщение длиннее " + maxMessageChars + " символов (" + content.length() + ") — сократите текст";
            return sendFrame(wsSession, createStreamEvent(conversationId, Map.of(ChatService.ERROR, error)));
        }
        Flux<ServerSentEvent<Map<String, Object>>> stream = buildStream(message, action, userId);
        return Flux.from(stream
                        .map(serverSentEvent -> createStreamEvent(conversationId, serverSentEvent.data()))
                        .doOnNext(event -> log.info("[{}] Sending to client: {}", userId, event))
                        .doOnComplete(() -> log.info("[{}] Chat stream completed for sessionId={}", userId, sessionId)))
                // ошибка генерации — кадр error с причиной, сокет остаётся открытым
                .onErrorResume(e -> Flux.just(errorEvent(conversationId, userId, e)))
                .map(wsSession::textMessage)
                .delayElements(Duration.ofMillis(10))
                .as(wsSession::send)
                .then();
    }

    /**
     * Поток событий сервиса по команде клиента. Документы берутся из кэша диалога;
     * пустой кэш для regenerate/edit передаётся как {@code null}: сервис читает
     * вложения сообщения из хранилища либо сообщает, что они устарели.
     *
     * @param message команда клиента
     * @param action  действие (send, regenerate, edit)
     * @param userId  идентификатор пользователя
     * @return поток SSE-событий
     */
    private Flux<ServerSentEvent<Map<String, Object>>> buildStream(ChatMessage message, String action, String userId) {
        UUID conversationId = message.conversationId();
        String content = message.content();
        var documentsText = documentTextCache.getCachedDocumentTexts(conversationId);
        var docIds = documentTextCache.getCachedDocIds(conversationId);
        boolean cached = !documentsText.isEmpty();
        switch (ActionType.valueOf(action.toUpperCase())) {
            case REGENERATE -> {
                return chatService.regenerateStream(conversationId,
                        cached ? docIds : null, cached ? documentsText : null);
            }
            case EDIT -> {
                return chatService.editMessageStream(conversationId, message.messageId(), content,
                        cached ? docIds : null, cached ? documentsText : null);
            }
            default -> {
                // Имена прикреплённых файлов добавляются к сообщению читаемым списком
                // конкатенация List + String давала префикс "[]" у каждого сообщения
                var fileNames = documentTextCache.getCachedFileNames(conversationId);
                var prefix = fileNames.isEmpty()
                        ? ""
                        : "Прикреплённые файлы: " + String.join(", ", fileNames) + "\n";
                return CurrentUserHolder.withUser(userId, () -> chatService.sendMessageStream(
                        conversationId, prefix + (content != null ? content : ""),
                        docIds, documentsText));
            }
        }
    }

    /**
     * Кадр ошибки генерации: причина (403/404, исчерпанные повторы GigaChat) в поле error.
     *
     * @param conversationId UUID диалога
     * @param userId         идентификатор пользователя (для журнала)
     * @param e              ошибка потока
     * @return JSON кадра
     */
    private String errorEvent(UUID conversationId, String userId, Throwable e) {
        log.error("[{}] Chat stream failed, conversationId={}", userId, conversationId, e);
        String reason = e.getMessage() == null || e.getMessage().isBlank()
                ? e.getClass().getSimpleName()
                : e.getMessage();
        return createStreamEvent(conversationId, Map.of(ChatService.ERROR, SchemaLimitUtils.clip(reason, ERROR_MAX_LENGTH)));
    }

    private Mono<Void> sendFrame(WebSocketSession session, String json) {
        return session.send(Flux.just(json).map(session::textMessage));
    }

    /**
     * Преобразует данные SSE в формат StreamEvent.
     *
     * @param conversationId UUID диалога
     * @param data           данные SSE
     * @return Map в формате StreamEvent
     */
    private String createStreamEvent(UUID conversationId, Map<String, Object> data) {
        Map<String, Object> event = new HashMap<>();

        if (conversationId != null) {
            event.put("conversation_id", conversationId.toString());
        }

        if (data.containsKey(ChatService.CONTENT)) {
            event.put("content", data.get(ChatService.CONTENT));
        }

        if (data.containsKey(ChatService.USAGE)) {
            event.put("usage", data.get(ChatService.USAGE));
        }

        if (data.containsKey(ChatService.SOURCES)) {
            event.put("sources", data.get(ChatService.SOURCES));
        }

        if (data.containsKey(ChatMessage.DOCUMENT_ID_KEY)) {
            event.put("document_ids", data.get(ChatMessage.DOCUMENT_ID_KEY));
        }

        if (data.containsKey(ChatService.DONE)) {
            event.put("done", data.get(ChatService.DONE));
        }

        if (data.containsKey(ChatService.ERROR)) {
            event.put("error", data.get(ChatService.ERROR));
        }

        try {
            return objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            log.error("Error serializing StreamEvent", e);
            return "{}";
        }
    }

    private Mono<Void> sendErrorMessage(WebSocketSession session, String errorMessage) {
        if (session != null && session.isOpen()) {
            try {
                Map<String, Object> errorEvent = Map.of(
                        "session_id", session.getId(),
                        "error", errorMessage
                );
                String json = objectMapper.writeValueAsString(errorEvent);
                return session.send(Flux.just(json).map(session::textMessage));
            } catch (Exception e) {
                log.error("Error serializing error message", e);
                return Mono.error(e);
            }
        }
        return Mono.empty();
    }

    /**
     * Сообщение WebSocket от клиента.
     *
     * @param conversationId UUID диалога
     * @param content        текст сообщения (для edit — новый текст)
     * @param documentIds    список UUID документов (опционально)
     * @param action         действие: send (по умолчанию), regenerate, edit
     * @param messageId      UUID редактируемого сообщения (для action=edit)
     */
    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public record ChatMessage(
            UUID conversationId,
            String content,
            List<String> documentIds,
            String action,
            UUID messageId
    ) {
        static String DOCUMENT_ID_KEY = "document_ids";
    }
}
