package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ru.sber.cs.ai.gigame.service.scenario.executor.Form3Ops.str;

/**
 * Поиск акта/УПД строки Формы 3 по алгоритму Егоровой (письмо «Ошибки по акту» и ответы методолога, 16.09.2026).
 * <p>
 * Правило 1 (в форме указан номер акта/УПД): признаки — (а) номер и дата акта, (б) дата подписания из графы формы
 * «Дата подписания» (без подстановки даты из реквизитов акта) против последней подписи в штампе ЭДО, а без штампа —
 * даты приёмки УПД или даты документа (источник даты пишется в аудит; штамп в тексте есть, но дата не разобрана —
 * признак не совпадает, в аудите «штамп ЭДО не разобран»), (в) сумма «Всего к оплате» до копейки
 * (у акта — итог акта либо итог этапа с явной меткой «Итого»/«Всего»/«к оплате»/«составляет»/«Стоимость этапа»);
 * документ найден, если совпали минимум два признака из трёх. Оговорка проекта — короткая форма участника (Комплект 7):
 * в строке нет граф суммы и даты подписания (обе пусты, «не применимо» или «да»), и точный номер вместе с датой акта
 * достаточен. В полной форме точный номер без (б) и (в) документ не находит.
 * Правило 2 (номер не указан — «б/н», «б.н.», «б\н» или пусто): признаки только (б) и (в), документ найден,
 * если совпали оба; дата акта из формы — не признак, а лишь разрешение ничьей между полными совпадениями.
 * Правило 3: документ, полностью совпавший (3 из 3, 2 из 2, точный номер короткой формы) со строками разных договоров
 * и/или спецификаций, для которых он лучший полный кандидат, не идентифицирован — он не достаётся никому,
 * строки-претенденты получают особый {@link Hit}.
 * <p>
 * Кроме признаков, в тексте документа должны быть реквизиты договора строки (номер, дата — если указана),
 * а документ чужой спецификации не подходит (дубль акта другой спецификации в папке). При нескольких
 * кандидатах выбор — по полноте совпадения, числу признаков, сумме, спецификации, точному номеру; равные кандидаты
 * помечаются в аудите. Каждый документ достаётся одной строке: сначала лучшие совпадения по всем строкам, чтобы одна
 * строка не забрала документ, точно принадлежащий другой.
 * <p>
 * Строкам без документа после правил 1–3 полагаются только ходы с пометкой в аудите и проверкой агентом
 * ({@link Sign#TOLERANCE}): запасной ход {@link #ignoringDocSpec} (правило 1/2 выполнено, но номер спецификации,
 * взятый из пути к файлу, не совпал со строкой; правило 3 действует и здесь), допуск распознавания
 * {@link #scanTolerance}, допуск {@link #anySignTolerance} (дата графы — дата не последней подписи штампа ЭДО; параметр
 * «б/н_любая_подпись», по умолчанию включён) и — по параметру операции «б/н_допуски» — допуски
 * {@link #actDateTolerance} и {@link #specTolerance} для строк без номера.
 */
final class Form3Match {

    /** Поле УПД-карты строки с пояснением поиска для аудита. */
    static final String NOTE = "поиск_примечание";
    private static final int FOUND = 2;
    /** Число признаков правила 1. */
    private static final int FEATURES = 3;
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern FORM_NUMBER = Pattern.compile("№\\s*([^\\s,;()]+)");
    private static final Pattern NO_NUMBER = Pattern.compile("(?<![А-Яа-яЁёA-Za-z])[бБ]\\s*[./\\\\-]\\s*[нН]\\.?(?![А-Яа-яЁё])");
    /** Знак номера относится не к акту, а к заявке, спецификации, договору или заказу: «по Заявке №10», «к Договору № ШТ-2023». */
    private static final Pattern FOREIGN_SIGN = Pattern.compile("(?<![А-Яа-яЁё])(?:заявк|специфик|спец|договор|дог|дс|заказ|знзо)[А-Яа-яЁё.]*\\s*$", FLAGS);
    /** Номер акта без знака «№»: «Акт 12 от 30.06.2025» (но не дата «Акт 12.01.2026»). */
    private static final Pattern ACT_NUMBER = Pattern.compile("(?<![А-Яа-яЁёA-Za-z])Акт\\s+(\\d{1,12})(?!\\d|[.,/]\\d)", FLAGS);
    private static final Pattern DIGIT = Pattern.compile("\\d");
    private static final Comparator<Hit> RANK = Comparator.comparing(Hit::full, Comparator.reverseOrder())
            .thenComparing(Hit::score, Comparator.reverseOrder())
            .thenComparing(Hit::amount, Comparator.reverseOrder())
            .thenComparing(Hit::spec, Comparator.reverseOrder())
            .thenComparing(Hit::exact, Comparator.reverseOrder())
            .thenComparing(Hit::dateTie, Comparator.reverseOrder())
            .thenComparingInt(Hit::order);

    private Form3Match() {
    }

    /** Признаки кандидата: совпадения строки формы с документом и свойства самой строки. */
    enum Sign {
        /** Совпали номер и дата акта (у строки без номера — только дата акта, не признак). */
        ACT,
        /** Совпала дата подписания. */
        SIGN,
        /** Совпала сумма. */
        AMOUNT,
        /** Документ той же спецификации/заявки, что строка. */
        SPEC,
        /** Номер указан и в форме, и в документе и совпал. */
        EXACT,
        /** Номер акта в форме не указан — правило 2 (свойство строки). */
        NO_NUMBER,
        /** В строке нет граф суммы и даты подписания — короткая форма (свойство строки). */
        SHORT_FORM,
        /** Документ найден не правилами 1–3, а запасным ходом или допуском — строка на проверку агенту. */
        TOLERANCE
    }

    /**
     * Кандидат в документы строки формы.
     *
     * @param line         строка формы
     * @param doc          документ реестра (УПД или акт)
     * @param signs        совпавшие признаки и свойства строки
     * @param order        порядок перебора (строка формы, затем документ)
     * @param note         пояснение для аудита
     * @param unidentified документ не идентифицирован (правило 3): строка — один из претендентов, документ ей не достаётся
     */
    record Hit(Form3Form.Row line, Map<String, Object> doc, Set<Sign> signs, int order, String note, boolean unidentified) {

        boolean act() {
            return signs.contains(Sign.ACT);
        }

        boolean sign() {
            return signs.contains(Sign.SIGN);
        }

        boolean amount() {
            return signs.contains(Sign.AMOUNT);
        }

        boolean spec() {
            return signs.contains(Sign.SPEC);
        }

        /** Точный номер совпал вместе с датой акта. */
        boolean exact() {
            return signs.contains(Sign.EXACT) && act();
        }

        boolean noNumber() {
            return signs.contains(Sign.NO_NUMBER);
        }

        boolean shortForm() {
            return signs.contains(Sign.SHORT_FORM);
        }

        /** Документ найден запасным ходом или допуском — на проверку агенту. */
        boolean tolerance() {
            return signs.contains(Sign.TOLERANCE);
        }

        /** Число совпавших признаков: из трёх по правилу 1, из двух (дата подписания и сумма) по правилу 2. */
        int score() {
            return (act() && !noNumber() ? 1 : 0) + (sign() ? 1 : 0) + (amount() ? 1 : 0);
        }

        /** Документ найден: оба признака по правилу 2, точный номер в короткой форме, два признака из трёх по правилу 1. */
        boolean found() {
            if (noNumber()) {
                return sign() && amount();
            }
            return shortForm() ? exact() : score() >= FOUND;
        }

        /** Полное совпадение (для правила 3): два из двух по правилу 2, точный номер короткой формы, три из трёх по правилу 1. */
        boolean full() {
            if (noNumber()) {
                return sign() && amount();
            }
            return shortForm() ? exact() : score() == FEATURES;
        }

        /** Дата акта формы совпала у строки без номера: не признак, а разрешение ничьей между полными совпадениями. */
        boolean dateTie() {
            return noNumber() && act();
        }

        boolean sameRank(Hit other) {
            return full() == other.full() && score() == other.score() && amount() == other.amount() && spec() == other.spec()
                    && exact() == other.exact() && dateTie() == other.dateTie();
        }

        Hit withNote(String text) {
            return new Hit(line, doc, signs, order, text, unidentified);
        }

        Hit asUnidentified(String text) {
            return new Hit(line, doc, signs, order, text, true);
        }
    }

    /**
     * Строки формы и занятые документы — для пояснений аудита, почему строка осталась без документа.
     *
     * @param lines   строки формы
     * @param used    документы, доставшиеся строкам (правилами или ходами)
     * @param blocked неидентифицированные документы (правило 3)
     */
    record Taken(List<Form3Form.Row> lines, Set<Map<String, Object>> used, Set<Map<String, Object>> blocked) {
    }

    /**
     * Документы строк формы по правилам 1–3 с проверкой реквизитов договора.
     *
     * @param lines строки формы
     * @param docs  УПД и акты реестра
     * @return найденный документ для каждой строки, у которой он есть; для претендентов на неидентифицированный
     *     документ (правило 3) — особый {@link Hit#unidentified()}
     */
    static Map<Form3Form.Row, Hit> assign(List<Form3Form.Row> lines, List<Map<String, Object>> docs) {
        List<Hit> hits = candidates(lines, docs, false);
        return resolve(hits, (hit, blocked) -> hit.withNote(note(hit, hits, blocked)));
    }

    /**
     * Запасной ход после правил 1–3 для строк без документа: правило 1 или 2 выполнено, но документ отсеян только
     * ссылкой на спецификацию, взятой из пути к файлу (папка спецификации — признак реестра
     * {@link Form3Ops#SPEC_BY_NAME}); спецификация, названная в тексте документа, ходом не обходится. Прежние ходы
     * «УПД по сумме и дате» и «акт по спецификации и сумме» находили документ и при одном признаке из трёх, поэтому
     * заменены этим ходом. Правило 3 действует и здесь: документ, полностью совпавший со строками разных договоров и/или
     * спецификаций, не идентифицирован. Найденный документ получает пометку в аудите и строку на проверку агенту.
     *
     * @param lines строки формы без документа
     * @param docs  свободные УПД и акты реестра
     * @return найденный документ для строк, у которых он есть; для претендентов на неидентифицированный документ —
     *     особый {@link Hit#unidentified()}
     */
    static Map<Form3Form.Row, Hit> ignoringDocSpec(List<Form3Form.Row> lines, List<Map<String, Object>> docs) {
        List<Map<String, Object>> byName = docs.stream().filter(doc -> Boolean.TRUE.equals(doc.get(Form3Ops.SPEC_BY_NAME))).toList();
        return resolve(candidates(lines, byName, true), (hit, blocked) -> tolerant(hit, "запасной ход: " + ruleNote(hit)
                + "; номер спецификации документа («" + hit.doc().get("спецификация") + "», из пути к файлу) не совпал со "
                + "спецификацией строки — на проверку"));
    }

    /**
     * Распределение кандидатов по строкам: правило 3 (неидентифицированный документ никому не достаётся, его претенденты
     * других документов не получают), затем каждый документ — лучшей по рангу строке.
     *
     * @param hits   кандидаты всех строк в порядке ранга
     * @param accept итоговый кандидат строки по кандидату и множеству неидентифицированных документов
     * @return документ для каждой строки, у которой он есть
     */
    private static Map<Form3Form.Row, Hit> resolve(List<Hit> hits, BiFunction<Hit, Set<Map<String, Object>>, Hit> accept) {
        Map<Form3Form.Row, Hit> out = unidentified(hits);
        Set<Map<String, Object>> blocked = Collections.newSetFromMap(new IdentityHashMap<>());
        out.values().forEach(hit -> blocked.add(hit.doc()));
        Set<Map<String, Object>> used = Collections.newSetFromMap(new IdentityHashMap<>());
        used.addAll(blocked);
        for (Hit hit : hits) {
            if (!out.containsKey(hit.line()) && used.add(hit.doc())) {
                out.put(hit.line(), accept.apply(hit, blocked));
            }
        }
        return out;
    }

    /** Кандидаты всех строк в порядке ранга; {@code foreignOnly} — только документы, отсеянные ссылкой на чужую спецификацию. */
    private static List<Hit> candidates(List<Form3Form.Row> lines, List<Map<String, Object>> docs, boolean foreignOnly) {
        List<Hit> hits = new ArrayList<>();
        int order = 0;
        for (Form3Form.Row line : lines) {
            EnumSet<Sign> base = rowSigns(line);
            for (Map<String, Object> doc : docs) {
                Hit hit = evaluate(line, base, doc, order++, foreignOnly);
                if (hit != null) {
                    hits.add(hit);
                }
            }
        }
        hits.sort(RANK);
        return hits;
    }

    /** Свойства строки формы — вычисляются один раз на строку. */
    private static EnumSet<Sign> rowSigns(Form3Form.Row line) {
        EnumSet<Sign> signs = EnumSet.noneOf(Sign.class);
        mark(signs, Sign.NO_NUMBER, noNumber(line));
        mark(signs, Sign.SHORT_FORM, shortForm(line));
        return signs;
    }

    private static void mark(Set<Sign> signs, Sign sign, boolean value) {
        if (value) {
            signs.add(sign);
        }
    }

    /**
     * Правило 3: документ, полностью совпавший со строками формы разных договоров и/или спецификаций, не
     * идентифицирован — все строки-претенденты получают особый {@link Hit} с перечнем претендентов для аудита.
     * Претендент — строка, для которой документ лучший полный кандидат: у строки с другим полным кандидатом выше рангом
     * (своя спецификация, точный номер) этот документ не спорный. Строки одного договора и спецификации решаются
     * обычной ничьёй.
     *
     * @param hits кандидаты всех строк в порядке ранга
     * @return особые кандидаты строк-претендентов
     */
    private static Map<Form3Form.Row, Hit> unidentified(List<Hit> hits) {
        Map<Form3Form.Row, Hit> best = new IdentityHashMap<>();
        hits.stream().filter(Hit::full).forEach(hit -> best.putIfAbsent(hit.line(), hit));
        List<Hit> claimants = hits.stream().filter(hit -> best.get(hit.line()) == hit).toList();
        Map<Form3Form.Row, Hit> out = new IdentityHashMap<>();
        for (Hit hit : claimants) {
            List<Hit> same = claimants.stream().filter(h -> h.doc() == hit.doc()).toList();
            if (!out.containsKey(hit.line()) && same.stream().map(h -> rowKey(h.line())).distinct().count() > 1) {
                String note = "правило 3: документ «" + hit.doc().get("файл") + "» полностью совпал со строками разных "
                        + "договоров/спецификаций — акт не идентифицирован; претенденты: " + claimantsLabel(same);
                same.forEach(h -> out.put(h.line(), h.asUnidentified(note)));
            }
        }
        return out;
    }

    /** Ключ строки для правила 3: номер договора и номер спецификации/заявки из формы. */
    private static String rowKey(Form3Form.Row line) {
        return Form3Rows.contractNumber(line.contract()) + "|" + Form3Rows.specNumber(line.spec());
    }

    /** Строки-претенденты для аудита: реквизиты акта, договор и спецификация каждой. */
    private static String claimantsLabel(List<Hit> claimants) {
        List<String> labels = new ArrayList<>();
        for (Hit h : claimants) {
            String contract = Form3Rows.contractNumber(h.line().contract());
            String spec = Form3Rows.specNumber(h.line().spec());
            labels.add("«" + h.line().act() + "» (договор " + (contract.isEmpty() ? "не указан" : contract) + ", спецификация "
                    + (spec.isEmpty() ? "не указана" : spec) + ")");
        }
        return String.join(", ", labels);
    }

    /**
     * Запасной ход для документа без текста (скан не распознан): номер и дата акта из имени файла,
     * договор — из пути к файлу. Методолог выбрала распознавание сканов моделью, поэтому ход включается
     * только параметром операции {@link Form3Rows#SCANS_BY_NAME}; найденный так документ — на проверку агенту. Строке без
     * номера ход не полагается: по правилу 2 документ опознаётся лишь по дате подписания и сумме, а имя файла даёт только
     * дату акта.
     *
     * @param line строка формы
     * @param acts акты реестра
     * @param used уже занятые документы
     * @return акт или {@code null}
     */
    static Hit byFileName(Form3Form.Row line, List<Map<String, Object>> acts, Set<Map<String, Object>> used) {
        if (noNumber(line)) {
            return null;
        }
        for (Map<String, Object> act : acts) {
            if (!used.contains(act) && Boolean.TRUE.equals(act.get("без_текста")) && contractFits(line, act)
                    && !foreignSpec(line, act) && actFits(line, act)) {
                return new Hit(line, act, EnumSet.of(Sign.ACT, Sign.TOLERANCE), 0, "реквизиты по имени файла, текст не распознан — на проверку", false);
            }
        }
        return null;
    }

    /**
     * Допуск распознавания (технический, не методологический; включён всегда): у строки без номера распознанный скан
     * акта (поле «скан») найден по дате подписания и номеру заявки/спецификации строки, а сумма формы в распознанном
     * тексте не найдена — модель ошибается в цифрах. Сумма берётся из формы участника с пометкой, строка — на проверку агенту.
     *
     * @param line строка формы
     * @param acts акты реестра
     * @param used уже занятые документы
     * @return акт или {@code null}
     */
    static Hit scanTolerance(Form3Form.Row line, List<Map<String, Object>> acts, Set<Map<String, Object>> used) {
        if (!noNumber(line)) {
            return null;
        }
        for (Map<String, Object> act : acts) {
            if (free(line, act, used) && Boolean.TRUE.equals(act.get("скан")) && sameSpec(line, act) && signFits(line, act)) {
                return tolerant(new Hit(line, act, EnumSet.of(Sign.SIGN, Sign.SPEC), 0, "", false),
                        "допуск распознавания: распознанный скан найден по дате подписания (" + signSource(act)
                                + ") и номеру заявки/спецификации, сумма формы в распознанном тексте не найдена — на проверку");
            }
        }
        return null;
    }

    /**
     * Допуск «любая подпись штампа», параметр «б/н_любая_подпись» (по умолчанию включён): у строки без номера сумма
     * совпала, а дата в графе подписания равна дате не последней подписи штампа ЭДО (подписи исполнителя). Пример
     * методолога к правилу 2 (Комплект 9, «б/н от 10.06.2025 (Этап 1)»): в форме 10.06.2025 — подпись исполнителя
     * 10.06.2025 12:30:34, заказчик подписал 11.06.2025 17:18:25, а ответ на вопрос 4 требует последнюю подпись.
     * Документ с этой суммой и подписью у строки должен быть единственным; до ответа методолога — на проверку агенту.
     *
     * @param line строка формы
     * @param docs УПД и акты реестра
     * @param used уже занятые документы
     * @return документ или {@code null}
     */
    static Hit anySignTolerance(Form3Form.Row line, List<Map<String, Object>> docs, Set<Map<String, Object>> used) {
        if (!noNumber(line) || line.signDate().isEmpty()) {
            return null;
        }
        List<Map<String, Object>> signed = docs.stream().filter(doc -> free(line, doc, used) && !foreignSpec(line, doc)
                && signatures(doc).contains(line.signDate()) && !signFits(line, doc) && amountFits(line, doc)).toList();
        if (signed.size() != 1) {
            return null;
        }
        Map<String, Object> doc = signed.get(0);
        return tolerant(new Hit(line, doc, EnumSet.of(Sign.AMOUNT), 0, "", false),
                "допуск подписи штампа: дата в графе подписания формы " + line.signDate() + " — дата одной из подписей штампа ЭДО ("
                        + String.join(", ", signatures(doc)) + "), а не последней (" + signSource(doc)
                        + "); сумма совпала, документ единственный — на проверку");
    }

    /** Даты всех подписей штампа ЭДО документа реестра. */
    private static List<String> signatures(Map<String, Object> doc) {
        return doc.get(Form3Acts.SIGNATURES) instanceof Collection<?> dates ? dates.stream().map(String::valueOf).toList() : List.of();
    }

    /**
     * Допуск «б/н» (а), параметр «б/н_допуски»: у строки без номера дата в графе подписания равна дате самого акта
     * (участник пишет в графу дату акта, а штамп ЭДО позже — Комплекты 5 Хинт и 9 АксТим), сумма совпала, и документ с
     * этой суммой у строки единственный. Методологически спорно — на проверку агенту.
     *
     * @param line строка формы
     * @param docs УПД и акты реестра
     * @param used уже занятые документы
     * @return документ или {@code null}
     */
    static Hit actDateTolerance(Form3Form.Row line, List<Map<String, Object>> docs, Set<Map<String, Object>> used) {
        if (!noNumber(line) || line.signDate().isEmpty()) {
            return null;
        }
        List<Map<String, Object>> sameAmount = docs.stream()
                .filter(doc -> free(line, doc, Set.of()) && !foreignSpec(line, doc) && amountFits(line, doc)).toList();
        if (sameAmount.size() != 1 || used.contains(sameAmount.get(0)) || !line.signDate().equals(str(sameAmount.get(0).get("дата")))) {
            return null;
        }
        Map<String, Object> doc = sameAmount.get(0);
        return tolerant(new Hit(line, doc, EnumSet.of(Sign.AMOUNT), 0, "", false),
                "б/н допуск (а): дата в графе подписания формы " + line.signDate() + " равна дате акта, дата подписания документа — "
                        + signSource(doc) + "; сумма совпала, документ с этой суммой единственный — на проверку");
    }

    /**
     * Допуск «б/н» (б), параметр «б/н_допуски»: у строки без номера совпали номер спецификации/заявки строки и сумма,
     * а дата подписания нет (акты Сбера docx без штампа ЭДО). Методологически спорно — на проверку агенту.
     *
     * @param line строка формы
     * @param docs УПД и акты реестра
     * @param used уже занятые документы
     * @return документ или {@code null}
     */
    static Hit specTolerance(Form3Form.Row line, List<Map<String, Object>> docs, Set<Map<String, Object>> used) {
        if (!noNumber(line)) {
            return null;
        }
        for (Map<String, Object> doc : docs) {
            if (free(line, doc, used) && sameSpec(line, doc) && amountFits(line, doc)) {
                return tolerant(new Hit(line, doc, EnumSet.of(Sign.SPEC, Sign.AMOUNT), 0, "", false),
                        "б/н допуск (б): совпали номер спецификации/заявки строки и сумма, дата подписания не совпала (в форме "
                                + (line.signDate().isEmpty() ? "не указана" : line.signDate()) + ", документ — " + signSource(doc) + ") — на проверку");
            }
        }
        return null;
    }

    /** Документ свободен, с текстом и с реквизитами договора строки. */
    private static boolean free(Form3Form.Row line, Map<String, Object> doc, Set<Map<String, Object>> used) {
        return !used.contains(doc) && !Boolean.TRUE.equals(doc.get("без_текста")) && contractFits(line, doc);
    }

    private static Hit tolerant(Hit hit, String note) {
        EnumSet<Sign> signs = EnumSet.copyOf(hit.signs());
        signs.add(Sign.TOLERANCE);
        return new Hit(hit.line(), hit.doc(), signs, hit.order(), note, false);
    }

    /**
     * Пояснение для аудита, почему строка осталась без документа. У строки с номером: точный номер и дата акта совпали,
     * но документ отнесён к другой строке, не идентифицирован (правило 3) или в полной форме не совпали сумма и/или дата
     * подписания (оговорка «точный номер достаточен» — только для короткой формы); либо дата акта/УПД и сумма совпали,
     * а номер другой (участник повторил номер соседней строки — Комплекты 6 и 9). У строки без номера — сумма совпала до
     * копейки, а дата подписания нет (правило 2: участник пишет в графу дату акта, штамп ЭДО позже), либо у распознанного
     * скана её заявки/спецификации не совпали ни сумма, ни дата подписания (Комплект 5).
     *
     * @param line  строка формы без документа
     * @param docs  УПД и акты реестра
     * @param taken строки формы, документы других строк и неидентифицированные документы
     * @return пояснение или пусто
     */
    static String missNote(Form3Form.Row line, List<Map<String, Object>> docs, Taken taken) {
        if (noNumber(line)) {
            return signMiss(line, docs, taken.used());
        }
        String exact = exactNumberMiss(line, docs, taken);
        return exact.isEmpty() ? otherNumberMiss(line, docs, taken) : exact;
    }

    private static String exactNumberMiss(Form3Form.Row line, List<Map<String, Object>> docs, Taken taken) {
        for (Map<String, Object> doc : docs) {
            if (!free(line, doc, Set.of()) || !exactNumber(line, doc) || !actFits(line, doc)) {
                continue;
            }
            String head = "документ «" + doc.get("файл") + "»: точный номер совпал, но ";
            if (taken.blocked().contains(doc)) {
                return head + "акт не идентифицирован (правило 3)";
            }
            if (taken.used().contains(doc)) {
                return head + "документ уже отнесён к другой строке формы";
            }
            List<String> missed = new ArrayList<>();
            addIf(missed, "сумма", !amountFits(line, doc));
            addIf(missed, "дата подписания", !signFits(line, doc));
            if (!shortForm(line) && !missed.isEmpty()) {
                return head + "не совпал" + (missed.size() > 1 ? "и " : "а ") + String.join(" и ", missed) + " (правило 1: "
                        + signCompare(line, doc) + "; " + amountCompare(line, doc) + ")";
            }
        }
        return "";
    }

    /** Строка с номером: у документа те же дата акта/УПД и сумма, но другой номер (номер повторяет соседнюю строку формы). */
    private static String otherNumberMiss(Form3Form.Row line, List<Map<String, Object>> docs, Taken taken) {
        String formDate = Form3Form.actDate("", line.act());
        String formNumber = formNumber(line.act());
        for (Map<String, Object> doc : docs) {
            String docNumber = number(str(doc.get("номер")));
            if (free(line, doc, taken.used()) && !foreignSpec(line, doc) && !formDate.isEmpty() && formDate.equals(str(doc.get("дата")))
                    && !docNumber.isEmpty() && !docNumber.equals(formNumber) && amountFits(line, doc)) {
                return "документ «" + doc.get("файл") + "»: дата акта/УПД и сумма совпали, но номер в форме «" + formNumber
                        + "» не совпал с номером документа «" + docNumber + "»" + repeatedNumber(line, formNumber, taken.lines())
                        + " (правило 1: " + signCompare(line, doc) + ")";
            }
        }
        return "";
    }

    /** Номер акта строки повторяет номер другой строки формы: «; номер повторяет строку 1 формы («УПД № … от …»)». */
    private static String repeatedNumber(Form3Form.Row line, String formNumber, List<Form3Form.Row> lines) {
        for (int i = 0; i < lines.size(); i++) {
            Form3Form.Row other = lines.get(i);
            if (other != line && formNumber.equals(formNumber(other.act()))) {
                return "; номер повторяет строку " + (i + 1) + " формы («" + other.act() + "»)";
            }
        }
        return "";
    }

    private static void addIf(List<String> names, String name, boolean value) {
        if (value) {
            names.add(name);
        }
    }

    /** Суммы формы и документа для аудита. */
    private static String amountCompare(Form3Form.Row line, Map<String, Object> doc) {
        return "сумма формы " + (line.amount().isEmpty() ? "не указана" : line.amount()) + ", документ — "
                + (str(doc.get("сумма")).isEmpty() ? "нет итога" : doc.get("сумма"));
    }

    private static String signMiss(Form3Form.Row line, List<Map<String, Object>> docs, Set<Map<String, Object>> used) {
        for (Map<String, Object> doc : docs) {
            if (free(line, doc, used) && !foreignSpec(line, doc) && amountFits(line, doc) && !signFits(line, doc)) {
                return "документ «" + doc.get("файл") + "»: сумма совпала, но дата подписания не совпала (правило 2: "
                        + signCompare(line, doc) + ")";
            }
        }
        return scanMiss(line, docs, used);
    }

    /** Строка без номера: распознанный скан её заявки/спецификации есть, но не совпали ни сумма, ни дата подписания (Комплект 5). */
    private static String scanMiss(Form3Form.Row line, List<Map<String, Object>> docs, Set<Map<String, Object>> used) {
        for (Map<String, Object> doc : docs) {
            if (free(line, doc, used) && Boolean.TRUE.equals(doc.get("скан")) && sameSpec(line, doc) && !signFits(line, doc)) {
                return "распознанный скан «" + doc.get("файл") + "» заявки/спецификации строки: не совпали сумма и дата подписания "
                        + "(правило 2: " + signCompare(line, doc) + "; " + amountCompare(line, doc) + ")";
            }
        }
        return "";
    }

    /** Даты подписания формы и документа с источником для аудита. */
    private static String signCompare(Form3Form.Row line, Map<String, Object> doc) {
        return "дата подписания в форме " + (line.signDate().isEmpty() ? "не указана" : line.signDate()) + ", документ — " + signSource(doc);
    }

    /**
     * Номер акта/УПД в форме не указан («б/н», «б.н.», «б\н» или пусто) — строка идёт по правилу 2.
     *
     * @param line строка формы
     * @return {@code true}, если номера нет
     */
    static boolean noNumber(Form3Form.Row line) {
        return formNumber(line.act()).isEmpty();
    }

    /**
     * Короткая форма: в строке нет граф суммы и даты подписания (обе пусты, «не применимо» или «да») — оговорка проекта
     * к правилу 1, документ находится по точному номеру и дате акта.
     *
     * @param line строка формы
     * @return {@code true}, если обеих граф нет
     */
    static boolean shortForm(Form3Form.Row line) {
        return line.amount().isEmpty() && line.signDate().isEmpty();
    }

    private static Hit evaluate(Form3Form.Row line, EnumSet<Sign> base, Map<String, Object> doc, int order, boolean foreignOnly) {
        if (Boolean.TRUE.equals(doc.get("без_текста")) || !contractFits(line, doc) || foreignSpec(line, doc) != foreignOnly) {
            return null;
        }
        EnumSet<Sign> signs = EnumSet.copyOf(base);
        mark(signs, Sign.ACT, actFits(line, doc));
        mark(signs, Sign.SIGN, signFits(line, doc));
        // дешёвые признаки раньше суммы: без даты подписания правило 2 не выполнить, а правило 1 — без неё и без номера/даты акта
        if (!signs.contains(Sign.SIGN) && (base.contains(Sign.NO_NUMBER) || !signs.contains(Sign.ACT))) {
            return null;
        }
        mark(signs, Sign.AMOUNT, amountFits(line, doc));
        mark(signs, Sign.SPEC, sameSpec(line, doc));
        mark(signs, Sign.EXACT, exactNumber(line, doc));
        Hit hit = new Hit(line, doc, signs, order, "", false);
        return hit.found() ? hit : null;
    }

    /** Точный номер акта/УПД совпал в форме и документе. */
    static boolean exactNumber(Form3Form.Row line, Map<String, Object> doc) {
        String formNumber = formNumber(line.act());
        String docNumber = number(str(doc.get("номер")));
        return !formNumber.isEmpty() && !docNumber.isEmpty() && formNumber.equals(docNumber);
    }

    private static String note(Hit hit, List<Hit> hits, Set<Map<String, Object>> blocked) {
        String note = ruleNote(hit);
        if (!contractDateFits(hit.line(), hit.doc())) {
            note = note + "; дата договора из формы в тексте документа не найдена";
        }
        long ties = hits.stream().filter(h -> h.line() == hit.line() && h.doc() != hit.doc() && !blocked.contains(h.doc())
                && h.sameRank(hit)).count();
        return ties == 0 ? note : note + "; неоднозначно: ещё " + ties + " документ(а) с теми же признаками, выбран «"
                + hit.doc().get("файл") + "»";
    }

    /** По какому правилу найден документ: правило 2 (без номера), точный номер (короткая форма) или правило 1; источник дат и сумм. */
    private static String ruleNote(Hit hit) {
        String sign = "дата подписания — " + yesNo(hit.sign()) + " (" + signDetail(hit) + ")";
        String amount = "сумма — " + yesNo(hit.amount()) + amountDetail(hit);
        if (hit.noNumber()) {
            return "правило 2 (номер акта не указан): " + sign + ", " + amount + "; дата акта из формы — " + yesNo(hit.act()) + " (не признак)";
        }
        if (hit.shortForm()) {
            return "документ найден по точному номеру и дате акта/УПД (короткая форма: в строке нет граф суммы и даты подписания)";
        }
        return "правило 1: документ найден по признакам «2 из 3» (" + hit.score() + " из 3): номер и дата акта — " + yesNo(hit.act())
                + ", " + sign + ", " + amount;
    }

    /** Источник даты подписания документа, а при несовпадении — и дата из формы. */
    private static String signDetail(Hit hit) {
        if (hit.sign()) {
            return signSource(hit.doc());
        }
        String form = hit.line().signDate();
        return (form.isEmpty() ? "в форме не указана" : "в форме " + form) + ", документ — " + signSource(hit.doc());
    }

    /** Сумма совпала не с итогом документа, а с итогом этапа в тексте акта. */
    private static String amountDetail(Hit hit) {
        String total = str(hit.doc().get("сумма"));
        return hit.amount() && !hit.line().amount().equals(total)
                ? " (итог этапа с меткой итога в тексте акта; итог акта " + (total.isEmpty() ? "не разобран" : total) + ")" : "";
    }

    private static String yesNo(boolean value) {
        return value ? Form3Rows.YES : Form3Rows.NO;
    }

    /** (а) Дата акта формы равна дате документа; номер сравнивается, если указан и в форме, и в документе. */
    static boolean actFits(Form3Form.Row line, Map<String, Object> doc) {
        String formDate = Form3Form.actDate("", line.act());
        if (formDate.isEmpty() || !formDate.equals(str(doc.get("дата")))) {
            return false;
        }
        String formNumber = formNumber(line.act());
        String docNumber = number(str(doc.get("номер")));
        return formNumber.isEmpty() || docNumber.isEmpty() || formNumber.equals(docNumber);
    }

    /** (б) Дата подписания из графы формы (без подстановки даты из реквизитов акта) равна дате подписания документа. */
    static boolean signFits(Form3Form.Row line, Map<String, Object> doc) {
        return !line.signDate().isEmpty() && line.signDate().equals(signDate(doc));
    }

    /**
     * (в) Сумма формы равна итогу документа до копейки; у акта — также итогу этапа с явной меткой итога в тексте
     * («Итого с НДС», «Следует к оплате», «составляет», «Стоимость этапа»; поле реестра {@link Form3Acts#TOTALS}, считается
     * один раз при разборе акта), но не любому числу текста (ставке, позиции).
     *
     * @param line строка формы
     * @param doc  документ реестра
     * @return {@code true}, если сумма совпала
     */
    static boolean amountFits(Form3Form.Row line, Map<String, Object> doc) {
        String amount = line.amount();
        if (amount.isEmpty()) {
            return false;
        }
        return amount.equals(str(doc.get("сумма"))) || Form3Acts.KIND_ACT.equals(doc.get("вид"))
                && doc.get(Form3Acts.TOTALS) instanceof Collection<?> totals && totals.contains(amount);
    }

    /**
     * Дата подписания документа: последняя подпись штампа ЭДО, иначе (штампа в тексте нет) дата приёмки УПД, иначе дата
     * документа. Штамп в тексте есть, а дата не разобрана — пусто: дата документа штамп не подменяет.
     *
     * @param doc документ реестра
     * @return дата dd.MM.yyyy или пусто
     */
    static String signDate(Map<String, Object> doc) {
        if (!str(doc.get("дата_подписания")).isEmpty() || Boolean.TRUE.equals(doc.get(Form3Acts.STAMP))) {
            return str(doc.get("дата_подписания"));
        }
        return str(doc.get("дата_приёмки")).isEmpty() ? str(doc.get("дата")) : str(doc.get("дата_приёмки"));
    }

    /**
     * Источник даты подписания документа для аудита: «штамп ЭДО 25.03.2025», «штамп ЭДО не разобран», «дата приёмки УПД
     * 24.07.2025, штампа нет», «дата документа 08.04.2025, штампа нет».
     *
     * @param doc документ реестра
     * @return описание источника даты
     */
    static String signSource(Map<String, Object> doc) {
        if (!str(doc.get("дата_подписания")).isEmpty()) {
            return "штамп ЭДО " + str(doc.get("дата_подписания"));
        }
        if (Boolean.TRUE.equals(doc.get(Form3Acts.STAMP))) {
            return "штамп ЭДО не разобран";
        }
        if (!str(doc.get("дата_приёмки")).isEmpty()) {
            return "дата приёмки УПД " + str(doc.get("дата_приёмки")) + ", штампа нет";
        }
        return str(doc.get("дата")).isEmpty() ? "даты подписания нет" : "дата документа " + str(doc.get("дата")) + ", штампа нет";
    }

    /**
     * В тексте документа есть номер договора строки (п. 2 письма: реквизиты договора, однозначно определяющие
     * принадлежность документа). У документа без текста номер ищется в пути к файлу
     * («Договор №32514746233 от 04.06.2025/Акт …»).
     *
     * @param line строка формы
     * @param doc  документ реестра
     * @return {@code true}, если номер найден или в форме договор не указан
     */
    static boolean contractFits(Form3Form.Row line, Map<String, Object> doc) {
        String number = Form3Rows.contractNumber(line.contract());
        return number.isEmpty() || requisites(doc).contains(number);
    }

    /**
     * Дата договора строки есть в тексте найденного документа. Расхождение не отменяет находку (в комплекте
     * МЕТРО акты 2023 года называют договор «от 22.07.2020», форма — «от 22.07.2019»), но помечается в аудите.
     *
     * @param line строка формы
     * @param doc  найденный документ
     * @return {@code true}, если дата совпала или в форме её нет
     */
    static boolean contractDateFits(Form3Form.Row line, Map<String, Object> doc) {
        String date = Form3Form.actDate(line.contract(), "");
        String where = requisites(doc);
        return date.isEmpty() || where.contains(date) || Form3Acts.wordDates(where).contains(date);
    }

    private static String requisites(Map<String, Object> doc) {
        String text = str(doc.get("текст"));
        return Boolean.TRUE.equals(doc.get("без_текста")) || text.isBlank() ? str(doc.get("файл")) : text;
    }

    private static boolean foreignSpec(Form3Form.Row line, Map<String, Object> doc) {
        String rowSpec = Form3Rows.specNumber(line.spec());
        String docSpec = str(doc.get("спецификация"));
        return !rowSpec.isEmpty() && !docSpec.isEmpty() && !rowSpec.equals(docSpec) && !rowSpec.equals(str(doc.get("заявка")));
    }

    /** Документ той же спецификации/заявки, что строка формы. */
    static boolean sameSpec(Form3Form.Row line, Map<String, Object> doc) {
        String rowSpec = Form3Rows.specNumber(line.spec());
        return !rowSpec.isEmpty() && (rowSpec.equals(str(doc.get("спецификация"))) || rowSpec.equals(str(doc.get("заявка"))));
    }

    /**
     * Номер акта/УПД в реквизитах формы без ведущих нулей: «№ 104227011 от …», «УПД 118724 от …», «Акт 12 от …»;
     * «б/н», «б.н.», «б\н», знак номера без цифр («№ от», «№_») и номер заявки/спецификации/договора
     * («по Заявке №10») — пусто (номер акта не указан).
     *
     * @param actText реквизиты акта из формы
     * @return номер или пусто
     */
    static String formNumber(String actText) {
        if (NO_NUMBER.matcher(actText).find()) {
            return "";
        }
        Matcher m = FORM_NUMBER.matcher(actText);
        while (m.find()) {
            if (DIGIT.matcher(m.group(1)).find() && !FOREIGN_SIGN.matcher(actText.substring(0, m.start())).find()) {
                return number(m.group(1));
            }
        }
        Matcher act = ACT_NUMBER.matcher(actText);
        if (act.find()) {
            return number(act.group(1));
        }
        Set<String> upd = Form3Form.numbers(Form3Form.UPD_NUMBER, actText);
        return upd.isEmpty() ? "" : number(upd.iterator().next());
    }

    private static String number(String raw) {
        if (raw.isEmpty() || NO_NUMBER.matcher(raw).find()) {
            return "";
        }
        String stripped = raw.replaceFirst("^0+(?=\\d)", "");
        return stripped.replaceFirst("[.,]$", "");
    }
}
