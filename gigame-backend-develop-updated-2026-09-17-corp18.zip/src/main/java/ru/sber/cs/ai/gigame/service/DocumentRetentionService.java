package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Срок хранения документов-сирот. Файл, загруженный в диалог, попадает в
 * {@code documents} сразу, а в {@code messages.document_ids} — только с
 * отправленным вопросом; если вопрос не отправлен (или кэш документов диалога
 * истёк раньше), текст на десятки мегабайт и его эмбеддинги оставались навсегда.
 * Раз в {@code app.document.orphan-retention-interval-ms} удаляются документы
 * старше {@code app.document.orphan-retention-hours}, не входящие ни в одну базу
 * знаний и не упомянутые ни в одном сообщении, вместе с эмбеддингами коллекции
 * «doc» (явно; внешний ключ embeddings.source_document_id — страховка каскадом).
 * Срок в часах заведомо больше TTL кэша документов диалога (минуты).
 */
@Slf4j
@Service
public class DocumentRetentionService {

    /** Размер пачки удаляемых документов в одной транзакции. */
    static final int BATCH_SIZE = 100;

    /** Предохранитель от бесконечного цикла: максимум пачек за один запуск. */
    static final int MAX_BATCHES = 1000;

    private final DocumentRepository documentRepository;
    private final EmbeddingService embeddingService;
    private final TransactionTemplate transactionTemplate;

    /** Срок хранения сирот в часах; 0 и меньше — чистка выключена. */
    @Value("${app.document.orphan-retention-hours:24}")
    private int retentionHours = 24;

    public DocumentRetentionService(PlatformTransactionManager transactionManager,
                                    DocumentRepository documentRepository,
                                    EmbeddingService embeddingService) {
        this.documentRepository = documentRepository;
        this.embeddingService = embeddingService;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    /**
     * Плановая чистка: через 15 минут после старта и далее раз в час.
     */
    @Scheduled(initialDelayString = "${app.document.orphan-retention-initial-delay-ms:900000}",
            fixedDelayString = "${app.document.orphan-retention-interval-ms:3600000}")
    public void purgeOrphans() {
        try {
            purgeOrphans(OffsetDateTime.now());
        } catch (Exception e) {
            log.warn("Чистка документов-сирот не выполнена: {}", e.getMessage());
        }
    }

    /**
     * Удаляет документы-сироты старше срока хранения относительно указанного момента.
     *
     * @param now текущий момент
     * @return число удалённых документов
     */
    int purgeOrphans(OffsetDateTime now) {
        if (retentionHours <= 0) {
            return 0;
        }
        OffsetDateTime cutoff = now.minusHours(retentionHours);
        int total = 0;
        for (int batches = 0; batches < MAX_BATCHES; batches++) {
            List<UUID> batch = documentRepository.findOrphanIds(cutoff, BATCH_SIZE);
            if (batch.isEmpty()) {
                break;
            }
            transactionTemplate.execute(status -> {
                batch.forEach(embeddingService::deleteDocumentChunks);
                documentRepository.deleteAllByIdInBatch(batch);
                return null;
            });
            total += batch.size();
            if (batch.size() < BATCH_SIZE) {
                break;
            }
        }
        if (total > 0) {
            log.info("Чистка документов-сирот: удалено {} документов старше {} ч (до {})", total, retentionHours, cutoff);
        } else {
            log.info("Чистка документов-сирот: документов старше {} ч без сообщений и баз знаний нет", retentionHours);
        }
        return total;
    }

    void setRetentionHours(int retentionHours) {
        this.retentionHours = retentionHours;
    }
}
