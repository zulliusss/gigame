package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ru.sber.cs.ai.gigame.service.scenario.executor.Form3Ops.str;

/**
 * Исходная Форма 3 участника как таблица: шапка (узел «Шапка исходной формы»)
 * даёт номера колонок, строки (узел «Строки исходной формы») — значения.
 * Объединённые ячейки Excel приходят пустыми во всех строках, кроме первой,
 * поэтому компания, исполнитель, заказчик, договор и спецификация наследуются сверху.
 * <p>
 * Форма — первичный список строк заключения: строка оценивается по данным
 * формы (заказчик → рейтинг, дата акта → периоды), а документы комплекта
 * подтверждают её; если документов нет, строка всё равно получает вердикт
 * и причину, а не пропадает.
 */
final class Form3Form {

    static final Pattern SIMPLE_DATE = Pattern.compile("(?<!\\d)(\\d{2}\\.\\d{2}\\.\\d{4})(?!\\d)");
    static final Pattern ISO_DATE = Pattern.compile("(?<!\\d)(\\d{4})-(\\d{2})-(\\d{2})(?!\\d)");
    /** Номер УПД в форме: «УПД № 0000118724 от …» либо «УПД от 23.12.2025 №970». */
    static final Pattern UPD_NUMBER = Pattern.compile(
            "УПД\\s*(?:от\\s*(?:от\\s*)?\\d{2}\\.\\d{2}\\.\\d{2,4}\\s*)?(?:№\\s*0*(\\d{1,12})|0*(\\d{3,12}))(?!\\d)");
    /** Разряды через запятую, копейки через точку: «3,400,940.77». */
    private static final Pattern GROUPED_COMMA = Pattern.compile("\\d{1,3}(?:,\\d{3})+(?:\\.\\d{1,2})?");
    /** Разряды через точку, копейки через запятую: «1.234.567,89». */
    private static final Pattern GROUPED_DOT = Pattern.compile("\\d{1,3}(?:\\.\\d{3})+(?:,\\d{1,2})?");
    private static final String TECH_COLUMN = "в рамках выполнения работ";
    private static final int INHERITED = 5;

    /**
     * Строка формы с разобранными полями.
     *
     * @param line         исходная строка (ячейки через «|»)
     * @param company      участник
     * @param executor     исполнитель по договору
     * @param customer     заказчик по договору
     * @param contract     реквизиты договора
     * @param spec         реквизиты спецификации/заказа
     * @param act          реквизиты акта/УПД
     * @param actDate      дата подписания акта (dd.MM.yyyy) или пусто
     * @param dates        все даты строки (колонка даты и реквизиты акта)
     * @param amount       сумма по акту «1234567.89» или пусто
     * @param claimedTechs заголовки колонок технологий, где участник поставил «да»
     * @param techHeaders  заголовки всех колонок технологий формы (пусто — таких колонок нет)
     * @param signDate     дата только из графы «Дата подписания» (dd.MM.yyyy), без подстановки даты из реквизитов акта,
     *                     или пусто — признак «дата подписания» правил идентификации акта
     */
    record Row(String line, String company, String executor, String customer, String contract, String spec, String act,
               String actDate, Set<String> dates, String amount, List<String> claimedTechs, List<String> techHeaders,
               String signDate) {
    }

    private final int company;
    private final int executor;
    private final int customer;
    private final int contract;
    private final int spec;
    private final int act;
    private final int date;
    private final int amount;
    private final List<Integer> techColumns = new ArrayList<>();
    private final List<String> techNames = new ArrayList<>();

    private Form3Form(List<String> header) {
        company = find(header, "наименование компании", "исполни", "заказчик");
        executor = find(header, "исполни", null, null);
        customer = find(header, "заказчик", null, null);
        contract = find(header, "реквизиты договора", "генеральн", null);
        spec = find(header, "спецификаци", "реквизиты акта", null);
        act = find(header, "реквизиты акта", null, null);
        date = find(header, "дата подписания", null, null);
        amount = find(header, "сумма выполненных", null, null);
        for (int i = 0; i < header.size(); i++) {
            if (header.get(i).toLowerCase(Locale.ROOT).startsWith(TECH_COLUMN)) {
                techColumns.add(i);
                techNames.add(header.get(i));
            }
        }
    }

    /**
     * Разбор шапки формы.
     *
     * @param headerLine строка-шапка (ячейки через «|»)
     * @return форма или {@code null}, если шапки нет или в ней нет колонки реквизитов акта
     */
    static Form3Form parse(String headerLine) {
        if (headerLine == null || headerLine.isBlank()) {
            return null;
        }
        Form3Form form = new Form3Form(cells(headerLine));
        return form.act < 0 ? null : form;
    }

    /**
     * Строки формы в порядке следования; строки без реквизитов акта пропускаются,
     * пустые ячейки объединённых колонок наследуются от строки выше.
     *
     * @param lines строки формы (ячейки через «|»)
     * @return разобранные строки
     */
    List<Row> rows(String lines) {
        List<Row> out = new ArrayList<>();
        String[] carry = new String[INHERITED];
        for (String line : (lines == null ? "" : lines).split("\n")) {
            if (line.isBlank()) {
                continue;
            }
            List<String> c = cells(line);
            String[] inherited = {cell(c, company), cell(c, executor), cell(c, customer), cell(c, contract), cell(c, spec)};
            for (int i = 0; i < inherited.length; i++) {
                if (inherited[i].isEmpty() || "none".equalsIgnoreCase(inherited[i])) {
                    inherited[i] = carry[i] == null ? "" : carry[i];
                } else {
                    carry[i] = inherited[i];
                }
            }
            String actText = cell(c, act);
            if (actText.isEmpty()) {
                continue;
            }
            Set<String> dates = dates(cell(c, date) + " " + actText);
            out.add(new Row(line.strip(), inherited[0], inherited[1], inherited[2], inherited[3], inherited[4], actText,
                    actDate(cell(c, date), actText), dates, amount(cell(c, amount)), claimed(c), List.copyOf(techNames),
                    actDate(cell(c, date), "")));
        }
        return out;
    }

    private List<String> claimed(List<String> c) {
        List<String> claimed = new ArrayList<>();
        for (int i = 0; i < techColumns.size(); i++) {
            if (cell(c, techColumns.get(i)).toLowerCase(Locale.ROOT).startsWith("да")) {
                claimed.add(techNames.get(i));
            }
        }
        return claimed;
    }

    /**
     * Дата акта: из колонки даты (dd.MM.yyyy, ISO-дата Excel либо словами «28 июня 2024»),
     * иначе последняя дата в реквизитах акта.
     *
     * @param dateCell ячейка даты
     * @param actText  реквизиты акта
     * @return дата dd.MM.yyyy или пусто
     */
    static String actDate(String dateCell, String actText) {
        Matcher m = SIMPLE_DATE.matcher(dateCell);
        if (m.find()) {
            return m.group(1);
        }
        Matcher iso = ISO_DATE.matcher(dateCell);
        if (iso.find()) {
            return iso.group(3) + "." + iso.group(2) + "." + iso.group(1);
        }
        List<String> words = Form3Acts.wordDates(dateCell);
        if (!words.isEmpty()) {
            return words.get(0);
        }
        String last = "";
        Matcher inAct = SIMPLE_DATE.matcher(actText);
        while (inAct.find()) {
            last = inAct.group(1);
        }
        return last;
    }

    /** Все даты dd.MM.yyyy текста (ISO-даты Excel приводятся к тому же виду). */
    static Set<String> dates(String text) {
        Set<String> out = new LinkedHashSet<>();
        Matcher iso = ISO_DATE.matcher(text);
        while (iso.find()) {
            out.add(iso.group(3) + "." + iso.group(2) + "." + iso.group(1));
        }
        Matcher m = SIMPLE_DATE.matcher(text);
        while (m.find()) {
            out.add(m.group(1));
        }
        out.addAll(Form3Acts.wordDates(text));
        return out;
    }

    /**
     * Сумма формы в виде реестра: «1 234 567,89» / «1234567.89» / «2495000» → «…89» / «2495000.00»;
     * числовая ячейка Excel с маской «#,##0.00» приходит как «3,400,940.77» (запятая — разделитель разрядов),
     * европейская запись — «1.234.567,89»; неразрывный и узкий пробелы — как обычный.
     *
     * @param cell ячейка суммы
     * @return сумма с двумя знаками или пусто
     */
    static String amount(String cell) {
        String spaced = Form3Ops.normalize(cell).replace(' ', ' ');
        Matcher m = Form3Ops.AMOUNT.matcher(spaced);
        if (m.find()) {
            return m.group(1).replace(" ", "") + "." + m.group(2);
        }
        String plain = spaced.replace(" ", "");
        if (GROUPED_COMMA.matcher(plain).matches()) {
            plain = plain.replace(",", "");
        } else if (GROUPED_DOT.matcher(plain).matches()) {
            plain = plain.replace(".", "").replace(",", ".");
        } else {
            plain = plain.replace(",", ".");
        }
        if (plain.matches("\\d+")) {
            return plain + ".00";
        }
        if (plain.matches("\\d+\\.\\d")) {
            return plain + "0";
        }
        return plain.matches("\\d+\\.\\d{2}") ? plain : "";
    }

    /** Номера УПД и спецификаций из текста (первая непустая группа шаблона). */
    static Set<String> numbers(Pattern pattern, String text) {
        Set<String> out = new LinkedHashSet<>();
        Matcher m = pattern.matcher(text);
        while (m.find()) {
            for (int g = 1; g <= m.groupCount(); g++) {
                if (m.group(g) != null) {
                    out.add(m.group(g));
                    break;
                }
            }
        }
        return out;
    }

    static List<String> cells(String line) {
        List<String> out = new ArrayList<>();
        for (String part : line.split("\\|", -1)) {
            out.add(part.strip());
        }
        return out;
    }

    private static String cell(List<String> cells, int index) {
        return index < 0 || index >= cells.size() ? "" : str(cells.get(index));
    }

    /** Индекс первой колонки, чей заголовок содержит {@code needle} и не содержит исключений. */
    private static int find(List<String> header, String needle, String excludeA, String excludeB) {
        for (int i = 0; i < header.size(); i++) {
            String h = header.get(i).toLowerCase(Locale.ROOT);
            boolean excluded = excludeA != null && h.contains(excludeA) || excludeB != null && h.contains(excludeB);
            if (h.contains(needle) && !excluded) {
                return i;
            }
        }
        return -1;
    }
}
