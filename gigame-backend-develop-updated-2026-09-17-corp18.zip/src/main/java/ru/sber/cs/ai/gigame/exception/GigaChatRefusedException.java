package ru.sber.cs.ai.gigame.exception;

import java.util.regex.Pattern;

/**
 * Модель отказалась обрабатывать запрос узла сценария (отказ цензора GigaChat: «разговоры на некоторые темы
 * временно ограничены» и т. п.; finish_reason=blacklist) и после деления документа. Текст ошибки цитирует
 * начало отказа; узел завершается ошибкой (FAILED), а не успехом с текстом отказа вместо результата.
 */
public class GigaChatRefusedException extends GigaChatException {

    /** Предел длины цитаты отказа в тексте ошибки, знаков. */
    public static final int QUOTE_LIMIT = 160;
    private static final Pattern SPACES = Pattern.compile("\\s+");

    private final String refusal;

    /**
     * Исключение с цитатой отказа в тексте.
     *
     * @param refusal текст отказа модели
     */
    public GigaChatRefusedException(String refusal) {
        super(message(refusal));
        this.refusal = refusal;
    }

    /**
     * Текст отказа модели целиком.
     *
     * @return ответ модели, распознанный как отказ
     */
    public String getRefusal() {
        return refusal;
    }

    /**
     * Текст ошибки узла с цитатой начала отказа.
     *
     * @param refusal текст отказа модели
     * @return «Модель отказалась обрабатывать запрос (ограничение темы GigaChat): «…» — измените формулировку
     *         или сократите документ»
     */
    public static String message(String refusal) {
        return "Модель отказалась обрабатывать запрос (ограничение темы GigaChat): «" + quote(refusal)
                + "» — измените формулировку или сократите документ";
    }

    /** Первые {@link #QUOTE_LIMIT} знаков отказа одной строкой (обрезанная цитата — с многоточием). */
    private static String quote(String refusal) {
        String line = SPACES.matcher(refusal == null ? "" : refusal).replaceAll(" ").strip();
        return line.length() <= QUOTE_LIMIT ? line : line.substring(0, QUOTE_LIMIT) + "…";
    }
}
