package ru.sber.cs.ai.gigame.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.exception.GigaChatRefusedException;
import ru.sber.cs.ai.gigame.exception.GigaFilterBlockedException;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Распознавание PDF-сканов через файловое хранилище GigaChat.
 * <p>
 * PDF без текстового слоя загружается в хранилище GigaChat вложением к запросу
 * «выпиши содержимое» — модель распознаёт скан и возвращает текст, который
 * дальше идёт по обычному конвейеру сценария (группировка, проверки, суммы).
 * Файл после распознавания удаляется из хранилища.
 * <p>
 * Многостраничный скан распознаётся постранично ({@code app.document.ocr-per-page},
 * по умолчанию включено): на весь документ модель отвечает пересказом
 * (шестистраничная заявка — 2,5 тыс. знаков, состав работ потерян), а на
 * одну страницу — переписывает её полностью (8,4 тыс. знаков на тот же
 * документ). Страницы с текстовым слоем (штамп ЭДО) не распознаются, а
 * берутся как есть, пустые страницы пропускаются; в GigaChat уходит не больше
 * {@code app.document.ocr-max-pages} страниц-изображений, остальные изображения
 * помечаются нераспознанными. Многостраничный документ, распознанный целиком
 * (постраничный режим выключен или PDF не разбирается PDFBox), помечается
 * отдельным префиксом {@link #OCR_WHOLE_PREFIX} — это пересказ.
 * <p>
 * Отказ модели («предоставьте документ», короткий комментарий «из предоставленного фрагмента
 * невозможно выписать…») не принимается за текст: запрос повторяется нейтральным запасным
 * промптом, после второго отказа страница получает маркер {@link #PAGE_REFUSED_MARKER},
 * документ целиком — маркер ручной проверки {@link #DOC_REFUSED_PREFIX}.
 * <p>
 * Выключено по умолчанию: {@code app.document.ocr-via-gigachat=true}
 * (env {@code OCR_VIA_GIGACHAT}) включает. Результат помечается префиксом
 * {@link #OCR_PREFIX} — суммы из скана в итоговой форме стоит перепроверять.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ScanOcrService {

    /** Префикс распознанного текста — виден конвейеру и в итоговой форме. */
    public static final String OCR_PREFIX = "[РАСПОЗНАНО ИЗ СКАНА — данные извлечены "
            + "автоматическим распознаванием, суммы рекомендуется перепроверить]";

    /** Префикс многостраничного скана, распознанного целиком: модель пересказывает, строки таблиц могут быть потеряны. */
    public static final String OCR_WHOLE_PREFIX = "[РАСПОЗНАНО ИЗ СКАНА ЦЕЛИКОМ — пересказ модели, "
            + "строки таблиц и суммы могли быть потеряны, документ рекомендуется проверить вручную]";

    /** Начало маркера документа, который модель отказалась распознавать. */
    public static final String DOC_REFUSED_PREFIX = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «";

    /** Маркер страницы, распознать которую модель отказалась (номер страницы — в тексте). */
    static final String PAGE_REFUSED_MARKER = "не распознана: отказ модели]";

    /** Маркер обрыва ответа модели по лимиту токенов (ставит {@link GigaChatClient#chatCompletionWithFile}). */
    static final String TRUNCATED_MARKER = GigaChatClient.TRUNCATED_MARKER;

    /**
     * Ответ вместо текста, когда запрос распознавания отклонён цензором GigaChat (finish_reason=blacklist) либо
     * фильтром GigaFilter: распознаётся как отказ ({@link #isRefusal}), но без повтора запасным промптом — отказ
     * по содержимому повтором другой формулировки не снимается, повтор только тратил бы вызов.
     */
    static final String BLOCKED_REFUSAL = "не могу выполнить: распознавание отклонено (ограничение темы GigaChat "
            + "либо фильтр GigaFilter)";

    /**
     * Формулировка «выпиши содержимое» вместо «перепиши дословно текст вложения»:
     * на просьбу дословной переписки вложения GigaChat отвечает шаблонным отказом,
     * хотя файл обработан и находится в контексте (проверено экспериментально).
     */
    private static final String OCR_PROMPT = """
            Это отсканированный финансовый документ. Выпиши максимально полно его \
            содержимое в текстовом виде: тип и реквизиты документа (номера, даты), \
            стороны (исполнитель, заказчик, ИНН), основание (договор, спецификация), \
            таблицу работ построчно (колонки через « | »), все суммы, включая ИТОГО \
            с НДС. Нечитаемые фрагменты помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя.""";

    /** Постраничный запрос: одна страница переписывается полностью, без пересказа. */
    private static final String PAGE_PROMPT = """
            Это страница отсканированного финансового документа. Выпиши максимально полно \
            и дословно весь текст страницы: заголовки, реквизиты (номера, даты), стороны, \
            таблицы построчно (колонки через « | »), все суммы. Нечитаемые фрагменты \
            помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя и не сокращай.""";

    /**
     * Запасной запрос после отказа модели — без слова «финансовый»: на нефинансовой странице (декларация о стране
     * происхождения АЗК, пустая форма таблицы в приложении договора) первые промпты давали комментарий «невозможно
     * выписать информацию о финансовом документе» вместо текста. Глагол «выпиши», а не «перепиши»: на просьбу
     * переписать вложение дословно GigaChat отвечает шаблонным отказом.
     */
    private static final String FALLBACK_PROMPT = """
            Это отсканированная страница документа. Выпиши дословно весь текст страницы: \
            заголовки, реквизиты, таблицы построчно (колонки через « | »), подписи. Нечитаемые \
            фрагменты помечай [НЕЧИТАЕМО]. Ничего не добавляй от себя, не сокращай и не комментируй.""";

    /**
     * Отказ модели переписать страницу — повтор с нейтральным запасным промптом {@link #FALLBACK_PROMPT}.
     * Просьба приложить текст или файл считается отказом только как обращение к пользователю
     * («Пожалуйста, приложите текст или файл», «приложи файл, который нужно обработать»): указание
     * документа «Приложите к заявке копию лицензии» в начале распознанного текста отказом не является.
     */
    private static final Pattern REFUSAL = Pattern.compile(
            "невозможно сформировать|Из предоставленного контекста|предоставьте полн|не могу выполнить|не содержит текст"
                    + "|не является отсканированным|нет (?:текста|самой) страницы|нет прикрепл[её]нного|нет доступа к содержимому"
                    + "|приложи(?:те)? (?:саму|сам|страницу|документ)|предоставь(?:те)? (?:страницу|текстовую версию)"
                    + "|не могу помочь"
                    + "|(?:пожалуйста,?\\s+приложи(?:те)?|приложи(?:те)?,?\\s+пожалуйста,?)\\s+(?:[^\\s.,]+\\s+)?(?:текст|файл)"
                    + "|приложи(?:те)?\\s+(?:текст|файл)[^.\\n]{0,60}?(?:нужно|необходимо|надо)\\s+(?:обработать|распознать|переписать)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Комментарий модели вместо текста нефинансовой страницы («Из предоставленного фрагмента текста невозможно выписать
     * запрашиваемую информацию о финансовом документе…», «Из предоставленного фрагмента таблицы невозможно однозначно
     * определить содержание финансового документа…»; в сканах Комплекта 5 — «Из предоставленного тобой текста невозможно
     * извлечь…», «Из предоставленного отрывка текста невозможно полностью воспроизвести всю страницу…»). Считается
     * отказом только в коротком ответе ({@link #SHORT_REFUSAL_MAX_CHARS}): распознанный документ с такой оговоркой длиннее.
     */
    private static final Pattern SHORT_REFUSAL = Pattern.compile(
            "из\\s+предоставленного\\s+(?:тобой\\s+)?(?:фрагмента|текста|отрывка|описания)"
                    + "|невозможно\\s+(?:выписать|извлечь|однозначно\\s+определить|полностью\\s+(?:восстановить|воспроизвести))",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Длина ответа, начиная с которой фразы {@link #SHORT_REFUSAL} отказом не считаются: комментарии модели — 250–400 знаков. */
    private static final int SHORT_REFUSAL_MAX_CHARS = 900;
    /** Доля букв среди непробельных знаков текстового слоя, ниже которой страница считается нечитаемой (штамп ЭДО без ToUnicode). */
    private static final double LETTER_SHARE_MIN = 0.5;
    /** Нечитаемый слой короткий: страница штампа — сотни знаков, страница текста — тысячи. */
    private static final int GARBLED_MAX_CHARS = 3000;
    /** Маркер нераспознанной страницы: «[страница N не распознана: отказ модели]». */
    private static final Pattern PAGE_REFUSED = Pattern.compile("\\[страница (\\d+) " + Pattern.quote(PAGE_REFUSED_MARKER));
    /** Страница, распознанная моделью: «--- страница N ---» без маркера «[страница N не распознана…]» следом. */
    private static final Pattern PAGE_RECOGNIZED = Pattern.compile("--- страница (\\d+) ---\\n(?!\\[страница \\1 не распознана)");
    private static final int REFUSAL_WINDOW = 400;
    private static final double OCR_TEMPERATURE = 0.01;
    private static final String PDF = "application/pdf";

    private final GigaChatClient gigaChatClient;

    @Value("${app.document.ocr-via-gigachat:true}")
    private boolean enabled;

    /** Модель для распознавания (пусто — глобальная модель по умолчанию). */
    @Value("${app.document.ocr-model:}")
    private String ocrModel;

    /** Лимит токенов ответа — страница либо документ целиком. */
    @Value("${app.document.ocr-max-tokens:8000}")
    private int ocrMaxTokens = 8000;

    /** Постраничное распознавание многостраничных сканов. */
    @Value("${app.document.ocr-per-page:true}")
    private boolean ocrPerPage = true;

    /** Максимум распознаваемых страниц одного документа. */
    @Value("${app.document.ocr-max-pages:40}")
    private int ocrMaxPages = 40;

    /** Порог текстового слоя страницы: короче — страница-картинка, распознаётся. */
    @Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars = 40;

    /**
     * Одновременных запросов распознавания к GigaChat. Пул разбора документов —
     * 4 потока, и четыре параллельных OCR упирались в лимит запросов корп-ключа
     * (429 с паузами 30–300 с: 16 сканов Комплекта 4 шли 31 минуту вместо ~10).
     */
    @Value("${app.document.ocr-parallelism:1}")
    private int ocrParallelism = 1;

    private Semaphore ocrSlots;

    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Распознаёт PDF-скан через GigaChat: постранично для многостраничного
     * документа, целиком для одностраничного.
     *
     * @param filename имя файла (для хранилища и префикса)
     * @param content  содержимое PDF
     * @return распознанный текст с префиксом {@link #OCR_PREFIX} (либо
     *         {@link #OCR_WHOLE_PREFIX} для многостраничного документа, распознанного целиком;
     *         маркер {@link #DOC_REFUSED_PREFIX} при отказе модели)
     */
    public String recognize(String filename, byte[] content) {
        log.info("OCR скана через GigaChat: {} ({} КБ)", filename, content.length / 1024);
        int total = pageCount(content);
        List<String> pages = ocrPerPage && total > 1 ? recognizePages(filename, content) : List.of();
        if (!pages.isEmpty()) {
            return OCR_PREFIX + " Документ «" + filename + "»:\n" + String.join("\n\n", pages);
        }
        String text = ask(OCR_PROMPT, filename, content);
        if (isRefusal(text) && !BLOCKED_REFUSAL.equals(text)) {
            // одностраничный документ: отказ модели повторяется запасным промптом, как и страница
            log.info("OCR «{}»: отказ модели на документе целиком, повтор с запасным промптом", filename);
            text = ask(FALLBACK_PROMPT, filename, content);
        }
        if (isRefusal(text)) {
            log.warn("OCR «{}»: модель отказалась распознавать документ и после запасного промпта", filename);
            return DOC_REFUSED_PREFIX + filename + "» не распознан: модель отказалась распознавать скан. "
                    + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
        }
        String head = (total == 1 ? OCR_PREFIX : OCR_WHOLE_PREFIX) + " Документ «" + filename + "»:\n";
        return head + text;
    }

    /** Число страниц PDF; -1, если PDFBox не разбирает файл. */
    private static int pageCount(byte[] content) {
        try (PDDocument doc = Loader.loadPDF(content)) {
            return doc.getNumberOfPages();
        } catch (IOException e) {
            return -1;
        }
    }

    /**
     * Постраничное распознавание: страницы с текстовым слоем берутся как есть
     * всегда, в том числе за лимитом {@code app.document.ocr-max-pages}; по одной
     * распознаются только страницы-изображения ({@link DocumentService#isImagePage})
     * и страницы с нечитаемым слоем, пустые страницы в GigaChat не отправляются.
     * Лимит ограничивает число страниц, отправленных в GigaChat: не распознанные
     * из-за него страницы-изображения перечисляются в маркере. Сбой одной страницы
     * не роняет документ.
     *
     * @return тексты страниц с маркерами «--- страница N ---»; пусто, если документ
     *         не разбирается PDFBox либо в нём нет ни текста, ни изображений
     *         (тогда — распознавание целиком)
     */
    private List<String> recognizePages(String filename, byte[] content) {
        List<String> parts = new ArrayList<>();
        List<Integer> overLimit = new ArrayList<>();
        int sent = 0;
        try (PDDocument doc = Loader.loadPDF(content)) {
            int total = doc.getNumberOfPages();
            PDFTextStripper stripper = new PDFTextStripper();
            for (int page = 1; page <= total; page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);
                String layer = stripper.getText(doc).strip();
                if (!needsOcr(doc.getPage(page - 1), layer)) {
                    addTextLayer(parts, page, layer);
                } else if (sent < ocrMaxPages) {
                    sent++;
                    parts.add("--- страница " + page + " ---\n" + recognizePage(filename, doc, page));
                } else {
                    overLimit.add(page);
                }
            }
            if (!overLimit.isEmpty()) {
                parts.add("[страницы " + pageRanges(overLimit) + " не распознаны: превышен лимит страниц OCR "
                        + ocrMaxPages + "]");
            }
            log.info("OCR «{}»: страниц {}, распознано постранично {}", filename, total, sent);
        } catch (IOException e) {
            log.warn("OCR «{}»: PDF не разбирается постранично ({}) — распознаётся целиком", filename, e.getMessage());
            return List.of();
        }
        return parts;
    }

    /**
     * Страница уходит в GigaChat: изображение без текстового слоя либо нечитаемый
     * слой (штамп ЭДО без ToUnicode). Пустая страница не распознаётся.
     *
     * @param page  страница PDF
     * @param layer текстовый слой страницы без краевых пробелов
     * @return {@code true}, если страницу нужно распознавать
     */
    private boolean needsOcr(PDPage page, String layer) {
        return layer.length() >= minParsedChars
                ? looksGarbled(layer)
                : DocumentService.isImagePage(page, layer, minParsedChars);
    }

    /** Страница с текстовым слоем как есть; пустая страница пропускается. */
    private static void addTextLayer(List<String> parts, int page, String layer) {
        if (!layer.isEmpty()) {
            parts.add("--- страница " + page + " (текстовый слой) ---\n" + layer);
        }
    }

    /**
     * Номера страниц диапазонами: [41, 42, 43, 50] → «41–43, 50».
     *
     * @param pages номера страниц по возрастанию
     * @return перечень номеров и диапазонов через запятую
     */
    static String pageRanges(List<Integer> pages) {
        List<String> ranges = new ArrayList<>();
        int start = 0;
        for (int i = 1; i <= pages.size(); i++) {
            if (i == pages.size() || pages.get(i) != pages.get(i - 1) + 1) {
                ranges.add(start == i - 1 ? String.valueOf(pages.get(start)) : pages.get(start) + "–" + pages.get(i - 1));
                start = i;
            }
        }
        return String.join(", ", ranges);
    }

    private String recognizePage(String filename, PDDocument doc, int page) {
        try (PDDocument single = new PDDocument()) {
            single.importPage(doc.getPage(page - 1));
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            single.save(out);
            String text = ask(PAGE_PROMPT, "page-" + page + ".pdf", out.toByteArray());
            if (isRefusal(text) && !BLOCKED_REFUSAL.equals(text)) {
                log.info("OCR «{}»: страница {} — отказ модели, повтор с запасным промптом", filename, page);
                text = ask(FALLBACK_PROMPT, "page-" + page + ".pdf", out.toByteArray());
            }
            if (isRefusal(text)) {
                log.warn("OCR «{}»: страница {} — отказ модели и после запасного промпта", filename, page);
                return "[страница " + page + " " + PAGE_REFUSED_MARKER;
            }
            return text;
        } catch (IOException e) {
            log.warn("OCR «{}»: страница {} не выделена ({})", filename, page, e.getMessage());
            return "[страница " + page + " не распознана: " + e.getMessage() + "]";
        }
    }

    /**
     * Текстовый слой страницы нечитаем: штамп оператора ЭДО в актах МЕТРО свёрстан шрифтом без таблицы
     * ToUnicode и извлекается как «X c X " +" - 469 -» — букв меньше половины знаков. Такая страница
     * распознаётся моделью, как страница без слоя, иначе дата и подпись заказчика из штампа теряются.
     *
     * @param layer текстовый слой страницы
     * @return {@code true}, если слой короткий и в нём меньше половины букв
     */
    static boolean looksGarbled(String layer) {
        if (layer.length() > GARBLED_MAX_CHARS) {
            return false;
        }
        int total = 0;
        int letters = 0;
        for (int i = 0; i < layer.length(); i++) {
            char c = layer.charAt(i);
            if (Character.isWhitespace(c)) {
                continue;
            }
            total++;
            if (Character.isLetter(c)) {
                letters++;
            }
        }
        return total > 0 && letters < total * LETTER_SHARE_MIN;
    }

    /**
     * Отказ модели в начале ответа: вместо текста — просьба предоставить документ либо, в коротком ответе,
     * комментарий «из предоставленного фрагмента невозможно выписать…» ({@link #SHORT_REFUSAL}).
     *
     * @param text ответ модели
     * @return {@code true}, если ответ — отказ, а не распознанный текст
     */
    static boolean isRefusal(String text) {
        String head = text == null ? "" : text.substring(0, Math.min(text.length(), REFUSAL_WINDOW));
        return REFUSAL.matcher(head).find()
                || text != null && text.strip().length() < SHORT_REFUSAL_MAX_CHARS && SHORT_REFUSAL.matcher(head).find();
    }

    /**
     * Текст предупреждения загрузки по результату распознавания: отказ модели,
     * распознавание целиком (пересказ), нераспознанные страницы, обрыв ответа
     * либо обычное «распознан — проверьте суммы». У смешанного PDF, где моделью
     * распознаны отдельные страницы, вместо «PDF-скан распознан» перечисляются
     * эти страницы: документ машиночитаемый, перепроверять нужно только их.
     *
     * @param recognized результат {@link #recognize(String, byte[])}
     * @param mixed      документ — смешанный PDF (текстовый слой есть, часть страниц — изображения)
     * @return текст для upload_warning
     */
    public static String uploadWarning(String recognized, boolean mixed) {
        if (recognized.startsWith(DOC_REFUSED_PREFIX)) {
            return "PDF-скан не распознан: модель отказалась распознавать документ — требуется ручная проверка";
        }
        List<String> notes = new ArrayList<>();
        if (recognized.startsWith(OCR_WHOLE_PREFIX)) {
            notes.add("многостраничный скан распознан целиком (пересказ) — строки таблиц могли быть потеряны");
        }
        List<String> refused = new ArrayList<>();
        Matcher m = PAGE_REFUSED.matcher(recognized);
        while (m.find()) {
            refused.add(m.group(1));
        }
        if (!refused.isEmpty()) {
            notes.add("страницы " + String.join(", ", refused) + " не распознаны: отказ модели");
        }
        if (recognized.contains(TRUNCATED_MARKER)) {
            notes.add("ответ модели оборван по лимиту длины — часть текста не распознана");
        }
        List<Integer> pages = mixed ? recognizedPages(recognized) : List.of();
        String base = pages.isEmpty()
                ? "PDF-скан распознан через GigaChat — проверьте суммы"
                : "распознаны через GigaChat страницы " + pageRanges(pages) + " — проверьте суммы";
        return notes.isEmpty() ? base : base + "; " + String.join("; ", notes);
    }

    /**
     * Номера страниц, распознанных моделью постранично: заголовок «--- страница N ---»
     * без пометки текстового слоя и без маркера нераспознанной страницы.
     *
     * @param recognized результат {@link #recognize(String, byte[])}
     * @return номера страниц по возрастанию
     */
    private static List<Integer> recognizedPages(String recognized) {
        List<Integer> pages = new ArrayList<>();
        Matcher m = PAGE_RECOGNIZED.matcher(recognized);
        while (m.find()) {
            pages.add(Integer.parseInt(m.group(1)));
        }
        return pages;
    }

    /**
     * Запрос к GigaChat под ограничителем одновременных распознаваний; отказ цензора и блокировка фильтром GigaFilter —
     * {@link #BLOCKED_REFUSAL} (отказ без повтора запасным промптом).
     */
    private String ask(String prompt, String filename, byte[] content) {
        Semaphore slots = slots();
        slots.acquireUninterruptibly();
        try {
            var result = gigaChatClient.chatCompletionWithFile(prompt, filename, content, PDF,
                    ocrModel == null || ocrModel.isBlank() ? null : ocrModel, OCR_TEMPERATURE, ocrMaxTokens);
            return result.text();
        } catch (GigaChatRefusedException | GigaFilterBlockedException e) {
            log.warn("OCR «{}»: {}", filename, e.getMessage());
            return BLOCKED_REFUSAL;
        } finally {
            slots.release();
        }
    }

    /** Ограничитель создаётся лениво: поле {@code ocrParallelism} заполняется после конструктора. */
    private synchronized Semaphore slots() {
        if (ocrSlots == null) {
            ocrSlots = new Semaphore(Math.max(1, ocrParallelism));
        }
        return ocrSlots;
    }
}
