package ru.sber.cs.ai.gigame.service;

import java.util.ArrayList;
import java.util.List;

/**
 * Деление текста на фрагменты для проверки фильтром GigaFilter с границами, заданными содержимым.
 * <p>
 * Разрез ставится после строки, когда во фрагменте накоплено не меньше половины размера и строка пустая (граница
 * абзаца) либо хэш строки кратен {@link #DIVISOR}; строка, не влезающая в остаток фрагмента, начинает новый
 * фрагмент; строка длиннее фрагмента режется по пробелу; начало документа («&lt;&lt;&lt;Документ:») или страницы OCR
 * начинает новый фрагмент — заблокированный фрагмент не захватывает соседний документ. Границы зависят от текста, а не от его смещения: один и тот
 * же документ после разных инструкций (циклы Формы 3, несколько узлов) делится на те же фрагменты — вердикты
 * берутся из кэша, фильтр не вызывается повторно.
 */
final class GigaFilterChunker {

    /** Делитель хэша строки для «естественного» разреза: в среднем разрез через 8 строк после половины размера. */
    static final int DIVISOR = 8;
    /** Нижний предел размера фрагмента, знаков (защита от нулевой настройки). */
    static final int MIN_SIZE = 200;
    /** Перед началом документа или страницы разрез ставится, если накоплено не меньше 1/8 размера фрагмента. */
    static final int ANCHOR_DIVISOR = 8;
    /** Начала документа группы и страницы OCR: заблокированный фрагмент не захватывает соседний документ. */
    private static final List<String> ANCHORS = List.of("<<<Документ:", "--- страница");

    private GigaFilterChunker() {
    }

    /**
     * Фрагмент текста.
     *
     * @param start смещение начала в исходном тексте
     * @param text  текст фрагмента
     */
    record Chunk(int start, String text) {

        /**
         * Смещение конца (не включительно).
         *
         * @return start + длина текста
         */
        int end() {
            return start + text.length();
        }
    }

    /**
     * Делит текст на фрагменты не длиннее {@code size}; склейка фрагментов даёт исходный текст.
     *
     * @param text текст ({@code null} — пусто)
     * @param size размер фрагмента, знаков (меньше {@link #MIN_SIZE} — {@link #MIN_SIZE})
     * @return фрагменты по порядку
     */
    static List<Chunk> chunks(String text, int size) {
        List<Chunk> out = new ArrayList<>();
        if (text == null || text.isEmpty()) {
            return out;
        }
        int limit = Math.max(MIN_SIZE, size);
        int start = 0;
        int pos = 0;
        while (pos < text.length()) {
            int lineEnd = lineEnd(text, pos);
            if (pos - start >= limit / ANCHOR_DIVISOR && startsAnchor(text, pos)) {
                out.add(new Chunk(start, text.substring(start, pos)));
                start = pos;
            } else if (lineEnd - start > limit && pos > start) {
                out.add(new Chunk(start, text.substring(start, pos)));
                start = pos;
            } else if (lineEnd - start > limit) {
                pos = hardCut(text, start, limit);
                out.add(new Chunk(start, text.substring(start, pos)));
                start = pos;
            } else {
                String line = text.substring(pos, lineEnd);
                pos = lineEnd;
                if (pos - start >= limit / 2 && naturalCut(line)) {
                    out.add(new Chunk(start, text.substring(start, pos)));
                    start = pos;
                }
            }
        }
        if (start < text.length()) {
            out.add(new Chunk(start, text.substring(start)));
        }
        return out;
    }

    /** Конец строки, начинающейся в pos (после перевода строки), либо конец текста. */
    private static int lineEnd(String text, int pos) {
        int eol = text.indexOf('\n', pos);
        return eol < 0 ? text.length() : eol + 1;
    }

    /** Строка в позиции pos начинает документ или страницу. */
    private static boolean startsAnchor(String text, int pos) {
        for (String anchor : ANCHORS) {
            if (text.startsWith(anchor, pos)) {
                return true;
            }
        }
        return false;
    }

    /** Разрез после строки: пустая строка (граница абзаца) либо хэш строки кратен {@link #DIVISOR}. */
    private static boolean naturalCut(String line) {
        return line.isBlank() || Math.floorMod(line.hashCode(), DIVISOR) == 0;
    }

    /** Разрез слишком длинной строки: последний пробел во второй половине окна, иначе ровно по размеру. */
    private static int hardCut(String text, int start, int limit) {
        int end = start + limit;
        int space = text.lastIndexOf(' ', end - 1);
        return space > start + limit / 2 ? space + 1 : end;
    }
}
