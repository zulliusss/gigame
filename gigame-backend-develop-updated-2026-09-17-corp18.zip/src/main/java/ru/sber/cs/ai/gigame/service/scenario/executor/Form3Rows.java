package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ru.sber.cs.ai.gigame.service.scenario.executor.Form3Ops.str;

/**
 * Строки Формы 3 по реестру документов и критериям Шага 1 (шаблон Егоровой):
 * к1 компания, к2 исполнитель, к3 заказчик, к4 договор, к5 спецификация,
 * к6 акт/УПД, к7 дата подписания, к8 период квалификации (да/нет), к9 период
 * методики (да/нет), к10 сумма по акту, к11 заказчик в рейтинге (да/нет),
 * к12 мобильная разработка (да/нет), к13 только тестирование (да/нет),
 * к14 сумма зачтено, к15 причина незачёта, т_&lt;технология&gt; (да/нет) по
 * каждой технологии критериев, к16…к19 технология подтверждена в договоре /
 * спецификации / акте / отчёте, к20 аудит.
 * <p>
 * Сумма зачитывается, только если акт подписан заказчиком, найдена хотя бы
 * одна технология в спецификации/заявке, акте/УПД или отчёте к УПД (договор
 * технологию строки не засчитывает — письма Егоровой 16.09.2026; исключение — нерамочный
 * договор без спецификаций, где договор играет роль спецификации), заказчик в рейтинге,
 * дата акта внутри периода методики, нет мобильной разработки (если закупка
 * не мобильная) и спецификация не только на тестирование.
 */
final class Form3Rows {

    static final String YES = "да";
    static final String NO = "нет";
    static final String NO_DATA = "нет данных";
    static final String MANUAL = "проверить вручную";
    static final String DASH = "-";
    /** Формулировки причин незачёта — как в разметке Егоровой. */
    static final String REASON_NO_DOCS = "Подтверждающие документы не найдены";
    static final String REASON_PERIOD = "Акт не в периоде";
    static final String REASON_RATING = "Заказчик не в рейтинге";
    /** Правило 3 Егоровой (16.09.2026): один документ полностью совпал со строками разных договоров/спецификаций. */
    static final String REASON_UNIDENTIFIED = "Не удалось идентифицировать акт";
    /** Поле строки с исходной строкой формы — ключ обогащения формы. */
    static final String SOURCE_LINE = "исходная_строка";
    /** Служебное поле строки: сколько договоров комплекта найдено для строки (правило «без договора не засчитывать»). */
    static final String CONTRACTS = "договоров_найдено";
    /** Служебное поле УПД-карты: в комплекте есть акты/УПД договора этой строки («да»/«нет»). */
    static final String CONTRACT_DOCS = "акты_договора_в_комплекте";
    /** Служебное поле УПД-карты: строка — претендент на неидентифицированный документ (правило 3), «да». */
    static final String UNIDENTIFIED = "акт_не_идентифицирован";
    /**
     * Параметр операции: документ без текста (скан не распознан) искать по реквизитам в имени файла ({@code "true"});
     * по умолчанию выключен — методолог выбрала распознавание сканов моделью (вопрос 2 письма 16.09.2026).
     */
    static final String SCANS_BY_NAME = "сканы_по_имени_файла";
    /** Параметр операции: строка без договора в комплекте не засчитывается ({@code "true"}), см. {@link #denyWithoutContract}. */
    static final String WITHOUT_CONTRACT = "без_договора_не_засчитывать";
    /** Пометка аудита строки, документ которой найден, но договора в комплекте нет (параметр {@link #WITHOUT_CONTRACT}). */
    static final String WITHOUT_CONTRACT_NOTE = "договора в комплекте нет — без договора не засчитывается";
    /** Пояснение аудита: акт/УПД строки не найден, есть только запись формы участника. */
    private static final String ACT_NOT_FOUND = "акт/УПД по номеру, сумме и дате не найден";
    /**
     * Параметр операции: методологически спорные допуски для строк без номера акта ({@code "true"}; по умолчанию выключен) —
     * {@link Form3Match#actDateTolerance} (дата в графе подписания равна дате акта) и {@link Form3Match#specTolerance}
     * (совпали номер спецификации/заявки и сумма). Найденный допуском документ помечается в аудите и уходит агенту.
     * Основание допуска (а) — Комплекты 5 (Хинт) и 9 (АксТим): участник пишет в графу подписания дату акта, штамп ЭДО позже;
     * без параметра такие строки «Подтверждающие документы не найдены» (Комплект 9: зачёт совпадает с разметкой в 31 из 43
     * строк против 42 из 43 с параметром).
     */
    static final String BN_TOLERANCES = "б/н_допуски";
    /**
     * Параметр операции: допуск {@link Form3Match#anySignTolerance} — у строки без номера дата графы подписания равна дате
     * не последней подписи штампа ЭДО (по умолчанию {@code "true"}: так заполнен пример методолога к правилу 2 в Комплекте 9,
     * а ответ на вопрос 4 требует последнюю подпись; до ответа методолога документ уходит агенту).
     */
    static final String BN_ANY_SIGNATURE = "б/н_любая_подпись";
    /**
     * Параметр операции: отчёт о выполненных работах к УПД подтверждает технологию наравне с актом (по умолчанию
     * {@code "true"}; в шаблоне методолога — «Акт/УПД + Отчёт к УПД», прямого ответа методолога пока нет).
     */
    static final String REPORT_AS_ACT = "отчёт_как_акт";
    /** Служебное поле УПД-карты: документ найден запасным ходом или допуском — строка на проверку агенту («да»). */
    static final String AGENT_CHECK = "на_проверку_агенту";
    /** Причина незачёта: ни одной требуемой технологии в спецификации/заявке, акте/УПД и отчёте. */
    static final String REASON_NO_TECH = "технология не найдена";
    private static final String SCAN_NOTE = "документ-скан не распознан (распознавание моделью выключено или не удалось)";
    /** Пометка аудита строки нерамочного договора, где технологии засчитываются по договору. */
    static final String NON_FRAMEWORK_NOTE = "нерамочный договор: технологии по договору (спецификаций нет)";
    /**
     * Графа спецификации формы у нерамочного договора: пусто, «не применимо», «не применяется», «нет», «отсутствует»,
     * прочерк (после отбрасывания точки в конце).
     */
    private static final Pattern NO_SPEC = Pattern.compile("(?:не\\s*примен[а-яё]*|нет|отсутству[а-яё]*|[-‐‑–—]+)?",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Заказчики в рейтингах по умолчанию (переопределяется конфигом {@code "заказчики_в_рейтинге"}):
     * ТОП-25 банков по активам и крупнейшие компании (ТОП-100 РБК/Мосбиржи). Дочерние
     * и зависимые общества не засчитываются («ЛУКОЙЛ-Интер-Кард» ≠ «ЛУКОЙЛ») — имя
     * компании должно стоять отдельным словом, без дефисного продолжения.
     */
    private static final String DEFAULT_RATING = "Сбербанк|СБЕР\\b|ВТБ|Газпромбанк|Альфа\\s?-?\\s?Банк|Россельхозбанк|Открытие|"
            + "Совкомбанк|Райффайзен|Росбанк|Тинькофф|Т-Банк|Промсвязьбанк|Московский кредитный банк|МКБ|ЮниКредит|"
            + "Ак Барс|Почта Банк|Уралсиб|Банк Санкт-Петербург|Ситибанк|Хоум Банк|Русский Стандарт|ОТП Банк|Зенит|"
            + "ДОМ\\.РФ|Новикомбанк|Абсолют|"
            + "МЕТРО Кэш энд Керри|Metro Cash|X5|Магнит\\b|Яндекс|Ozon|Wildberries|Вайлдберриз|МТС\\b|МегаФон|Ростелеком|"
            + "(?<![\\wА-Яа-я-])(?:Газпром|Роснефть|ЛУКОЙЛ|Лукойл|НОВАТЭК|Норникель|Сургутнефтегаз|Татнефть|Северсталь|НЛМК|ММК|"
            + "РУСАЛ|Полюс|АЛРОСА|Аэрофлот|РЖД|Транснефть|Ростех|Росатом|ФосАгро|Интер РАО|РусГидро|Россети|Сибур|"
            + "Мечел|Евраз|ПИК|Самолет|ЛСР|Лента|Детский мир|М\\.Видео|Ситилинк|Softline|Positive Technologies|VK)(?![\\wА-Яа-я-])";
    /** Встроенный перечень заказчиков рейтинга — скомпилирован один раз (длиннее предела пользовательского шаблона). */
    private static final Pattern DEFAULT_RATING_PATTERN = Pattern.compile(DEFAULT_RATING,
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern MOBILE = Pattern.compile(
            "мобильн[а-я]*\\s+(приложен|разработ|платформ|клиент|верси|банк|устройств)|(?<![a-z])(ios|android)(?![a-z])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Технологии-платформы мобильной разработки в критериях. */
    private static final Pattern PLATFORM = Pattern.compile("(?iu)\\s*(ios|android|harmonyos|аврора|huawei\\s*\\w*)\\s*");
    /** Слова о мобильном приложении — сильное доказательство мобильной разработки (без упоминаний платформ). */
    private static final Pattern MOBILE_WORDS = Pattern.compile(
            "мобильн[а-я]*\\s+(приложен|разработ|платформ|клиент|верси|банк|устройств)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SUBJECT = Pattern.compile("Предмет\\s+(?:Спецификации|Заказа|Договора|отч[её]та)?\\s*:?\\s*([^\\n]{0,600})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern TESTING = Pattern.compile("тестирован|испытани|автотест|\\bQA\\b",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern DEVELOPMENT = Pattern.compile(
            "разработ|модификац|доработ|создани|реализац|внедрен|сопровожден|развити|проектирован|интеграц|миграц|поддержк",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final int SUBJECT_LIMIT = 600;
    private static final Pattern FORM_SPEC = Pattern.compile("Спецификаци\\S{0,3}\\s*№?\\s*(\\d{7,8})(?!\\d)");
    private static final Pattern FORM_AMOUNT = Pattern.compile("(?<![\\d,.])(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?![\\d])");
    private static final Pattern SPEC_NUMBER = Pattern.compile("(?<!\\d)(\\d{6,8})(?!\\d)");
    private static final Pattern CONTRACT_DIGITS = Pattern.compile("(?<![\\d/])(\\d{5,12})(?![\\d/])");
    /** Роль исполнителя с технологией в спецификации: «Главный разработчик GreenPlum», «Ведущий аналитик Python». */
    private static final Pattern ROLE_TECH = Pattern.compile("(?:разработчик|аналитик|архитектор|тестировщик|инженер)\\s+([A-Za-z][A-Za-z0-9+#./-]{1,24})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern CONTRACT_ALNUM = Pattern.compile("№\\s*([A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9/\\-]{2,24})");

    private Form3Rows() {
    }

    /**
     * Документы, относящиеся к строке УПД.
     *
     * @param contractEvidence договор строки — источник технологий наравне со спецификацией (нерамочный договор без
     *                         спецификаций, {@link #nonFramework})
     */
    private record Linked(Map<String, Object> upd, List<Map<String, Object>> specs,
                          List<Map<String, Object>> contracts, List<Map<String, Object>> reports, String specNote,
                          boolean contractEvidence) {

        /** Те же документы строки, договор которой засчитывает технологии (нерамочный договор). */
        Linked withContractEvidence() {
            return new Linked(upd, specs, contracts, reports, specNote, true);
        }
    }

    /**
     * Номера спецификаций из строк формы участника, относящихся к УПД: строка
     * содержит номер УПД либо сумму и дату УПД (участники нередко пишут в
     * форме номер заказа вместо номера УПД).
     */
    static Set<String> formSpecHints(Map<String, Object> upd, String formLines) {
        Set<String> hints = new LinkedHashSet<>();
        if (formLines == null || formLines.isBlank()) {
            return hints;
        }
        String number = str(upd.get("номер")).replaceFirst("^0+", "");
        Pattern byNumber = number.isEmpty() ? null : Pattern.compile("УПД\\s*№?\\s*0*" + Pattern.quote(number) + "(?!\\d)");
        String amount = str(upd.get("сумма"));
        String date = str(upd.get("дата"));
        for (String line : formLines.split("\n")) {
            boolean hit = byNumber != null && byNumber.matcher(line).find();
            if (!hit && !amount.isEmpty() && !date.isEmpty() && line.contains(date)) {
                Matcher m = FORM_AMOUNT.matcher(line);
                while (m.find() && !hit) {
                    hit = amount.equals(m.group(1).replace(" ", "") + "." + m.group(2));
                }
            }
            if (hit) {
                Matcher m = FORM_SPEC.matcher(line);
                while (m.find()) {
                    hints.add(m.group(1));
                }
            }
        }
        return hints;
    }

    private static List<Map<String, Object>> withNumbers(List<Map<String, Object>> specs, Set<String> numbers) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> spec : specs) {
            if (numbers.contains(str(spec.get("номер")))) {
                out.add(spec);
            }
        }
        return out;
    }

    private static List<Map<String, Object>> dedupByNumber(List<Map<String, Object>> specs) {
        Set<String> seen = new LinkedHashSet<>();
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map<String, Object> spec : specs) {
            if (seen.add(str(spec.get("номер")))) {
                out.add(spec);
            }
        }
        return out;
    }

    /**
     * Строки формы по реестру.
     *
     * @param op       конфиг операции ({@code "заказчики_в_рейтинге"} — regex)
     * @param registry реестр документов
     * @param criteria критерии Шага 1
     * @return строки (карты полей)
     */
    static List<Map<String, Object>> build(Map<String, Object> op, Map<String, Object> registry,
                                           Form3Ops.Criteria criteria) {
        return build(op, registry, criteria, "", "");
    }

    /**
     * Строки формы по реестру с подсказками из исходной формы участника.
     *
     * @param formLines строки исходной формы (ячейки через «|»), может быть пустой
     */
    static List<Map<String, Object>> build(Map<String, Object> op, Map<String, Object> registry,
                                           Form3Ops.Criteria criteria, String formLines) {
        return build(op, registry, criteria, formLines, "");
    }

    /**
     * Строки заключения. С шапкой формы форма первична: каждая строка формы
     * участника получает вердикт — по найденному УПД (по номеру, иначе по сумме
     * и дате акта), а без документов в комплекте — по данным самой формы;
     * УПД комплекта, не заявленные в форме, в заключение не попадают. Без
     * шапки строки строятся по УПД реестра.
     *
     * @param headerLine строка-шапка исходной формы, может быть пустой
     */
    static List<Map<String, Object>> build(Map<String, Object> op, Map<String, Object> registry,
                                           Form3Ops.Criteria criteria, String formLines, String headerLine) {
        Registry docs = Registry.of(registry);
        // встроенный перечень длиннее предела пользовательского шаблона — он статический, через SafeRegex идёт только override
        Object ratingRaw = op.get("заказчики_в_рейтинге");
        Pattern rating = ratingRaw == null ? DEFAULT_RATING_PATTERN
                : SafeRegex.compile(String.valueOf(ratingRaw), Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE, "заказчики_в_рейтинге");
        List<Map<String, Object>> rows = new ArrayList<>();
        Set<String> evidence = evidence(op);
        Form3Form form = Form3Form.parse(headerLine);
        if (form == null) {
            for (Map<String, Object> upd : docs.upds()) {
                rows.add(row(link(upd, docs, formSpecHints(upd, formLines)), criteria, rating, evidence));
            }
            return rows;
        }
        List<Form3Form.Row> lines = form.rows(formLines);
        Map<Form3Form.Row, Map<String, Object>> matched = match(lines, docs, Moves.of(op));
        for (Form3Form.Row line : lines) {
            Map<String, Object> upd = matched.get(line);
            Map<String, Object> row = row(nonFramework(line, docs, link(upd, docs, formSpecHints(upd, line.line()))), criteria, rating, evidence);
            row.put(SOURCE_LINE, line.line());
            rows.add(row);
        }
        return rows;
    }

    /** Реестр документов по типам. */
    private record Registry(List<Map<String, Object>> upds, List<Map<String, Object>> specs,
                            List<Map<String, Object>> contracts, List<Map<String, Object>> reports,
                            List<Map<String, Object>> acts) {
        @SuppressWarnings("unchecked")
        static Registry of(Map<String, Object> registry) {
            return new Registry((List<Map<String, Object>>) registry.getOrDefault("упд", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("спецификации", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("договоры", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("отчёты", List.of()),
                    (List<Map<String, Object>>) registry.getOrDefault("акты", List.of()));
        }
    }

    /**
     * Ходы для строк без документа после правил 1–3, включаемые параметрами операции.
     *
     * @param scansByName искать сканы без текста по имени файла ({@link #SCANS_BY_NAME})
     * @param tolerances  допуски строк без номера акта ({@link #BN_TOLERANCES})
     * @param anySign     допуск «дата любой подписи штампа ЭДО» ({@link #BN_ANY_SIGNATURE})
     */
    private record Moves(boolean scansByName, boolean tolerances, boolean anySign) {
        static Moves of(Map<String, Object> op) {
            return new Moves(enabled(op, SCANS_BY_NAME), enabled(op, BN_TOLERANCES), flag(op, BN_ANY_SIGNATURE, true));
        }
    }

    /** Документы строки УПД: спецификации (с учётом подсказки формы), договор, отчёты. */
    private static Linked link(Map<String, Object> upd, Registry docs, Set<String> hint) {
        List<Map<String, Object>> candidates = matchSpecs(upd, docs.specs());
        String specNote = "";
        if (!hint.isEmpty()) {
            List<Map<String, Object>> narrowed = withNumbers(candidates, hint);
            if (!narrowed.isEmpty()) {
                specNote = candidates.size() > 1 ? "спецификация выбрана по форме участника" : "";
                candidates = narrowed;
            } else if (candidates.isEmpty()) {
                candidates = withNumbers(dedupByNumber(docs.specs()), hint);
                specNote = candidates.isEmpty() ? "" : "спецификация взята из формы участника (по сумме не сошлась)";
            }
        }
        return new Linked(upd, candidates, matchContracts(upd, docs.contracts()),
                matchReports(upd, candidates, docs.reports()), specNote, false);
    }

    /**
     * Нерамочный договор: методика оценивает признаки «в рамках спецификации/заказа (если рамочный договор) или договора
     * (нерамочный договор)» (письма Борисова и Егоровой 16.09.2026). Строка относится к нерамочному договору, если графа
     * спецификации формы пуста или «не применимо»/«нет»/«отсутствует»/прочерк ({@link #NO_SPEC}), к строке не привязана
     * ни одна спецификация и среди документов комплекта нет спецификации/заказа/заявки к её договору. Тогда договор
     * строки — источник технологий наравне со спецификацией; у договора со спецификациями поведение прежнее. Без шапки
     * формы (строки по УПД реестра) графы спецификации нет — правило не применяется.
     *
     * @param line   строка формы
     * @param docs   реестр документов
     * @param linked документы строки
     * @return документы строки, при нерамочном договоре — с договором среди доказательных документов
     */
    private static Linked nonFramework(Form3Form.Row line, Registry docs, Linked linked) {
        String spec = line.spec().strip().replaceFirst("\\.$", "").strip();
        boolean noSpec = NO_SPEC.matcher(spec).matches() && linked.specs().isEmpty()
                && docs.specs().stream().noneMatch(doc -> ofContract(line, doc));
        return noSpec ? linked.withContractEvidence() : linked;
    }

    /**
     * Спецификация/заказ/заявка реестра относится к договору строки: номер договора документа совпал с номером формы
     * (по {@link #contractKey}), а если номер в документе не разобран — номер договора строки есть в тексте или в пути
     * к файлу (папка «Договор … /Спецификация …»). Строка без номера договора считает своими все спецификации комплекта
     * (осторожный исход: договор технологии не засчитывает).
     */
    private static boolean ofContract(Form3Form.Row line, Map<String, Object> spec) {
        String number = contractNumber(line.contract());
        String own = str(spec.get("договор"));
        if (number.isEmpty()) {
            return true;
        }
        if (!own.isEmpty()) {
            return contractKey(number).equals(contractKey(own));
        }
        return str(spec.get("текст")).contains(number) || str(spec.get("файл")).contains(number);
    }

    /**
     * Документы строк формы: сначала правила 1–3 по всем строкам ({@link Form3Match#assign}), затем запасной ход
     * {@link Form3Match#ignoringDocSpec} для оставшихся строк (правило 1/2 выполнено, но не совпала ссылка документа на
     * спецификацию, взятую из пути к файлу), затем в порядке формы — допуск распознавания сканов, по параметру
     * {@link #BN_ANY_SIGNATURE} — допуск «дата любой подписи штампа», по параметру {@link #BN_TOLERANCES} — допуски строк
     * без номера, по параметру {@link #SCANS_BY_NAME} — документ без текста по реквизитам в имени файла. Документ,
     * найденный не правилами 1–3, помечается в аудите и отправляет строку агенту ({@link #AGENT_CHECK}).
     * Найденный документ всегда содержит реквизиты договора строки.
     *
     * @param lines строки формы
     * @param docs  реестр документов
     * @param moves ходы, включённые параметрами операции
     * @return УПД-карта для каждой строки (без документа — по данным формы, вид «форма»)
     */
    private static Map<Form3Form.Row, Map<String, Object>> match(List<Form3Form.Row> lines, Registry docs, Moves moves) {
        List<Map<String, Object>> all = new ArrayList<>(docs.upds());
        all.addAll(docs.acts());
        Map<Form3Form.Row, Form3Match.Hit> hits = Form3Match.assign(lines, all);
        Set<Map<String, Object>> used = Collections.newSetFromMap(new IdentityHashMap<>());
        hits.values().forEach(hit -> used.add(hit.doc()));
        List<Form3Form.Row> rest = lines.stream().filter(line -> !hits.containsKey(line)).toList();
        Form3Match.ignoringDocSpec(rest, all.stream().filter(doc -> !used.contains(doc)).toList()).forEach((line, hit) -> {
            hits.put(line, hit);
            used.add(hit.doc());
        });
        Set<Map<String, Object>> blocked = Collections.newSetFromMap(new IdentityHashMap<>());
        hits.values().stream().filter(Form3Match.Hit::unidentified).forEach(hit -> blocked.add(hit.doc()));
        Form3Match.Taken taken = new Form3Match.Taken(lines, used, blocked);
        Map<Form3Form.Row, Map<String, Object>> matched = new IdentityHashMap<>();
        for (Form3Form.Row line : lines) {
            Form3Match.Hit hit = hits.get(line);
            if (hit != null && hit.unidentified()) {
                matched.put(line, unidentifiedDoc(line, hit));
                continue;
            }
            hit = hit == null ? tolerance(line, docs, used, moves) : hit;
            if (hit != null) {
                used.add(hit.doc());
            }
            matched.put(line, hit == null ? missingDoc(line, docs.acts(), all, taken) : foundDoc(line, hit));
        }
        return matched;
    }

    /**
     * Ходы для строки без документа после правил 1–3 и запасного хода, в порядке: допуск распознавания скана,
     * допуск «дата любой подписи штампа» (по параметру, по умолчанию включён), допуски «б/н» (по параметру), скан без
     * текста по имени файла (по параметру).
     */
    private static Form3Match.Hit tolerance(Form3Form.Row line, Registry docs, Set<Map<String, Object>> used, Moves moves) {
        List<Map<String, Object>> all = new ArrayList<>(docs.upds());
        all.addAll(docs.acts());
        Form3Match.Hit hit = Form3Match.scanTolerance(line, docs.acts(), used);
        if (hit == null && moves.anySign()) {
            hit = Form3Match.anySignTolerance(line, all, used);
        }
        if (hit == null && moves.tolerances()) {
            hit = Form3Match.actDateTolerance(line, all, used);
        }
        if (hit == null && moves.tolerances()) {
            hit = Form3Match.specTolerance(line, all, used);
        }
        if (hit == null && moves.scansByName()) {
            hit = Form3Match.byFileName(line, docs.acts(), used);
        }
        return hit;
    }

    /** УПД-карта строки с найденным документом; документ не по правилам 1–3 — строка на проверку агенту. */
    private static Map<String, Object> foundDoc(Form3Form.Row line, Form3Match.Hit hit) {
        Map<String, Object> linked = linkedDoc(line, hit.doc(), hit.note());
        if (hit.tolerance()) {
            linked.put(AGENT_CHECK, YES);
        }
        return linked;
    }

    /**
     * УПД-карта строки без документа. Комплект содержит акты/УПД этого договора — значит документ строки действительно
     * не найден, а не «комплект без актов» (Комплекты 1 и 6, где сумму этапа подтверждала спецификация). В аудит —
     * почему не найден документ ({@link Form3Match#missNote}) и пометка о нераспознанном скане.
     */
    private static Map<String, Object> missingDoc(Form3Form.Row line, List<Map<String, Object>> acts, List<Map<String, Object>> all,
                                                  Form3Match.Taken taken) {
        Map<String, Object> linked = linkedDoc(line, null, "");
        linked.put(CONTRACT_DOCS, all.stream().anyMatch(d -> Form3Match.contractFits(line, d)) ? YES : NO);
        List<String> notes = new ArrayList<>(List.of(Form3Match.missNote(line, all, taken), scanNote(line, acts, all)));
        notes.removeIf(String::isEmpty);
        linked.put(Form3Match.NOTE, String.join("; ", notes));
        return linked;
    }

    /**
     * Правило 3: строка — претендент на документ, полностью совпавший со строками разных договоров/спецификаций.
     * Карта строится по данным формы (документ строке не достаётся), пометка {@link #UNIDENTIFIED} даёт причину
     * незачёта, пояснение поиска с перечнем претендентов уходит в аудит.
     */
    private static Map<String, Object> unidentifiedDoc(Form3Form.Row line, Form3Match.Hit hit) {
        Map<String, Object> linked = pseudoUpd(line, null);
        linked.put("файл", str(hit.doc().get("файл")));
        linked.put(UNIDENTIFIED, YES);
        linked.put(CONTRACT_DOCS, YES);
        linked.put(Form3Match.NOTE, hit.note());
        return linked;
    }

    /**
     * Вопрос 2 письма: строка без документа, в комплекте по её договору есть скан без текстового слоя, а документов
     * с текстом по её договору и спецификации нет — иначе пометка о скане вводила бы в заблуждение (Комплект 5: все
     * акты одного рамочного договора, акт строки распознан, но по правилу 2 не сошёлся).
     */
    private static String scanNote(Form3Form.Row line, List<Map<String, Object>> acts, List<Map<String, Object>> all) {
        boolean scan = acts.stream().anyMatch(act -> Boolean.TRUE.equals(act.get("без_текста")) && Form3Match.contractFits(line, act));
        boolean anySpec = specNumber(line.spec()).isEmpty();
        boolean withText = all.stream().anyMatch(doc -> !Boolean.TRUE.equals(doc.get("без_текста")) && Form3Match.contractFits(line, doc)
                && (anySpec || Form3Match.sameSpec(line, doc)));
        return scan && !withText ? SCAN_NOTE : "";
    }

    /** Параметр операции со значением {@code "true"} (без учёта регистра); не задан — выключен. */
    private static boolean enabled(Map<String, Object> op, String key) {
        return flag(op, key, false);
    }

    /** Параметр операции «true»/«false» (без учёта регистра) со значением по умолчанию. */
    private static boolean flag(Map<String, Object> op, String key, boolean byDefault) {
        return "true".equalsIgnoreCase(String.valueOf(op.getOrDefault(key, String.valueOf(byDefault))));
    }

    /** УПД-карта строки: УПД реестра с датой формы, акт или только форма; пояснение поиска — для аудита. */
    private static Map<String, Object> linkedDoc(Form3Form.Row line, Map<String, Object> doc, String note) {
        boolean upd = doc != null && !Form3Acts.KIND_ACT.equals(doc.get("вид"));
        Map<String, Object> linked = upd ? withFormDate(doc, line) : pseudoUpd(line, doc);
        linked.put(Form3Match.NOTE, doc == null ? "" : note);
        return linked;
    }

    /** Сумма есть в спецификации (её итог или любая сумма текста): спецификация подтверждает сумму этапа. */
    @SuppressWarnings("unchecked")
    private static boolean specAmountFits(Map<String, Object> spec, String amount) {
        return !amount.isEmpty() && (amount.equals(str(spec.get("сумма")))
                || ((List<String>) spec.getOrDefault("суммы", List.of())).contains(amount));
    }

    /** Номер спецификации (6–8 цифр) либо заявки («Заявка 104») из реквизитов формы. */
    static String specNumber(String spec) {
        Matcher m = SPEC_NUMBER.matcher(spec);
        if (m.find()) {
            return m.group(1);
        }
        return Form3Ops.firstGroup(Form3Acts.ORDER_REF, spec);
    }

    /**
     * УПД строки с датой, заявленной в форме: если дата формы совпадает с датой УПД
     * либо датой приёмки, она и считается датой акта (Егорова судит период по дате,
     * названной участником: «УПД 138 от 24.03.2025» — по 24.03, хотя приёмка позже).
     */
    private static Map<String, Object> withFormDate(Map<String, Object> upd, Form3Form.Row line) {
        Map<String, Object> copy = new LinkedHashMap<>(upd);
        copy.put("заявлено", line.claimedTechs());
        copy.put("колонки_технологий", line.techHeaders());
        String formDate = line.actDate();
        if (!formDate.isEmpty() && (formDate.equals(str(upd.get("дата"))) || formDate.equals(str(upd.get("дата_приёмки"))))) {
            copy.put("дата_по_форме", formDate);
        }
        // покупатель в УПД не разобран (иная печатная форма) — заказчик берётся из формы участника
        if (str(upd.get("покупатель")).isEmpty()) {
            copy.put("покупатель", line.customer());
        }
        // номер договора в УПД не разобран (буквенно-цифровой «CN_1090_IT_19_134108_037544» у МЕТРО): документ уже
        // проверен на реквизиты договора строки, поэтому договор берётся из формы — иначе «договор 0» и незачёт
        if (str(upd.get("договор")).isEmpty()) {
            copy.put("договор", contractNumber(line.contract()));
            copy.put("договор_дата", Form3Form.actDate(line.contract(), ""));
        }
        if (str(upd.get("продавец")).isEmpty()) {
            copy.put("продавец", line.executor().isEmpty() ? line.company() : line.executor());
        }
        // участник засчитывает часть УПД (только профильные позиции): заявленная сумма меньше итога — берётся она
        String total = str(upd.get("сумма"));
        if (!line.amount().isEmpty() && !total.isEmpty() && !line.amount().equals(total) && less(line.amount(), total)) {
            copy.put("сумма", line.amount());
            copy.put("сумма_примечание", "сумма по форме участника " + line.amount() + " (итог УПД " + total + ")");
        }
        return copy;
    }

    private static boolean less(String a, String b) {
        try {
            return Double.parseDouble(a) < Double.parseDouble(b);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Запись строки формы без УПД в виде УПД-карты: реквизиты акта (если найден)
     * и формы участника; {@code "вид"} = «акт» либо «форма» (документов акта нет).
     */
    private static Map<String, Object> pseudoUpd(Form3Form.Row line, Map<String, Object> act) {
        Map<String, Object> upd = new LinkedHashMap<>();
        boolean hasAct = act != null;
        String order = hasAct ? str(act.get("заявка")) : "";
        upd.put("файл", hasAct ? str(act.get("файл")) : "");
        upd.put("вид", hasAct ? Form3Acts.KIND_ACT : "форма");
        String date = hasAct && !str(act.get("дата")).isEmpty() ? str(act.get("дата")) : line.actDate();
        upd.put("номер", hasAct ? "от " + date + (order.isEmpty() ? "" : " (заявка " + order + ")") : "");
        upd.put("метка", hasAct ? "Акт " + upd.get("номер") : line.act());
        upd.put("дата", date);
        upd.put("дата_приёмки", date);
        upd.put("дата_подписания", hasAct ? str(act.get("дата_подписания")) : "");
        // стороны — из формы участника (первична), из акта — только если в форме пусто
        String seller = line.executor().isEmpty() ? line.company() : line.executor();
        String buyer = line.customer();
        upd.put("продавец", seller.isEmpty() && hasAct ? str(act.get("продавец")) : seller);
        upd.put("покупатель", buyer.isEmpty() && hasAct ? str(act.get("покупатель")) : buyer);
        upd.put("договор", contractNumber(line.contract()));
        upd.put("договор_дата", Form3Form.actDate(line.contract(), ""));
        // сумма формы, если она — итог акта или итог этапа с меткой итога (признак «сумма» правил идентификации); распознанный
        // скан суммам не судья — берётся сумма формы с пометкой; для текстового акта без суммы формы — сумма акта с пометкой
        boolean scanned = hasAct && str(act.get("текст")).startsWith("[РАСПОЗНАНО") || hasAct && Boolean.TRUE.equals(act.get("скан"));
        boolean fits = hasAct && Form3Match.amountFits(line, act);
        String amount = hasAct && !fits && !scanned && !str(act.get("сумма")).isEmpty() ? str(act.get("сумма")) : line.amount();
        upd.put("сумма", amount.isEmpty() && hasAct ? str(act.get("сумма")) : amount);
        String note = "";
        if (hasAct && !fits && !line.amount().isEmpty()) {
            note = scanned ? "сумма взята из формы участника (в распознанном скане акта не найдена"
                    + (str(act.get("сумма")).isEmpty() ? ")" : ", скан даёт " + act.get("сумма") + ")")
                    : "сумма формы " + line.amount() + " в акте не найдена, взята сумма акта";
        }
        upd.put("сумма_примечание", note);
        upd.put("подпись_заказчика", hasAct);
        upd.put("подпись_примечание", hasAct ? str(act.get("подпись_примечание")) : "");
        upd.put("спецификация", specNumber(line.spec()));
        upd.put("заказы", order.isEmpty() ? List.of() : List.of(order));
        upd.put("заявлено", line.claimedTechs());
        upd.put("колонки_технологий", line.techHeaders());
        upd.put("текст", hasAct ? str(act.get("текст")) : "");
        return upd;
    }

    /** Номер договора из реквизитов формы: длинный числовой, иначе буквенно-цифровой после «№». */
    static String contractNumber(String contract) {
        Matcher digits = CONTRACT_DIGITS.matcher(contract);
        if (digits.find()) {
            return digits.group(1);
        }
        return Form3Ops.firstGroup(CONTRACT_ALNUM, contract);
    }

    /**
     * Заказчик вне рейтинга — стоп-фактор (шаблон Егоровой): остальные проверки
     * не выполняются и помечаются прочерком, причина незачёта одна. Второе мнение
     * агента такой строке не нужно — она агенту не отправляется (письмо Егоровой
     * «Ошибка выполнения», Комплект 4: 13 строк стоп-фактора уходили агенту впустую).
     */
    private static Map<String, Object> ratingStop(Map<String, Object> row) {
        if (!NO.equals(row.get("к11"))) {
            return row;
        }
        for (String key : List.of("к8", "к9", "к10", "к12", "к13", "к16", "к17", "к18", "к19")) {
            row.put(key, DASH);
        }
        row.replaceAll((key, value) -> key.startsWith("т_") ? DASH : value);
        row.put("к14", "0");
        row.put("к15", REASON_RATING);
        row.put("агенту", "");
        return row;
    }

    /** Кандидаты-спецификации: по номеру из УПД, иначе того же договора с равной суммой этапа. */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> matchSpecs(Map<String, Object> upd, List<Map<String, Object>> specs) {
        String number = str(upd.get("спецификация"));
        List<Map<String, Object>> byNumber = new ArrayList<>();
        List<Map<String, Object>> bySum = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (Map<String, Object> spec : specs) {
            if (!seen.add(str(spec.get("номер")))) {
                continue;
            }
            if (!number.isEmpty() && number.equals(str(spec.get("номер")))) {
                byNumber.add(spec);
            }
            boolean sameContract = str(spec.get("договор")).isEmpty() || str(upd.get("договор")).isEmpty()
                    || str(spec.get("договор")).equals(str(upd.get("договор")));
            List<String> sums = (List<String>) spec.getOrDefault("суммы", List.of());
            if (sameContract && !str(upd.get("сумма")).isEmpty() && sums.contains(str(upd.get("сумма")))) {
                bySum.add(spec);
            }
        }
        return byNumber.isEmpty() ? bySum : byNumber;
    }

    private static List<Map<String, Object>> matchContracts(Map<String, Object> upd, List<Map<String, Object>> contracts) {
        List<Map<String, Object>> matched = new ArrayList<>();
        String number = contractKey(str(upd.get("договор")));
        for (Map<String, Object> contract : contracts) {
            if (!number.isEmpty() && number.equals(contractKey(str(contract.get("номер"))))) {
                matched.add(contract);
            }
        }
        return matched;
    }

    /**
     * Ключ сравнения номеров договора: длинный числовой фрагмент, если он есть, иначе номер целиком —
     * так «CN_1090_IT_19_134108_037544» из реестра (договор МЕТРО) совпадает со строкой формы, где
     * из тех же реквизитов взято «134108».
     */
    static String contractKey(String number) {
        Matcher digits = CONTRACT_DIGITS.matcher(number);
        return digits.find() ? digits.group(1) : number;
    }

    /**
     * Отчёты строки: по номеру спецификации-кандидата, по номеру УПД, по общему
     * номеру заказа (ЗНЗО/заказ/заявка) с УПД или по сумме УПД.
     */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> matchReports(Map<String, Object> upd, List<Map<String, Object>> specs,
                                                          List<Map<String, Object>> reports) {
        Set<String> specNumbers = new LinkedHashSet<>();
        for (Map<String, Object> spec : specs) {
            specNumbers.add(str(spec.get("номер")));
        }
        String updNumber = str(upd.get("номер")).replaceFirst("^0+", "");
        List<String> updOrders = (List<String>) upd.getOrDefault("заказы", List.of());
        List<Map<String, Object>> matched = new ArrayList<>();
        for (Map<String, Object> report : reports) {
            boolean bySpec = !str(report.get("спецификация")).isEmpty() && specNumbers.contains(str(report.get("спецификация")));
            boolean byUpd = !updNumber.isEmpty() && str(report.get("упд")).replaceFirst("^0+", "").equals(updNumber);
            List<String> orders = (List<String>) report.getOrDefault("заказы", List.of());
            boolean byNumber = orders.stream().anyMatch(updOrders::contains);
            List<String> sums = (List<String>) report.getOrDefault("суммы", List.of());
            // по сумме — только если отчёт не относится к другой спецификации: у нескольких УПД одного
            // договора суммы этапов совпадают, и отчёт чужой спецификации приносил чужие технологии
            String reportSpec = str(report.get("спецификация"));
            boolean foreignSpec = !reportSpec.isEmpty() && !specNumbers.isEmpty() && !specNumbers.contains(reportSpec);
            boolean bySum = !foreignSpec && !str(upd.get("сумма")).isEmpty() && sums.contains(str(upd.get("сумма")));
            if (bySpec || byUpd || byNumber || bySum) {
                matched.add(report);
            }
        }
        return matched;
    }

    private static Map<String, Object> row(Linked linked, Form3Ops.Criteria criteria, Pattern rating, Set<String> evidence) {
        Map<String, Object> upd = linked.upd();
        Map<String, Object> row = new LinkedHashMap<>();
        String seller = str(upd.get("продавец"));
        String buyer = str(upd.get("покупатель"));
        row.put("к1", seller);
        row.put("к2", seller);
        row.put("к3", buyer);
        row.put("к4", contractLabel(upd));
        row.put("к5", specLabel(linked.specs()));
        row.put("к6", str(upd.get("метка")).isEmpty() ? "УПД " + upd.get("номер") + " от " + upd.get("дата") : str(upd.get("метка")));
        String actDate = signDate(upd);
        row.put("к7", actDate);
        String qual = criteria.qualFrom == null ? DASH : periodVerdict(actDate, criteria.qualFrom, criteria.qualTo);
        String method = periodVerdict(actDate, criteria.methodFrom, criteria.methodTo);
        row.put("к8", qual);
        row.put("к9", method);
        row.put("к10", str(upd.get("сумма")));
        boolean inRating = SafeRegex.find(rating, buyer);
        row.put("к11", inRating ? YES : NO);
        String mobile = mobileVerdict(linked, criteria);
        row.put("к12", mobile);
        String testing = testingOnlyVerdict(linked);
        row.put("к13", testing);
        Map<String, Set<String>> techPlaces = technologyPlaces(linked, criteria.allTechnologies());
        Map<String, Set<String>> proven = proven(withoutContractWhenSpecNamesRoles(techPlaces, linked), rowEvidence(linked, evidence));
        List<String> reasons = reasons(linked, criteria, inRating, method, mobile, testing, proven);
        row.put("к14", reasons.isEmpty() ? str(upd.get("сумма")) : "0");
        row.put("к15", reasons.isEmpty() ? DASH : String.join("; ", reasons));
        for (Map.Entry<String, Set<String>> tech : proven.entrySet()) {
            // письма Егоровой 16.09.2026: «да», если технология найдена в спецификации/заявке, акте/УПД (или отчёте к УПД);
            // договор и заявка участника в форме столбец не заполняют — расхождение с формой только в аудите
            row.put("т_" + tech.getKey(), tech.getValue().isEmpty() ? NO : YES);
        }
        row.put("к16", placeLabel(techPlaces, "договор"));
        row.put("к17", placeLabel(techPlaces, "спецификация"));
        row.put("к18", actColumn(reasons, techPlaces));
        row.put("к19", placeLabel(techPlaces, "отчёт"));
        row.put("к20", audit(linked, criteria, techPlaces, proven, qual, method, buyer, mobile));
        row.put(CONTRACTS, String.valueOf(linked.contracts().size()));
        row.put("к20", str(row.get("к20")) + roleNote(techPlaces, linked) + contractNote(linked, reasons, techPlaces));
        // строки для второго мнения агента: причина незачёта, слабое доказательство мобильной разработки либо документ,
        // найденный не правилами идентификации акта (запасной ход, допуск)
        row.put("агенту", !reasons.isEmpty() || weakMobile(linked, mobile) || YES.equals(str(upd.get(AGENT_CHECK))) ? YES : "");
        return ratingStop(row);
    }

    /**
     * Дата подписания акта (к7): штамп ЭДО (последняя подпись — заказчика, письмо Егоровой 16.09.2026), иначе дата,
     * заявленная в форме и совпавшая с датой УПД/приёмки, иначе дата приёмки, иначе дата документа.
     */
    private static String signDate(Map<String, Object> upd) {
        String date = str(upd.get("дата_подписания"));
        if (date.isEmpty()) {
            date = str(upd.get("дата_по_форме"));
        }
        if (date.isEmpty()) {
            date = str(upd.get("дата_приёмки")).isEmpty() ? str(upd.get("дата")) : str(upd.get("дата_приёмки"));
        }
        return date;
    }

    /**
     * Доказательные документы для столбцов технологий и зачёта (письма Егоровой 16.09.2026 «Ошибки с поиском технологий»
     * и ответ о зачёте): спецификация/заявка и акт/УПД, отчёт о выполненных работах к УПД — наравне с актом по параметру
     * {@link #REPORT_AS_ACT} (по умолчанию включён). Договор технологию строки не доказывает: его технологии только
     * перечисляются в графе «подтверждено в Договоре» (к16), закупщик разбирается с ними сам. Исключение — нерамочный
     * договор без спецификаций ({@link #rowEvidence}).
     */
    private static Set<String> evidence(Map<String, Object> op) {
        return flag(op, REPORT_AS_ACT, true) ? Set.of("спецификация", "акт", "отчёт") : Set.of("спецификация", "акт");
    }

    /**
     * Доказательные документы строки: у нерамочного договора без спецификаций ({@link #nonFramework}) договор играет роль
     * спецификации и добавляется к доказательным, у остальных строк — общий набор {@link #evidence}.
     */
    private static Set<String> rowEvidence(Linked linked, Set<String> evidence) {
        if (!linked.contractEvidence()) {
            return evidence;
        }
        Set<String> withContract = new LinkedHashSet<>(evidence);
        withContract.add("договор");
        return withContract;
    }

    /** Места нахождения технологий, ограниченные доказательными документами. */
    private static Map<String, Set<String>> proven(Map<String, Set<String>> techPlaces, Set<String> evidence) {
        Map<String, Set<String>> proven = new LinkedHashMap<>();
        for (Map.Entry<String, Set<String>> e : techPlaces.entrySet()) {
            Set<String> places = new LinkedHashSet<>(e.getValue());
            places.retainAll(evidence);
            proven.put(e.getKey(), places);
        }
        return proven;
    }

    /**
     * Причины незачёта в формулировках письма Егоровой (16.09.2026); пустой список — сумма зачитывается.
     * Исходы письма разделены: документ не идентифицирован (правило 3) — причина одна; документ не найден —
     * причина одна; акт вне периода методики — причина одна; иначе перечисляются технология, мобильная
     * разработка и тестирование.
     */
    private static List<String> reasons(Linked linked, Form3Ops.Criteria criteria, boolean inRating, String method,
                                        String mobile, String testing, Map<String, Set<String>> techPlaces) {
        List<String> reasons = new ArrayList<>();
        if (YES.equals(str(linked.upd().get(UNIDENTIFIED)))) {
            reasons.add(REASON_UNIDENTIFIED);
            return reasons;
        }
        boolean formOnly = "форма".equals(linked.upd().get("вид"));
        // исход 1: акт/УПД не найден — строка засчитывается только по спецификации, подтверждающей сумму этапа
        // (разметка Егоровой, Комплекты 1 и 6), иначе обработка строки на этом заканчивается
        if (formOnly && !specConfirmsAmount(linked)) {
            reasons.add(REASON_NO_DOCS);
            return reasons;
        }
        if (!formOnly && !Boolean.TRUE.equals(linked.upd().get("подпись_заказчика"))) {
            reasons.add("акт не подписан заказчиком");
        }
        if (!inRating) {
            reasons.add(REASON_RATING);
        }
        // исход 2: дата акта вне периода методики — сумма не засчитывается, остальные ограничения не перечисляются
        if (NO.equals(method)) {
            reasons.add(REASON_PERIOD);
            return reasons;
        }
        reasons.addAll(limitReasons(criteria, mobile, testing, techPlaces));
        return reasons;
    }

    /** Исход 4 письма: технология не найдена, мобильная разработка, только тестирование. */
    private static List<String> limitReasons(Form3Ops.Criteria criteria, String mobile, String testing,
                                             Map<String, Set<String>> techPlaces) {
        List<String> reasons = new ArrayList<>();
        if (!criteria.allTechnologies().isEmpty() && techPlaces.values().stream().allMatch(Set::isEmpty)) {
            reasons.add(REASON_NO_TECH);
        }
        if (YES.equals(mobile) && !criteria.mobileProcurement) {
            reasons.add("мобильная разработка");
        }
        if (NO.equals(mobile) && criteria.mobileProcurement) {
            reasons.add("нет мобильной разработки");
        }
        if (YES.equals(testing)) {
            reasons.add("только тестирование");
        }
        return reasons;
    }

    /**
     * Без договора опыт не засчитывается (письмо Егоровой, Комплект 8 «без договора»: в комплекте только спецификации
     * и акты — все строки «Подтверждающие документы не найдены»). Включается параметром операции
     * {@code "без_договора_не_засчитывать": "true"}: строка, для которой договор не найден среди документов комплекта
     * (поле {@link #CONTRACTS}), получает сумму зачтено «0» и причину {@link #REASON_NO_DOCS} первой; если документ строки
     * найден, аудит (к20) поясняет, что незачёт — из-за договора ({@link #foundWithoutContractNote}). Строку со
     * стоп-фактором «Заказчик не в рейтинге» (к11 = «нет») правило не трогает: её причина одна (Комплект 4 без OCR —
     * договоры не распознаны, но эталон даёт только «Заказчик не в рейтинге»).
     *
     * @param op   конфиг операции
     * @param rows строки заключения (изменяются на месте)
     * @return число строк, не засчитанных из-за отсутствия договора
     */
    static int denyWithoutContract(Map<String, Object> op, List<Map<String, Object>> rows) {
        if (!enabled(op, WITHOUT_CONTRACT)) {
            return 0;
        }
        int denied = 0;
        for (Map<String, Object> row : rows) {
            if (!"0".equals(str(row.get(CONTRACTS))) || NO.equals(row.get("к11"))) {
                continue;
            }
            String reasons = str(row.get("к15"));
            // правило 3: «Не удалось идентифицировать акт» — причина единственная, «документы не найдены» к ней не приписывается
            if (!reasons.contains(REASON_NO_DOCS) && !reasons.contains(REASON_UNIDENTIFIED)) {
                row.put("к15", DASH.equals(reasons) || reasons.isEmpty() ? REASON_NO_DOCS : REASON_NO_DOCS + "; " + reasons);
                row.put("к20", str(row.get("к20")) + "; " + foundWithoutContractNote(row));
            }
            row.put("к14", "0");
            row.put("агенту", YES);
            denied++;
        }
        return denied;
    }

    /**
     * Пометка аудита строки, не засчитанной без договора, хотя документ найден (F3-P7: УПД найден по признакам «3 из 3»,
     * а причина — общая «Подтверждающие документы не найдены»): акт/УПД (к6) либо — если акта нет — спецификация (к5),
     * подтвердившая сумму этапа.
     */
    private static String foundWithoutContractNote(Map<String, Object> row) {
        String document = str(row.get("к20")).contains(ACT_NOT_FOUND) ? "спецификация " + str(row.get("к5")) : str(row.get("к6"));
        return "документ найден (" + document + "), " + WITHOUT_CONTRACT_NOTE;
    }

    /**
     * Спецификация строки подтверждает сумму этапа: акт/УПД не найден, сумма есть в спецификации и в комплекте
     * вообще нет актов/УПД этого договора (Комплекты 1 и 6 Егоровой). Если акты договора в комплекте есть,
     * ненайденный документ строки — исход 1 письма, спецификация его не заменяет.
     */
    private static boolean specConfirmsAmount(Linked linked) {
        String amount = str(linked.upd().get("сумма"));
        return !YES.equals(str(linked.upd().get(CONTRACT_DOCS))) && !amount.isEmpty()
                && linked.specs().stream().anyMatch(spec -> specAmountFits(spec, amount));
    }

    /** Технологии критериев, для которых в форме есть колонка, но участник не поставил «да». */
    @SuppressWarnings("unchecked")
    private static List<String> notClaimed(Map<String, Object> upd, Form3Ops.Criteria criteria) {
        List<String> headers = (List<String>) upd.getOrDefault("колонки_технологий", List.of());
        List<String> claimed = (List<String>) upd.getOrDefault("заявлено", List.of());
        List<String> out = new ArrayList<>();
        for (String tech : criteria.allTechnologies()) {
            boolean hasColumn = headers.stream().anyMatch(h -> Form3Ops.containsTechnology(h, tech));
            boolean claimedInForm = claimed.stream().anyMatch(h -> Form3Ops.containsTechnology(h, tech));
            if (hasColumn && !claimedInForm) {
                out.add(tech);
            }
        }
        return out;
    }

    /** В форме есть колонки платформ из критериев (iOS/Android/…), и участник не заявил ни одну. */
    private static boolean platformsNotClaimed(Map<String, Object> upd, Form3Ops.Criteria criteria) {
        List<String> platforms = criteria.allTechnologies().stream()
                .filter(t -> PLATFORM.matcher(t).matches()).toList();
        if (platforms.isEmpty()) {
            return false;
        }
        return notClaimed(upd, criteria).containsAll(platforms);
    }

    /** Мобильная разработка доказана лишь упоминанием платформы (iOS/Android) без слов о мобильном приложении. */
    private static boolean weakMobile(Linked linked, String mobile) {
        if (!YES.equals(mobile)) {
            return false;
        }
        List<Map<String, Object>> docs = new ArrayList<>(linked.specs());
        docs.addAll(linked.reports());
        docs.add(linked.upd());
        return docs.stream().noneMatch(doc -> MOBILE_WORDS.matcher(str(doc.get("текст"))).find());
    }

    /** Где найдена каждая технология критериев: договор / спецификация / акт / отчёт. */
    private static Map<String, Set<String>> technologyPlaces(Linked linked, List<String> required) {
        Map<String, Set<String>> places = new LinkedHashMap<>();
        for (String tech : required) {
            Set<String> found = new LinkedHashSet<>();
            if (anyContains(linked.contracts(), tech)) {
                found.add("договор");
            }
            if (anyContains(linked.specs(), tech)) {
                found.add("спецификация");
            }
            if (Form3Ops.containsTechnology(str(linked.upd().get("текст")), tech)) {
                found.add("акт");
            }
            if (anyContains(linked.reports(), tech)) {
                found.add("отчёт");
            }
            places.put(tech, found);
        }
        return places;
    }

    /**
     * Технологии договора не доказывают технологию строки, если спецификация сама называет роли исполнителей с технологиями
     * («Главный разработчик GreenPlum»): рамочный договор перечисляет ставки всех ролей, а работы заказа — только названные
     * в спецификации (Комплект 9 Егоровой: Python есть только в ставках договора 5028839, спецификация 5491012 называет
     * GreenPlum — «Технологии не найдены»). После писем Егоровой 16.09.2026 договор не входит в доказательные документы
     * ({@link #evidence}) и при спецификации без ролей, поэтому на столбцы технологий и зачёт фильтр не влияет — правило
     * сохранено и объясняет незачёт в аудите ({@link #roleNote}).
     *
     * @param techPlaces места технологий строки
     * @param linked     документы строки
     * @return места технологий для доказательства (копия без «договор», если спецификация называет роли)
     */
    private static Map<String, Set<String>> withoutContractWhenSpecNamesRoles(Map<String, Set<String>> techPlaces, Linked linked) {
        if (specRoleTechnologies(linked).isEmpty()) {
            return techPlaces;
        }
        Map<String, Set<String>> filtered = new LinkedHashMap<>();
        for (Map.Entry<String, Set<String>> e : techPlaces.entrySet()) {
            Set<String> places = new LinkedHashSet<>(e.getValue());
            places.remove("договор");
            filtered.put(e.getKey(), places);
        }
        return filtered;
    }

    /** Технологии из ролей исполнителей в спецификациях строки («разработчик GreenPlum» → GreenPlum). */
    private static Set<String> specRoleTechnologies(Linked linked) {
        Set<String> techs = new LinkedHashSet<>();
        for (Map<String, Object> spec : linked.specs()) {
            Matcher m = ROLE_TECH.matcher(str(spec.get("текст")));
            while (m.find()) {
                techs.add(m.group(1));
            }
        }
        return techs;
    }

    /**
     * Пояснение аудита о договоре строки: у нерамочного договора — пометка {@link #NON_FRAMEWORK_NOTE} (технологии договора
     * засчитаны, пояснение «только в договоре» не ставится), у остальных — {@link #contractOnlyNote}.
     */
    private static String contractNote(Linked linked, List<String> reasons, Map<String, Set<String>> techPlaces) {
        return linked.contractEvidence() ? "; " + NON_FRAMEWORK_NOTE : contractOnlyNote(reasons, techPlaces);
    }

    /**
     * Пояснение аудита: ни одной требуемой технологии нет в спецификации и акте, а в договоре есть — опыт не засчитан
     * (зачёт только по спецификации/акту; закупщик увидит технологии договора в к16 и разберётся сам).
     */
    private static String contractOnlyNote(List<String> reasons, Map<String, Set<String>> techPlaces) {
        List<String> techs = techPlaces.entrySet().stream().filter(e -> e.getValue().contains("договор")).map(Map.Entry::getKey).toList();
        return !reasons.contains(REASON_NO_TECH) || techs.isEmpty() ? ""
                : "; технологии найдены только в договоре (" + String.join(", ", techs) + ") — в спецификации и акте нет, опыт не засчитан";
    }

    /**
     * Пояснение аудита: технология найдена только в договоре, а спецификация называет другие роли. После писем Егоровой
     * 16.09.2026 договор технологию не засчитывает вовсе, правило ролей для зачёта ничего не меняет и оставлено пояснением.
     */
    private static String roleNote(Map<String, Set<String>> techPlaces, Linked linked) {
        Set<String> roles = specRoleTechnologies(linked);
        boolean contractOnly = techPlaces.values().stream().anyMatch(p -> p.size() == 1 && p.contains("договор"));
        return roles.isEmpty() || !contractOnly ? ""
                : "; технологии только из договора не засчитываются: спецификация называет роли исполнителей (" + String.join(", ", roles) + ")";
    }

    private static boolean anyContains(List<Map<String, Object>> docs, String tech) {
        for (Map<String, Object> doc : docs) {
            if (Form3Ops.containsTechnology(str(doc.get("текст")), tech)) {
                return true;
            }
        }
        return false;
    }

    /** к18: документ не найден или не идентифицирован — причина вместо технологий, иначе технологии, подтверждённые актом. */
    private static String actColumn(List<String> reasons, Map<String, Set<String>> techPlaces) {
        for (String reason : List.of(REASON_NO_DOCS, REASON_UNIDENTIFIED)) {
            if (reasons.contains(reason)) {
                return reason;
            }
        }
        return placeLabel(techPlaces, "акт");
    }

    /** «да: Java, Python» — технологии, подтверждённые в документах этого типа, иначе «нет». */
    private static String placeLabel(Map<String, Set<String>> techPlaces, String place) {
        List<String> techs = new ArrayList<>();
        for (Map.Entry<String, Set<String>> e : techPlaces.entrySet()) {
            if (e.getValue().contains(place)) {
                techs.add(e.getKey());
            }
        }
        return techs.isEmpty() ? NO : YES + ": " + String.join(", ", techs);
    }

    /**
     * Мобильная разработка по текстам спецификаций/заявок, отчётов и акта/УПД строки (договор не смотрим — он рамочный);
     * если в форме есть колонки платформ (iOS/Android) и участник ни одну не заявил — «нет» (разметка Егоровой, Комплект 3).
     */
    private static String mobileVerdict(Linked linked, Form3Ops.Criteria criteria) {
        if (platformsNotClaimed(linked.upd(), criteria)) {
            return NO;
        }
        List<Map<String, Object>> docs = new ArrayList<>(linked.specs());
        docs.addAll(linked.reports());
        docs.add(linked.upd());
        for (Map<String, Object> doc : docs) {
            if (MOBILE.matcher(str(doc.get("текст"))).find()) {
                return YES;
            }
        }
        return NO;
    }

    /**
     * Только тестирование: в предмете спецификации (или отчёта, если спецификации
     * нет) есть тестирование и нет разработки/модификации/внедрения.
     */
    private static String testingOnlyVerdict(Linked linked) {
        List<Map<String, Object>> docs = linked.specs().isEmpty() ? linked.reports() : linked.specs();
        if (docs.isEmpty()) {
            return NO_DATA;
        }
        boolean testingOnly = true;
        for (Map<String, Object> doc : docs) {
            String subject = subject(str(doc.get("текст")));
            if (!TESTING.matcher(subject).find() || DEVELOPMENT.matcher(subject).find()) {
                testingOnly = false;
            }
        }
        return testingOnly ? YES : NO;
    }

    /** Предмет документа: фраза после «Предмет …:», иначе начало текста. */
    private static String subject(String text) {
        Matcher m = SUBJECT.matcher(text);
        if (m.find()) {
            return m.group(1);
        }
        return text.length() > SUBJECT_LIMIT ? text.substring(0, SUBJECT_LIMIT) : text;
    }

    private static String contractLabel(Map<String, Object> upd) {
        String number = str(upd.get("договор"));
        if (number.isEmpty()) {
            return NO_DATA;
        }
        String date = str(upd.get("договор_дата"));
        return "договор " + number + (date.isEmpty() ? "" : " от " + date);
    }

    private static String specLabel(List<Map<String, Object>> candidates) {
        if (candidates.isEmpty()) {
            return "не сопоставлена";
        }
        List<String> labels = new ArrayList<>();
        for (Map<String, Object> spec : candidates) {
            String date = str(spec.get("дата"));
            String kind = Form3Acts.KIND_ORDER.equals(spec.get("вид")) ? "заявка " : "";
            labels.add(kind + spec.get("номер") + (date.isEmpty() ? "" : " от " + date));
        }
        String joined = String.join(" или ", labels);
        return candidates.size() == 1 ? joined
                : joined + " (сумма этапа совпадает в нескольких спецификациях — выбрать по форме)";
    }

    /** «да»/«нет» по дате акта внутри периода; без дат в критериях — «проверить вручную». */
    static String periodVerdict(String actDate, LocalDate from, LocalDate to) {
        if (from == null || to == null) {
            return MANUAL;
        }
        LocalDate act = Form3Ops.parseDate(actDate);
        if (act == null) {
            return MANUAL;
        }
        return !act.isBefore(from) && !act.isAfter(to) ? YES : NO;
    }

    private static String audit(Linked linked, Form3Ops.Criteria criteria, Map<String, Set<String>> techPlaces,
                                Map<String, Set<String>> proven, String qual, String method, String buyer, String mobile) {
        List<String> parts = new ArrayList<>();
        parts.add("период квалификации: " + periodNote(qual, criteria.qualFrom, criteria.qualTo));
        parts.add("период методики: " + periodNote(method, criteria.methodFrom, criteria.methodTo));
        for (Map.Entry<String, List<String>> lot : criteria.lots.entrySet()) {
            List<String> hit = new ArrayList<>();
            List<String> miss = new ArrayList<>();
            for (String tech : lot.getValue()) {
                Set<String> places = techPlaces.getOrDefault(tech, Set.of());
                (places.isEmpty() ? miss : hit).add(places.isEmpty() ? tech : tech + " (" + String.join(", ", places) + ")");
            }
            parts.add("лот " + lot.getKey() + ": " + (hit.isEmpty() ? "ничего не найдено" : "найдено " + String.join(", ", hit))
                    + (miss.isEmpty() ? "" : "; не найдено " + String.join(", ", miss)));
        }
        parts.add("заказчик: " + buyer);
        parts.add("технологии засчитываются по спецификации/заявке и акту/УПД (отчёт к УПД — по параметру «отчёт_как_акт»), договор — только "
                + "графа «подтверждено в Договоре» (у нерамочного договора без спецификаций — наравне со спецификацией); "
                + "мобильная разработка — по спецификации/заявке, акту и отчёту");
        parts.add("документы строки: " + actNote(linked.upd()) + "договор " + linked.contracts().size() + ", спецификаций "
                + linked.specs().size() + ", отчётов " + linked.reports().size());
        for (String note : List.of(Form3Match.NOTE, "подпись_примечание", "сумма_примечание")) {
            if (!str(linked.upd().get(note)).isEmpty()) {
                parts.add(str(linked.upd().get(note)));
            }
        }
        List<String> claimed = claimed(linked.upd(), criteria, proven);
        if (!claimed.isEmpty()) {
            parts.add("заявлено участником в форме, в спецификации/акте не подтверждено: " + String.join(", ", claimed));
        }
        parts.addAll(extraNotes(linked, criteria, mobile, proven));
        if (linked.specs().size() > 1) {
            parts.add("спецификация: несколько кандидатов по сумме этапа");
        }
        if (!linked.specNote().isEmpty()) {
            parts.add(linked.specNote());
        }
        if (criteria.mobileProcurement) {
            parts.add("закупка мобильной разработки: мобильная разработка не стоп-фактор");
        }
        return String.join("; ", parts);
    }

    /**
     * Пометки аудита: технологии, найденные в спецификации/акте, но не заявленные участником в форме (на столбцы
     * технологий не влияет — только расхождение с формой), зачёт по спецификации без акта, слабая мобильность.
     */
    private static List<String> extraNotes(Linked linked, Form3Ops.Criteria criteria, String mobile, Map<String, Set<String>> proven) {
        List<String> notes = new ArrayList<>();
        List<String> notClaimed = notClaimed(linked.upd(), criteria).stream().filter(tech -> !proven.getOrDefault(tech, Set.of()).isEmpty()).toList();
        if (!notClaimed.isEmpty()) {
            notes.add("по форме участника не заявлено, но найдено в спецификации/акте: " + String.join(", ", notClaimed));
        }
        if ("форма".equals(linked.upd().get("вид")) && specConfirmsAmount(linked)) {
            notes.add("акт/УПД не найден, сумма этапа подтверждена спецификацией");
        }
        if (platformsNotClaimed(linked.upd(), criteria)) {
            notes.add("мобильная разработка по форме не заявлена (платформы «нет») — не засчитывается");
        }
        if (weakMobile(linked, mobile)) {
            notes.add("мобильная разработка — только по упоминанию платформы (iOS/Android), без слов о мобильном приложении: на проверку агенту");
        }
        return notes;
    }

    private static String actNote(Map<String, Object> upd) {
        String kind = str(upd.get("вид"));
        if (YES.equals(str(upd.get(UNIDENTIFIED)))) {
            return "акт «" + upd.get("файл") + "» не идентифицирован (правило 3); ";
        }
        if ("форма".equals(kind)) {
            return ACT_NOT_FOUND + "; ";
        }
        return Form3Acts.KIND_ACT.equals(kind) ? "акт «" + upd.get("файл") + "», " : "";
    }

    /** Технологии, отмеченные участником «да» в форме, но не найденные в доказательных документах строки (без договора). */
    @SuppressWarnings("unchecked")
    private static List<String> claimed(Map<String, Object> upd, Form3Ops.Criteria criteria,
                                        Map<String, Set<String>> techPlaces) {
        List<String> claimed = new ArrayList<>();
        List<String> headers = (List<String>) upd.getOrDefault("заявлено", List.of());
        for (String tech : criteria.allTechnologies()) {
            boolean claimedInForm = headers.stream().anyMatch(h -> Form3Ops.containsTechnology(h, tech));
            if (claimedInForm && techPlaces.getOrDefault(tech, Set.of()).isEmpty()) {
                claimed.add(tech);
            }
        }
        return claimed;
    }

    private static String periodNote(String verdict, LocalDate from, LocalDate to) {
        if (DASH.equals(verdict)) {
            return "квалификационные требования к периоду не предъявляются (в критериях нет дат)";
        }
        if (MANUAL.equals(verdict)) {
            return "проверить вручную (в критериях нет дат периода)";
        }
        return verdict + " (с " + from.format(Form3Ops.DATE) + " по " + to.format(Form3Ops.DATE) + ")";
    }
}
