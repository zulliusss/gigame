package ru.sber.cs.ai.gigame.exception;

/**
 * Запрос агентного цикла (tool-цикл GigaChat) больше контекстного окна модели (HTTP 422 «context too long») и после
 * сжатия ответов инструментов либо сжимать нечего. Узел агента на эту ошибку не падает: финальный ответ строится без
 * инструментов по собранным наблюдениям, результат помечается как возможно неполный.
 */
public class AgentContextOverflowException extends GigaChatException {

    private final int requested;
    private final int maximum;

    /**
     * Исключение с размерами запроса из ответа модели.
     *
     * @param requested запрошено токенов (0 — не указано в ответе)
     * @param maximum   максимум контекста модели, токенов (0 — не указано в ответе)
     * @param cause     исходная ошибка вызова модели
     */
    public AgentContextOverflowException(int requested, int maximum, Throwable cause) {
        super("Контекст агента больше окна модели (" + limits(requested, maximum) + ")", cause);
        this.requested = requested;
        this.maximum = maximum;
    }

    /**
     * Запрошено токенов.
     *
     * @return число токенов запроса (0 — не указано)
     */
    public int getRequested() {
        return requested;
    }

    /**
     * Максимум контекста модели.
     *
     * @return число токенов (0 — не указано)
     */
    public int getMaximum() {
        return maximum;
    }

    /**
     * Размеры превышения для текста пометки.
     *
     * @return «запрос N токенов при максимуме M» либо общая формулировка, если размеры не указаны
     */
    public String limits() {
        return limits(requested, maximum);
    }

    /**
     * Размеры превышения для текста пометки или уведомления.
     *
     * @param tokens запрошено токенов (0 — не указано)
     * @param window максимум контекста модели, токенов (0 — не указано)
     * @return «запрос N токенов при максимуме M» либо общая формулировка, если размеры не указаны
     */
    public static String limits(int tokens, int window) {
        if (tokens > 0 && window > 0) {
            return "запрос " + tokens + " токенов при максимуме " + window;
        }
        return tokens > 0 ? "запрос " + tokens + " токенов" : "превышено контекстное окно модели";
    }
}
