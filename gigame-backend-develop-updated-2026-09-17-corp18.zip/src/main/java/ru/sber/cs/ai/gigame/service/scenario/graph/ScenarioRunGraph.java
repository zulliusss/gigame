package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.tuple.Pair;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;

@Getter
public class ScenarioRunGraph {
    /** Причина остановки прогона по умолчанию — явная остановка пользователем. */
    public static final String CANCELLED_BY_USER = "Прогон остановлен пользователем";
    /** Узлы в порядке {@code graphData.nodes()} (LinkedHashMap — порядок обхода детерминирован). */
    private final Map<String, ScenarioRunNode> nodeMap;
    private final Map<Pair<String, String>, EdgeDataDto> edgeMap = new HashMap<>();
    private final ScenarioRunNode startNode;
    private final Map<String, ScenarioRunDoc> docMap;
    private final Map<String, float[]> embeddingCache;
    /** Идентификаторы прогона — для памяти агента (уроки, вопросы). */
    @Setter
    private UUID runId;
    @Setter
    private UUID scenarioId;
    /** Запускающий пользователь — его личные общие уроки применяются к прогону. */
    @Setter
    private String runnerUserId;
    /** Запрошена остановка прогона: узлы и инструменты агента проверяют флаг. */
    private final AtomicBoolean cancelRequested = new AtomicBoolean();
    /**
     * Причина остановки — текст ошибки узла и шага: {@link #CANCELLED_BY_USER} либо
     * {@code ScenarioEngine.RESTART_REASON} при graceful-остановке сервиса. Записывается до взвода
     * {@link #cancelRequested}: узел, ждущий флага, уже видит причину.
     */
    private final AtomicReference<String> cancelReason = new AtomicReference<>();
    /** Метки узлов, упавших при on_error=continue/branch: прогон с ними не считается успешным. */
    private final List<String> failedNodeLabels = Collections.synchronizedList(new ArrayList<>());

    public ScenarioRunGraph(GraphDataDto graphData) {
        AtomicInteger idx = new AtomicInteger();
        // LinkedHashMap: порядок узлов и документов — порядок JSON графа и загрузки (DOC_1..DOC_n),
        // а не хеш-порядок HashMap, который менял docList детей входа, группировки и своды
        this.nodeMap = graphData.nodes().stream()
                .collect(Collectors.toMap(
                        NodeDto::id,
                        node -> buildNode(idx.incrementAndGet(), node, this),
                        (first, second) -> {
                            throw new IllegalStateException("Дубликат идентификатора узла: " + first.getId());
                        },
                        LinkedHashMap::new));
        for (var edge : graphData.edges()) {
            String src = edge.source();
            String tgt = edge.target();
            nodeMap.get(src).getChildNodeList().add(nodeMap.get(tgt));
            nodeMap.get(tgt).getParentNodeList().add(nodeMap.get(src));
            var edgeData = edge.data();
            edgeMap.put(Pair.of(src, tgt), edgeData);
        }
        // стартовый узел — «Вход» (validateGraph движка гарантирует единственный корень);
        // в графах без входа (под-графы тестов) — первый узел без родителей в порядке JSON
        startNode = nodeMap.values().stream()
                .filter(node -> node.getType() == ScenarioNodeType.INPUT_NODE)
                .findFirst()
                .orElseGet(() -> nodeMap.values().stream()
                        .filter(node -> node.getParentNodeList().isEmpty())
                        .findFirst().orElseThrow());
        docMap = new LinkedHashMap<>();
        embeddingCache = new HashMap<>();
    }

    /**
     * Индекс узла 1-базный: он показывается пользователю как «шаг N из M»
     * в событиях node_status.
     */
    private ScenarioRunNode buildNode(int index, NodeDto node, ScenarioRunGraph graph) {
        return ScenarioRunNode.fromDto(index, node, graph);
    }

    public void addDocs(List<String> documentTextList, List<String> filenameList) {
        if (documentTextList != null && !documentTextList.isEmpty()) {
            for (int i = 0; i < documentTextList.size(); i++) {
                docMap.put("DOC_" + (i + 1), new ScenarioRunDoc(filenameList.get(i), documentTextList.get(i)));
            }
        }
    }

    /**
     * Кладёт исходный документ под явным ключом (без перенумерации, в отличие
     * от {@link #addDocs}). Нужен возобновлению прогона: документ обязан
     * вернуться под своей исходной меткой DOC_i, иначе классы документов
     * и выборки по docClass достаются чужим текстам.
     *
     * @param docKey   исходная метка документа (например, DOC_3)
     * @param filename имя файла
     * @param text     текст документа
     */
    public void putDoc(String docKey, String filename, String text) {
        docMap.put(docKey, new ScenarioRunDoc(filename, text));
    }

    public boolean isCancelRequested() {
        return cancelRequested.get();
    }

    /**
     * Прерывает работу узла, если запрошена остановка прогона: циклы по документам,
     * элементам списка и группам проверяют флаг перед каждой итерацией.
     *
     * @throws ScenarioException если остановка запрошена
     */
    public void checkNotCancelled() {
        if (cancelRequested.get()) {
            throw new ScenarioException(getCancelReason());
        }
    }

    /**
     * Причина остановки прогона (текст ошибки узла и шага).
     *
     * @return причина; до запроса остановки — {@link #CANCELLED_BY_USER}
     */
    public String getCancelReason() {
        String reason = cancelReason.get();
        return reason == null ? CANCELLED_BY_USER : reason;
    }

    /**
     * Фиксирует узел, упавший при on_error=continue/branch: по этому списку
     * движок завершает прогон статусом FAILED вместо «тихого успеха».
     *
     * @param label метка упавшего узла
     */
    public void addFailedNode(String label) {
        failedNodeLabels.add(label);
    }

    /**
     * Узлы в топологическом порядке (алгоритм Кана, как {@code topologicalSort} движка):
     * корни — в порядке {@link #getNodeMap()} ({@code graphData.nodes()}), далее узлы
     * в порядке, в котором рёбра графа делают их готовыми. Порядок планирования волн
     * одинаков от прогона к прогону и не зависит от перечисления узлов в JSON сценария.
     *
     * @return узлы графа в детерминированном топологическом порядке
     */
    public List<ScenarioRunNode> nodesInTopologicalOrder() {
        Map<ScenarioRunNode, Integer> inDegree = new LinkedHashMap<>();
        for (var node : nodeMap.values()) {
            inDegree.put(node, node.getParentNodeList().size());
        }
        Deque<ScenarioRunNode> queue = new ArrayDeque<>();
        for (var entry : inDegree.entrySet()) {
            if (entry.getValue() == 0) {
                queue.add(entry.getKey());
            }
        }
        List<ScenarioRunNode> ordered = new ArrayList<>();
        while (!queue.isEmpty()) {
            var node = queue.poll();
            ordered.add(node);
            for (var child : node.getChildNodeList()) {
                if (inDegree.merge(child, -1, Integer::sum) == 0) {
                    queue.add(child);
                }
            }
        }
        // узлы вне порядка (цикл — граф уже отвергла валидация) дописываются, чтобы ничего не потерять
        for (var node : nodeMap.values()) {
            if (!ordered.contains(node)) {
                ordered.add(node);
            }
        }
        return ordered;
    }

    public void requestCancel() {
        requestCancel(CANCELLED_BY_USER);
    }

    /**
     * Запрашивает остановку прогона с причиной, которая станет текстом ошибки узла.
     * Первая причина сохраняется: повторный запрос её не меняет.
     *
     * @param reason причина остановки
     */
    public void requestCancel(String reason) {
        // сначала причина, затем флаг: узел, ждущий остановки, не должен увидеть флаг без причины
        cancelReason.compareAndSet(null, reason == null || reason.isBlank() ? CANCELLED_BY_USER : reason);
        cancelRequested.set(true);
    }

    /**
     * Сохраняет рабочий файл агента (write_file) в документы прогона:
     * последующие агент-узлы видят его инструментами. Повторная запись под
     * тем же именем обновляет файл; имя исходного документа занять нельзя.
     *
     * @param filename имя рабочего файла
     * @param text     содержимое
     * @return {@code null} при успехе, иначе текст ошибки
     */
    public synchronized String addWorkingDoc(String filename, String text) {
        for (var entry : docMap.entrySet()) {
            if (entry.getValue().getFilename().equals(filename)) {
                if (!entry.getValue().isWorkNote()) {
                    return "Имя занято исходным документом прогона — выбери другое.";
                }
                entry.setValue(new ScenarioRunDoc(filename, text, true));
                return null;
            }
        }
        docMap.put("WORK_" + (docMap.size() + 1), new ScenarioRunDoc(filename, text, true));
        return null;
    }
}
