package ru.sber.cs.ai.gigame.service.scenario.executor;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.service.AgentContextBudget;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;

@Component
public class ScenarioExecutorFactory {

    private final GigaChatClient gigaChatClient;
    private final EmbeddingService embeddingService;
    /**
     * Ленивая ссылка на движок (для узла «Под-сценарий»):
     * прямая инъекция невозможна — движок сам использует фабрику.
     */
    private final ObjectProvider<ScenarioEngine> engineProvider;
    @Value("${app.embedding.text-max-length:800}")
    private int ragQueryMaxLength;
    @Value("${app.processing-node.cache-short-query-length:200}")
    private int cacheShortQueryLength;
    @Value("${app.loop-node.delay-between-iterations:1000}")
    private int delayBetweenIterations;
    @Value("${app.loop-node.classify-head-chars:5000}")
    private int classifyHeadChars;
    @Value("${app.loop-node.classify-tail-chars:2000}")
    private int classifyTailChars;
    @Value("${app.chat.document-char-limit:200000}")
    private int docCharLimit;
    /**
     * Параллельность LLM-вызовов групп в processing-узле режима group
     * (env {@code SCENARIO_GROUP_PARALLELISM}). 1 — последовательно (как раньше);
     * при больших наборах (100+ групп) ускоряет прогон кратно значению,
     * ограничение — квоты одновременных запросов GigaChat.
     */
    @Value("${app.scenario.group-parallelism:1}")
    private int groupParallelism;
    /** Таймаут одного поиска пользовательским regex, мс (см. {@link SafeRegex}). */
    @Value("${app.scenario.regex-timeout-millis:5000}")
    private long regexTimeoutMillis;
    /** Предел длины результата одной операции узла «Трансформация». */
    @Value("${app.scenario.max-transform-chars:5000000}")
    private int maxTransformChars;
    /** Предел элементов цикла по списку. */
    @Value("${app.scenario.loop-max-items:1000}")
    private int loopMaxItems;
    /** Бюджет контекста агента, токенов: доля на задание агента — {@link AgentContextBudget#TASK_SHARE}. */
    @Value("${app.agent.max-context-tokens:100000}")
    private int agentMaxContextTokens = AgentContextBudget.DEFAULT_MAX_CONTEXT_TOKENS;
    /** Символов на токен в оценке размера контекста агента. */
    @Value("${app.agent.chars-per-token:3.0}")
    private double agentCharsPerToken = AgentContextBudget.DEFAULT_CHARS_PER_TOKEN;
    /** Бюджет описаний функций агентного запроса, токенов: сверх него инструменты передаются по приоритету. */
    @Value("${app.agent.max-functions-tokens:3500}")
    private int agentMaxFunctionsTokens = AgentDocumentTools.DEFAULT_MAX_FUNCTIONS_TOKENS;

    /** Память агента (уроки/планы/вопросы); может отсутствовать в тестах. */
    private final ObjectProvider<AgentMemoryService> agentMemoryProvider;

    /** Документы баз знаний — для структурного индекса нормативки (может отсутствовать в тестах). */
    private final ObjectProvider<KBDocumentRepository> kbDocumentProvider;

    public ScenarioExecutorFactory(GigaChatClient gigaChatClient,
                                   EmbeddingService embeddingService,
                                   ObjectProvider<ScenarioEngine> engineProvider,
                                   ObjectProvider<AgentMemoryService> agentMemoryProvider,
                                   ObjectProvider<KBDocumentRepository> kbDocumentProvider) {
        this.gigaChatClient = gigaChatClient;
        this.embeddingService = embeddingService;
        this.engineProvider = engineProvider;
        this.agentMemoryProvider = agentMemoryProvider;
        this.kbDocumentProvider = kbDocumentProvider;
    }

    /**
     * Применяет настройки к статическим защитам: таймаут пользовательских regex
     * и предел значения выражения в промпте (равен пределу текста документа).
     */
    @PostConstruct
    void applyLimits() {
        SafeRegex.setTimeoutMillis(regexTimeoutMillis);
        ExpressionResolver.setValueLimit(docCharLimit);
    }

    /**
     * Загрузчик структурного индекса нормативки по id базы знаний: имя файла →
     * текст всех документов базы (см. {@link NormIndex}).
     */
    Function<UUID, NormIndex> normIndexLoader() {
        return kbId -> {
            KBDocumentRepository repo = kbDocumentProvider == null ? null : kbDocumentProvider.getIfAvailable();
            Map<String, String> docs = new LinkedHashMap<>();
            if (repo != null && kbId != null) {
                for (KBDocument d : repo.findByKnowledgeBaseIdWithDocument(kbId)) {
                    if (d.getDocument() != null && d.getDocument().getFilename() != null) {
                        docs.put(d.getDocument().getFilename(), d.getDocument().getExtractedText());
                    }
                }
            }
            return NormIndex.build(docs);
        };
    }

    public AbstractScenarioExecutor createExecutor(ScenarioRunNode node) {
        return switch (node.getType()) {
            case INPUT_NODE -> new ScenarioExecutorInputNode(node);
            case OUTPUT_NODE -> new ScenarioExecutorOutputNode(node);
            case PROCESSING_NODE -> {
                var executor = new ScenarioExecutorProcessingNode(node, gigaChatClient, embeddingService);
                executor.setConfiguration(ragQueryMaxLength, cacheShortQueryLength);
                executor.setDocCharLimit(docCharLimit);
                executor.setGroupParallelism(groupParallelism);
                executor.setAgentContextBudget(new AgentContextBudget(agentMaxContextTokens, agentCharsPerToken));
                executor.setMaxFunctionsTokens(agentMaxFunctionsTokens);
                executor.setAgentMemory(agentMemoryProvider != null
                        ? agentMemoryProvider.getIfAvailable() : null);
                executor.setNormIndexLoader(normIndexLoader());
                yield executor;
            }
            case IF_NODE -> new ScenarioExecutorIfNode(node);
            case SWITCH_NODE -> new ScenarioExecutorSwitchNode(node);
            case CALC_NODE -> new ScenarioExecutorCalcNode(node);
            case AGGREGATE_NODE -> new ScenarioExecutorAggregateNode(node);
            case TRANSFORM_NODE -> {
                var executor = new ScenarioExecutorTransformNode(node);
                executor.setNormIndexLoader(normIndexLoader());
                executor.setMaxTransformChars(maxTransformChars);
                yield executor;
            }
            case SUBSCENARIO_NODE -> new ScenarioExecutorSubscenarioNode(node, engineProvider.getObject());
            case CONTROL_NODE -> new ScenarioExecutorControlNode(node);
            case WAIT_NODE -> new ScenarioExecutorWaitNode(node);
            case LOOP_NODE -> {
                var executor = new ScenarioExecutorLoopNode(node, gigaChatClient);
                executor.setDelayBetweenIterations(delayBetweenIterations);
                executor.setClassifyLimits(classifyHeadChars, classifyTailChars);
                executor.setDocCharLimit(docCharLimit);
                executor.setMaxItems(loopMaxItems);
                yield executor;
            }
            // Добавьте другие типы по мере необходимости
            default -> throw new IllegalArgumentException("Unknown node type: " + node.getType());
        };
    }
}