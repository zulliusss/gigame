package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Кодовые операции Формы 3 (опыт участника закупки) без участия LLM.
 * <p>
 * «реестр_документов» разбирает тексты комплекта: УПД (номер, дата, продавец,
 * покупатель, договор, сумма «Всего к оплате», дата приёмки и подпись
 * заказчика), спецификации (номер, договор, дата подписания, суммы, текст),
 * договоры (номер, дата, текст) и отчёты о выполненных работах (спецификация,
 * договор, номера, суммы, текст). «строки_формы3» по реестру и выверенным
 * критериям Шага 1 строит строки формы — см. {@link Form3Rows}. Форматы взяты
 * с УПД/спецификаций ЭДО СберКорус.
 */
final class Form3Ops {

    static final ObjectMapper MAPPER = new ObjectMapper();
    static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    /** Текст документа в реестре: договор на сотню страниц несёт требования к ролям (технологии) в конце. */
    private static final int TEXT_LIMIT = 400000;
    private static final int MAX_SPEC_NUMBER = 8;

    /** Заголовок счёта-фактуры УПД; номер бывает не указан: «Счет-фактура N б.н. от 24.03.2025». */
    private static final Pattern UPD_HEAD = Pattern.compile(
            "Сч[её]т-?фактура\\s*[N№]\\s*([бБ]\\s*[./\\\\-]?\\s*[нН]\\.?|\\d+)\\s+от\\s+(\\d{2}\\.\\d{2}\\.\\d{4})");
    /** Дата приёмки печатной формы Контур (Диадок): «Дата получения (приемки) 29.05.2025 (18)». */
    private static final Pattern UPD_ACCEPT_NUMERIC = Pattern.compile("Дата получения \\(при[её]мки\\)\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*[\\[(]18[\\])]");
    /**
     * Титул покупателя Контур (Диадок) заполнен и подписан: дата приёмки [18] и «Электронная подпись» ответственного
     * лица покупателя до [21] — так видна подпись заказчика, когда штамп ЭДО в PDF не имеет текстового слоя.
     */
    private static final Pattern UPD_BUYER_TITLE = Pattern.compile(
            "Дата получения \\(при[её]мки\\)\\s*\\d{2}\\.\\d{2}\\.\\d{4}\\s*\\(18\\)[\\s\\S]{0,400}?Электронная подпись[\\s\\S]{0,200}?\\(21\\)");
    /** Номер спецификации в информационном поле УПД СберКорус: «Дог 050005270341_AGR_Договор вн. №_5028839_от …» → 5270341. */
    private static final Pattern AGR_SPEC = Pattern.compile("Дог\\s*\\d*?(\\d{7})_AGR_");
    /** Договор в том же поле: «…_AGR_Договор вн. №_5028839_от 07.08.2024». */
    private static final Pattern AGR_CONTRACT = Pattern.compile("_AGR_Договор\\s*вн\\.\\s*№_(\\d{5,12})_от\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern UPD_SELLER = Pattern.compile("Продавец:\\s*(.+?)\\s*\\(2\\)");
    private static final Pattern UPD_BUYER = Pattern.compile("Покупатель:\\s*(.+?)\\s*\\(6\\)");
    private static final Pattern UPD_TOTAL = Pattern.compile(
            "Всего к оплате\\s*\\(9\\)((?:\\s*(?:[\\d ]+[,.]\\d{2}|×|без НДС|без налога|-))+)");
    /** Итог печатной формы СберКорус — целые рубли без копеек: «Всего к оплате (9) 4341149». */
    private static final Pattern UPD_TOTAL_WHOLE = Pattern.compile("Всего к оплате\\s*\\(9\\)\\s*(\\d{3,12})(?![\\d,.])");
    /** Подпись покупателя в штампе ЭДО: две и более подписи «Подпись соответствует файлу документа». */
    private static final int EDO_BOTH_SIDES = 2;
    private static final Pattern UPD_ACCEPT = Pattern.compile(
            "\"\\s*(\\d{1,2})\\s*\"\\s*([а-яё]+)\\s*(\\d{4})\\s*г\\.\\s*\\[18\\]");
    private static final Pattern UPD_BUYER_SIGN = Pattern.compile("Электронная подпись\\s+[А-ЯЁ][^\\[]{3,80}?\\[20\\]");
    static final Pattern CONTRACT_REF = Pattern.compile(
            "Договор[а-я]*\\s*№?\\s*(\\d{5,12})(?:[^\\n]{0,60}?от\\s*(\\d{2}\\.\\d{2}\\.\\d{4}))?");
    static final Pattern SPEC_REF = Pattern.compile("Спецификаци[а-я]*[^\\n№]{0,120}?№\\s*(\\d{6,8})");
    private static final Pattern SPEC_HEAD = Pattern.compile(Form3Acts.TYPE_LINE + "\\d?\\s*Спецификаци",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SPEC_CONTRACT = Pattern.compile("к\\s+Договору\\s*№?\\s*(\\d{5,12})");
    /** Заголовок договора в первых 60 знаках: «ДОГОВОР № …», «Рамочный Договор № …», «1 ДОГОВОР № …», «Тип документа: Договор». */
    private static final Pattern CONTRACT_HEAD = Pattern.compile(
            "^[\\s\\S]{0,60}?(?<![А-Яа-яЁё])(?<!к\\s)(?<!по\\s)Договор[а-яё]*\\s*№", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern REPORT_HEAD = Pattern.compile(Form3Acts.TYPE_LINE + "Отч[её]т\\s+о\\s+выполненн",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SIGN_STAMP = Pattern.compile("(\\d{2}\\.\\d{2}\\.\\d{4})\\s+\\d{2}:\\d{2}:\\d{2}");
    static final Pattern AMOUNT = Pattern.compile("(?<![\\d,.])(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?![\\d])");
    private static final Pattern FILE_NUMBER = Pattern.compile("(?<!\\d)(\\d{7,8})(?!\\d)");
    /** Имя файла печатной формы УПД в формате ФНС («ON_NSCHFDOPPR_…», «ON_NSCHFDOPPOK_…»). */
    private static final Pattern FNS_UPD_NAME = Pattern.compile("^ON_NSCHF", Pattern.CASE_INSENSITIVE);
    /** Поле реестра УПД: номер спецификации взят из пути к файлу, а не из текста документа. */
    static final String SPEC_BY_NAME = "спецификация_из_имени";
    /** Номер документа в распознанном тексте: «Реквизиты документа: № 4801685». */
    private static final Pattern OCR_NUMBER = Pattern.compile("(?:Реквизиты документа|Номер документа|Номер)[^\\n]{0,40}?№\\s*(\\d{6,8})(?!\\d)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Буквенно-цифровой номер договора («Договор № АБ-С-ИТ-2020», «№ CN_1090_IT_19_134108_037544» — МЕТРО). */
    static final Pattern CONTRACT_ALNUM = Pattern.compile("Договор[а-яё]*\\s*№\\s*([A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9/\\-_]{2,40})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Имя файла договора: «Договор Метро № CN_….pdf», «Договор 5028839 от 07.08.2024.pdf» (скан без заголовка в тексте). */
    private static final Pattern CONTRACT_NAME = Pattern.compile("^\\W*Договор(?![А-Яа-яЁё])", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Номер договора после «№» с предметом между словом «Договор» и знаком номера — распознанный скан МЕТРО:
     * «Договор по разработке программного обеспечения и услугам консультирования №\n\nCN 1090 1Т 19 134108 037544».
     * Берётся хвост строки после «№» (до конца строки), ключ сравнения — {@link Form3Rows#contractKey}.
     */
    private static final Pattern CONTRACT_NUMBER_LINE = Pattern.compile(
            "Договор[^\\n№]{0,120}?№\\s*([A-Za-zА-Яа-яЁё0-9][^\\n]{2,60})", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Заголовок договора с предметом до знака номера в первых 200 знаках распознанного текста (после строки страницы). */
    private static final Pattern CONTRACT_HEAD_LOOSE = Pattern.compile(
            "^[\\s\\S]{0,200}?(?<![А-Яа-яЁё])(?<!к\\s)(?<!по\\s)Договор\\s+(?:по|на|о|об)\\s[^\\n№]{0,120}?№", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern CONTRACT_SIGNED = Pattern.compile("Дата подписания:\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
    /** Номера заказов (ЗНЗО, заказ, заявка) — связка отчёта с УПД; ИНН/КПП и номера договоров не берутся. */
    static final Pattern ORDER_REF = Pattern.compile(
            "(?:ЗНЗО|[Зз]аказ[а-я]*|[Зз]аявк[а-я]*)\\s*(?:на\\s+\\S+\\s+)?№?\\s*(\\d{6,14})(?!\\d)");
    private static final Pattern REPORT_UPD = Pattern.compile("УПД\\s*№?\\s*0*(\\d{3,10})");
    /** Номер договора в договоре/отчёте: заголовок бывает в верхнем регистре («ДОГОВОР № …»). */
    private static final Pattern CONTRACT_REF_CI = Pattern.compile(CONTRACT_REF.pattern(),
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Методологии: упоминание в названии должности («Главный инженер DevOps») применение методологии не подтверждает. */
    private static final Pattern METHODOLOGY = Pattern.compile("^(DevOps|DevSecOps|Agile|Scrum|Kanban|Sbergile|ITIL|SAFe)$",
            Pattern.CASE_INSENSITIVE);
    private static final String ROLE_BEFORE =
            "(?<!(?:инженер|специалист|разработчик|архитектор|аналитик|тестировщик|engineer)\\s{1,3})";

    /** Общепринятые сокращения технологий: в документах «JavaScript» пишут «JS», «TypeScript» — «TS». */
    private static final Map<String, String> TECH_SYNONYMS = Map.ofEntries(
            Map.entry("javascript", "JS"), Map.entry("typescript", "TS"), Map.entry("kubernetes", "k8s"),
            Map.entry("postgresql", "Postgres"), Map.entry("golang", "Go"), Map.entry("python", "Py"),
            Map.entry("c#", "CSharp"), Map.entry("react", "ReactJS"), Map.entry("node.js", "NodeJS"));
    /** Альтернативы в значении технологии: «UniData или Tibco» — подходит любая из них. */
    private static final Pattern TECH_ALTERNATIVES = Pattern.compile("\\s+или\\s+", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Служебные слова значения технологии — не технологии: «и/или», «на», «в» есть почти в любом тексте. */
    private static final Set<String> TECH_STOP_WORDS = Set.of("или", "и", "с", "на", "в", "для");

    static final Map<String, String> MONTHS = Map.ofEntries(
            Map.entry("января", "01"), Map.entry("февраля", "02"), Map.entry("марта", "03"),
            Map.entry("апреля", "04"), Map.entry("мая", "05"), Map.entry("июня", "06"),
            Map.entry("июля", "07"), Map.entry("августа", "08"), Map.entry("сентября", "09"),
            Map.entry("октября", "10"), Map.entry("ноября", "11"), Map.entry("декабря", "12"));

    private Form3Ops() {
    }

    /** Документ комплекта: имя файла и текст. */
    record Source(String name, String text) {
    }

    // ------------------------------------------------------------------ реестр

    /**
     * Реестр документов комплекта в JSON: {@code {"упд": [...], "спецификации": [...],
     * "договоры": [...], "отчёты": [...], "акты": [...], "прочее": [...],
     * "не_разобраны": [{"файл", "причина"}]}}. Нечитаемые документы (маркер ручной
     * проверки: скан без OCR, битый файл, нераспакованный архив) не классифицируются. Заявки
     * (заказы к рамочному договору) лежат среди спецификаций с полем «вид»,
     * акты сдачи-приёмки без структуры УПД — отдельным списком (см. {@link Form3Acts}).
     *
     * @param sources документы комплекта
     * @return JSON реестра
     */
    static String registry(List<Source> sources) {
        List<Map<String, Object>> upds = new ArrayList<>();
        List<Map<String, Object>> specs = new ArrayList<>();
        List<Map<String, Object>> contracts = new ArrayList<>();
        List<Map<String, Object>> reports = new ArrayList<>();
        List<Map<String, Object>> acts = new ArrayList<>();
        List<Map<String, Object>> unreadable = new ArrayList<>();
        List<String> other = new ArrayList<>();
        for (Source source : sources) {
            String text = normalize(source.text());
            // распознанный скан начинается со служебной строки OCR — заголовок документа ищется после неё
            String head = Form3Acts.body(text);
            if (ScenarioRunDoc.isUnreadable(text)) {
                // маркер ручной проверки — не документ: раньше слово «акт» в имени делало из него акт с пустой суммой
                unreadable.add(unreadableEntry(source.name(), text));
            } else if (UPD_HEAD.matcher(text).find()) {
                upds.add(parseUpd(source.name(), text));
            } else if (REPORT_HEAD.matcher(head).find()) {
                reports.add(parseReport(source.name(), text));
            } else if (Form3Acts.isAct(source.name(), text)) {
                acts.add(Form3Acts.parseAct(source.name(), text));
            } else if (Form3Acts.isOrder(source.name(), text)) {
                specs.add(Form3Acts.parseOrder(source.name(), text));
            } else if (SPEC_HEAD.matcher(head).find() && (SPEC_REF.matcher(text).find() || OCR_NUMBER.matcher(text).find())) {
                specs.add(parseSpec(source.name(), text));
            } else if (CONTRACT_HEAD.matcher(head).find() || CONTRACT_HEAD_LOOSE.matcher(head).find()
                    || CONTRACT_SIGNED.matcher(text).find() || CONTRACT_NAME.matcher(Form3Acts.baseName(source.name())).find()) {
                // договор-скан (МЕТРО): распознанный текст начинается не с заголовка, вид виден по имени файла
                contracts.add(parseContract(source.name(), text));
            } else {
                other.add(source.name());
            }
        }
        Map<String, Object> registry = new LinkedHashMap<>();
        registry.put("упд", upds);
        registry.put("спецификации", specs);
        registry.put("договоры", contracts);
        registry.put("отчёты", reports);
        registry.put("акты", acts);
        registry.put("прочее", other);
        registry.put("не_разобраны", unreadable);
        return toJson(registry);
    }

    /** Запись реестра о документе, который не удалось разобрать: имя файла и причина из маркера. */
    private static Map<String, Object> unreadableEntry(String name, String text) {
        Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("файл", name);
        entry.put("причина", ScenarioRunDoc.unreadableReason(text));
        return entry;
    }

    /**
     * Нормализация текста ЭДО-документа: неразрывные пробелы, мягкие переносы,
     * возвраты каретки.
     */
    static String normalize(String text) {
        return text == null ? "" : text.replace('\u00A0', ' ').replace('\u2002', ' ').replace('\u2009', ' ').replace('\u202F', ' ')
                .replace("\u00AD", "").replace("\r", "");
    }

    private static Map<String, Object> parseUpd(String name, String text) {
        Map<String, Object> upd = new LinkedHashMap<>();
        upd.put("файл", name);
        Matcher head = UPD_HEAD.matcher(text);
        head.find();
        upd.put("номер", head.group(1));
        upd.put("дата", head.group(2));
        upd.put("продавец", firstGroup(UPD_SELLER, text));
        upd.put("покупатель", firstGroup(UPD_BUYER, text));
        Matcher contract = CONTRACT_REF.matcher(text);
        Matcher agreement = AGR_CONTRACT.matcher(text);
        String contractNumber = "";
        String contractDate = "";
        if (contract.find()) {
            contractNumber = contract.group(1);
            contractDate = contract.group(2) == null ? "" : contract.group(2);
        }
        // информационное поле СберКорус называет договор без пробела после «№»: «_AGR_Договор вн. №_5028839_от 07.08.2024»
        if (contractDate.isEmpty() && agreement.find()) {
            contractNumber = contractNumber.isEmpty() ? agreement.group(1) : contractNumber;
            contractDate = agreement.group(1).equals(contractNumber) ? agreement.group(2) : contractDate;
        }
        upd.put("договор", contractNumber);
        upd.put("договор_дата", contractDate);
        upd.put("сумма", totalAmount(text));
        upd.put("дата_приёмки", acceptanceDate(text));
        Form3Acts.putEdoStamp(upd, text);
        upd.put("подпись_заказчика", UPD_BUYER_SIGN.matcher(text).find() || Form3Acts.edoSignatures(text) >= EDO_BOTH_SIDES
                || UPD_BUYER_TITLE.matcher(text).find());
        putSpecReference(upd, text, name, contractNumber);
        upd.put("заказы", orderNumbers(text));
        upd.put("текст", limit(text));
        return upd;
    }

    private static String totalAmount(String text) {
        String split = Form3Acts.payableTotal(text);
        if (!split.isEmpty()) {
            return split;
        }
        Matcher m = UPD_TOTAL.matcher(text);
        if (!m.find()) {
            Matcher whole = UPD_TOTAL_WHOLE.matcher(text);
            return whole.find() ? whole.group(1) + ".00" : "";
        }
        String last = "";
        Matcher amounts = AMOUNT.matcher(m.group(1));
        while (amounts.find()) {
            last = amounts.group(1).replace(" ", "") + "." + amounts.group(2);
        }
        return last;
    }

    private static String acceptanceDate(String text) {
        Matcher m = UPD_ACCEPT.matcher(text);
        if (!m.find()) {
            return firstGroup(UPD_ACCEPT_NUMERIC, text);
        }
        String month = MONTHS.get(m.group(2).toLowerCase(Locale.ROOT));
        if (month == null) {
            return "";
        }
        return String.format("%02d.%s.%s", Integer.parseInt(m.group(1)), month, m.group(3));
    }

    /**
     * Номер спецификации УПД: из текста («Спецификация … № …», поле «Дог …_AGR_»), иначе из пути к файлу; признак
     * {@link #SPEC_BY_NAME} — номер взят из пути (запасной ход {@link Form3Match#ignoringDocSpec} только для таких).
     * Имя печатной формы УПД ФНС («ON_NSCHFDOPPR_2BK-7707083893-…_2BK-9709070357-6766351_20250714_….pdf») номера
     * спецификации не содержит: в нём ЭДО-идентификаторы участников и дата, поэтому номер ищется только в папках пути.
     */
    private static void putSpecReference(Map<String, Object> upd, String text, String fileName, String contractNumber) {
        String inText = firstGroup(SPEC_REF, text);
        // поле «Дог 0500053302 41_AGR_…» называет спецификацию документа точнее папки: дубль акта чужой спецификации
        String spec = inText.isEmpty() ? firstGroup(AGR_SPEC, text) : inText;
        String inName = spec.isEmpty() ? specInName(fileName, contractNumber) : "";
        upd.put("спецификация", spec.isEmpty() ? inName : spec);
        upd.put(SPEC_BY_NAME, !inName.isEmpty());
    }

    private static String specInName(String fileName, String contractNumber) {
        String base = Form3Acts.baseName(fileName);
        String path = FNS_UPD_NAME.matcher(base).find() ? fileName.substring(0, fileName.length() - base.length()) : fileName;
        Matcher inName = FILE_NUMBER.matcher(path);
        while (inName.find()) {
            if (!inName.group(1).equals(contractNumber) && inName.group(1).length() <= MAX_SPEC_NUMBER) {
                return inName.group(1);
            }
        }
        return "";
    }

    private static Map<String, Object> parseSpec(String name, String text) {
        Map<String, Object> spec = new LinkedHashMap<>();
        spec.put("файл", name);
        String number = firstGroup(SPEC_REF, text);
        if (number.isEmpty()) {
            number = firstGroup(OCR_NUMBER, text);
        }
        spec.put("номер", number.isEmpty() ? firstGroup(FILE_NUMBER, name) : number);
        spec.put("договор", firstGroup(SPEC_CONTRACT, text));
        spec.put("дата", latestStamp(text));
        spec.put("суммы", amounts(text));
        spec.put("текст", limit(text));
        return spec;
    }

    private static Map<String, Object> parseContract(String name, String text) {
        Map<String, Object> contract = new LinkedHashMap<>();
        contract.put("файл", name);
        Matcher ref = CONTRACT_REF_CI.matcher(text);
        // скан без текстового слоя: номер договора берётся из имени файла («Договор № 4652269 от …»);
        // рамочные договоры банков бывают с буквенно-цифровым номером («АБ-С-ИТ-2020»)
        String number = ref.find() ? ref.group(1) : firstGroup(CONTRACT_ALNUM, text);
        if (number.isEmpty()) {
            number = firstGroup(CONTRACT_ALNUM, name);
        }
        if (number.isEmpty()) {
            // скан МЕТРО: предмет договора между «Договор» и «№», номер с пробелами на следующей строке
            number = numberAfterSign(Form3Acts.body(text));
        }
        if (number.isEmpty()) {
            number = numberAfterSign(Form3Acts.baseName(name));
        }
        contract.put("номер", number.isEmpty() ? firstGroup(FILE_NUMBER, name) : number);
        String signed = firstGroup(CONTRACT_SIGNED, text);
        contract.put("дата", signed.isEmpty() ? latestStamp(text) : signed);
        contract.put("текст", limit(text));
        return contract;
    }

    /**
     * Номер договора из хвоста строки после «№», когда между словом «Договор» и знаком стоит предмет договора:
     * длинный числовой фрагмент («134108» из «CN 1090 1Т 19 134108 037544»), иначе первое слово после «№».
     *
     * @param text распознанный текст или имя файла
     * @return номер либо пусто
     */
    static String numberAfterSign(String text) {
        String tail = firstGroup(CONTRACT_NUMBER_LINE, text);
        if (tail.isEmpty()) {
            return "";
        }
        String key = Form3Rows.contractKey(tail);
        return key.equals(tail) ? tail.split("\\s+")[0].replaceAll("[.,;:)]+$", "") : key;
    }

    /** Отчёт о выполненных работах: связки со спецификацией, договором, УПД, длинными номерами и суммами. */
    private static Map<String, Object> parseReport(String name, String text) {
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("файл", name);
        report.put("спецификация", firstGroup(SPEC_REF, text));
        report.put("договор", firstGroup(CONTRACT_REF_CI, text));
        report.put("упд", firstGroup(REPORT_UPD, text));
        report.put("заказы", orderNumbers(text));
        report.put("суммы", amounts(text));
        report.put("текст", limit(text));
        return report;
    }

    static List<String> amounts(String text) {
        Set<String> amounts = new LinkedHashSet<>();
        Matcher m = AMOUNT.matcher(text);
        while (m.find()) {
            amounts.add(m.group(1).replace(" ", "") + "." + m.group(2));
        }
        return new ArrayList<>(amounts);
    }

    private static List<String> orderNumbers(String text) {
        Set<String> numbers = new LinkedHashSet<>();
        Matcher m = ORDER_REF.matcher(text);
        while (m.find()) {
            numbers.add(m.group(1));
        }
        return new ArrayList<>(numbers);
    }

    static String limit(String text) {
        return text.length() > TEXT_LIMIT ? text.substring(0, TEXT_LIMIT) : text;
    }

    private static String latestStamp(String text) {
        LocalDate latest = null;
        Matcher m = SIGN_STAMP.matcher(text);
        while (m.find()) {
            LocalDate d = parseDate(m.group(1));
            if (d != null && (latest == null || d.isAfter(latest))) {
                latest = d;
            }
        }
        return latest == null ? "" : latest.format(DATE);
    }

    // ------------------------------------------------------------------ строки

    /**
     * Строки Формы 3 по реестру документов и критериям Шага 1 (см. {@link Form3Rows}).
     *
     * @param op           конфиг операции ({@code "заказчики_в_рейтинге"} — regex; {@code "без_договора_не_засчитывать"},
     *                     {@code "сканы_по_имени_файла"}, {@code "б/н_допуски"} — «true»/«false», по умолчанию выключены;
     *                     {@code "отчёт_как_акт"}, {@code "б/н_любая_подпись"} — «true»/«false», по умолчанию включены;
     *                     см. {@link Form3Rows})
     * @param registryJson реестр из «реестр_документов»
     * @param criteriaText текст выверенных критериев (строки «Критерий | Значение | …»)
     * @return JSON-массив строк
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText) {
        return rows(op, registryJson, criteriaText, "");
    }

    /**
     * То же с исходной формой участника ({@code "форма_из_узла"}): строки формы
     * подсказывают, какая спецификация относится к УПД, когда по сумме этапа
     * подходят несколько или ни одной.
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText, String formLines) {
        return rows(op, registryJson, criteriaText, formLines, "");
    }

    /**
     * То же с шапкой исходной формы ({@code "шапка_из_узла"}): при наличии шапки
     * форма первична — строки заключения строятся по строкам формы участника.
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText, String formLines,
                       String headerLine) {
        List<Map<String, Object>> built = Form3Rows.build(op, parseRegistry(registryJson), Criteria.parse(normalize(criteriaText)),
                normalize(formLines), normalize(headerLine));
        Form3Rows.denyWithoutContract(op, built);
        return toJson(built);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> parseRegistry(String text) {
        // первый разбираемый JSON-объект входа (общий разбор LlmJson: строго, терпимо, с починкой запятых)
        LlmJson.Selection selection = LlmJson.first(text, LlmJson.OBJECT);
        LlmJson.Parsed block = selection.first();
        if (block == null && selection.lastError() == null) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: во входе нет реестра документов");
        }
        if (block == null) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: реестр не разобран: " + selection.lastError());
        }
        return (Map<String, Object>) block.value();
    }

    /**
     * Технология в тексте. Значение «UniData или Tibco» делится по «или» на альтернативы:
     * технология найдена, если найдена любая альтернатива. Название вида «Go (Golang)»
     * ищется по любому из вариантов и общепринятых сокращений (JavaScript → JS), границы — не буквы;
     * служебные слова («или», «и», «с», «на», «в», «для») вариантами не считаются — иначе
     * «и/или» в тексте засчитывало бы технологию «UniData или Tibco».
     *
     * @param text       текст, в котором ищется технология
     * @param technology значение технологии из критериев
     * @return {@code true}, если найдена хотя бы одна альтернатива
     */
    static boolean containsTechnology(String text, String technology) {
        for (String alternative : TECH_ALTERNATIVES.split(technology.strip())) {
            if (containsAlternative(text, alternative)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Одна альтернатива значения технологии: найден любой её вариант или его сокращение.
     *
     * @param text        текст, в котором ищется технология
     * @param alternative альтернатива («Go (Golang)», «PL/SQL», «Java Spring/React»)
     * @return {@code true}, если найден хотя бы один вариант, кроме служебных слов
     */
    private static boolean containsAlternative(String text, String alternative) {
        String cleaned = alternative.replace(")", "").replace("(", " ").strip();
        List<String> variants = new ArrayList<>(List.of(cleaned.split("\\s+|/")));
        variants.removeIf(variant -> TECH_STOP_WORDS.contains(variant.toLowerCase(Locale.ROOT)));
        for (String variant : List.copyOf(variants)) {
            String synonym = TECH_SYNONYMS.get(variant.toLowerCase(Locale.ROOT));
            if (synonym != null) {
                variants.add(synonym);
            }
        }
        for (String variant : variants) {
            if (variant.length() < 2) {
                continue;
            }
            String roleGuard = METHODOLOGY.matcher(variant).matches() ? ROLE_BEFORE : "";
            Pattern p = Pattern.compile(roleGuard + "(?<![A-Za-zА-Яа-я0-9])" + Pattern.quote(variant) + "(?![A-Za-zА-Яа-я0-9])",
                    Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
            if (p.matcher(text).find()) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ критерии

    /** Выверенные критерии Шага 1: периоды, технологии по лотам, признак мобильной закупки. */
    static final class Criteria {
        private static final Pattern PERIOD_QUAL = Pattern.compile(
                "(?m)^Период опыта участника по квалификационным требованиям\\s*[—-]\\s*календарные даты\\s*\\|\\s*"
                        + "с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern PERIOD_METHOD = Pattern.compile(
                "(?m)^Период опыта по методике оценки\\s*[—-]\\s*календарные даты\\s*\\|\\s*"
                        + "с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern QUAL_TEXT = Pattern.compile(
                "(?m)^Период опыта участника по квалификационным требованиям\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern METHOD_TEXT = Pattern.compile("(?m)^Период опыта по методике оценки\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern START_DATE = Pattern.compile(
                "(?m)^Дата начала срока подачи заявок\\s*\\|\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern SPAN = Pattern.compile(
                "(\\d{1,3})\\s*(?:\\([^)]*\\))?\\s*(год|лет|месяц)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        private static final Pattern LOT = Pattern.compile("^ЛОТ\\s*№\\s*(\\d+)\\s*\\((Квалификационн|Методическ)");
        private static final Pattern TECH = Pattern.compile("^Технология\\s*\\d+\\s*\\|\\s*([^|]+?)\\s*\\|");
        private static final Pattern MOBILE = Pattern.compile(
                "(?m)^Признак\\s*[«\"]?Мобильная разработка[»\"]?\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern MOBILE_EXCLUDED = Pattern.compile(
                "не\\s+засчит|не\\s+учит|исключ|не\\s+принима|не\\s+являет", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        private static final Pattern MOBILE_SUBJECT = Pattern.compile(
                "закупа|предмет|засчит|являет|учитыва|требует", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        /** Технология лота — мобильная платформа (iOS, Android, Swift, Kotlin, Flutter, React Native, Objective-C, «мобильн…»). */
        private static final Pattern MOBILE_TECH = Pattern.compile(
                "(?<![\\p{L}\\d])(?:ios|android|swift|kotlin|flutter|react\\s*native|objective[-\\s]?c)(?![\\p{L}\\d])|мобильн",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        /** Признак описывает разработку мобильных приложений: «…внедрению мобильных приложений iOS и Android». */
        private static final Pattern MOBILE_DEVELOPMENT = Pattern.compile(
                "мобильн\\S*\\s+приложени|(?:разработ|модификац|внедрен)[^|]{0,120}?(?<![\\p{L}\\d])(?:ios|android)(?![\\p{L}\\d])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

        LocalDate qualFrom;
        LocalDate qualTo;
        LocalDate methodFrom;
        LocalDate methodTo;
        boolean mobileProcurement;
        final Map<String, List<String>> lots = new LinkedHashMap<>();
        private final Map<String, List<String>> methodLots = new LinkedHashMap<>();

        static Criteria parse(String text) {
            Criteria c = new Criteria();
            LocalDate start = parseDate(firstGroup(START_DATE, text));
            Matcher q = PERIOD_QUAL.matcher(text);
            if (q.find()) {
                c.qualFrom = parseDate(q.group(1));
                c.qualTo = parseDate(q.group(2));
            } else if (start != null) {
                c.qualFrom = minusSpan(start, firstGroup(QUAL_TEXT, text));
                c.qualTo = c.qualFrom == null ? null : start;
            }
            Matcher m = PERIOD_METHOD.matcher(text);
            if (m.find()) {
                c.methodFrom = parseDate(m.group(1));
                c.methodTo = parseDate(m.group(2));
            } else if (start != null) {
                c.methodFrom = minusSpan(start, firstGroup(METHOD_TEXT, text));
                c.methodTo = c.methodFrom == null ? null : start;
            }
            c.parseLots(text);
            c.mobileProcurement = c.isMobileProcurement(firstGroup(MOBILE, text));
            return c;
        }

        /**
         * Закупка мобильной разработки (письмо Егоровой 16.09.2026): явный запрет в признаке («не засчитывается»,
         * «исключается») — мобильная разработка стоп-фактор; иначе закупка мобильная, если требуемые технологии
         * какого-либо лота (квалификационные или методические) — мобильные платформы, либо признак описывает
         * разработку мобильных приложений; иначе — по словам о предмете закупки, как прежде.
         *
         * @param mobile значение признака «Мобильная разработка» (пусто, если строки нет)
         * @return {@code true}, если мобильная разработка засчитывается
         */
        private boolean isMobileProcurement(String mobile) {
            if (MOBILE_EXCLUDED.matcher(mobile).find()) {
                return false;
            }
            if (mobileLot(lots) || mobileLot(methodLots)) {
                return true;
            }
            return !mobile.isEmpty() && (MOBILE_DEVELOPMENT.matcher(mobile).find() || MOBILE_SUBJECT.matcher(mobile).find());
        }

        /** Есть лот, все технологии которого — мобильные платформы. */
        private static boolean mobileLot(Map<String, List<String>> byLot) {
            return byLot.values().stream().anyMatch(techs -> !techs.isEmpty()
                    && techs.stream().allMatch(tech -> MOBILE_TECH.matcher(tech).find()));
        }

        /** Начало периода: дата начала подачи заявок минус «N (…) лет/месяцев» из текста критерия. */
        private static LocalDate minusSpan(LocalDate start, String periodText) {
            Matcher span = SPAN.matcher(periodText);
            if (!span.find()) {
                return null;
            }
            int n = Integer.parseInt(span.group(1));
            return span.group(2).toLowerCase(Locale.ROOT).startsWith("месяц") ? start.minusMonths(n) : start.minusYears(n);
        }

        private void parseLots(String text) {
            String lot = null;
            boolean qualification = true;
            for (String line : text.split("\n")) {
                Matcher head = LOT.matcher(line.strip());
                if (head.find()) {
                    lot = head.group(1);
                    qualification = head.group(2).startsWith("Квалификац");
                    continue;
                }
                Matcher tech = TECH.matcher(line.strip());
                if (lot != null && tech.find() && !tech.group(1).toLowerCase(Locale.ROOT).startsWith("не указано")) {
                    (qualification ? lots : methodLots).computeIfAbsent(lot, k -> new ArrayList<>()).add(tech.group(1));
                }
            }
            for (Map.Entry<String, List<String>> e : methodLots.entrySet()) {
                lots.putIfAbsent(e.getKey(), e.getValue());
            }
        }

        List<String> allTechnologies() {
            Set<String> all = new LinkedHashSet<>();
            lots.values().forEach(all::addAll);
            return new ArrayList<>(all);
        }
    }

    // ------------------------------------------------------------------ утилиты

    static String firstGroup(Pattern p, String text) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1).strip() : "";
    }

    static LocalDate parseDate(String value) {
        try {
            return LocalDate.parse(value, DATE);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }

    static String str(Object value) {
        return value == null ? "" : String.valueOf(value).strip();
    }

    static String toJson(Object value) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать результат: " + e.getMessage());
        }
    }
}
