package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.contentstream.PDContentStream;
import org.apache.pdfbox.contentstream.operator.Operator;
import org.apache.pdfbox.contentstream.operator.OperatorName;
import org.apache.pdfbox.cos.COSBase;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdfparser.PDFStreamParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFGroupShape;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTable;
import org.apache.poi.xslf.usermodel.XSLFTableCell;
import org.apache.poi.xslf.usermodel.XSLFTableRow;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFFooter;
import org.apache.poi.xwpf.usermodel.XWPFFootnote;
import org.apache.poi.xwpf.usermodel.XWPFHeader;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFSDT;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.apache.xmlbeans.XmlCursor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.FileUtils;
import ru.sber.cs.ai.gigame.utils.TextSplitter;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Сервис обработки загруженных файлов, извлечения текста и индексации документов.
 * <p>
 * Основные функции:
 * <ul>
 *   <li>Загрузка файлов различных форматов (PDF, DOCX, XLSX, TXT)</li>
 *   <li>Извлечение текстового содержимого из документов</li>
 *   <li>Разбиение длинных документов на фрагменты (чанки)</li>
 *   <li>Векторная индексация для последующего поиска похожих фрагментов</li>
 *   <li>Хранение метаданных файлов в базе данных</li>
 * </ul>
 *
 * @see Document
 * @see DocumentRepository
 * @see EmbeddingService
 * @see TextSplitter
 * @see GigaChatClient
 */
@Service
@Slf4j
public class DocumentService {
    /** Число с разрядами, сгруппированными пробелами («9 750 986,34»). */
    private static final Pattern GROUPED_NUMBER = Pattern.compile(
            "(?<![\\d,.])\\d{1,3}(?:[ \\u00A0\\u202F\\u2009]\\d{3})+(?:[.,]\\d{1,2})?(?!\\d)");
    /** Число, рваное экстрактором на неравные куски («9 750 98 6,34» у PDFBox):
     *  куски по 1-3 цифры, десятичная часть обязательна — иначе слипались бы
     *  соседние самостоятельные целые числа. Повтор кусков взят possessiv-квант-
     *  фикатором (++): куски поглощаются без возвратов, что убирает риск
     *  стек-переполнения (S5998) на больших входах — поведение не меняется.
     */
    private static final Pattern TORN_NUMBER = Pattern.compile(
            "(?<![\\d,.])\\d{1,3}(?:[ \\u00A0\\u202F\\u2009]\\d{1,3})++[.,]\\d{1,2}(?!\\d)");
    private static final Pattern GROUP_SEPARATORS = Pattern.compile("[ \\u00A0\\u202F\\u2009]");
    /** Число, разорванное переносом строки на длинную голову и короткий дробный хвост
     *  («394134\n3,56» = 3941343,56 в узких колонках таблиц PDF): голова от 4 цифр,
     *  хвост 1-2 цифры с обязательной дробной частью — самостоятельное число из
     *  1-2 цифр с копейками сразу под 4+-значным целым в таблицах не встречается. */
    private static final Pattern WRAPPED_NUMBER = Pattern.compile(
            "(?<![\\d,.])\\d{4,}[\\r\\n]+\\d{1,2}[.,]\\d{1,2}(?!\\d)");
    /** Разрыв переносом ПОСЛЕ десятичной запятой («384553,\n94» = 384553,94):
     *  голова от 4 цифр с запятой, хвост 1-2 цифры копеек. */
    private static final Pattern WRAPPED_AFTER_COMMA = Pattern.compile(
            "(?<![\\d,.])\\d{4,},[\\r\\n]+\\d{1,2}(?![\\d,.])");
    private static final Pattern WRAP_SEPARATORS = Pattern.compile("[\\r\\n]+");
    /** Маркер в начале текста TXT, кодировку которого не удалось распознать. */
    public static final String ENCODING_MARKER = "[кодировка не распознана — текст может быть искажён]";
    /** Минимальная доля читаемых символов текста, ниже — маркер нераспознанной кодировки. */
    static final double READABLE_SHARE_MIN = 0.6;
    /** Заголовок блока колонтитулов DOCX после тела документа. */
    static final String DOCX_HEADERS_BLOCK = "=== Колонтитулы ===";
    /** Заголовок блока сносок DOCX после тела документа. */
    static final String DOCX_FOOTNOTES_BLOCK = "=== Сноски ===";
    /** XPath текстов внутри текстовых полей (w:txbxContent) абзаца. */
    private static final String TXBX_TEXT_PATH = "declare namespace w='http://schemas.openxmlformats.org/wordprocessingml/2006/main' "
            + ".//w:txbxContent//w:t";
    private final DocumentRepository documentRepository;
    private final EmbeddingService embeddingService;
    private final DocumentIndexService indexService;
    /**
     * Максимальная длина текста документа для включения полного содержимого в промпт.
     * Документы длиннее этого лимита разбиваются на фрагменты и индексируются для поиска по схожести.
     */
    @Value("${app.embedding.char-limit:12000}")
    private int charLimit;

    /**
     * Порог длины текста PDF, ниже которого документ считается сканом без текстового слоя.
     */
    @Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars = 40;

    /**
     * Максимальный размер загружаемого файла в байтах (защита от ZIP-бомб при парсинге).
     */
    @Value("${app.document.max-file-size:104857600}")
    private long maxFileSizeBytes = 100L * 1024 * 1024;

    /**
     * Максимальное число листов Excel, обрабатываемых при парсинге (защита от DoS).
     */
    @Value("${app.document.max-sheets:100}")
    private int maxSheetsToParse = 100;

    /**
     * Максимальное суммарное число строк Excel по всем листам (защита от DoS).
     */
    @Value("${app.document.max-total-rows:100000}")
    private int maxTotalRows = 100_000;

    /**
     * Максимальное число обрабатываемых узлов XML (защита от Billion Laughs / DoS).
     */
    @Value("${app.document.max-xml-nodes:10000}")
    private int maxXmlNodes = 10_000;

    /**
     * Предел суммарного объёма текстов одной загрузки в диалог (символы); 0 и меньше — без предела.
     */
    @Value("${app.document.chat-max-total-chars:20000000}")
    private long chatMaxTotalChars = 20_000_000L;

    /**
     * Распознавание PDF-сканов (может отсутствовать в тестовом контексте).
     */
    private final ObjectProvider<ScanOcrService> scanOcrProvider;

    @Autowired
    public DocumentService(DocumentRepository documentRepository, EmbeddingService embeddingService,
                           DocumentIndexService indexService,
                           ObjectProvider<ScanOcrService> scanOcrProvider) {
        this.documentRepository = documentRepository;
        this.embeddingService = embeddingService;
        this.indexService = indexService;
        this.scanOcrProvider = scanOcrProvider;
    }

    public DocumentService(DocumentRepository documentRepository, EmbeddingService embeddingService,
                           DocumentIndexService indexService) {
        this(documentRepository, embeddingService, indexService, null);
    }

    // -------------------------------------------------------------------------
    // Text extraction
    // -------------------------------------------------------------------------

    /**
     * Сохраняет загруженный файл, извлекает текст, сохраняет в БД
     * и индексирует, если документ большой.
     * <p>
     * Алгоритм работы:
     * <ol>
     *   <li>Извлекает имя файла и определяет тип контента</li>
     *   <li>Читает содержимое файла из multipart-запроса</li>
     *   <li>Извлекает текст в зависимости от типа файла</li>
     *   <li>Сохраняет метаданные в базу данных</li>
     *   <li>Если текст большой, запускает индексацию</li>
     * </ol>
     * Метод намеренно НЕ транзакционный: разбор, распознавание скана и эмбеддинги
     * занимают минуты, и соединение БД из пула Hikari на это время не удерживается —
     * запись документа ({@code save}) и запись фрагментов ({@code storeDocumentChunks})
     * идут короткими транзакциями.
     *
     * @param file загруженный файл
     * @return DTO с метаданными документа
     */
    public DocumentResponse uploadDocument(FilePart file) {
        String filename = file.filename();
        String userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] uploadDocument, filename='{}'", userId, filename);
        if (filename.isBlank()) {
            throw new FileException("Пустое имя файла");
        }
        String contentType = FileUtils.detectContentType(filename);
        byte[] contentBytes = readContent(file);
        contentType = FileUtils.detectContentType(filename, contentBytes);
        String extractedText = extractText(filename, contentType, contentBytes);
        Document document = new Document();
        document.setFilename(filename);
        document.setContentType(contentType);
        document.setExtractedText(extractedText);
        // размер по фактически прочитанным байтам: у multipart-части заголовка Content-Length обычно нет (-1)
        document.setSizeBytes(contentBytes.length);
        document.setContentSha256(sha256Hex(contentBytes));
        // Нормализация (пусто -> anonymous): иначе владелец-аноним не пройдёт
        // проверку доступа при просмотре собственного документа
        document.setUserId(userId);
        document = documentRepository.save(document);

        if (extractedText.length() > charLimit) {
            try {
                indexService.indexDocument(document.getId(), extractedText);
            } catch (Exception e) {
                log.error("[{}] Document {} indexing error {}", CurrentUserHolder.getCurrentUser(), document.getId(), e.getMessage());
            }
        }

        return toDto(document);
    }

    /**
     * Читает содержимое загруженного файла целиком и проверяет предел размера
     * ({@code app.document.max-file-size}). Часть multipart-запроса живёт только
     * до конца HTTP-запроса, поэтому байты читаются синхронно — даже когда разбор
     * и индексация уходят в фон.
     *
     * @param file загруженный файл
     * @return содержимое файла
     * @throws FileException файл не читается либо больше предела
     */
    public byte[] readContent(FilePart file) {
        String filename = file.filename();
        byte[] contentBytes;
        try (InputStream inputStream = FileUtils.toInputStream(file).block()) {
            assert inputStream != null;
            contentBytes = inputStream.readAllBytes();
        } catch (Exception e) {
            log.error("[{}] Ошибка при чтении файла {}: {}", CurrentUserHolder.getCurrentUser(), filename, e.getMessage());
            throw new FileException("Failed to read file " + filename, e);
        }
        if (contentBytes.length > maxFileSizeBytes) {
            throw new FileException("Файл " + filename + " превышает максимально допустимый размер: "
                    + maxFileSizeBytes + " байт");
        }
        return contentBytes;
    }

    /**
     * Извлекает текст из содержимого файла: разбор по типу контента и, для
     * PDF-скана, распознавание через GigaChat ({@link #maybeOcrScan}). Разбор
     * и распознавание могут занимать минуты — вызывать вне HTTP-потока, где это возможно.
     *
     * @param filename    имя файла
     * @param contentType тип контента (см. {@link FileUtils#detectContentType(String, byte[])})
     * @param content     содержимое файла
     * @return извлечённый (и распознанный) текст
     * @throws FileException текст не извлекается
     */
    public String extractText(String filename, String contentType, byte[] content) {
        String extractedText;
        try {
            extractedText = parseText(new ByteArrayInputStream(content), contentType);
        } catch (Exception e) {
            log.error("[{}] Ошибка при обработке файла {}: {}", CurrentUserHolder.getCurrentUser(), filename, e.getMessage());
            throw new FileException("Failed to extract text from " + filename, e);
        }
        return maybeOcrScan(filename, contentType, content, extractedText);
    }

    /**
     * SHA-256 содержимого файла в шестнадцатеричном виде (64 символа) — ключ
     * распознавания повторной загрузки того же файла.
     *
     * @param content содержимое файла
     * @return хэш в нижнем регистре
     */
    public static String sha256Hex(byte[] content) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(content);
            StringBuilder hex = new StringBuilder(digest.length * 2);
            for (byte b : digest) {
                hex.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    /**
     * Проверяет суммарный объём текстов одной загрузки в диалог
     * ({@code app.document.chat-max-total-chars}): тексты попадают в кэш документов
     * диалога целиком и живут там до истечения TTL — сто больших книг Excel
     * в одном запросе исчерпали бы память. Документы уже сохранены; без
     * сообщения их уберёт плановая чистка сирот.
     *
     * @param texts извлечённые тексты документов загрузки
     * @throws FileException суммарный объём больше предела
     */
    public void checkChatTotalChars(List<String> texts) {
        if (chatMaxTotalChars <= 0) {
            return;
        }
        long total = 0;
        for (String text : texts) {
            total += text == null ? 0 : text.length();
        }
        if (total > chatMaxTotalChars) {
            throw new FileException("Суммарный объём текста загруженных файлов (" + total
                    + " символов) превышает предел " + chatMaxTotalChars + " — загрузите меньше файлов");
        }
    }

    /**
     * PDF без текстового слоя (скан): при включённом OCR
     * ({@code app.document.ocr-via-gigachat}) распознаётся через файловое
     * хранилище GigaChat; при выключенном или при ошибке текст остаётся как есть
     * (модель в чате честно скажет, что содержимое не извлечено).
     *
     * @param filename    имя файла
     * @param contentType тип контента
     * @param content     содержимое файла
     * @param parsed      извлечённый парсером текст
     * @return распознанный либо исходный текст
     */
    private String maybeOcrScan(String filename, String contentType, byte[] content, String parsed) {
        if (!"pdf".equals(contentType) || !isScanPdf(content, parsed)) {
            return parsed;
        }
        ScanOcrService ocr = scanOcrProvider != null ? scanOcrProvider.getIfAvailable() : null;
        if (ocr == null || !ocr.isEnabled()) {
            return parsed;
        }
        try {
            return withParsed(ocr.recognize(filename, content), parsed);
        } catch (Exception e) {
            log.warn("[{}] OCR скана «{}» не удался ({}) — текст остаётся пустым", CurrentUserHolder.getCurrentUser(), filename, e.getMessage());
            return parsed;
        }
    }

    /**
     * Признак скана: текстового слоя меньше порога либо не менее половины
     * страниц — изображения без текстового слоя ({@link #isImagePage}). Сканы актов
     * из ЭДО несут страницу-штамп с текстом подписей: суммарный текст превышает
     * порог, хотя страницы самого документа — изображения, и без постраничной
     * проверки скан не распознаётся. Пустые страницы (ни текста, ни изображений)
     * в правило половины не входят.
     *
     * @param content содержимое PDF
     * @param parsed  текст, извлечённый парсером
     * @return {@code true}, если документ нужно распознавать
     */
    public boolean isScanPdf(byte[] content, String parsed) {
        if (parsed.strip().length() < minParsedChars) {
            return true;
        }
        PdfPages pages = checkPdfPages(content);
        return pages.total() > 0 && pages.textless().size() * 2 >= pages.total();
    }

    /**
     * Номера страниц (с 1) без текстового слоя — страниц-изображений по правилу
     * {@link #isImagePage}. Пустая страница машиночитаемого документа сюда не попадает.
     *
     * @param content содержимое PDF
     * @return номера страниц-изображений; пустой список, если PDF не разбирается
     */
    public List<Integer> textlessPages(byte[] content) {
        return checkPdfPages(content).textless();
    }

    /**
     * Постраничная проверка PDF: текстовый слой и изображения каждой страницы.
     *
     * @param content содержимое PDF
     * @return число страниц и номера страниц-изображений; ноль страниц, если PDF не разбирается
     */
    private PdfPages checkPdfPages(byte[] content) {
        List<Integer> textless = new ArrayList<>();
        try (PDDocument doc = Loader.loadPDF(content)) {
            PDFTextStripper stripper = new PDFTextStripper();
            for (int page = 1; page <= doc.getNumberOfPages(); page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);
                if (isImagePage(doc.getPage(page - 1), stripper.getText(doc), minParsedChars)) {
                    textless.add(page);
                }
            }
            return new PdfPages(doc.getNumberOfPages(), textless);
        } catch (IOException e) {
            log.warn("[{}] Постраничная проверка PDF не удалась ({}) — считается текстовым", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return new PdfPages(0, List.of());
        }
    }

    /**
     * Страница без текстового слоя — кандидат на OCR: текст короче порога и на
     * странице есть изображение ({@link #hasImages}). Пустая страница (ни текста,
     * ни изображений) сканом не считается: распознавать на ней нечего, а пустая
     * страница машиночитаемого договора отправляла весь документ в OCR. Правило
     * общее для проверки скана, смешанного PDF и постраничного распознавания
     * ({@link ScanOcrService}).
     *
     * @param page     страница PDF
     * @param text     текстовый слой страницы
     * @param minChars порог текстового слоя ({@code app.document.min-parsed-chars})
     * @return {@code true}, если страницу нужно распознавать
     */
    public static boolean isImagePage(PDPage page, String text, int minChars) {
        return text.strip().length() < minChars && hasImages(page);
    }

    /**
     * Есть ли на странице изображение: image XObject в ресурсах (в том числе
     * внутри вложенных form XObject) либо inline image в потоке содержимого.
     * Если структура страницы не читается, страница считается изображением —
     * как до проверки изображений.
     *
     * @param page страница PDF
     * @return {@code true}, если изображение найдено либо структура не читается
     */
    private static boolean hasImages(PDPage page) {
        try {
            return hasImages(page, Collections.newSetFromMap(new IdentityHashMap<>()));
        } catch (IOException | RuntimeException e) {
            log.warn("[{}] Проверка изображений страницы PDF не удалась ({}) — страница считается изображением", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return true;
        }
    }

    /**
     * Изображение в потоке содержимого страницы либо form XObject: ресурсы
     * обходятся рекурсивно, уже просмотренные формы пропускаются (защита от циклов).
     *
     * @param stream  страница или form XObject
     * @param visited просмотренные form XObject
     * @return {@code true}, если изображение найдено
     */
    private static boolean hasImages(PDContentStream stream, Set<COSBase> visited) throws IOException {
        PDResources resources = stream.getResources();
        if (resources != null) {
            for (COSName name : resources.getXObjectNames()) {
                if (resources.isImageXObject(name) || isFormWithImages(resources, name, visited)) {
                    return true;
                }
            }
        }
        return hasInlineImage(stream);
    }

    private static boolean isFormWithImages(PDResources resources, COSName name, Set<COSBase> visited) throws IOException {
        return resources.getXObject(name) instanceof PDFormXObject form
                && visited.add(form.getCOSObject())
                && hasImages(form, visited);
    }

    /** Inline image (оператор BI) в потоке содержимого. */
    private static boolean hasInlineImage(PDContentStream stream) throws IOException {
        PDFStreamParser parser = new PDFStreamParser(stream);
        try {
            for (Object token = parser.parseNextToken(); token != null; token = parser.parseNextToken()) {
                if (token instanceof Operator operator && OperatorName.BEGIN_INLINE_IMAGE.equals(operator.getName())) {
                    return true;
                }
            }
            return false;
        } finally {
            parser.close();
        }
    }

    /**
     * Итог постраничной проверки PDF.
     *
     * @param total    число страниц (0 — PDF не разбирается)
     * @param textless номера страниц-изображений без текстового слоя
     */
    private record PdfPages(int total, List<Integer> textless) {
    }

    /**
     * Распознанный текст вместе с текстовым слоем (штамп ЭДО с подписями и датами).
     *
     * @param recognized распознанный текст
     * @param parsed     текст, извлечённый парсером
     * @return объединённый текст
     */
    public static String withParsed(String recognized, String parsed) {
        return parsed.strip().isEmpty() ? recognized : recognized + "\n\n" + parsed.strip();
    }

    /**
     * Извлекает текст из файла в зависимости от его типа контента.
     * <p>
     * Поддерживаемые форматы:
     * <ul>
     *   <li>PDF — с помощью Apache PDFBox</li>
     *   <li>DOCX — с помощью Apache POI (параграфы и таблицы)</li>
     *   <li>XLSX/XLS — с помощью Apache POI (все листы)</li>
     *   <li>TXT — как plain text</li>
     * </ul>
     *
     * @param inputStream поток с содержимым файла
     * @param contentType тип контента ("pdf", "docx", "xlsx", "txt")
     * @return извлечённый текст
     * @throws IOException              если произошла ошибка при чтении файла
     * @throws IllegalArgumentException если тип контента не поддерживается
     */
    public String parseText(InputStream inputStream, String contentType) throws IOException {
        String extracted = switch (contentType) {
            case "pdf" -> parsePdf(inputStream);
            case "docx" -> parseDocx(inputStream);
            case "xlsx" -> parseXlsx(inputStream);
            case "xls" -> parseXls(inputStream);
            case "pptx" -> parsePptx(inputStream);
            case "xml" -> parseXml(inputStream);
            case "txt" -> decodeText(inputStream.readAllBytes());
            default -> throw new IllegalArgumentException("Неподдерживаемый тип контента: " + contentType);
        };
        return normalizeNumberGroups(extracted);
    }

    /**
     * Склеивает разряды чисел, разорванные пробелами-разделителями: «9 750 986,34» →
     * «9750986,34». Модель теряет разряды при переписывании разорванных чисел, а
     * детерминированные узлы (расчёт, трансформация) не распознают их как числа.
     * Склейка только внутри валидно сгруппированных чисел (по три цифры), поэтому
     * соседние самостоятельные числа («2025 100 000,00») не слипаются.
     *
     * @param text исходный текст документа
     * @return текст со склеенными числами
     */
    static String normalizeNumberGroups(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        String glued = glueMatches(GROUPED_NUMBER, text, GROUP_SEPARATORS);
        glued = glueMatches(TORN_NUMBER, glued, GROUP_SEPARATORS);
        glued = glueMatches(WRAPPED_NUMBER, glued, WRAP_SEPARATORS);
        return glueMatches(WRAPPED_AFTER_COMMA, glued, WRAP_SEPARATORS);
    }

    private static String glueMatches(Pattern pattern, String text, Pattern separators) {
        Matcher m = pattern.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            m.appendReplacement(sb,
                    Matcher.quoteReplacement(separators.matcher(m.group()).replaceAll("")));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /**
     * Декодирует текстовый файл: BOM (UTF-8/UTF-16) срезается и задаёт кодировку;
     * UTF-16 без BOM узнаётся по нулевым байтам; далее строгий UTF-8, при ошибке —
     * windows-1251 либо CP866 (что даёт больше читаемых букв). Если и после этого
     * доля кириллицы и латиницы среди значимых символов ниже порога, текст
     * помечается маркером {@link #ENCODING_MARKER} — загрузка даёт предупреждение.
     * <p>
     * Раньше использовалась кодировка JVM по умолчанию — на Windows (cp1251)
     * загруженные UTF-8 файлы превращались в нечитаемый текст, а BOM оставался
     * в тексте и ломал якорные регэкспы Формы 3.
     */
    static String decodeText(byte[] bytes) {
        String decoded = decodeByBom(bytes);
        if (decoded == null) {
            decoded = strictUtf8(bytes);
        }
        if (decoded == null) {
            String cp1251 = new String(bytes, Charset.forName("windows-1251"));
            String cp866 = new String(bytes, Charset.forName("CP866"));
            decoded = readableShare(cp866) > readableShare(cp1251) ? cp866 : cp1251;
        }
        return readableShare(decoded) < READABLE_SHARE_MIN ? ENCODING_MARKER + "\n" + decoded : decoded;
    }

    /** Текст по BOM либо по нулевым байтам UTF-16; {@code null}, если признаков нет. */
    private static String decodeByBom(byte[] bytes) {
        if (bytes.length >= 3 && (bytes[0] & 0xFF) == 0xEF && (bytes[1] & 0xFF) == 0xBB && (bytes[2] & 0xFF) == 0xBF) {
            String utf8 = strictUtf8(Arrays.copyOfRange(bytes, 3, bytes.length));
            return utf8 != null ? utf8 : new String(bytes, 3, bytes.length - 3, StandardCharsets.UTF_8);
        }
        if (bytes.length >= 2 && (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xFE) {
            return new String(bytes, 2, bytes.length - 2, StandardCharsets.UTF_16LE);
        }
        if (bytes.length >= 2 && (bytes[0] & 0xFF) == 0xFE && (bytes[1] & 0xFF) == 0xFF) {
            return new String(bytes, 2, bytes.length - 2, StandardCharsets.UTF_16BE);
        }
        // UTF-16 без BOM: старший байт почти каждой пары — 0x00 (латиница, цифры) или 0x04 (кириллица)
        int pairs = bytes.length / 2;
        int highOdd = utf16HighBytes(bytes, 1);
        int highEven = utf16HighBytes(bytes, 0);
        if (pairs >= 4 && highOdd * 4 >= pairs * 3 && highEven * 10 < pairs) {
            return new String(bytes, StandardCharsets.UTF_16LE);
        }
        if (pairs >= 4 && highEven * 4 >= pairs * 3 && highOdd * 10 < pairs) {
            return new String(bytes, StandardCharsets.UTF_16BE);
        }
        return null;
    }

    /** Число байт 0x00/0x04 на позициях offset, offset+2, … (старшие байты UTF-16 для латиницы и кириллицы). */
    private static int utf16HighBytes(byte[] bytes, int offset) {
        int count = 0;
        for (int i = offset; i < bytes.length; i += 2) {
            if (bytes[i] == 0 || bytes[i] == 4) {
                count++;
            }
        }
        return count;
    }

    private static String strictUtf8(byte[] bytes) {
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException e) {
            return null;
        }
    }

    /**
     * Доля кириллицы, латиницы, цифр и обычной пунктуации среди непробельных
     * символов (1.0 для пустого текста). Управляющие символы, псевдографика,
     * редкие буквы других кириллических алфавитов и чужие письменности —
     * признак неверной кодировки.
     */
    static double readableShare(String text) {
        int total = 0;
        int readable = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (Character.isWhitespace(c)) {
                continue;
            }
            total++;
            if ((c >= 0x20 && c < 0x7F) || (c >= 0x410 && c <= 0x44F) || c == 'Ё' || c == 'ё'
                    || c == '№' || c == '«' || c == '»' || c == '—' || c == '–'
                    || c == '…' || c == '“' || c == '”' || c == '„' || c == '’') {
                readable++;
            }
        }
        return total == 0 ? 1.0 : (double) readable / total;
    }

    /**
     * Извлекает текст из PDF-документа.
     *
     * @param inputStream поток с PDF-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении PDF
     */
    private String parsePdf(InputStream inputStream) throws IOException {
        byte[] pdfBytes = inputStream.readAllBytes();
        try (PDDocument doc = Loader.loadPDF(pdfBytes)) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(doc);
        }
    }

    /**
     * Извлекает текст из DOCX-документа.
     * <p>
     * Обрабатывает параграфы и таблицы (важно для документов с заявками и спецификациями).
     * Для таблиц ячейки объединяются символом "|".
     *
     * @param inputStream поток с DOCX-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении DOCX
     */
    private String parseDocx(InputStream inputStream) throws IOException {
        ZipSecureFile.setMinInflateRatio(0);
        try (XWPFDocument doc = new XWPFDocument(inputStream)) {
            String body = processDocxElement(doc.getBodyElements());
            String extras = docxHeadersAndFootnotes(doc);
            return extras.isEmpty() ? body : body + "\n\n" + extras;
        }
    }

    /**
     * Колонтитулы и сноски DOCX (раньше не извлекались вовсе: номера договоров
     * и реквизиты в верхнем колонтитуле, оговорки в сносках терялись).
     * Колонтитулы дедуплицируются — один и тот же текст на каждой секции даётся один раз.
     *
     * @param doc документ
     * @return блоки «=== Колонтитулы ===» и «=== Сноски ===» либо пустая строка
     */
    private String docxHeadersAndFootnotes(XWPFDocument doc) {
        List<String> blocks = new ArrayList<>();
        Set<String> headers = new LinkedHashSet<>();
        for (XWPFHeader header : doc.getHeaderList()) {
            addIfNotBlank(headers, processDocxElement(header.getBodyElements()));
        }
        for (XWPFFooter footer : doc.getFooterList()) {
            addIfNotBlank(headers, processDocxElement(footer.getBodyElements()));
        }
        if (!headers.isEmpty()) {
            blocks.add(DOCX_HEADERS_BLOCK + "\n" + String.join("\n", headers));
        }
        List<String> footnotes = new ArrayList<>();
        for (XWPFFootnote footnote : doc.getFootnotes()) {
            String text = processDocxElement(footnote.getBodyElements());
            if (!text.isBlank()) {
                footnotes.add("[" + footnote.getId() + "] " + text.strip());
            }
        }
        if (!footnotes.isEmpty()) {
            blocks.add(DOCX_FOOTNOTES_BLOCK + "\n" + String.join("\n", footnotes));
        }
        return String.join("\n\n", blocks);
    }

    private static void addIfNotBlank(Set<String> target, String text) {
        if (text != null && !text.isBlank()) {
            target.add(text.strip());
        }
    }

    /**
     * Текст абзаца вместе с содержимым текстовых полей (w:txbxContent): POI не
     * включает текстовые поля в {@code getText()}, а в них бывают штампы и подписи.
     *
     * @param paragraph абзац
     * @return текст абзаца; текстовые поля добавляются в скобках «[текстовое поле: …]»
     */
    static String paragraphText(XWPFParagraph paragraph) {
        String text = paragraph.getText();
        String base = text == null ? "" : text.strip();
        List<String> boxes = new ArrayList<>();
        try (XmlCursor cursor = paragraph.getCTP().newCursor()) {
            cursor.selectPath(TXBX_TEXT_PATH);
            while (cursor.toNextSelection()) {
                String piece = cursor.getTextValue();
                if (piece != null && !piece.isBlank() && !base.contains(piece.strip())) {
                    boxes.add(piece);
                }
            }
        }
        if (boxes.isEmpty()) {
            return base;
        }
        String box = "[текстовое поле: " + String.join("", boxes).strip() + "]";
        return base.isEmpty() ? box : base + " " + box;
    }

    private String processDocxElement(List<IBodyElement> bodyElements) {
        List<String> parts = new ArrayList<>();
        for (IBodyElement bodyElement : bodyElements) {
            switch (bodyElement.getElementType()) {
                case PARAGRAPH:
                    parts.add(paragraphText((XWPFParagraph) bodyElement));
                    break;
                case TABLE:
                    parts.add(processDocxTable((XWPFTable) bodyElement));
                    break;
                case CONTENTCONTROL:
                    parts.add(((XWPFSDT) bodyElement).getContent().getText());
                    break;
                default:
            }
        }
        return String.join("\n", parts);
    }

    private String processDocxTable(XWPFTable table) {
        List<String> lines = new ArrayList<>();
        for (XWPFTableRow row : table.getRows()) {
            List<String> cellContents = new ArrayList<>();
            for (XWPFTableCell cell : row.getTableCells()) {
                cellContents.add(processDocxElement(cell.getBodyElements()));
            }
            lines.add("< " + String.join(" | ", cellContents) + " >");
        }

        return "[ " + String.join("\n", lines) + " ]";
    }

    /**
     * Извлекает текст из XLSX-файла.
     * <p>
     * Обрабатывает все листы книги. Если листов несколько, каждый лист
     * помечается заголовком "=== Лист: [название] ===". Ячейки в строке
     * объединяются символом "|". Для ячеек с формулами извлекается вычисленное значение.
     *
     * @param inputStream поток с XLSX-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении XLSX
     */
    private String parseXlsx(InputStream inputStream) throws IOException {
        // потоковый разбор: DOM-модель XSSF на книгах в десятки тысяч строк
        // (финансовая структура банка, 8 МБ) падала с OutOfMemoryError при загрузке
        return XlsxStreamingParser.parse(inputStream, maxSheetsToParse, maxTotalRows);
    }

    /**
     * Извлекает текст из бинарного XLS-файла (старый формат Excel 97-2003).
     * Раньше .xls направлялся в XLSX-парсер и не разбирался.
     *
     * @param inputStream поток с XLS-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении XLS
     */
    private String parseXls(InputStream inputStream) throws IOException {
        try (HSSFWorkbook wb = new HSSFWorkbook(inputStream)) {
            return parseWorkbook(wb);
        }
    }

    /**
     * Общая логика извлечения текста из книги Excel (XLSX и XLS).
     * Обрабатывает все листы; при нескольких листах каждый помечается
     * заголовком "=== Лист: [название] ===". Формулы вычисляются.
     */
    private String parseWorkbook(Workbook wb) {
        List<String> parts = new ArrayList<>();
        DataFormatter fmt = new RussianDateFormatter();
        for (int s = 0; s < wb.getNumberOfSheets(); s++) {
            Sheet sheet = wb.getSheetAt(s);
            if (wb.getNumberOfSheets() > 1) {
                parts.add("=== Лист: " + sheet.getSheetName() + " ===");
            }
            for (Row row : sheet) {
                parts.add(parseExcelRow(row, fmt));
            }
            // пустая строка между листами
            parts.add("");
        }
        return String.join("\n", parts);
    }

    /**
     * Извлекает текст из PPTX-презентации.
     * <p>
     * Каждый слайд помечается заголовком "=== Слайд N ===". Обрабатываются
     * текстовые фигуры, таблицы (ячейки объединяются "|", как в DOCX)
     * и группы фигур (рекурсивно).
     *
     * @param inputStream поток с PPTX-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении PPTX
     */
    private String parsePptx(InputStream inputStream) throws IOException {
        ZipSecureFile.setMinInflateRatio(0);
        List<String> parts = new ArrayList<>();
        try (XMLSlideShow ppt = new XMLSlideShow(inputStream)) {
            int slideNum = 1;
            for (XSLFSlide slide : ppt.getSlides()) {
                parts.add("=== Слайд " + slideNum++ + " ===");
                for (XSLFShape shape : slide.getShapes()) {
                    appendPptxShape(shape, parts);
                }
                parts.add("");
            }
        }
        return String.join("\n", parts);
    }

    private void appendPptxShape(XSLFShape shape, List<String> parts) {
        if (shape instanceof XSLFTable table) {
            appendPptxTable(table, parts);
        } else if (shape instanceof XSLFTextShape textShape) {
            appendPptxTextShape(textShape, parts);
        } else if (shape instanceof XSLFGroupShape group) {
            for (XSLFShape child : group.getShapes()) {
                appendPptxShape(child, parts);
            }
        }
    }

    private void appendPptxTable(XSLFTable table, List<String> parts) {
        List<String> lines = new ArrayList<>();
        for (XSLFTableRow row : table.getRows()) {
            List<String> cells = new ArrayList<>();
            for (XSLFTableCell cell : row.getCells()) {
                String text = cell.getText();
                cells.add(text == null ? "" : text.strip());
            }
            lines.add("< " + String.join(" | ", cells) + " >");
        }
        parts.add("[ " + String.join("\n", lines) + " ]");
    }

    private void appendPptxTextShape(XSLFTextShape textShape, List<String> parts) {
        String text = textShape.getText();
        if (text != null && !text.isBlank()) {
            parts.add(text.strip());
        }
    }

    /**
     * Строка листа: ячейки через « | ». Формулы НЕ пересчитываются — берётся
     * сохранённый в файле результат (пересчёт падал NotImplementedException на
     * функциях, которых нет в POI, и весь файл считался повреждённым); формула
     * без сохранённого результата даётся как «=формула». Даты — дд.мм.гггг.
     *
     * @param row строка листа
     * @param fmt форматтер значений
     * @return текст строки
     */
    private String parseExcelRow(Row row, DataFormatter fmt) {
        List<String> cells = new ArrayList<>();
        for (int c = 0; c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            String val = "";
            if (cell != null && cell.getCellType() == CellType.FORMULA) {
                val = cachedFormulaValue(cell, fmt);
            } else if (cell != null && cell.getCellType() == CellType.NUMERIC) {
                val = formatNumeric(cell, fmt);
            } else if (cell != null && cell.getCellType() != CellType.BLANK) {
                val = fmt.formatCellValue(cell);
            }
            cells.add(flattenCell(val));
        }
        return String.join(" | ", cells);
    }

    /**
     * Число по формату ячейки через {@code formatRawCellContents} — как в потоковом
     * XLSX-парсере: {@code formatCellValue} форматирует даты в обход переопределения
     * и давал «7/1/20» вместо «01.07.2020».
     */
    private static String formatNumeric(Cell cell, DataFormatter fmt) {
        CellStyle style = cell.getCellStyle();
        return fmt.formatRawCellContents(cell.getNumericCellValue(),
                style == null ? -1 : style.getDataFormat(),
                style == null ? "General" : style.getDataFormatString());
    }

    /** Сохранённый результат формулы по типу кэша; без результата — текст формулы. */
    private static String cachedFormulaValue(Cell cell, DataFormatter fmt) {
        switch (cell.getCachedFormulaResultType()) {
            case NUMERIC:
                return formatNumeric(cell, fmt);
            case STRING:
                return cell.getStringCellValue();
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case ERROR:
                return "";
            default:
                return "=" + cell.getCellFormula();
        }
    }

    /**
     * Значение ячейки одной строкой: внутренние переводы строк заменяются
     * пробелом. Перенос внутри ячейки рвал текстовую строку листа пополам —
     * потребители построчного текста (regex-извлечение строк формы,
     * обогащение исходной формой) получали половину строки и сдвиг колонок.
     *
     * @param raw значение ячейки
     * @return однострочное значение без краевых пробелов
     */
    private static String flattenCell(String raw) {
        return raw == null ? "" : raw.replaceAll("[\r\n]+", " ").strip();
    }

    /**
     * Извлекает текст из XML-документа.
     * <p>
     * Универсальный передаточный документ ФНС (УПД, формат "Файл/Документ/СвСчФакт")
     * преобразуется в структурированный читаемый текст: реквизиты документа,
     * продавец/покупатель, состав работ с суммами, итог и основание передачи.
     * Прочие XML сводятся к конкатенации текстовых узлов и значимых атрибутов.
     * Внешние сущности отключены (защита от XXE).
     *
     * @param inputStream поток с XML-файлом
     * @return извлечённый текст
     * @throws IOException если XML повреждён или не разбирается
     */
    private String parseXml(InputStream inputStream) throws IOException {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
            dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            dbf.setXIncludeAware(false);
            dbf.setExpandEntityReferences(false);
            var xml = dbf.newDocumentBuilder().parse(inputStream);
            var root = xml.getDocumentElement();
            String updText = parseUpdXml(root);
            return updText != null ? updText : xmlToPlainText(root);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Не удалось разобрать XML-документ", e);
        }
    }

    /**
     * Собирает читаемый текст из УПД (счёт-фактура/акт ЭДО, приказ ФНС ММВ-7-15/820@).
     *
     * @return текст УПД или {@code null}, если структура не соответствует формату
     */
    private String parseUpdXml(Element root) {
        if (!"Файл".equals(root.getNodeName())) {
            return null;
        }
        var doc = childElement(root, "Документ");
        var schFakt = doc != null ? childElement(doc, "СвСчФакт") : null;
        if (schFakt == null) {
            return null;
        }
        List<String> parts = new ArrayList<>();
        parts.add("Универсальный передаточный документ (УПД)");
        parts.add("Номер документа: " + schFakt.getAttribute("НомерСчФ")
                + ", дата: " + schFakt.getAttribute("ДатаСчФ"));
        String function = doc.getAttribute("Функция");
        if (!function.isBlank()) {
            parts.add("Функция документа: " + function);
        }
        appendUpdParty(parts, schFakt, "СвПрод", "Продавец (исполнитель)");
        appendUpdParty(parts, schFakt, "СвПокуп", "Покупатель (заказчик)");

        appendUpdExtraInfo(parts, schFakt);
        appendUpdTable(parts, doc);
        appendUpdTransfer(parts, doc);
        return String.join("\n", parts);
    }

    /**
     * Привязка к договору: ИнфПолФХЖ1/ТекстИнф[@Идентиф="Дог"] и прочие доп. сведения.
     */
    private void appendUpdExtraInfo(List<String> parts, Element schFakt) {
        var infPol = childElement(schFakt, "ИнфПолФХЖ1");
        if (infPol != null) {
            for (var ti : childElements(infPol, "ТекстИнф")) {
                parts.add("Доп. сведения (" + ti.getAttribute("Идентиф") + "): " + ti.getAttribute("Значен"));
            }
        }
    }

    private void appendUpdTable(List<String> parts, Element doc) {
        var table = childElement(doc, "ТаблСчФакт");
        if (table == null) {
            return;
        }
        for (var row : childElements(table, "СведТов")) {
            parts.add("Позиция " + row.getAttribute("НомСтр") + ": " + row.getAttribute("НаимТов"));
            parts.add("  Стоимость без НДС: " + row.getAttribute("СтТовБезНДС")
                    + ", с НДС: " + row.getAttribute("СтТовУчНал"));
        }
        var total = childElement(table, "ВсегоОпл");
        if (total != null) {
            parts.add("ИТОГО без НДС: " + total.getAttribute("СтТовБезНДСВсего")
                    + ", с НДС: " + total.getAttribute("СтТовУчНалВсего"));
        }
    }

    private void appendUpdTransfer(List<String> parts, Element doc) {
        var prodPer = childElement(doc, "СвПродПер");
        var per = prodPer != null ? childElement(prodPer, "СвПер") : null;
        if (per == null) {
            return;
        }
        String content = per.getAttribute("СодОпер");
        if (!content.isBlank()) {
            parts.add("Содержание операции: " + content);
        }
        var osn = childElement(per, "ОснПер");
        if (osn != null) {
            String osnText = (osn.getAttribute("НаимОсн") + " " + osn.getAttribute("НомОсн")
                    + " " + osn.getAttribute("ДатаОсн")).strip().replaceAll("\\s+", " ");
            parts.add("Основание передачи: " + osnText);
        }
    }

    private void appendUpdParty(List<String> parts, Element schFakt, String tag, String title) {
        var party = childElement(schFakt, tag);
        var idSv = party != null ? childElement(party, "ИдСв") : null;
        var org = idSv != null ? childElement(idSv, "СвЮЛУч") : null;
        if (org != null) {
            parts.add(title + ": " + org.getAttribute("НаимОрг") + ", ИНН " + org.getAttribute("ИННЮЛ"));
        }
    }

    private Element childElement(Element parent, String name) {
        List<Element> found = childElements(parent, name);
        return found.isEmpty() ? null : found.get(0);
    }

    private List<Element> childElements(Element parent, String name) {
        List<Element> result = new ArrayList<>();
        var children = parent.getChildNodes();
        for (int i = 0; i < Math.min(children.getLength(), maxXmlNodes); i++) {
            if (children.item(i) instanceof Element el && name.equals(el.getNodeName())) {
                result.add(el);
            }
        }
        return result;
    }

    /**
     * Fallback для прочих XML: текстовые узлы и значимые атрибуты в порядке документа.
     */
    private String xmlToPlainText(Element root) {
        StringBuilder sb = new StringBuilder();
        collectXmlText(root, sb, new int[]{0});
        return sb.toString().strip();
    }

    private void collectXmlText(Node node, StringBuilder sb, int[] visited) {
        if (visited[0]++ > maxXmlNodes) {
            throw new FileException("XML-документ содержит слишком много узлов: " + maxXmlNodes);
        }
        if (node instanceof Element el) {
            NamedNodeMap attrs = el.getAttributes();
            for (int i = 0; i < attrs.getLength(); i++) {
                Node attr = attrs.item(i);
                String value = attr.getNodeValue();
                if (value != null && !value.isBlank()) {
                    sb.append(attr.getNodeName()).append(": ").append(value).append('\n');
                }
            }
        } else if (node.getNodeType() == Node.TEXT_NODE) {
            String text = node.getNodeValue();
            if (text != null && !text.isBlank()) {
                sb.append(text.strip()).append('\n');
            }
        }
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            collectXmlText(children.item(i), sb, visited);
        }
    }

    /**
     * Удаляет документ: удаляет файл с диска, векторные эмбеддинги и запись в БД.
     *
     * @param documentId UUID документа
     */
    public void deleteDocument(UUID documentId) {
        log.info("[{}] deleteDocument, documentId={}", CurrentUserHolder.getCurrentUser(), documentId);
        Document doc = documentRepository.findById(documentId)
                .orElseThrow(() -> new NotFoundException("Документ не найден: " + documentId));
        // Удаляем эмбеддинги
        embeddingService.deleteDocumentChunks(documentId);

        // Удаляем запись в БД
        documentRepository.delete(doc);
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Преобразует сущность Document в DTO для ответа клиенту.
     *
     * @param doc сущность документа
     * @return DTO с метаданными документа
     */
    public DocumentResponse toDto(Document doc) {
        return new DocumentResponse(
                doc.getId(),
                doc.getFilename(),
                doc.getContentType(),
                doc.getSizeBytes(),
                doc.getExtractedText() != null ? doc.getExtractedText().length() : 0,
                doc.getExtractedText(),
                doc.getCreatedAt(),
                doc.getUpdatedAt()
        );
    }

    // -------------------------------------------------------------------------
    // DTO record
    // -------------------------------------------------------------------------

    /**
     * Неизменяемый DTO для метаданных документа.
     */
    public record DocumentResponse(
            UUID id,
            String filename,
            String contentType,
            Integer sizeBytes,
            int textLength,
            String extractedText,
            OffsetDateTime createdAt,
            OffsetDateTime updatedAt
    ) {
    }
}
