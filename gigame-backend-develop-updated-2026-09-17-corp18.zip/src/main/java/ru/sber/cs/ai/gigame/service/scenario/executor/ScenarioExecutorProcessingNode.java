package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.AgentContextOverflowException;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.AgentContextBudget;
import ru.sber.cs.ai.gigame.service.AgentMemoryService;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.LlmJson;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitProcessingProgressEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitRagSearchEvent;

@Slf4j
@SuppressWarnings("java:S1192") // String literals should not be duplicated
public class ScenarioExecutorProcessingNode extends AbstractScenarioExecutor {
    private static final int DETAILS_MAX_LENGTH = 200;
    /** Строк перечня документов в системном промпте агента (системное сообщение GigaChat — до 4096 токенов). */
    static final int MAX_SYSTEM_DOCS = 40;
    /** Строк перечня документов после HTTP 413 «Tokens limit exceeded for index 0». */
    static final int SHRUNK_SYSTEM_DOCS = 10;
    static final String DOCS_HEADER = "\nДОСТУПНЫЕ ДОКУМЕНТЫ:\n";

    /**
     * Режим data.mode: документы обрабатываются группами, один LLM-вызов на группу.
     */
    static final String MODE_GROUP = "group";

    /**
     * Режим data.mode: агент — модель получает простое задание (намерение)
     * и сама читает документы инструментами (function calling), вместо
     * вставки полных текстов в промпт. Пользователю не нужен
     * профессиональный промпт-инжиниринг.
     */
    static final String MODE_AGENT = "agent";
    /**
     * Агент-ревизор: сверка входных данных с документами БЕЗ цитатной
     * валидации и добора. Выводы проверяющего («совпадает», «расхождение») —
     * вердикты, а не выписки: дословных цитат для них в документах не
     * существует, тетрадь их всегда браковала, и узел делал двойную работу.
     */
    static final String MODE_AGENT_REVIEW = "agent_review";
    /**
     * Агент по группам: docList разбивается по ключу из имени файла (регэксп
     * как в {@link #MODE_GROUP}), и на КАЖДУЮ группу выполняется отдельный
     * агентский конвейер; документы без совпадения (извещение, договор) —
     * общий контекст каждой группы. Сценарий не фиксирует число сущностей
     * (заявок, договоров) — универсален к составу комплекта, а каждый агент
     * работает с малым набором документов (закон масштаба агентного узла).
     */
    static final String MODE_AGENT_GROUP = "agent_group";
    /** Максимум пунктов плана агента: длиннее — перебор вместо работы. */
    static final int MAX_PLAN_ITEMS = 12;
    /** План из одного пункта: план не построен, раздут или не нужен (ревизор). */
    static final String WHOLE_TASK_PLAN_ITEM = "Выполнить задание целиком";
    /**
     * Пункт плана — готовый вердикт, а не вопрос к документам: «НАХОДКА №2: ПОДТВЕРЖДАЮ — …» (S1-D05, 150 таких пунктов;
     * агент копировал их в ответ). «Подтверждаю», «возражаю» и «находка №» — в любом регистре; «РАСХОЖДЕНИЕ» — только
     * прописными, как пишет вердикт модель: «найти расхождение сумм» — законный пункт. Границы слов — явные по кириллице:
     * {@code \b} с JDK 19 учитывает только ASCII-буквы.
     */
    static final Pattern PLAN_VERDICT = Pattern.compile("(?iu:НАХОДКА\\s*№|(?<![А-ЯЁа-яё])(?:ПОДТВЕРЖДАЮ|ВОЗРАЖАЮ)(?![А-ЯЁа-яё]))"
            + "|(?<![А-ЯЁа-яё])РАСХОЖДЕНИЕ(?![А-ЯЁа-яё])");
    /** Пункт плана по находке: «НАХОДКА №15: п. 2, 4 ч. 1 ст. 3 223-ФЗ: «…» — …» (ПЗД, агент h3), группа — номер находки. */
    static final Pattern PLAN_FINDING = Pattern.compile("^[^\\p{L}\\p{N}]*НАХОДКА\\s*№\\s*(\\d+)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Пункт плана по находке без готового ответа: «НАХОДКА №15». */
    static final String FINDING_PLAN_ITEM = "НАХОДКА №";
    /** Разбор контрактов выхода узла (guardrails). */
    private static final ObjectMapper CONTRACT_MAPPER = new ObjectMapper();
    /** Единственный поддерживаемый тип контракта выхода. */
    private static final String CONTRACT_JSON_ARRAY = "json_массив";
    /** Начало текста-заглушки документа, который не удалось разобрать (см. ScenarioService). */
    private static final String MANUAL_CHECK_MARKER = "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА]";
    /** Предел фрагментов базы знаний в финальном ответе агента без инструментов, символов. */
    static final int OVERFLOW_KB_CHARS = 20_000;

    /**
     * Дефолтный ключ группы: номер договора из пути/имени файла.
     */
    static final String DEFAULT_GROUP_REGEX = "(?iu)(?:договор|contract)\\s*[№#]?\\s*(\\d{5,})";
    /** Системный промпт агента после урезания (HTTP 413) — тот же для добора пунктов плана. */
    private String agentSystem;
    /** После HTTP 413 узел работает компактным набором инструментов до конца выполнения. */
    private boolean compactToolsOnly;
    /** Бюджет контекста агента: доля на задание — подстановки выражений и результаты предыдущих шагов. */
    private AgentContextBudget contextBudget = AgentContextBudget.defaults();
    /** Переполнение контекста модели в основном tool-цикле агента (null — не было): результат помечается. */
    private AgentContextOverflowException contextOverflow;
    /** Бюджет описаний функций агентного запроса, токенов ({@code app.agent.max-functions-tokens}). */
    private int maxFunctionsTokens = AgentDocumentTools.DEFAULT_MAX_FUNCTIONS_TOKENS;
    /** Урезание набора инструментов по бюджету описаний уже отмечено в журнале прогона узла. */
    private boolean functionsBudgetNoted;

    private final GigaChatClient gigaChatClient;
    private final EmbeddingService embeddingService;
    private int ragQueryMaxLength;
    private int cacheShortQueryLength;
    private int groupParallelism = 1;
    /** Память агента (уроки/планы/вопросы); null — фичи памяти выключены. */
    private AgentMemoryService agentMemory;

    /** Структурный индекс нормативки по id базы знаний (инструмент kb_article агента). */
    private java.util.function.Function<java.util.UUID, NormIndex> normIndexLoader;

    @SuppressWarnings("unused")
    protected ScenarioExecutorProcessingNode(ScenarioRunNode node) {
        super(node);
        this.embeddingService = null;
        this.gigaChatClient = null;
        this.ragQueryMaxLength = 800;
        this.cacheShortQueryLength = 200;
    }

    protected ScenarioExecutorProcessingNode(ScenarioRunNode node,
                                             GigaChatClient gigaChatClient,
                                             EmbeddingService embeddingService) {
        super(node);
        this.embeddingService = embeddingService;
        this.gigaChatClient = gigaChatClient;
        this.ragQueryMaxLength = 800;
        this.cacheShortQueryLength = 200;
    }

    /**
     * Sets configuration values from Spring properties.
     * Called by ScenarioExecutorFactory after bean creation.
     */
    protected void setConfiguration(int pRagQueryMaxLength, int pCacheShortQueryLength) {
        this.ragQueryMaxLength = pRagQueryMaxLength;
        this.cacheShortQueryLength = pCacheShortQueryLength;
    }

    /**
     * Параллельность LLM-вызовов групп в режиме group (1 — последовательно).
     */
    protected void setGroupParallelism(int parallelism) {
        this.groupParallelism = Math.max(1, parallelism);
    }

    /**
     * Бюджет контекста агента (настройки {@code app.agent.*}, вызывается фабрикой).
     *
     * @param budget бюджет (null — умолчания)
     */
    protected void setAgentContextBudget(AgentContextBudget budget) {
        this.contextBudget = budget == null ? AgentContextBudget.defaults() : budget;
    }

    /**
     * Бюджет описаний функций агентного запроса (настройка {@code app.agent.max-functions-tokens}, вызывается фабрикой).
     *
     * @param tokens бюджет, токенов (меньше 1 — умолчание {@link AgentDocumentTools#DEFAULT_MAX_FUNCTIONS_TOKENS})
     */
    protected void setMaxFunctionsTokens(int tokens) {
        this.maxFunctionsTokens = tokens < 1 ? AgentDocumentTools.DEFAULT_MAX_FUNCTIONS_TOKENS : tokens;
    }

    /** Внедряет память агента (вызывается фабрикой). */
    protected void setAgentMemory(AgentMemoryService memory) {
        this.agentMemory = memory;
    }

    protected void setNormIndexLoader(java.util.function.Function<java.util.UUID, NormIndex> loader) {
        this.normIndexLoader = loader;
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] ProcessingNode execute, node='{}' (id={})",
                currentUser(), node.getLabel(), node.getId());
        // Узел обработки (с опциональным RAG)
        // Если предыдущий узел Switch отфильтровал документы для этого узла, использовать отфильтрованный набор
        var docs = node.getDocList();
        List<String> resultList;
        if (MODE_AGENT.equals(node.getMode()) || MODE_AGENT_REVIEW.equals(node.getMode())) {
            resultList = new ArrayList<>(processAgent(sink, docs));
        } else if (MODE_AGENT_GROUP.equals(node.getMode())) {
            resultList = new ArrayList<>(processAgentGroups(sink, docs));
        } else if (!docs.isEmpty() && MODE_GROUP.equals(node.getMode())) {
            // режим группировки: один LLM-вызов на группу документов (перекрёстные проверки)
            resultList = new ArrayList<>(processDocGroups(sink, docs));
        } else {
            resultList = new ArrayList<>(processDocList(sink, docs));
            if (docs.isEmpty()) {
                if (node.getParentNodeList().get(0).getType().equals(ScenarioNodeType.LOOP_NODE)) {
                    resultList.addAll(processInputList(sink));
                } else {
                    resultList.addAll(processSimpleInput(sink));
                }
            }
        }
        resultList = applyOutputContract(sink, resultList);
        node.getOutput().addAll(resultList);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.addInputs(node.getId(), input);
        }
        return String.join("\n\n", resultList);
    }

    /**
     * Агентский режим — конвейер «план → исполнение → цитатная валидация →
     * добор → финал»:
     * <ol>
     *     <li>ПЛАН: из задания строится нумерованный чек-лист пунктов
     *     (Plan-and-Execute — покрытие полей не зависит от настроения модели);</li>
     *     <li>ИСПОЛНЕНИЕ: tool-цикл ({@link AgentDocumentTools}: поиск, чтение,
     *     БЗ, think-tool) заполняет РАБОЧУЮ ТЕТРАДЬ — по каждому пункту значение
     *     с дословной цитатой и документом-источником;</li>
     *     <li>ВАЛИДАЦИЯ: код ({@link AgentEvidence}) детерминированно проверяет,
     *     что каждая цитата действительно входит в текст документа —
     *     grounding by construction, «тихая выдумка» не проходит;</li>
     *     <li>ДОБОР: пункты плана без записей закрываются одним дополнительным
     *     tool-циклом;</li>
     *     <li>ФИНАЛ: ответ в формате задания собирается из ПРОВЕРЕННОЙ тетради;
     *     неподтверждённые значения помечаются.</li>
     * </ol>
     * Полные тексты документов в промпт не вставляются — лимиты размера
     * запроса агентскому узлу не страшны.
     */
    private List<String> processAgent(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        requireAgentInput(docs);
        var tools = buildAgentTools(docs);
        // живая трассировка: каждое действие агента — строка в лог прогона,
        // прогон перестаёт быть чёрным ящиком
        tools.setProgress(msg -> emitProcessingProgressEvent(sink, node,
                Math.max(1, tools.callCount()), AgentDocumentTools.MAX_TOOL_CALLS, msg));
        // остановка прогона: инструменты сворачиваются на ближайшем вызове
        tools.setRunCancelled(() -> node.getGraph().isCancelRequested());
        String task = buildAgentTask();
        emitTruncationNotes(sink, 1, 1, "");
        assert gigaChatClient != null;
        List<String> plan = buildAgentPlan(task);
        agentTrace(sink, tools, "🧭 план (" + plan.size() + " пунктов): "
                + StringUtils.abbreviate(String.join("; ", plan), 700));
        boolean kbConfigured = ObjectUtils.isNotEmpty(node.getKnowledgeBaseId());
        List<String> lessons = agentLessons();
        if (!lessons.isEmpty()) {
            agentTrace(sink, tools, "🧠 применяю уроки памяти: " + lessons.size());
        }
        String system = buildAgentSystemPrompt(tools.documentSummary(), kbConfigured, plan, lessons);
        prompt = system + "\n\n=== ЗАДАНИЕ ===\n" + task;

        String taskWithData = withFullDocumentList(taskWithPrefetch(sink, task, plan, tools), tools.documentSummary());
        try {
            String answer = runAgentLoop(sink, system, taskWithData, tools);
            system = agentSystem == null ? system : agentSystem;
            if (node.getGraph().isCancelRequested()) {
                throw new ScenarioException(node.getGraph().getCancelReason());
            }
            String result;
            if (MODE_AGENT_REVIEW.equals(node.getMode())) {
                // ревизор: ответ-отчёт и есть результат, тетрадь не требуется
                agentTrace(sink, tools, "🧾 режим сверки: отчёт ревизора без цитатной валидации");
                rememberPlan(task, plan);
                result = answer;
            } else {
                result = validateAndCompose(sink, tools, system, task, plan, answer);
            }
            emitProcessingProgressEvent(sink, node, 1, 1, agentDetails(plan, tools));
            return List.of(markIfContextOverflow(markIfToolLimitExhausted(tools, result)));
        } catch (Exception e) {
            // чекпойнт: собранные наблюдения переживут сбой — resume отдаст их
            // агенту рабочим файлом, цикл не начнётся с нуля
            checkpoint = tools.observationsSummary();
            throw e;
        }
    }

    /**
     * Агенту нечего исследовать: ни документов прогона (рабочие файлы не в счёт),
     * ни входа — ошибка узла, а не «успешный» ответ модели на пустоте.
     *
     * @param docs документы узла (пустой список — все документы прогона)
     */
    private void requireAgentInput(List<String> docs) {
        boolean noDocs = docs.isEmpty()
                && node.getGraph().getDocMap().values().stream().allMatch(ScenarioRunDoc::isWorkNote);
        boolean noInput = node.getInput().stream().allMatch(String::isBlank);
        if (noDocs && noInput) {
            throw new ScenarioException("Узел «" + node.getLabel()
                    + "» (агент): нет ни документов, ни входа — агенту нечего исследовать");
        }
    }

    /**
     * Лимит обращений к инструментам был исчерпан — агент мог не добрать данные:
     * пометка в начале результата, чтобы неполнота не прошла как успех.
     *
     * @param tools  инструменты агента после цикла
     * @param result результат узла
     * @return результат с пометкой либо исходный
     */
    static String markIfToolLimitExhausted(AgentDocumentTools tools, String result) {
        if (!tools.isLimitExhausted()) {
            return result;
        }
        return "⚠ Лимит инструментов агента исчерпан (" + AgentDocumentTools.MAX_TOOL_CALLS
                + " вызовов) — результат может быть неполным\n\n" + result;
    }

    /**
     * Контекст модели переполнился в tool-цикле и ответ построен без инструментов — пометка в начале результата,
     * чтобы неполнота не прошла как успех.
     *
     * @param result результат узла
     * @return результат с пометкой либо исходный
     */
    String markIfContextOverflow(String result) {
        if (contextOverflow == null) {
            return result;
        }
        return "Контекст агента усечён по лимиту модели (" + contextOverflow.limits()
                + ") — результат может быть неполным\n\n" + result;
    }

    /** Дополняет задание предвыборкой ReWOO по плану (если она что-то нашла). */
    private String taskWithPrefetch(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                    String task, List<String> plan, AgentDocumentTools tools) {
        String prefetched = rewooPrefetch(task, plan, tools);
        if (prefetched.isBlank()) {
            return task;
        }
        agentTrace(sink, tools, "⚡ предвыборка по плану: " + prefetched.length()
                + " символов фрагментов собрано без участия модели");
        return task + "\n\n=== ПРЕДВАРИТЕЛЬНО СОБРАННЫЕ ФРАГМЕНТЫ "
                + "(по плану; используй их, инструментами добирай только недостающее) ===\n"
                + prefetched;
    }

    /** Валидация тетради (с переформатом при сбое формата) и финальный ответ. */
    private String validateAndCompose(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                      AgentDocumentTools tools, String system, String task,
                                      List<String> plan, String answer) {
        var evidence = AgentEvidence.parse(answer);
        if (evidence.isEmpty() && !answer.isBlank()) {
            // финал не в формате тетради — один дешёвый переформат перед деградацией
            agentTrace(sink, tools, "🩹 финал не в формате тетради — переформатирую");
            evidence = reformatToNotebook(answer);
        }
        if (evidence.isEmpty()) {
            // тетрадь не распознана — деградация к прежнему поведению
            agentTrace(sink, tools, "⚠️ рабочая тетрадь не распознана — отдаю ответ без валидации");
            return answer;
        }
        var validated = AgentEvidence.validate(evidence, tools.docsSnapshot());
        agentTrace(sink, tools, "🧪 цитатная валидация: " + verdictSummary(validated));
        validated = coverPlanGaps(sink, system, plan, validated, tools);
        agentTrace(sink, tools, "📝 собираю финальный ответ из проверенной тетради");
        String result = composeFinalAnswer(task, validated);
        emitNodeReflection(sink, tools, plan, validated);
        result = appendAgentQuestions(sink, result, plan, validated);
        result = result + evidenceAppendix(validated);
        rememberPlan(task, plan);
        return result;
    }

    /**
     * Аудиторский след: компактная таблица источников из проверенной тетради
     * дописывается к результату узла — узлы ниже по цепочке (сводка, строки
     * формы) могут выносить источник каждого значения в отчёт/Excel.
     */
    private static String evidenceAppendix(List<AgentEvidence.Entry> validated) {
        StringBuilder sb = new StringBuilder("\n\n=== ИСТОЧНИКИ (аудит) ===\n");
        int rows = 0;
        for (AgentEvidence.Entry e : validated) {
            if (e.quote() == null || e.quote().isBlank()) {
                continue;
            }
            sb.append("- ").append(StringUtils.abbreviate(e.name(), 60)).append(" = ")
                    .append(StringUtils.abbreviate(String.valueOf(e.value()), 60))
                    .append(" | ").append(e.doc())
                    .append(" | «").append(StringUtils.abbreviate(e.quote(), 120))
                    .append("» | ").append(e.verdict()).append('\n');
            rows++;
        }
        return rows == 0 ? "" : sb.toString();
    }

    /**
     * Выходной контракт узла (guardrails): в {@code data.rules} узла обработки
     * можно объявить {"контракт": {"тип": "json_массив",
     * "обязательные_ключи": ["..."], "мин_элементов": N}} — выход проверяется
     * КОДОМ, при нарушении делается один repair-вызов с текстом ошибки,
     * повторное нарушение роняет узел (on_error решает дальнейшее).
     */
    private List<String> applyOutputContract(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             List<String> resultList) {
        var contract = readOutputContract();
        if (contract == null) {
            return resultList;
        }
        String type = contract.path("тип").asText();
        if (!CONTRACT_JSON_ARRAY.equals(type)) {
            // ошибка конфигурации узла: автор узнаёт сразу, а не после «успешного» прогона без проверки
            emitProcessingProgressEvent(sink, node, 1, 1, "📐 контракт: тип «" + type + "» не поддерживается");
            throw new ScenarioException("Контракт выхода узла «" + node.getLabel() + "»: тип «" + type
                    + "» не поддерживается (поддерживается только «" + CONTRACT_JSON_ARRAY + "»)");
        }
        if (gigaChatClient == null) {
            return resultList;
        }
        String joined = String.join("\n\n", resultList);
        String violation = contractViolation(contract, joined);
        if (violation == null) {
            warnIfEmptyArray(sink, joined);
            return resultList;
        }
        emitProcessingProgressEvent(sink, node, 1, 1,
                "📐 контракт выхода нарушен (" + violation + ") — запрашиваю исправление");
        String repaired = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                "Твой ответ не прошёл проверку формата: " + violation + ". Исправь и верни "
                        + "ПОЛНЫЙ ответ в требуемом формате, не теряя данных. Верни ТОЛЬКО "
                        + "исправленный ответ.\n\n=== ТВОЙ ОТВЕТ ===\n" + joined)),
                node.getModel(), node.getTemperature());
        String again = contractViolation(contract, repaired);
        if (again != null) {
            throw new ScenarioException("Выход узла не соответствует контракту: " + again);
        }
        warnIfEmptyArray(sink, repaired);
        return List.of(repaired);
    }

    /**
     * json_массив без элементов при мин_элементов=0 формально проходит контракт —
     * предупреждение в журнал, чтобы пустой результат узла не остался незамеченным.
     */
    private void warnIfEmptyArray(FluxSink<ServerSentEvent<Map<String, Object>>> sink, String text) {
        String block = lastJsonArray(text);
        if (block != null && "[]".equals(block.replaceAll("\\s", ""))) {
            emitProcessingProgressEvent(sink, node, 1, 1,
                    "📐 контракт: JSON-массив пуст (0 элементов при мин_элементов=0) — результат узла пустой");
        }
    }

    /** Контракт из rules узла или {@code null}, если не объявлен/не распознан. */
    private JsonNode readOutputContract() {
        String rules = node.getRules();
        if (rules == null || rules.isBlank()) {
            return null;
        }
        try {
            var parsed = CONTRACT_MAPPER.readTree(rules).path("контракт");
            return parsed.isMissingNode() || parsed.isNull() ? null : parsed;
        } catch (Exception e) {
            return null;
        }
    }

    /** Текст нарушения контракта или {@code null}, если выход корректен. */
    private static String contractViolation(JsonNode contract, String text) {
        if (!CONTRACT_JSON_ARRAY.equals(contract.path("тип").asText())) {
            return null;
        }
        String block = lastJsonArray(text);
        if (block == null) {
            return "в ответе нет корректного JSON-массива";
        }
        JsonNode rows;
        try {
            rows = CONTRACT_MAPPER.readTree(block);
        } catch (Exception e) {
            return "JSON-массив не разбирается: " + e.getMessage();
        }
        int min = contract.path("мин_элементов").asInt(0);
        if (rows.size() < min) {
            return "элементов " + rows.size() + ", требуется не менее " + min;
        }
        for (JsonNode key : contract.path("обязательные_ключи")) {
            for (int i = 0; i < rows.size(); i++) {
                if (!rows.get(i).has(key.asText())) {
                    return "у элемента " + (i + 1) + " нет обязательного ключа «"
                            + key.asText() + "»";
                }
            }
        }
        return null;
    }

    /**
     * Последний разбираемый JSON-массив объектов (или пустой) в тексте или {@code null}:
     * перебор с конца до первого разбираемого — «[см. выше]» в хвосте ответа больше не
     * заслоняет корректный массив выше и не гоняет узел по кругу исправлений.
     */
    private static String lastJsonArray(String text) {
        LlmJson.Parsed block = LlmJson.last(text, LlmJson.ARRAY_OF_OBJECTS_OR_EMPTY).first();
        return block == null ? null : block.json();
    }

    /** Строка трассировки конвейера агента в лог прогона. */
    private void agentTrace(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                            AgentDocumentTools tools, String message) {
        emitProcessingProgressEvent(sink, node,
                Math.max(1, tools.callCount()), AgentDocumentTools.MAX_TOOL_CALLS, message);
    }

    /**
     * Рефлексия узла (Reflexion в миниатюре): генерируется только при
     * отклонениях и только о них — общие слова запрещены промптом.
     * На гладком прогоне рефлексировать не о чем — пропуск без вызова.
     * Сбой рефлексии не влияет на результат узла.
     */
    private void emitNodeReflection(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                    AgentDocumentTools tools, List<String> plan,
                                    List<AgentEvidence.Entry> validated) {
        List<String> deviations = reflectionDeviations(plan, validated);
        if (deviations.isEmpty()) {
            return;
        }
        try {
            String reflection = gigaChatClient.chatCompletion(List.of(Map.of("role", "user",
                    "content", "Ты выполнил задание агентом, часть пунктов прошла НЕ гладко:\n- "
                            + String.join("\n- ", deviations)
                            + "\nДай рефлексию в 2-4 предложениях от первого лица ТОЛЬКО об этих "
                            + "отклонениях: почему не нашлось или не подтвердилось и какое "
                            + "конкретное правило помогло бы в следующий раз. Общие слова "
                            + "(«прошло гладко», «стоит быть внимательнее») запрещены.\n"
                            + "Журнал действий:\n"
                            + StringUtils.abbreviate(String.join("\n", tools.callLog()), 3000))),
                    node.getModel(), node.getTemperature());
            agentTrace(sink, tools, "🪞 рефлексия: " + StringUtils.abbreviate(reflection, 600));
        } catch (Exception e) {
            log.warn("[{}] Рефлексия узла не удалась: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /** Отклонения прогона для рефлексии: всё, что прошло не гладко. */
    private static List<String> reflectionDeviations(List<String> plan,
                                                     List<AgentEvidence.Entry> validated) {
        List<String> deviations = new ArrayList<>();
        for (var e : validated) {
            boolean notSpecified = AgentEvidence.NOT_SPECIFIED
                    .equalsIgnoreCase(String.valueOf(e.value()).strip());
            if (!AgentEvidence.CONFIRMED.equals(e.verdict()) || notSpecified) {
                deviations.add("пункт " + e.item() + " «" + e.name() + "» — "
                        + (notSpecified ? "значение не найдено (не указано)" : e.verdict()));
            }
        }
        for (Integer i : AgentEvidence.uncoveredItems(plan.size(), validated)) {
            deviations.add("пункт " + i + " плана остался незакрытым");
        }
        return deviations;
    }

    /** Сводка вердиктов валидации для трассировки. */
    private String verdictSummary(List<AgentEvidence.Entry> validated) {
        long confirmed = validated.stream()
                .filter(e -> AgentEvidence.CONFIRMED.equals(e.verdict())).count();
        long calculated = validated.stream()
                .filter(e -> AgentEvidence.CALCULATED.equals(e.verdict())).count();
        long rejected = validated.size() - confirmed - calculated;
        return confirmed + " подтверждено, " + calculated + " расчётных, "
                + rejected + " отклонено";
    }

    /** Уроки из памяти агента (частные сценария + одобренные общие). */
    private List<String> agentLessons() {
        if (agentMemory == null) {
            return List.of();
        }
        try {
            return agentMemory.lessonsForScenario(node.getGraph().getScenarioId(),
                    node.getGraph().getRunnerUserId());
        } catch (Exception e) {
            log.warn("[{}] Уроки агента недоступны: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    /**
     * Сохраняет план успешного прогона в память планов. Раздутые планы
     * не запоминаются: развёрнутый по сущностям чек-лист (21 пункт на
     * 3 заявки) на повторе превращался в механический перебор поисков
     * дословными формулировками пунктов.
     */
    private void rememberPlan(String task, List<String> plan) {
        // план по находкам не запоминается: номера находок — свои у каждого прогона
        if (agentMemory != null && plan.size() > 1 && plan.size() <= MAX_PLAN_ITEMS && withoutVerdicts(plan).size() == plan.size()) {
            agentMemory.savePlan(node.getGraph().getScenarioId(), task, plan);
        }
    }

    /**
     * Переформат ответа, отданного не в формате тетради: один дешёвый вызов
     * без инструментов — иначе узел уходил в деградацию без цитатной
     * валидации при верных, но неструктурированных данных.
     *
     * @return распознанная тетрадь или пустой список — деградация как раньше
     */
    private List<AgentEvidence.Entry> reformatToNotebook(String answer) {
        try {
            String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                    "Переложи свой ответ ниже СТРОГО в JSON рабочей тетради: {\"записи\": "
                            + "[{\"пункт\": N, \"название\": \"...\", \"значение\": \"...\", "
                            + "\"цитата\": \"дословная цитата из ответа\", \"документ\": "
                            + "\"имя файла\"}]}. Ничего не добавляй от себя, значения и цитаты "
                            + "бери только из ответа. Верни ТОЛЬКО JSON.\n\n=== ОТВЕТ ===\n"
                            + StringUtils.abbreviate(answer, 12000))),
                    node.getModel(), node.getTemperature());
            return AgentEvidence.parse(raw);
        } catch (Exception e) {
            log.warn("[{}] Переформат тетради не удался: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return List.of();
        }
    }

    /**
     * Асинхронный human-in-the-loop: спорные записи тетради (значение без
     * подтверждённой цитаты) и ненайденные данные превращаются в вопросы
     * пользователю. Прогон НЕ останавливается: вопросы сохраняются в память
     * (ответ станет уроком сценария) и дублируются блоком в результате узла.
     */
    private String appendAgentQuestions(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                        String result, List<String> plan,
                                        List<AgentEvidence.Entry> validated) {
        List<String> questions = AgentEvidence.buildQuestions(plan, validated);
        if (questions.isEmpty()) {
            return result;
        }
        emitProcessingProgressEvent(sink, node, 1, 1,
                "❓ вопросов пользователю: " + questions.size()
                        + " (ответы в карточке прогона станут уроками)");
        if (agentMemory != null && node.getGraph().getRunId() != null) {
            try {
                agentMemory.saveQuestions(node.getGraph().getRunId(),
                        node.getGraph().getScenarioId(), node.getLabel(), questions);
            } catch (Exception e) {
                log.warn("[{}] Вопросы агента не сохранены: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            }
        }
        StringBuilder sb = new StringBuilder(result)
                .append("\n\n=== АГЕНТ ПРОСИТ УТОЧНИТЬ ")
                .append("(ответьте в карточке прогона — ответы сохранятся в память сценария) ===\n");
        for (int i = 0; i < questions.size(); i++) {
            sb.append(i + 1).append(". ").append(questions.get(i)).append('\n');
        }
        return sb.toString();
    }

    private AgentDocumentTools buildAgentTools(List<String> docs) {
        // docList раздаёт только input-узел своим детям; агент-узлы дальше по
        // цепочке (например, критик после аналитика) без этого работали бы
        // вслепую — при пустом docList агент получает ВСЕ документы прогона
        List<ScenarioRunDoc> selected =
                docs.isEmpty()
                        ? new ArrayList<>(node.getGraph().getDocMap().values())
                        : docs.stream()
                                .map(id -> node.getGraph().getDocMap().get(id))
                                .collect(Collectors.toCollection(ArrayList::new));
        // рабочие файлы прошлых агент-узлов видимы всегда (общая ФС прогона)
        for (var doc : node.getGraph().getDocMap().values()) {
            if (doc.isWorkNote() && !selected.contains(doc)) {
                selected.add(doc);
            }
        }
        List<AgentDocumentTools.DocEntry> entries = selected.stream()
                .map(d -> new AgentDocumentTools.DocEntry(d.getFilename(), d.getText()))
                .toList();
        boolean kbConfigured = ObjectUtils.isNotEmpty(node.getKnowledgeBaseId());
        var tools = new AgentDocumentTools(entries,
                kbConfigured ? q -> ragSearchForNode(q, "", node.getKnowledgeBaseId()) : null);
        if (kbConfigured && normIndexLoader != null) {
            java.util.UUID kbId = node.getKnowledgeBaseId();
            tools.setNormIndex(() -> normIndexLoader.apply(kbId));
        }
        for (var doc : selected) {
            if (doc.isWorkNote()) {
                tools.markWorkNote(doc.getFilename());
            }
        }
        tools.setWriteSink((name, text) -> node.getGraph().addWorkingDoc(name, text));
        // кодовые проверки документов прогона (сверка сумм/процентов/дат, regex, цитаты) — те же операции,
        // что у узла «Трансформация», документы берутся из графа узла
        tools.setOperationRunner((operation, params, input) ->
                new ScenarioExecutorTransformNode(node).runOperation(operation, params, input));
        return tools;
    }

    /**
     * План-чеклист из задания: один дешёвый вызов без инструментов.
     * При нераспознанном ответе — деградация к плану из одного пункта.
     * <p>
     * Пункты-вердикты ({@link #PLAN_VERDICT}) отбрасываются, пункты по находкам сводятся к номерам находок, больше
     * {@link #MAX_PLAN_ITEMS} пунктов-вопросов заменяются одним пунктом ({@link #boundedPlan}): S1-D05 — 150 пунктов
     * «НАХОДКА №N: ПОДТВЕРЖДАЮ», агент их копировал. Ревизору ({@link #MODE_AGENT_REVIEW}) план не строится: план-вызов
     * сам отвечал на задание сверки. План из памяти берётся без пунктов по находкам: номера находок — свои у прогона.
     */
    private List<String> buildAgentPlan(String task) {
        if (MODE_AGENT_REVIEW.equals(node.getMode())) {
            log.info("[{}] Агент-ревизор: план не строится — задание целиком", CurrentUserHolder.getCurrentUser());
            return List.of(WHOLE_TASK_PLAN_ITEM);
        }
        if (agentMemory != null) {
            try {
                List<String> found = agentMemory.findPlan(node.getGraph().getScenarioId(), task);
                List<String> remembered = found == null ? List.of() : withoutVerdicts(found);
                if (!remembered.isEmpty() && remembered.size() <= MAX_PLAN_ITEMS) {
                    log.info("[{}] Агент: план из памяти ({} пунктов)", CurrentUserHolder.getCurrentUser(), remembered.size());
                    return remembered;
                }
            } catch (Exception e) {
                log.warn("[{}] Память планов недоступна: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
            }
        }
        try {
            String raw = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content",
                            "Разбей задание на чек-лист конкретных пунктов-вопросов к документам "
                                    + "(от 3 до " + MAX_PLAN_ITEMS + ", каждый пункт — одно "
                                    + "проверяемое значение или маленькая группа связанных "
                                    + "значений). Несколько однотипных сущностей (заявки, акты, "
                                    + "договоры) НЕ разворачивай в отдельные пункты по каждой — "
                                    + "делай один обобщённый пункт «для каждой …». Пункты — только "
                                    + "ДАННЫЕ из документов (значения, числа, даты, списки); НЕ "
                                    + "включай пункты-проверки процесса («проверить наличие», "
                                    + "«убедиться в корректности/полноте») — наличие и полнота "
                                    + "видны по самим найденным данным. Верни ТОЛЬКО "
                                    + "JSON-массив строк без пояснений.\n\n=== ЗАДАНИЕ ===\n" + task)
            ), node.getModel(), node.getTemperature());
            List<String> plan = boundedPlan(AgentEvidence.parsePlan(raw));
            if (!plan.isEmpty()) {
                return plan;
            }
        } catch (Exception e) {
            log.warn("[{}] План агента не построен ({}), работаю без чек-листа", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
        return List.of(WHOLE_TASK_PLAN_ITEM);
    }

    /**
     * План после разбора. Пункты по находкам («НАХОДКА №15: п. 2, 4 ч. 1 ст. 3 223-ФЗ: «…» — …») сводятся к номеру
     * находки «НАХОДКА №15» без готового ответа и по длине не ограничиваются: по ним добор ({@link #coverPlanGaps})
     * находит пропущенные находки (ПЗД Z007, агент h3 — 41 находка, Z014 — 15). Прочие пункты-вердикты
     * ({@link #PLAN_VERDICT}) отбрасываются. Больше {@link #MAX_PLAN_ITEMS} пунктов-вопросов — перебор вместо работы:
     * остаются пункты по находкам, а без них — один пункт {@link #WHOLE_TASK_PLAN_ITEM}. Пустой — пустой (вызывающий
     * деградирует к одному пункту).
     *
     * @param parsed пункты плана из ответа модели
     * @return пригодный план
     */
    static List<String> boundedPlan(List<String> parsed) {
        Set<String> findings = new LinkedHashSet<>();
        List<String> questions = new ArrayList<>();
        List<String> plan = new ArrayList<>();
        for (String item : parsed) {
            Matcher finding = PLAN_FINDING.matcher(item);
            if (finding.find()) {
                String number = FINDING_PLAN_ITEM + finding.group(1);
                if (findings.add(number)) {
                    plan.add(number);
                }
            } else if (!PLAN_VERDICT.matcher(item).find()) {
                questions.add(item);
                plan.add(item);
            }
        }
        if (plan.size() < parsed.size() || questions.size() > MAX_PLAN_ITEMS) {
            log.warn("[{}] Агент: в плане {} пунктов, по находкам {}, вопросов {}{}", CurrentUserHolder.getCurrentUser(), parsed.size(),
                    findings.size(), questions.size(), questions.size() > MAX_PLAN_ITEMS ? " — вопросы заменены" : "");
        }
        if (questions.size() <= MAX_PLAN_ITEMS) {
            return plan;
        }
        return findings.isEmpty() ? List.of(WHOLE_TASK_PLAN_ITEM) : List.copyOf(findings);
    }

    /**
     * Пункты плана без готовых вердиктов ({@link #PLAN_VERDICT}).
     *
     * @param plan пункты плана
     * @return пункты-вопросы к документам
     */
    static List<String> withoutVerdicts(List<String> plan) {
        return plan.stream().filter(item -> !PLAN_VERDICT.matcher(item).find()).toList();
    }

    /**
     * ReWOO-предвыборка: один вызов планирует поисковые запросы по пунктам
     * плана (с целевыми документами), код исполняет их пакетом БЕЗ модели —
     * основной цикл стартует с уже собранными фрагментами и делает в разы
     * меньше round-trip'ов (боль больших комплектов и нестабильной сети).
     * Любой сбой фазы — тихая деградация к обычному циклу.
     */
    private String rewooPrefetch(String task, List<String> plan, AgentDocumentTools tools) {
        try {
            StringBuilder planText = new StringBuilder();
            for (int i = 0; i < plan.size(); i++) {
                planText.append(i + 1).append(". ").append(plan.get(i)).append('\n');
            }
            String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                    "По плану и заданию составь поисковые запросы к документам: на каждый пункт "
                            + "1-2 КОРОТКИХ ключевых слова/термина (и число, если ищется число). "
                            + "Укажи целевые документы подстроками их имён, если очевидно из "
                            + "задания. Верни ТОЛЬКО JSON-массив объектов "
                            + "{\"запрос\": \"...\", \"документы\": [\"...\"]} без пояснений.\n\n"
                            + "=== ДОКУМЕНТЫ ===\n" + String.join("\n", tools.documentSummary())
                            + "\n\n=== ПЛАН ===\n" + planText
                            + "\n=== ЗАДАНИЕ ===\n" + StringUtils.abbreviate(task, 4000))),
                    node.getModel(), node.getTemperature());
            var queries = AgentEvidence.parseSearchPlan(raw);
            if (queries.isEmpty()) {
                return "";
            }
            return tools.prefetch(queries);
        } catch (Exception e) {
            log.warn("[{}] ReWOO-предвыборка не удалась ({}), обычный цикл", CurrentUserHolder.getCurrentUser(), e.getMessage());
            return "";
        }
    }

    /**
     * Основной tool-цикл с добивающим вызовом при пустом финале; переполнение контекста модели — финальный ответ
     * без инструментов ({@link #answerWithoutTools}), узел не падает.
     */
    private String runAgentLoop(FluxSink<ServerSentEvent<Map<String, Object>>> sink, String system, String task,
                                AgentDocumentTools tools) {
        contextOverflow = null;
        GigaChatClient.ChatResult chat;
        try {
            chat = callToolLoop(system, task, tools);
        } catch (AgentContextOverflowException e) {
            return answerWithoutTools(sink, task, tools, e);
        }
        if (agentSystem != null) {
            log.info("[{}] Агент: системный промпт урезан после HTTP 413, дальнейшие вызовы — с урезанным",
                    CurrentUserHolder.getCurrentUser());
        }
        String answer = chat.text();
        if (answer == null || answer.isBlank()) {
            answer = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content",
                            task + "\n\n=== ДАННЫЕ, СОБРАННЫЕ ИЗ ДОКУМЕНТОВ ===\n"
                                    + tools.observationsSummary()
                                    + "\nСформулируй рабочую тетрадь (формат из задания) строго "
                                    + "по этим данным. Чего в данных нет — 'не указано'.")
            ), node.getModel(), node.getTemperature());
        }
        return answer;
    }

    /**
     * Финальный ответ агента без инструментов, когда запрос tool-цикла больше окна модели и после сжатия истории:
     * урезанное до бюджета задание, сводка наблюдений инструментов и фрагменты базы знаний.
     *
     * @param sink  поток событий прогона
     * @param task  задание агента
     * @param tools инструменты агента с накопленными наблюдениями
     * @param e     переполнение контекста
     * @return ответ модели
     */
    private String answerWithoutTools(FluxSink<ServerSentEvent<Map<String, Object>>> sink, String task,
                                      AgentDocumentTools tools, AgentContextOverflowException e) {
        contextOverflow = e;
        log.warn("[{}] Агент: {} — финальный ответ без инструментов", CurrentUserHolder.getCurrentUser(), e.getMessage());
        agentTrace(sink, tools, "✂ контекст агента больше окна модели (" + e.limits()
                + ") — финальный ответ без инструментов по собранным наблюдениям");
        int limit = contextBudget.taskChars();
        String shortTask = task.length() <= limit ? task
                : task.substring(0, limit) + "\n[... задание усечено по бюджету контекста агента ...]";
        String kb = tools.kbFragmentsSummary(OVERFLOW_KB_CHARS);
        String content = shortTask + "\n\n=== ДАННЫЕ, СОБРАННЫЕ ИЗ ДОКУМЕНТОВ ===\n" + tools.observationsSummary()
                + (kb.isEmpty() ? "" : "\n\n=== ФРАГМЕНТЫ БАЗЫ ЗНАНИЙ ===\n" + kb)
                + "\n\nИнструменты недоступны: контекст превысил лимит модели. Сформулируй ответ (формат из задания) "
                + "строго по этим данным. Чего в данных нет — 'не указано'.";
        return gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", content)),
                node.getModel(), node.getTemperature());
    }

    /**
     * Tool-цикл с повторами при HTTP 413 «Tokens limit exceeded for index 0».
     * <p>
     * Эксперимент 13.09.2026 (дамп Комплекта 6, 261 файл): ошибка зависит от числа функций
     * и длины задания, а не от системного промпта — с 7 и более функциями длинное задание
     * отклоняется, с шестью проходит (см. {@link AgentDocumentTools#MAX_TOOLS_FOR_LONG_TASK}).
     * Набор инструментов — по режиму узла в пределах бюджета описаний ({@link #agentToolSet}). Ступени: урезанный
     * по приоритету набор ({@link AgentDocumentTools#compact}) → то же без полного перечня документов в задании → то же
     * с системным промптом без перечня и уроков; каждая ступень после 413 — пометка в журнале прогона. Инструменты не
     * отключаются: урезанный набор всегда содержит поиск и чтение документов.
     *
     * @param system системный промпт
     * @param task   задание
     * @param tools  инструменты агента
     * @return ответ модели
     */
    private GigaChatClient.ChatResult callToolLoop(String system, String task, AgentDocumentTools tools) {
        String current = agentSystem == null ? system : agentSystem;
        List<ToolCallback> full = agentToolSet(tools);
        List<ToolAttempt> attempts = toolAttempts(current, task, full);
        RuntimeException last = null;
        for (int i = 0; i < attempts.size(); i++) {
            ToolAttempt attempt = attempts.get(i);
            try {
                var result = gigaChatClient.chatCompletionWithTools(agentMessages(attempt.system(), attempt.task()),
                        attempt.tools(), node.getModel(), node.getTemperature());
                rememberAttempt(attempt, current, full);
                return result;
            } catch (RuntimeException e) {
                if (!isSystemTooLong(e)) {
                    throw e;
                }
                last = e;
                reportTooLong(tools, attempt, i + 1 < attempts.size() ? attempts.get(i + 1) : null, e);
            }
        }
        throw last;
    }

    /**
     * Инструменты tool-цикла: ревизору ({@link #MODE_AGENT_REVIEW}) — только чтение и поиск по документам и базе знаний
     * ({@link AgentDocumentTools#reviewCallbacks()}), остальным режимам — полный набор; сверх бюджета описаний функций
     * {@code app.agent.max-functions-tokens} инструменты передаются по приоритету, пока укладываются (WARN в лог и
     * пометка в журнале прогона — один раз за выполнение узла).
     *
     * @param tools инструменты агента
     * @return набор для запроса
     */
    private List<ToolCallback> agentToolSet(AgentDocumentTools tools) {
        List<ToolCallback> modeSet = MODE_AGENT_REVIEW.equals(node.getMode()) ? tools.reviewCallbacks() : tools.callbacks();
        List<ToolCallback> selected = AgentDocumentTools.withinBudget(modeSet, maxFunctionsTokens, contextBudget);
        if (selected.size() < modeSet.size() && !functionsBudgetNoted) {
            functionsBudgetNoted = true;
            String notice = "✂ описания инструментов агента ≈" + AgentDocumentTools.functionsTokens(modeSet, contextBudget)
                    + " токенов больше бюджета " + maxFunctionsTokens + " — переданы по приоритету " + selected.size() + " из "
                    + modeSet.size() + ": " + AgentDocumentTools.names(selected);
            log.warn("[{}] Агент: {}", CurrentUserHolder.getCurrentUser(), notice);
            tools.progressNote(notice);
        }
        return selected;
    }

    /**
     * Ступени tool-цикла (см. {@link #callToolLoop}); после 413 на урезанном наборе узел сразу идёт с ним.
     *
     * @param current системный промпт
     * @param task    задание
     * @param full    набор инструментов узла
     * @return ступени по порядку
     */
    private List<ToolAttempt> toolAttempts(String current, String task, List<ToolCallback> full) {
        List<ToolCallback> compact = AgentDocumentTools.compact(full);
        String shortTask = stripTaskDocumentList(task);
        String stripped = dropLessons(stripDocumentList(current));
        List<ToolAttempt> attempts = new ArrayList<>();
        if (!compactToolsOnly) {
            attempts.add(new ToolAttempt(current, task, full, "полный набор инструментов"));
        }
        if (compact.size() < full.size() || compactToolsOnly) {
            attempts.add(new ToolAttempt(current, task, compact, "компактный набор (" + compact.size() + " инструментов)"));
        }
        if (!shortTask.equals(task)) {
            attempts.add(new ToolAttempt(current, shortTask, compact, "компактный набор, задание без полного перечня документов"));
        }
        if (!stripped.equals(current)) {
            attempts.add(new ToolAttempt(stripped, shortTask, compact, "компактный набор, системный промпт без перечня и уроков"));
        }
        return attempts;
    }

    /**
     * Удачная ступень: урезанный системный промпт становится промптом узла, урезанный набор инструментов — набором
     * следующих tool-циклов узла (добор пунктов плана).
     */
    private void rememberAttempt(ToolAttempt attempt, String current, List<ToolCallback> full) {
        if (!attempt.system().equals(current)) {
            agentSystem = attempt.system();
            prompt = attempt.system() + "\n\n=== ЗАДАНИЕ ===\n" + attempt.task();
        }
        compactToolsOnly = compactToolsOnly || attempt.tools().size() < full.size();
    }

    /**
     * HTTP 413 «index 0» на ступени: WARN в лог, пометка в журнале прогона со следующей ступенью, дамп промпта.
     *
     * @param tools   инструменты агента (журнал прогона)
     * @param attempt отклонённая ступень
     * @param next    следующая ступень (null — ступени исчерпаны)
     * @param e       ошибка вызова
     */
    private void reportTooLong(AgentDocumentTools tools, ToolAttempt attempt, ToolAttempt next, RuntimeException e) {
        String reason = e.getCause() == null ? e.getMessage() : e.getCause().getMessage();
        log.warn("[{}] Агент: GigaChat отклонил запрос по лимиту (HTTP 413 index 0; {}: {} функций, задание {} символов): {}",
                CurrentUserHolder.getCurrentUser(), attempt.label(), attempt.tools().size(), attempt.task().length(), reason);
        tools.progressNote("✂ GigaChat отклонил запрос агента по лимиту (HTTP 413 «index 0»; " + attempt.label() + ", "
                + attempt.tools().size() + " функций) — " + (next == null ? "ступени повтора исчерпаны"
                : "повтор: " + next.label() + " (" + next.tools().size() + " функций: " + AgentDocumentTools.names(next.tools()) + ")"));
        dumpSystemPrompt(attempt.system(), attempt.task());
    }

    /** Ступень повтора tool-цикла: системный промпт, задание, набор инструментов и метка для лога. */
    private record ToolAttempt(String system, String task, List<ToolCallback> tools, String label) {
    }

    /**
     * Задание без блока «=== ПОЛНЫЙ ПЕРЕЧЕНЬ ДОКУМЕНТОВ» (см. {@link #withFullDocumentList}):
     * имена документов остаются доступны через search_documents.
     *
     * @param task задание
     * @return задание без перечня (без блока — без изменений)
     */
    static String stripTaskDocumentList(String task) {
        int start = task.indexOf("\n\n=== ПОЛНЫЙ ПЕРЕЧЕНЬ ДОКУМЕНТОВ");
        return start < 0 ? task : task.substring(0, start)
                + "\n\n(полный перечень документов не поместился в лимит GigaChat — имена документов ищи через search_documents)";
    }

    /** Системный промпт и задание, отвергнутые GigaChat по лимиту, — в файл во временном каталоге для разбора. */
    private static void dumpSystemPrompt(String system, String task) {
        try {
            java.nio.file.Files.writeString(java.nio.file.Path.of(System.getProperty("java.io.tmpdir"), "gigame-agent-413-system.txt"),
                    system + "\n\n=== ЗАДАНИЕ ===\n" + task, java.nio.charset.StandardCharsets.UTF_8);
        } catch (java.io.IOException e) {
            log.warn("[{}] Не удалось сохранить промпт агента: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /**
     * Системный промпт без перечня документов (остаётся подсказка про search_documents) — последняя ступень при HTTP 413.
     *
     * @param system системный промпт
     * @return промпт без перечня (без блока — без изменений)
     */
    static String stripDocumentList(String system) {
        int start = system.indexOf(DOCS_HEADER);
        int end = start < 0 ? -1 : system.indexOf("\nПЛАН (чек-лист", start);
        if (start < 0 || end < 0) {
            return system;
        }
        return system.substring(0, start) + DOCS_HEADER
                + "- (перечень не поместился в лимит: имена и содержимое документов — через search_documents)\n"
                + system.substring(end);
    }

    private static List<Map<String, String>> agentMessages(String system, String task) {
        return List.of(Map.of("role", "system", "content", system), Map.of("role", "user", "content", task));
    }

    /**
     * Ошибка GigaChat о превышении лимита токенов первого (системного) сообщения.
     *
     * @param e исключение с цепочкой причин
     * @return true — HTTP 413 «Tokens limit exceeded for index 0»
     */
    static boolean isSystemTooLong(Throwable e) {
        Throwable t = e;
        for (int depth = 0; t != null && depth < 8; depth++) {
            String msg = String.valueOf(t.getMessage());
            if (msg.contains("Tokens limit exceeded") && msg.contains("index 0")) {
                return true;
            }
            t = t.getCause() == t ? null : t.getCause();
        }
        return false;
    }

    /**
     * Системный промпт с перечнем документов, урезанным до {@link #SHRUNK_SYSTEM_DOCS} строк.
     *
     * @param system системный промпт
     * @return промпт с коротким перечнем (без перечня — без изменений)
     */
    static String shrinkDocumentList(String system) {
        int start = system.indexOf(DOCS_HEADER);
        int end = start < 0 ? -1 : system.indexOf("\nПЛАН (чек-лист", start);
        if (start < 0 || end < 0) {
            return system;
        }
        // строки перечня без служебной «- … и ещё N документов»; число скрытых считается по документам, а не строкам
        List<String> names = new ArrayList<>();
        int hiddenBefore = 0;
        for (String line : system.substring(start + DOCS_HEADER.length(), end).split("\n")) {
            Matcher more = Pattern.compile("^- … и ещё (\\d+) документов").matcher(line);
            if (more.find()) {
                hiddenBefore = Integer.parseInt(more.group(1));
            } else if (!line.isBlank()) {
                names.add(line);
            }
        }
        if (names.size() <= SHRUNK_SYSTEM_DOCS) {
            return system;
        }
        StringBuilder sb = new StringBuilder(DOCS_HEADER);
        for (int i = 0; i < SHRUNK_SYSTEM_DOCS; i++) {
            sb.append(names.get(i)).append('\n');
        }
        sb.append("- … остальные документы (").append(names.size() - SHRUNK_SYSTEM_DOCS + hiddenBefore)
                .append("): полный перечень — в задании, содержимое — через search_documents\n");
        return system.substring(0, start) + sb + system.substring(end);
    }

    /**
     * Системный промпт без блока «УРОКИ ИЗ ПРОШЛЫХ ПРОГОНОВ» — второй уровень деградации при HTTP 413.
     *
     * @param system системный промпт
     * @return промпт без уроков (без блока — без изменений)
     */
    static String dropLessons(String system) {
        int start = system.indexOf("\nУРОКИ ИЗ ПРОШЛЫХ ПРОГОНОВ");
        int end = start < 0 ? -1 : system.indexOf("\nМЕТОДИКА:", start);
        if (start < 0 || end < 0) {
            return system;
        }
        return system.substring(0, start) + system.substring(end);
    }

    /**
     * Перечень документов системного промпта — не больше {@link #MAX_SYSTEM_DOCS} строк;
     * остальные имена агент получает в задании и через search_documents.
     *
     * @param sb         системный промпт
     * @param docSummary перечень «имя (N символов)»
     */
    static void appendDocumentList(StringBuilder sb, List<String> docSummary) {
        sb.append(DOCS_HEADER);
        int shown = Math.min(docSummary.size(), MAX_SYSTEM_DOCS);
        for (int i = 0; i < shown; i++) {
            sb.append("- ").append(docSummary.get(i)).append('\n');
        }
        if (docSummary.size() > shown) {
            sb.append("- … и ещё ").append(docSummary.size() - shown)
                    .append(" документов: полный перечень — в задании, содержимое — через search_documents\n");
        }
    }

    /**
     * Полный перечень документов в задании, если в системный промпт вошли не все.
     *
     * @param task       задание агенту
     * @param docSummary перечень «имя (N символов)»
     * @return задание с перечнем либо без изменений
     */
    static String withFullDocumentList(String task, List<String> docSummary) {
        if (docSummary.size() <= MAX_SYSTEM_DOCS) {
            return task;
        }
        return task + "\n\n=== ПОЛНЫЙ ПЕРЕЧЕНЬ ДОКУМЕНТОВ (" + docSummary.size() + ") ===\n- "
                + String.join("\n- ", docSummary);
    }

    /**
     * Добор: пункты плана без записей закрываются одним дополнительным
     * tool-циклом; его тетрадь валидируется и подшивается к основной.
     */
    private List<AgentEvidence.Entry> coverPlanGaps(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                                    String system, List<String> plan,
                                                    List<AgentEvidence.Entry> validated,
                                                    AgentDocumentTools tools) {
        var uncovered = AgentEvidence.uncoveredItems(plan.size(), validated);
        if (uncovered.isEmpty()) {
            return validated;
        }
        agentTrace(sink, tools, "🩹 добор незакрытых пунктов плана: " + uncovered);
        StringBuilder gaps = new StringBuilder("Не закрыты пункты плана:\n");
        for (int i : uncovered) {
            gaps.append(i).append(". ").append(plan.get(i - 1)).append('\n');
        }
        gaps.append("Найди в документах данные ИМЕННО по этим пунктам и верни рабочую "
                + "тетрадь ТОЛЬКО по ним (тот же JSON-формат «записи», номера пунктов сохрани). "
                + "ЦИТАТА — только ДОСЛОВНО скопированный фрагмент документа (не пересказ, "
                + "не переформулировка): прочитай нужное место (read_document) и скопируй. "
                + "Если данных нет — запись со значением 'не указано' и пустой цитатой.");
        try {
            var chat = callToolLoop(system, gaps.toString(), tools);
            var extra = AgentEvidence.parse(chat.text());
            if (!extra.isEmpty()) {
                var merged = new ArrayList<>(validated);
                merged.addAll(AgentEvidence.validate(extra, tools.docsSnapshot()));
                return merged;
            }
        } catch (Exception e) {
            log.warn("[{}] Добор незакрытых пунктов не удался: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
        return validated;
    }

    /** Финал: ответ в формате задания собирается из проверенной тетради. */
    private String composeFinalAnswer(String task, List<AgentEvidence.Entry> validated) {
        return gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content",
                        task + "\n\n=== ПРОВЕРЕННАЯ РАБОЧАЯ ТЕТРАДЬ "
                                + "(поле 'проверка' — вердикт кода, цитаты сверены с документами) ===\n"
                                + AgentEvidence.toJson(validated)
                                + "\n\nСобери финальный ответ строго по заданию из этой тетради. "
                                + "Значения с проверкой '" + AgentEvidence.CONFIRMED + "' и '"
                                + AgentEvidence.CALCULATED
                                + "' используй как факты. Значения с другими вердиктами НЕ выдавай "
                                + "за факты: пиши 'не указано' или явно помечай '(не подтверждено "
                                + "документами)'. Ничего не добавляй сверх тетради.")
        ), node.getModel(), node.getTemperature());
    }

    /** Детали шага для UI: план, статистика инструментов, журнал. */
    private String agentDetails(List<String> plan, AgentDocumentTools tools) {
        StringBuilder sb = new StringBuilder("агент: план из ").append(plan.size())
                .append(" пунктов, ").append(tools.callCount()).append(" обращений к инструментам\n");
        for (int i = 0; i < plan.size(); i++) {
            sb.append(i + 1).append(". ").append(plan.get(i)).append('\n');
        }
        sb.append(StringUtils.abbreviate(String.join("\n", tools.callLog()), 1200));
        return sb.toString();
    }

    /**
     * Задание агенту: намерение пользователя (промпт узла с поддержкой
     * выражений) плюс результаты предыдущих узлов как контекст.
     * <p>
     * Задание ограничено долей бюджета контекста агента ({@link AgentContextBudget#taskChars()}): подстановки выражений
     * делят бюджет за вычетом инструкции (инструкция вокруг выражений сохраняется целиком), блок результатов
     * предыдущих шагов получает остаток (и не больше {@code docCharLimit}); обрезки — в пометки журнала прогона.
     * Вклады узлов, чей выход подставлен через {@code {{output:…}}}, в блок не добавляются: прогон ПЗД v4.23 отправлял
     * выходы s9 и r3 дважды и падал на 422 «context too long».
     */
    private String buildAgentTask() {
        String template = node.getPrompt();
        int budget = contextBudget.taskChars();
        String intent = agentIntent(template, budget);
        Set<String> substituted = ExpressionResolver.hasExpressions(template)
                ? ExpressionResolver.outputSources(template, node.getGraph().getNodeMap()) : Set.of();
        String contextInput = String.join("\n\n", node.getInputExcluding(substituted));
        if (contextInput.isBlank()) {
            return intent;
        }
        int limit = Math.min(getDocCharLimit(), Math.max(0, budget - String.valueOf(intent).length()));
        if (contextInput.length() > limit) {
            noteTruncation("результат предыдущих шагов в задании агента", limit, contextInput.length());
            contextInput = contextInput.substring(0, limit) + "\n[... обрезано ...]";
        }
        return intent + "\n\n=== РЕЗУЛЬТАТЫ ПРЕДЫДУЩИХ ШАГОВ (контекст) ===\n" + contextInput;
    }

    /**
     * Намерение агента: промпт узла с подстановкой выражений в пределах бюджета задания.
     *
     * @param template промпт узла
     * @param budget   бюджет задания, символов
     * @return промпт с подставленными значениями (усечение значений — в пометки)
     */
    private String agentIntent(String template, int budget) {
        if (!ExpressionResolver.hasExpressions(template)) {
            return template;
        }
        var resolved = ExpressionResolver.resolveWithin(template, node.getGraph().getNodeMap(), budget);
        if (resolved.kept() < resolved.total()) {
            noteTruncation("текст подстановок выражений в задании агента", resolved.kept(), resolved.total());
        }
        return resolved.text();
    }

    /**
     * Системный промпт агента: инструменты, план-чеклист, методика, правила
     * качества и формат РАБОЧЕЙ ТЕТРАДИ (значение + дословная цитата +
     * документ) — цитаты затем детерминированно сверяются кодом. Ревизору think-tool и рабочие файлы не передаются
     * ({@link AgentDocumentTools#reviewCallbacks()}) — в промпте их нет.
     */
    private String buildAgentSystemPrompt(List<String> docSummary, boolean kbConfigured,
                                          List<String> plan, List<String> lessons) {
        boolean review = MODE_AGENT_REVIEW.equals(node.getMode());
        StringBuilder sb = new StringBuilder();
        appendToolGuide(sb, kbConfigured, review);
        appendDocumentList(sb, docSummary);
        sb.append("\nПЛАН (чек-лист, закрой КАЖДЫЙ пункт):\n");
        for (int i = 0; i < plan.size(); i++) {
            sb.append(i + 1).append(". ").append(plan.get(i)).append('\n');
        }
        if (!lessons.isEmpty()) {
            sb.append("\nУРОКИ ИЗ ПРОШЛЫХ ПРОГОНОВ (обязательно учитывай):\n");
            for (String lesson : lessons) {
                sb.append("- ").append(lesson).append('\n');
            }
        }
        appendMethodology(sb, review);
        if (review) {
            appendReviewFormat(sb);
        } else {
            appendNotebookFormat(sb);
        }
        return sb.toString();
    }

    /**
     * Перечень инструментов системного промпта агента.
     *
     * @param sb           системный промпт
     * @param kbConfigured база знаний подключена
     * @param review       режим ревизора: без note_thought и write_file
     */
    private static void appendToolGuide(StringBuilder sb, boolean kbConfigured, boolean review) {
        sb.append("Ты — ИИ-агент по анализу документов. ")
                .append("Тебе дано задание пользователя и документы. ")
                .append("Полные тексты документов НЕ приложены — читай их инструментами:\n")
                .append("- search_documents — поиск по всем документам: короткие ключевые ")
                .append("термины из задания, их синонимы и части слов; ")
                .append("числа можно искать как есть — разделители разрядов учитываются;\n")
                .append("- read_document — чтение документа фрагментами (offset, next_offset);\n");
        if (!review) {
            sb.append("- note_thought — запиши короткое рассуждение перед сменой пункта плана;\n")
                    .append("- write_file — сохрани рабочий файл (конспект, промежуточную таблицу) ")
                    .append("для агентов следующих узлов; рабочие файлы не являются источниками ")
                    .append("цитат.\n");
        }
        if (kbConfigured) {
            sb.append("- search_knowledge_base — семантический поиск по базе знаний.\n");
        }
    }

    /**
     * Методика и бюджет обращений системного промпта агента.
     *
     * @param sb     системный промпт
     * @param review режим ревизора: без правил note_thought
     */
    private static void appendMethodology(StringBuilder sb, boolean review) {
        sb.append("\nМЕТОДИКА: иди по плану пункт за пунктом: поиск по коротким ключевым ")
                .append("словам (пробуй синонимы и части слов) → точечное чтение нужных мест. ");
        if (!review) {
            sb.append("note_thought вызывай ТОЛЬКО на настоящей развилке — когда что-то пошло ")
                    .append("не по плану: не нашёл и меняю формулировку (какую и почему); вычисляю ")
                    .append("значение из найденного (приведи расчёт); противоречие между документами ")
                    .append("(какое); сдаюсь и помечаю «не указано» (что перепробовал). В мысли — ")
                    .append("конкретные значения и причина решения, её видит пользователь. Если ")
                    .append("результат ожидаем — мысль НЕ пиши, просто работай дальше. ");
        }
        sb.append("БЮДЖЕТ: обращения к инструментам ограничены (")
                .append(AgentDocumentTools.MAX_TOOL_CALLS)
                .append(") — распределяй по всем пунктам и документам, большие документы НЕ читай ")
                .append("целиком подряд.\n");
    }

    /** Формат финала ревизора: отчёт сверки вместо рабочей тетради. */
    private void appendReviewFormat(StringBuilder sb) {
        sb.append("\nТы — ПРОВЕРЯЮЩИЙ: сверяй данные из задания с документами. ")
                .append("ФИНАЛЬНЫЙ ОТВЕТ — отчёт по заданию обычным текстом (НЕ JSON): по каждому ")
                .append("проверенному пункту вердикт «совпадает» или «РАСХОЖДЕНИЕ: в задании X, ")
                .append("в документе Y», с найденным инструментами значением и именем документа. ")
                .append("Значения бери ТОЛЬКО из результатов инструментов этого разговора, ")
                .append("по памяти не дополняй; не смог проверить — так и напиши.");
    }

    /** Формат рабочей тетради и правила цитирования (часть системного промпта). */
    private void appendNotebookFormat(StringBuilder sb) {
        sb.append("\nФИНАЛЬНЫЙ ОТВЕТ — ТОЛЬКО рабочая тетрадь, JSON строго такого вида:\n")
                .append("{\"записи\": [\n")
                .append("  {\"пункт\": 1, \"название\": \"<пункт плана>\", ")
                .append("\"значение\": \"<извлечённое значение>\", ")
                .append("\"цитата\": \"<ДОСЛОВНАЯ выдержка из документа, подтверждающая значение, ")
                .append("10-200 символов, копируй как в документе>\", ")
                .append("\"документ\": \"<имя документа из списка выше>\"},\n")
                .append("  ...\n]}\n")
                .append("По пункту может быть несколько записей (несколько значений). ")
                .append("Цитаты будут АВТОМАТИЧЕСКИ сверены с текстами документов — цитата, ")
                .append("которой нет в документе дословно, аннулирует значение. Поэтому копируй ")
                .append("цитаты точно из результатов инструментов, не пересказывай. ")
                .append("Если значения нет в документах: \"значение\": \"не указано\", \"цитата\": \"\".\n")
                .append("\nПРАВИЛА: значения бери ТОЛЬКО из результатов инструментов этого разговора, ")
                .append("списки по памяти не дополняй; числа в поле «значение» — без пробелов, дробная ")
                .append("часть через точку (в цитате — как в документе); даты — ДД.ММ.ГГГГ; ")
                .append("производные значения (порог из процента и НМЦ, период из даты и срока) ")
                .append("вычисляй и в цитате давай исходные данные расчёта.");
    }

    /**
     * Режим группировки документов: docList разбивается на группы по ключу
     * из имени файла (первая capture-группа регэкспа из {@code data.value};
     * при пустом значении — {@link #DEFAULT_GROUP_REGEX}, номер договора из пути).
     * Все документы группы попадают в один LLM-вызов (с именами файлов) —
     * это позволяет сверять документы группы между собой (договор ↔ спецификация ↔ акт).
     * Документ без совпадения с регэкспом образует отдельную группу по своему имени.
     */
    private List<String> processDocGroups(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        Pattern pattern = compileGroupPattern();
        Map<String, List<String>> groups = new LinkedHashMap<>();
        for (String docId : docs) {
            var doc = node.getGraph().getDocMap().get(docId);
            String key = extractGroupKey(pattern, doc.getFilename());
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(docId);
        }
        // промпты групп строятся последовательно в основном потоке (детерминизм,
        // RAG-события в sink); LLM-вызовы — параллельно (groupParallelism > 1)
        List<GroupCall> calls = new ArrayList<>();
        for (var entry : groups.entrySet()) {
            String groupKey = entry.getKey();
            String docsBlock = buildGroupDocsBlock(groupKey, entry.getValue());
            var contextInput = String.join("\n\n", node.getInput());
            prompt = buildPrompt(contextInput, docsBlock,
                    getKbChunks(sink, "", docsBlock), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            emitTruncationNotes(sink, calls.size() + 1, groups.size(), " (группа «" + groupKey + "»)");
            calls.add(new GroupCall(groupKey, entry.getValue().size(), prompt));
        }
        assert gigaChatClient != null;
        return groupParallelism <= 1 || calls.size() <= 1
                ? runGroupsSequentially(sink, calls)
                : runGroupsInParallel(sink, calls);
    }

    /**
     * Подготовленный LLM-вызов одной группы.
     */
    private record GroupCall(String groupKey, int docCount, String prompt) {
    }

    private Pattern compileGroupPattern() {
        String regex = node.getValue().isBlank() ? DEFAULT_GROUP_REGEX : node.getValue();
        try {
            return SafeRegex.compile(regex, 0, "регэксп группировки");
        } catch (PatternSyntaxException e) {
            throw new ScenarioException("Некорректный регэксп группировки документов: " + regex, e);
        }
    }

    /**
     * Агент по группам: отдельный агентский конвейер на каждую группу
     * документов (ключ — первая capture-группа регэкспа по имени файла);
     * документы без совпадения — общий контекст, добавляются каждой группе.
     * Групп нет вовсе (ни один документ не совпал) — обычный агентский
     * прогон по всем документам.
     */
    private List<String> processAgentGroups(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                            List<String> docs) {
        List<String> scope = docs.isEmpty()
                ? new ArrayList<>(node.getGraph().getDocMap().keySet()) : docs;
        Pattern pattern = compileGroupPattern();
        Map<String, List<String>> groups = new LinkedHashMap<>();
        List<String> common = new ArrayList<>();
        for (String docId : scope) {
            var doc = node.getGraph().getDocMap().get(docId);
            var m = SafeRegex.matcher(pattern, doc.getFilename());
            if (m.find() && m.groupCount() >= 1 && m.group(1) != null) {
                groups.computeIfAbsent(m.group(1), k -> new ArrayList<>()).add(docId);
            } else {
                common.add(docId);
            }
        }
        if (groups.isEmpty()) {
            return processAgent(sink, scope);
        }
        List<String> results = new ArrayList<>();
        int i = 0;
        for (var entry : groups.entrySet()) {
            // остановка прогона проверяется перед каждой группой, а не только на границе узла
            node.getGraph().checkNotCancelled();
            i++;
            emitProcessingProgressEvent(sink, node, i, groups.size(),
                    "🧩 группа «" + entry.getKey() + "»: " + entry.getValue().size()
                            + " док. + " + common.size() + " общих");
            List<String> groupDocs = new ArrayList<>(entry.getValue());
            groupDocs.addAll(common);
            try {
                results.add("=== Группа " + entry.getKey() + " ===\n"
                        + processAgent(sink, groupDocs).get(0));
                // чекпойнт узла: ГОТОВЫЕ группы переживают сбой следующих —
                // resume отдаст их рабочим файлом, а не начнёт перебор с нуля
                checkpoint = String.join("\n\n", results);
            } catch (Exception e) {
                // processAgent уже положил в checkpoint тетрадь упавшей группы —
                // дополняем её результатами завершённых групп
                String failedNotes = checkpoint != null && !checkpoint.isBlank()
                        && !checkpoint.startsWith("=== Группа")
                        ? "\n\n=== тетрадь группы " + entry.getKey()
                                + " (прервана сбоем) ===\n" + checkpoint
                        : "";
                checkpoint = String.join("\n\n", results) + failedNotes;
                throw e;
            }
        }
        return results;
    }

    private List<String> runGroupsSequentially(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                               List<GroupCall> calls) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < calls.size(); i++) {
            var call = calls.get(i);
            String result = gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", call.prompt())
            ), node.getModel(), node.getTemperature());
            resultList.add("=== Группа " + call.groupKey() + " ===\n" + result);
            emitProcessingProgressEvent(sink, node, i + 1, calls.size(),
                    "Группа " + call.groupKey() + " (" + call.docCount() + " док.)");
        }
        return resultList;
    }

    /**
     * LLM-вызов группы в потоке пула: на время вызова ставится проверка остановки прогона — как в потоке узла,
     * иначе в воркере не действовали политика отказа цензора GigaChat (текст отказа становился результатом группы)
     * и прерывание повторов при остановке прогона.
     *
     * @param call вызов группы
     * @return ответ модели и usage
     */
    private GigaChatClient.ChatResult groupWorkerCall(GroupCall call) {
        GigaChatClient.setRunCancelCheck(node.getGraph()::isCancelRequested);
        try {
            return gigaChatClient.chatCompletionResult(List.of(
                    Map.of("role", "user", "content", call.prompt())
            ), node.getModel(), node.getTemperature());
        } finally {
            GigaChatClient.clearRunCancelCheck();
        }
    }

    /**
     * Параллельные LLM-вызовы групп: пул на {@code groupParallelism} потоков.
     * Учёт токенов: кадр учёта ({@code beginUsageCapture}) привязан к потоку
     * движка, поэтому воркеры возвращают usage вместе с результатом, а в кадр
     * он добавляется здесь, в потоке движка. Порядок результатов — как у групп;
     * события прогресса — по мере завершения. Ошибка любой группы отменяет
     * остальные и роняет узел (как и при последовательном выполнении).
     */
    private List<String> runGroupsInParallel(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             List<GroupCall> calls) {
        var pool = Executors.newFixedThreadPool(
                Math.min(groupParallelism, calls.size()));
        try {
            var completion = new ExecutorCompletionService<int[]>(pool);
            var results = new String[calls.size()];
            var usages = new ConcurrentHashMap<Integer, Map<String, Object>>();
            for (int i = 0; i < calls.size(); i++) {
                final int index = i;
                completion.submit(() -> {
                    var chat = groupWorkerCall(calls.get(index));
                    results[index] = chat.text();
                    if (chat.usage() != null) {
                        usages.put(index, chat.usage());
                    }
                    return new int[]{index};
                });
            }
            for (int done = 1; done <= calls.size(); done++) {
                int index = completion.take().get()[0];
                var call = calls.get(index);
                emitProcessingProgressEvent(sink, node, done, calls.size(),
                        "Группа " + call.groupKey() + " (" + call.docCount() + " док.)");
            }
            // usage воркеров — в кадр учёта потока движка
            usages.values().forEach(GigaChatClient::addCapturedUsage);
            List<String> resultList = new ArrayList<>();
            for (int i = 0; i < calls.size(); i++) {
                resultList.add("=== Группа " + calls.get(i).groupKey() + " ===\n" + results[i]);
            }
            return resultList;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ScenarioException("Обработка групп прервана", e);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            if (cause instanceof RuntimeException runtime) {
                throw runtime;
            }
            throw new ScenarioException("Ошибка обработки группы: " + cause.getMessage(), cause);
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * Собирает блок документов группы, укладываясь в {@code docCharLimit}.
     * <p>
     * Общая обрезка блока срезала бы документы, попавшие в конец (обычно акты —
     * самые важные для проверки). Вместо этого бюджет распределяется жадно:
     * документы обходятся по возрастанию длины, каждому выделяется его доля
     * остатка бюджета — короткие (акты, УПД) входят целиком, а излишек уходит
     * длинным (договор обрезается по остаточному бюджету с маркером обрезки).
     */
    private String buildGroupDocsBlock(String groupKey, List<String> docIds) {
        // запас на заголовки документов и маркеры, чтобы buildPrompt не обрезал блок повторно
        int overhead = 200 + docIds.size() * 150;
        int budget = Math.max(getDocCharLimit() - overhead, 1000);
        Map<String, Integer> caps = new HashMap<>();
        List<String> byLength = new ArrayList<>(docIds);
        byLength.sort(Comparator.comparingInt(
                id -> node.getGraph().getDocMap().get(id).getText().length()));
        int remaining = byLength.size();
        for (String docId : byLength) {
            int share = budget / Math.max(remaining, 1);
            int len = node.getGraph().getDocMap().get(docId).getText().length();
            int use = Math.min(len, share);
            caps.put(docId, use);
            budget -= use;
            remaining--;
        }
        StringBuilder docsBlock = new StringBuilder("Группа документов: " + groupKey);
        for (String docId : docIds) {
            var doc = node.getGraph().getDocMap().get(docId);
            String text = doc.getText();
            int cap = caps.getOrDefault(docId, text.length());
            if (text.length() > cap) {
                noteTruncation("документ «" + doc.getFilename() + "»", cap, text.length());
                text = text.substring(0, cap) + "\n[... документ обрезан по лимиту контекста ...]";
            }
            docsBlock.append("\n\n<<<Документ: ").append(doc.getFilename()).append(">>>\n")
                    .append(text)
                    .append("\n<<<КОНЕЦ ДОКУМЕНТА>>>");
        }
        return docsBlock.toString();
    }

    private String extractGroupKey(Pattern pattern, String filename) {
        var matcher = SafeRegex.matcher(pattern, filename);
        if (matcher.find()) {
            String key = matcher.groupCount() >= 1 ? matcher.group(1) : matcher.group();
            if (key != null && !key.isBlank()) {
                return key;
            }
        }
        return filename;
    }

    private List<String> processSimpleInput(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> resultList = new ArrayList<>();
        var input = String.join("\n\n", node.getInput());
        prompt = buildPrompt(input, "", getKbChunks(sink, input, ""), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
        emitTruncationNotes(sink, 1, 1, "");
        assert gigaChatClient != null;
        resultList.add(gigaChatClient.chatCompletion(List.of(
                Map.of("role", "user", "content", prompt)
        ), node.getModel(), node.getTemperature()));
        var details = node.getInput().stream()
                .map(s -> StringUtils.abbreviate(s, DETAILS_MAX_LENGTH))
                .collect(Collectors.joining("\n\n"));
        emitProcessingProgressEvent(sink,
                node,
                1,
                1,
                details);
        return resultList;
    }

    private List<String> processInputList(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < node.getInput().size(); i++) {
            var input = node.getInput().get(i);
            prompt = buildPrompt(input, "", getKbChunks(sink, input, ""), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            emitTruncationNotes(sink, i + 1, node.getInput().size(), "");
            assert gigaChatClient != null;
            resultList.add(gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", prompt)
            ), node.getModel(), node.getTemperature()));
            emitProcessingProgressEvent(sink,
                    node,
                    i + 1,
                    node.getInput().size(),
                    StringUtils.abbreviate(input, DETAILS_MAX_LENGTH));
        }
        return resultList;
    }

    private List<String> processDocList(FluxSink<ServerSentEvent<Map<String, Object>>> sink, List<String> docs) {
        List<String> resultList = new ArrayList<>();
        for (int i = 0; i < docs.size(); i++) {
            // остановка прогона проверяется перед каждым документом, а не только на границе узла
            node.getGraph().checkNotCancelled();
            var docId = docs.get(i);
            var doc = node.getGraph().getDocMap().get(docId);
            var docText = doc.getText();
            if (docText != null && docText.startsWith(MANUAL_CHECK_MARKER)) {
                // маркерный документ уходит в LLM как текст-заглушка — предупреждение, без пропуска
                emitProcessingProgressEvent(sink, node, i + 1, docs.size(), "⚠ " + docId + " - " + doc.getFilename()
                        + ": маркерный документ «ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА» — в LLM уходит текст-заглушка");
            }
            // Результаты предыдущих узлов включаются в контекст наряду с документами узла
            var contextInput = String.join("\n\n", node.getInput());
            prompt = buildPrompt(contextInput, docText, getKbChunks(sink, "", docText), ObjectUtils.isNotEmpty(node.getKnowledgeBaseId()));
            emitTruncationNotes(sink, i + 1, docs.size(), " («" + doc.getFilename() + "»)");
            assert gigaChatClient != null;
            resultList.add(gigaChatClient.chatCompletion(List.of(
                    Map.of("role", "user", "content", prompt)
            ), node.getModel(), node.getTemperature()));
            emitProcessingProgressEvent(sink,
                    node,
                    i + 1,
                    node.getDocList().size(),
                    docId + " - " + doc.getFilename());
        }
        return resultList;
    }

    /**
     * Пометки об обрезках промпта до docCharLimit (см. {@code noteTruncation}) —
     * отдельными событиями в журнал прогона; возвращаются и одной строкой для details шага.
     *
     * @param sink      поток событий
     * @param iteration номер итерации
     * @param total     всего итераций
     * @param where     уточнение места («(«файл»)», «группы X»)
     */
    private void emitTruncationNotes(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                       int iteration, int total, String where) {
        for (String note : drainTruncationNotes()) {
            emitProcessingProgressEvent(sink, node, iteration, total, note + where);
        }
    }

    /** Узел с контрактом json_массив: при делении промпта по лимиту контекста массивы частей объединяются. */
    @Override
    protected boolean mergeArraysOnSplit() {
        var contract = readOutputContract();
        return contract != null && CONTRACT_JSON_ARRAY.equals(contract.path("тип").asText());
    }

    private List<String> getKbChunks(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                     String input,
                                     String docText) {
        List<String> kbChunks = List.of();
        if (ObjectUtils.isNotEmpty(node.getKnowledgeBaseId())) {
            try {
                kbChunks = ragSearchForNode(input, docText, node.getKnowledgeBaseId());
            } catch (Exception e) {
                log.error("[{}] RAG не удался для узла {} {}", CurrentUserHolder.getCurrentUser(), node.getId(), e.getMessage());
                kbChunks = List.of();
            }
            emitRagSearchEvent(sink, node, kbChunks.size());
        }
        return kbChunks;
    }

    /**
     * Выполняет RAG-поиск для узла по базе знаний.
     * <p>
     * Собирает запрос из предыдущего вывода или промпта узла.
     * Кэширует эмбеддинги в рамках одного выполнения.
     *
     * @param previousOutput предыдущий вывод
     * @param documentText   текст документа
     * @param kbId           идентификатор базы знаний
     * @return список релевантных фрагментов из базы знаний
     */
    private List<String> ragSearchForNode(String previousOutput,
                                          String documentText,
                                          UUID kbId) {
        String query = buildRagQuery(previousOutput, documentText);
        if (query.isEmpty()) {
            return List.of();
        }
        try {
            float[] embedding = embeddingForQuery(query);
            assert embeddingService != null;
            List<String> chunks = embeddingService.hybridSearch("kb", kbId, embedding, query);
            log.info("[{}] RAG: found {} chunks in KB {} for node {}", CurrentUserHolder.getCurrentUser(), chunks.size(), kbId, node.getId());
            return chunks;
        } catch (Exception e) {
            log.error("[{}] RAG search failed for KB {}", CurrentUserHolder.getCurrentUser(), kbId, e);
            return List.of();
        }
    }

    /**
     * Запрос RAG-поиска: предыдущий вывод, иначе промпт узла, иначе текст
     * документа; обрезается до {@code ragQueryMaxLength}.
     */
    private String buildRagQuery(String previousOutput, String documentText) {
        String query = previousOutput;
        if (query.isEmpty()) {
            query = node.getPrompt();
        }
        if (query.isEmpty()) {
            query = documentText;
        }
        if (query.length() > ragQueryMaxLength) {
            query = query.substring(0, ragQueryMaxLength);
        }
        return query;
    }

    /**
     * Эмбеддинг запроса с кэшированием в рамках одного выполнения сценария.
     */
    private float[] embeddingForQuery(String query) {
        String cacheKey = query.length() <= cacheShortQueryLength ? query : String.valueOf(query.hashCode());
        var embeddingCache = node.getGraph().getEmbeddingCache();
        if (embeddingCache != null && embeddingCache.containsKey(cacheKey)) {
            return embeddingCache.get(cacheKey);
        }
        assert gigaChatClient != null;
        float[] embedding = gigaChatClient.getEmbeddings(List.of(query)).get(0);
        if (embeddingCache != null) {
            embeddingCache.put(cacheKey, embedding);
        }
        return embedding;
    }
}
