package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «месяцы_из_дат» узла «Трансформация»: перечень допустимых месяцев
 * периода считается кодом из строки «… — календарные даты» той же группы.
 * <p>
 * Модель для длинных периодов (Приложение 3: 45 месяцев) сокращает перечень
 * многоточием («01.2021, 02.2021, ..., 09.2024»). Для каждой строки, чей
 * критерий оканчивается на «— допустимые месяцы», ищется строка с тем же
 * началом критерия и окончанием «— календарные даты»; из её значения
 * «с ДД.ММ.ГГГГ по ДД.ММ.ГГГГ» строится полный перечень «ММ.ГГГГ» по порядку.
 * Значение всегда перезаписывается (расчёт точен), достоверность — «рассчитано кодом».
 * <pre>
 * {"оп": "месяцы_из_дат", "суффикс_месяцев": "допустимые месяцы", "суффикс_дат": "календарные даты"}
 * </pre>
 */
final class PeriodMonthsOps {

    /** Пометка достоверности рассчитанной строки. */
    static final String CALCULATED = "рассчитано кодом";
    /** Разумный предел длины периода в месяцах: больше — ошибка дат, не перечень. */
    static final int MAX_MONTHS = 600;
    private static final Pattern DATES = Pattern.compile("с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final DateTimeFormatter MONTH = DateTimeFormatter.ofPattern("MM.yyyy");

    private PeriodMonthsOps() {
    }

    /**
     * Перезаписывает строки «… — допустимые месяцы» перечнем месяцев из строк «… — календарные даты».
     *
     * @param op   параметры операции (суффиксы критериев, по умолчанию «допустимые месяцы» и «календарные даты»)
     * @param rows строки критериев (объекты с полями «критерий», «значение»)
     * @return число пересчитанных строк
     */
    static int monthsFromDates(Map<String, Object> op, List<Object> rows) {
        Pattern months = suffixPattern(op, "суффикс_месяцев", "допустимые месяцы");
        Pattern dates = suffixPattern(op, "суффикс_дат", "календарные даты");
        int done = 0;
        for (Object o : rows) {
            if (!(o instanceof Map<?, ?> m)) {
                continue;
            }
            Matcher mm = months.matcher(text(m.get("критерий")));
            if (!mm.find()) {
                continue;
            }
            Map<String, Object> datesRow = findByPrefix(rows, dates, mm.group(1));
            if (datesRow != null && fill(cast(m), datesRow)) {
                done++;
            }
        }
        return done;
    }

    /** Шаблон «<начало критерия> — <суффикс>»: группа 1 — начало критерия. */
    private static Pattern suffixPattern(Map<String, Object> op, String key, String fallback) {
        String suffix = Pattern.quote(String.valueOf(op.getOrDefault(key, fallback)).strip());
        return Pattern.compile("^\\s*(.*?)\\s*[—–-]\\s*" + suffix + "\\s*$", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    }

    private static Map<String, Object> findByPrefix(List<Object> rows, Pattern dates, String prefix) {
        for (Object o : rows) {
            if (o instanceof Map<?, ?> m) {
                Matcher dm = dates.matcher(text(m.get("критерий")));
                if (dm.find() && dm.group(1).strip().equalsIgnoreCase(prefix.strip())) {
                    return cast(m);
                }
            }
        }
        return null;
    }

    /** Заполняет перечень месяцев по датам; {@code false}, если даты не разобрались или период неразумен. */
    private static boolean fill(Map<String, Object> monthsRow, Map<String, Object> datesRow) {
        Matcher dm = DATES.matcher(text(datesRow.get("значение")));
        if (!dm.find()) {
            return false;
        }
        LocalDate from;
        LocalDate to;
        try {
            from = LocalDate.parse(dm.group(1), DATE);
            to = LocalDate.parse(dm.group(2), DATE);
        } catch (DateTimeParseException e) {
            return false;
        }
        YearMonth first = YearMonth.from(from);
        YearMonth last = YearMonth.from(to);
        if (last.isBefore(first) || first.until(last, ChronoUnit.MONTHS) > MAX_MONTHS) {
            return false;
        }
        List<String> list = new ArrayList<>();
        for (YearMonth ym = first; !ym.isAfter(last); ym = ym.plusMonths(1)) {
            list.add(ym.format(MONTH));
        }
        monthsRow.put("значение", String.join(", ", list));
        monthsRow.put("источник", "расчёт кодом по строке «" + text(datesRow.get("критерий")) + "»: первый месяц с "
                + from.getDayOfMonth() + "-го числа, последний по " + to.getDayOfMonth() + "-е число");
        monthsRow.put("достоверность", CALCULATED);
        return true;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> cast(Map<?, ?> m) {
        return (Map<String, Object>) m;
    }

    private static String text(Object value) {
        return value == null ? "" : String.valueOf(value);
    }
}
