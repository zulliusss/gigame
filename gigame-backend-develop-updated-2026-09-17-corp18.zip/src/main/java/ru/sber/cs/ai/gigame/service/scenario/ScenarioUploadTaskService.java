package ru.sber.cs.ai.gigame.service.scenario;

import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.dto.scenario.UploadStatusResponse;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Фоновая обработка загруженных документов сценария (режим {@code ?async=true}
 * эндпоинта загрузки).
 * <p>
 * Синхронная обработка большого комплекта (сотни страниц PDF, OCR сканов)
 * держит HTTP-запрос открытым минутами, и корпоративные шлюзы обрывают его
 * по таймауту. В асинхронном режиме запрос загрузки лишь принимает байты
 * файлов и ставит задачу разбора; клиент опрашивает прогресс короткими
 * запросами {@code GET /api/scenarios/{id}/upload-status} — длинных
 * HTTP-обменов не остаётся вовсе.
 * <p>
 * Задачи и документы изолированы по пользователю (ключ
 * {@link DocsTextCacheService#scenarioKey(UUID, String)}): общий сценарий
 * загружают и запускают разные пользователи. На пару «сценарий + пользователь»
 * допускается одна активная задача; запуск прогона до завершения разбора
 * блокируется через {@link #isProcessing(UUID, String)}.
 * <p>
 * Завершённые задачи (done/failed) живут {@code app.upload.task-ttl-minutes} минут
 * после завершения — чтобы клиент успел забрать предупреждения, — и затем
 * вычищаются при следующем обращении: без этого карта задач с событиями
 * разбора (десятки КБ на загрузку) росла бесконечно.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScenarioUploadTaskService {

    /**
     * Статусы задачи разбора.
     */
    public static final String STATUS_PROCESSING = "processing";
    /**
     * Задача завершена, документы в кэше сценария.
     */
    public static final String STATUS_DONE = "done";
    /**
     * Задача завершилась ошибкой (текст — в поле error статуса).
     */
    public static final String STATUS_FAILED = "failed";
    /**
     * Для сценария нет ни одной задачи разбора.
     */
    public static final String STATUS_NONE = "none";
    /**
     * Размер пула фоновых разборов по умолчанию (для сервиса, созданного без настроек).
     */
    private static final int DEFAULT_PARSE_THREADS = 2;
    /**
     * Срок жизни завершённой задачи по умолчанию, минут.
     */
    private static final int DEFAULT_TASK_TTL_MINUTES = 10;

    private final ScenarioService scenarioService;
    private final DocsTextCacheService docsTextCacheService;

    private final Map<UUID, UploadTask> tasks = new ConcurrentHashMap<>();
    /**
     * Число одновременно разбираемых загрузок (app.upload.parse-threads), остальные ждут
     * в очереди пула. Разбор сканов распознаёт страницы через GigaChat — увеличение
     * упирается в квоту одновременных запросов (ответы 429).
     */
    @Value("${app.upload.parse-threads:2}")
    private int parseThreads = DEFAULT_PARSE_THREADS;
    /**
     * Сколько минут завершённая задача (done/failed) остаётся доступной в статусе.
     */
    @Value("${app.upload.task-ttl-minutes:10}")
    private int taskTtlMinutes = DEFAULT_TASK_TTL_MINUTES;
    /**
     * Пул фоновых разборов: создаётся при первой задаче, когда настройка уже внедрена
     * (в том числе у сервиса, созданного в тестах без Spring).
     */
    private ExecutorService executor;

    /**
     * Состояние одной задачи разбора.
     */
    private static final class UploadTask {
        private final int filesTotal;
        private final List<ServerSentEvent<Map<String, Object>>> events =
                Collections.synchronizedList(new ArrayList<>());
        private volatile String status = STATUS_PROCESSING;
        private volatile int documentsCached;
        private volatile String error;
        /** Момент завершения (System.nanoTime) — для чистки по TTL. */
        private volatile long finishedAtNanos;

        private UploadTask(int filesTotal) {
            this.filesTotal = filesTotal;
        }

        private void finish(String finalStatus) {
            // момент завершения — до смены статуса: параллельный опрос не примет задачу за давно завершённую
            this.finishedAtNanos = System.nanoTime();
            this.status = finalStatus;
        }

        private boolean finished() {
            return !STATUS_PROCESSING.equals(status);
        }
    }

    /**
     * Сводка событий разбора для статуса задачи.
     *
     * @param warnings тексты предупреждений «файл: сообщение» в порядке поступления
     * @param parsed   число разобранных документов (события upload_parsed)
     */
    private record EventSummary(List<String> warnings, int parsed) {
    }

    /**
     * Ставит задачу фонового разбора файлов. Байты файлов уже прочитаны
     * в HTTP-запросе — сама задача не держит соединение.
     * <p>
     * Задача, очистка кэша и защита от повторной загрузки действуют только
     * в пределах пары «сценарий + пользователь».
     *
     * @param scenarioId идентификатор сценария
     * @param userId     загружающий пользователь (null или пусто — аноним)
     * @param files      файлы: имя + содержимое
     * @param append     догрузка к уже закэшированным документам
     * @throws FileException если у этого пользователя по сценарию уже идёт разбор
     */
    public void start(UUID scenarioId, String userId, List<ScenarioService.RawFile> files, boolean append) {
        evictFinishedTasks();
        UUID key = DocsTextCacheService.scenarioKey(scenarioId, userId);
        UploadTask task = new UploadTask(files.size());
        // проверка «разбор уже идёт» и регистрация задачи — одна атомарная операция карты:
        // два одновременных запроса не ставят две задачи на один ключ
        tasks.compute(key, (k, existing) -> {
            if (existing != null && STATUS_PROCESSING.equals(existing.status)) {
                throw new FileException("Предыдущая загрузка документов ещё обрабатывается — "
                        + "дождитесь её завершения (GET upload-status)");
            }
            return task;
        });
        if (!append) {
            docsTextCacheService.clearCache(key);
        }
        // пока идёт разбор партии, уже закэшированные партии не устаревают по TTL
        // (пометки считаются: завершение одной загрузки ключа не снимает защиту другой)
        docsTextCacheService.markUploading(key);
        executor().submit(() -> CurrentUserHolder.withUser(userId, () -> runTask(scenarioId, key, task, files)));
        log.info("[{}] Сценарий {}: поставлена фоновая задача разбора {} файла(ов), append={}, ключ кэша {}",
                userId, scenarioId, files.size(), append, key);
    }

    /**
     * Регистрирует итог синхронной загрузки как завершённую задачу: предупреждения
     * разбора (скан, пустой или нечитаемый файл) при синхронной загрузке иначе
     * терялись — теперь клиент забирает их тем же GET upload-status. Идущую
     * фоновую задачу того же ключа запись не подменяет.
     *
     * @param key             ключ кэша документов сценария пользователя
     * @param filesTotal      число загруженных файлов
     * @param documentsCached документов в кэше после загрузки
     * @param events          события разбора (upload_warning, upload_parsed)
     */
    public void recordSyncUpload(UUID key, int filesTotal, int documentsCached,
                                 List<ServerSentEvent<Map<String, Object>>> events) {
        evictFinishedTasks();
        UploadTask task = new UploadTask(filesTotal);
        if (events != null) {
            task.events.addAll(events);
        }
        task.documentsCached = documentsCached;
        task.finish(STATUS_DONE);
        tasks.compute(key, (k, existing) -> existing != null && !existing.finished() ? existing : task);
    }

    /**
     * Идёт ли у пользователя по сценарию фоновый разбор документов (запуск
     * прогона в это время блокируется — кэш документов ещё не полон).
     * Загрузки других пользователей того же сценария не учитываются.
     *
     * @param scenarioId идентификатор сценария
     * @param userId     запускающий пользователь (null или пусто — аноним)
     * @return {@code true}, если разбор ещё не завершён
     */
    public boolean isProcessing(UUID scenarioId, String userId) {
        UploadTask task = tasks.get(DocsTextCacheService.scenarioKey(scenarioId, userId));
        return task != null && STATUS_PROCESSING.equals(task.status);
    }

    /**
     * Снимок состояния задачи разбора для опроса клиентом. Ответ строго
     * по схеме UploadStatusResponse спецификации: лимиты применяет
     * {@link UploadStatusResponse#of}. Возвращается задача только этого
     * пользователя: чужие загрузки того же сценария не видны.
     *
     * @param scenarioId идентификатор сценария
     * @param userId     пользователь, опрашивающий статус (null или пусто — аноним)
     * @return status (processing/done/failed/none), files, documents (во время
     * processing — разобрано документов текущей партии, после завершения —
     * документов в кэше), warnings (тексты upload_warning), error
     */
    public UploadStatusResponse status(UUID scenarioId, String userId) {
        evictFinishedTasks();
        UUID key = DocsTextCacheService.scenarioKey(scenarioId, userId);
        UploadTask task = tasks.get(key);
        if (task == null) {
            return UploadStatusResponse.of(STATUS_NONE, 0, 0, List.of(), "");
        }
        String taskStatus = task.status;
        boolean processing = STATUS_PROCESSING.equals(taskStatus);
        if (processing) {
            docsTextCacheService.touch(key);
        }
        EventSummary summary = summarize(task);
        int documents = processing ? summary.parsed() : task.documentsCached;
        return UploadStatusResponse.of(taskStatus, task.filesTotal, documents, summary.warnings(), task.error);
    }

    /**
     * Удаляет задачи, завершённые раньше чем {@code app.upload.task-ttl-minutes} минут назад.
     */
    private void evictFinishedTasks() {
        long now = System.nanoTime();
        long ttl = TimeUnit.MINUTES.toNanos(Math.max(0, taskTtlMinutes));
        tasks.entrySet().removeIf(e -> e.getValue().finished() && now - e.getValue().finishedAtNanos > ttl);
    }

    /**
     * Сводка событий разбора задачи: предупреждения (upload_warning) в порядке
     * поступления и число разобранных документов (upload_parsed).
     *
     * @param task задача
     * @return сводка событий
     */
    private static EventSummary summarize(UploadTask task) {
        List<String> warnings = new ArrayList<>();
        int parsed = 0;
        synchronized (task.events) {
            for (ServerSentEvent<Map<String, Object>> event : task.events) {
                Map<String, Object> data = event.data();
                String type = data == null ? "" : String.valueOf(data.get("type"));
                if ("upload_warning".equals(type)) {
                    warnings.add(data.get("file") + ": " + data.get("message"));
                } else if ("upload_parsed".equals(type)) {
                    parsed++;
                }
            }
        }
        return new EventSummary(warnings, parsed);
    }

    /**
     * Тело фоновой задачи: разбор, проверка лимита, догрузка в кэш сценария
     * пользователя. Ключ вычислен в потоке запроса и передан аргументом —
     * поток пула не читает пользователя из ThreadLocal для работы с кэшем.
     *
     * @param scenarioId идентификатор сценария (для логов)
     * @param key        ключ кэша документов сценария пользователя
     * @param task       задача
     * @param files      файлы: имя + содержимое
     * @return {@code null}
     */
    private Void runTask(UUID scenarioId, UUID key, UploadTask task, List<ScenarioService.RawFile> files) {
        try {
            List<DocumentText> documents = dropDuplicates(scenarioService.parseFiles(files, task.events), key, task);
            int cached = docsTextCacheService.getCachedDocumentTexts(key).size();
            int limit = scenarioService.getMaxDocumentsPerRun();
            if (cached + documents.size() > limit) {
                throw new FileException("Слишком много документов с учётом уже загруженных: "
                        + (cached + documents.size()) + ". Максимум на прогон: " + limit);
            }
            docsTextCacheService.appendDocumentTexts(key,
                    documents.stream().map(DocumentText::text).toList(),
                    documents.stream().map(DocumentText::filename).toList(),
                    List.of());
            task.documentsCached = cached + documents.size();
            task.finish(STATUS_DONE);
            log.info("[{}] Сценарий {}: фоновый разбор завершён, документов в кэше {}",
                    CurrentUserHolder.getCurrentUser(), scenarioId, task.documentsCached);
        } catch (Exception e) {
            task.error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            task.finish(STATUS_FAILED);
            log.warn("[{}] Сценарий {}: фоновый разбор документов упал: {}", CurrentUserHolder.getCurrentUser(), scenarioId, task.error);
        } finally {
            docsTextCacheService.unmarkUploading(key);
        }
        return null;
    }

    /**
     * Догрузка (append=true) того же архива или файла давала дубли документов:
     * у агента одноимённые документы схлопывались, у группировки — задваивались.
     * Документ с тем же именем и тем же текстом (SHA-256), что уже в кэше,
     * пропускается с предупреждением upload_warning.
     *
     * @param documents разобранные документы партии
     * @param key       ключ кэша документов сценария пользователя
     * @param task      задача (для событий)
     * @return документы без дублей уже закэшированных
     */
    private List<DocumentText> dropDuplicates(List<DocumentText> documents, UUID key, UploadTask task) {
        var cached = docsTextCacheService.getCachedDocuments(key).orElse(DocsTextCacheService.CachedDocuments.EMPTY);
        if (cached.texts().isEmpty()) {
            return documents;
        }
        Set<String> known = new HashSet<>();
        for (int i = 0; i < cached.texts().size() && i < cached.fileNames().size(); i++) {
            known.add(cached.fileNames().get(i) + "\n" + sha256(cached.texts().get(i)));
        }
        List<DocumentText> fresh = new ArrayList<>();
        for (DocumentText document : documents) {
            if (known.contains(document.filename() + "\n" + sha256(document.text()))) {
                log.info("[{}] Документ «{}» уже загружен ранее — дубль пропущен", CurrentUserHolder.getCurrentUser(), document.filename());
                task.events.add(ServerSentEvent.<Map<String, Object>>builder().data(Map.of("type", "upload_warning",
                        "file", document.filename(), "message", "документ уже загружен ранее (то же имя и содержимое) — дубль пропущен")).build());
            } else {
                fresh.add(document);
            }
        }
        return fresh;
    }

    private static String sha256(String text) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    /**
     * Пул фоновых разборов размером app.upload.parse-threads (не меньше 1),
     * создаваемый при первом обращении.
     *
     * @return пул фоновых разборов
     */
    private synchronized ExecutorService executor() {
        if (executor == null) {
            int threads = Math.max(1, parseThreads);
            executor = Executors.newFixedThreadPool(threads);
            log.info("ScenarioUploadTaskService: потоков фонового разбора {}", threads);
        }
        return executor;
    }

    /**
     * Останавливает пул фоновых задач при завершении приложения.
     */
    @PreDestroy
    public synchronized void shutdown() {
        if (executor != null) {
            executor.shutdownNow();
        }
    }
}
