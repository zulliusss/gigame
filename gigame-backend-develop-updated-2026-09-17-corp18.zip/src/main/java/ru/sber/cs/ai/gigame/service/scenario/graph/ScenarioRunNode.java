package ru.sber.cs.ai.gigame.service.scenario.graph;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.springframework.util.ObjectUtils;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Getter
public class ScenarioRunNode {
    private final NodeDto dto;
    private final List<ScenarioRunNode> parentNodeList;
    private final List<ScenarioRunNode> childNodeList;
    private final List<String> docList;
    /**
     * Вход узла: представление над вкладами родителей. Читается в порядке рёбер
     * графа ({@link #parentNodeList}), а не в порядке завершения родителей;
     * {@code add} без источника кладёт вклад в конец (ручные вклады, тесты).
     */
    private final List<String> input;
    private final List<String> output;
    /** Вклады во вход по id узла-источника; доступ только под монитором этой карты. */
    @Getter(AccessLevel.NONE)
    private final Map<String, List<String>> inputBySource = new LinkedHashMap<>();
    /** Вклады без источника — читаются после вкладов родителей. */
    @Getter(AccessLevel.NONE)
    private final List<String> unsourcedInput = new ArrayList<>();
    /** Результат исполнителя узла — итог прогона берётся с output-узла по нему. */
    @Setter
    private volatile String result;
    @Setter
    private Boolean completed;
    @Setter
    private Boolean skip;
    private ScenarioRunGraph graph;
    private int index;

    public ScenarioRunNode(NodeDto dto) {
        this.dto = dto;
        // Синхронизированные списки: при параллельном выполнении ветвей несколько
        // родителей могут одновременно дописывать вход/документы этого узла
        this.output = Collections.synchronizedList(new ArrayList<>());
        this.input = new OrderedInput();
        parentNodeList = new ArrayList<>();
        childNodeList = new ArrayList<>();
        docList = Collections.synchronizedList(new ArrayList<>());
        completed = false;
        skip = true;
    }

    public static ScenarioRunNode fromDto(int index, NodeDto dto, ScenarioRunGraph graph) {
        if (dto == null) {
            return null;
        }
        var node = new ScenarioRunNode(dto);

        node.graph = graph;
        node.index = index;
        return node;
    }

    public int getTotal() {
        if (graph == null) {
            return 0;
        }
        if (graph.getNodeMap() == null) {
            return 0;
        }
        return graph.getNodeMap().size();
    }

    public String getId() {
        return dto.id();
    }

    public ScenarioNodeType getType() {
        return ObjectUtils.isEmpty(dto.type()) ? ScenarioNodeType.UNKNOWN : ScenarioNodeType.valueOfNodeType(dto.type());
    }

    public String getLabel() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().label())) ? getType().toString() : dto.data().label();
    }

    public String getRules() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().rules())) ? "[]" : dto.data().rules();
    }

    public String getMode() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().mode())) ? "all" : dto.data().mode();
    }

    public String getPrompt() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().prompt())) ? "" : dto.data().prompt();
    }

    public boolean isClassifyStrict() {
        var classifyStrictStr = (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().classifyStrict())) ? "false" : dto.data().classifyStrict();
        return Boolean.parseBoolean(classifyStrictStr);
    }

    public String getClasses() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().classes())) ? "" : dto.data().classes();
    }

    public String getField() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().field())) ? "" : dto.data().field();
    }

    public String getOperator() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().operator())) ? "contains" : dto.data().operator();
    }

    public String getValue() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().value())) ? "" : dto.data().value();
    }

    public UUID getKnowledgeBaseId() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().knowledgeBaseId())) ? null : UUID.fromString(dto.data().knowledgeBaseId());
    }

    /**
     * Модель GigaChat для этого узла (null — модель по умолчанию).
     */
    public String getModel() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().model())) ? null : dto.data().model();
    }

    /**
     * Температура генерации для этого узла (null — значение по умолчанию).
     */
    public Double getTemperature() {
        if (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().temperature())) {
            return null;
        }
        try {
            return Double.parseDouble(dto.data().temperature().replace(",", "."));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Поведение при ошибке узла: stop (по умолчанию) / continue / branch.
     */
    public String getOnError() {
        return (ObjectUtils.isEmpty(dto.data()) || ObjectUtils.isEmpty(dto.data().onError())) ? "stop" : dto.data().onError();
    }

    /**
     * Собирает тексты всех документов, привязанных к данному узлу, в одну строку.
     * <p>
     * Каждый документ отделяется от следующего двумя переносами строки.
     * Если документов нет, возвращает пустую строку.
     *
     * @return объединённый текст всех документов узла
     */
    public String getAllDocTexts() {
        return docList.stream()
                .map(docId -> graph.getDocMap().get(docId))
                .filter(doc -> doc != null && doc.getText() != null)
                .map(ScenarioRunDoc::getText)
                .collect(Collectors.joining("\n\n"));
    }

    /**
     * Добавляет вклад узла-источника во вход. При чтении {@link #getInput()} вклады
     * выстраиваются в порядке рёбер графа (по {@link #parentNodeList}), поэтому
     * порядок завершения параллельных родителей на вход не влияет.
     *
     * @param sourceId id узла-источника ({@code null} — вклад без источника, читается последним)
     * @param text     текст вклада
     */
    public void addInput(String sourceId, String text) {
        synchronized (inputBySource) {
            if (sourceId == null) {
                unsourcedInput.add(text);
            } else {
                inputBySource.computeIfAbsent(sourceId, k -> new ArrayList<>()).add(text);
            }
        }
    }

    /**
     * Добавляет несколько вкладов одного узла-источника (см. {@link #addInput}).
     *
     * @param sourceId id узла-источника
     * @param texts    тексты вкладов
     */
    public void addInputs(String sourceId, Collection<String> texts) {
        for (String text : texts) {
            addInput(sourceId, text);
        }
    }

    /**
     * Вход без вкладов указанных узлов-источников, в порядке рёбер графа (как {@link #getInput()}): агенту не нужен
     * повторно выход узла, уже подставленный в промпт выражением {@code {{output:…}}}. Вклады без источника остаются.
     *
     * @param sourceIds id узлов-источников, чьи вклады исключаются
     * @return снимок входа без этих вкладов
     */
    public List<String> getInputExcluding(Collection<String> sourceIds) {
        return assembleInput(sourceIds);
    }

    private List<String> assembleInput() {
        return assembleInput(Set.of());
    }

    /**
     * Вход в порядке рёбер графа: вклады родителей по {@link #parentNodeList},
     * затем прочих источников (в порядке появления), затем вклады без источника.
     *
     * @param excluded id источников, чьи вклады не включаются
     * @return снимок входа
     */
    private List<String> assembleInput(Collection<String> excluded) {
        synchronized (inputBySource) {
            List<String> assembled = new ArrayList<>();
            Set<String> seen = new HashSet<>(excluded);
            for (var parent : parentNodeList) {
                if (seen.add(parent.getId())) {
                    assembled.addAll(inputBySource.getOrDefault(parent.getId(), List.of()));
                }
            }
            for (var entry : inputBySource.entrySet()) {
                if (seen.add(entry.getKey())) {
                    assembled.addAll(entry.getValue());
                }
            }
            assembled.addAll(unsourcedInput);
            return assembled;
        }
    }

    /**
     * Список-представление входа: чтение — снимок в порядке рёбер, {@code add} —
     * вклад без источника, {@code clear} — сброс всех вкладов. Потокобезопасен
     * (как прежний synchronizedList): все операции под одним монитором.
     */
    private final class OrderedInput extends AbstractList<String> {
        @Override
        public String get(int position) {
            return assembleInput().get(position);
        }

        @Override
        public int size() {
            synchronized (inputBySource) {
                int size = unsourcedInput.size();
                for (var contributions : inputBySource.values()) {
                    size += contributions.size();
                }
                return size;
            }
        }

        @Override
        public Iterator<String> iterator() {
            return assembleInput().iterator();
        }

        @Override
        public boolean add(String text) {
            addInput(null, text);
            return true;
        }

        @Override
        public void clear() {
            synchronized (inputBySource) {
                inputBySource.clear();
                unsourcedInput.clear();
            }
        }
    }
}