package ru.sber.cs.ai.gigame.service.scenario;

import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.EmbeddingService;
import ru.sber.cs.ai.gigame.service.GigaChatClient;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorOutputNode;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitNodeErrorEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitNodeStatusEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitProcessingProgressEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitRunNoticeEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitRunQueuedEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitStatusEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitStepCompleteEvent;
import static ru.sber.cs.ai.gigame.service.scenario.ScenarioEventEmission.emitStepPausedEvent;

/**
 * Ядро движка выполнения сценариев.
 * <p>
 * Обходит граф узлов в топологическом порядке, выполняет каждый узел
 * и генерирует SSE-события, которые потребляет React-frontend в режиме реального времени.
 * <p>
 * Поддерживаемые типы узлов:
 * <ul>
 *   <li>input — входной узел с исходным текстом документов</li>
 *   <li>output — выходной узел, собирающий результаты</li>
 *   <li>loop — цикл по документам с классификацией или анализом</li>
 *   <li>switch — условный переход на основе правил</li>
 *   <li>if_node — узел ветвления по условию</li>
 *   <li>processing node — общий узел обработки с опциональным RAG</li>
 * </ul>
 * <p>
 * Особенности:
 * <ul>
 *   <li>Потоковое выполнение через {@link Flux}</li>
 *   <li>Режим пошагового выполнения для отладки</li>
 *   <li>RAG-поиск по базам знаний</li>
 *   <li>Проверка графа на циклы перед выполнением</li>
 * </ul>
 *
 * @see ScenarioRun
 * @see ScenarioRunStep
 * @see GigaChatClient
 * @see EmbeddingService
 */
@Service
@Slf4j
public class ScenarioEngine {

    private final ScenarioRunService runService;
    private final ScenarioRunStepService stepService;
    private final ScenarioExecutorFactory executorFactory;
    private final DocsTextCacheService docsTextCacheService;
    /**
     * Пул прогонов: число одновременно выполняемых прогонов (app.scenario.run-threads),
     * остальные ждут в очереди.
     */
    private final ThreadPoolExecutor executor;
    /**
     * Таймаут паузы пошагового режима (30 минут) — предотвращает зависание
     * потока при отвале клиента.
     */
    private static final long PAUSE_TIMEOUT_MINUTES = 30;
    /**
     * Размер пула прогонов по умолчанию (для движка, созданного без настроек).
     */
    private static final int DEFAULT_RUN_THREADS = 2;
    /** Ожидание завершения прогонов при остановке приложения по умолчанию, секунд. */
    private static final long DEFAULT_SHUTDOWN_WAIT_SECONDS = 30;
    /**
     * Причина остановки прогонов при graceful-остановке сервиса: текст ошибки узла и шага,
     * прогон получает статус FAILED и возобновляется командой resume («продолжить с места сбоя»).
     */
    public static final String RESTART_REASON =
            "Прогон прерван перезапуском сервиса — используйте «продолжить с места сбоя»";

    // Состояние пошагового режима отладки в памяти (по run_id)
    private final ConcurrentHashMap<String, CompletableFuture<Void>> stepEvents = new ConcurrentHashMap<>();
    private final Set<String> stepModeEnabled = ConcurrentHashMap.newKeySet();
    private final Set<String> stepModeDisabled = ConcurrentHashMap.newKeySet();
    private final ConcurrentHashMap<String, Long> runTimestamps = new ConcurrentHashMap<>();
    /**
     * Активные графы прогонов — для явной остановки по запросу пользователя.
     */
    private final ConcurrentHashMap<String, ScenarioRunGraph> activeGraphs = new ConcurrentHashMap<>();
    /**
     * Прогоны, принятые к выполнению и ещё не стартовавшие в пуле: причина
     * остановки, запрошенной пользователем (или остановкой сервиса), пока прогон
     * ждал в очереди; {@code null} — остановка не запрошена.
     */
    private final ConcurrentHashMap<String, AtomicReference<String>> queuedRuns = new ConcurrentHashMap<>();
    /**
     * Задачи прогонов в пуле — для прерывания потока при остановке ({@code cancel(true)}):
     * узел, занятый регулярным выражением или ожиданием, завершается сразу, а не по окончании операции.
     */
    private final ConcurrentHashMap<String, Future<?>> runFutures = new ConcurrentHashMap<>();

    private final ScenarioRepository scenarioRepository;
    /**
     * Доп. возможности output-узла: нарастающий итог и реестр в базе знаний.
     */
    private final ScenarioOutputSupportService outputSupportService;

    /**
     * Параллельное выполнение независимых ветвей графа.
     * Отключается конфигурацией; пошаговый режим всегда выполняется последовательно.
     */
    @Value("${app.scenario.parallel-enabled:true}")
    private boolean parallelEnabled;
    @Value("${app.scenario.parallel-threads:4}")
    private int parallelThreads;
    /**
     * Сколько секунд при остановке приложения ждать завершения прогонов, которым запрошена остановка
     * «прерван перезапуском» ({@code app.scenario.shutdown-wait-seconds}); по истечении пул прерывается.
     */
    @Value("${app.scenario.shutdown-wait-seconds:30}")
    private long shutdownWaitSeconds = DEFAULT_SHUTDOWN_WAIT_SECONDS;

    /**
     * Глубина вложенности под-сценариев в текущем потоке выполнения.
     */
    private static final ThreadLocal<Integer> SUB_DEPTH = ThreadLocal.withInitial(() -> 0);
    /** Предел вложенности под-сценариев; на эту же глубину граф проверяет {@link ScenarioOperationsValidator}. */
    static final int MAX_SUB_DEPTH = 2;
    /** Предел числа узлов графа: граф на десятки тысяч узлов иначе занимал память и поток прогона. */
    static final int MAX_GRAPH_NODES = 1000;

    /**
     * Начало результата узла, завершившегося ошибкой при on_error=continue/branch
     * («[ОШИБКА УЗЛА «Метка»: текст]»). По нему возобновление узнаёт шаги,
     * выполненные на тексте ошибки родителя.
     */
    public static final String NODE_ERROR_PREFIX = "[ОШИБКА УЗЛА «";
    /** Метка узла из маркера ошибки «[ОШИБКА УЗЛА «Метка»: текст]». */
    private static final Pattern NODE_ERROR_LABEL = Pattern.compile(Pattern.quote(NODE_ERROR_PREFIX) + "([^»]*)»");

    /**
     * Наибольший номер метки DOC_i, принимаемый при возобновлении. Метки берутся из
     * текста шага входного узла, куда документы попадают дословно: «&lt;&lt;&lt;DOC_2000000000&gt;&gt;&gt;»
     * из текста документа раздул бы список имён в saveInputDocNames до OutOfMemoryError.
     * Предел с запасом выше лимитов загрузки (max-documents-per-run, 500 по умолчанию).
     */
    static final int MAX_DOC_LABEL_INDEX = 100_000;

    public ScenarioEngine(ScenarioRunService runService,
                          ScenarioRunStepService stepService,
                          ScenarioExecutorFactory executorFactory,
                          DocsTextCacheService docsTextCacheService,
                          ScenarioRepository scenarioRepository,
                          ScenarioOutputSupportService outputSupportService) {
        this(runService, stepService, executorFactory, docsTextCacheService, scenarioRepository,
                outputSupportService, DEFAULT_RUN_THREADS);
    }

    /**
     * Движок с настраиваемым пулом прогонов. Увеличение числа потоков упирается
     * в квоту одновременных запросов GigaChat (ответы 429).
     *
     * @param runService           сервис прогонов
     * @param stepService          сервис шагов прогона
     * @param executorFactory      фабрика исполнителей узлов
     * @param docsTextCacheService кэш загруженных документов
     * @param scenarioRepository   репозиторий сценариев
     * @param outputSupportService доп. возможности output-узла
     * @param runThreads           число одновременно выполняемых прогонов (не меньше 1)
     */
    @Autowired
    public ScenarioEngine(ScenarioRunService runService,
                          ScenarioRunStepService stepService,
                          ScenarioExecutorFactory executorFactory,
                          DocsTextCacheService docsTextCacheService,
                          ScenarioRepository scenarioRepository,
                          ScenarioOutputSupportService outputSupportService,
                          @Value("${app.scenario.run-threads:6}") int runThreads) {
        this.runService = runService;
        this.stepService = stepService;
        this.executorFactory = executorFactory;
        this.docsTextCacheService = docsTextCacheService;
        this.scenarioRepository = scenarioRepository;
        this.outputSupportService = outputSupportService;
        int threads = Math.max(1, runThreads);
        this.executor = new ThreadPoolExecutor(threads, threads, 0L, TimeUnit.MILLISECONDS,
                new LinkedBlockingQueue<>());
        log.info("ScenarioEngine: потоков прогонов {}", threads);
    }

    /**
     * Блокировка с таймаутом 30 минут до вызова /continue или отключения step-mode.
     * <p>
     * Пауза дольше 30 минут прерывается — прогон продолжается последовательно.
     * Это предотвращает зависание потока при отвале клиента.
     */
    private static void pauseFutureGet(CompletableFuture<Void> pauseFuture, String runId) {
        log.info("[{}] pauseFutureGet, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        try {
            pauseFuture.get(PAUSE_TIMEOUT_MINUTES, TimeUnit.MINUTES);
        } catch (InterruptedException | ExecutionException e) {
            log.warn("Пауза шага прервана для запуска {}", runId);
            Thread.currentThread().interrupt();
        } catch (TimeoutException e) {
            log.warn("Пауза шага таймаут {} минут для запуска {}, продолжаем",
                    PAUSE_TIMEOUT_MINUTES, runId);
            // Таймаут — не прерываем, просто продолжаем
        }
    }

    private static Set<String> getNodeIds(GraphDataDto graphData) {
        log.info("[{}] getNodeIds, nodes={}",
                CurrentUserHolder.getCurrentUser(), graphData == null ? 0 : graphData.nodes().size());
        if (graphData == null) {
            return Set.of();
        }
        Set<String> nodeIds = new HashSet<>();
        for (var node : graphData.nodes()) {
            String id = node.id();
            if (id == null || id.isEmpty()) {
                throw new ScenarioException("Ошибка валидации графа: у узла отсутствует идентификатор");
            }
            nodeIds.add(id);
        }

        // Валидация ссылок рёбер
        for (var edge : graphData.edges()) {
            String source = edge.source();
            String target = edge.target();
            if (!nodeIds.contains(source)) {
                throw new ScenarioException("Ошибка валидации графа: источник ребра '" + source + "' ссылается на несуществующий узел");
            }
            if (!nodeIds.contains(target)) {
                throw new ScenarioException("Ошибка валидации графа: цель ребра '" + target + "' ссылается на несуществующий узел");
            }
        }
        return nodeIds;
    }

    // -------------------------------------------------------------------------
    // Main execution
    // -------------------------------------------------------------------------

    /**
     * Начало остановки приложения ({@link ContextClosedEvent} публикуется до graceful-фазы веб-сервера
     * и до уничтожения бинов): активным и ожидающим в очереди прогонам запрашивается остановка
     * с причиной {@link #RESTART_REASON} — узлы завершаются на границе, прогон получает FAILED в БД
     * и событие STATUS клиенту, пока WebSocket-сессии ещё живы.
     */
    @EventListener(ContextClosedEvent.class)
    public void onContextClosed() {
        cancelRunsForRestart();
    }

    /**
     * Освобождает ресурсы при завершении работы приложения: прогонам (если это ещё не сделано
     * по {@link ContextClosedEvent}) запрашивается остановка «прерван перезапуском», пул ждёт их
     * завершения не дольше {@code app.scenario.shutdown-wait-seconds}, затем прерывается —
     * не завершившиеся к этому моменту прогоны остаются RUNNING до {@code failOrphanedRunningRuns} следующего старта.
     */
    @PreDestroy
    void shutdown() {
        cancelRunsForRestart();
        executor.shutdown();
        try {
            var terminated = executor.awaitTermination(Math.max(1, shutdownWaitSeconds), TimeUnit.SECONDS);
            if (!terminated) {
                log.warn("[shutdown] Прогоны не завершились за {} с — пул прерывается, не завершённые: {}",
                        shutdownWaitSeconds, activeGraphs.keySet());
                executor.shutdownNow();
            }
            log.info("[shutdown] Завершено ожидание окончания потока result={}", terminated);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** Запрашивает остановку всех активных и ожидающих прогонов с причиной {@link #RESTART_REASON}. */
    private void cancelRunsForRestart() {
        Set<String> runIds = new LinkedHashSet<>(queuedRuns.keySet());
        runIds.addAll(activeGraphs.keySet());
        if (runIds.isEmpty()) {
            return;
        }
        log.warn("[shutdown] Остановка сервиса: прерываются прогоны ({}): {}", runIds.size(), runIds);
        runIds.forEach(runId -> requestCancel(runId, RESTART_REASON));
    }

    /**
     * Удаляет устаревшее состояние пошагового режима для запусков старше 10 минут.
     * Выполняется по расписанию каждые 5 минут.
     */
    @Scheduled(fixedRateString = "${scenario.engine.evict-rate-ms:300000}")
    void evictStaleRuns() {
        long cutoff = System.currentTimeMillis() - 10 * 60 * 1000;
        // Snapshot keys to avoid ConcurrentModification when cleanupRun removes from runTimestamps
        Set<String> staleRunIds = new HashSet<>();
        for (var entry : runTimestamps.entrySet()) {
            // прогон, ждущий в очереди пула, не устаревает: отметка обновится при его старте
            if (entry.getValue() < cutoff && !queuedRuns.containsKey(entry.getKey())) {
                staleRunIds.add(entry.getKey());
            }
        }
        for (String runId : staleRunIds) {
            log.info("Evicting stale run state: {}", runId);
            cleanupRun(runId);
        }
        // Also clean step mode sets that may have been orphaned (enableStepMode called but
        // doExecute never reached — e.g., due to pre-execution failure or user cancel before runTimestamps was set)
        for (String runId : Set.copyOf(stepModeEnabled)) {
            if (!runTimestamps.containsKey(runId)) {
                log.info("Evicting orphaned stepMode entry: {}", runId);
                stepModeEnabled.remove(runId);
                stepModeDisabled.remove(runId);
                evictStepEvents(runId);
            }
        }
    }

    /**
     * Периодически очищает старые stepEvents, которые не были завершены (timeout).
     * Выполняется каждую минуту.
     */
    @Scheduled(fixedRateString = "${scenario.engine.evict-step-events-rate-ms:60000}")
    void evictExpiredStepEvents() {
        // 10 минут
        long timeout = System.currentTimeMillis() - 10 * 60 * 1000;
        stepEvents.entrySet().removeIf(entry -> {
            Long timestamp = runTimestamps.get(entry.getKey());
            // Evict if expired OR if orphaned (runId not in runTimestamps at all)
            if (timestamp == null || timestamp < timeout) {
                log.info("Evicting expired/orphaned step event for run: {}", entry.getKey());
                entry.getValue().complete(null);
                return true;
            }
            return false;
        });
    }

    private void evictStepEvents(String runId) {
        log.info("[{}] evictStepEvents, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        CompletableFuture<Void> future = stepEvents.get(runId);
        if (future != null) {
            future.complete(null);
            stepEvents.remove(runId);
        }
    }

    /**
     * Включает режим пошагового выполнения для указанного запуска.
     * Выполнение останавливается после каждого узла до вызова {@link #continueStep}.
     *
     * @param runId UUID запуска сценария
     */
    public void enableStepMode(String runId) {
        log.info("[{}] enableStepMode, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        stepModeEnabled.add(runId);
    }

    /**
     * Отключает режим пошагового выполнения для указанного запуска.
     * Если выполнение на паузе, продолжает выполнение.
     *
     * @param runId UUID запуска сценария
     */
    public void disableStepMode(String runId) {
        log.info("[{}] disableStepMode, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        stepModeDisabled.add(runId);
        CompletableFuture<Void> future = stepEvents.get(runId);
        if (future != null) {
            future.complete(null);
        }
    }

    // -------------------------------------------------------------------------
    // Main execution
    // -------------------------------------------------------------------------

    /**
     * Продолжает выполнение с паузы для указанного запуска.
     * Используется после включения пошагового режима.
     *
     * @param runId UUID запуска сценария
     */
    public void continueStep(String runId) {
        log.info("[{}] continueStep, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        CompletableFuture<Void> future = stepEvents.get(runId);
        if (future != null) {
            future.complete(null);
        }
    }

    /**
     * Очищает внутреннее состояние для указанного запуска.
     * Удаляет события паузы, временные метки и кэш документов.
     * Пауза пошагового режима завершается: поток прогона не ждёт её таймаута.
     *
     * @param runId UUID запуска сценария
     */
    public Void cleanupRun(String runId) {
        log.info("cleanupRun, runId={}", runId);
        CompletableFuture<Void> pause = stepEvents.remove(runId);
        if (pause != null) {
            pause.complete(null);
        }
        stepModeEnabled.remove(runId);
        stepModeDisabled.remove(runId);
        runTimestamps.remove(runId);
        // кэш документов живёт по ключу «сценарий + пользователь», а не по id прогона: прежний
        // clearCache(runId) ничего не удалял. Комплект намеренно НЕ чистится по окончании прогона —
        // пользователь перезапускает сценарий на тех же документах; устаревшие записи снимает TTL кэша
        return null;
    }

    /**
     * Явная остановка прогона пользователем: узлы проверяют флаг на своих
     * границах, инструменты агентского узла — на каждом вызове. Обрыв
     * соединения намеренно НЕ останавливает прогон (нестабильная корп. сеть,
     * прогон должен переживать разрывы) — остановка только этим методом.
     * Возможная пауза пошагового режима снимается, чтобы поток выполнения
     * дошёл до проверки флага.
     * <p>
     * Прогон, ещё ждущий в очереди пула, помечается остановленным и при старте
     * сразу завершается (FAILED), не выполняя узлов.
     *
     * @param runId UUID запуска сценария
     * @return {@code true}, если прогон был активен (или в очереди) и остановка запрошена
     */
    public boolean requestCancel(String runId) {
        return requestCancel(runId, ScenarioRunGraph.CANCELLED_BY_USER);
    }

    /**
     * Остановка прогона с причиной — текстом ошибки узла и шага ({@link ScenarioRunGraph#CANCELLED_BY_USER}
     * или {@link #RESTART_REASON}).
     *
     * @param runId  UUID запуска сценария
     * @param reason причина остановки
     * @return {@code true}, если прогон был активен (или в очереди) и остановка запрошена
     */
    public boolean requestCancel(String runId, String reason) {
        log.info("[{}] requestCancel, runId={}, reason={}",
                CurrentUserHolder.getCurrentUser(), runId, reason);
        // сначала флаг очереди, затем граф: старт прогона делает наоборот (граф, затем флаг) —
        // остановка, пришедшая в момент старта, не теряется
        var queued = queuedRuns.get(runId);
        if (queued != null) {
            queued.compareAndSet(null, reason);
        }
        var graph = activeGraphs.get(runId);
        if (graph == null) {
            return queued != null;
        }
        graph.requestCancel(reason);
        continueStep(runId);
        // поток прогона прерывается: узел, занятый регулярным выражением или ожиданием,
        // завершается сразу (ScenarioException «Прогон остановлен пользователем» → FAILED)
        var future = runFutures.get(runId);
        if (future != null) {
            future.cancel(true);
        }
        return true;
    }

    /**
     * Выполняет сценарий и возвращает поток SSE-событий.
     * <p>
     * Выполнение происходит в фоновом потоке, чтобы не блокировать Netty.
     * Возвращаемый Flux генерирует события для пошагового отображения
     * прогресса выполнения на frontend.
     *
     * @param run       сущность запуска сценария
     * @param graphData данные графа (узлы и рёбра)
     * @return поток SSE-событий {@link ServerSentEvent}
     */
    public Flux<ServerSentEvent<Map<String, Object>>> executeScenario(
            ScenarioRun run,
            GraphDataDto graphData) {
        return executeScenario(run, graphData, null);
    }

    /**
     * Запуск сценария с известным запускающим пользователем — его личные
     * общие уроки памяти агента применяются к прогону.
     *
     * @param run       сущность запуска сценария
     * @param graphData данные графа
     * @param userId    запускающий пользователь (null — аноним)
     * @return поток событий
     */
    public Flux<ServerSentEvent<Map<String, Object>>> executeScenario(
            ScenarioRun run,
            GraphDataDto graphData,
            String userId) {

        log.info("[{}] executeScenario, runId={}, scenarioId={}",
                userId, run.getId(), run.getScenarioId());
        // документы фиксируются при приёме команды, а не при старте в пуле
        var docs = snapshotDocuments(run, userId);
        return Flux.create(sink -> {
            // Register cancel handler first so it's always present
            sink.onCancel(() -> CurrentUserHolder.withUser(userId, () -> cleanupRun(run.getId().toString())));
            acceptRun(sink, run, userId);
            // задача регистрируется до постановки в пул: остановка прогона прерывает её поток
            var task = new FutureTask<Void>(() -> {
                try {
                    CurrentUserHolder.withUser(userId, () -> doExecute(sink, run, graphData, docs));
                } catch (Throwable e) {
                    // Error (StackOverflowError формулы, OutOfMemoryError) тоже завершает прогон
                    // статусом FAILED, а не оставляет его running навсегда
                    log.error("[{}] Scenario execution failed unexpectedly", CurrentUserHolder.getCurrentUser(), e);
                    finishFailedRun(sink, run);
                } finally {
                    cleanupRun(run.getId().toString());
                    activeGraphs.remove(run.getId().toString());
                    queuedRuns.remove(run.getId().toString());
                    runFutures.remove(run.getId().toString());
                    SUB_DEPTH.remove();
                }
            }, null);
            runFutures.put(run.getId().toString(), task);
            executor.execute(task);
        });
    }

    /**
     * Завершает прогон, упавший вне узла: статус FAILED в БД и клиенту, поток событий закрыт.
     * Прерывание потока (cancel(true) при остановке) снимается, чтобы запись в БД прошла.
     *
     * @param sink поток событий прогона
     * @param run  прогон
     */
    private void finishFailedRun(FluxSink<ServerSentEvent<Map<String, Object>>> sink, ScenarioRun run) {
        Thread.interrupted();
        safeSetRunFailed(run);
        emitStatusEvent(sink, run.getId(), ScenarioStatus.FAILED, null);
        sink.complete();
    }

    /**
     * Снимок документов прогона в момент приёма команды: тексты и имена файлов,
     * загруженные запускающим пользователем, одной согласованной операцией чтения
     * кэша. Загрузка новых файлов после «Запустить» и вытеснение кэша по TTL, пока
     * прогон ждёт в очереди пула, документы принятого прогона не меняют.
     * Нет документов в кэше — пустой снимок (прежнее поведение).
     *
     * @param run    принимаемый прогон
     * @param userId запускающий пользователь (null — аноним)
     * @return снимок документов
     */
    private DocsTextCacheService.CachedDocuments snapshotDocuments(ScenarioRun run, String userId) {
        var docsKey = DocsTextCacheService.scenarioKey(run.getScenarioId(), userId);
        var docs = docsTextCacheService.getCachedDocuments(docsKey)
                .orElse(DocsTextCacheService.CachedDocuments.EMPTY);
        log.info("[{}] Снимок документов прогона {} при приёме команды: ключ кэша {}, документов {}",
                userId, run.getId(), docsKey, docs.texts().size());
        return docs;
    }

    /**
     * Регистрирует принятый прогон до постановки в пул: отметка времени (состояние
     * пошагового режима не вычищается, пока прогон ждёт), флаг остановки прогона
     * в очереди и события приёма: STATUS с run_id (клиент получает id прогона сразу,
     * а не после старта) и, если все потоки пула заняты, запись журнала о положении
     * в очереди.
     *
     * @param sink   поток событий прогона
     * @param run    принятый прогон
     * @param userId запускающий пользователь (для журнала)
     */
    private void acceptRun(FluxSink<ServerSentEvent<Map<String, Object>>> sink, ScenarioRun run, String userId) {
        var runId = run.getId().toString();
        runTimestamps.put(runId, System.currentTimeMillis());
        queuedRuns.put(runId, new AtomicReference<>());
        int ahead = executor.getQueue().size();
        int busy = executor.getActiveCount();
        int threads = executor.getMaximumPoolSize();
        String queueNotice = ahead == 0 && busy < threads
                ? null
                : "перед вами " + ahead + " прогон(ов), выполняется " + busy + " из " + threads;
        log.info("[{}] Прогон {} принят, очередь: {}", userId, runId, queueNotice == null ? "нет" : queueNotice);
        emitRunQueuedEvent(sink, run.getId(), ahead, queueNotice);
    }

    /**
     * Снимает прогон с учёта очереди при старте в пуле и завершает его как
     * остановленный пользователем, если остановка пришла, пока прогон ждал
     * (тот же итог, что у остановки идущего прогона: исключение → FAILED).
     * Вызывается после регистрации графа в activeGraphs: дальнейшая остановка
     * идёт через флаг графа.
     *
     * @param runId UUID прогона
     */
    private void failIfCancelledInQueue(String runId) {
        var queued = queuedRuns.remove(runId);
        if (queued != null && queued.get() != null) {
            log.info("[{}] Прогон {} остановлен до старта: {}", CurrentUserHolder.getCurrentUser(), runId, queued.get());
            throw new ScenarioException(queued.get());
        }
    }

    /**
     * Помечает прогон статусом FAILED, не давая ошибке сохранения
     * прервать обработку исходного сбоя выполнения.
     *
     * @param run сущность запуска сценария
     */
    private void safeSetRunFailed(ScenarioRun run) {
        log.info("[{}] safeSetRunFailed, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        try {
            runService.setScenarioRunStatusFailed(run);
        } catch (Exception persistError) {
            log.warn("[{}] Не удалось сохранить статус FAILED: {}", CurrentUserHolder.getCurrentUser(), persistError.getMessage());
        }
    }

    /**
     * Выполняет сценарий в потоке.
     * <p>
     * Основной метод выполнения сценария. Осуществляет:
     * <ul>
     *   <li>Валидацию графа перед выполнением</li>
     *   <li>Топологическую сортировку узлов</li>
     *   <li>Обход узлов и их выполнение в зависимости от типа</li>
     *   <li>Генерацию SSE-событий для frontend</li>
     *   <li>Обработку ошибок и обновление статуса запуска</li>
     * </ul>
     *
     * @param sink      поток SSE-событий
     * @param run       сущность запуска сценария
     * @param graphData данные графа сценария
     * @param docs      снимок документов, снятый при приёме команды
     */
    private Void doExecute(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                           ScenarioRun run,
                           GraphDataDto graphData,
                           DocsTextCacheService.CachedDocuments docs) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] doExecute, runId={}", userId, run.getId());
        var runId = run.getId().toString();
        runTimestamps.put(runId, System.currentTimeMillis());
        graphData = stripNoteNodes(graphData);
        validateGraph(graphData);
        // Построение графа
        var graph = new ScenarioRunGraph(graphData);
        graph.setRunId(run.getId());
        graph.setScenarioId(run.getScenarioId());
        graph.setRunnerUserId(userId);
        activeGraphs.put(runId, graph);
        // остановка, запрошенная, пока прогон ждал в очереди (проверка после регистрации графа)
        failIfCancelledInQueue(runId);
        // документы, загруженные именно запускающим пользователем (общий сценарий запускают разные пользователи)
        var docsKey = DocsTextCacheService.scenarioKey(run.getScenarioId(), userId);
        // снимок при приёме команды: загрузки после «Запустить» и TTL кэша в очереди его не меняют
        var docTextList = docs.texts();
        var filenameList = docs.fileNames();
        graph.addDocs(docTextList, filenameList);
        // ключ и число документов — сверка с ключом загрузки, если X-UserId в WebSocket и HTTP разошёлся
        log.info("[{}] Документы прогона {}: ключ кэша {}, документов {}", userId, runId, docsKey, docTextList.size());
        // Обновление статуса запуска на выполняется
        run = runService.setScenarioRunStatusRunning(run);
        emitStatusEvent(sink, run.getId(), ScenarioStatus.RUNNING, null);
        var finalResult = executeGraph(sink, run, graph, userId);
        finishRun(sink, run, graph, finalResult);
        cleanupRun(runId);
        sink.complete();
        return null;
    }

    /**
     * Завершает прогон по итогам узлов. Если хотя бы один узел упал и прогон
     * продолжился (on_error=continue/branch) либо итог содержит текст ошибки узла,
     * прогон получает статус FAILED: итог сохраняется как есть (он неполный), в журнал
     * уходит перечень упавших узлов, STATUS FAILED несёт итог. Иначе — COMPLETED.
     *
     * @param sink        поток SSE-событий
     * @param run         сущность запуска сценария
     * @param graph       граф прогона
     * @param finalResult итог прогона
     */
    private void finishRun(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                           ScenarioRun run,
                           ScenarioRunGraph graph,
                           String finalResult) {
        Set<String> failed = new LinkedHashSet<>(graph.getFailedNodeLabels());
        failed.addAll(errorNodeLabels(finalResult));
        if (failed.isEmpty()) {
            runService.setScenarioRunStatusCompleted(run, finalResult);
            emitStatusEvent(sink, run.getId(), ScenarioStatus.COMPLETED, finalResult);
            return;
        }
        log.warn("[{}] Прогон {} завершён с ошибками узлов: {}", CurrentUserHolder.getCurrentUser(), run.getId(), failed);
        runService.setScenarioRunStatusFailed(run, finalResult);
        emitRunNoticeEvent(sink, run.getId(), "Прогон завершён с ошибками узлов: "
                + String.join(", ", failed) + " — результат неполный");
        emitStatusEvent(sink, run.getId(), ScenarioStatus.FAILED, finalResult);
    }

    /**
     * Метки узлов из маркеров «[ОШИБКА УЗЛА «Метка»: …]» в тексте (в порядке появления, без повторов).
     *
     * @param text текст (итог прогона, вход узла)
     * @return метки упавших узлов; пустой список, если маркеров нет
     */
    public static List<String> errorNodeLabels(String text) {
        if (text == null || !text.contains(NODE_ERROR_PREFIX)) {
            return List.of();
        }
        Set<String> labels = new LinkedHashSet<>();
        var matcher = NODE_ERROR_LABEL.matcher(text);
        while (matcher.find()) {
            labels.add(matcher.group(1));
        }
        return new ArrayList<>(labels);
    }

    /**
     * Итог прогона — результат первого по порядку узлов графа ({@code graphData.nodes()})
     * выполненного output-узла; одинаково для волнового и последовательного режимов.
     * Если ни один output-узел не выполнен (ветки не активированы), выход другого узла
     * итог не подменяет: предупреждение в журнал, итог — пустая строка.
     *
     * @param sink  поток SSE-событий
     * @param run   сущность запуска сценария
     * @param graph граф прогона
     * @return итог прогона
     */
    private String finalResultOf(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                 ScenarioRun run,
                                 ScenarioRunGraph graph) {
        for (var node : graph.getNodeMap().values()) {
            if (node.getType() == ScenarioNodeType.OUTPUT_NODE && Boolean.TRUE.equals(node.getCompleted())) {
                return Objects.toString(node.getResult(), "");
            }
        }
        log.warn("[{}] Прогон {}: ни один узел «Выход» не выполнен — итог пуст", CurrentUserHolder.getCurrentUser(), run.getId());
        emitRunNoticeEvent(sink, run.getId(), "⚠ Ни один узел «Выход» не выполнен — итог прогона пуст");
        return "";
    }

    /**
     * Выполняет граф: параллельными волнами (независимые ветви — конкурентно)
     * либо последовательной рекурсией (пошаговый режим или параллелизм отключён).
     */
    private String executeGraph(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                ScenarioRunGraph graph,
                                String userId) {
        CurrentUserHolder.setCurrentUser(userId);
        log.info("[{}] executeGraph, runId={}", CurrentUserHolder.getCurrentUser(), run.getId());
        boolean stepMode = stepModeEnabled.contains(run.getId().toString());
        if (!parallelEnabled || stepMode) {
            executeNode(sink, run, graph.getStartNode());
            return finalResultOf(sink, run, graph);
        }
        return executeWaves(sink, run, graph);
    }

    /**
     * Тело выполнения одного узла: шаг в БД, события, исполнитель, пауза пошагового
     * режима. При ошибке фиксирует шаг/событие; on_error узла определяет дальнейшее:
     * stop (по умолчанию) — исключение, прогон завершается со статусом FAILED;
     * continue — ошибка становится результатом узла, обычные ветки продолжаются;
     * branch — активируются только ветки с меткой «ошибка».
     */
    private String runNodeBody(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                               ScenarioRun run,
                               ScenarioRunNode node) {
        var runId = run.getId().toString();
        log.info("[{}] runNodeBody, runId={}, node='{}' (id={}, type={})",
                CurrentUserHolder.getCurrentUser(), runId,
                node.getLabel(), node.getId(), node.getType());
        if (node.getGraph().isCancelRequested()) {
            throw new ScenarioException(node.getGraph().getCancelReason());
        }
        var step = stepService.setScenarioStepStatusRunning(run.getId(), node.getId(), node.getType());
        emitNodeStatusEvent(sink, node, ScenarioStatus.RUNNING);
        GigaChatClient.beginUsageCapture();
        // остановка прогона прерывает и ретраи LLM-вызовов текущего узла, и поиск regex
        GigaChatClient.setRunCancelCheck(node.getGraph()::isCancelRequested);
        SafeRegex.setCancelCheck(node.getGraph()::isCancelRequested);
        // паузы повторов GigaChat (лимит, недоступность) видны в журнале прогона — шаг ждёт, а не падает
        GigaChatClient.setRunWaitNotice(notice -> emitProcessingProgressEvent(sink, node, 0, 0, runNoticeDetail(notice)));
        AbstractScenarioExecutor executorNode = null;
        try {
            executorNode = executorFactory.createExecutor(node);
            if (executorNode instanceof ScenarioExecutorOutputNode outputNode) {
                // контекст прогона включает rules-возможности output-узла
                // («накапливать», «в_базу_знаний»)
                outputNode.setRunContext(outputSupportService, run);
            }
            String output = executorNode.execute(sink);
            node.setResult(output);
            var prompt = executorNode.getPrompt();
            // в шаг идёт сводка документов (метки + SHA-256), полный текст комплекта — только в шаге входного узла
            var nodeDocs = ScenarioRunStepService.documentsSummary(node.getDocList(), node.getAllDocTexts());
            var input = String.join("\n\n", node.getInput());
            Integer tokensUsed = GigaChatClient.endUsageCapture();
            step = stepService.setScenarioStepStatusCompleted(step, input, nodeDocs, output, prompt, tokensUsed,
                    inputDocNames(node));
            emitNodeStatusEvent(sink, node, ScenarioStatus.COMPLETED);
            node.setCompleted(true);
            // исполнители активируют всех детей — ветки «ошибка» при успехе возвращаются в спячку
            setErrorBranchSkip(node);
            // Отправка полных данных шага для живой отладки
            emitStepCompleteEvent(sink, node, step);
            pauseIfStepMode(sink, node, runId);
            return output;
        } catch (Throwable e) {
            GigaChatClient.endUsageCapture();
            // прерывание потока (cancel(true) при остановке прогона) снимается: шаг и статус
            // сохраняются в БД без помех; Error (StackOverflowError формулы) — ошибка узла, а не смерть потока
            Thread.interrupted();
            return handleNodeError(sink, node, step, asException(e), executorNode);
        } finally {
            GigaChatClient.clearRunCancelCheck();
            GigaChatClient.clearRunWaitNotice();
            SafeRegex.clearCancelCheck();
        }
    }

    /**
     * Текст уведомления GigaChat в журнале прогона: паузы и ожидание — с «⏸», предупреждения, уже начинающиеся
     * с «⚠» (отказ модели по ограничению темы), — как есть.
     *
     * @param notice текст уведомления клиента GigaChat
     * @return строка detail события прогресса
     */
    static String runNoticeDetail(String notice) {
        return notice.startsWith("⚠") ? notice : "⏸ " + notice;
    }

    private static Exception asException(Throwable t) {
        return t instanceof Exception e ? e : new ScenarioException("Внутренняя ошибка узла: " + t, t);
    }

    /**
     * Сохраняет чекпойнт упавшего узла в шаг: наблюдения агентского цикла
     * не теряются при обрыве сети, возобновление отдаст их агенту.
     */
    private void saveNodeCheckpoint(ScenarioRunStep step, AbstractScenarioExecutor executorNode) {
        log.info("[{}] saveNodeCheckpoint, nodeId={}",
                CurrentUserHolder.getCurrentUser(),
                step == null ? null : step.getNodeId());
        try {
            String checkpoint = executorNode == null ? null : executorNode.getCheckpoint();
            if (checkpoint != null && !checkpoint.isBlank()) {
                stepService.appendOutputData(step, "checkpoint",
                        StringUtils.abbreviate(checkpoint, 30000));
            }
        } catch (Exception e) {
            log.warn("[{}] Чекпойнт узла не сохранён: {}", CurrentUserHolder.getCurrentUser(), e.getMessage());
        }
    }

    /**
     * Пауза выполнения после узла, если включён пошаговый режим.
     *
     * @param sink  поток SSE-событий
     * @param node  завершившийся узел
     * @param runId UUID запуска сценария
     */
    private void pauseIfStepMode(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                 ScenarioRunNode node,
                                 String runId) {
        if (stepModeEnabled.contains(runId) && !stepModeDisabled.contains(runId)) {
            log.info("[{}] pauseIfStepMode, runId={}, node='{}' (id={})",
                    node.getGraph().getRunnerUserId(), runId,
                    node.getLabel(), node.getId());
            CompletableFuture<Void> pauseFuture = new CompletableFuture<>();
            stepEvents.put(runId, pauseFuture);
            emitStepPausedEvent(sink, node, node.getTotal());
            pauseFutureGet(pauseFuture, runId);
        }
    }

    /**
     * Обрабатывает ошибку узла: фиксирует шаг/событие, а on_error узла определяет
     * дальнейшее: stop (по умолчанию) — исключение, прогон завершается со статусом
     * FAILED; continue — ошибка становится результатом узла, обычные ветки
     * продолжаются; branch — активируются только ветки с меткой «ошибка».
     *
     * @param sink поток SSE-событий
     * @param node узел, завершившийся ошибкой
     * @param step шаг узла в БД
     * @param e    возникшая ошибка
     * @return результат узла-ошибки (для on_error=continue/branch)
     */
    private String handleNodeError(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                   ScenarioRunNode node,
                                   ScenarioRunStep step,
                                   Exception e,
                                   AbstractScenarioExecutor executorNode) {
        log.info("[{}] handleNodeError, node='{}' (id={})",
                CurrentUserHolder.getCurrentUser(), node.getLabel(), node.getId());
        log.error("[{}] Ошибка узла {} {}", CurrentUserHolder.getCurrentUser(), node.getId(), e.getMessage());
        stepService.setScenarioStepStatusFailed(step, e.getMessage());
        // чекпойнт дописывается ПОСЛЕ failed-статуса (тот перетирает output_data)
        saveNodeCheckpoint(step, executorNode);
        emitNodeErrorEvent(sink, node, e.getMessage(), node.getTotal());
        String onError = node.getOnError();
        boolean isControl = node.getType()
                == ScenarioNodeType.CONTROL_NODE;
        if (isControl || "stop".equals(onError)) {
            // узел «Контроль» всегда останавливает сценарий — в этом его смысл
            throw new ScenarioException("Узел «" + node.getLabel() + "» завершился ошибкой: "
                    + e.getMessage(), e);
        }
        String errOutput = NODE_ERROR_PREFIX + node.getLabel() + "»: " + e.getMessage() + "]";
        node.getOutput().add(errOutput);
        node.setResult(errOutput);
        node.setCompleted(true);
        // прогон с упавшим узлом завершится статусом FAILED с неполным итогом (см. finishRun)
        node.getGraph().addFailedNode(node.getLabel());
        boolean branchMode = "branch".equals(onError);
        String contribution = "=== РЕЗУЛЬТАТ ОТ \"" + node.getLabel() + "\" (ОШИБКА) ===\n" + errOutput;
        for (var child : node.getChildNodeList()) {
            boolean errorChild = isErrorEdge(node, child);
            if (branchMode == errorChild) {
                // branch: только ветки «ошибка»; continue: только обычные ветки
                child.setSkip(false);
                child.addInput(node.getId(), contribution);
            } else {
                child.setSkip(true);
            }
        }
        log.warn("[{}] Узел {} продолжен после ошибки (on_error={})", CurrentUserHolder.getCurrentUser(), node.getId(), onError);
        return errOutput;
    }

    /**
     * Пропуск/включение дочерних узлов, соединённых ребром с меткой «ошибка».
     */
    private void setErrorBranchSkip(ScenarioRunNode node) {
        for (var child : node.getChildNodeList()) {
            if (isErrorEdge(node, child)) {
                log.info("[{}] setErrorBranchSkip, node='{}' (id={}) child='{}' (id={})",
                        node.getGraph().getRunnerUserId(),
                        node.getLabel(), node.getId(), child.getLabel(), child.getId());
                child.setSkip(true);
            }
        }
    }

    private boolean isErrorEdge(ScenarioRunNode from, ScenarioRunNode to) {
        var edgeData = from.getGraph().getEdgeMap()
                .get(Pair.of(from.getId(), to.getId()));
        if (edgeData == null || edgeData.label() == null) {
            return false;
        }
        String label = edgeData.label().trim().toLowerCase();
        log.info("[{}] isErrorEdge, from='{}' (id={}), to='{}' (id={})",
                from.getGraph().getRunnerUserId(),
                from.getLabel(), from.getId(), to.getLabel(), to.getId());
        return "ошибка".equals(label) || "error".equals(label);
    }

    private String executeNode(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                               ScenarioRun run,
                               ScenarioRunNode node) {
        var runId = run.getId().toString();
        log.info("[{}] executeNode, runId={}, node='{}' (id={})",
                CurrentUserHolder.getCurrentUser(), runId,
                node.getLabel(), node.getId());
        var output = runNodeBody(sink, run, node);
        for (var nextNode : node.getChildNodeList()) {
            if (isNotReadyForTraversal(nextNode, runId)) {
                continue;
            }
            if (Boolean.FALSE.equals(nextNode.getSkip())) {
                output = executeNode(sink, run, nextNode);
            } else {
                log.info("[{}] Узел пропущен {} (runId={})", CurrentUserHolder.getCurrentUser(), nextNode.getId(), runId);
            }
        }
        return output;
    }

    /**
     * Дочерний узел не готов к обходу: уже выполнен через другого родителя
     * (ромбовидная топология) либо ещё не все родители завершены.
     *
     * @param nextNode дочерний узел
     * @param runId    UUID запуска сценария
     * @return {@code true}, если узел нужно пропустить при обходе
     */
    private boolean isNotReadyForTraversal(ScenarioRunNode nextNode, String runId) {
        log.info("[{}] isNotReadyForTraversal, node='{}' (id={}), runId={}",
                CurrentUserHolder.getCurrentUser(),
                nextNode.getLabel(), nextNode.getId(), runId);
        if (Boolean.TRUE.equals(nextNode.getCompleted())) {
            return true;
        }
        if (!isAllParentCompleted(nextNode)) {
            log.info("[{}] Ожидание завершения всех родительских узлов для узла {} (runId={})", CurrentUserHolder.getCurrentUser(), nextNode.getId(), runId);
            return true;
        }
        return false;
    }

    /**
     * Волновое параллельное выполнение: на каждом цикле запускаются все узлы,
     * у которых завершены (или пропущены) родители; независимые ветви исполняются
     * конкурентно. Узлы планируются в топологическом порядке графа, поэтому очередь
     * пула одинакова от прогона к прогону; вход узла с несколькими родителями
     * собирается в порядке рёбер (см. {@link ScenarioRunNode#addInput}). При ошибке
     * любого узла (on_error=stop) оставшиеся не запускаются.
     *
     * @return итог прогона (см. {@link #finalResultOf})
     */
    private String executeWaves(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                ScenarioRunGraph graph) {
        log.info("[{}] executeWaves, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        var nodes = graph.nodesInTopologicalOrder();
        ExecutorService pool = Executors.newFixedThreadPool(Math.max(1, parallelThreads));
        var ecs = new ExecutorCompletionService<Object[]>(pool);
        Set<ScenarioRunNode> scheduled = new HashSet<>();
        // Узлы, фактически пропущенные в этом прогоне. Поле skip здесь непригодно:
        // до активации родителем skip=true у ВСЕХ узлов (семантика активации ветвей),
        // и «родитель со skip=true» ещё не означает «родитель отработал».
        Set<ScenarioRunNode> skippedNodes = new HashSet<>();
        int active = 0;
        try {
            while (true) {
                active += scheduleReadyNodes(sink, run, nodes, ecs, scheduled, skippedNodes);
                if (active == 0) {
                    break;
                }
                takeCompletedOrAwaitOthers(ecs, active);
                active--;
            }
            return finalResultOf(sink, run, graph);
        } finally {
            pool.shutdownNow();
        }
    }

    /**
     * Планирует на выполнение все узлы, готовые к запуску: родители завершены
     * либо пропущены. Узлы, не активированные ни одной веткой, помечаются
     * пропущенными (их дети каскадно пропускаются через skippedNodes).
     *
     * @param sink         поток SSE-событий
     * @param run          сущность запуска сценария
     * @param nodes        все узлы графа
     * @param ecs          сервис завершения задач пула
     * @param scheduled    уже запланированные узлы (пополняется)
     * @param skippedNodes фактически пропущенные узлы (пополняется)
     * @return количество узлов, отправленных на выполнение
     */
    private int scheduleReadyNodes(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                   ScenarioRun run,
                                   Collection<ScenarioRunNode> nodes,
                                   ExecutorCompletionService<Object[]> ecs,
                                   Set<ScenarioRunNode> scheduled,
                                   Set<ScenarioRunNode> skippedNodes) {
        log.info("[{}] scheduleReadyNodes, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        int started = 0;
        for (var n : nodes) {
            if (scheduleNodeIfReady(sink, run, n, ecs, scheduled, skippedNodes)) {
                started++;
            }
        }
        return started;
    }

    /**
     * Планирует один узел, если он готов к запуску: родители завершены либо
     * пропущены. Узел, не активированный ни одной веткой, помечается пропущенным.
     *
     * @param sink         поток SSE-событий
     * @param run          сущность запуска сценария
     * @param n            проверяемый узел
     * @param ecs          сервис завершения задач пула
     * @param scheduled    уже запланированные узлы (пополняется)
     * @param skippedNodes фактически пропущенные узлы (пополняется)
     * @return {@code true}, если узел отправлен на выполнение
     */
    private boolean scheduleNodeIfReady(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                        ScenarioRun run,
                                        ScenarioRunNode n,
                                        ExecutorCompletionService<Object[]> ecs,
                                        Set<ScenarioRunNode> scheduled,
                                        Set<ScenarioRunNode> skippedNodes) {
        log.info("[{}] scheduleNodeIfReady, node='{}' (id={}), runId={}",
                CurrentUserHolder.getCurrentUser(),
                n.getLabel(), n.getId(), run.getId());
        if (scheduled.contains(n)) {
            return false;
        }
        if (Boolean.TRUE.equals(n.getCompleted())) {
            // восстановлен из предыдущего прогона (resume)
            scheduled.add(n);
            return false;
        }
        var parents = n.getParentNodeList();
        boolean isStart = parents == null || parents.isEmpty();
        boolean parentsDone = isStart || parents.stream().allMatch(
                p -> Boolean.TRUE.equals(p.getCompleted()) || skippedNodes.contains(p));
        if (!parentsDone) {
            return false;
        }
        var userId = CurrentUserHolder.getCurrentUser();
        if (!isStart && Boolean.TRUE.equals(n.getSkip())) {
            scheduled.add(n);
            skippedNodes.add(n);
            log.info("[{}] Узел пропущен {} (runId={})", userId, n.getId(), run.getId());
            return false;
        }
        scheduled.add(n);
        ecs.submit(() -> CurrentUserHolder.withUser(userId, () -> new Object[]{n, runNodeBody(sink, run, n)}));
        return true;
    }

    /**
     * Очередной завершённый узел; если он упал — сначала дожидается узлов, уже выполняющихся параллельно,
     * и только затем пробрасывает ошибку. Раньше пул сразу прерывался, и соседний узел, ждавший ответа
     * GigaChat, завершался ложной ошибкой «Не удалось выполнить запрос к GigaChat», а его результат терялся.
     *
     * @param ecs    сервис завершения задач пула
     * @param active число выполняющихся узлов, включая ожидаемый
     * @return массив из двух элементов: узел и его результат
     */
    private Object[] takeCompletedOrAwaitOthers(ExecutorCompletionService<Object[]> ecs, int active) {
        try {
            return takeCompletedNode(ecs);
        } catch (RuntimeException e) {
            awaitRunningNodes(ecs, active - 1);
            throw e;
        }
    }

    /**
     * Дожидается завершения узлов, уже запущенных параллельно (их ошибки только журналируются).
     *
     * @param ecs   сервис завершения задач пула
     * @param count сколько узлов ещё выполняется
     */
    private void awaitRunningNodes(ExecutorCompletionService<Object[]> ecs, int count) {
        for (int i = 0; i < count; i++) {
            try {
                ecs.take().get();
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return;
            } catch (ExecutionException ee) {
                log.warn("[{}] Параллельный узел завершился ошибкой после остановки прогона: {}",
                        CurrentUserHolder.getCurrentUser(), String.valueOf(ee.getCause()));
            }
        }
    }

    /**
     * Ожидает завершения очередного узла в пуле и возвращает пару
     * {узел, результат}. Прерывание и ошибки выполнения преобразуются
     * в {@link ScenarioException} (либо пробрасывается исходное RuntimeException).
     *
     * @param ecs сервис завершения задач пула
     * @return массив из двух элементов: узел и его результат
     */
    private Object[] takeCompletedNode(ExecutorCompletionService<Object[]> ecs) {
        log.info("[{}] takeCompletedNode",
                CurrentUserHolder.getCurrentUser());
        try {
            return ecs.take().get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ScenarioException("Выполнение сценария прервано");
        } catch (ExecutionException e) {
            throw e.getCause() instanceof RuntimeException re
                    ? re : new ScenarioException(String.valueOf(e.getCause()));
        }
    }

    /**
     * Выполняет под-сценарий внутри текущего (узел «Под-сценарий»).
     * <p>
     * Документами под-сценария становятся документы родительского узла, а при их
     * отсутствии — вход узла единым документом. Шаги под-сценария в БД не пишутся
     * и события узлов не эмитятся (id узлов под-сценария конфликтовали бы с холстом
     * родителя) — результатом является выход output-узла под-сценария.
     *
     * @param subScenarioIdRaw id вызываемого сценария
     * @param parentNode       узел «Под-сценарий» родительского графа
     * @param sink             поток SSE (для прогресса циклов внутри)
     * @return результат под-сценария
     */
    public String executeSubScenarioInline(String subScenarioIdRaw,
                                           ScenarioRunNode parentNode,
                                           FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        log.info("[{}] executeSubScenarioInline, subScenarioId='{}', parentNode='{}'",
                CurrentUserHolder.getCurrentUser(), subScenarioIdRaw, parentNode.getLabel());
        int depth = SUB_DEPTH.get();
        if (depth >= MAX_SUB_DEPTH) {
            throw new ScenarioException("Превышена глубина вложенности под-сценариев (максимум "
                    + MAX_SUB_DEPTH + ")");
        }
        UUID subId;
        try {
            subId = UUID.fromString(subScenarioIdRaw.trim());
        } catch (IllegalArgumentException e) {
            throw new ScenarioException("Узел «Под-сценарий»: некорректный идентификатор сценария: "
                    + subScenarioIdRaw);
        }
        var sub = scenarioRepository.findById(subId)
                .orElseThrow(() -> new ScenarioException("Узел «Под-сценарий»: сценарий не найден: " + subId));
        GraphDataDto graphData = GraphDataMapper.toDto(sub.getGraphData());
        graphData = stripNoteNodes(graphData);
        validateGraph(graphData);
        var graph = new ScenarioRunGraph(graphData);
        List<String> texts = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (String docId : parentNode.getDocList()) {
            var doc = parentNode.getGraph().getDocMap().get(docId);
            texts.add(doc.getText());
            names.add(doc.getFilename());
        }
        if (texts.isEmpty()) {
            String inputAll = String.join("\n\n", parentNode.getInput());
            if (inputAll.isBlank()) {
                throw new ScenarioException("Узел «Под-сценарий»: нет ни документов, ни входа — "
                        + "под-сценарию нечего обрабатывать");
            }
            texts.add(inputAll);
            names.add("вход_узла.txt");
        }
        graph.addDocs(texts, names);
        SUB_DEPTH.set(depth + 1);
        try {
            executeSubGraph(sink, graph.getStartNode());
            return subGraphResult(graph);
        } finally {
            SUB_DEPTH.set(depth);
            if (depth == 0) {
                SUB_DEPTH.remove();
            }
        }
    }

    private String executeSubGraph(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                   ScenarioRunNode node) {
        log.info("[{}] executeSubGraph, node='{}' (id={}, type={})",
                CurrentUserHolder.getCurrentUser(),
                node.getLabel(), node.getId(), node.getType());
        String output;
        var executorNode = executorFactory.createExecutor(node);
        output = executorNode.execute(sink);
        node.setResult(output);
        node.setCompleted(true);
        for (var nextNode : node.getChildNodeList()) {
            if (Boolean.TRUE.equals(nextNode.getCompleted()) || !isAllParentCompleted(nextNode)) {
                continue;
            }
            if (Boolean.FALSE.equals(nextNode.getSkip())) {
                output = executeSubGraph(sink, nextNode);
            }
        }
        return output;
    }

    /**
     * Результат под-сценария — выход его первого по порядку узлов выполненного
     * output-узла. Если output-узел не выполнился (ветки под-графа не активированы),
     * это ошибка узла «Под-сценарий», а не пустой «успех».
     *
     * @param graph граф под-сценария после выполнения
     * @return результат output-узла под-сценария
     */
    private static String subGraphResult(ScenarioRunGraph graph) {
        for (var node : graph.getNodeMap().values()) {
            if (node.getType() == ScenarioNodeType.OUTPUT_NODE && Boolean.TRUE.equals(node.getCompleted())) {
                return Objects.toString(node.getResult(), "");
            }
        }
        throw new ScenarioException("Узел «Под-сценарий»: выходной узел под-сценария не выполнен — "
                + "ни одна ветка не дошла до узла «Выход»");
    }

    /**
     * Возобновляет упавший прогон в фоне и возвращает поток SSE-событий
     * (обёртка над {@link #resumeExecution} по образцу executeScenario).
     *
     * @param run       НОВЫЙ прогон
     * @param graphData граф сценария
     * @param oldSteps  шаги исходного прогона
     * @return поток SSE-событий
     */
    public Flux<ServerSentEvent<Map<String, Object>>> resumeScenario(ScenarioRun run,
                                                                     GraphDataDto graphData,
                                                                     List<ScenarioRunStep> oldSteps) {
        return resumeScenario(run, graphData, oldSteps, null);
    }

    /**
     * Возобновление с известным запускающим пользователем (его личные общие
     * уроки памяти агента применяются к прогону).
     *
     * @param run       новый прогон
     * @param graphData граф
     * @param oldSteps  шаги исходного прогона
     * @param userId    запускающий (null — аноним)
     * @return поток событий
     */
    public Flux<ServerSentEvent<Map<String, Object>>> resumeScenario(ScenarioRun run,
                                                                     GraphDataDto graphData,
                                                                     List<ScenarioRunStep> oldSteps,
                                                                     String userId) {
        log.info("[{}] resumeScenario, runId={}, scenarioId={}",
                userId, run.getId(), run.getScenarioId());
        return Flux.create(sink -> {
            sink.onCancel(() -> CurrentUserHolder.withUser(userId, () -> cleanupRun(run.getId().toString())));
            acceptRun(sink, run, userId);
            var task = new FutureTask<Void>(() -> {
                try {
                    // пользователь потока — как в executeScenario: узлы (в т.ч. в пуле волн)
                    // берут его из CurrentUserHolder, иначе возобновление шло от «anonymous»
                    CurrentUserHolder.withUser(userId, () -> {
                        resumeExecution(sink, run, graphData, oldSteps, userId);
                        return null;
                    });
                } catch (Throwable e) {
                    log.error("[{}] Scenario resume failed", CurrentUserHolder.getCurrentUser(), e);
                    finishFailedRun(sink, run);
                } finally {
                    cleanupRun(run.getId().toString());
                    activeGraphs.remove(run.getId().toString());
                    queuedRuns.remove(run.getId().toString());
                    runFutures.remove(run.getId().toString());
                    SUB_DEPTH.remove();
                }
            }, null);
            runFutures.put(run.getId().toString(), task);
            executor.execute(task);
        });
    }

    /**
     * Возобновляет упавший прогон: выходы завершённых LLM-узлов (processing, loop,
     * subscenario) восстанавливаются из шагов старого прогона, дешёвые узлы (input,
     * switch, if, calc, transform, output) выполняются заново, оставшиеся — как обычно.
     * Документы восстанавливаются из шага входного узла, классы документов —
     * из выхода классифицирующего цикла.
     *
     * @param sink      поток SSE-событий
     * @param run       НОВЫЙ прогон (создан сервисом)
     * @param graphData граф сценария
     * @param oldSteps  шаги исходного прогона
     */
    public void resumeExecution(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                GraphDataDto graphData,
                                List<ScenarioRunStep> oldSteps) {
        resumeExecution(sink, run, graphData, oldSteps, null);
    }

    /**
     * Возобновление прогона с известным запускающим пользователем.
     *
     * @param sink         поток событий
     * @param run          новый прогон
     * @param graphData    граф
     * @param oldSteps     шаги исходного прогона
     * @param runnerUserId запускающий пользователь (null — аноним)
     */
    public void resumeExecution(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                GraphDataDto graphData,
                                List<ScenarioRunStep> oldSteps,
                                String runnerUserId) {
        log.info("[{}] resumeExecution, runId={}, scenarioId={}",
                runnerUserId, run.getId(), run.getScenarioId());
        var runId = run.getId().toString();
        runTimestamps.put(runId, System.currentTimeMillis());
        graphData = stripNoteNodes(graphData);
        validateGraph(graphData);
        var graph = new ScenarioRunGraph(graphData);
        graph.setRunId(run.getId());
        graph.setRunnerUserId(runnerUserId);
        graph.setScenarioId(run.getScenarioId());
        activeGraphs.put(runId, graph);
        // остановка, запрошенная, пока возобновление ждало в очереди пула
        failIfCancelledInQueue(runId);
        restoreDocsFromSteps(graph, oldSteps);
        run = runService.setScenarioRunStatusRunning(run);
        emitStatusEvent(sink, run.getId(), ScenarioStatus.RUNNING, null);
        restoreCompletedLlmNodes(sink, run, graph, oldSteps);
        restoreAgentCheckpoints(graph, oldSteps);
        var finalResult = executeWaves(sink, run, graph);
        finishRun(sink, run, graph, finalResult);
        cleanupRun(runId);
        sink.complete();
    }

    /**
     * Чекпойнты упавших агентских узлов из шагов исходного прогона кладутся
     * рабочими файлами прогона: агент видит «чекпойнт-…» в списке документов,
     * читает собранные наблюдения и добирает только недостающее — дорогой
     * цикл после обрыва сети не начинается с нуля.
     */
    static void restoreAgentCheckpoints(ScenarioRunGraph graph, List<ScenarioRunStep> oldSteps) {
        for (ScenarioRunStep old : oldSteps) {
            var out = old.getOutputData();
            if (out == null || !ScenarioStatus.FAILED.getValue().equals(old.getStatus())
                    || !hasCheckpoint(out.get("checkpoint"))) {
                continue;
            }
            graph.addWorkingDoc("чекпойнт-" + old.getNodeId() + "-прерванного-прогона.md",
                    "ЧАСТИЧНЫЕ ДАННЫЕ узла, собранные до сбоя прошлого прогона "
                            + "(используй их, добирай только недостающее):\n" + out.get("checkpoint"));
            log.info("[{}] Чекпойнт узла {} восстановлен рабочим файлом", CurrentUserHolder.getCurrentUser(), old.getNodeId());
        }
    }

    /** Чекпойнт пригоден к восстановлению, если заполнен непустым текстом. */
    private static boolean hasCheckpoint(Object checkpoint) {
        return checkpoint != null && !String.valueOf(checkpoint).isBlank();
    }

    /**
     * Восстанавливает документы прогона из сохранённого выхода входного узла
     * (формат «&lt;&lt;&lt;DOC_i&gt;&gt;&gt;текст&lt;&lt;&lt;END_DOC_i&gt;&gt;&gt;»).
     */
    private void restoreDocsFromSteps(ScenarioRunGraph graph, List<ScenarioRunStep> oldSteps) {
        log.info("[{}] restoreDocsFromSteps, steps={}",
                CurrentUserHolder.getCurrentUser(), oldSteps == null ? 0 : oldSteps.size());
        var inputStep = stepByType(oldSteps, graph, ScenarioNodeType.INPUT_NODE);
        String inputResult = inputStep == null || inputStep.getOutputData() == null
                ? null
                : Objects.toString(inputStep.getOutputData().get("result"), null);
        if (inputResult == null) {
            throw new ScenarioException("Возобновление невозможно: в исходном прогоне нет шага входного узла");
        }
        List<String> texts = new ArrayList<>();
        List<String> names = new ArrayList<>();
        var m = Pattern
                .compile("<<<(DOC_\\d+)>>>\\n(.*?)\\n<<<END_\\1>>>", Pattern.DOTALL)
                .matcher(inputResult);
        while (m.find()) {
            int idx = docLabelIndex(m.group(1));
            if (idx < 1 || idx > MAX_DOC_LABEL_INDEX) {
                // метка из текста документа («<<<DOC_2000000000>>>»), а не от входного узла
                log.warn("[{}] Блок {} пропущен: номер метки вне 1..{}",
                        CurrentUserHolder.getCurrentUser(), m.group(1), MAX_DOC_LABEL_INDEX);
                continue;
            }
            texts.add(m.group(2));
            names.add(m.group(1));
        }
        if (texts.isEmpty()) {
            throw new ScenarioException("Возобновление невозможно: не удалось восстановить документы "
                    + "из шага входного узла");
        }
        // исходные метки DOC_i: names ниже заменяются настоящими именами файлов
        List<String> labels = new ArrayList<>(names);
        restoreRealDocNames(inputStep, names);
        // документы — под ИСХОДНЫМИ метками: блоки старых прогонов шли в порядке итерации HashMap,
        // а addDocs перенумеровал бы их по позиции, и классы DOC_i цикла-классификатора
        // (restoreDocClasses) вместе с выборками по docClass доставались бы чужим текстам;
        // пропуски номеров сохраняются. Кладём в числовом порядке DOC_i: порядок docMap наследуют
        // docList детей входа, группировки и своды — иначе возобновлённый прогон шёл бы в хеш-порядке
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < texts.size(); i++) {
            order.add(i);
        }
        order.sort(Comparator.comparingInt(i -> docLabelIndex(labels.get(i))));
        for (int i : order) {
            graph.putDoc(labels.get(i), names.get(i), texts.get(i));
        }
    }

    /**
     * Подменяет технические имена DOC_i настоящими именами файлов из ключа
     * «doc_names» шага входного узла (сохраняется при выполнении) — иначе
     * возобновлённый прогон теряет группировку по имени/пути файла.
     * Сопоставление СТРОГО по номеру i метки DOC_i (doc_names хранит имена
     * в порядке DOC_1..DOC_n), а не по позиции блока: блоки в result идут
     * в порядке итерации docMap (HashMap) — позиционная подмена раздавала
     * документам ЧУЖИЕ имена и рушила группировку agent_group/group.
     * Старые прогоны без «doc_names» остаются на DOC_i.
     */
    static void restoreRealDocNames(ScenarioRunStep inputStep, List<String> names) {
        String saved = inputStep.getOutputData().get(ScenarioRunStepService.KEY_DOC_NAMES);
        if (saved == null || saved.isEmpty()) {
            return;
        }
        String[] savedNames = saved.split("\n", -1);
        for (int i = 0; i < names.size(); i++) {
            int idx = docLabelIndex(names.get(i));
            if (idx >= 1 && idx <= savedNames.length) {
                names.set(i, savedNames[idx - 1]);
            }
        }
    }

    /**
     * Номер i из технической метки «DOC_i»; -1, если метка не такого вида.
     */
    private static int docLabelIndex(String label) {
        log.info("[{}] docLabelIndex, label='{}'",
                CurrentUserHolder.getCurrentUser(), label);
        if (label == null || !label.startsWith("DOC_")) {
            return -1;
        }
        try {
            return Integer.parseInt(label.substring("DOC_".length()));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /**
     * Настоящие имена файлов документов для выхода шага входного узла
     * (ключ «doc_names», пишется тем же UPDATE, что и результат шага) — для
     * восстановления группировки при возобновлении.
     * Имя кладётся на позицию i-1 по номеру метки DOC_i: рабочие файлы агента
     * (WORK_i — например, чекпойнты возобновлённого прогона) пропускаются,
     * пропуски номеров заполняются пустыми строками. Раньше любой WORK_i или
     * пропуск номера отменял сохранение, и повторное возобновление теряло имена.
     *
     * @param node узел
     * @return имена через перевод строки либо {@code null} (не входной узел, документов нет)
     */
    private String inputDocNames(ScenarioRunNode node) {
        if (node.getType() != ScenarioNodeType.INPUT_NODE) {
            return null;
        }
        log.info("[{}] inputDocNames, node='{}' (id={})",
                node.getGraph().getRunnerUserId(),
                node.getLabel(), node.getId());
        var docMap = node.getGraph().getDocMap();
        if (docMap == null || docMap.isEmpty()) {
            return null;
        }
        List<String> names = new ArrayList<>();
        for (var entry : docMap.entrySet()) {
            int idx = docLabelIndex(entry.getKey());
            if (idx < 1 || idx > MAX_DOC_LABEL_INDEX || entry.getValue().isWorkNote()) {
                continue;
            }
            while (names.size() < idx) {
                names.add("");
            }
            names.set(idx - 1, entry.getValue().getFilename());
        }
        if (names.isEmpty()) {
            return null;
        }
        // имена не содержат перевода строки — компактная сериализация в String-поле
        return String.join("\n", names);
    }

    private ScenarioRunStep stepByType(List<ScenarioRunStep> steps, ScenarioRunGraph graph,
                                       ScenarioNodeType type) {
        log.info("[{}] stepByType, type={}", CurrentUserHolder.getCurrentUser(), type);
        for (var step : steps) {
            var node = graph.getNodeMap().get(step.getNodeId());
            if (node != null && node.getType() == type && step.getOutputData() != null) {
                return step;
            }
        }
        return null;
    }

    @SuppressWarnings("unused")
    private String stepResult(List<ScenarioRunStep> steps, ScenarioRunGraph graph, ScenarioNodeType type) {
        log.info("[{}] stepResult, type={}", CurrentUserHolder.getCurrentUser(), type);
        for (var step : steps) {
            var node = graph.getNodeMap().get(step.getNodeId());
            if (node != null && node.getType() == type && step.getOutputData() != null) {
                Object result = step.getOutputData().get("result");
                if (result != null) {
                    return String.valueOf(result);
                }
            }
        }
        return null;
    }

    /**
     * Помечает завершённые LLM-узлы восстановленными: выход — из шага старого прогона,
     * вклад в входы детей — как при обычном выполнении; классы документов —
     * из меток «&lt;&lt;&lt;DOC_i|CLASS:...&gt;&gt;&gt;» классифицирующего цикла.
     */
    private void restoreCompletedLlmNodes(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          ScenarioRun run,
                                          ScenarioRunGraph graph,
                                          List<ScenarioRunStep> oldSteps) {
        log.info("[{}] restoreCompletedLlmNodes, steps={}",
                CurrentUserHolder.getCurrentUser(), oldSteps == null ? 0 : oldSteps.size());
        Set<String> errorTainted = collectErrorTaintedNodeIds(graph, oldSteps);
        for (var step : oldSteps) {
            var node = graph.getNodeMap().get(step.getNodeId());
            if (errorTainted.contains(step.getNodeId())) {
                log.info("[{}] Узел {} упал или построен на ошибке родителя — узел перезапускается",
                        CurrentUserHolder.getCurrentUser(), step.getNodeId());
            } else if (isRestorableLlmStep(step, node)) {
                restoreLlmNode(sink, run, graph, step, node);
            }
        }
    }

    /**
     * Узлы, которые нельзя восстанавливать из-за ошибки родителя: упавший узел
     * и шаг, выполненный на результате узла, упавшего при on_error=continue/branch
     * ({@link #isBuiltOnNodeError}), плюс все потомки таких узлов в текущем графе —
     * их результаты выведены из текста ошибки, даже если маркер до них не дошёл.
     * Потомки упавшего узла помечаются и без маркера: при on_error=branch обычные
     * ветки пропускаются, и узел слияния отрабатывает на входе одной лишь соседней
     * ветки — после перезапуска упавшего узла его выход иначе молча терялся бы.
     * При on_error=stop у потомков упавшего узла шагов нет — поведение не меняется.
     *
     * @param graph    граф прогона
     * @param oldSteps шаги исходного прогона
     * @return идентификаторы узлов, которые нужно перезапустить
     */
    private Set<String> collectErrorTaintedNodeIds(ScenarioRunGraph graph, List<ScenarioRunStep> oldSteps) {
        log.info("[{}] collectErrorTaintedNodeIds, steps={}",
                CurrentUserHolder.getCurrentUser(), oldSteps.size());
        Set<String> tainted = new HashSet<>();
        int docMarkers = inputDocMarkerCount(graph, oldSteps);
        for (var step : oldSteps) {
            var node = graph.getNodeMap().get(step.getNodeId());
            boolean failed = ScenarioStatus.FAILED.getValue().equals(step.getStatus());
            if (node != null && (failed || isBuiltOnNodeError(step, docMarkers))) {
                markWithDescendants(node, tainted);
            }
        }
        return tainted;
    }

    /**
     * Число вхождений маркера ошибки узла в текстах документов исходного прогона —
     * по результату шага входного узла, где комплект хранится целиком (в шагах остальных
     * узлов с corp15 лежит только сводка документов). Верхняя граница для любого узла:
     * его документы — подмножество комплекта.
     *
     * @param graph    граф прогона
     * @param oldSteps шаги исходного прогона
     * @return число маркеров в комплекте документов (0, если шага входного узла нет)
     */
    private int inputDocMarkerCount(ScenarioRunGraph graph, List<ScenarioRunStep> oldSteps) {
        var inputStep = stepByType(oldSteps, graph, ScenarioNodeType.INPUT_NODE);
        String inputResult = inputStep == null ? null : inputStep.getOutputData().get(ScenarioRunStepService.KEY_RESULT);
        return StringUtils.countMatches(inputResult, NODE_ERROR_PREFIX);
    }

    /**
     * Добавляет узел и всех его потомков (граф ациклический) в набор.
     *
     * @param node    узел
     * @param tainted набор идентификаторов узлов (пополняется)
     */
    private static void markWithDescendants(ScenarioRunNode node, Set<String> tainted) {
        if (!tainted.add(node.getId())) {
            return;
        }
        for (var child : node.getChildNodeList()) {
            markWithDescendants(child, tainted);
        }
    }

    /**
     * Шаг выполнен на тексте ошибки родителя: во входе шага (input_data.previous_output —
     * вклад «=== РЕЗУЛЬТАТ ОТ "X" (ОШИБКА) ===», в том числе проброшенный через if/switch)
     * или в промпте (выражение {{output:X}}) есть результат узла, упавшего при
     * on_error=continue/branch (см. handleNodeError). Промпт содержит и тексты документов:
     * маркер засчитывается, только если в промпте его вхождений больше, чем в документах
     * комплекта, — документ с такой строкой (например, выгрузка итога прогона) не превращает
     * каждое возобновление в полный перезапуск поддерева. Число маркеров в документах —
     * из результата шага входного узла ({@code docMarkers}); для старых прогонов, где
     * input_data.documents_text ещё хранил полный текст, учитывается и он.
     *
     * @param step       шаг исходного прогона
     * @param docMarkers число маркеров в текстах документов комплекта
     * @return {@code true}, если результат шага построен на тексте ошибки
     */
    static boolean isBuiltOnNodeError(ScenarioRunStep step, int docMarkers) {
        var inputData = step.getInputData();
        String previousOutput = inputData == null
                ? null
                : inputData.get(ScenarioRunStepService.KEY_PREVIOUS_OUTPUT);
        String documentsText = inputData == null
                ? null
                : inputData.get(ScenarioRunStepService.KEY_DOCUMENTS_TEXT);
        int inDocs = Math.max(docMarkers, StringUtils.countMatches(documentsText, NODE_ERROR_PREFIX));
        return StringUtils.contains(previousOutput, NODE_ERROR_PREFIX)
                || StringUtils.countMatches(step.getPromptUsed(), NODE_ERROR_PREFIX) > inDocs;
    }

    /**
     * Шаг пригоден для восстановления: узел найден в графе, шаг завершён успешно,
     * узел LLM-типа (processing, loop, subscenario) и в шаге сохранён результат.
     *
     * @param step шаг исходного прогона
     * @param node узел графа, соответствующий шагу (может быть {@code null})
     * @return {@code true}, если выход узла можно восстановить из шага
     */
    private boolean isRestorableLlmStep(ScenarioRunStep step, ScenarioRunNode node) {
        log.info("[{}] isRestorableLlmStep, nodeId={}",
                CurrentUserHolder.getCurrentUser(),
                step == null ? null : step.getNodeId());
        if (node == null || step == null || !"completed".equalsIgnoreCase(String.valueOf(step.getStatus()))) {
            return false;
        }
        var type = node.getType();
        boolean llmNode = type == ScenarioNodeType.PROCESSING_NODE
                || type == ScenarioNodeType.LOOP_NODE
                || type == ScenarioNodeType.SUBSCENARIO_NODE;
        return llmNode && step.getOutputData() != null && step.getOutputData().get("result") != null;
    }

    /**
     * Восстанавливает один LLM-узел из шага старого прогона: выход, статусы,
     * копия шага в новый прогон, классы документов и вклад во входы детей.
     *
     * @param sink  поток SSE-событий
     * @param run   НОВЫЙ прогон
     * @param graph граф прогона
     * @param step  шаг исходного прогона с сохранённым результатом
     * @param node  восстанавливаемый узел
     */
    private void restoreLlmNode(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                ScenarioRun run,
                                ScenarioRunGraph graph,
                                ScenarioRunStep step,
                                ScenarioRunNode node) {
        log.info("[{}] restoreLlmNode, node='{}' (id={}, type={})",
                CurrentUserHolder.getCurrentUser(),
                node.getLabel(), node.getId(), node.getType());
        String output = String.valueOf(step.getOutputData().get("result"));
        node.getOutput().add(output);
        node.setCompleted(true);
        node.setSkip(false);
        // копия шага в новый прогон — иначе повторное возобновление не увидит
        // восстановленные LLM-узлы и перевыполнит их заново
        stepService.copyStepToRun(run.getId(), step);
        emitNodeStatusEvent(sink, node, ScenarioStatus.COMPLETED);
        // классы документов из классифицирующего цикла
        if (node.getType() == ScenarioNodeType.LOOP_NODE
                && node.isClassifyStrict()) {
            restoreDocClasses(graph, output);
        }
        // вклад восстановленного узла во входы детей: обычные ветки активируются,
        // ветки «ошибка» остаются пропущенными (узел завершился успешно)
        String contribution = "=== РЕЗУЛЬТАТ ОТ \"" + node.getLabel() + "\" ===\n" + output;
        for (var child : node.getChildNodeList()) {
            child.addInput(node.getId(), contribution);
            if (!isErrorEdge(node, child)) {
                child.setSkip(false);
            }
        }
    }

    /**
     * Восстанавливает классы документов из меток
     * «&lt;&lt;&lt;DOC_i|CLASS:...&gt;&gt;&gt;» в выходе классифицирующего цикла.
     *
     * @param graph  граф прогона
     * @param output восстановленный выход узла-цикла
     */
    private void restoreDocClasses(ScenarioRunGraph graph, String output) {
        log.info("[{}] restoreDocClasses, outputChars={}",
                CurrentUserHolder.getCurrentUser(), output == null ? 0 : output.length());
        var cm = Pattern.compile("<<<(DOC_\\d+)\\|CLASS:([^>]*)>>>").matcher(output);
        while (cm.find()) {
            var doc = graph.getDocMap().get(cm.group(1));
            if (doc != null) {
                doc.setDocClass(cm.group(2).trim());
            }
        }
    }

    private boolean isAllParentCompleted(ScenarioRunNode node) {
        log.info("[{}] isAllParentCompleted, node='{}' (id={})",
                CurrentUserHolder.getCurrentUser(),
                node.getLabel(), node.getId());
        var parentNodeList = node.getParentNodeList();
        if (parentNodeList == null || parentNodeList.isEmpty()) {
            return true;
        }
        return parentNodeList.stream().allMatch(p -> p.getCompleted() || p.getSkip());
    }

    /**
     * Валидирует граф сценария перед выполнением.
     * <p>
     * Проверяет:
     * <ul>
     *   <li>Наличие и непустота массивов nodes и edges</li>
     *   <li>Валидность ссылок рёбер на существующие узлы</li>
     *   <li>Отсутствие циклов (по результату топологической сортировки)</li>
     * </ul>
     *
     * @param graphData данные графа сценария
     * @throws IllegalArgumentException если валидация не пройдена
     */
    /**
     * Убирает из графа узлы-заметки (type=note) вместе с их рёбрами:
     * это аннотации для людей, в валидации и выполнении они не участвуют.
     */
    static GraphDataDto stripNoteNodes(GraphDataDto graphData) {
        Set<String> noteIds = graphData.nodes().stream()
                .filter(n -> ScenarioNodeType.NOTE_NODE
                        .toString().equals(n.type()))
                .map(NodeDto::id)
                .collect(Collectors.toSet());
        if (noteIds.isEmpty()) {
            return graphData;
        }
        return new GraphDataDto(
                graphData.nodes().stream().filter(n -> !noteIds.contains(n.id())).toList(),
                graphData.edges().stream()
                        .filter(e -> !noteIds.contains(e.source()) && !noteIds.contains(e.target()))
                        .toList());
    }

    private void validateGraph(GraphDataDto graphData) {
        log.info("[{}] validateGraph, nodes={}, edges={}",
                CurrentUserHolder.getCurrentUser(),
                graphData == null ? 0 : graphData.nodes().size(),
                graphData == null ? 0 : graphData.edges().size());
        if (graphData == null) {
            throw new ScenarioException("Ошибка валидации графа: отсутствуют данные графа");
        }
        if (graphData.nodes().isEmpty()) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует или пуст массив nodes");
        }
        if (graphData.nodes().size() > MAX_GRAPH_NODES) {
            throw new ScenarioException("Ошибка валидации графа: узлов " + graphData.nodes().size()
                    + " больше предела " + MAX_GRAPH_NODES);
        }
        if (graphData.edges().isEmpty()) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует или пуст массив edges");
        }
        if (graphData.nodes().stream()
                .noneMatch(n -> "input".equals(n.type()))) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует узел с типом 'Вход'");
        }
        if (graphData.nodes().stream()
                .noneMatch(n -> "output".equals(n.type()))) {
            throw new ScenarioException("Ошибка валидации графа: отсутствует узел с типом 'Выход'");
        }
        Set<String> nodeIds = getNodeIds(graphData);
        if (!getDisconnectedNodes(graphData, nodeIds).isEmpty()) {
            throw new ScenarioException("Ошибка валидации графа: обнаружены узлы, не связанные рёбрами");
        }
        // ровно один корень без родителей — «Вход»: лишний корень в последовательном/пошаговом
        // режиме не выполнялся бы вовсе (обходится только поддерево стартового узла);
        // ноль корней — цикл, о нём сообщает проверка ниже
        List<String> roots = getRootNodes(graphData);
        if (roots.size() > 1) {
            throw new ScenarioException("Ошибка валидации графа: несколько узлов без входящих рёбер, "
                    + "а корень должен быть один — «Вход»: " + String.join(", ", roots));
        }
        // Проверка успешной топологической сортировки (отсутствие циклов)
        List<String> sorted = topologicalSort(graphData);
        if (sorted.size() != nodeIds.size()) {
            throw new ScenarioException("Ошибка валидации графа: обнаружен цикл (" + sorted.size() + " из " + nodeIds.size() + " узлов отсортировано)");
        }
    }

    /**
     * Узлы без входящих рёбер в порядке JSON графа — в виде «метка (id, тип)» для сообщения об ошибке.
     *
     * @param graphData граф сценария
     * @return описания корневых узлов
     */
    private static List<String> getRootNodes(GraphDataDto graphData) {
        Set<String> targets = graphData.edges().stream()
                .map(EdgeDto::target)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        return graphData.nodes().stream()
                .filter(n -> !targets.contains(n.id()))
                .map(n -> {
                    String label = n.data() == null || n.data().label() == null ? "" : "«" + n.data().label() + "» ";
                    return label + "(" + n.id() + ", " + n.type() + ")";
                })
                .toList();
    }

    private List<String> getDisconnectedNodes(GraphDataDto graphData, Set<String> nodeIds) {
        log.info("[{}] getDisconnectedNodes, nodeIds={}",
                CurrentUserHolder.getCurrentUser(), nodeIds == null ? 0 : nodeIds.size());
        if (nodeIds == null) {
            return List.of();
        }
        // Проверка, что все узлы участвуют хотя бы в одном ребре (source или target)
        Set<String> edgeNodeIds = graphData.edges().stream()
                .flatMap(e -> Stream.of(e.source(), e.target()))
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());
        return nodeIds.stream()
                .filter(id -> !edgeNodeIds.contains(id))
                .toList();
    }

    private List<String> topologicalSort(GraphDataDto graphData) {
        log.info("[{}] topologicalSort, nodes={}",
                CurrentUserHolder.getCurrentUser(),
                graphData == null ? 0 : graphData.nodes().size());
        if (graphData == null) {
            return List.of();
        }
        var nodes = graphData.nodes();
        var edges = graphData.edges();
        Map<String, List<String>> graph = new HashMap<>();
        Map<String, Integer> inDegree = new LinkedHashMap<>();

        for (var node : nodes) {
            inDegree.put(node.id(), 0);
        }

        for (var edge : edges) {
            String src = edge.source();
            String tgt = edge.target();
            graph.computeIfAbsent(src, k -> new ArrayList<>()).add(tgt);
            inDegree.merge(tgt, 1, Integer::sum);
        }

        Deque<String> queue = new ArrayDeque<>();
        for (Map.Entry<String, Integer> entry : inDegree.entrySet()) {
            if (entry.getValue() == 0) {
                queue.add(entry.getKey());
            }
        }

        List<String> result = new ArrayList<>();
        while (!queue.isEmpty()) {
            String nodeId = queue.poll();
            result.add(nodeId);
            for (String neighbor : graph.getOrDefault(nodeId, List.of())) {
                int newDeg = inDegree.merge(neighbor, -1, Integer::sum);
                if (newDeg == 0) {
                    queue.add(neighbor);
                }
            }
        }
        return result;
    }
}
