package ru.sber.cs.ai.gigame.service;

import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Краткая понятная человеку причина сбоя вызова GigaChat — для текста ошибки шага прогона и журнала пользователя.
 * <p>
 * Причина извлекается из цепочки cause. Ответ GigaChat с кодом ошибки spring-ai превращает в
 * {@code NonTransientAiException} (4xx) или {@code TransientAiException} (5xx) с текстом
 * «HTTP 404 - {"status":404,"message":"No such model"}»; ответы RestClient/WebClient разбираются по коду и телу;
 * прерывание потока узла ({@link InterruptedException} в цепочке) — отдельная причина; прочее — сообщение
 * исключения и его корневой причины без стека.
 */
final class GigaChatFailureReason {

    /** Предел длины тела ответа или сообщения в причине. */
    static final int DETAIL_LIMIT = 200;
    /** Причина при HTTP 413 «Tokens limit exceeded». */
    static final String TOKENS_LIMIT = "превышен лимит токенов модели (HTTP 413) — сократите документы или промпт";
    /** Причина при прерывании потока узла без остановки прогона. */
    static final String INTERRUPTED = "запрос прерван: поток выполнения узла остановлен";
    private static final int MAX_DEPTH = 8;
    private static final int HTTP_NOT_FOUND = 404;
    private static final int HTTP_TOO_LARGE = 413;
    /** «HTTP 413 - {…}» (spring-ai-autoconfigure-retry), «HTTP 500» или «413 - {…}» (RetryUtils по умолчанию). */
    private static final Pattern HTTP_TEXT = Pattern.compile(
            "^(?:HTTP\\s+([1-5]\\d{2})\\b(?:\\s*-)?|([1-5]\\d{2})\\s+-)\\s*(.*)$", Pattern.DOTALL);
    /** Поле message JSON-тела ответа GigaChat. */
    private static final Pattern JSON_MESSAGE = Pattern.compile("\"message\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
    private static final Pattern HTML_TAG = Pattern.compile("<[^>]*>");
    private static final Pattern SPACES = Pattern.compile("\\s+");

    private GigaChatFailureReason() {
    }

    /** Ответ GigaChat с кодом ошибки: код и тело. */
    private record HttpFailure(int status, String body) {
    }

    /**
     * Краткая причина сбоя вызова GigaChat.
     *
     * @param error исключение вызова (с цепочкой причин)
     * @param model имя модели запроса (null — неизвестно)
     * @return строка причины без стека, не длиннее нескольких сотен символов
     */
    static String describe(Throwable error, String model) {
        if (error == null) {
            return "неизвестная ошибка";
        }
        HttpFailure http = findHttpFailure(error);
        if (http != null) {
            return describeHttp(http, model);
        }
        if (hasInterruption(error)) {
            return INTERRUPTED;
        }
        return shorten(plainMessage(error));
    }

    /**
     * Код ответа GigaChat с ошибкой из цепочки причин.
     *
     * @param error исключение вызова
     * @return HTTP-код или {@code null}, если в цепочке нет ответа с кодом ошибки
     */
    static Integer httpStatus(Throwable error) {
        HttpFailure http = error == null ? null : findHttpFailure(error);
        return http == null ? null : http.status();
    }

    private static HttpFailure findHttpFailure(Throwable error) {
        Throwable t = error;
        for (int depth = 0; t != null && depth < MAX_DEPTH; depth++) {
            HttpFailure found = httpFailureOf(t);
            if (found != null) {
                return found;
            }
            t = t.getCause() == t ? null : t.getCause();
        }
        return null;
    }

    private static HttpFailure httpFailureOf(Throwable t) {
        if (t instanceof RestClientResponseException rest) {
            return new HttpFailure(rest.getStatusCode().value(), rest.getResponseBodyAsString());
        }
        if (t instanceof WebClientResponseException web) {
            return new HttpFailure(web.getStatusCode().value(), web.getResponseBodyAsString());
        }
        Matcher m = HTTP_TEXT.matcher(String.valueOf(t.getMessage()).strip());
        if (!m.matches()) {
            return null;
        }
        String code = m.group(1) != null ? m.group(1) : m.group(2);
        return new HttpFailure(Integer.parseInt(code), m.group(3));
    }

    private static String describeHttp(HttpFailure http, String model) {
        String body = http.body() == null ? "" : http.body();
        if (http.status() == HTTP_NOT_FOUND && body.toLowerCase(Locale.ROOT).contains("model")) {
            String name = model == null || model.isBlank() ? "модель" : "модель «" + model + "»";
            return name + " недоступна (HTTP 404)";
        }
        if (http.status() == HTTP_TOO_LARGE && body.contains("Tokens limit")) {
            return TOKENS_LIMIT;
        }
        String detail = shorten(bodyMessage(body));
        return detail.isEmpty() ? "HTTP " + http.status() : "HTTP " + http.status() + ": " + detail;
    }

    /** Текст из тела ответа: поле message JSON, иначе тело без HTML-разметки. */
    private static String bodyMessage(String body) {
        Matcher m = JSON_MESSAGE.matcher(body);
        if (m.find()) {
            return m.group(1).replace("\\\"", "\"");
        }
        return HTML_TAG.matcher(body).replaceAll(" ");
    }

    private static boolean hasInterruption(Throwable error) {
        Throwable t = error;
        for (int depth = 0; t != null && depth < MAX_DEPTH; depth++) {
            if (t instanceof InterruptedException) {
                return true;
            }
            t = t.getCause() == t ? null : t.getCause();
        }
        return false;
    }

    /** Сообщение исключения; корневая причина дописывается в скобках, если её текста в сообщении нет. */
    private static String plainMessage(Throwable error) {
        Throwable root = error;
        for (int depth = 0; root.getCause() != null && root.getCause() != root && depth < MAX_DEPTH; depth++) {
            root = root.getCause();
        }
        String top = messageOf(error);
        String rootMessage = messageOf(root);
        return root == error || top.contains(rootMessage) ? top : top + " (" + rootMessage + ")";
    }

    private static String messageOf(Throwable t) {
        String message = t.getMessage();
        return message == null || message.isBlank() ? t.getClass().getSimpleName() : message;
    }

    /** Одна строка без лишних пробелов, не длиннее {@link #DETAIL_LIMIT} символов. */
    private static String shorten(String text) {
        String line = SPACES.matcher(text).replaceAll(" ").strip();
        return line.length() <= DETAIL_LIMIT ? line : line.substring(0, DETAIL_LIMIT) + "…";
    }
}
