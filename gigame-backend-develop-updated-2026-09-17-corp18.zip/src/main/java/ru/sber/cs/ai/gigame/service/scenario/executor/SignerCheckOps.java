package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «сверить_подписантов» узла «Трансформация»: ФИО лиц из преамбулы договора
 * («в лице Генерального директора Щербаковой Елены Олеговны») сверяются с расшифровками подписей
 * («Е.О. Щербакова», «Новикова Е.В.»).
 * <p>
 * Преамбула пишет ФИО в родительном падеже, подпись — фамилию в именительном и инициалы, поэтому
 * фамилии сравниваются по основе (без двух последних букв), а имя и отчество — по первым буквам.
 * Итог по каждому лицу: СОВПАДАЕТ; РАСХОЖДЕНИЕ (фамилия та же, инициалы другие); ПОДПИСЬ НЕ НАЙДЕНА
 * (расшифровки с этой фамилией в договоре нет — строки подписи пустые или подписывает другое лицо).
 * <p>
 * Сверка идёт сначала по расшифровкам с инициалами; если расшифровки с фамилией лица нет, — по ФИО штампа электронной
 * подписи («Подписано электронной подписью / ФИО: …», «Подпись банка / ФИО / дата»), затем по полным ФИО
 * («Ларионов Евгений Алексеевич») из блока подписей (после «От Заказчика:», «Подписи сторон» и т.п.). Полное ФИО блока
 * засчитывается, только если стоит у строки подписи (своя или соседняя непустая строка с чертой «___» или расшифровкой
 * «/…/»), расшифровка там не пустая («/ ______ /») и в строках подписи того же блока нет расшифровки лица, полное ФИО
 * которого в договоре не встречается («/П.П. Петров/ по доверенности»), — иначе ПОДПИСЬ НЕ НАЙДЕНА. Полные ФИО из тела
 * договора (контактные лица, преамбула ИП) подписью не считаются.
 * <p>
 * Сторона-ИП без «в лице» («Индивидуальный предприниматель Иванов Иван Иванович, именуемый в дальнейшем …») подписывает
 * сама: её ФИО в именительном падеже — тоже лицо преамбулы и сверяется с подписями тем же порядком.
 * <pre>
 * {"оп": "сверить_подписантов", "класс_договора": "договор"}
 * </pre>
 */
final class SignerCheckOps {

    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final String WORD = "[А-ЯЁ][а-яё]+(?:-[А-ЯЁ][а-яё]+)?";
    private static final Pattern IN_PERSON = Pattern.compile("в\\s+лице", FLAGS);
    private static final Pattern FULL_NAME = Pattern.compile("(" + WORD + ")\\s+([А-ЯЁ][а-яё]+)\\s+([А-ЯЁ][а-яё]+(?:вич|ич|вн|чн)[аы]?)(?![а-яё])");
    /**
     * Сторона-ИП в преамбуле: ФИО в именительном падеже после «Индивидуальный предприниматель» или «ИП» до «, именуем…»,
     * «, действующ…», «(ИНН» или «(ОГРНИП» (текст после {@link #capitalized}: «ИНН» → «Инн»).
     */
    private static final Pattern ENTREPRENEUR = Pattern.compile("(?iu:индивидуальный\\s+предприниматель|(?<![а-яё])ип)\\s+[«\"“]?(" + WORD
            + ")\\s+([А-ЯЁ][а-яё]+)\\s+([А-ЯЁ][а-яё]+(?:вич|ич|вн|чн)[аы]?)[»\"”]?\\s*(?iu:,\\s*(?:именуем|действующ)|\\(\\s*(?:инн|огрнип))");
    /** Конец описания стороны в преамбуле: «с одной/другой стороны», «(совместно) именуемые», начало следующей стороны «и ПАО …». */
    private static final Pattern PARTY_END = Pattern.compile("(?iu:с\\s+(?:одной|другой)\\s+сторон|именуемые)|(?<![А-ЯЁа-яё])и\\s+[«\"]?[А-ЯЁ]");
    private static final Pattern INITIALS_FIRST = Pattern.compile("(?<![А-ЯЁа-яё])([А-ЯЁ])\\.\\s?([А-ЯЁ])\\.\\s?(" + WORD + ")");
    private static final Pattern SURNAME_FIRST = Pattern.compile("(" + WORD + ")\\s+([А-ЯЁ])\\.\\s?([А-ЯЁ])\\.");
    /** Начало блока подписей: «реквизиты (и подписи) сторон», «подписи сторон», «от заказчика:», «от поставщика:» и т.п. */
    private static final Pattern BLOCK_MARKER = Pattern.compile("реквизиты\\s+(?:и\\s+подписи\\s+)?сторон|подписи\\s+сторон"
            + "|от\\s+(?:заказчика|поставщика|исполнителя|подрядчика|покупателя|продавца|банка|арендатора|арендодателя|лицензиара|лицензиата)\\s*:", FLAGS);
    /**
     * Полное ФИО отдельной строкой или ячейкой: от начала строки, черты подписи «___», «/» или границы ячейки таблицы
     * («|», «&lt;», «&gt;») до конца строки или такой же границы. ФИО «Мохов Михаил Александрович, e-mail: …»
     * (контактные лица) не подходит.
     */
    private static final Pattern BLOCK_FULL_NAME = Pattern.compile("(?:^|(?<=[_/|<>]))\\h*(" + WORD + ")\\h+([А-ЯЁ][а-яё]+)\\h+"
            + "([А-ЯЁ][а-яё]+(?:вич|ич|вн|чн)[аы]?)\\h*(?=[_/|<>]|$)");
    /** ФИО штампа электронной подписи: «Подписано электронной подписью\nФИО: Ларионов Евгений Алексеевич». */
    private static final Pattern STAMP_NAME = Pattern.compile("подписан[а-яё]*\\s+электронн[а-яё]*\\s+подпис[а-яё]*\\s*ФИО\\s*:\\h*([^\\r\\n]+)", FLAGS);
    /** ФИО штампа ЭДО: «Подпись\nпоставщика\nЛатин Юрий Эдуардович\nООО …\n28.03.2025 16:32:05» (F3-K7). */
    private static final Pattern EDO_STAMP_NAME = Pattern.compile("(?<![а-яё])подпись\\s+(?:банка|заказчика|поставщика|исполнителя|подрядчика"
            + "|покупателя|продавца)\\h*\\R\\h*([^\\r\\n]+)", FLAGS);
    /** Слово прописными буквами («ГРЯЗНОВ»). */
    private static final Pattern UPPER_WORD = Pattern.compile("(?<![А-ЯЁа-яё])([А-ЯЁ])([А-ЯЁ]+)(?![А-ЯЁа-яё])");
    /** Черта подписи. */
    private static final Pattern SIGN_STROKE = Pattern.compile("_{3,}");
    /** Расшифровка подписи в косых чертах «/П.П. Петров/», «/ __________ /» (по порядку, без перекрытий). */
    private static final Pattern SLOT = Pattern.compile("/([^/\\r\\n]{0,80})/");
    /** Пустая расшифровка: черта, возможно с подсказкой бланка «__________(указать ФИО) _________». */
    private static final Pattern BLANK_SLOT = Pattern.compile("\\h*_+[\\h_]*(?:\\([^)]*\\)[\\h_]*)?");
    /** Пометка вердикта, вынесенного по штампу электронной подписи. */
    private static final String STAMP_NOTE = " (ФИО в штампе электронной подписи)";
    /** Пометка вердикта, вынесенного по полному ФИО у строки подписи. */
    private static final String BLOCK_NOTE = " (полное ФИО у строки подписи)";
    private static final String NOT_FOUND = "ПОДПИСЬ НЕ НАЙДЕНА";
    /** Сколько символов после «в лице» просматривается в поисках ФИО (и после ФИО стороны-ИП — в поисках «в лице»). */
    private static final int PREAMBLE_WINDOW = 300;
    /** Сколько символов после начала блока подписей просматривается в поисках полных ФИО. */
    private static final int BLOCK_WINDOW = 600;
    /** Сколько «в лице» в начале договора рассматривается (стороны договора). */
    private static final int MAX_PARTIES = 4;
    private static final int STEM_CUT = 2;
    private static final int MIN_STEM = 3;

    private SignerCheckOps() {
    }

    /** Лицо: фамилия (как в тексте), первые буквы имени и отчества. */
    record Person(String surname, char name, char patronymic) {

        String initials() {
            return name + "." + patronymic + ".";
        }
    }

    /**
     * Полное ФИО из блока подписей.
     *
     * @param person   лицо в инициалах
     * @param fullName ФИО как в блоке (прописные буквы приведены к обычному написанию)
     * @param foreign  расшифровки лиц, чьё полное ФИО в договоре не встречается, в строках подписи того же блока
     *                 («П.П. Петров»); пусто — ФИО стоит у строки подписи с непустой расшифровкой
     */
    record BlockName(Person person, String fullName, List<String> foreign) {
    }

    /**
     * Подписи договора.
     *
     * @param initials   расшифровки с инициалами («Е.А. Ларионов», «Новикова Е.В.») по порядку появления
     * @param stamps     ФИО штампов электронной подписи и ЭДО в инициалах, без повторов
     * @param blockNames полные ФИО блоков подписей, без повторов
     */
    record Signatures(List<Person> initials, List<Person> stamps, List<BlockName> blockNames) {
    }

    /**
     * Сверка подписантов по договорам прогона.
     *
     * @param op   параметры операции
     * @param docs документы прогона с классами
     * @return отчёт по каждому лицу преамбулы и итоговый JSON
     */
    static String check(Map<String, Object> op, Collection<ScenarioRunDoc> docs) {
        Pattern contractClass = SafeRegex.compile("^(?:" + op.getOrDefault("класс_договора", "договор") + ")$", FLAGS, "класс_договора");
        StringBuilder sb = new StringBuilder("СВЕРКА ПОДПИСАНТОВ (код)\n");
        int mismatches = 0;
        int missing = 0;
        int people = 0;
        for (ScenarioRunDoc doc : docs) {
            if (doc.isWorkNote() || doc.getDocClass() == null || !SafeRegex.matches(contractClass, doc.getDocClass().strip())) {
                continue;
            }
            sb.append("Договор «").append(doc.getFilename()).append("»:\n");
            Signatures signatures = signatures(doc.getText());
            for (Person person : preamble(doc.getText())) {
                String verdict = verdict(person, signatures);
                people++;
                mismatches += verdict.startsWith("РАСХОЖДЕНИЕ") ? 1 : 0;
                missing += verdict.startsWith(NOT_FOUND) ? 1 : 0;
                sb.append("- ").append(person.surname()).append(' ').append(person.initials()).append(" (преамбула): ").append(verdict).append('\n');
            }
        }
        if (people == 0) {
            sb.append("ФИО подписантов в преамбуле («в лице …») не найдены — сверка не выполнена\n");
        }
        return sb.append("{\"подписантов\": ").append(people).append(", \"расхождений\": ").append(mismatches)
                .append(", \"подпись_не_найдена\": ").append(missing).append("}").toString();
    }

    /**
     * Лица из преамбулы: ФИО (фамилия, имя, отчество) после «в лице», затем стороны-ИП без «в лице»
     * ({@link #entrepreneurs}), кроме уже найденных после «в лице» («ИП Иванов Иван Иванович, именуемый …, в лице
     * Иванова Ивана Ивановича»).
     *
     * @param text текст договора
     * @return лица по порядку без повторов
     */
    static List<Person> preamble(String text) {
        List<Person> people = representatives(text);
        for (Person owner : entrepreneurs(text)) {
            if (people.stream().noneMatch(person -> samePerson(person, owner))) {
                people.add(owner);
            }
        }
        return people;
    }

    /**
     * Лица после «в лице» в первых {@link #MAX_PARTIES} оборотах договора.
     *
     * @param text текст договора
     * @return лица по порядку без повторов
     */
    static List<Person> representatives(String text) {
        Set<Person> people = new LinkedHashSet<>();
        Matcher in = IN_PERSON.matcher(text);
        for (int i = 0; i < MAX_PARTIES && in.find(); i++) {
            String window = text.substring(in.end(), Math.min(text.length(), in.end() + PREAMBLE_WINDOW));
            Matcher fm = FULL_NAME.matcher(window);
            if (fm.find()) {
                people.add(new Person(fm.group(1), fm.group(2).charAt(0), fm.group(3).charAt(0)));
            }
        }
        return new ArrayList<>(people);
    }

    /**
     * Стороны-ИП преамбулы, подписывающие сами: «Индивидуальный предприниматель Иванов Иван Иванович, именуемый в дальнейшем
     * «Поставщик»» (ФИО в именительном падеже, прописные буквы приводятся к обычному написанию). ИП, от имени которого
     * действует представитель («…, именуемый «Поставщик», в лице Петрова Петра Петровича»), не берётся — подписывает
     * представитель, он найден после «в лице».
     *
     * @param text текст договора
     * @return лица по порядку без повторов
     */
    static List<Person> entrepreneurs(String text) {
        String normal = capitalized(text);
        Set<Person> people = new LinkedHashSet<>();
        Matcher party = ENTREPRENEUR.matcher(normal);
        for (int i = 0; i < MAX_PARTIES && party.find(); i++) {
            if (!actsThroughRepresentative(normal, party.end())) {
                people.add(new Person(party.group(1), party.group(2).charAt(0), party.group(3).charAt(0)));
            }
        }
        return new ArrayList<>(people);
    }

    /**
     * Есть ли «в лице» в описании стороны после её ФИО — до «с одной/другой стороны», «именуемые» или следующей стороны
     * («и ПАО Сбербанк»), не дальше {@link #PREAMBLE_WINDOW} символов.
     *
     * @param text текст договора
     * @param from конец ФИО стороны
     * @return {@code true}, если сторона действует в лице представителя
     */
    private static boolean actsThroughRepresentative(String text, int from) {
        String clause = text.substring(from, Math.min(text.length(), from + PREAMBLE_WINDOW));
        Matcher end = PARTY_END.matcher(clause);
        return IN_PERSON.matcher(end.find() ? clause.substring(0, end.start()) : clause).find();
    }

    private static boolean samePerson(Person a, Person b) {
        return a.name() == b.name() && a.patronymic() == b.patronymic() && sameSurname(a.surname(), b.surname());
    }

    /**
     * Подписи договора: расшифровки вида «И.О. Фамилия» и «Фамилия И.О.» во всём тексте, ФИО штампов ЭП и ЭДО и полные
     * ФИО («Ларионов Евгений Алексеевич») из блоков подписей.
     *
     * @param text текст договора
     * @return расшифровки, штампы и полные ФИО блоков
     */
    static Signatures signatures(String text) {
        return new Signatures(decryptions(text), stampNames(text), blockNames(text));
    }

    /**
     * Расшифровки с инициалами по порядку: сначала «И.О. Фамилия», затем «Фамилия И.О.».
     *
     * @param text текст
     * @return лица без «М.П.»
     */
    static List<Person> decryptions(String text) {
        List<Person> result = new ArrayList<>();
        Matcher a = INITIALS_FIRST.matcher(text);
        while (a.find()) {
            addSignature(result, new Person(a.group(3), a.group(1).charAt(0), a.group(2).charAt(0)));
        }
        Matcher b = SURNAME_FIRST.matcher(text);
        while (b.find()) {
            addSignature(result, new Person(b.group(1), b.group(2).charAt(0), b.group(3).charAt(0)));
        }
        return result;
    }

    /**
     * ФИО штампов электронной подписи и ЭДО в инициалах; прописные буквы («ГРЯЗНОВ ВЛАДИМИР СЕРГЕЕВИЧ») приводятся
     * к обычному написанию.
     *
     * @param text текст договора
     * @return лица без повторов по порядку: сначала штампы ЭП, затем ЭДО
     */
    static List<Person> stampNames(String text) {
        Set<Person> people = new LinkedHashSet<>();
        for (Pattern pattern : List.of(STAMP_NAME, EDO_STAMP_NAME)) {
            Matcher stamp = pattern.matcher(text);
            while (stamp.find()) {
                Matcher name = FULL_NAME.matcher(capitalized(stamp.group(1).strip()));
                if (name.lookingAt()) {
                    people.add(new Person(name.group(1), name.group(2).charAt(0), name.group(3).charAt(0)));
                }
            }
        }
        return new ArrayList<>(people);
    }

    /**
     * Полные ФИО блоков подписей: строки в окне после каждого начала блока ({@link #BLOCK_MARKER}; после основного блока
     * в договоре обычно идут пустые формы актов приложений с теми же «От Поставщика: От Заказчика:»), кроме остатка
     * строки самого начала блока. ФИО берётся, если в строках подписи окна есть расшифровка лица, чьё полное ФИО
     * в договоре не встречается (с пометкой {@link BlockName#foreign()}), либо ФИО стоит у строки подписи с непустой
     * расшифровкой.
     *
     * @param text текст договора
     * @return полные ФИО без повторов по порядку
     */
    static List<BlockName> blockNames(String text) {
        List<String> named = namedSurnames(text);
        Set<BlockName> result = new LinkedHashSet<>();
        Matcher marker = BLOCK_MARKER.matcher(text);
        while (marker.find()) {
            String window = capitalized(text.substring(marker.end(), Math.min(text.length(), marker.end() + BLOCK_WINDOW)));
            List<String> lines = List.of(window.split("\\R", -1));
            List<String> foreign = foreignSignatures(lines, named);
            for (int i = 1; i < lines.size(); i++) {
                Matcher name = BLOCK_FULL_NAME.matcher(lines.get(i));
                while (name.find()) {
                    Person person = new Person(name.group(1), name.group(2).charAt(0), name.group(3).charAt(0));
                    String fullName = name.group(1) + " " + name.group(2) + " " + name.group(3);
                    if (!foreign.isEmpty() || nearSignatureLine(lines, i)) {
                        result.add(new BlockName(person, fullName, foreign));
                    }
                }
            }
        }
        return new ArrayList<>(result);
    }

    /**
     * Фамилии полных ФИО договора (преамбула, реквизиты, штампы): лицо с расшифровкой подписи, чьей фамилии среди них
     * нет, в договоре больше не упоминается. Окно преамбулы ограничено ({@link #PREAMBLE_WINDOW}): F3-K7 — «в лице
     * Старшего управляющего директора … Ильина Анатолия Сергеевича» дальше окна, а «/А.С. Ильин/» — законная подпись.
     *
     * @param text текст договора
     * @return фамилии по порядку появления
     */
    static List<String> namedSurnames(String text) {
        Set<String> surnames = new LinkedHashSet<>();
        Matcher name = FULL_NAME.matcher(capitalized(text));
        while (name.find()) {
            surnames.add(name.group(1));
        }
        return new ArrayList<>(surnames);
    }

    /**
     * Расшифровки в строках подписи окна лиц, чьё полное ФИО в договоре не встречается: «_____________ /П.П. Петров/»
     * при преамбуле «в лице … Иванова Ивана Ивановича» — подписывает другое лицо (по доверенности).
     *
     * @param lines строки окна блока подписей
     * @param named фамилии полных ФИО договора ({@link #namedSurnames})
     * @return расшифровки «И.О. Фамилия» без повторов
     */
    static List<String> foreignSignatures(List<String> lines, List<String> named) {
        Set<String> foreign = new LinkedHashSet<>();
        for (String line : lines) {
            if (!isSignatureLine(line)) {
                continue;
            }
            for (Person signer : decryptions(line)) {
                if (named.stream().noneMatch(surname -> sameSurname(surname, signer.surname()))) {
                    foreign.add(signer.initials() + " " + signer.surname());
                }
            }
        }
        return new ArrayList<>(foreign);
    }

    /**
     * ФИО строки {@code index} стоит у строки подписи: своя строка — строка подписи с непустой расшифровкой; иначе
     * соседние непустые строки (выше и ниже), среди которых есть строка подписи и нет пустой расшифровки «/ ______ /».
     *
     * @param lines строки окна блока подписей
     * @param index строка с ФИО
     * @return {@code true}, если ФИО — расшифровка подписи
     */
    static boolean nearSignatureLine(List<String> lines, int index) {
        String own = lines.get(index);
        if (isSignatureLine(own)) {
            return !hasBlankSlot(own);
        }
        boolean signature = false;
        for (String line : List.of(neighbour(lines, index, -1), neighbour(lines, index, 1))) {
            if (hasBlankSlot(line)) {
                return false;
            }
            signature |= isSignatureLine(line);
        }
        return signature;
    }

    private static String neighbour(List<String> lines, int index, int step) {
        for (int i = index + step; i >= 0 && i < lines.size(); i += step) {
            if (!lines.get(i).isBlank()) {
                return lines.get(i);
            }
        }
        return "";
    }

    /** Строка подписи: черта «___» или расшифровка с ФИО в косых чертах «/П.П. Петров/». */
    private static boolean isSignatureLine(String line) {
        if (SIGN_STROKE.matcher(line).find()) {
            return true;
        }
        Matcher slot = SLOT.matcher(line);
        while (slot.find()) {
            String content = slot.group(1);
            if (INITIALS_FIRST.matcher(content).find() || SURNAME_FIRST.matcher(content).find() || FULL_NAME.matcher(content).find()) {
                return true;
            }
        }
        return false;
    }

    /** В строке есть пустая расшифровка «/ __________ /» (или бланк «/ ____(указать ФИО) ____ /»). */
    private static boolean hasBlankSlot(String line) {
        Matcher slot = SLOT.matcher(line);
        while (slot.find()) {
            if (BLANK_SLOT.matcher(slot.group(1)).matches()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Слова прописными буквами — с заглавной буквы («ГРЯЗНОВ ВЛАДИМИР» → «Грязнов Владимир»): штамп ЭП и бланки
     * пишут ФИО прописными.
     *
     * @param text текст
     * @return текст с прописными словами в обычном написании
     */
    static String capitalized(String text) {
        Matcher m = UPPER_WORD.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + m.group(2).toLowerCase(Locale.ROOT)));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /** «М.П.» после расшифровки подписи — место печати, не инициалы. */
    private static void addSignature(List<Person> result, Person person) {
        if (person.name() != 'М' || person.patronymic() != 'П') {
            result.add(person);
        }
    }

    /**
     * Вердикт по лицу: по расшифровкам с инициалами; если расшифровки с фамилией лица нет — по штампу ЭП или ЭДО; затем по
     * полным ФИО блока подписей: ФИО лица в блоке, где подписывает другое лицо, — ПОДПИСЬ НЕ НАЙДЕНА с расшифровкой,
     * ФИО у строки подписи — вердикт с пометкой {@link #BLOCK_NOTE}.
     */
    private static String verdict(Person person, Signatures signatures) {
        String byInitials = verdict(person, signatures.initials(), "");
        if (!byInitials.startsWith(NOT_FOUND)) {
            return byInitials;
        }
        String byStamp = verdict(person, signatures.stamps(), STAMP_NOTE);
        if (!byStamp.startsWith(NOT_FOUND)) {
            return byStamp;
        }
        List<Person> nearLine = new ArrayList<>();
        for (BlockName block : signatures.blockNames()) {
            if (!sameSurname(person.surname(), block.person().surname())) {
                continue;
            }
            if (!block.foreign().isEmpty()) {
                return NOT_FOUND + (block.foreign().size() == 1 ? " — расшифровка «" : " — расшифровки «") + String.join("», «", block.foreign())
                        + "», ФИО «" + block.fullName() + "» указано только в реквизитах";
            }
            nearLine.add(block.person());
        }
        String byBlock = verdict(person, nearLine, BLOCK_NOTE);
        return byBlock.startsWith(NOT_FOUND) ? byInitials : byBlock;
    }

    private static String verdict(Person person, List<Person> signatures, String note) {
        List<String> sameSurname = new ArrayList<>();
        for (Person s : signatures) {
            if (!sameSurname(person.surname(), s.surname())) {
                continue;
            }
            if (s.name() == person.name() && s.patronymic() == person.patronymic()) {
                return "СОВПАДАЕТ — подпись «" + s.initials() + " " + s.surname() + "»" + note;
            }
            sameSurname.add(s.initials() + " " + s.surname());
        }
        if (!sameSurname.isEmpty()) {
            return "РАСХОЖДЕНИЕ — в подписи другие инициалы: " + String.join(", ", new LinkedHashSet<>(sameSurname)) + note;
        }
        return NOT_FOUND + " — расшифровки подписи с фамилией " + person.surname() + " в договоре нет";
    }

    /**
     * Одна ли фамилия в разных падежах: общая основа без двух последних букв («Щербаковой» / «Щербакова»,
     * «Ларионова» / «Ларионов»).
     *
     * @param a фамилия
     * @param b фамилия
     * @return {@code true}, если основы совпадают
     */
    static boolean sameSurname(String a, String b) {
        String x = a.toLowerCase(Locale.ROOT).replace('ё', 'е');
        String y = b.toLowerCase(Locale.ROOT).replace('ё', 'е');
        int stem = Math.max(MIN_STEM, Math.min(x.length(), y.length()) - STEM_CUT);
        return x.length() >= stem && y.length() >= stem && x.substring(0, stem).equals(y.substring(0, stem));
    }
}
