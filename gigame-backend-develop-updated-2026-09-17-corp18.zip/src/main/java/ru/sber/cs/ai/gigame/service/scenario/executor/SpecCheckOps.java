package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Block;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.LineResult;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecLineCheck.Status;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecTableParser.Columns;
import ru.sber.cs.ai.gigame.service.scenario.executor.SpecTableParser.SpecPosition;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.utils.SafeRegex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Операция «сверить_характеристики» узла «Трансформация»: характеристики продукции из таблицы
 * извещения / документации / ТЗ сверяются с текстом договора кодом, построчно и по позициям.
 * <p>
 * Модель сворачивала все требования документа в одну строку и теряла позиции (из 16 позиций
 * мебели проверялись две) и хвосты фраз («прозрачное закаленное стекло. Снизу матовое.» → ложное
 * «НАРУШЕНИЕ»). Код берёт только таблицу характеристик (ГОСТ, сертификаты и упаковка вне таблицы
 * не сверяются), находит каждую позицию в договоре по наименованию и проверяет каждую строку
 * (см. {@link SpecLineCheck}). Модели остаются только строки, не найденные дословно; под каждой — участок договора,
 * где слов строки больше всего (см. {@link SpecFragment}).
 * <pre>
 * {"оп": "сверить_характеристики", "классы_требований": "документация|техническое_задание",
 *  "класс_договора": "договор", "колонка_наименования": "наименован", "колонка_характеристик": "характеристик|описание",
 *  "колонка_параметра": "параметр|характеристик|показател", "колонка_значения": "^\s*(?:требуем\S*\s+)?значени"}
 * </pre>
 * Таблица «параметр — значение» (шапка «Наименование Оборудования | Требуемый параметр | Требуемое значение»)
 * распознаётся по колонкам параметра и значения: характеристика — «параметр: значение единица» (см. {@link SpecTableParser}).
 * <p>
 * Если в прогоне нет ни одного документа классов требований (по умолчанию «документация», «техническое_задание»), сверять
 * не с чем: отчёт {@link #NO_REQUIREMENTS} и {@code "требования_приложены": false} — иначе модель «сверяла» бы договор
 * с требованиями, извлечёнными из него самого (комплект из протокола и договора).
 */
final class SpecCheckOps {

    /** Начало строки отчёта: в прогоне нет документов с требованиями (документации, ТЗ). */
    static final String NO_REQUIREMENTS = "ТРЕБОВАНИЯ НЕ ПРИЛОЖЕНЫ";
    /** Участок позиции в договоре не длиннее (нормализованных символов). */
    static final int MAX_BLOCK = 6000;
    /** Наименование позиции короче (нормализованных символов) не режет договор на участки: «Стол» есть в «Столешнице». */
    private static final int MIN_NAME_FOR_SPLIT = 8;
    private static final int SNIPPET = 500;
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;

    private SpecCheckOps() {
    }

    /**
     * Сверка характеристик по документам прогона.
     *
     * @param op   параметры операции
     * @param docs документы прогона с классами
     * @return отчёт: сводка, строки без дословного совпадения с текстом позиции в договоре, итоговый JSON; без документов
     *         классов требований — {@link #NO_REQUIREMENTS}
     */
    static String check(Map<String, Object> op, Collection<ScenarioRunDoc> docs) {
        Pattern reqClass = SafeRegex.compile("^(?:" + op.getOrDefault("классы_требований", "документация|техническое_задание") + ")$", FLAGS, "классы_требований");
        Pattern contractClass = SafeRegex.compile("^(?:" + op.getOrDefault("класс_договора", "договор") + ")$", FLAGS, "класс_договора");
        Columns columns = columns(op);
        List<SpecPosition> positions = new ArrayList<>();
        List<ScenarioRunDoc> contracts = new ArrayList<>();
        boolean requirementsAttached = false;
        for (ScenarioRunDoc doc : docs) {
            if (matches(reqClass, doc)) {
                requirementsAttached = true;
                positions.addAll(SpecTableParser.parse(doc.getText(), doc.getFilename(), columns));
            } else if (matches(contractClass, doc)) {
                contracts.add(doc);
            }
        }
        StringBuilder sb = new StringBuilder("СВЕРКА ХАРАКТЕРИСТИК (код)\n");
        if (!requirementsAttached) {
            return sb.append(NO_REQUIREMENTS).append(" — характеристики не сверяются\n")
                    .append("{\"таблица_найдена\": false, \"требования_приложены\": false, \"не_найдено\": 0, \"порог_нарушен\": 0}").toString();
        }
        if (positions.isEmpty() || contracts.isEmpty()) {
            return sb.append(positions.isEmpty() ? "ТАБЛИЦА ХАРАКТЕРИСТИК НЕ НАЙДЕНА в документации и ТЗ — характеристики сверяет модель по извлечённым требованиям\n"
                    : "ДОГОВОР НЕ ПРИЛОЖЕН — характеристики не сверяются\n")
                    .append("{\"таблица_найдена\": ").append(!positions.isEmpty()).append(", \"не_найдено\": 0, \"порог_нарушен\": 0}").toString();
        }
        sb.append("Требования: ").append(sources(positions)).append(" — позиций ").append(positions.size())
                .append(", характеристик ").append(positions.stream().mapToInt(p -> p.lines().size()).sum()).append('\n');
        for (ScenarioRunDoc contract : contracts) {
            checkContract(sb, positions, contract);
        }
        return sb.toString();
    }

    /**
     * Шаблоны заголовков колонок таблицы требований из параметров операции (по умолчанию — типовые шапки).
     *
     * @param op параметры операции
     * @return шаблоны колонок наименования, характеристик, параметра и значения
     */
    private static Columns columns(Map<String, Object> op) {
        return new Columns(column(op, "колонка_наименования", "наименован"), column(op, "колонка_характеристик", "характеристик|описание"),
                column(op, "колонка_параметра", SpecTableParser.PARAM_COLUMN), column(op, "колонка_значения", SpecTableParser.VALUE_COLUMN));
    }

    private static Pattern column(Map<String, Object> op, String key, String defaultRegex) {
        return SafeRegex.compile(String.valueOf(op.getOrDefault(key, defaultRegex)), FLAGS, key);
    }

    private static boolean matches(Pattern cls, ScenarioRunDoc doc) {
        return !doc.isWorkNote() && doc.getDocClass() != null && SafeRegex.matches(cls, doc.getDocClass().strip());
    }

    private static String sources(List<SpecPosition> positions) {
        return positions.stream().map(p -> "«" + p.source() + "»").distinct().reduce((a, b) -> a + ", " + b).orElse("");
    }

    private static void checkContract(StringBuilder sb, List<SpecPosition> positions, ScenarioRunDoc contract) {
        NormalizedText text = NormalizedText.of(contract.getText());
        Map<Status, Integer> counts = new EnumMap<>(Status.class);
        StringBuilder issues = new StringBuilder();
        List<String> unlocated = new ArrayList<>();
        for (SpecPosition position : positions) {
            List<Block> blocks = SpecBlocks.of(text, position, positions, MIN_NAME_FOR_SPLIT, MAX_BLOCK);
            if (blocks.isEmpty()) {
                unlocated.add("«" + position.name() + "»");
                blocks = List.of(new Block(0, text.norm().length()));
            }
            checkPosition(issues, counts, position, text, blocks);
        }
        sb.append("Договор «").append(contract.getFilename()).append("»: совпали дословно ").append(count(counts, Status.EXACT))
                .append(", совпали с переносами строк ").append(count(counts, Status.GAPPED))
                .append(", порог выполнен ").append(count(counts, Status.THRESHOLD_OK))
                .append(", порог нарушен ").append(count(counts, Status.THRESHOLD_FAIL))
                .append(", не найдены ").append(count(counts, Status.MISSING)).append('\n');
        if (!unlocated.isEmpty()) {
            sb.append("ПОЗИЦИИ НЕ НАЙДЕНЫ В ДОГОВОРЕ ПО НАИМЕНОВАНИЮ (характеристики искались по всему договору): ")
                    .append(String.join("; ", unlocated)).append('\n');
        }
        sb.append(issues.length() == 0 ? "Все характеристики найдены в договоре.\n" : issues.toString());
        sb.append("{\"договор\": \"").append(contract.getFilename().replace("\"", "'")).append("\", \"таблица_найдена\": true, \"не_найдено\": ")
                .append(count(counts, Status.MISSING)).append(", \"порог_нарушен\": ").append(count(counts, Status.THRESHOLD_FAIL))
                .append(", \"позиций_не_найдено\": ").append(unlocated.size()).append("}\n");
    }

    private static void checkPosition(StringBuilder issues, Map<Status, Integer> counts, SpecPosition position, NormalizedText text, List<Block> blocks) {
        boolean startShown = false;
        for (String line : position.lines()) {
            LineResult result = SpecLineCheck.check(line, text, blocks);
            counts.merge(result.status(), 1, Integer::sum);
            if (result.status() != Status.MISSING && result.status() != Status.THRESHOLD_FAIL) {
                continue;
            }
            String label = result.status() == Status.MISSING ? "НЕ НАЙДЕНО ДОСЛОВНО" : "ПОРОГ НАРУШЕН";
            issues.append("- ").append(label).append(" | позиция ").append(position.number()).append(" «").append(position.name())
                    .append("» | «").append(line).append("» | ").append(result.detail()).append('\n');
            if (result.status() == Status.MISSING) {
                startShown = appendContractText(issues, line, text, blocks, startShown);
            }
        }
    }

    /**
     * Текст договора под строкой «НЕ НАЙДЕНО ДОСЛОВНО»: участок, где слов строки больше всего (см. {@link SpecFragment}).
     * Если слов строки в позиции нет — начало текста позиции, один раз на позицию. У строки «ПОРОГ НАРУШЕН» значение из
     * договора уже в пояснении, текст позиции не выводится.
     *
     * @param issues     отчёт о строках
     * @param line       строка характеристики
     * @param text       нормализованный текст договора
     * @param blocks     участки позиции в договоре
     * @param startShown начало текста позиции уже выведено
     * @return выведено ли начало текста позиции
     */
    private static boolean appendContractText(StringBuilder issues, String line, NormalizedText text, List<Block> blocks, boolean startShown) {
        Block fragment = SpecFragment.of(line, text, blocks);
        if (fragment == null && startShown) {
            return true;
        }
        Block shown = fragment != null ? fragment : blocks.stream().max((a, b) -> Integer.compare(a.to() - a.from(), b.to() - b.from())).orElse(blocks.get(0));
        boolean midPosition = blocks.stream().noneMatch(b -> b.from() == shown.from());
        issues.append("  текст позиции в договоре: «").append(midPosition ? "…" : "").append(text.snippet(shown.from(), shown.to(), SNIPPET)).append("»\n");
        return startShown || fragment == null;
    }

    private static int count(Map<Status, Integer> counts, Status status) {
        return counts.getOrDefault(status, 0);
    }
}
