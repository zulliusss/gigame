package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.KBService;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.InMemoryFilePart;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Дополнительные возможности output-узла, включаемые через его {@code rules}:
 * <ul>
 *   <li>{@code "накапливать": true} — нарастающий итог: к строкам текущего
 *   прогона дописываются строки того же output-узла из ПРЕДЫДУЩЕГО прогона
 *   сценария (партия за партией: обработали первые документы, догрузили
 *   следующие — форма содержит все строки);</li>
 *   <li>{@code "в_базу_знаний": "<uuid БЗ>"} — реестр: результат узла
 *   сохраняется текстовым документом в базу знаний, где накапливается
 *   реестр обработанных заявок для кросс-проверок через RAG.</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScenarioOutputSupportService {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private final ScenarioRunRepository scenarioRunRepository;
    private final ScenarioRunStepRepository scenarioRunStepRepository;
    private final ScenarioRepository scenarioRepository;
    private final KBService kbService;

    /**
     * Нарастающий итог: если в rules узла включено {@code "накапливать"},
     * строки этого же узла из предыдущего прогона сценария дописываются
     * ПЕРЕД строками текущего результата (новое — ниже ранее обработанного).
     * Любая проблема (нет прошлых прогонов, не распарсились строки) — результат
     * возвращается без изменений.
     *
     * @param run    текущий прогон
     * @param node   output-узел
     * @param result результат узла (текст с JSON-массивом строк)
     * @return слитый JSON-массив строк либо исходный результат
     */
    public String accumulateIfConfigured(ScenarioRun run, ScenarioRunNode node, String result) {
        Map<String, Object> rules = parseRules(node.getRules());
        if (!Boolean.parseBoolean(String.valueOf(rules.get("накапливать")))) {
            return result;
        }
        try {
            List<Map<String, Object>> current = parseRows(result);
            if (current == null) {
                return result;
            }
            List<Map<String, Object>> previous = previousRows(run, node);
            if (previous.isEmpty()) {
                return result;
            }
            List<Map<String, Object>> merged = new ArrayList<>(previous);
            merged.addAll(current);
            log.info("Нарастающий итог узла {}: {} строк прошлых прогонов + {} новых",
                    node.getId(), previous.size(), current.size());
            return objectMapper.writeValueAsString(merged);
        } catch (Exception e) {
            log.warn("Нарастающий итог узла {} не собран ({}) — используется текущий результат",
                    node.getId(), e.getMessage());
            return result;
        }
    }

    /**
     * Реестр: если в rules узла задан {@code "в_базу_знаний"}, результат
     * сохраняется текстовым документом в указанную базу знаний. Ошибка
     * сохранения НЕ роняет прогон (реестр вторичен) — только предупреждение
     * в лог.
     *
     * @param run    текущий прогон
     * @param node   output-узел
     * @param result результат узла
     */
    public void saveToKnowledgeBaseIfConfigured(ScenarioRun run, ScenarioRunNode node, String result) {
        Map<String, Object> rules = parseRules(node.getRules());
        Object kbIdRaw = rules.get("в_базу_знаний");
        if (kbIdRaw == null || String.valueOf(kbIdRaw).isBlank()) {
            return;
        }
        try {
            UUID kbId = UUID.fromString(String.valueOf(kbIdRaw).strip());
            String userId = scenarioRepository.findById(run.getScenarioId())
                    .map(Scenario::getUserId)
                    .orElse(null);
            String runShort = run.getId().toString().substring(0, 8);
            String filename = "registry-" + runShort + ".txt";
            String content = "Реестр результатов прогона " + run.getId()
                    + " сценария " + run.getScenarioId() + "\n\n" + result;
            kbService.addDocumentToKB(userId, kbId,
                    new InMemoryFilePart(filename, content.getBytes(StandardCharsets.UTF_8)));
            log.info("Результат узла {} прогона {} сохранён в базу знаний {} ({})",
                    node.getId(), runShort, kbId, filename);
        } catch (Exception e) {
            log.warn("Не удалось сохранить результат узла {} в базу знаний ({}) — прогон продолжается",
                    node.getId(), e.getMessage());
        }
    }

    /** Строки этого же узла из последнего прогона сценария, где узел завершился успешно. */
    private List<Map<String, Object>> previousRows(ScenarioRun run, ScenarioRunNode node) {
        List<ScenarioRun> runs = scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(run.getScenarioId());
        for (ScenarioRun previous : runs) {
            if (previous.getId().equals(run.getId())) {
                continue;
            }
            List<ScenarioRunStep> steps = scenarioRunStepRepository
                    .findByRunIdOrderByStartedAtAsc(previous.getId());
            for (ScenarioRunStep step : steps) {
                if (!node.getId().equals(step.getNodeId()) || step.getOutputData() == null) {
                    continue;
                }
                Object prevResult = step.getOutputData().get("result");
                List<Map<String, Object>> rows = parseRows(String.valueOf(prevResult));
                if (rows != null && !rows.isEmpty()) {
                    // прогон найден (даже если контроль ниже по графу дал FAILED —
                    // форма этого узла была успешно построена)
                    return rows;
                }
            }
        }
        return List.of();
    }

    /** @return строки JSON-массива из текста результата либо {@code null}, если массива нет */
    private List<Map<String, Object>> parseRows(String result) {
        try {
            String json = ScenarioResultToXlsx.extractJson(result);
            if (!json.trim().startsWith("[")) {
                return List.of();
            }
            return objectMapper.readValue(json, new TypeReference<>() {
            });
        } catch (Exception e) {
            return List.of();
        }
    }

    /** @return rules узла как карта; пустая карта при отсутствии или невалидном JSON */
    private Map<String, Object> parseRules(String rulesJson) {
        if (rulesJson == null || rulesJson.isBlank() || rulesJson.trim().startsWith("[")) {
            return Map.of();
        }
        try {
            return objectMapper.readValue(rulesJson, new TypeReference<>() {
            });
        } catch (Exception e) {
            return Map.of();
        }
    }
}
