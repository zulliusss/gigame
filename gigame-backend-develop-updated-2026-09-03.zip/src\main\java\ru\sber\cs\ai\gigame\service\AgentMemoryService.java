package ru.sber.cs.ai.gigame.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.dto.agent.AgentLessonResponseDto;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.AgentLesson;
import ru.sber.cs.ai.gigame.model.AgentPlan;
import ru.sber.cs.ai.gigame.model.AgentQuestion;
import ru.sber.cs.ai.gigame.repository.AgentLessonRepository;
import ru.sber.cs.ai.gigame.repository.AgentPlanRepository;
import ru.sber.cs.ai.gigame.repository.AgentQuestionRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.scenario.executor.AgentEvidence;
import ru.sber.cs.ai.gigame.utils.UserUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Память агента (саморазвитие): уроки, планы, вопросы пользователю.
 * <p>
 * Уроки — правила, выученные из прошлых прогонов; частные (сценария)
 * применяются сразу, общие — после одобрения (защита от отравления памяти).
 * Планы — проверенные чек-листы, переиспользуемые для повторных заданий.
 * Вопросы — асинхронный human-in-the-loop: агент не останавливает прогон,
 * ответ пользователя превращается в урок. Механизмы универсальны — никакой
 * привязки к предметной области сценариев.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AgentMemoryService {

    /** Максимум уроков каждой области, подмешиваемых в промпт агента. */
    static final int LESSONS_LIMIT = 10;
    /** Порог рефлексии-сжатия: больше уроков — предлагается сжатие. */
    static final int COMPRESS_THRESHOLD = 15;
    /** Начала банальных «уроков», которые ничему не учат, — отсекаются кодом. */
    private static final List<String> GENERIC_LESSON_STARTS = List.of(
            "проверяй", "проверьте", "следите", "следи", "обращайте", "обращай",
            "убедитесь", "убедись", "уточняйте", "уточняй", "обязательно",
            "внимательно", "не забывайте", "не забудьте", "всегда", "тщательно");

    private final AgentLessonRepository lessonRepository;
    private final AgentPlanRepository planRepository;
    private final AgentQuestionRepository questionRepository;
    private final GigaChatClient gigaChatClient;
    private final ScenarioRepository scenarioRepository;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Память сценария — часть сценария: изменять её может только автор
     * (читать — все, у кого есть доступ к сценарию).
     *
     * @param userId     пользователь
     * @param scenarioId сценарий (null — не сценарная память, проверка не нужна)
     */
    private void checkScenarioAuthor(String userId, UUID scenarioId) {
        if (scenarioId == null) {
            return;
        }
        scenarioRepository.findById(scenarioId).ifPresent(
                scenario -> UserUtils.checkUserId(userId, scenario.getUserId()));
    }

    /** Системный урок поставляется релизом — менять его нельзя никому. */
    private static void checkNotSystem(AgentLesson lesson) {
        if (AgentLesson.SOURCE_SYSTEM.equals(lesson.getSource())) {
            throw new IllegalArgumentException(
                    "Системный урок поставляется релизом и не редактируется");
        }
    }

    // -------------------------------------------------------------------
    // Уроки
    // -------------------------------------------------------------------

    /**
     * Уроки для промпта агентского узла — три слоя:
     * <ol>
     *     <li>СИСТЕМНЫЕ — поставляются релизом, действуют на всех;</li>
     *     <li>ЛИЧНЫЕ ОБЩИЕ запускающего — его кросс-сценарные правила,
     *     действуют только на его запуски;</li>
     *     <li>СЦЕНАРНЫЕ (одобренные) — часть сценария, едут с ним к любому
     *     запускающему.</li>
     * </ol>
     *
     * @param scenarioId   сценарий прогона (null — без сценарного слоя)
     * @param runnerUserId запускающий пользователь (null — без личного слоя)
     * @return тексты уроков
     */
    public List<String> lessonsForScenario(UUID scenarioId, String runnerUserId) {
        List<String> result = new ArrayList<>();
        lessonRepository.findByScenarioIdIsNullAndSourceOrderByCreatedAtDesc(
                        AgentLesson.SOURCE_SYSTEM).stream()
                .limit(LESSONS_LIMIT)
                .forEach(l -> result.add(l.getLesson()));
        if (runnerUserId != null && !runnerUserId.isBlank()) {
            lessonRepository.findByScenarioIdIsNullAndUserIdAndSourceNotOrderByCreatedAtDesc(
                            UserUtils.getUserId(runnerUserId), AgentLesson.SOURCE_SYSTEM).stream()
                    .limit(LESSONS_LIMIT)
                    .forEach(l -> result.add(l.getLesson()));
        }
        if (scenarioId != null) {
            // неодобренные кандидаты (авто-уроки из прогонов) не применяются
            lessonRepository.findByScenarioIdOrderByCreatedAtDesc(scenarioId).stream()
                    .filter(l -> Boolean.TRUE.equals(l.getApproved()))
                    .limit(LESSONS_LIMIT)
                    .forEach(l -> result.add(l.getLesson()));
        }
        return result;
    }

    /**
     * Все уроки для страницы «Память агента».
     *
     * @param scenarioId фильтр по сценарию; null — общие уроки
     * @return уроки
     */
    public List<AgentLessonResponseDto> getLessons(UUID scenarioId) {
        var entities = scenarioId != null
                ? lessonRepository.findByScenarioIdOrderByCreatedAtDesc(scenarioId)
                : lessonRepository.findByScenarioIdIsNullOrderByCreatedAtDesc();
        return entities.stream()
                .map(AgentLessonResponseDto::from)
                .collect(Collectors.toList());
    }

    /**
     * Добавляет урок. Частный урок применяется сразу; общий — после одобрения.
     *
     * @param userId     автор
     * @param scenarioId сценарий; null — общий урок
     * @param lesson     текст правила
     * @param source     источник (user/reviser/auto)
     * @return сохранённый урок
     */
    @Transactional
    public AgentLessonResponseDto addLesson(String userId, UUID scenarioId, String lesson, String source) {
        if (lesson == null || lesson.isBlank()) {
            throw new IllegalArgumentException("Текст урока обязателен");
        }
        checkScenarioAuthor(userId, scenarioId);
        AgentLesson entity = new AgentLesson();
        entity.setUserId(UserUtils.getUserId(userId));
        entity.setScenarioId(scenarioId);
        entity.setLesson(lesson.strip());
        entity.setSource(source == null ? AgentLesson.SOURCE_USER : source);
        // личный общий урок действует только на запуски владельца — активен сразу;
        // сценарный от автора — тоже; неодобренными остаются лишь авто-кандидаты
        entity.setApproved(true);
        return AgentLessonResponseDto.from(lessonRepository.save(entity));
    }

    /** Обновляет текст урока (сценарные — только автор сценария). */
    @Transactional
    public AgentLessonResponseDto updateLesson(String userId, UUID id, String lesson) {
        AgentLesson entity = lessonRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Урок не найден: " + id));
        checkNotSystem(entity);
        checkScenarioAuthor(userId, entity.getScenarioId());
        entity.setLesson(lesson.strip());
        return AgentLessonResponseDto.from(lessonRepository.save(entity));
    }

    /** Удаляет урок (сценарные — только автор сценария). */
    @Transactional
    public void deleteLesson(String userId, UUID id) {
        lessonRepository.findById(id).ifPresent(entity -> {
            checkNotSystem(entity);
            checkScenarioAuthor(userId, entity.getScenarioId());
            lessonRepository.delete(entity);
        });
    }

    /** Одобряет урок к применению (сценарные — только автор сценария). */
    @Transactional
    public AgentLessonResponseDto approveLesson(String userId, UUID id) {
        AgentLesson entity = lessonRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Урок не найден: " + id));
        checkScenarioAuthor(userId, entity.getScenarioId());
        entity.setApproved(true);
        return AgentLessonResponseDto.from(lessonRepository.save(entity));
    }

    /**
     * Рефлексия-сжатие: уроки сценария дистиллируются LLM-вызовом в меньший
     * набор общих правил (не теряя конкретных значений и констант); старые
     * уроки заменяются сжатыми с источником auto. Явное действие пользователя
     * со страницы памяти — без тихой фоновой магии.
     *
     * @param userId     инициатор
     * @param scenarioId сценарий
     * @return новые (сжатые) уроки
     */
    @Transactional
    public List<AgentLessonResponseDto> compressLessons(String userId, UUID scenarioId) {
        checkScenarioAuthor(userId, scenarioId);
        List<AgentLesson> old = lessonRepository.findByScenarioIdOrderByCreatedAtDesc(scenarioId);
        if (old.size() < 3) {
            throw new IllegalArgumentException("Слишком мало уроков для сжатия: " + old.size());
        }
        StringBuilder sb = new StringBuilder();
        for (AgentLesson lesson : old) {
            sb.append("- ").append(lesson.getLesson()).append('\n');
        }
        String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                "Ниже — правила, выученные ИИ-агентом на прогонах одного сценария. Сожми их "
                        + "в НЕ БОЛЕЕ 7 правил: объединяй дублирующие, обобщай похожие, но НЕ теряй "
                        + "конкретные значения, названия и константы. Верни ТОЛЬКО JSON-массив строк.\n\n"
                        + sb)), null, null);
        List<String> compressed = AgentEvidence.parsePlan(raw);
        if (compressed == null || compressed.isEmpty()) {
            throw new IllegalStateException("Сжатие не удалось: ответ модели не распознан");
        }
        lessonRepository.deleteAll(old);
        List<AgentLesson> entities = new ArrayList<>();
        for (String text : compressed) {
            AgentLesson entity = new AgentLesson();
            entity.setUserId(UserUtils.getUserId(userId));
            entity.setScenarioId(scenarioId);
            entity.setLesson(text);
            entity.setSource(AgentLesson.SOURCE_AUTO);
            entity.setApproved(true);
            entities.add(lessonRepository.save(entity));
        }
        log.info("Уроки сценария {} сжаты: {} -> {}", scenarioId, old.size(), entities.size());
        return entities.stream()
                .map(AgentLessonResponseDto::from)
                .collect(Collectors.toList());
    }

    /**
     * Авто-уроки из прогона (источник reviser): LLM выделяет из выходов
     * узлов прогона (замечания критика, правки ревизора, расхождения)
     * кандидатов-уроков. Кандидаты сохраняются НЕОДОБРЕННЫМИ — в промпт
     * агента попадут только после одобрения на странице памяти
     * (защита от самоотравления).
     *
     * @param userId      инициатор
     * @param scenarioId  сценарий прогона
     * @param runOutputs  выходы узлов прогона (метка — текст)
     * @return сохранённые кандидаты-уроки
     */
    @Transactional
    public List<AgentLessonResponseDto> extractLessonsFromRun(String userId, UUID scenarioId,
                                                   Map<String, String> runOutputs) {
        StringBuilder sb = new StringBuilder();
        runOutputs.forEach((label, text) -> sb.append("=== ").append(label).append(" ===\n")
                .append(text.length() > 6000 ? text.substring(0, 6000) + "…" : text)
                .append("\n\n"));
        String raw = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content",
                "Ниже — результаты узлов прогона сценария (включая замечания проверяющих и "
                        + "правки). Выдели НЕ БОЛЕЕ 5 ПЕРЕНОСИМЫХ правил для будущих прогонов — "
                        + "только из ФАКТИЧЕСКИ найденных ошибок и исправлений. Правило обязано "
                        + "быть конкретным: назвать термин/поле/формулировку из документов и "
                        + "действие с ним — формат «X — это Y», «X ищи в Z», «не бери A, бери B». "
                        + "Пример формата из ДРУГОЙ предметной области (его НЕ копируй): "
                        + "«Гарантийный срок ищи в разделе Гарантия договора, а не в "
                        + "спецификации». ЗАПРЕЩЕНЫ общие призывы («проверяйте», "
                        + "«обращайте внимание», «следите за корректностью») — лучше пустой "
                        + "массив, чем банальность. Если ошибок не было — верни []. "
                        + "Верни ТОЛЬКО JSON-массив строк.\n\n" + sb)), null, null);
        List<String> candidates = AgentEvidence.parsePlan(raw);
        List<AgentLesson> entities = new ArrayList<>();
        if (candidates == null) {
            return entities.stream()
                    .map(AgentLessonResponseDto::from)
                    .collect(Collectors.toList());
        }
        List<String> known = knownLessonTexts(scenarioId);
        int dropped = 0;
        for (String text : candidates) {
            boolean duplicate = known.stream().anyMatch(k -> similarLesson(text, k));
            if (!specificLesson(text) || duplicate) {
                dropped++;
                continue;
            }
            AgentLesson lesson = new AgentLesson();
            lesson.setUserId(UserUtils.getUserId(userId));
            lesson.setScenarioId(scenarioId);
            lesson.setLesson(text);
            lesson.setSource(AgentLesson.SOURCE_REVISER);
            lesson.setApproved(false);
            entities.add(lessonRepository.save(lesson));
        }
        log.info("Из прогона извлечено кандидатов-уроков: {} (отсеяно: {})", entities.size(), dropped);
        return entities.stream()
                .map(AgentLessonResponseDto::from)
                .collect(Collectors.toList());
    }

    /**
     * Кандидат-урок полезен, только если конкретен: не начинается с общего
     * призыва и содержит фактуру — термин в кавычках, число или соответствие
     * («X — Y», «X = Y»). Банальности вида «проверяйте суммы» лишь шумят в
     * системном промпте агента (наблюдалось: все 5 кандидатов прогона —
     * общие призывы без единого конкретного правила).
     */
    static boolean specificLesson(String text) {
        String l = text == null ? "" : text.strip().toLowerCase(Locale.ROOT);
        if (l.isBlank() || GENERIC_LESSON_STARTS.stream().anyMatch(l::startsWith)) {
            return false;
        }
        return l.matches("(?s).*[«\"\\d=—].*");
    }

    /**
     * Активные уроки для дедупликации кандидатов: системные и сценарные —
     * кандидат-перефраз существующего правила бесполезен (наблюдалось:
     * извлечение вернуло системный урок №1 другими словами).
     */
    private List<String> knownLessonTexts(UUID scenarioId) {
        try {
            return lessonsForScenario(scenarioId, null);
        } catch (Exception e) {
            log.warn("Уроки для дедупликации недоступны: {}", e.getMessage());
            return List.of();
        }
    }

    /**
     * Дубликат-перефраз: значимые слова кандидата в основном совпадают со
     * словами существующего урока (порог 60% от меньшего набора).
     */
    static boolean similarLesson(String a, String b) {
        Set<String> wa = lessonWords(a);
        Set<String> wb = lessonWords(b);
        if (wa.isEmpty() || wb.isEmpty()) {
            return false;
        }
        long common = wa.stream().filter(wb::contains).count();
        return common >= Math.min(wa.size(), wb.size()) * 0.6;
    }

    private static Set<String> lessonWords(String s) {
        return Arrays.stream(normalizedLesson(s).split("[^а-яёa-z0-9]+"))
                .filter(w -> w.length() >= 3)
                .collect(Collectors.toSet());
    }

    private static String normalizedLesson(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT)
                .replace('ё', 'е').replaceAll("[\\s\\u00A0]+", " ").strip();
    }

    // -------------------------------------------------------------------
    // Планы
    // -------------------------------------------------------------------

    /**
     * Ищет проверенный план для задания (по хэшу нормализованного текста).
     *
     * @param task задание агенту
     * @return пункты плана или {@code null}
     */
    public List<String> findPlan(String task) {
        return planRepository.findFirstByTaskHashOrderByUsesDesc(taskHash(task))
                .map(p -> {
                    p.setUses(p.getUses() + 1);
                    planRepository.save(p);
                    return AgentEvidence.parsePlan(p.getPlan());
                })
                .orElse(null);
    }

    /**
     * Сохраняет план успешно завершённого агентского прогона (или обновляет
     * существующий для того же задания).
     *
     * @param scenarioId сценарий
     * @param task       задание
     * @param plan       пункты плана
     */
    @Transactional
    public void savePlan(UUID scenarioId, String task, List<String> plan) {
        try {
            String hash = taskHash(task);
            AgentPlan entity = planRepository.findFirstByTaskHashOrderByUsesDesc(hash)
                    .orElseGet(AgentPlan::new);
            entity.setScenarioId(scenarioId);
            entity.setTaskHash(hash);
            entity.setTaskPreview(task.length() > 300 ? task.substring(0, 300) + "…" : task);
            entity.setPlan(objectMapper.writeValueAsString(plan));
            if (entity.getUses() == null) {
                entity.setUses(0);
            }
            planRepository.save(entity);
        } catch (Exception e) {
            log.warn("План не сохранён в память: {}", e.getMessage());
        }
    }

    /** Планы сценария для страницы памяти. */
    public List<AgentPlan> getPlans(UUID scenarioId) {
        return planRepository.findByScenarioIdOrderByUpdatedAtDesc(scenarioId);
    }

    /** Удаляет план из памяти (только автор сценария). */
    @Transactional
    public void deletePlan(String userId, UUID id) {
        planRepository.findById(id).ifPresent(plan -> {
            checkScenarioAuthor(userId, plan.getScenarioId());
            planRepository.delete(plan);
        });
    }

    /** SHA-256 нормализованного задания (пробелы схлопнуты, нижний регистр). */
    static String taskHash(String task) {
        try {
            String normalized = task.replaceAll("\\s+", " ").strip().toLowerCase(Locale.ROOT);
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(normalized.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 недоступен", e);
        }
    }

    // -------------------------------------------------------------------
    // Вопросы (асинхронный human-in-the-loop)
    // -------------------------------------------------------------------

    /**
     * Сохраняет вопросы агента к пользователю по итогам прогона узла.
     *
     * @param runId      прогон
     * @param scenarioId сценарий
     * @param nodeLabel  метка узла
     * @param questions  тексты вопросов
     */
    @Transactional
    public void saveQuestions(UUID runId, UUID scenarioId, String nodeLabel, List<String> questions) {
        for (String question : questions) {
            AgentQuestion entity = new AgentQuestion();
            entity.setRunId(runId);
            entity.setScenarioId(scenarioId);
            entity.setNodeLabel(nodeLabel);
            entity.setQuestion(question);
            questionRepository.save(entity);
        }
    }

    /** Вопросы прогона (для карточки прогона в UI). */
    public List<AgentQuestion> getQuestionsByRun(UUID runId) {
        return questionRepository.findByRunIdOrderByCreatedAtAsc(runId);
    }

    /**
     * Ответ пользователя на вопрос агента: сохраняется и превращается в
     * частный урок сценария — при следующем прогоне агент его учтёт.
     *
     * @param userId отвечающий
     * @param id     вопрос
     * @param answer текст ответа
     * @return обновлённый вопрос
     */
    @Transactional
    public AgentQuestion answerQuestion(String userId, UUID id, String answer) {
        if (answer == null || answer.isBlank()) {
            throw new IllegalArgumentException("Текст ответа обязателен");
        }
        AgentQuestion question = questionRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Вопрос не найден: " + id));
        // ответ рождает урок сценария — право автора
        checkScenarioAuthor(userId, question.getScenarioId());
        question.setAnswer(answer.strip());
        question.setAnsweredAt(OffsetDateTime.now());
        questionRepository.save(question);
        addLesson(userId, question.getScenarioId(),
                "На вопрос «" + question.getQuestion() + "» пользователь уточнил: " + answer.strip(),
                AgentLesson.SOURCE_USER);
        return question;
    }
}
