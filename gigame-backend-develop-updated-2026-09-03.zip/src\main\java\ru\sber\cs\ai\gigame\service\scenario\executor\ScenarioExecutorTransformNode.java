package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;

/**
 * Узел «Трансформация»: детерминированные операции над текстом без LLM.
 * <p>
 * Вход — тексты документов узла (если подключены) либо результаты предыдущих узлов.
 * Конфигурация — в поле rules узла (настраивается формой в UI):
 * <pre>
 * {"операции": [
 *   {"оп": "извлечь_regex", "шаблон": "№\\s*(\\d+)", "группа": 1, "все": true, "разделитель": "\n"},
 *   {"оп": "заменить", "найти": "...", "на": "...", "regex": false},
 *   {"оп": "оставить_строки", "шаблон": "..."},
 *   {"оп": "удалить_строки", "шаблон": "..."},
 *   {"оп": "json_поле", "путь": "участники[0].название"},
 *   {"оп": "слить_json_массивы", "дедуп_по": ["тип", "цитата"]},
 *   {"оп": "проверить_цитаты"},
 *   {"оп": "взять_символы", "от": 0, "до": 1000},
 *   {"оп": "первые_строки", "n": 20},
 *   {"оп": "последние_строки", "n": 20},
 *   {"оп": "уникальные_строки"}
 * ]}
 * </pre>
 * Операции применяются по цепочке сверху вниз.
 */
public class ScenarioExecutorTransformNode extends AbstractScenarioExecutor {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    protected ScenarioExecutorTransformNode(ScenarioRunNode node) {
        super(node);
    }

    @Override
    public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> sink) {
        String text = inputText();
        List<Map<String, Object>> operations = parseOperations();
        StringBuilder logView = new StringBuilder("[трансформация без LLM]\n");
        for (Map<String, Object> op : operations) {
            String name = String.valueOf(op.get("оп"));
            text = apply(name, op, text);
            logView.append("- ").append(name).append(" → ").append(text.length()).append(" символов\n");
        }
        prompt = logView.toString();
        node.getOutput().add(text);
        var input = prepareNextInput();
        for (var next : node.getChildNodeList()) {
            next.setSkip(false);
            next.getInput().addAll(input);
        }
        return text;
    }

    private String inputText() {
        if (!node.getDocList().isEmpty()) {
            return node.getDocList().stream()
                    .map(id -> node.getGraph().getDocMap().get(id).getText())
                    .collect(Collectors.joining("\n\n"));
        }
        return String.join("\n\n", node.getInput());
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseOperations() {
        Map<String, Object> config = parseConfig(node.getRules());
        Object ops = config.get("операции");
        if (!(ops instanceof List<?> list) || list.isEmpty()) {
            throw new ScenarioException("Узел «Трансформация»: список операций пуст");
        }
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object o : list) {
            if (o instanceof Map) {
                result.add((Map<String, Object>) o);
            }
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseConfig(Object raw) {
        try {
            if (raw instanceof Map) {
                return (Map<String, Object>) raw;
            }
            if (raw instanceof String s && !s.isBlank()) {
                Map<String, Object> config = MAPPER.readValue(s, Map.class);
                if (config != null) {
                    return config;
                }
            }
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось разобрать конфигурацию: " + e.getMessage());
        }
        throw new ScenarioException("Узел «Трансформация»: не заданы операции (настройте узел в панели)");
    }

    private String apply(String name, Map<String, Object> op, String text) {
        try {
            return switch (name) {
                case "извлечь_regex" -> extractRegex(op, text);
                case "заменить" -> replaceOp(op, text);
                case "оставить_строки" -> filterLines(op, text, true);
                case "удалить_строки" -> filterLines(op, text, false);
                case "json_поле" -> jsonField(op, text);
                case "слить_json_массивы" -> mergeJsonArrays(op, text);
                case "проверить_цитаты" -> verifyCitations(op, text);
                case "сверить_суммы" -> compareAmounts(op);
                case "извлечь_из_документов" -> extractFromDocs(op);
                case "взять_символы" -> substringOp(op, text);
                case "первые_строки" -> headTail(op, text, true);
                case "последние_строки" -> headTail(op, text, false);
                case "уникальные_строки" -> uniqueLines(text);
                default -> throw new ScenarioException("Узел «Трансформация»: неизвестная операция «" + name + "»");
            };
        } catch (PatternSyntaxException e) {
            throw new ScenarioException("Узел «Трансформация», операция «" + name
                    + "»: некорректное регулярное выражение: " + e.getDescription());
        }
    }

    /**
     * Удаляет повторяющиеся строки, сохраняя порядок первых вхождений.
     * Пустые строки отбрасываются. Например, извлечённые regex-ом значения
     * ячеек (повторяющиеся на каждом уровне иерархии) сводятся к перечню
     * уникальных с сохранением привязки к маркерам разделов.
     */
    private String uniqueLines(String text) {
        Set<String> seen = new LinkedHashSet<>();
        for (String line : text.split("\n")) {
            String trimmed = line.strip();
            if (!trimmed.isEmpty()) {
                seen.add(trimmed);
            }
        }
        return String.join("\n", seen);
    }

    private String extractRegex(Map<String, Object> op, String text) {
        Pattern p = Pattern.compile(String.valueOf(op.get("шаблон")), Pattern.MULTILINE);
        int group = op.get("группа") == null ? 0 : Integer.parseInt(String.valueOf(op.get("группа")));
        boolean all = Boolean.parseBoolean(String.valueOf(op.getOrDefault("все", "true")));
        String sep = String.valueOf(op.getOrDefault("разделитель", "\n"));
        Matcher m = p.matcher(text);
        List<String> found = new ArrayList<>();
        while (m.find()) {
            found.add(m.group(Math.min(group, m.groupCount())));
            if (!all) {
                break;
            }
        }
        return String.join(sep, found);
    }

    private String replaceOp(Map<String, Object> op, String text) {
        String find = String.valueOf(op.get("найти"));
        String repl = String.valueOf(op.getOrDefault("на", ""));
        boolean regex = Boolean.parseBoolean(String.valueOf(op.getOrDefault("regex", "false")));
        return regex ? text.replaceAll(find, repl) : text.replace(find, repl);
    }

    private String filterLines(Map<String, Object> op, String text, boolean keep) {
        Pattern p = Pattern.compile(String.valueOf(op.get("шаблон")));
        return Arrays.stream(text.split("\n", -1))
                .filter(line -> p.matcher(line).find() == keep)
                .collect(Collectors.joining("\n"));
    }

    /**
     * Сливает все JSON-массивы объектов из входного текста в один массив.
     * <p>
     * Детерминированная замена LLM-слиянию: результаты нескольких групп/итераций
     * (каждая выдала свой JSON-массив) объединяются в порядке появления во входе.
     * Числа с десятичной запятой чинятся. Если ни одного массива не найдено —
     * ошибка узла. Необязательный параметр «дедуп_по» (список ключей) убирает
     * повторы: объекты с одинаковыми значениями перечисленных ключей (без учёта
     * регистра и краевых пробелов) схлопываются до первого вхождения — разные
     * группы документов часто выдают одну и ту же находку.
     */
    private String mergeJsonArrays(Map<String, Object> op, String text) {
        List<Object> merged = new ArrayList<>();
        int arrays = 0;
        int i = 0;
        while (i < text.length()) {
            int next = tryMergeArrayAt(text, i, merged);
            if (next > i) {
                arrays++;
                i = next;
            } else {
                i++;
            }
        }
        if (arrays == 0) {
            throw new ScenarioException("Узел «Трансформация», операция «слить_json_массивы»: "
                    + "во входе не найдено ни одного JSON-массива объектов");
        }
        return serializeMerged(dedupeByKeys(op, merged));
    }

    @SuppressWarnings("unchecked")
    private List<Object> dedupeByKeys(Map<String, Object> op, List<Object> merged) {
        if (!(op.get("дедуп_по") instanceof List<?> keys) || keys.isEmpty()) {
            return merged;
        }
        Set<String> seen = new LinkedHashSet<>();
        List<Object> result = new ArrayList<>();
        for (Object o : merged) {
            Map<String, Object> m = (Map<String, Object>) o;
            StringBuilder sig = new StringBuilder();
            for (Object k : keys) {
                Object v = m.get(String.valueOf(k));
                sig.append(v == null ? "" : String.valueOf(v).strip().toLowerCase())
                        .append('\u0001');
            }
            if (seen.add(sig.toString())) {
                result.add(o);
            }
        }
        return result;
    }

    /**
     * Пытается разобрать JSON-массив объектов в позиции {@code from}: объекты
     * добавляются в {@code merged}, возвращается позиция за массивом; если
     * пригодного массива в позиции нет — возвращается {@code from} (сдвиг
     * на один символ выполняет вызывающий цикл).
     */
    private int tryMergeArrayAt(String text, int from, List<Object> merged) {
        if (text.charAt(from) != '[') {
            return from;
        }
        int end = JsonCalcUtils.balancedEnd(text, from);
        if (end < 0) {
            return from;
        }
        try {
            List<?> arr = MAPPER.readValue(
                    JsonCalcUtils.sanitizeDecimalCommas(text.substring(from, end + 1)), List.class);
            // пустой массив — валидный вклад («находок нет»): без этого узел падал
            // на комплектах, где ни один документ не дал ни одной записи
            if (arr.isEmpty() || arr.stream().anyMatch(Map.class::isInstance)) {
                for (Object o : arr) {
                    if (o instanceof Map) {
                        merged.add(o);
                    }
                }
                return end + 1;
            }
        } catch (Exception ignored) {
            // не JSON-массив — ищем дальше
        }
        return from;
    }

    private String serializeMerged(List<Object> merged) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(merged);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать объединённый массив: "
                    + e.getMessage());
        }
    }

    /**
     * Дополняет каждый объект свода находок полями «документ» и «достоверность»:
     * поле «цитата» ищется в текстах всех документов прогона — точное вхождение
     * либо покрытие слов цитаты не ниже 0.8 в окне двойной длины (вставки в
     * тексте документа не мешают). Находки-констатации отсутствия («нет …»,
     * «отсутств…») получают достоверность «н/п (об отсутствии)» — им цитата
     * не полагается. Параметров у операции нет.
     */
    private String verifyCitations(Map<String, Object> op, String text) {
        int from = text.indexOf('[');
        int end = from < 0 ? -1 : JsonCalcUtils.balancedEnd(text, from);
        if (from < 0 || end < 0) {
            throw new ScenarioException("Узел «Трансформация», операция «проверить_цитаты»: "
                    + "во входе не найден JSON-массив находок");
        }
        List<?> arr;
        try {
            arr = MAPPER.readValue(JsonCalcUtils.sanitizeDecimalCommas(
                    text.substring(from, end + 1)), List.class);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация», операция «проверить_цитаты»: "
                    + "не удалось разобрать массив находок: " + e.getMessage());
        }
        List<DocIndex> docs = node.getGraph().getDocMap().values().stream()
                .map(d -> new DocIndex(d.getFilename(), normForSearch(d.getText())))
                .toList();
        List<Object> out = new ArrayList<>();
        for (Object o : arr) {
            if (o instanceof Map<?, ?> raw) {
                Map<String, Object> m = new LinkedHashMap<>();
                raw.forEach((k, v) -> m.put(String.valueOf(k), v));
                locateCitation(m, docs);
                out.add(m);
            }
        }
        return serializeMerged(out);
    }

    private void locateCitation(Map<String, Object> m, List<DocIndex> docs) {
        String cite = String.valueOf(m.getOrDefault("цитата", ""));
        String low = cite.strip().toLowerCase();
        if (low.startsWith("нет ") || low.startsWith("отсутств")
                || low.startsWith("не устано") || low.startsWith("не указан")) {
            m.put("достоверность", "н/п (об отсутствии)");
            m.put("документ", "—");
            return;
        }
        String c = normForSearch(cite);
        if (c.length() < 12) {
            m.put("достоверность", "цитата слишком коротка");
            m.put("документ", "—");
            return;
        }
        String[] cw = c.split(" ");
        String bestDoc = "—";
        double bestCov = 0;
        for (DocIndex d : docs) {
            if (d.norm.contains(c)) {
                m.put("достоверность", "точно");
                m.put("документ", d.name);
                return;
            }
            double cov = d.coverage(cw);
            if (cov > bestCov) {
                bestCov = cov;
                bestDoc = d.name;
            }
        }
        m.put("достоверность", bestCov >= 0.8 ? "нечётко" : "НЕ НАЙДЕНА");
        m.put("документ", bestCov >= 0.8 ? bestDoc : "—");
    }

    private static String normForSearch(String s) {
        return s == null ? "" : s.toLowerCase().replace('ё', 'е')
                .replaceAll("[^0-9a-zа-я]+", " ").strip();
    }

    /** Пословный индекс документа для быстрого поиска цитат вокруг якорного слова. */
    private static final class DocIndex {
        private final String name;
        private final String norm;
        private final String[] words;
        private final Map<String, List<Integer>> positions = new HashMap<>();

        DocIndex(String name, String norm) {
            this.name = name;
            this.norm = norm;
            this.words = norm.isEmpty() ? new String[0] : norm.split(" ");
            for (int i = 0; i < words.length; i++) {
                positions.computeIfAbsent(words[i], k -> new ArrayList<>()).add(i);
            }
        }

        /** Доля слов цитаты, идущих по порядку в окне вокруг самого длинного слова. */
        double coverage(String[] cw) {
            String anchor = "";
            for (String w : cw) {
                if (w.length() > anchor.length()) {
                    anchor = w;
                }
            }
            List<Integer> anchors = positions.get(anchor);
            if (anchors == null) {
                return 0;
            }
            int win = Math.max(cw.length * 2, cw.length + 6);
            double best = 0;
            int tried = 0;
            for (int pos : anchors) {
                if (tried++ > 200) {
                    break;
                }
                int start = Math.max(0, pos - cw.length);
                int stop = Math.min(words.length, start + win);
                best = Math.max(best, orderedMatches(cw, start, stop) / (double) cw.length);
                if (best >= 0.99) {
                    break;
                }
            }
            return best;
        }

        private int orderedMatches(String[] cw, int from, int to) {
            int width = to - from;
            int[] prev = new int[width + 1];
            int[] cur = new int[width + 1];
            for (String s : cw) {
                for (int j = 1; j <= width; j++) {
                    cur[j] = s.equals(words[from + j - 1])
                            ? prev[j - 1] + 1
                            : Math.max(prev[j], cur[j - 1]);
                }
                int[] t = prev;
                prev = cur;
                cur = t;
                Arrays.fill(cur, 0);
            }
            return prev[width];
        }
    }

    /**
     * Собирает по всем документам прогона упоминания сумм рядом с меткой
     * (по умолчанию НМЦ/НМЦД) и возвращает сводку для судьи: каждое значение и
     * документы, где оно встречено. Судья сам решает, какие значения обязаны
     * совпадать (итог в разных разделах), а какие различаются законно (лоты).
     * Параметры: «метка» (regex, по умолчанию «НМЦД?»), «окно» (максимум
     * символов между меткой и числом, по умолчанию 80).
     */
    private String compareAmounts(Map<String, Object> op) {
        String label = String.valueOf(op.getOrDefault("метка", "НМЦД?"));
        int window = op.get("окно") == null ? 80
                : Integer.parseInt(String.valueOf(op.get("окно")));
        Pattern p = Pattern.compile("(" + label + ")[^0-9]{0," + window + "}?"
                        + "(\\d[\\d\\s\\u00A0]{3,17}(?:[.,]\\d{1,2})?)(?![\\d])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        Map<String, Set<String>> byValue = new LinkedHashMap<>();
        for (var d : node.getGraph().getDocMap().values()) {
            Matcher m = p.matcher(d.getText());
            while (m.find()) {
                String raw = m.group(2).replace(" ", "").replace(" ", "")
                        .replace(",", ".");
                double v;
                try {
                    v = Double.parseDouble(raw);
                } catch (NumberFormatException e) {
                    continue;
                }
                if (v < 10_000) {
                    continue; // проценты, номера пунктов и прочий шум рядом с меткой
                }
                byValue.computeIfAbsent(String.format(Locale.ROOT, "%.2f", v), k -> new LinkedHashSet<>())
                        .add(d.getFilename());
            }
        }
        StringBuilder sb = new StringBuilder("СВЕРКА СУММ ПО МЕТКЕ «" + label
                + "» ПО ВСЕМ ДОКУМЕНТАМ КОМПЛЕКТА:\n");
        if (byValue.isEmpty()) {
            return sb.append("упоминаний сумм рядом с меткой не найдено").toString();
        }
        for (var e : byValue.entrySet()) {
            sb.append("- ").append(e.getKey()).append(" руб.: ")
                    .append(String.join("; ", e.getValue())).append('\n');
        }
        sb.append("Различных значений: ").append(byValue.size());
        if (byValue.size() > 1) {
            sb.append(". Если среди значений есть суммы, обязанные совпадать "
                    + "(итоговая НМЦ в разных разделах одного документа), "
                    + "это противоречие комплекта.");
        }
        return sb.toString();
    }

    /**
     * Извлекает regex-ом значение из документов прогона, отфильтрованных по
     * ИМЕНИ файла: сначала пробуются документы, чьё имя матчится параметром
     * «имя» (regex, без учёта регистра), затем — при отсутствии совпадений и
     * «строго» != true — все остальные. Возвращается первое совпадение.
     * Незаменимо, когда порядок документов недетерминирован, а значение нужно
     * брать из конкретного типа документа (ПЗ, извещение).
     * Параметры: «имя», «шаблон», «группа» (по умолчанию 1), «строго».
     */
    private String extractFromDocs(Map<String, Object> op) {
        Pattern nameP = Pattern.compile(String.valueOf(op.getOrDefault("имя", ".")),
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        Pattern p = Pattern.compile(String.valueOf(op.get("шаблон")), Pattern.MULTILINE);
        int group = op.get("группа") == null ? 1
                : Integer.parseInt(String.valueOf(op.get("группа")));
        boolean strict = Boolean.parseBoolean(String.valueOf(op.getOrDefault("строго", "false")));
        var docs = node.getGraph().getDocMap().values();
        for (boolean preferred : new boolean[]{true, false}) {
            for (var d : docs) {
                if (nameP.matcher(d.getFilename()).find() != preferred) {
                    continue;
                }
                Matcher m = p.matcher(d.getText());
                if (m.find()) {
                    return m.group(Math.min(group, m.groupCount())).strip()
                            + " [источник: " + d.getFilename() + "]";
                }
            }
            if (strict) {
                break;
            }
        }
        return "не найдено";
    }

    private String jsonField(Map<String, Object> op, String text) {
        String path = String.valueOf(op.get("путь"));
        // переиспользуем механику выражений: {{json:...}} по текущему тексту
        return ExpressionResolver.extractJsonPathFromText(text, path);
    }

    private String substringOp(Map<String, Object> op, String text) {
        int from = op.get("от") == null ? 0 : Integer.parseInt(String.valueOf(op.get("от")));
        int to = op.get("до") == null ? text.length() : Integer.parseInt(String.valueOf(op.get("до")));
        from = Math.max(0, Math.min(from, text.length()));
        to = Math.max(from, Math.min(to, text.length()));
        return text.substring(from, to);
    }

    private String headTail(Map<String, Object> op, String text, boolean head) {
        int n = op.get("n") == null ? 10 : Integer.parseInt(String.valueOf(op.get("n")));
        String[] lines = text.split("\n", -1);
        if (lines.length <= n) {
            return text;
        }
        String[] slice = head
                ? Arrays.copyOfRange(lines, 0, n)
                : Arrays.copyOfRange(lines, lines.length - n, lines.length);
        return String.join("\n", slice);
    }
}
