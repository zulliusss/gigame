package ru.sber.cs.ai.gigame.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.web.reactive.socket.WebSocketSession;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;

/**
 * Утилитный класс для работы с идентификаторами пользователей.
 * <p>
 * Предоставляет методы для получения и проверки userId из HTTP-заголовков.
 * Поддерживает анонимные сессии (необязательный userId).
 *
 * @see ObjectUtils
 */
@Slf4j
public class UserUtils {
    private UserUtils() {
    }

    /**
     * Получает идентификатор пользователя, подставляя значение по умолчанию для пустых/null значений.
     *
     * @param userId userId из HTTP-заголовка X-UserId (может быть null)
     * @return userId или "anonymous" если userId пустой/null
     */
    public static String getUserId(String userId) {
        return ObjectUtils.isEmpty(userId) ? "anonymous" : userId;
    }

    /**
     * Проверяет совпадение userId с ожидаемым значением.
     * Выбрасывает исключение, если userId не совпадают.
     *
     * @param userId       userId из HTTP-заголовка
     * @param actualUserId ожидаемый userId из сущности
     * @throws IllegalArgumentException если userId не совпадают
     */
    public static void checkUserId(String userId, String actualUserId) {
        if (!UserUtils.getUserId(userId).equals(actualUserId)) {
            throw new AccessDeniedException("illegal userId");
        }
    }

    public static String extractUserIdFromWebSocketSession(WebSocketSession session) {
        // Получаем userId из headers (для WebFlux WebSocket)
        String userId = getUserId(
                session.getHandshakeInfo()
                        .getHeaders()
                        .getFirst("X-UserId")
        );

        log.debug("Extracted userId from WebSocket session: {}", userId);
        return userId;
    }
}
