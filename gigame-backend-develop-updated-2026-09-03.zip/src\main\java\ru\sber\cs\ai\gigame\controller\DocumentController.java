package ru.sber.cs.ai.gigame.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.document.DocumentViewResponse;
import ru.sber.cs.ai.gigame.dto.ErrorResponse;
import ru.sber.cs.ai.gigame.service.KBService;

import java.util.UUID;

/**
 * REST-контроллер документов.
 * <p>
 * Позволяет просматривать загруженные документы (метаданные и извлечённый
 * текст) — используется для перехода к источникам RAG из ответов ассистента.
 *
 * @see KBService
 */
@RestController
@RequestMapping("/api/documents")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Документы", description = "Просмотр загруженных документов")
@SuppressWarnings("unused")
public class DocumentController {

    private final KBService kbService;

    /**
     * Просмотр документа: метаданные и извлечённый текст.
     *
     * @param userId Идентификатор пользователя (из заголовка X-UserId)
     * @param id     Идентификатор документа
     * @return Документ с текстом
     */
    @GetMapping("/{id}")
    @Operation(
            summary = "Получить документ с извлечённым текстом",
            description = "Возвращает метаданные и извлечённый текст документа. " +
                    "Доступ: владелец документа или любой пользователь, если документ " +
                    "входит в доступную ему базу знаний (собственную или общую).",
            responses = {
                    @ApiResponse(responseCode = "200",
                            description = "Документ найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = DocumentViewResponse.class))
                    ),
                    @ApiResponse(responseCode = "403",
                            description = "Нет доступа к документу",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class))
                    ),
                    @ApiResponse(responseCode = "404",
                            description = "Документ не найден",
                            content = @Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
                                    schema = @Schema(implementation = ErrorResponse.class)))})
    public Mono<DocumentViewResponse> getDocument(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(
                    name = "X-UserId",
                    in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$")
            )
            String userId,
            @Parameter(description = "Уникальный идентификатор документа (UUID)",
                    schema = @Schema(type = "string", pattern = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"))
            @PathVariable UUID id) {
        log.debug("getDocument: userId={}, documentId={}", userId, id);
        return Mono.fromCallable(() -> kbService.getDocumentView(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }
}
