package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFGroupShape;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFSlide;
import org.apache.poi.xslf.usermodel.XSLFTable;
import org.apache.poi.xslf.usermodel.XSLFTableCell;
import org.apache.poi.xslf.usermodel.XSLFTableRow;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.IBodyElement;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFSDT;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.utils.FileUtils;
import ru.sber.cs.ai.gigame.utils.TextSplitter;
import ru.sber.cs.ai.gigame.utils.UserUtils;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Сервис обработки загруженных файлов, извлечения текста и индексации документов.
 * <p>
 * Основные функции:
 * <ul>
 *   <li>Загрузка файлов различных форматов (PDF, DOCX, XLSX, TXT)</li>
 *   <li>Извлечение текстового содержимого из документов</li>
 *   <li>Разбиение длинных документов на фрагменты (чанки)</li>
 *   <li>Векторная индексация для последующего поиска похожих фрагментов</li>
 *   <li>Хранение метаданных файлов в базе данных</li>
 * </ul>
 *
 * @see Document
 * @see DocumentRepository
 * @see EmbeddingService
 * @see TextSplitter
 * @see GigaChatClient
 */
@Service
@Slf4j
public class DocumentService {
    /** Число с разрядами, сгруппированными пробелами («9 750 986,34»). */
    private static final Pattern GROUPED_NUMBER = Pattern.compile(
            "(?<![\\d,.])\\d{1,3}(?:[ \\u00A0\\u202F\\u2009]\\d{3})+(?:[.,]\\d{1,2})?(?!\\d)");
    /** Число, рваное экстрактором на неравные куски («9 750 98 6,34» у PDFBox):
     *  куски по 1-3 цифры, десятичная часть обязательна — иначе слипались бы
     *  соседние самостоятельные целые числа. */
    private static final Pattern TORN_NUMBER = Pattern.compile(
            "(?<![\\d,.])\\d{1,3}(?:[ \\u00A0\\u202F\\u2009]\\d{1,3})+[.,]\\d{1,2}(?!\\d)");
    private static final Pattern GROUP_SEPARATORS = Pattern.compile("[ \\u00A0\\u202F\\u2009]");
    /** Число, разорванное переносом строки на длинную голову и короткий дробный хвост
     *  («394134\n3,56» = 3941343,56 в узких колонках таблиц PDF): голова от 4 цифр,
     *  хвост 1-2 цифры с обязательной дробной частью — самостоятельное число из
     *  1-2 цифр с копейками сразу под 4+-значным целым в таблицах не встречается. */
    private static final Pattern WRAPPED_NUMBER = Pattern.compile(
            "(?<![\\d,.])\\d{4,}[\\r\\n]+\\d{1,2}[.,]\\d{1,2}(?!\\d)");
    /** Разрыв переносом ПОСЛЕ десятичной запятой («384553,\n94» = 384553,94):
     *  голова от 4 цифр с запятой, хвост 1-2 цифры копеек. */
    private static final Pattern WRAPPED_AFTER_COMMA = Pattern.compile(
            "(?<![\\d,.])\\d{4,},[\\r\\n]+\\d{1,2}(?![\\d,.])");
    private static final Pattern WRAP_SEPARATORS = Pattern.compile("[\\r\\n]+");
    private final DocumentRepository documentRepository;
    private final EmbeddingService embeddingService;
    private final DocumentIndexService indexService;
    /**
     * Максимальная длина текста документа для включения полного содержимого в промпт.
     * Документы длиннее этого лимита разбиваются на фрагменты и индексируются для поиска по схожести.
     */
    @Value("${app.embedding.char-limit:12000}")
    private int charLimit;

    /**
     * Порог длины текста PDF, ниже которого документ считается сканом без текстового слоя.
     */
    @Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars = 40;

    /**
     * Распознавание PDF-сканов (может отсутствовать в тестовом контексте).
     */
    private final ObjectProvider<ScanOcrService> scanOcrProvider;

    @Autowired
    public DocumentService(DocumentRepository documentRepository, EmbeddingService embeddingService,
                           DocumentIndexService indexService,
                           ObjectProvider<ScanOcrService> scanOcrProvider) {
        this.documentRepository = documentRepository;
        this.embeddingService = embeddingService;
        this.indexService = indexService;
        this.scanOcrProvider = scanOcrProvider;
    }

    public DocumentService(DocumentRepository documentRepository, EmbeddingService embeddingService,
                           DocumentIndexService indexService) {
        this(documentRepository, embeddingService, indexService, null);
    }

    // -------------------------------------------------------------------------
    // Text extraction
    // -------------------------------------------------------------------------

    /**
     * Сохраняет загруженный файл, извлекает текст, сохраняет в БД
     * и индексирует, если документ большой.
     * <p>
     * Алгоритм работы:
     * <ol>
     *   <li>Извлекает имя файла и определяет тип контента</li>
     *   <li>Читает содержимое файла из multipart-запроса</li>
     *   <li>Извлекает текст в зависимости от типа файла</li>
     *   <li>Сохраняет метаданные в базу данных</li>
     *   <li>Если текст большой, запускает индексацию</li>
     * </ol>
     *
     * @param file   загруженный файл
     * @param userId идентификатор пользователя
     * @return DTO с метаданными документа
     */
    @Transactional
    public DocumentResponse uploadDocument(FilePart file, String userId) {
        String filename = file.filename();
        if (filename.isBlank()) {
            throw new FileException("Пустое имя файла");
        }
        String contentType = FileUtils.detectContentType(filename);
        String extractedText;
        byte[] contentBytes;
        try (InputStream inputStream = FileUtils.toInputStream(file).block()) {
            assert inputStream != null;
            contentBytes = inputStream.readAllBytes();
            extractedText = parseText(new ByteArrayInputStream(contentBytes), contentType);
        } catch (Exception e) {
            log.error("Ошибка при обработке файла {}: {}", filename, e.getMessage());
            throw new FileException("Failed to extract text from " + filename, e);
        }
        extractedText = maybeOcrScan(filename, contentType, contentBytes, extractedText);
        Document document = new Document();
        document.setFilename(filename);
        document.setContentType(contentType);
        document.setExtractedText(extractedText);
        document.setSizeBytes((int) file.headers().getContentLength());
        // Нормализация (null/пусто -> anonymous): иначе владелец-аноним не пройдёт
        // проверку доступа при просмотре собственного документа
        document.setUserId(UserUtils.getUserId(userId));
        document = documentRepository.save(document);

        if (extractedText.length() > charLimit) {
            try {
                indexService.indexDocument(document.getId(), extractedText);
            } catch (Exception e) {
                log.error("Document {} indexing error {}", document.getId(), e.getMessage());
            }
        }

        return toDto(document);
    }

    /**
     * PDF без текстового слоя (скан): при включённом OCR
     * ({@code app.document.ocr-via-gigachat}) распознаётся через файловое
     * хранилище GigaChat; при выключенном или при ошибке текст остаётся как есть
     * (модель в чате честно скажет, что содержимое не извлечено).
     *
     * @param filename    имя файла
     * @param contentType тип контента
     * @param content     содержимое файла
     * @param parsed      извлечённый парсером текст
     * @return распознанный либо исходный текст
     */
    private String maybeOcrScan(String filename, String contentType, byte[] content, String parsed) {
        if (!"pdf".equals(contentType) || parsed.strip().length() >= minParsedChars) {
            return parsed;
        }
        ScanOcrService ocr = scanOcrProvider != null ? scanOcrProvider.getIfAvailable() : null;
        if (ocr == null || !ocr.isEnabled()) {
            return parsed;
        }
        try {
            return ocr.recognize(filename, content);
        } catch (Exception e) {
            log.warn("OCR скана «{}» не удался ({}) — текст остаётся пустым", filename, e.getMessage());
            return parsed;
        }
    }

    /**
     * Извлекает текст из файла в зависимости от его типа контента.
     * <p>
     * Поддерживаемые форматы:
     * <ul>
     *   <li>PDF — с помощью Apache PDFBox</li>
     *   <li>DOCX — с помощью Apache POI (параграфы и таблицы)</li>
     *   <li>XLSX/XLS — с помощью Apache POI (все листы)</li>
     *   <li>TXT — как plain text</li>
     * </ul>
     *
     * @param inputStream поток с содержимым файла
     * @param contentType тип контента ("pdf", "docx", "xlsx", "txt")
     * @return извлечённый текст
     * @throws IOException              если произошла ошибка при чтении файла
     * @throws IllegalArgumentException если тип контента не поддерживается
     */
    public String parseText(InputStream inputStream, String contentType) throws IOException {
        String extracted = switch (contentType) {
            case "pdf" -> parsePdf(inputStream);
            case "docx" -> parseDocx(inputStream);
            case "xlsx" -> parseXlsx(inputStream);
            case "xls" -> parseXls(inputStream);
            case "pptx" -> parsePptx(inputStream);
            case "xml" -> parseXml(inputStream);
            case "txt" -> decodeText(inputStream.readAllBytes());
            default -> throw new IllegalArgumentException("Неподдерживаемый тип контента: " + contentType);
        };
        return normalizeNumberGroups(extracted);
    }

    /**
     * Склеивает разряды чисел, разорванные пробелами-разделителями: «9 750 986,34» →
     * «9750986,34». Модель теряет разряды при переписывании разорванных чисел, а
     * детерминированные узлы (расчёт, трансформация) не распознают их как числа.
     * Склейка только внутри валидно сгруппированных чисел (по три цифры), поэтому
     * соседние самостоятельные числа («2025 100 000,00») не слипаются.
     *
     * @param text исходный текст документа
     * @return текст со склеенными числами
     */
    static String normalizeNumberGroups(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        String glued = glueMatches(GROUPED_NUMBER, text, GROUP_SEPARATORS);
        glued = glueMatches(TORN_NUMBER, glued, GROUP_SEPARATORS);
        glued = glueMatches(WRAPPED_NUMBER, glued, WRAP_SEPARATORS);
        return glueMatches(WRAPPED_AFTER_COMMA, glued, WRAP_SEPARATORS);
    }

    private static String glueMatches(Pattern pattern, String text, Pattern separators) {
        Matcher m = pattern.matcher(text);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            m.appendReplacement(sb,
                    Matcher.quoteReplacement(separators.matcher(m.group()).replaceAll("")));
        }
        m.appendTail(sb);
        return sb.toString();
    }

    /**
     * Декодирует текстовый файл: сначала строгий UTF-8, при ошибке — windows-1251.
     * <p>
     * Раньше использовалась кодировка JVM по умолчанию — на Windows (cp1251)
     * загруженные UTF-8 файлы превращались в нечитаемый текст.
     */
    private String decodeText(byte[] bytes) {
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException e) {
            return new String(bytes, Charset.forName("windows-1251"));
        }
    }

    /**
     * Извлекает текст из PDF-документа.
     *
     * @param inputStream поток с PDF-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении PDF
     */
    private String parsePdf(InputStream inputStream) throws IOException {
        byte[] pdfBytes = inputStream.readAllBytes();
        try (PDDocument doc = Loader.loadPDF(pdfBytes)) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(doc);
        }
    }

    /**
     * Извлекает текст из DOCX-документа.
     * <p>
     * Обрабатывает параграфы и таблицы (важно для документов с заявками и спецификациями).
     * Для таблиц ячейки объединяются символом "|".
     *
     * @param inputStream поток с DOCX-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении DOCX
     */
    private String parseDocx(InputStream inputStream) throws IOException {
        ZipSecureFile.setMinInflateRatio(0);
        try (XWPFDocument doc = new XWPFDocument(inputStream)) {
            return processDocxElement(doc.getBodyElements());
        }
    }

    private String processDocxElement(List<IBodyElement> bodyElements) {
        List<String> parts = new ArrayList<>();
        for (IBodyElement bodyElement : bodyElements) {
            switch (bodyElement.getElementType()) {
                case PARAGRAPH:
                    String text = ((XWPFParagraph) bodyElement).getText();
                    if (text != null && !text.isBlank()) {
                        parts.add(text.strip());
                    } else {
                        parts.add("");
                    }
                    break;
                case TABLE:
                    parts.add(processDocxTable((XWPFTable) bodyElement));
                    break;
                case CONTENTCONTROL:
                    parts.add(((XWPFSDT) bodyElement).getContent().getText());
                    break;
                default:
            }
        }
        return String.join("\n", parts);
    }

    private String processDocxTable(XWPFTable table) {
        List<String> lines = new ArrayList<>();
        for (XWPFTableRow row : table.getRows()) {
            List<String> cellContents = new ArrayList<>();
            for (XWPFTableCell cell : row.getTableCells()) {
                cellContents.add(processDocxElement(cell.getBodyElements()));
            }
            lines.add("< " + String.join(" | ", cellContents) + " >");
        }

        return "[ " + String.join("\n", lines) + " ]";
    }

    /**
     * Извлекает текст из XLSX-файла.
     * <p>
     * Обрабатывает все листы книги. Если листов несколько, каждый лист
     * помечается заголовком "=== Лист: [название] ===". Ячейки в строке
     * объединяются символом "|". Для ячеек с формулами извлекается вычисленное значение.
     *
     * @param inputStream поток с XLSX-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении XLSX
     */
    private String parseXlsx(InputStream inputStream) throws IOException {
        try (XSSFWorkbook wb = new XSSFWorkbook(inputStream)) {
            return parseWorkbook(wb);
        }
    }

    /**
     * Извлекает текст из бинарного XLS-файла (старый формат Excel 97-2003).
     * Раньше .xls направлялся в XLSX-парсер и не разбирался.
     *
     * @param inputStream поток с XLS-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении XLS
     */
    private String parseXls(InputStream inputStream) throws IOException {
        try (HSSFWorkbook wb = new HSSFWorkbook(inputStream)) {
            return parseWorkbook(wb);
        }
    }

    /**
     * Общая логика извлечения текста из книги Excel (XLSX и XLS).
     * Обрабатывает все листы; при нескольких листах каждый помечается
     * заголовком "=== Лист: [название] ===". Формулы вычисляются.
     */
    private String parseWorkbook(Workbook wb) {
        List<String> parts = new ArrayList<>();
        for (int s = 0; s < wb.getNumberOfSheets(); s++) {
            Sheet sheet = wb.getSheetAt(s);
            FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
            if (wb.getNumberOfSheets() > 1) {
                parts.add("=== Лист: " + sheet.getSheetName() + " ===");
            }
            for (Row row : sheet) {
                parts.add(parseExcelRow(row, evaluator));
            }
            // пустая строка между листами
            parts.add("");
        }
        return String.join("\n", parts);
    }

    /**
     * Извлекает текст из PPTX-презентации.
     * <p>
     * Каждый слайд помечается заголовком "=== Слайд N ===". Обрабатываются
     * текстовые фигуры, таблицы (ячейки объединяются "|", как в DOCX)
     * и группы фигур (рекурсивно).
     *
     * @param inputStream поток с PPTX-файлом
     * @return извлечённый текст
     * @throws IOException если произошла ошибка при чтении PPTX
     */
    private String parsePptx(InputStream inputStream) throws IOException {
        ZipSecureFile.setMinInflateRatio(0);
        List<String> parts = new ArrayList<>();
        try (XMLSlideShow ppt = new XMLSlideShow(inputStream)) {
            int slideNum = 1;
            for (XSLFSlide slide : ppt.getSlides()) {
                parts.add("=== Слайд " + slideNum++ + " ===");
                for (XSLFShape shape : slide.getShapes()) {
                    appendPptxShape(shape, parts);
                }
                parts.add("");
            }
        }
        return String.join("\n", parts);
    }

    private void appendPptxShape(XSLFShape shape, List<String> parts) {
        if (shape instanceof XSLFTable table) {
            appendPptxTable(table, parts);
        } else if (shape instanceof XSLFTextShape textShape) {
            appendPptxTextShape(textShape, parts);
        } else if (shape instanceof XSLFGroupShape group) {
            for (XSLFShape child : group.getShapes()) {
                appendPptxShape(child, parts);
            }
        }
    }

    private void appendPptxTable(XSLFTable table, List<String> parts) {
        List<String> lines = new ArrayList<>();
        for (XSLFTableRow row : table.getRows()) {
            List<String> cells = new ArrayList<>();
            for (XSLFTableCell cell : row.getCells()) {
                String text = cell.getText();
                cells.add(text == null ? "" : text.strip());
            }
            lines.add("< " + String.join(" | ", cells) + " >");
        }
        parts.add("[ " + String.join("\n", lines) + " ]");
    }

    private void appendPptxTextShape(XSLFTextShape textShape, List<String> parts) {
        String text = textShape.getText();
        if (text != null && !text.isBlank()) {
            parts.add(text.strip());
        }
    }

    private String parseExcelRow(Row row, FormulaEvaluator evaluator) {
        DataFormatter fmt = new DataFormatter();
        List<String> cells = new ArrayList<>();
        for (int c = 0; c < row.getLastCellNum(); c++) {
            Cell cell = row.getCell(c);
            String val = "";
            if (cell != null && cell.getCellType() != CellType.BLANK) {
                // Используем evaluator для вычисления формул
                CellValue cellValue = evaluator.evaluate(cell);
                if (cellValue != null) {
                    val = fmt.formatCellValue(cell, evaluator).strip();
                } else {
                    val = fmt.formatCellValue(cell).strip();
                }
            }
            cells.add(val);
        }
        return String.join(" | ", cells);
    }

    /**
     * Извлекает текст из XML-документа.
     * <p>
     * Универсальный передаточный документ ФНС (УПД, формат "Файл/Документ/СвСчФакт")
     * преобразуется в структурированный читаемый текст: реквизиты документа,
     * продавец/покупатель, состав работ с суммами, итог и основание передачи.
     * Прочие XML сводятся к конкатенации текстовых узлов и значимых атрибутов.
     * Внешние сущности отключены (защита от XXE).
     *
     * @param inputStream поток с XML-файлом
     * @return извлечённый текст
     * @throws IOException если XML повреждён или не разбирается
     */
    private String parseXml(InputStream inputStream) throws IOException {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
            dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            dbf.setXIncludeAware(false);
            dbf.setExpandEntityReferences(false);
            var xml = dbf.newDocumentBuilder().parse(inputStream);
            var root = xml.getDocumentElement();
            String updText = parseUpdXml(root);
            return updText != null ? updText : xmlToPlainText(root);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Не удалось разобрать XML-документ", e);
        }
    }

    /**
     * Собирает читаемый текст из УПД (счёт-фактура/акт ЭДО, приказ ФНС ММВ-7-15/820@).
     *
     * @return текст УПД или {@code null}, если структура не соответствует формату
     */
    private String parseUpdXml(Element root) {
        if (!"Файл".equals(root.getNodeName())) {
            return null;
        }
        var doc = childElement(root, "Документ");
        var schFakt = doc != null ? childElement(doc, "СвСчФакт") : null;
        if (schFakt == null) {
            return null;
        }
        List<String> parts = new ArrayList<>();
        parts.add("Универсальный передаточный документ (УПД)");
        parts.add("Номер документа: " + schFakt.getAttribute("НомерСчФ")
                + ", дата: " + schFakt.getAttribute("ДатаСчФ"));
        String function = doc.getAttribute("Функция");
        if (!function.isBlank()) {
            parts.add("Функция документа: " + function);
        }
        appendUpdParty(parts, schFakt, "СвПрод", "Продавец (исполнитель)");
        appendUpdParty(parts, schFakt, "СвПокуп", "Покупатель (заказчик)");

        appendUpdExtraInfo(parts, schFakt);
        appendUpdTable(parts, doc);
        appendUpdTransfer(parts, doc);
        return String.join("\n", parts);
    }

    /**
     * Привязка к договору: ИнфПолФХЖ1/ТекстИнф[@Идентиф="Дог"] и прочие доп. сведения.
     */
    private void appendUpdExtraInfo(List<String> parts, Element schFakt) {
        var infPol = childElement(schFakt, "ИнфПолФХЖ1");
        if (infPol != null) {
            for (var ti : childElements(infPol, "ТекстИнф")) {
                parts.add("Доп. сведения (" + ti.getAttribute("Идентиф") + "): " + ti.getAttribute("Значен"));
            }
        }
    }

    private void appendUpdTable(List<String> parts, Element doc) {
        var table = childElement(doc, "ТаблСчФакт");
        if (table == null) {
            return;
        }
        for (var row : childElements(table, "СведТов")) {
            parts.add("Позиция " + row.getAttribute("НомСтр") + ": " + row.getAttribute("НаимТов"));
            parts.add("  Стоимость без НДС: " + row.getAttribute("СтТовБезНДС")
                    + ", с НДС: " + row.getAttribute("СтТовУчНал"));
        }
        var total = childElement(table, "ВсегоОпл");
        if (total != null) {
            parts.add("ИТОГО без НДС: " + total.getAttribute("СтТовБезНДСВсего")
                    + ", с НДС: " + total.getAttribute("СтТовУчНалВсего"));
        }
    }

    private void appendUpdTransfer(List<String> parts, Element doc) {
        var prodPer = childElement(doc, "СвПродПер");
        var per = prodPer != null ? childElement(prodPer, "СвПер") : null;
        if (per == null) {
            return;
        }
        String content = per.getAttribute("СодОпер");
        if (!content.isBlank()) {
            parts.add("Содержание операции: " + content);
        }
        var osn = childElement(per, "ОснПер");
        if (osn != null) {
            String osnText = (osn.getAttribute("НаимОсн") + " " + osn.getAttribute("НомОсн")
                    + " " + osn.getAttribute("ДатаОсн")).strip().replaceAll("\\s+", " ");
            parts.add("Основание передачи: " + osnText);
        }
    }

    private void appendUpdParty(List<String> parts, Element schFakt, String tag, String title) {
        var party = childElement(schFakt, tag);
        var idSv = party != null ? childElement(party, "ИдСв") : null;
        var org = idSv != null ? childElement(idSv, "СвЮЛУч") : null;
        if (org != null) {
            parts.add(title + ": " + org.getAttribute("НаимОрг") + ", ИНН " + org.getAttribute("ИННЮЛ"));
        }
    }

    private Element childElement(Element parent, String name) {
        List<Element> found = childElements(parent, name);
        return found.isEmpty() ? null : found.get(0);
    }

    private List<Element> childElements(Element parent, String name) {
        List<Element> result = new ArrayList<>();
        var children = parent.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            if (children.item(i) instanceof Element el && name.equals(el.getNodeName())) {
                result.add(el);
            }
        }
        return result;
    }

    /**
     * Fallback для прочих XML: текстовые узлы и значимые атрибуты в порядке документа.
     */
    private String xmlToPlainText(Element root) {
        StringBuilder sb = new StringBuilder();
        collectXmlText(root, sb);
        return sb.toString().strip();
    }

    private void collectXmlText(Node node, StringBuilder sb) {
        if (node instanceof Element el) {
            NamedNodeMap attrs = el.getAttributes();
            for (int i = 0; i < attrs.getLength(); i++) {
                Node attr = attrs.item(i);
                String value = attr.getNodeValue();
                if (value != null && !value.isBlank()) {
                    sb.append(attr.getNodeName()).append(": ").append(value).append('\n');
                }
            }
        } else if (node.getNodeType() == Node.TEXT_NODE) {
            String text = node.getNodeValue();
            if (text != null && !text.isBlank()) {
                sb.append(text.strip()).append('\n');
            }
        }
        NodeList children = node.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            collectXmlText(children.item(i), sb);
        }
    }

    /**
     * Удаляет документ: удаляет файл с диска, векторные эмбеддинги и запись в БД.
     *
     * @param documentId UUID документа
     */
    public void deleteDocument(UUID documentId) {
        Document doc = documentRepository.findById(documentId)
                .orElseThrow(() -> new NotFoundException("Документ не найден: " + documentId));
        // Удаляем эмбеддинги
        embeddingService.deleteDocumentChunks(documentId);

        // Удаляем запись в БД
        documentRepository.delete(doc);
    }

    // -------------------------------------------------------------------------
    // Вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Преобразует сущность Document в DTO для ответа клиенту.
     *
     * @param doc сущность документа
     * @return DTO с метаданными документа
     */
    public DocumentResponse toDto(Document doc) {
        return new DocumentResponse(
                doc.getId(),
                doc.getFilename(),
                doc.getContentType(),
                doc.getSizeBytes(),
                doc.getExtractedText() != null ? doc.getExtractedText().length() : 0,
                doc.getExtractedText(),
                doc.getCreatedAt(),
                doc.getUpdatedAt()
        );
    }

    // -------------------------------------------------------------------------
    // DTO record
    // -------------------------------------------------------------------------

    /**
     * Неизменяемый DTO для метаданных документа.
     */
    public record DocumentResponse(
            UUID id,
            String filename,
            String contentType,
            Integer sizeBytes,
            int textLength,
            String extractedText,
            OffsetDateTime createdAt,
            OffsetDateTime updatedAt
    ) {
    }
}
