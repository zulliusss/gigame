package ru.sber.cs.ai.gigame.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.dto.prompt.PromptCreate;
import ru.sber.cs.ai.gigame.dto.prompt.PromptRateRequest;
import ru.sber.cs.ai.gigame.dto.prompt.PromptResponse;
import ru.sber.cs.ai.gigame.dto.prompt.PromptUpdate;
import ru.sber.cs.ai.gigame.service.PromptService;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * REST API базы промптов: проверенные формулировки с рейтингами и
 * статистикой использования.
 */
@RestController
@RequestMapping("/api/prompts")
@RequiredArgsConstructor
@Tag(name = "prompts", description = "База промптов: проверенные формулировки с рейтингами")
@SuppressWarnings("unused")
public class PromptController {

    private final PromptService promptService;

    /**
     * Промпты, видимые пользователю: собственные и все общие.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @return промпты со статистикой, новые сверху
     */
    @GetMapping
    @Operation(summary = "Список промптов",
            description = "Собственные промпты пользователя и все общие, со статистикой.")
    public Mono<List<PromptResponse>> listPrompts(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId) {
        return Mono.fromCallable(() -> promptService.getPrompts(userId))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Создаёт промпт.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param body   данные промпта
     * @return созданный промпт
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Создать промпт")
    public Mono<PromptResponse> createPrompt(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @RequestBody PromptCreate body) {
        return Mono.fromCallable(() -> promptService.createPrompt(userId, body))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Обновляет промпт (только владелец).
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор промпта
     * @param body   изменяемые поля (null — не менять)
     * @return обновлённый промпт
     */
    @PutMapping("/{id}")
    @Operation(summary = "Обновить промпт")
    public Mono<PromptResponse> updatePrompt(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id,
            @RequestBody PromptUpdate body) {
        return Mono.fromCallable(() -> promptService.updatePrompt(userId, id, body))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Удаляет промпт (только владелец).
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор промпта
     */
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Удалить промпт")
    public Mono<Void> deletePrompt(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id) {
        return Mono.<Void>fromRunnable(() -> promptService.deletePrompt(userId, id))
                .subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Оценивает промпт (1..5); повторная оценка заменяет предыдущую.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор промпта
     * @param body   тело с полем rating
     */
    @PostMapping("/{id}/rating")
    @Operation(summary = "Оценить промпт",
            description = "Оценка от 1 до 5; повторная оценка заменяет предыдущую.")
    public Mono<Void> ratePrompt(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id,
            @RequestBody PromptRateRequest body) {
        return Mono.<Void>fromRunnable(() -> {
            Integer rating = body.rating();
            if (rating == null) {
                throw new IllegalArgumentException("Не указано поле rating");
            }
            promptService.ratePrompt(userId, id, rating);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    /**
     * Отмечает использование промпта: инкремент счётчика, возврат текста.
     *
     * @param userId идентификатор пользователя (из заголовка X-UserId)
     * @param id     идентификатор промпта
     * @return текст промпта (поле text)
     */
    @PostMapping("/{id}/use")
    @Operation(summary = "Использовать промпт",
            description = "Увеличивает счётчик использований и возвращает текст промпта.")
    public Mono<Map<String, String>> usePrompt(
            @RequestHeader(name = "X-UserId", required = false)
            @Parameter(name = "X-UserId", in = ParameterIn.HEADER,
                    schema = @Schema(type = "string", pattern = "^[A-Z0-9]{0,16}$"))
            String userId,
            @PathVariable UUID id) {
        return Mono.fromCallable(() -> Map.of("text", promptService.usePrompt(userId, id)))
                .subscribeOn(Schedulers.boundedElastic());
    }
}
