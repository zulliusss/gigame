package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.reactive.socket.HandshakeInfo;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioEngine;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioService;
import ru.sber.cs.ai.gigame.service.scenario.ScenarioUploadTaskService;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SuppressWarnings("unchecked")
class ScenarioWebSocketHandlerTest {

    private ScenarioWebSocketHandler handler;
    private ScenarioService scenarioService;
    private WebSocketSessionManager sessionManager;
    private ObjectMapper objectMapper;
    private DocsTextCacheService docsTextCacheService;
    private ScenarioUploadTaskService scenarioUploadTaskService;
    private WebSocketSession webSocketSession;

    @BeforeEach
    void setUp() {
        scenarioService = mock(ScenarioService.class);
        ScenarioEngine scenarioEngine = mock(ScenarioEngine.class);
        sessionManager = mock(WebSocketSessionManager.class);
        objectMapper = new ObjectMapper();
        docsTextCacheService = mock(DocsTextCacheService.class);
        scenarioUploadTaskService = mock(ScenarioUploadTaskService.class);

        handler = new ScenarioWebSocketHandler(
                scenarioService,
                scenarioEngine,
                sessionManager,
                objectMapper,
                scenarioUploadTaskService
        );

        // Mock DocsTextCacheService to return empty list instead of null
        when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());

        // Create a mock WebSocketSession
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        headers.put("X-UserId", List.of("test-user-id"));
        when(handshakeInfo.getHeaders()).thenReturn(headers);

        webSocketSession = mock(WebSocketSession.class);
        when(webSocketSession.getId()).thenReturn("test-session-id");
        when(webSocketSession.getHandshakeInfo()).thenReturn(handshakeInfo);
        when(webSocketSession.isOpen()).thenReturn(true);
        when(webSocketSession.textMessage(anyString())).thenReturn(mock(WebSocketMessage.class));
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
    }

    @Test
    void testHandle_addsSession() {
        when(webSocketSession.receive()).thenReturn(Flux.empty());
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);

        handler.handle(webSocketSession).block();

        verify(sessionManager, times(1)).addSession(webSocketSession, "test-user-id");
    }

    @Test
    void testHandle_removesSessionOnTerminate() {
        when(webSocketSession.receive()).thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(sessionManager, times(1)).removeSession(webSocketSession);
    }

    @Test
    void testHandle_processesIncomingMessage() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), any(), anyBoolean()))
                .thenReturn(Flux.empty());

        handler.handle(webSocketSession).block();

        verify(scenarioService, times(1)).runScenario(
                "test-user-id",
                UUID.fromString("123e4567-e89b-12d3-a456-426614174000"),
                true
        );
    }

    @Test
    void testHandle_sendsErrorMessageOnJsonParseError() {
        String invalidPayload = "{ invalid json }";

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(invalidPayload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        handler.handle(webSocketSession).block();

        verify(webSocketSession, times(1)).send(any());
    }

    @Test
    void testHandle_sendsErrorMessageOnSessionClosed() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        // Session not found
        when(sessionManager.getSession("test-session-id")).thenReturn(null);

        handler.handle(webSocketSession).block();
        verify(webSocketSession).receive();
    }

    @Test
    void testHandle_sessionNotFound() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(null);

        handler.handle(webSocketSession).block();

        verify(scenarioService, never()).runScenario(any(), any(), anyBoolean());
    }

    @Test
    void testHandle_emptyDocumentsText() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), any(), anyBoolean()))
                .thenReturn(Flux.empty());
        when(docsTextCacheService.getCachedDocumentTexts(any())).thenReturn(List.of());

        handler.handle(webSocketSession).block();

        verify(scenarioService, times(1)).runScenario(
                any(),
                any(),
                anyBoolean());
    }

    @Test
    void testHandle_withDocumentsText() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": false
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), any(), anyBoolean()))
                .thenReturn(Flux.empty());
        when(docsTextCacheService.getCachedDocumentTexts(any()))
                .thenReturn(List.of("cached document text"));

        handler.handle(webSocketSession).block();

        verify(scenarioService, times(1)).runScenario(
                any(),
                any(),
                eq(false)
        );
    }

    @Test
    void testHandle_errorSerialization() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());
        when(scenarioService.runScenario(any(), any(), anyBoolean()))
                .thenReturn(Flux.error(new RuntimeException("Test error")));

        handler.handle(webSocketSession).block();
        verify(scenarioService).runScenario(any(), any(), anyBoolean());
    }

    @Test
    void testHandle_withNullUserIdInHeaders() {
        HandshakeInfo handshakeInfo = mock(HandshakeInfo.class);
        HttpHeaders headers = new HttpHeaders();
        // No X-UserId
        when(handshakeInfo.getHeaders()).thenReturn(headers);

        WebSocketSession session = mock(WebSocketSession.class);
        when(session.getId()).thenReturn("test-session-id-2");
        when(session.getHandshakeInfo()).thenReturn(handshakeInfo);
        when(session.isOpen()).thenReturn(true);
        when(session.receive()).thenReturn(Flux.empty());

        handler.handle(session).block();

        verify(sessionManager, times(1)).addSession(session, "anonymous");
    }

    @Test
    void testHandle_createsStreamEvent() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with data
        Map<String, Object> eventData = Map.of("type", "status", "message", "Running");
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(eventData).build();
        when(scenarioService.runScenario(any(), any(), anyBoolean()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();

        // Verify that the message was sent with correct structure
        ArgumentCaptor<Flux<WebSocketMessage>> fluxCaptor = ArgumentCaptor.forClass(Flux.class);
        verify(webSocketSession, times(1)).send(fluxCaptor.capture());

        Flux<?> capturedFlux = fluxCaptor.getValue();
        List<?> messages = capturedFlux.collectList().block();

        assertNotNull(messages);
        assertEquals(1, messages.size());
    }

    @Test
    void testHandle_emptyDataInStreamEvent() {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        WebSocketMessage message = mock(
                WebSocketMessage.class
        );
        when(message.getPayloadAsText()).thenReturn(payload);

        when(webSocketSession.receive()).thenReturn(Flux.just(message));
        when(sessionManager.getSession("test-session-id")).thenReturn(webSocketSession);
        when(webSocketSession.send(any())).thenReturn(Mono.empty());

        // Mock a server sent event with null data
        ServerSentEvent<Map<String, Object>> sse = ServerSentEvent.<Map<String, Object>>builder().data(null).build();
        when(scenarioService.runScenario(any(), any(), anyBoolean()))
                .thenReturn(Flux.just(sse));

        handler.handle(webSocketSession).block();
        verify(scenarioService).runScenario(any(), any(), anyBoolean());
    }

    @Test
    void testScenarioMessageRecord() throws Exception {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": true
                }
                """;

        ScenarioWebSocketHandler.ScenarioMessage message = objectMapper.readValue(
                payload,
                ScenarioWebSocketHandler.ScenarioMessage.class
        );

        assertEquals("123e4567-e89b-12d3-a456-426614174000", message.scenarioId());
        assertTrue(message.stepMode());
    }

    @Test
    void testScenarioMessageRecord_falseStepMode() throws Exception {
        String payload = """
                {
                    "scenario_id": "123e4567-e89b-12d3-a456-426614174000",
                    "step_mode": false
                }
                """;

        ScenarioWebSocketHandler.ScenarioMessage message = objectMapper.readValue(
                payload,
                ScenarioWebSocketHandler.ScenarioMessage.class
        );

        assertEquals("123e4567-e89b-12d3-a456-426614174000", message.scenarioId());
        assertFalse(message.stepMode());
    }
}
