package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.model.Embedding;
import ru.sber.cs.ai.gigame.repository.EmbeddingRepository;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.MatchResult;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

/**
 * Сервис управления векторными эмбеддингами и поиска похожих фрагментов.
 * <p>
 * Использует pgvector для хранения векторов и выполнения поиска по косинусному расстоянию.
 *
 * @see Embedding
 * @see EmbeddingRepository
 */
@Service
@Slf4j
public class EmbeddingService {

    /** Константа Reciprocal Rank Fusion (классическое значение). */
    static final int RRF_K = 60;
    /** Условная дистанция чисто лексических хитов (дословное вхождение — сильный сигнал). */
    static final double LEXICAL_DISTANCE = 0.15;

    private final EmbeddingRepository embeddingRepository;
    @Value("${app.embedding.topK:5}")
    private int topK;

    public EmbeddingService(EmbeddingRepository embeddingRepository) {
        this.embeddingRepository = embeddingRepository;
    }


    /**
     * Сохраняет фрагменты документа с векторными эмбеддингами.
     * <p>
     * Используется для индексации документов в коллекции типа "doc".
     *
     * @param documentId UUID документа (используется как collection_id и source_document_id)
     * @param chunks     текстовые фрагменты
     * @param embeddings соответствующие векторные эмбеддинги
     */
    @Transactional
    public void storeDocumentChunks(UUID documentId, List<String> chunks, List<float[]> embeddings) {
        var embeddingList = IntStream.range(0, chunks.size())
                .mapToObj(idx -> new Embedding(
                        null,
                        "doc",
                        documentId,
                        documentId,
                        idx,
                        chunks.get(idx),
                        embeddings.get(idx)))
                .toList();
        
        embeddingRepository.saveAll(embeddingList);
        log.info("Сохранено {} фрагментов документа для документа {}", chunks.size(), documentId);
    }

    /**
     * Сохраняет фрагменты базы знаний с векторными эмбеддингами.
     * <p>
     * Используется для индексации документов в коллекции типа "kb".
     *
     * @param kbId             UUID базы знаний (collection_id)
     * @param sourceDocumentId UUID исходного документа
     * @param chunks           текстовые фрагменты
     * @param embeddings       соответствующие векторные эмбеддинги
     */
    @Transactional
    public void storeKBChunks(UUID kbId, UUID sourceDocumentId, List<String> chunks, List<float[]> embeddings) {
        var embeddingList = IntStream.range(0, chunks.size())
                .mapToObj(idx -> new Embedding(
                        null,
                        "kb",
                        kbId,
                        sourceDocumentId,
                        idx,
                        chunks.get(idx),
                        embeddings.get(idx)))
                .toList();
        
        embeddingRepository.saveAll(embeddingList);
        log.info("Сохранено {} фрагментов БЗ для БЗ={} документ={}", chunks.size(), kbId, sourceDocumentId);
    }

    /**
     * Ищет топ-K наиболее похожих фрагментов по косинусному расстоянию pgvector.
     *
     * @param collectionType тип коллекции ("doc" или "kb")
     * @param collectionId   UUID документа или базы знаний
     * @param queryEmbedding вектор запроса
     * @return список текстов фрагментов, отсортированных по схожести
     */
    public List<String> searchSimilar(String collectionType, UUID collectionId,
                                      float[] queryEmbedding) {
        return embeddingRepository.searchSimilar(collectionType, collectionId, queryEmbedding, topK);
    }

    /**
     * Найденный фрагмент с метаданными источника.
     *
     * @param text             текст фрагмента
     * @param sourceDocumentId UUID исходного документа
     * @param distance         косинусное расстояние до запроса (меньше — ближе)
     */
    public record ChunkHit(String text, UUID sourceDocumentId, double distance) {
    }

    /**
     * Ищет топ-K похожих фрагментов с указанием документа-источника и расстояния.
     * Расстояние позволяет корректно сливать результаты нескольких коллекций.
     *
     * @param collectionType тип коллекции ("doc" или "kb")
     * @param collectionId   UUID документа или базы знаний
     * @param queryEmbedding вектор запроса
     * @return список фрагментов, отсортированных по схожести
     */
    public List<ChunkHit> searchSimilarWithSources(String collectionType, UUID collectionId,
                                                   float[] queryEmbedding) {
        return embeddingRepository.searchSimilarWithSource(collectionType, collectionId, queryEmbedding, topK)
                .stream()
                .map(row -> new ChunkHit(
                        (String) row[0],
                        row[1] != null ? UUID.fromString(row[1].toString()) : null,
                        row[2] != null ? ((Number) row[2]).doubleValue() : Double.MAX_VALUE))
                .toList();
    }

    /**
     * Гибридный поиск (вектора + лексический канал, RRF-слияние): точные
     * термины и номера («1808920», «неустойка») эмбеддинги размывают, а
     * дословное вхождение — сильный сигнал. Чанки обоих каналов сливаются
     * по формуле Reciprocal Rank Fusion; чисто лексическим хитам даётся
     * условно-хорошая дистанция {@link #LEXICAL_DISTANCE} (дельта-фильтр
     * коллекций продолжает работать).
     *
     * @param collectionType тип коллекции ("doc" или "kb")
     * @param collectionId   UUID документа или базы знаний
     * @param queryEmbedding вектор запроса
     * @param queryText      текст запроса (для лексических термов)
     * @return слитый топ фрагментов
     */
    public List<ChunkHit> hybridSearchWithSources(String collectionType, UUID collectionId,
                                                  float[] queryEmbedding, String queryText) {
        List<ChunkHit> vector = searchSimilarWithSources(collectionType, collectionId, queryEmbedding);
        Map<String, ChunkHit> byText = new LinkedHashMap<>();
        Map<String, Double> score = new HashMap<>();
        int rank = 0;
        for (ChunkHit hit : vector) {
            byText.putIfAbsent(hit.text(), hit);
            score.merge(hit.text(), 1.0 / (RRF_K + rank++), Double::sum);
        }
        for (String term : lexicalTerms(queryText)) {
            rank = 0;
            for (Object[] row : embeddingRepository.searchLexical(
                    collectionType, collectionId, "%" + term + "%", topK)) {
                String text = (String) row[0];
                byText.putIfAbsent(text, new ChunkHit(text,
                        row[1] != null ? UUID.fromString(row[1].toString()) : null,
                        LEXICAL_DISTANCE));
                score.merge(text, 1.0 / (RRF_K + rank++), Double::sum);
            }
        }
        return byText.values().stream()
                .sorted(Comparator.comparingDouble(h -> -score.get(h.text())))
                .limit(topK)
                .toList();
    }

    /** Гибридный поиск без метаданных источника (тексты фрагментов). */
    public List<String> hybridSearch(String collectionType, UUID collectionId,
                                     float[] queryEmbedding, String queryText) {
        return hybridSearchWithSources(collectionType, collectionId, queryEmbedding, queryText)
                .stream().map(ChunkHit::text).toList();
    }

    /**
     * Лексические термы запроса: числа от 4 цифр и слова от 5 букв
     * (до 3 самых длинных) — то, что должно совпадать дословно.
     * Порог 5 (не 6): «итого», «сумма», «цена+» — ключевые слова
     * финансовых вопросов, и лексический канал без них слеп.
     */
    static List<String> lexicalTerms(String queryText) {
        if (queryText == null) {
            return List.of();
        }
        return Pattern.compile("[а-яёА-ЯЁa-zA-Z]{5,}|\\d{4,}").matcher(queryText).results()
                .map(MatchResult::group)
                .map(s -> s.toLowerCase(Locale.ROOT))
                .distinct()
                .sorted(Comparator.comparingInt(String::length).reversed())
                .limit(3)
                .toList();
    }

    /**
     * Возвращает настроенный размер выдачи topK.
     *
     * @return topK
     */
    public int getTopK() {
        return topK;
    }

    /**
     * Удаляет все векторные эмбеддинги для указанного документа.
     *
     * @param documentId UUID документа
     */
    @Transactional
    public void deleteDocumentChunks(UUID documentId) {
        embeddingRepository.deleteByCollection("doc", documentId);
        log.info("Удалены фрагменты документа для документа {}", documentId);
    }

    /**
     * Удаляет фрагменты конкретного документа из коллекции базы знаний.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     */
    @Transactional
    public void deleteKBDocumentChunks(UUID kbId, UUID documentId) {
        embeddingRepository.deleteKBDocumentChunks(kbId, documentId);
        log.info("Удалены фрагменты БЗ для БЗ={} документ={}", kbId, documentId);
    }

    /**
     * Удаляет все эмбеддинги для всей базы знаний.
     *
     * @param kbId UUID базы знаний
     */
    @Transactional
    public void deleteKBCollection(UUID kbId) {
        embeddingRepository.deleteByCollection("kb", kbId);
        log.info("Удалена вся коллекция БЗ {}", kbId);
    }
}
