package ru.sber.cs.ai.gigame.service.scenario;

import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Фоновая обработка загруженных документов сценария (режим {@code ?async=true}
 * эндпоинта загрузки).
 * <p>
 * Синхронная обработка большого комплекта (сотни страниц PDF, OCR сканов)
 * держит HTTP-запрос открытым минутами, и корпоративные шлюзы обрывают его
 * по таймауту. В асинхронном режиме запрос загрузки лишь принимает байты
 * файлов и ставит задачу разбора; клиент опрашивает прогресс короткими
 * запросами {@code GET /api/scenarios/{id}/upload-status} — длинных
 * HTTP-обменов не остаётся вовсе.
 * <p>
 * На сценарий допускается одна активная задача; запуск прогона до завершения
 * разбора блокируется через {@link #isProcessing(UUID)}.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ScenarioUploadTaskService {

    /** Статусы задачи разбора. */
    public static final String STATUS_PROCESSING = "processing";
    /** Задача завершена, документы в кэше сценария. */
    public static final String STATUS_DONE = "done";
    /** Задача завершилась ошибкой (текст — в поле error статуса). */
    public static final String STATUS_FAILED = "failed";
    /** Для сценария нет ни одной задачи разбора. */
    public static final String STATUS_NONE = "none";

    private final ScenarioService scenarioService;
    private final DocsTextCacheService docsTextCacheService;

    private final Map<UUID, UploadTask> tasks = new ConcurrentHashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(2);

    /** Состояние одной задачи разбора. */
    private static final class UploadTask {
        private final int filesTotal;
        private final List<ServerSentEvent<Map<String, Object>>> events =
                Collections.synchronizedList(new ArrayList<>());
        private volatile String status = STATUS_PROCESSING;
        private volatile int documentsCached;
        private volatile String error;

        private UploadTask(int filesTotal) {
            this.filesTotal = filesTotal;
        }
    }

    /**
     * Ставит задачу фонового разбора файлов. Байты файлов уже прочитаны
     * в HTTP-запросе — сама задача не держит соединение.
     *
     * @param scenarioId идентификатор сценария
     * @param files      файлы: имя + содержимое
     * @param append     догрузка к уже закэшированным документам
     * @throws FileException если по сценарию уже идёт разбор
     */
    public void start(UUID scenarioId, List<ScenarioService.RawFile> files, boolean append) {
        UploadTask existing = tasks.get(scenarioId);
        if (existing != null && STATUS_PROCESSING.equals(existing.status)) {
            throw new FileException("Предыдущая загрузка документов ещё обрабатывается — "
                    + "дождитесь её завершения (GET upload-status)");
        }
        UploadTask task = new UploadTask(files.size());
        tasks.put(scenarioId, task);
        if (!append) {
            docsTextCacheService.clearCache(scenarioId);
        }
        executor.submit(() -> runTask(scenarioId, task, files));
        log.info("Сценарий {}: поставлена фоновая задача разбора {} файла(ов), append={}",
                scenarioId, files.size(), append);
    }

    /**
     * Идёт ли по сценарию фоновый разбор документов (запуск прогона в это
     * время блокируется — кэш документов ещё не полон).
     *
     * @param scenarioId идентификатор сценария
     * @return {@code true}, если разбор ещё не завершён
     */
    public boolean isProcessing(UUID scenarioId) {
        UploadTask task = tasks.get(scenarioId);
        return task != null && STATUS_PROCESSING.equals(task.status);
    }

    /**
     * Снимок состояния задачи разбора для опроса клиентом.
     *
     * @param scenarioId идентификатор сценария
     * @return status (processing/done/failed/none), files, documents,
     *         warnings (тексты upload_warning), error
     */
    public Map<String, Object> status(UUID scenarioId) {
        UploadTask task = tasks.get(scenarioId);
        if (task == null) {
            return Map.of("status", STATUS_NONE, "files", 0, "documents", 0,
                    "warnings", List.of(), "error", "");
        }
        List<String> warnings = new ArrayList<>();
        synchronized (task.events) {
            for (ServerSentEvent<Map<String, Object>> event : task.events) {
                Map<String, Object> data = event.data();
                if (data != null && "upload_warning".equals(data.get("type"))) {
                    warnings.add(data.get("file") + ": " + data.get("message"));
                }
            }
        }
        return Map.of(
                "status", task.status,
                "files", task.filesTotal,
                "documents", task.documentsCached,
                "warnings", warnings,
                "error", task.error == null ? "" : task.error);
    }

    /** Тело фоновой задачи: разбор, проверка лимита, догрузка в кэш сценария. */
    private void runTask(UUID scenarioId, UploadTask task, List<ScenarioService.RawFile> files) {
        try {
            List<DocumentText> documents = scenarioService.parseFiles(files, task.events);
            int cached = docsTextCacheService.getCachedDocumentTexts(scenarioId).size();
            int limit = scenarioService.getMaxDocumentsPerRun();
            if (cached + documents.size() > limit) {
                throw new FileException("Слишком много документов с учётом уже загруженных: "
                        + (cached + documents.size()) + ". Максимум на прогон: " + limit);
            }
            docsTextCacheService.appendDocumentTexts(scenarioId,
                    documents.stream().map(DocumentText::text).toList(),
                    documents.stream().map(DocumentText::filename).toList(),
                    List.of());
            task.documentsCached = cached + documents.size();
            task.status = STATUS_DONE;
            log.info("Сценарий {}: фоновый разбор завершён, документов в кэше {}",
                    scenarioId, task.documentsCached);
        } catch (Exception e) {
            task.error = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            task.status = STATUS_FAILED;
            log.warn("Сценарий {}: фоновый разбор документов упал: {}", scenarioId, task.error);
        }
    }

    /** Останавливает пул фоновых задач при завершении приложения. */
    @PreDestroy
    public void shutdown() {
        executor.shutdownNow();
    }
}
