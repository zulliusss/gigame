package ru.sber.cs.ai.gigame.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import ru.sber.cs.ai.gigame.dto.kb.KBDocumentResponse;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KBDocument;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.utils.TextSplitter;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@Slf4j
public class DocumentIndexService {
    private final TransactionTemplate transactionTemplate;
    private final KBDocumentRepository kbDocumentRepository;
    private final DocumentRepository documentRepository;
    private final EmbeddingService embeddingService;
    private final TextSplitter textSplitter;
    private final GigaChatClient gigaChatClient;

    public DocumentIndexService(PlatformTransactionManager transactionManager, KBDocumentRepository kbDocumentRepository, DocumentRepository documentRepository, EmbeddingService embeddingService, TextSplitter textSplitter, GigaChatClient gigaChatClient) {
        this.kbDocumentRepository = kbDocumentRepository;
        this.documentRepository = documentRepository;
        this.embeddingService = embeddingService;
        this.textSplitter = textSplitter;
        this.gigaChatClient = gigaChatClient;
        this.transactionTemplate = new TransactionTemplate(transactionManager);
    }

    /**
     * Разбивает текст на фрагменты, вычисляет векторные эмбеддинги и сохраняет их.
     * <p>
     * Фрагменты сохраняются в векторное хранилище с использованием pgvector.
     * эмбеддинги вычисляются пакетами по 50 фрагментов (ограничение GigaChat API).
     *
     * @param documentId UUID документа
     * @param text       полный извлечённый текст
     */
    public void indexDocument(UUID documentId, String text) {
        transactionTemplate.execute(status -> {
            List<String> chunks = textSplitter.split(text);
            if (chunks.isEmpty()) {
                return false;
            }
            // Векторизуем пакетами по 50 (ограничение GigaChat API)
            List<float[]> allEmbeddings = new ArrayList<>();
            for (int i = 0; i < chunks.size(); i += 50) {
                List<String> batch = chunks.subList(i, Math.min(i + 50, chunks.size()));
                List<float[]> batchEmbeddings = gigaChatClient.getEmbeddings(batch);
                allEmbeddings.addAll(batchEmbeddings);
            }
            embeddingService.storeDocumentChunks(documentId, chunks, allEmbeddings);
            log.info("Проиндексирован документ {}: {} фрагментов", documentId, chunks.size());
            return true;
        });
    }

    /**
     * Переиндексирует документ в базе знаний: удаляет старые фрагменты,
     * заново вычисляет эмбеддинги и обновляет статус.
     * Выбрасывает исключение, если запись KBDocument не найдена.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @return обновлённый KBDocumentResponse
     */
    public KBDocumentResponse reindexDocument(UUID kbId, UUID documentId) {
        return transactionTemplate.execute(status -> {
            KBDocument kbDoc = kbDocumentRepository.findByKnowledgeBaseIdAndDocumentId(kbId, documentId)
                    .orElseThrow(() -> new NotFoundException(
                            "Документ базы знаний не найден: kbId=" + kbId + " docId=" + documentId));
            // Удаляем старые фрагменты
            embeddingService.deleteKBDocumentChunks(kbId, documentId);

            kbDoc.setStatus("processing");
            kbDoc.setErrorMessage(null);
            kbDoc = kbDocumentRepository.save(kbDoc);

            try {
                Document doc = documentRepository.findById(documentId)
                        .orElseThrow(() -> new NotFoundException("Документ не найден: " + documentId));
                if (doc.getExtractedText() == null || doc.getExtractedText().isBlank()) {
                    throw new IllegalStateException("Документ не содержит извлечённого текста");
                }

                List<String> chunks = textSplitter.split(doc.getExtractedText());
                if (chunks.isEmpty()) {
                    throw new IllegalStateException("Документ не дал фрагментов");
                }

                List<float[]> allEmbeddings = new ArrayList<>();
                for (int i = 0; i < chunks.size(); i += 50) {
                    List<String> batch = chunks.subList(i, Math.min(i + 50, chunks.size()));
                    List<float[]> batchEmbeddings = gigaChatClient.getEmbeddings(batch);
                    allEmbeddings.addAll(batchEmbeddings);
                }

                embeddingService.storeKBChunks(kbId, documentId, chunks, allEmbeddings);
                kbDoc.setChunkCount(chunks.size());
                kbDoc.setStatus("ready");
                log.info("Переиндексирован документ {} в KB {}: {} фрагментов", documentId, kbId, chunks.size());
            } catch (Exception e) {
                log.error("Переиндексация не удалась для документа {} в KB {}", documentId, kbId, e);
                kbDoc.setStatus("error");
                kbDoc.setErrorMessage(e.getMessage());
            }

            kbDoc = kbDocumentRepository.save(kbDoc);
            return KBMapper.toKBDocumentResponse(kbDoc);
        });
    }


    /**
     * Асинхронно разбивает, вычисляет эмбеддинги и сохраняет текст документа
     * как векторные данные базы знаний.
     * <p>
     * Выполняется на отдельном потоке (@Async). Обновляет статус документа
     * в процессе или при ошибке.
     *
     * @param kbId       UUID базы знаний
     * @param documentId UUID документа
     * @param kbDocId    UUID записи KBDocument
     */
    @Async
    public void indexDocumentAsync(UUID kbId, UUID documentId, UUID kbDocId) {
        transactionTemplate.execute(status -> {
            try {
                Document doc = documentRepository.findById(documentId)
                        .orElseThrow(() -> new NotFoundException("Документ не найден: " + documentId));
                if (doc.getExtractedText() == null || doc.getExtractedText().isBlank()) {
                    throw new IllegalStateException("Документ не содержит извлечённого текста");
                }

                List<String> chunks = textSplitter.split(doc.getExtractedText());
                if (chunks.isEmpty()) {
                    throw new IllegalStateException("Документ не дал фрагментов");
                }

                // эмбеддинги вычисляем пакетами по 50
                List<float[]> allEmbeddings = new ArrayList<>();
                for (int i = 0; i < chunks.size(); i += 50) {
                    List<String> batch = chunks.subList(i, Math.min(i + 50, chunks.size()));
                    List<float[]> batchEmbeddings = gigaChatClient.getEmbeddings(batch);
                    allEmbeddings.addAll(batchEmbeddings);
                }

                embeddingService.storeKBChunks(kbId, documentId, chunks, allEmbeddings);

                // Обновляем статус
                KBDocument kbDoc = kbDocumentRepository.findById(kbDocId)
                        .orElseThrow(() -> new IllegalStateException("KBDocument не найден: " + kbDocId));
                kbDoc.setChunkCount(chunks.size());
                kbDoc.setStatus("ready");
                kbDocumentRepository.save(kbDoc);

                log.info("Проиндексирован документ {} в KB {}: {} фрагментов", documentId, kbId, chunks.size());
                return true;
            } catch (Exception e) {
                log.error("Не удалось проиндексировать документ {} в KB {}", documentId, kbId, e);
                kbDocumentRepository.findById(kbDocId).ifPresent(kbDoc -> {
                    kbDoc.setStatus("error");
                    kbDoc.setErrorMessage(e.getMessage());
                    kbDocumentRepository.save(kbDoc);
                });
                return false;
            }
        });
    }

}
