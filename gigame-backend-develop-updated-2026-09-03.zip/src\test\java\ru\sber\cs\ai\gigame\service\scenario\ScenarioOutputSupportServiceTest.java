package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.service.KBService;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;
import ru.sber.cs.ai.gigame.utils.InMemoryFilePart;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Тесты доп. возможностей output-узла: нарастающий итог («накапливать»)
 * и реестр в базе знаний («в_базу_знаний»).
 */
@ExtendWith(MockitoExtension.class)
class ScenarioOutputSupportServiceTest {

    @Mock
    private ScenarioRunRepository scenarioRunRepository;
    @Mock
    private ScenarioRunStepRepository scenarioRunStepRepository;
    @Mock
    private ScenarioRepository scenarioRepository;
    @Mock
    private KBService kbService;

    @InjectMocks
    private ScenarioOutputSupportService service;

    private static ScenarioRun run(UUID id, UUID scenarioId) {
        ScenarioRun run = new ScenarioRun();
        run.setId(id);
        run.setScenarioId(scenarioId);
        return run;
    }

    private static ScenarioRunNode outputNode(String rules) {
        ScenarioRunNode node = mock(ScenarioRunNode.class);
        when(node.getRules()).thenReturn(rules);
        lenient().when(node.getId()).thenReturn("b9");
        return node;
    }

    @Test
    void accumulate_appendsCurrentRowsBelowPreviousRunRows() {
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        ScenarioRun previous = run(UUID.randomUUID(), scenarioId);
        ScenarioRunStep prevStep = new ScenarioRunStep();
        prevStep.setNodeId("b9");
        prevStep.setOutputData(Map.of("result", "[{\"договор\": \"партия-1\", \"сумма\": 100.50}]"));

        when(scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenarioId))
                .thenReturn(List.of(current, previous));
        when(scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(previous.getId()))
                .thenReturn(List.of(prevStep));

        String merged = service.accumulateIfConfigured(current, outputNode("{\"накапливать\": true}"),
                "[{\"договор\": \"партия-2\", \"сумма\": 200.00}]");

        // строки прошлого прогона ПЕРЕД новыми (новый результат — ниже первых)
        assertTrue(merged.indexOf("партия-1") < merged.indexOf("партия-2"));
        assertTrue(merged.trim().startsWith("["));
    }

    @Test
    void accumulate_withoutFlag_returnsResultUnchanged() {
        ScenarioRun current = run(UUID.randomUUID(), UUID.randomUUID());
        String result = "[{\"договор\": \"единственная партия\"}]";

        assertEquals(result, service.accumulateIfConfigured(current,
                outputNode("{\"колонки\": []}"), result));
        verify(scenarioRunRepository, never()).findByScenarioIdOrderByStartedAtDesc(any());
    }

    @Test
    void accumulate_withoutPreviousRuns_returnsResultUnchanged() {
        UUID scenarioId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        when(scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenarioId))
                .thenReturn(List.of(current));

        String result = "[{\"договор\": \"первая партия\"}]";
        assertEquals(result, service.accumulateIfConfigured(current,
                outputNode("{\"накапливать\": true}"), result));
    }

    @Test
    void saveToKnowledgeBase_uploadsResultAsTextDocument() {
        UUID scenarioId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        Scenario scenario = new Scenario();
        scenario.setUserId("USER1");
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.of(scenario));

        service.saveToKnowledgeBaseIfConfigured(current,
                outputNode("{\"в_базу_знаний\": \"" + kbId + "\"}"), "строки реестра");

        ArgumentCaptor<InMemoryFilePart> captor = ArgumentCaptor.forClass(InMemoryFilePart.class);
        verify(kbService).addDocumentToKB(eq("USER1"), eq(kbId), captor.capture());
        assertTrue(captor.getValue().filename().endsWith(".txt"));
        assertTrue(new String(captor.getValue().bytes(), StandardCharsets.UTF_8)
                .contains("строки реестра"));
    }

    @Test
    void saveToKnowledgeBase_errorDoesNotPropagate() {
        UUID scenarioId = UUID.randomUUID();
        UUID kbId = UUID.randomUUID();
        ScenarioRun current = run(UUID.randomUUID(), scenarioId);
        when(scenarioRepository.findById(scenarioId)).thenReturn(Optional.empty());
        doThrow(new RuntimeException("БЗ недоступна"))
                .when(kbService).addDocumentToKB(any(), eq(kbId), any());

        // ошибка сохранения реестра не роняет прогон
        assertDoesNotThrow((() -> service.saveToKnowledgeBaseIfConfigured(current,
                outputNode("{\"в_базу_знаний\": \"" + kbId + "\"}"), "строки")));
    }
}
