package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Тесты кодовой выверки чисел по эталону и слоя записи поверх исходной формы.
 */
class ScenarioResultToXlsxEnrichTest {

    private static final String CHECK_RULES =
            "{\"сверка_чисел\": {\"из_узла\": \"Суммы\", \"колонки\": [\"к9\"]}}";

    private static Map<String, Object> row(String key, Object value) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put(key, value);
        return map;
    }

    @Test
    void restoresLostDigitFromSingleReference() {
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к9", "194539,52")));

        ScenarioResultToXlsx.fixNumbersAgainstReference(data, CHECK_RULES,
                Set.of("1945390.52"));

        assertEquals("1945390.52", data.get(0).get("к9"));
    }

    @Test
    void keepsValueWhenSeveralCandidates() {
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к9", "194539,52")));

        ScenarioResultToXlsx.fixNumbersAgainstReference(data, CHECK_RULES,
                Set.of("1945390.52", "1945439.52"));

        assertEquals("194539,52", data.get(0).get("к9"));
    }

    @Test
    void canonicalMatchIsNotTouched() {
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к9", "3845539,4")));

        ScenarioResultToXlsx.fixNumbersAgainstReference(data, CHECK_RULES,
                Set.of("3845539.40"));

        assertEquals("3845539,4", data.get(0).get("к9"));
    }

    @Test
    void enrichKeepsEveryFormLineAndStubsUnmatched() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"(5\\\\d{6})\", \"ключ_данных\": \"к5\", "
                + "\"колонка_исходной\": \"к0\", \"заглушки\": {\"к9\": \"Нет данных\"}}}";
        List<Map<String, Object>> data = new ArrayList<>();
        Map<String, Object> matched = new LinkedHashMap<>();
        matched.put("к5", "5350904 (этап 1)");
        matched.put("к9", "6747168.30");
        data.add(matched);
        String formLines = "Спецификация 5350904 от 04.06.2025\nСпецификация 5311130 от 25.04.2025";

        List<Map<String, Object>> out =
                ScenarioResultToXlsx.enrichAgainstForm(data, rules, formLines);

        assertEquals(2, out.size());
        assertEquals("6747168.30", out.get(0).get("к9"));
        assertEquals("Нет данных", out.get(1).get("к9"));
        assertEquals("Спецификация 5311130 от 25.04.2025", out.get(1).get("к0"));
    }

    @Test
    void enrichAppendsDataRowsMissingInForm() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Форма\", "
                + "\"ключ_регекс\": \"(5\\\\d{6})\", \"ключ_данных\": \"к5\", "
                + "\"колонка_исходной\": \"к0\"}}";
        List<Map<String, Object>> data = new ArrayList<>(List.of(row("к5", "5242489")));

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(
                data, rules, "Спецификация 5311130 от 25.04.2025");

        assertEquals(2, out.size());
        assertEquals("нет в исходной форме", out.get(1).get("к0"));
    }
}
