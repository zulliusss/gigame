package ru.sber.cs.ai.gigame.service.scenario;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.utils.JsonCalcUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Утилитарный класс для генерации XLSX-файлов из JSON-данных.
 * <p>
 * Преобразует массив JSON-объектов в таблицу Excel, где ключи объектов становятся колонками,
 * а каждый объект — отдельной строкой.
 */
@Component
public class ScenarioResultToXlsx {

    private static final Logger LOG = LoggerFactory.getLogger(ScenarioResultToXlsx.class);
    private static final String MARKDOWN_FENCE = "```";

    /** Числовая строка с десятичной точкой: суммы вида 986724.24 (целые не трогаем — номера, ИНН). */
    private static final Pattern DECIMAL_STRING = Pattern.compile("-?\\d+\\.\\d+");

    private static final ObjectMapper objectMapper = new ObjectMapper();

    private ScenarioResultToXlsx() {
        // утилитарный класс
    }

    public static ResponseEntity<Resource> generateXlsx(UUID runId, ScenarioRunDetailResponse runDetail) {
        var stepsSize = runDetail.steps().size();
        if (stepsSize >= 2) {
            var secondToLastStep = runDetail.steps().get(stepsSize - 2);
            var resource = new ByteArrayResource(jsonToXlsx(secondToLastStep.outputData().result()));
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"result_" + runId.toString().substring(0, 8) + ".xlsx\"")
                    .body(resource);
        }
        return null;
    }

    /**
     * Генерирует XLSX-файл из JSON-строки и возвращает его как {@link ResponseEntity}.
     *
     * @param jsonData JSON-строка с данными для экспорта
     * @return ResponseEntity с XLSX-файлом
     */
    public static byte[] jsonToXlsx(String jsonData) {
        return jsonToXlsx(jsonData, null);
    }

    /**
     * Генерирует XLSX по данным и (опционально) шаблону формы из конфига output-узла.
     * <p>
     * Шаблон — JSON в {@code data.rules} узла:
     * <pre>
     * {"лист": "Данные",
     *  "колонки": [{"ключ": "исполнитель", "заголовок": "Наименование…", "группа": "Основные данные"}, …]}
     * </pre>
     * При наличии непустого массива {@code колонки} порядок и состав колонок фиксируются:
     * значение ячейки берётся из строки данных по {@code ключ} (нет ключа — пустая ячейка),
     * лишние ключи данных игнорируются. Если хотя бы у одной колонки задана {@code группа},
     * строится двухуровневая шапка (группы объединяются по соседним одинаковым значениям).
     * Без шаблона колонки формируются динамически из ключей JSON (прежнее поведение).
     *
     * @param jsonData  JSON-строка с данными (массив объектов или объект)
     * @param rulesJson конфиг шаблона из output-узла (может быть null/пустым/"[]")
     * @return содержимое XLSX-файла
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson) {
        return jsonToXlsx(jsonData, rulesJson, null);
    }

    /**
     * Генерация с кодовой выверкой чисел: числа в колонках из конфига
     * {@code "сверка_чисел": {"колонки": ["к8"]}} проверяются на членство в
     * {@code referenceNumbers} (эталон, извлечённый кодом из документов);
     * искажённое моделью значение заменяется единственным подходящим эталоном.
     * Деньги, прошедшие через LLM, теряют разряды — эталон из кода надёжнее.
     *
     * @param referenceNumbers эталонные числа в записи с точкой (может быть null)
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson, Set<String> referenceNumbers) {
        return jsonToXlsx(jsonData, rulesJson, referenceNumbers, null);
    }

    /**
     * Генерация со слоем записи ПОВЕРХ исходной формы участника: конфиг
     * {@code "обогащение_формы"} (см. {@link #enrichAgainstForm}) сопоставляет
     * строки данных со строками исходной таблицы по ключу; несопоставленные
     * строки формы попадают в выход с заглушками, а не теряются.
     *
     * @param enrichmentLines строки исходной формы из узла-донора (может быть null)
     */
    public static byte[] jsonToXlsx(String jsonData, String rulesJson, Set<String> referenceNumbers,
                                    String enrichmentLines) {
        try {
            // Извлекаем только JSON-часть (в {} или []) из строки
            String cleanJson = extractJson(jsonData);

            // Парсим JSON — ожидаем массив объектов
            List<Map<String, Object>> dataList = parseJsonToList(cleanJson);
            fixNumbersAgainstReference(dataList, rulesJson, referenceNumbers);
            dataList = enrichAgainstForm(dataList, rulesJson, enrichmentLines);

            XlsxTemplate template = XlsxTemplate.parse(rulesJson);
            if (dataList.isEmpty()) {
                if (template != null) {
                    // пустой результат при заданном шаблоне — файл с одной шапкой,
                    // а не ошибка узла (пример: нет ни одного требования к продукции)
                    return createTemplatedXlsx(template, dataList);
                }
                throw new FileException("Нет данных для экспорта");
            }

            if (template != null) {
                return createTemplatedXlsx(template, dataList);
            }

            // Собираем все уникальные ключи (колонки) в порядке появления
            Set<String> allKeys = new LinkedHashSet<>();
            for (Map<String, Object> item : dataList) {
                allKeys.addAll(item.keySet());
            }

            // Создаем workbook и обрабатываем данные
            return createXlsx(allKeys, dataList);
        } catch (Exception e) {
            throw new FileException("Ошибка при генерации XLSX-файла", e);
        }
    }

    /**
     * Выверка чисел по эталону из кода. Для каждого ключа из
     * {@code "сверка_чисел".колонки}: значение, отсутствующее в эталонном
     * множестве, заменяется эталоном, из цифр которого значение получается
     * удалением от 1 до 3 цифр (модель отбрасывает разряды при переписывании) —
     * только при ЕДИНСТВЕННОМ кандидате, иначе значение не трогается.
     */
    @SuppressWarnings("unchecked")
    static void fixNumbersAgainstReference(List<Map<String, Object>> dataList,
                                           String rulesJson, Set<String> referenceNumbers) {
        if (referenceNumbers == null || referenceNumbers.isEmpty()
                || rulesJson == null || rulesJson.isBlank() || dataList == null) {
            return;
        }
        List<String> keys = checkColumns(rulesJson);
        if (keys == null) {
            return;
        }
        Map<String, String> refDigits = new LinkedHashMap<>();
        Set<String> canonRefs = new LinkedHashSet<>();
        for (String ref : referenceNumbers) {
            refDigits.put(ref, ref.replaceAll("\\D", ""));
            canonRefs.add(canonical(ref));
        }
        for (Map<String, Object> row : dataList) {
            for (String key : keys) {
                fixRowValue(row, key, referenceNumbers, refDigits, canonRefs);
            }
        }
    }

    /**
     * Колонки для сверки из rules ({@code "сверка_чисел": {"колонки": [...]}}).
     *
     * @param rulesJson правила выходного узла
     * @return список ключей колонок или {@code null}, если сверка не настроена
     */
    @SuppressWarnings("unchecked")
    private static List<String> checkColumns(String rulesJson) {
        try {
            Map<String, Object> rules = objectMapper.readValue(rulesJson, new TypeReference<>() { });
            Object check = rules.get("сверка_чисел");
            if (!(check instanceof Map<?, ?> checkMap)
                    || !(((Map<String, Object>) checkMap).get("колонки") instanceof List<?> cols)) {
                return null;
            }
            return cols.stream().map(String::valueOf).toList();
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    /**
     * Канонизирует числовую запись: у дробной части срезаются хвостовые нули
     * («1945390.20» → «1945390.2») — они маскируют потерю разряда.
     *
     * @param value число в записи с точкой
     * @return канонизированная запись
     */
    private static String canonical(String value) {
        return value.contains(".")
                ? value.replaceAll("0+$", "").replaceAll("\\.$", "")
                : value;
    }

    /**
     * Чинит одно значение строки: если оно отсутствует среди эталонов и по цифрам
     * восстанавливается до единственного эталона (потеря 1-3 разрядов), значение
     * заменяется этим эталоном.
     *
     * @param row              строка данных
     * @param key              ключ проверяемой колонки
     * @param referenceNumbers эталонные числа
     * @param refDigits        эталон → только его цифры
     * @param canonRefs        канонизированные эталоны
     */
    private static void fixRowValue(Map<String, Object> row, String key,
                                    Set<String> referenceNumbers,
                                    Map<String, String> refDigits, Set<String> canonRefs) {
        Object raw = row.get(key);
        if (raw == null) {
            return;
        }
        String value = String.valueOf(raw).replace(" ", "").replace(",", ".");
        if (!value.matches("\\d+(\\.\\d+)?")) {
            return;
        }
        String canon = canonical(value);
        // канонизированное совпадение («3845539.4» и эталон «3845539.40» —
        // одно число, разница только в формате) — значение верное, не трогаем
        if (referenceNumbers.contains(value) || canonRefs.contains(canon)) {
            return;
        }
        String candidate = singleCandidate(canon, refDigits);
        if (candidate != null) {
            LOG.info("Сверка чисел: {} -> {} (колонка {})", value, candidate, key);
            row.put(key, candidate);
        }
    }

    /**
     * Единственный эталон, из цифр которого значение получается удалением
     * от 1 до 3 цифр; при нескольких кандидатах — {@code null} (не трогаем).
     *
     * @param canon     канонизированное значение
     * @param refDigits эталон → только его цифры
     * @return эталон-кандидат или {@code null}
     */
    private static String singleCandidate(String canon, Map<String, String> refDigits) {
        String valueDigits = canon.replaceAll("\\D", "");
        String candidate = null;
        for (Map.Entry<String, String> ref : refDigits.entrySet()) {
            int missing = ref.getValue().length() - valueDigits.length();
            // missing == 0: те же цифры, сдвинута запятая («3845539.4» vs
            // «384553.94») — чиним только между дробными записями, чтобы
            // сумма не совпала с целым эталоном (номером спецификации)
            if (missing == 0 && (!canon.contains(".") || !ref.getKey().contains("."))) {
                continue;
            }
            if (missing < 0 || missing > 3 || !isSubsequence(valueDigits, ref.getValue())) {
                continue;
            }
            if (candidate != null) {
                return null; // неоднозначно — не трогаем
            }
            candidate = ref.getKey();
        }
        return candidate;
    }

    /**
     * Слой записи поверх исходной формы участника. Конфиг в rules:
     * <pre>
     * "обогащение_формы": {
     *   "из_узла": "<метка узла со строками исходной формы>",
     *   "ключ_регекс": "(5\\d{6})",     — как извлечь ключ из строки формы
     *   "ключ_данных": "к5",             — где ключ в строках данных
     *   "колонка_исходной": "к0",        — ключ колонки с исходной строкой формы
     *   "заглушки": {"к9": "0", "к10": "Нет данных"}
     * }
     * </pre>
     * Выход упорядочен ПО ИСХОДНОЙ ФОРМЕ: каждая её строка даёт строку выхода
     * (сопоставленную с данными по ключу или заглушку); строки данных, не
     * нашедшие пары в форме, добавляются в конец. Ничего не затирается.
     */
    @SuppressWarnings("unchecked")
    static List<Map<String, Object>> enrichAgainstForm(List<Map<String, Object>> dataList,
                                                       String rulesJson, String enrichmentLines) {
        if (enrichmentLines == null || enrichmentLines.isBlank()
                || rulesJson == null || rulesJson.isBlank()) {
            return dataList;
        }
        Map<String, Object> cfg = enrichConfig(rulesJson);
        if (cfg == null) {
            return dataList;
        }
        Pattern keyPattern = compileOrNull(cfg, "ключ_регекс", "(\\d{7})");
        // в данных ключ обычно без окружения («5374245 (этап №1)») — свой шаблон
        Pattern dataKeyPattern = compileOrNull(cfg, "ключ_регекс_данных",
                String.valueOf(cfg.getOrDefault("ключ_регекс", "(\\d{7})")));
        if (keyPattern == null || dataKeyPattern == null) {
            return dataList;
        }
        String dataKey = String.valueOf(cfg.getOrDefault("ключ_данных", "к5"));
        String sourceColumn = String.valueOf(cfg.getOrDefault("колонка_исходной", "к0"));
        Map<String, Object> stubs = cfg.get("заглушки") instanceof Map<?, ?> stubMap
                ? (Map<String, Object>) stubMap : Map.of();

        // строки данных, разложенные по ключу (очередь на ключ — актов может быть
        // несколько на одну спецификацию)
        Map<String, ArrayDeque<Map<String, Object>>> byKey = new LinkedHashMap<>();
        List<Map<String, Object>> unkeyed = new ArrayList<>();
        for (Map<String, Object> row : dataList) {
            Matcher m = dataKeyPattern.matcher(String.valueOf(row.getOrDefault(dataKey, "")));
            if (m.find()) {
                byKey.computeIfAbsent(m.group(m.groupCount() >= 1 ? 1 : 0),
                        k -> new ArrayDeque<>()).add(row);
            } else {
                unkeyed.add(row);
            }
        }
        List<Map<String, Object>> out =
                overlayFormLines(enrichmentLines, keyPattern, byKey, dataKey, sourceColumn, stubs);
        appendUnmatched(out, byKey, sourceColumn, unkeyed);
        return out.isEmpty() ? dataList : out;
    }

    /**
     * Конфиг обогащения из rules ({@code "обогащение_формы": {...}}).
     *
     * @param rulesJson правила выходного узла
     * @return конфиг или {@code null}, если обогащение не настроено
     */
    @SuppressWarnings("unchecked")
    private static Map<String, Object> enrichConfig(String rulesJson) {
        try {
            Map<String, Object> rules = objectMapper.readValue(rulesJson, new TypeReference<>() { });
            return rules.get("обогащение_формы") instanceof Map<?, ?> raw
                    ? (Map<String, Object>) raw : null;
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    /**
     * Компилирует regex из конфига; {@code null} при некорректном шаблоне.
     *
     * @param cfg          конфиг обогащения
     * @param key          ключ параметра с шаблоном
     * @param defaultValue шаблон по умолчанию
     * @return скомпилированный шаблон или {@code null}
     */
    private static Pattern compileOrNull(Map<String, Object> cfg, String key, String defaultValue) {
        try {
            return Pattern.compile(String.valueOf(cfg.getOrDefault(key, defaultValue)));
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Строит выход ПО СТРОКАМ ИСХОДНОЙ ФОРМЫ: каждая строка формы даёт строку
     * выхода — сопоставленную с данными по ключу либо заглушку.
     *
     * @param enrichmentLines строки исходной формы
     * @param keyPattern      шаблон ключа в строке формы
     * @param byKey           строки данных по ключу (очереди)
     * @param dataKey         ключ колонки с ключом в данных
     * @param sourceColumn    ключ колонки исходной строки формы
     * @param stubs           значения-заглушки для несопоставленных строк
     * @return строки выхода в порядке исходной формы
     */
    private static List<Map<String, Object>> overlayFormLines(
            String enrichmentLines, Pattern keyPattern,
            Map<String, ArrayDeque<Map<String, Object>>> byKey,
            String dataKey, String sourceColumn, Map<String, Object> stubs) {
        List<Map<String, Object>> out = new ArrayList<>();
        int stubbed = 0;
        int matched = 0;
        for (String line : enrichmentLines.split("\\r?\\n")) {
            if (line.isBlank()) {
                continue;
            }
            Matcher m = keyPattern.matcher(line);
            if (!m.find()) {
                continue;
            }
            String key = m.group(m.groupCount() >= 1 ? 1 : 0);
            ArrayDeque<Map<String, Object>> queue = byKey.get(key);
            Map<String, Object> row;
            if (queue != null && !queue.isEmpty()) {
                row = new LinkedHashMap<>(queue.poll());
                matched++;
            } else {
                row = new LinkedHashMap<>();
                row.put(dataKey, key);
                stubs.forEach(row::put);
                stubbed++;
            }
            row.put(sourceColumn, line.trim());
            out.add(row);
        }
        LOG.info("Обогащение формы: сопоставлено {}, заглушек {}", matched, stubbed);
        return out;
    }

    /**
     * Добавляет в конец выхода строки данных, не нашедшие пары в форме,
     * и строки без ключа.
     *
     * @param out          строки выхода
     * @param byKey        остатки строк данных по ключу
     * @param sourceColumn ключ колонки исходной строки формы
     * @param unkeyed      строки данных без ключа
     */
    private static void appendUnmatched(List<Map<String, Object>> out,
                                        Map<String, ArrayDeque<Map<String, Object>>> byKey,
                                        String sourceColumn, List<Map<String, Object>> unkeyed) {
        int outside = 0;
        for (ArrayDeque<Map<String, Object>> queue : byKey.values()) {
            for (Map<String, Object> r : queue) {
                Map<String, Object> row = new LinkedHashMap<>(r);
                row.put(sourceColumn, "нет в исходной форме");
                out.add(row);
                outside++;
            }
        }
        out.addAll(unkeyed);
        LOG.info("Обогащение формы: вне формы {}, без ключа {}", outside, unkeyed.size());
    }

    /** {@code true}, если {@code sub} — подпоследовательность {@code full} (порядок цифр сохранён). */
    private static boolean isSubsequence(String sub, String full) {
        int i = 0;
        for (int j = 0; j < full.length() && i < sub.length(); j++) {
            if (sub.charAt(i) == full.charAt(j)) {
                i++;
            }
        }
        return i == sub.length();
    }

    /** Шаблон формы таблицы из конфига output-узла. */
    record XlsxTemplate(String sheetName, List<XlsxColumn> columns, boolean highlightSections) {

        /**
         * Колонка шаблона. Обычная колонка задаётся ключом; ДИНАМИЧЕСКАЯ —
         * префиксом ключа ({@code "ключ_префикс"}): она разворачивается в
         * отдельную колонку на КАЖДЫЙ фактический ключ данных с этим префиксом
         * (заголовок = "заголовок_префикс" + суффикс ключа). Так форма получает
         * по колонке на каждую технологию закупки, сколько бы их ни было.
         */
        record XlsxColumn(String key, String title, String group, String keyPrefix,
                          Map<String, String> highlight) {
            @SuppressWarnings("unused")
            XlsxColumn(String key, String title, String group) {
                this(key, title, group, "", Map.of());
            }
            @SuppressWarnings("unused")
            XlsxColumn(String key, String title, String group, String keyPrefix) {
                this(key, title, group, keyPrefix, Map.of());
            }

            boolean isDynamic() {
                return !keyPrefix.isBlank();
            }

            /** @return имя цвета подсветки для значения ячейки или {@code null} */
            String highlightColor(Object value) {
                if (highlight.isEmpty() || value == null) {
                    return null;
                }
                String text = value.toString().strip();
                for (Map.Entry<String, String> entry : highlight.entrySet()) {
                    if (entry.getKey().equalsIgnoreCase(text)) {
                        return entry.getValue();
                    }
                }
                return null;
            }
        }

        /** @return шаблон или {@code null}, если rules не содержит непустой массив "колонки" */
        static XlsxTemplate parse(String rulesJson) {
            if (rulesJson == null || rulesJson.isBlank() || rulesJson.trim().startsWith("[")) {
                return null;
            }
            try {
                Map<String, Object> rules = objectMapper.readValue(rulesJson, new TypeReference<>() {
                });
                List<XlsxColumn> columns = parseColumns(rules.get("колонки"));
                if (columns.isEmpty()) {
                    return null;
                }
                String sheet = stringOrEmpty(rules.get("лист"));
                boolean highlight = Boolean.parseBoolean(stringOrEmpty(rules.get("выделять_секции")));
                return new XlsxTemplate(sheet.isBlank() ? "Данные" : sheet, columns, highlight);
            } catch (JsonProcessingException e) {
                // rules другого узла/формата (например, calc) — работаем без шаблона
                return null;
            }
        }

        /**
         * Разворачивает динамические колонки по фактическим ключам данных:
         * для колонки с "ключ_префикс" создаётся по колонке на каждый
         * уникальный ключ с этим префиксом (в порядке появления в данных).
         *
         * @param dataList строки данных
         * @return список только конкретных колонок
         */
        List<XlsxColumn> expandColumns(List<Map<String, Object>> dataList) {
            List<XlsxColumn> expanded = new ArrayList<>();
            for (XlsxColumn column : columns) {
                if (!column.isDynamic()) {
                    expanded.add(column);
                    continue;
                }
                Set<String> matched = new LinkedHashSet<>();
                for (Map<String, Object> item : dataList) {
                    for (String key : item.keySet()) {
                        if (key.startsWith(column.keyPrefix())) {
                            matched.add(key);
                        }
                    }
                }
                for (String key : matched) {
                    String suffix = key.substring(column.keyPrefix().length());
                    expanded.add(new XlsxColumn(key, column.title() + suffix, column.group(),
                            "", column.highlight()));
                }
            }
            return expanded;
        }

        /** Разбирает значение ключа "колонки"; невалидные элементы пропускаются. */
        private static List<XlsxColumn> parseColumns(Object columnsRaw) {
            if (!(columnsRaw instanceof List<?> columnsList)) {
                return List.of();
            }
            List<XlsxColumn> columns = new ArrayList<>();
            for (Object item : columnsList) {
                XlsxColumn column = parseColumn(item);
                if (column != null) {
                    columns.add(column);
                }
            }
            return columns;
        }

        /** @return колонка (обычная или динамическая) или {@code null}, если элемент невалиден */
        @SuppressWarnings("unchecked")
        private static XlsxColumn parseColumn(Object item) {
            if (!(item instanceof Map<?, ?> col)) {
                return null;
            }
            Map<String, Object> colMap = (Map<String, Object>) col;
            String key = stringOrEmpty(colMap.get("ключ"));
            if (key.isBlank()) {
                return parsePrefixColumn(item);
            }
            String title = stringOrEmpty(colMap.get("заголовок"));
            return new XlsxColumn(key, title.isBlank() ? key : title,
                    stringOrEmpty(colMap.get("группа")), "", parseHighlight(colMap.get("подсветка")));
        }

        /** Разбирает карту подсветки «значение → цвет» из ключа "подсветка". */
        private static Map<String, String> parseHighlight(Object raw) {
            if (!(raw instanceof Map<?, ?> map)) {
                return Map.of();
            }
            Map<String, String> highlight = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (entry.getKey() != null && entry.getValue() != null) {
                    highlight.put(entry.getKey().toString(), entry.getValue().toString());
                }
            }
            return highlight;
        }

        /** @return динамическая колонка или {@code null}, если нет "ключ_префикс" */
        @SuppressWarnings("unchecked")
        private static XlsxColumn parsePrefixColumn(Object item) {
            if (!(item instanceof Map<?, ?> col)) {
                return null;
            }
            Map<String, Object> colMap = (Map<String, Object>) col;
            String keyPrefix = stringOrEmpty(colMap.get("ключ_префикс"));
            if (keyPrefix.isBlank()) {
                return null;
            }
            // префикс заголовка не стрипится: хвостовой пробел («Технология: ») значим
            Object titleRaw = colMap.get("заголовок_префикс");
            String titlePrefix = titleRaw == null ? "" : titleRaw.toString();
            return new XlsxColumn("", titlePrefix, stringOrEmpty(colMap.get("группа")),
                    keyPrefix, parseHighlight(colMap.get("подсветка")));
        }

        private static String stringOrEmpty(Object value) {
            return value == null ? "" : value.toString().strip();
        }

        boolean hasGroups() {
            return columns.stream().anyMatch(c -> !c.group().isBlank());
        }
    }

    /**
     * Создаёт XLSX с фиксированной формой: порядок колонок из шаблона,
     * опциональная двухуровневая шапка (строка групп + строка заголовков).
     */
    private static byte[] createTemplatedXlsx(XlsxTemplate template, List<Map<String, Object>> dataList) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet(template.sheetName());

            List<XlsxTemplate.XlsxColumn> columns = template.expandColumns(dataList);
            XlsxTemplate resolved = new XlsxTemplate(template.sheetName(), columns,
                    template.highlightSections());

            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);

            int headerRows = createTemplateHeader(sheet, resolved, headerStyle);
            populateDataRows(sheet, resolved, dataList, headerRows, headerStyle, dataStyle);

            autoResizeColumns(sheet, columns);

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            throw new FileException("Ошибка создания Excel файла ", e);
        }
    }

    /**
     * Авто-ширина для всех колонок листа.
     */
    private static void autoResizeColumns(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns) {
        for (int i = 0; i < columns.size(); i++) {
            sheet.autoSizeColumn(i);
        }
    }

    /**
     * Заполняет строки данными: для каждой строки создаёт ячейки по колонкам шаблона,
     * применяет стиль секции (если включена подсветка секций)
     * и подсветку значений по конфигу.
     */
    private static void populateDataRows(Sheet sheet, XlsxTemplate template,
                                         List<Map<String, Object>> dataList,
                                         int startRow,
                                         CellStyle headerStyle, CellStyle dataStyle) {
        List<XlsxTemplate.XlsxColumn> columns = template.columns();
        Map<String, CellStyle> highlightStyles = new LinkedHashMap<>();
        int rowNum = startRow;

        for (Map<String, Object> item : dataList) {
            Row row = sheet.createRow(rowNum++);
            boolean section = template.highlightSections() && isSectionRow(columns, item);
            populateRow(row, columns, item, section, headerStyle, dataStyle, highlightStyles);
        }
    }

    /**
     * Заполняет одну строку данными: проходит по колонкам, записывает значения,
     * применяет стиль (секция / обычная) и опциональную цветовую подсветку.
     */
    private static void populateRow(Row row, List<XlsxTemplate.XlsxColumn> columns,
                                    Map<String, Object> item,
                                    boolean section,
                                    CellStyle headerStyle, CellStyle dataStyle,
                                    Map<String, CellStyle> highlightStyles) {
        CellStyle defaultStyle = section ? headerStyle : dataStyle;

        for (int i = 0; i < columns.size(); i++) {
            Cell cell = row.createCell(i);
            Object value = item.get(columns.get(i).key());
            setCellSmart(cell, value);
            cell.setCellStyle(resolveCellStyle(cell, columns.get(i), value, defaultStyle, highlightStyles));
        }
    }

    /**
     * Определяет стиль ячейки: базовый стиль + цветовая подсветка, если есть совпадение.
     */
    private static CellStyle resolveCellStyle(Cell cell, XlsxTemplate.XlsxColumn column,
                                              Object value,
                                              CellStyle defaultStyle,
                                              Map<String, CellStyle> highlightStyles) {
        String colorName = column.highlightColor(value);
        if (colorName == null) {
            return defaultStyle;
        }
        CellStyle colored = highlightStyle(cell.getSheet().getWorkbook(), highlightStyles, colorName);
        return colored == null ? defaultStyle : colored;
    }

    /**
     * Строка-секция: значение есть только в первой колонке (заголовок раздела
     * внутри таблицы, например «Квалификационные требования»).
     *
     * @param columns колонки таблицы
     * @param item    строка данных
     * @return {@code true}, если строка — заголовок секции
     */
    private static boolean isSectionRow(List<XlsxTemplate.XlsxColumn> columns, Map<String, Object> item) {
        if (columns.size() < 2) {
            return false;
        }
        Object first = item.get(columns.get(0).key());
        if (first == null || first.toString().isBlank()) {
            return false;
        }
        for (int i = 1; i < columns.size(); i++) {
            Object value = item.get(columns.get(i).key());
            if (value != null && !value.toString().isBlank()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Строит шапку по шаблону: при наличии групп — двухуровневую
     * (строка групп с объединением соседних одинаковых + строка заголовков).
     *
     * @return количество строк шапки
     */
    private static int createTemplateHeader(Sheet sheet, XlsxTemplate template, CellStyle headerStyle) {
        List<XlsxTemplate.XlsxColumn> columns = template.columns();
        boolean twoLevel = template.hasGroups();
        if (twoLevel) {
            createGroupRow(sheet, columns, headerStyle);
        }
        Row headerRow = sheet.createRow(twoLevel ? 1 : 0);
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns.get(i).title());
            cell.setCellStyle(headerStyle);
        }
        return twoLevel ? 2 : 1;
    }

    /** Строка групп (строка 0) с объединением соседних колонок одинаковой непустой группы. */
    private static void createGroupRow(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns, CellStyle headerStyle) {
        Row groupRow = sheet.createRow(0);
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = groupRow.createCell(i);
            cell.setCellValue(columns.get(i).group());
            cell.setCellStyle(headerStyle);
        }
        mergeAdjacentGroups(sheet, columns);
    }

    /** Объединяет в строке 0 соседние колонки с одинаковой непустой группой. */
    private static void mergeAdjacentGroups(Sheet sheet, List<XlsxTemplate.XlsxColumn> columns) {
        int start = 0;
        for (int i = 1; i <= columns.size(); i++) {
            boolean sameGroup = i < columns.size()
                    && !columns.get(i).group().isBlank()
                    && columns.get(i).group().equals(columns.get(start).group());
            if (!sameGroup) {
                if (i - start > 1 && !columns.get(start).group().isBlank()) {
                    sheet.addMergedRegion(new CellRangeAddress(0, 0, start, i - 1));
                }
                start = i;
            }
        }
    }

    /**
     * Создает XLSX-ресурс из собранных данных.
     * Вынесено в отдельный метод для избежания вложенных try блоков.
     *
     * @param allKeys  набор уникальных ключей-колонок
     * @param dataList список данных для экспорта
     * @return ResponseEntity с XLSX-файлом
     */
    private static byte[] createXlsx(Set<String> allKeys, List<Map<String, Object>> dataList) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Данные");

            // Стили
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle dataStyle = createDataStyle(workbook);

            // Заголовки — все ключи как колонки
            Row headerRow = sheet.createRow(0);
            int colIndex = 0;
            for (String key : allKeys) {
                Cell cell = headerRow.createCell(colIndex++);
                cell.setCellValue(key);
                cell.setCellStyle(headerStyle);
            }

            // Заполняем данные — каждая строка = один объект
            int rowNum = 1;
            for (Map<String, Object> item : dataList) {
                Row row = sheet.createRow(rowNum++);
                colIndex = 0;
                for (String key : allKeys) {
                    Cell cell = row.createCell(colIndex++);
                    setCellSmart(cell, item.get(key));
                    cell.setCellStyle(dataStyle);
                }
            }

            // Автоширина колонок
            for (int i = 0; i < allKeys.size(); i++) {
                sheet.autoSizeColumn(i);
            }

            // Записываем в байтовый массив
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);

            return outputStream.toByteArray();

        } catch (IOException e) {
            throw new FileException("Ошибка создания Excel файла ", e);
        }
    }

    /**
     * Парсит JSON-строку в список Map. Поддерживает как массив объектов, так и одиночный объект.
     */
    private static List<Map<String, Object>> parseJsonToList(String json) {
        String trimmed = json.trim();
        if (!trimmed.startsWith("[") && !trimmed.startsWith("{")) {
            throw new FileException("Неверный формат JSON: ожидается объект или массив");
        }
        try {
            // Массив объектов парсим как есть
            if (trimmed.startsWith("[")) {
                return objectMapper.readValue(json, new TypeReference<>() {
                });
            }
            // Одиночный объект оборачиваем в список
            Map<String, Object> singleObject = objectMapper.readValue(json, new TypeReference<>() {
            });
            return Collections.singletonList(singleObject);
        } catch (JsonProcessingException e) {
            throw new FileException("Неверный формат JSON: ожидается объект или массив");
        }
    }

    /**
     * Записывает значение в ячейку с сохранением числового типа: числа и строки
     * вида 986724.24 становятся ЧИСЛОВЫМИ ячейками (Excel показывает их по локали
     * пользователя — с запятой в русской — и они участвуют в формулах и аналитике),
     * остальное — текстом. Целочисленные строки остаются текстом: это обычно
     * номера договоров и ИНН, а не величины.
     *
     * @param cell  ячейка
     * @param value значение (может быть {@code null})
     */
    private static void setCellSmart(Cell cell, Object value) {
        if (value instanceof Number number) {
            cell.setCellValue(number.doubleValue());
            return;
        }
        if (value instanceof String str && DECIMAL_STRING.matcher(str.strip()).matches()) {
            cell.setCellValue(Double.parseDouble(str.strip()));
            return;
        }
        cell.setCellValue(formatValue(value));
    }

    /**
     * Форматирует значение для записи в ячейку.
     * Массивы и объекты преобразуются в JSON-строку.
     */
    private static String formatValue(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof String str) {
            return str;
        }
        if (value instanceof Boolean) {
            return value.toString();
        }
        if (value instanceof Number number) {
            // Double.toString даёт научную запись (1.21377795E7) — в ячейке нужно 12137779.5
            return new java.math.BigDecimal(number.toString()).stripTrailingZeros().toPlainString();
        }
        if (value instanceof List || value instanceof Map) {
            try {
                return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(value);
            } catch (Exception e) {
                return value.toString();
            }
        }
        return value.toString();
    }

    /**
     * Извлекает JSON-объект или массив из строки, отбрасывая лишний текст.
     * Видимость package-private: используется и накоплением результата
     * ({@link ScenarioOutputSupportService}).
     */
    static String extractJson(String raw) {
        if (raw == null || raw.isBlank()) {
            return "[]";
        }

        // Сначала пробуем убрать markdown-блоки ```json ... ``` или ``` ... ```
        String sanitized = stripMarkdownFence(raw.trim());
        sanitized = sanitized.replace("\n", "").replace("\r", "");
        // Извлекаем первый JSON-объект или массив
        return firstJsonBlock(sanitized);
    }

    /**
     * Содержимое markdown-блока ```json ... ``` (или ``` ... ```), если он есть.
     * Закрывающая тройка учитывается только в самом конце строки; без неё
     * берётся всё после открывающей. Без блока строка возвращается как есть.
     */
    private static String stripMarkdownFence(String text) {
        int fence = text.indexOf(MARKDOWN_FENCE);
        if (fence < 0) {
            return text;
        }
        int start = fence + MARKDOWN_FENCE.length();
        if (text.startsWith("json", start)) {
            start += 4;
        }
        int end = text.length();
        if (text.endsWith(MARKDOWN_FENCE) && end - MARKDOWN_FENCE.length() >= start) {
            end -= MARKDOWN_FENCE.length();
        }
        return text.substring(start, end).trim();
    }

    /** Первый сбалансированный JSON-объект или массив в строке; "[]", если его нет. */
    private static String firstJsonBlock(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '{' || c == '[') {
                int end = JsonCalcUtils.balancedEnd(text, i);
                if (end >= 0) {
                    return text.substring(i, end + 1);
                }
            }
        }
        return "[]";
    }

    /**
     * Создает стиль для заголовков таблицы.
     */
    private static CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 12);
        style.setFont(font);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    /**
     * Создает стиль для ячеек с данными.
     */
    private static CellStyle createDataStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setWrapText(true);
        return style;
    }

    /**
     * Стиль данных с цветной заливкой (подсветка вердиктов: «Соответствует» —
     * зелёным, «Не соответствует» — красным и т.п.). Стили кэшируются по имени
     * цвета — Excel ограничивает число уникальных стилей в книге.
     *
     * @param workbook  книга
     * @param cache     кэш стилей по имени цвета
     * @param colorName имя цвета из конфига («зелёный», «красный», «жёлтый»)
     * @return стиль с заливкой либо {@code null}, если цвет неизвестен
     */
    private static CellStyle highlightStyle(Workbook workbook, Map<String, CellStyle> cache, String colorName) {
        String normalized = colorName.toLowerCase(Locale.ROOT).replace('ё', 'е');
        IndexedColors color = switch (normalized) {
            case "зеленый", "green" -> IndexedColors.LIGHT_GREEN;
            case "красный", "red" -> IndexedColors.ROSE;
            case "желтый", "yellow" -> IndexedColors.LIGHT_YELLOW;
            default -> null;
        };
        if (color == null) {
            return null;
        }
        return cache.computeIfAbsent(normalized, name -> {
            CellStyle style = createDataStyle(workbook);
            style.setFillForegroundColor(color.getIndex());
            style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            return style;
        });
    }
}