// Проверки отбрасывания служебных файлов при загрузке комплекта (src/api/uploadFilter.ts).
// Без тест-раннера и зависимостей: node >= 22.18 / 23.6 снимает типы с .ts сам.
// Запуск из корня фронта: node --test tests/uploadFilter.test.mjs

import { describe, test } from 'node:test';
import assert from 'node:assert/strict';

import { describeSkipped, dropJunkFiles, isJunkFile, SKIPPED_NAMES_SHOWN } from '../src/api/uploadFilter.ts';

function file(name, relativePath = '') {
  const f = new File(['x'], name);
  Object.defineProperty(f, 'webkitRelativePath', { value: relativePath });
  return f;
}

describe('isJunkFile', () => {
  test('служебные файлы Office, Windows и macOS', () => {
    for (const name of ['~$говор РК-02-1442-25.docx', '~$Счёт.xlsx', 'desktop.ini', 'Desktop.ini', 'Thumbs.db',
      'Thumbs (2).db', 'ehthumbs.db', '.DS_Store', '._Акт.pdf', 'копия.tmp', 'Договор — ярлык.lnk']) {
      assert.equal(isJunkFile(name), true, name);
    }
  });

  test('документы комплекта не трогаются', () => {
    for (const name of ['Договор РК-02-1442-25.docx', 'Акт № 5.pdf', 'Реестр.xlsx', 'УПД ИП-25-000492.xml',
      'Архив ЭДО.zip', 'Паспорт.txt', 'desktop.ini.pdf', 'Отчёт~$.pdf', 'Смета.xls', 'ТЗ.7z']) {
      assert.equal(isJunkFile(name), false, name);
    }
  });

  test('копии desktop.ini, созданные при слиянии папок, тоже служебные', () => {
    assert.equal(isJunkFile('desktop (12).ini'), true);
  });

  test('файлы из папки __MACOSX по относительному пути', () => {
    assert.equal(isJunkFile('Акт.pdf', 'Комплект/__MACOSX/Акт.pdf'), true);
    assert.equal(isJunkFile('Акт.pdf', 'Комплект/Акты/Акт.pdf'), false);
  });
});

describe('dropJunkFiles', () => {
  test('делит папку Борисова: 35 копий desktop.ini уходят, документы остаются в прежнем порядке', () => {
    const docs = [file('Акт 1.pdf', 'Иновью/Акт 1.pdf'), file('Акт 2.pdf', 'Иновью/Акт 2.pdf')];
    const junk = Array.from({ length: 35 }, (_, i) => file(i === 0 ? 'desktop.ini' : `desktop (${i}).ini`, 'Иновью/desktop.ini'));
    const { kept, skipped } = dropJunkFiles([docs[0], ...junk, docs[1]]);
    assert.deepEqual(kept.map((f) => f.name), ['Акт 1.pdf', 'Акт 2.pdf']);
    assert.equal(skipped.length, 35);
  });

  test('папка Егоровой: файл блокировки Word не уходит, сам договор уходит', () => {
    const { kept, skipped } = dropJunkFiles([file('~$говор РК-02-1442-25.docx'), file('Договор РК-02-1442-25.docx')]);
    assert.deepEqual(kept.map((f) => f.name), ['Договор РК-02-1442-25.docx']);
    assert.deepEqual(skipped, ['~$говор РК-02-1442-25.docx']);
  });

  test('без служебных файлов список не меняется', () => {
    const files = [file('a.pdf'), file('b.docx')];
    const { kept, skipped } = dropJunkFiles(files);
    assert.deepEqual(kept, files);
    assert.deepEqual(skipped, []);
  });
});

describe('describeSkipped', () => {
  test('один файл', () => {
    assert.equal(describeSkipped(['~$Договор.docx']), '1 служебный файл (~$Договор.docx)');
  });

  test('больше показываемого — имена обрезаются многоточием', () => {
    const names = Array.from({ length: SKIPPED_NAMES_SHOWN + 2 }, (_, i) => `f${i}.tmp`);
    assert.equal(describeSkipped(names), `${names.length} служебных файла(ов) (f0.tmp, f1.tmp, f2.tmp, …)`);
  });
});
