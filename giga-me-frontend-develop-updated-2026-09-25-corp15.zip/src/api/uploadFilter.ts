// Служебные файлы Windows, macOS и Office в загрузке комплекта.
//
// При загрузке папкой (и при «выделить всё» в окне выбора файлов) вместе с документами уходят файлы, которые
// документами не являются: файлы блокировки Word/Excel «~$Договор.docx» (162 байта, не docx по содержимому),
// desktop.ini, Thumbs.db, .DS_Store, «._имя» (AppleDouble), ярлыки .lnk, временные .tmp. Бэкенд помечает их как
// «файл не обработан (повреждён…) — требуется ручная проверка», что пугает пользователя, а на пром-контуре загрузка
// таких папок получала 403 от шлюза (письма 25.09.2026: Егорова «Ошибка 403», Борисов «Иновью»). Поэтому фронт
// отбрасывает их до отправки и пишет в журнал, что пропущено.

/**
 * Имена служебных файлов целиком (в нижнем регистре), с копиями « (N)», которые Windows создаёт при слиянии папок
 * («desktop (12).ini» — в комплекте Борисова их 35).
 */
const JUNK_NAMES = [/^desktop(?: \(\d+\))?\.ini$/, /^(?:eh)?thumbs(?: \(\d+\))?\.db$/, /^\.ds_store$/];

/** Расширения служебных файлов. */
const JUNK_EXTENSIONS = ['.tmp', '.lnk'];

/** Сколько имён пропущенных файлов показывать в журнале. */
export const SKIPPED_NAMES_SHOWN = 3;

function baseName(name: string): string {
  const parts = name.split(/[\\/]/);
  return parts[parts.length - 1] ?? name;
}

/**
 * Служебный ли файл: блокировка Office («~$…»), AppleDouble («._…»), desktop.ini, Thumbs.db, .DS_Store, *.tmp, *.lnk
 * или файл из папки «__MACOSX» (относительный путь при загрузке папкой).
 */
export function isJunkFile(name: string, relativePath = ''): boolean {
  const lower = baseName(name).toLowerCase();
  if (lower.startsWith('~$') || lower.startsWith('._')) {
    return true;
  }
  if (JUNK_NAMES.some((pattern) => pattern.test(lower)) || JUNK_EXTENSIONS.some((ext) => lower.endsWith(ext))) {
    return true;
  }
  return relativePath.split(/[\\/]/).some((segment) => segment === '__MACOSX');
}

export interface JunkSplit {
  kept: File[];
  skipped: string[];
}

/** Делит выбранные файлы на документы и служебные файлы (порядок документов сохраняется). */
export function dropJunkFiles(files: File[]): JunkSplit {
  const kept: File[] = [];
  const skipped: string[] = [];
  for (const file of files) {
    if (isJunkFile(file.name, file.webkitRelativePath ?? '')) {
      skipped.push(file.name);
    } else {
      kept.push(file);
    }
  }
  return { kept, skipped };
}

/** Строка для журнала: «3 служебных файла (~$Договор.docx, desktop.ini, desktop.ini, …)». */
export function describeSkipped(skipped: string[]): string {
  const shown = skipped.slice(0, SKIPPED_NAMES_SHOWN).join(', ');
  const more = skipped.length > SKIPPED_NAMES_SHOWN ? ', …' : '';
  return `${skipped.length} служебн${skipped.length === 1 ? 'ый файл' : 'ых файла(ов)'} (${shown}${more})`;
}
