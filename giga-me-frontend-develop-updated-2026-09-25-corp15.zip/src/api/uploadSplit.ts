// Загрузка комплекта под неизвестный лимит шлюза на размер запроса.
//
// Прокси корп-контура (SynGX) отвечает «413 Request Entity Too Large», если тело
// multipart-запроса больше его лимита; лимит на фронте неизвестен и может меняться.
// Поэтому партии подстраиваются: при 413 партия делится пополам, а одиночный
// ZIP-архив режется на несколько ZIP с тем же именем — сжатые данные записей
// копируются как есть (без распаковки), и бэкенд распаковывает части своим
// обычным кодом: имена документов («архив.zip/папка/файл.pdf»), фильтр служебных
// файлов и вложенные архивы остаются ровно такими же, как для целого архива.

/**
 * Отказ шлюза по размеру тела запроса: HTTP 413, либо HTML-страница 502/503/504 от WAF SOWA —
 * на партию 30 МБ он отвечает не 413, а своей страницей «502 Bad Gateway» (пром-контур, 23.09.2026).
 */
export class PayloadTooLargeError extends Error {
  readonly bytes: number;
  readonly status: number;

  constructor(bytes: number, status = 413) {
    super(`Шлюз отклонил запрос размером ${formatMb(bytes)} (HTTP ${status})`);
    this.name = 'PayloadTooLargeError';
    this.bytes = bytes;
    this.status = status;
  }
}

/**
 * Ответ шлюза, а не бэкенда, на тело загрузки: 502/503/504 без JSON (HTML-страница SOWA или текст envoy).
 * Бэкенд свои ошибки отдаёт JSON-ом со statusCode, поэтому такой ответ — запрос до него не дошёл.
 */
export function isGatewayRejection(status: number, body: string): boolean {
  return (status === 502 || status === 503 || status === 504) && !body.trim().startsWith('{');
}

/** Начальный бюджет партии и минимальный размер, до которого бюджет уменьшается. */
export const INITIAL_BATCH_BYTES = 30 * 1024 * 1024;
export const MIN_BATCH_BYTES = 1024 * 1024;
export const MAX_BATCH_FILES = 100;

export function formatMb(bytes: number): string {
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

export function totalBytes(files: File[]): number {
  return files.reduce((sum, file) => sum + file.size, 0);
}

/** Первая партия из очереди: не больше maxFiles файлов и budget байт (минимум один файл). */
export function takeBatch(queue: File[], budget: number, maxFiles = MAX_BATCH_FILES): File[] {
  const batch: File[] = [];
  let bytes = 0;
  for (const file of queue) {
    if (batch.length >= maxFiles || (batch.length > 0 && bytes + file.size > budget)) {
      break;
    }
    batch.push(file);
    bytes += file.size;
  }
  return batch;
}

export function isZip(file: File): boolean {
  return file.name.toLowerCase().endsWith('.zip');
}

/** Отправка одной партии: append=false только для первой успешной (она заменяет кэш документов). */
export type SendBatch = (batch: File[], append: boolean) => Promise<void>;
export type Notify = (message: string) => void;

/**
 * Загружает все файлы партиями, подстраиваясь под лимит шлюза.
 *
 * @returns итоговый бюджет партии (для следующей загрузки в том же окне)
 */
export async function uploadAdaptive(
  files: File[],
  send: SendBatch,
  notify: Notify,
  startBudget = INITIAL_BATCH_BYTES,
): Promise<number> {
  const queue = [...files];
  let budget = startBudget;
  let first = true;
  while (queue.length > 0) {
    const batch = takeBatch(queue, budget);
    try {
      await send(batch, !first);
    } catch (error) {
      if (!(error instanceof PayloadTooLargeError)) {
        throw error;
      }
      budget = await shrinkOnTooLarge(queue, batch, budget, notify, error.status);
      continue;
    }
    queue.splice(0, batch.length);
    first = false;
  }
  return budget;
}

/**
 * Реакция на отказ шлюза по размеру (413 или страница 502 SOWA): партию — пополам, одиночный ZIP — на части,
 * прочий одиночный файл — ошибка с понятным текстом. Партия не больше минимальной и всё равно отклонена —
 * дело не в размере (шлюз или бэкенд недоступны), делить дальше бессмысленно.
 */
async function shrinkOnTooLarge(
  queue: File[],
  batch: File[],
  budget: number,
  notify: Notify,
  status: number,
): Promise<number> {
  const bytes = totalBytes(batch);
  if (bytes <= MIN_BATCH_BYTES && status !== 413) {
    throw new Error(
      `Шлюз корп-контура отвечает ${status} даже на партию ${formatMb(bytes)} — дело не в размере запроса. ` +
        'Повторите загрузку позже; если ошибка повторяется, сообщите администраторам контура (запрос до бэкенда не доходит).',
    );
  }
  if (batch.length > 1) {
    const next = Math.max(MIN_BATCH_BYTES, Math.min(budget, Math.floor(bytes / 2)));
    notify(`шлюз не принял партию ${formatMb(bytes)} (${status}) — отправляю частями до ${formatMb(next)}`);
    return next;
  }
  const file = batch[0];
  const target = Math.max(MIN_BATCH_BYTES, Math.floor(Math.min(budget, file.size) / 2));
  if (!isZip(file) || file.size <= MIN_BATCH_BYTES) {
    throw new Error(
      `Файл «${file.name}» (${formatMb(file.size)}) больше лимита шлюза корп-контура на размер запроса. ` +
        'Уменьшите файл или загрузите документы из него отдельными файлами либо ZIP-архивом.',
    );
  }
  const parts = await splitZip(file, target);
  if (parts.length < 2) {
    throw new Error(
      `Архив «${file.name}» (${formatMb(file.size)}) не делится на части меньше лимита шлюза: ` +
        'в нём есть слишком большой документ. Загрузите его отдельно или уменьшите.',
    );
  }
  notify(`шлюз не принял архив «${file.name}» ${formatMb(file.size)} (${status}) — отправляю его ${parts.length} частями`);
  queue.splice(0, 1, ...parts);
  return target;
}

// ------------------------------------------------------------------ разрезание ZIP без распаковки

const EOCD_SIGNATURE = 0x06054b50;
const CENTRAL_SIGNATURE = 0x02014b50;
const EOCD_MIN = 22;
const EOCD_SEARCH = 0xffff + EOCD_MIN;

interface ZipEntry {
  central: Uint8Array;
  localOffset: number;
  end: number;
}

async function bytesOf(blob: Blob): Promise<DataView> {
  return new DataView(await blob.arrayBuffer());
}

async function readEntries(file: File): Promise<ZipEntry[]> {
  const tailStart = Math.max(0, file.size - EOCD_SEARCH);
  const tail = await bytesOf(file.slice(tailStart));
  let eocd = -1;
  for (let i = tail.byteLength - EOCD_MIN; i >= 0; i--) {
    if (tail.getUint32(i, true) === EOCD_SIGNATURE) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) {
    throw new Error(`«${file.name}» не является ZIP-архивом`);
  }
  const count = tail.getUint16(eocd + 10, true);
  const centralSize = tail.getUint32(eocd + 12, true);
  const centralOffset = tail.getUint32(eocd + 16, true);
  if (count === 0xffff || centralOffset === 0xffffffff) {
    throw new Error(`Архив «${file.name}» в формате ZIP64 — разрезать его на части нельзя`);
  }
  const central = new Uint8Array(await file.slice(centralOffset, centralOffset + centralSize).arrayBuffer());
  return parseCentral(central, count, centralOffset, file.name);
}

function parseCentral(central: Uint8Array, count: number, centralOffset: number, name: string): ZipEntry[] {
  const view = new DataView(central.buffer, central.byteOffset, central.byteLength);
  const entries: ZipEntry[] = [];
  let pos = 0;
  for (let i = 0; i < count; i++) {
    if (view.getUint32(pos, true) !== CENTRAL_SIGNATURE) {
      throw new Error(`Архив «${name}» повреждён: неверный центральный каталог`);
    }
    const length = 46 + view.getUint16(pos + 28, true) + view.getUint16(pos + 30, true) + view.getUint16(pos + 32, true);
    entries.push({ central: central.slice(pos, pos + length), localOffset: view.getUint32(pos + 42, true), end: 0 });
    pos += length;
  }
  // запись занимает байты от своего локального заголовка до следующего (с дескриптором данных, если он есть)
  const byOffset = [...entries].sort((a, b) => a.localOffset - b.localOffset);
  byOffset.forEach((entry, i) => {
    entry.end = i + 1 < byOffset.length ? byOffset[i + 1].localOffset : centralOffset;
  });
  return byOffset;
}

/** Группы записей, каждая не больше target байт (запись больше target — отдельной группой). */
function groupEntries(entries: ZipEntry[], target: number): ZipEntry[][] {
  const groups: ZipEntry[][] = [];
  let current: ZipEntry[] = [];
  let bytes = 0;
  for (const entry of entries) {
    const size = entry.end - entry.localOffset + entry.central.length;
    if (current.length > 0 && bytes + size > target) {
      groups.push(current);
      current = [];
      bytes = 0;
    }
    current.push(entry);
    bytes += size;
  }
  if (current.length > 0) {
    groups.push(current);
  }
  return groups;
}

function buildPart(file: File, group: ZipEntry[]): File {
  const chunks: BlobPart[] = [];
  const centrals: ArrayBuffer[] = [];
  let offset = 0;
  for (const entry of group) {
    chunks.push(file.slice(entry.localOffset, entry.end));
    // копия записи центрального каталога со смещением локального заголовка внутри части
    const central = new ArrayBuffer(entry.central.length);
    new Uint8Array(central).set(entry.central);
    new DataView(central).setUint32(42, offset, true);
    centrals.push(central);
    offset += entry.end - entry.localOffset;
  }
  const centralSize = centrals.reduce((sum, c) => sum + c.byteLength, 0);
  const eocd = new DataView(new ArrayBuffer(EOCD_MIN));
  eocd.setUint32(0, EOCD_SIGNATURE, true);
  eocd.setUint16(8, group.length, true);
  eocd.setUint16(10, group.length, true);
  eocd.setUint32(12, centralSize, true);
  eocd.setUint32(16, offset, true);
  return new File([...chunks, ...centrals, eocd.buffer], file.name, { type: 'application/zip' });
}

/**
 * Режет ZIP на части с тем же именем, каждая не больше target байт, копируя записи без распаковки.
 *
 * @param file   исходный архив
 * @param target целевой размер части в байтах
 * @returns части архива (одна — если разрезать не на что)
 */
export async function splitZip(file: File, target: number): Promise<File[]> {
  const entries = await readEntries(file);
  return groupEntries(entries, target).map((group) => buildPart(file, group));
}
