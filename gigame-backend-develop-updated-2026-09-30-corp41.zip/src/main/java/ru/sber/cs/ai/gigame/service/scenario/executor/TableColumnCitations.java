package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Операция «перепроверить_цитаты_таблиц» узла «Трансформация»: после «проверить_цитаты» цитаты с достоверностью
 * «НЕ НАЙДЕНА» или «нечётко» ещё раз ищутся в таблицах документов, прочитанных по столбцам.
 * <p>
 * Бэкенд отдаёт таблицу DOCX построчно: «[ &lt; a | b &gt;\n&lt; c | d &gt; ]». Модель часто цитирует столбец сверху
 * вниз: блок подписей «От Заказчика: | От Подрядчика:» / должности / подписи она склеивает в «От Подрядчика:
 * Генеральный директор … / А.А. Колючкин /». В построчном тексте такой цитаты нет — между её частями стоят ячейки
 * соседнего столбца, — хотя каждое слово в документе есть. Операция строит для каждой таблицы текст по столбцам
 * (ячейки столбца сверху вниз, затем следующего столбца) и ищет цитату в нём так же, как «проверить_цитаты»:
 * точное вхождение — «точно (столбец таблицы)», покрытие слов не ниже 0.8 в окне — «нечётко (столбец таблицы)».
 * «нечётко» уточняется только до точного вхождения. Остальные объекты не меняются.
 * <pre>
 * {"оп": "перепроверить_цитаты_таблиц", "поле": "цитата"}
 * </pre>
 */
final class TableColumnCitations {

    /** Вердикт «проверить_цитаты»: цитата не найдена. */
    static final String NOT_FOUND = "НЕ НАЙДЕНА";

    /** Вердикт «проверить_цитаты»: найдено покрытие слов не ниже 0.8. */
    static final String FUZZY = "нечётко";

    /** Новый вердикт: цитата дословно есть в тексте таблицы по столбцам. */
    static final String EXACT_COLUMN = "точно (столбец таблицы)";

    /** Новый вердикт: покрытие слов цитаты в тексте таблицы по столбцам не ниже 0.8. */
    static final String FUZZY_COLUMN = "нечётко (столбец таблицы)";

    private static final String VERDICT = "достоверность";
    private static final String DOCUMENT = "документ";
    private static final double MIN_COVERAGE = 0.8;
    private static final double FULL_COVERAGE = 0.99;
    private static final int MAX_ANCHORS = 200;

    /** Таблица в тексте документа: «[ &lt; a | b &gt;\n&lt; c | d &gt; ]». */
    private static final Pattern TABLE = Pattern.compile("\\[ < ([\\s\\S]*?) > \\]");
    private static final Pattern ROW_SEPARATOR = Pattern.compile(" >\\n< ");
    private static final Pattern CELL_SEPARATOR = Pattern.compile(" \\| ");
    private static final Pattern DIGIT_LETTER = Pattern.compile("(?<=\\d)(?=[a-zа-я])|(?<=[a-zа-я])(?=\\d)");
    private static final Pattern NOT_WORD = Pattern.compile("[^0-9a-zа-я]+");
    private static final Pattern VERDICT_PREFIX = Pattern.compile("^\\s*(не )?засчитывается:\\s*",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private TableColumnCitations() {
    }

    /**
     * Уточняет достоверность цитат по таблицам документов, прочитанным по столбцам.
     *
     * @param objects массив находок после «проверить_цитаты»
     * @param field   поле цитаты
     * @param sources документы прогона: имя файла и текст
     * @return массив той же длины и порядка; у объектов с «НЕ НАЙДЕНА» или «нечётко», чья цитата нашлась в столбце
     *         таблицы, — новый вердикт и документ
     */
    static List<Object> recheck(List<?> objects, String field, List<Form3Ops.Source> sources) {
        List<ColumnText> columns = columnTexts(sources);
        List<Object> out = new ArrayList<>();
        for (Object o : objects) {
            out.add(o instanceof Map<?, ?> raw ? recheckOne(copy(raw), field, columns) : o);
        }
        return out;
    }

    /**
     * Тексты таблиц всех документов, прочитанные по столбцам и нормализованные для поиска.
     *
     * @param sources документы
     * @return по одному тексту на таблицу документа
     */
    static List<ColumnText> columnTexts(List<Form3Ops.Source> sources) {
        List<ColumnText> list = new ArrayList<>();
        for (Form3Ops.Source s : sources) {
            Matcher m = TABLE.matcher(s.text() == null ? "" : s.text());
            while (m.find()) {
                String norm = normalize(columnWise(m.group(1)));
                if (!norm.isEmpty()) {
                    list.add(new ColumnText(s.name(), norm));
                }
            }
        }
        return list;
    }

    /**
     * Таблица по столбцам: ячейки первого столбца сверху вниз, затем второго и так далее. Строки с меньшим числом
     * ячеек пропускают недостающие столбцы.
     *
     * @param table содержимое таблицы между «[ &lt; » и « &gt; ]»
     * @return текст ячеек по столбцам, по ячейке на строку
     */
    static String columnWise(String table) {
        List<String[]> rows = new ArrayList<>();
        int width = 0;
        for (String row : ROW_SEPARATOR.split(table, -1)) {
            String[] cells = CELL_SEPARATOR.split(row, -1);
            rows.add(cells);
            width = Math.max(width, cells.length);
        }
        StringBuilder sb = new StringBuilder();
        for (int c = 0; c < width; c++) {
            for (String[] cells : rows) {
                if (c < cells.length) {
                    sb.append(cells[c]).append('\n');
                }
            }
        }
        return sb.toString();
    }

    /**
     * Нормализация для поиска, как у «проверить_цитаты»: нижний регистр, «ё» — «е», граница цифра/буква — пробел,
     * всё, кроме букв и цифр, — одиночный пробел.
     *
     * @param s текст
     * @return нормализованный текст
     */
    static String normalize(String s) {
        if (s == null) {
            return "";
        }
        String spaced = DIGIT_LETTER.matcher(s.toLowerCase(Locale.ROOT).replace('ё', 'е')).replaceAll(" ");
        return NOT_WORD.matcher(spaced).replaceAll(" ").strip();
    }

    /**
     * Доля слов цитаты, идущих по порядку в окне вокруг самого длинного слова цитаты, — как у «проверить_цитаты».
     *
     * @param cite  слова цитаты
     * @param words слова текста
     * @return покрытие от 0 до 1
     */
    static double coverage(String[] cite, String[] words) {
        String anchor = longest(cite);
        int win = Math.max(cite.length * 2, cite.length + 6);
        double best = 0;
        int tried = 0;
        for (int pos = 0; pos < words.length && tried <= MAX_ANCHORS && best < FULL_COVERAGE; pos++) {
            if (words[pos].equals(anchor)) {
                tried++;
                int start = Math.max(0, pos - cite.length);
                int stop = Math.min(words.length, start + win);
                best = Math.max(best, orderedMatches(cite, words, start, stop) / (double) cite.length);
            }
        }
        return best;
    }

    private static Map<String, Object> recheckOne(Map<String, Object> m, String field, List<ColumnText> columns) {
        String verdict = String.valueOf(m.get(VERDICT));
        boolean notFound = NOT_FOUND.equals(verdict);
        if (columns.isEmpty() || !notFound && !FUZZY.equals(verdict)) {
            return m;
        }
        String cite = normalize(VERDICT_PREFIX.matcher(String.valueOf(m.getOrDefault(field, ""))).replaceFirst(""));
        if (cite.isEmpty()) {
            return m;
        }
        for (ColumnText c : columns) {
            if (c.norm().contains(cite)) {
                mark(m, EXACT_COLUMN, c.document());
                return m;
            }
        }
        if (notFound) {
            markFuzzy(m, cite.split(" "), columns);
        }
        return m;
    }

    private static void markFuzzy(Map<String, Object> m, String[] cite, List<ColumnText> columns) {
        for (ColumnText c : columns) {
            if (coverage(cite, c.norm().split(" ")) >= MIN_COVERAGE) {
                mark(m, FUZZY_COLUMN, c.document());
                return;
            }
        }
    }

    private static void mark(Map<String, Object> m, String verdict, String document) {
        m.put(VERDICT, verdict);
        m.put(DOCUMENT, document);
    }

    private static Map<String, Object> copy(Map<?, ?> raw) {
        Map<String, Object> m = new LinkedHashMap<>();
        raw.forEach((k, v) -> m.put(String.valueOf(k), v));
        return m;
    }

    private static String longest(String[] words) {
        String best = "";
        for (String w : words) {
            if (w.length() > best.length()) {
                best = w;
            }
        }
        return best;
    }

    private static int orderedMatches(String[] cite, String[] words, int from, int to) {
        int width = to - from;
        int[] prev = new int[width + 1];
        int[] cur = new int[width + 1];
        for (String s : cite) {
            for (int j = 1; j <= width; j++) {
                cur[j] = s.equals(words[from + j - 1]) ? prev[j - 1] + 1 : Math.max(prev[j], cur[j - 1]);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
            Arrays.fill(cur, 0);
        }
        return prev[width];
    }

    /**
     * Текст одной таблицы документа по столбцам.
     *
     * @param document имя файла документа
     * @param norm     нормализованный текст таблицы по столбцам
     */
    record ColumnText(String document, String norm) {
    }
}
