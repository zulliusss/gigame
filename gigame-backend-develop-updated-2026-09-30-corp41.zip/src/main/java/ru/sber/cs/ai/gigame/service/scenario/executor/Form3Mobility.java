package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Правило «только мобильная разработка» (письмо Балакиревой 30.09.2026, Шаттл Линк, спецификация 5500945): критерий
 * не засчитывает спецификацию/заказ, если в ней содержатся ТОЛЬКО работы по мобильным приложениям, а смешанная
 * спецификация (мобильное приложение и разработка ПО) засчитывается. Правило действует, когда признак «Мобильная
 * разработка» критериев содержит слово «только» ({@link Form3Ops.Criteria#mobileOnlyRule}) и закупка не мобильная.
 * <p>
 * Смешанность устанавливает код по маркерам немобильных работ в спецификации (и нерамочном договоре) строки; если
 * маркеров нет — по разбору работ агентом (Форма 3 v6.13, параметр операции «строки_формы3» {@code "мобильность_из_узла"}):
 * JSON-массив {@code [{"строка": N, "работы": [{"цитата": "…", "мобильное_приложение": "да|нет"}]}]}, N — номер строки
 * заключения первого прохода. Принимаются только работы, чья цитата найдена в тексте документов строки; «только
 * мобильная» — если все принятые работы мобильные; ни одной принятой — как прежде («да» → незачёт).
 */
final class Form3Mobility {

    /** Ключ конфига операции с выходом узла работ спецификаций, проставляется исполнителем узла. */
    static final String OP_TEXT = "мобильность_текст";
    /** Вердикт: правило не применяется. */
    static final String NOT_APPLIED = "";
    /** Вердикт: спецификация смешанная — засчитывается. */
    static final String MIXED = "нет";
    /** Вердикт: только мобильная разработка — не засчитывается. */
    static final String ONLY = "да";
    /** Самая короткая цитата, которую код сверяет с документом. */
    private static final int MIN_QUOTE = 12;
    /** Сколько знаков маркера/цитаты попадает в аудит. */
    private static final int NOTE_LIMIT = 80;
    /** Немобильные работы в перечне работ спецификации: веб, серверная часть, инфраструктура. */
    private static final Pattern NON_MOBILE_WORK = Pattern.compile(
            "веб-?приложени|web-?приложени|портал|сайт|back[ -]?end|бэкенд|серверн|десктоп|микросервис|прокси"
                    + "|(?<![\\p{L}\\d])(?:DWH|1С|CRM|proxy|SberLinux)(?![\\p{L}\\d])",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SPACES = Pattern.compile("\\s+");
    private static final Pattern QUOTES = Pattern.compile("[«»\"'“”]");

    private Form3Mobility() {
    }

    /** Работа из перечня спецификации по разбору агента: цитата и признак мобильного приложения. */
    record Work(String quote, boolean mobile) {
    }

    /** Итог правила для строки: вердикт и пометка аудита. */
    record Verdict(String value, String note) {
        static final Verdict NONE = new Verdict(NOT_APPLIED, "");
    }

    /**
     * Вердикт «только мобильная» для строки формы.
     *
     * @param docs     тексты документов строки, по которым читается перечень работ (спецификации, нерамочный договор)
     * @param criteria критерии Шага 1
     * @param mobile   к12 — мобильная разработка «да»/«нет»
     * @param works    работы строки по разбору агента (пусто — без разбора)
     * @return вердикт и пометка аудита
     */
    static Verdict verdict(List<String> docs, Form3Ops.Criteria criteria, String mobile, List<Work> works) {
        if (!ONLY.equals(mobile) || criteria.mobileProcurement || !criteria.mobileOnlyRule) {
            return Verdict.NONE;
        }
        String marker = marker(docs);
        if (!marker.isEmpty()) {
            return new Verdict(MIXED, "мобильная разработка есть, но спецификация смешанная: «" + marker + "»");
        }
        return byWorks(docs, works);
    }

    /** Первый маркер немобильных работ с контекстом, иначе пусто. */
    private static String marker(List<String> docs) {
        for (String text : docs) {
            Matcher m = NON_MOBILE_WORK.matcher(text);
            if (m.find()) {
                int from = Math.max(0, m.start() - NOTE_LIMIT / 2);
                return SPACES.matcher(text.substring(from, Math.min(text.length(), m.end() + NOTE_LIMIT / 2))).replaceAll(" ").strip();
            }
        }
        return "";
    }

    /** Вердикт по разбору работ агентом: принятые цитаты — только найденные в документах строки. */
    private static Verdict byWorks(List<String> docs, List<Work> works) {
        List<String> normalized = docs.stream().map(Form3Mobility::normalize).toList();
        List<Work> accepted = new ArrayList<>();
        for (Work work : works) {
            String quote = normalize(work.quote());
            if (quote.length() >= MIN_QUOTE && normalized.stream().anyMatch(text -> text.contains(quote))) {
                accepted.add(work);
            }
        }
        if (accepted.isEmpty()) {
            return new Verdict(ONLY, works.isEmpty() ? "по словам о мобильном приложении, работы агентом не разобраны"
                    : "по словам о мобильном приложении, цитаты работ агента в документах не найдены");
        }
        for (Work work : accepted) {
            if (!work.mobile()) {
                return new Verdict(MIXED, "мобильная разработка есть, но спецификация смешанная (разбор работ агентом): «"
                        + shorten(work.quote()) + "»");
            }
        }
        return new Verdict(ONLY, "только мобильная разработка (разбор работ агентом: " + accepted.size() + " работ, все мобильные)");
    }

    private static String shorten(String quote) {
        String one = SPACES.matcher(quote).replaceAll(" ").strip();
        return one.length() > NOTE_LIMIT ? one.substring(0, NOTE_LIMIT) + "…" : one;
    }

    /** Текст для сверки цитат: без кавычек, в нижнем регистре, пробелы схлопнуты. */
    static String normalize(String text) {
        return SPACES.matcher(QUOTES.matcher(text == null ? "" : text).replaceAll("")).replaceAll(" ").strip().toLowerCase(Locale.ROOT);
    }

    /**
     * Работы строк по выходу узла агента.
     *
     * @param text выход узла (JSON-массив), может быть пустым
     * @return работы по номеру строки заключения (с 1); пустая карта — без разбора
     */
    static Map<Integer, List<Work>> parse(String text) {
        Map<Integer, List<Work>> out = new LinkedHashMap<>();
        if (text == null || text.isBlank()) {
            return out;
        }
        LlmJson.Parsed block = LlmJson.first(text, LlmJson.ARRAY_WITH_OBJECTS).first();
        if (block == null || !(block.value() instanceof List<?> items)) {
            return out;
        }
        for (Object item : items) {
            if (item instanceof Map<?, ?> m && m.get("работы") instanceof List<?> works) {
                int index = index(m.get("строка"));
                if (index >= 1) {
                    out.computeIfAbsent(index, k -> new ArrayList<>()).addAll(works(works));
                }
            }
        }
        return out;
    }

    private static List<Work> works(List<?> raw) {
        List<Work> out = new ArrayList<>();
        for (Object o : raw) {
            if (o instanceof Map<?, ?> w) {
                String quote = text(w.get("цитата"));
                String mobile = text(w.get("мобильное_приложение")).toLowerCase(Locale.ROOT);
                if (!quote.isEmpty()) {
                    out.add(new Work(quote, mobile.startsWith("да") || "true".equals(mobile)));
                }
            }
        }
        return out;
    }

    private static String text(Object raw) {
        return raw == null ? "" : String.valueOf(raw).strip();
    }

    private static int index(Object raw) {
        try {
            return (int) Double.parseDouble(String.valueOf(raw).strip());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Текст донора из конфига операции (пусто, если узел работ не задан). */
    static String donorText(Map<String, Object> op) {
        return String.valueOf(op.getOrDefault(OP_TEXT, ""));
    }
}
