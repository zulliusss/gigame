package ru.sber.cs.ai.gigame.service.scenario.executor;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Разделение склеенного файла комплекта на документы (письмо Егоровой 29.09.2026, комплект Балакиревой: участник
 * сшивает в один PDF договор, заказы, акты и отчёты — 947 страниц). Реестр видел такой файл одним договором,
 * и акты с отчётами внутри него не находились: все строки формы — «Подтверждающие документы не найдены».
 * <p>
 * Граница документа — его заголовок в начале страницы (смешанный PDF: постраничные маркеры «--- страница N ---»
 * распознавания) либо в начале строки сразу после конца предыдущего документа (PDF без страниц-изображений:
 * пустая строка, «Страница N из M», «3 / 3», штамп ЭДО, строка подписей, подпись в base64). Заголовок — в
 * именительном падеже и со знаком номера, чтобы перенос строки внутри абзаца («… по Спецификации № …») и раздел
 * «ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ» внутри акта документ не начинали: «Акт … № …», «Отчёт № …», «Спецификация … №»,
 * «Заказ № N», «Заявка № N», печатная форма УПД; у распознанной страницы — после строки «Тип документа:». Часть получает имя
 * «файл › стр. N: заголовок», и реестр ({@link Form3Ops#registry}) классифицирует её по имени и тексту как отдельный
 * файл; текст до первого заголовка (договор) остаётся под именем файла. Файл с одним документом не меняется.
 */
final class Form3Split {

    static final String SEPARATOR = " › ";
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern PAGE_MARK = Pattern.compile("(?m)^--- страница (\\d+)(?: \\(текстовый слой\\))? ---\\n?");
    private static final String NOT_LETTER = "(?![\\p{L}\\d])";
    /** Знак номера с самим номером: бланк «№ ______» из приложений к договору — не документ. */
    private static final String NUMBERED = "№[ _]*\\d";
    /** Заголовок документа в начале страницы или строки (после маркера распознавания и строки «Тип документа:»). */
    private static final Pattern HEAD = Pattern.compile("^[\\s\\p{Punct}«»№]*?(?:\\[РАСПОЗНАНО[^\\]\\n]*\\]\\s*)?(?:Тип документа:\\s*)?(?:"
            + "Акт" + NOT_LETTER + "[^\\n№]{0,100}" + NUMBERED
            + "|Отч[её]т" + NOT_LETTER + "\\s*" + NUMBERED
            + "|Спецификация" + NOT_LETTER + "[^\\n]{0,120}?" + NUMBERED
            + "|(?:Заказ|Заявка)" + NOT_LETTER + "\\s*№\\s*\\d"
            + "|Универсальный\\s+передаточный\\s+документ|Сч[её]т-?фактура\\s*[N№]\\s*\\d"
            + "|Приложение\\s*№\\s*1\\s+к\\s+постановлению\\s+Правительства)", FLAGS);
    /**
     * Печатная форма УПД начинается с «Приложение № 1 к постановлению Правительства…» не обязательно первой строкой
     * страницы: форма ППРБ Сбера ставит перед ней легенду статусов («1 – передаточный документ (акт) …»). Такая строка
     * начинает документ в любом месте текста.
     */
    private static final Pattern UPD_LINE = Pattern.compile(
            "^\\s*Приложение\\s*№\\s*1\\s+к\\s+постановлению\\s+Правительства", FLAGS);
    /** Конец предыдущего документа перед заголовком (только для текста без постраничных маркеров). */
    private static final Pattern BOUNDARY = Pattern.compile(
            "(?:Страница\\s+\\d+\\s+из\\s+\\d+|\\d+\\s*/\\s*\\d+|Подпись\\s+соответствует\\s+файлу(?:\\s+документа)?"
                    + "|\\(подпись\\)|[A-Za-z0-9+/=]{24,})\\s*$", FLAGS);
    private static final Pattern WHITESPACE = Pattern.compile("\\s+");
    /** Титул печатной формы УПД в заголовке части. */
    private static final Pattern UPD_TITLE = Pattern.compile("(?:Универсальный\\s+передаточный\\s+документ|Сч[её]т-?фактура)", FLAGS);
    /** Итоговая строка таблицы УПД. */
    private static final String TOTAL_LINE = "Всего к оплате";
    /** Конец страницы печатной формы («Страница 1 из 2»). */
    private static final Pattern PAGE_END = Pattern.compile("Страница\\s+\\d+\\s+из\\s+\\d+", FLAGS);
    private static final int TITLE_LIMIT = 90;
    /** Сколько первых непустых строк составляют заголовок документа. */
    private static final int HEAD_LINES = 3;
    /** Расстояние от начала документа, внутри которого строка «Приложение № 1 …» относится к тому же заголовку. */
    private static final int HEAD_WINDOW = 200;

    private Form3Split() {
    }

    /**
     * Документы комплекта, где каждый склеенный файл заменён своими частями.
     *
     * @param sources файлы комплекта
     * @return файлы и части склеенных файлов в исходном порядке
     */
    static List<Form3Ops.Source> split(List<Form3Ops.Source> sources) {
        List<Form3Ops.Source> out = new ArrayList<>();
        for (Form3Ops.Source source : sources) {
            out.addAll(parts(source));
        }
        return out;
    }

    /**
     * Части одного файла: по заголовкам в начале страниц (текст с маркерами страниц) либо строк.
     *
     * @param source файл комплекта
     * @return части файла; сам файл, если заголовков документов после первого нет
     */
    static List<Form3Ops.Source> parts(Form3Ops.Source source) {
        // те же неразрывные пробелы и мягкие переносы, что снимает реестр: печатная форма УПД ППРБ пишет «Приложение №
        // 1 к постановлению…» неразрывными пробелами
        String text = Form3Ops.normalize(source.text());
        List<Cut> cuts = PAGE_MARK.matcher(text).find() ? pageCuts(text) : lineCuts(text);
        cuts = withoutTitleAfterTable(text, withUpdForms(text, cuts));
        if (cuts.isEmpty()) {
            return List.of(source);
        }
        List<Form3Ops.Source> parts = new ArrayList<>();
        parts.add(new Form3Ops.Source(source.name(), text.substring(0, cuts.get(0).start())));
        for (int i = 0; i < cuts.size(); i++) {
            int end = i + 1 < cuts.size() ? cuts.get(i + 1).start() : text.length();
            parts.add(new Form3Ops.Source(source.name() + SEPARATOR + cuts.get(i).label() + ": " + cuts.get(i).title(),
                    text.substring(cuts.get(i).start(), end)));
        }
        return parts;
    }

    /**
     * Титул УПД, напечатанный после его же таблицы, — не начало документа. Печатная форма Диадока 2026 года ставит
     * блок «Универсальный передаточный документ / Счет-фактура № … от …» справа от таблицы, и текстовый слой отдаёт его
     * после строки «Всего к оплате (9)» той же страницы (УПД ЭЦС № 347 и № 396, письмо Паньковой 30.09.2026); разрез
     * по такому титулу оставлял сумму, продавца и договор в части без заголовка, а титул — без суммы, и УПД не находился.
     * Титул относится к предыдущему тексту, если в нём есть «Всего к оплате» и после него нет конца страницы.
     *
     * @param text текст файла
     * @param cuts найденные начала документов
     * @return начала без титулов УПД, следующих за своей таблицей
     */
    private static List<Cut> withoutTitleAfterTable(String text, List<Cut> cuts) {
        List<Cut> out = new ArrayList<>();
        int from = 0;
        for (Cut cut : cuts) {
            String before = text.substring(from, cut.start());
            int total = before.lastIndexOf(TOTAL_LINE);
            boolean sameUpd = UPD_TITLE.matcher(cut.title()).lookingAt() && total >= 0
                    && !PAGE_END.matcher(before.substring(total)).find();
            if (!sameUpd) {
                out.add(cut);
                from = cut.start();
            }
        }
        return out;
    }

    /** Начала документов по страницам: заголовок в первой непустой строке страницы, кроме первой страницы файла. */
    private static List<Cut> pageCuts(String text) {
        List<Cut> cuts = new ArrayList<>();
        Matcher m = PAGE_MARK.matcher(text);
        boolean first = true;
        while (m.find()) {
            String title = headTitle(firstLines(text, m.end()));
            if (!first && title != null) {
                cuts.add(new Cut(m.start(), "стр. " + m.group(1), title));
            }
            first = false;
        }
        return cuts;
    }

    /** Начала документов по строкам: заголовок в начале строки после конца предыдущего документа. */
    private static List<Cut> lineCuts(String text) {
        List<Cut> cuts = new ArrayList<>();
        String previous = null;
        int offset = 0;
        for (String line : text.split("\n", -1)) {
            String title = previous == null || previous.isBlank() || BOUNDARY.matcher(previous).find()
                    ? headTitle(firstLines(text, offset)) : null;
            if (title != null && offset > 0) {
                cuts.add(new Cut(offset, "часть " + (cuts.size() + 1), title));
            }
            previous = line;
            offset += line.length() + 1;
        }
        return cuts;
    }

    /**
     * Печатные формы УПД, начатые не с первой строки страницы ({@link #UPD_LINE}), — дополнительные начала документов;
     * начало, попавшее на уже найденное или в первые строки его заголовка, не дублируется.
     */
    private static List<Cut> withUpdForms(String text, List<Cut> cuts) {
        List<Cut> all = new ArrayList<>(cuts);
        int offset = 0;
        String previousTitle = null;
        for (String line : text.split("\n", -1)) {
            // «к постановлению…» бывает на следующей строке — проверяется заголовок из первых строк
            String head = line.stripLeading().startsWith("Приложение") ? firstLines(text, offset) : null;
            if (head != null && UPD_LINE.matcher(head).find() && !nearCut(cuts, offset)) {
                String title = headTitle(head);
                // печатная форма повторяет шапку на каждой странице («1 / 3», «2 / 3») — один документ, а не три
                if (!title.equals(previousTitle)) {
                    all.add(new Cut(offset, "УПД", title));
                }
                previousTitle = title;
            }
            offset += line.length() + 1;
        }
        all.sort((a, b) -> Integer.compare(a.start(), b.start()));
        return all;
    }

    /** Есть ли начало документа не раньше чем за {@link #HEAD_WINDOW} знаков до позиции. */
    private static boolean nearCut(List<Cut> cuts, int offset) {
        for (Cut cut : cuts) {
            if (cut.start() <= offset && offset - cut.start() <= HEAD_WINDOW) {
                return true;
            }
        }
        return false;
    }

    /** Заголовок документа из начала текста: сжатые пробелы, не длиннее {@link #TITLE_LIMIT}; {@code null}, если это не заголовок. */
    private static String headTitle(String head) {
        if (head == null || !HEAD.matcher(head).find()) {
            return null;
        }
        // косая черта в заголовке («работ/услуг») ломала бы базовое имя части (текст после последнего «/»)
        String title = WHITESPACE.matcher(head).replaceAll(" ").replace('/', '-').strip();
        return title.length() > TITLE_LIMIT ? title.substring(0, TITLE_LIMIT).strip() : title;
    }

    /**
     * Первые непустые строки текста от позиции одной строкой: заголовок бывает разбит переносом («Акт ⏎ сдачи-приемки
     * № 1 ДСФ», «Приложение № 1 ⏎ к постановлению Правительства»). Пустая строка и маркер страницы заканчивают заголовок.
     */
    private static String firstLines(String text, int from) {
        StringBuilder head = new StringBuilder();
        int pos = from;
        int lines = 0;
        while (pos < text.length() && lines < HEAD_LINES) {
            int end = text.indexOf('\n', pos);
            String line = end < 0 ? text.substring(pos) : text.substring(pos, end);
            if (line.isBlank() || line.startsWith("--- страница ")) {
                if (head.length() > 0) {
                    break;
                }
            } else {
                head.append(head.length() > 0 ? " " : "").append(line.strip());
                lines++;
            }
            if (end < 0) {
                break;
            }
            pos = end + 1;
        }
        return head.length() == 0 ? null : head.toString();
    }

    /** Начало части: смещение в тексте файла, подпись («стр. 13», «часть 2») и заголовок документа. */
    private record Cut(int start, String label, String title) {
    }
}
