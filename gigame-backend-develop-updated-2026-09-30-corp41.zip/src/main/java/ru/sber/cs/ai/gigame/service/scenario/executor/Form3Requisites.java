package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Реквизиты строк формы, приведённые моделью к каноническому виду (Форма 3 v6.12, узел «Реквизиты строк формы (агент)»,
 * параметр операции «строки_формы3» {@code "реквизиты_из_узла"}): JSON-массив объектов {@code {"строка": N, "договор",
 * "спецификация", "акт", "дата_акта", "сумма"}}, N — номер строки формы по порядку (с 1). Значение модели заменяет
 * ячейку строки, только если каждая группа цифр значения есть среди групп цифр исходной ячейки той же строки: так
 * «14 от 21.10.2021» становится «№14 от 21.10.2021», а чужой номер акта, дата соседней строки или выдуманный год
 * отклоняются. Год из двух цифр в ячейке считается совпавшим с четырёхзначным «20xx»/«19xx» значения; сумма — по
 * цифрам без разрядов, копейки «00» у значения допускаются при их отсутствии в ячейке. Пустой или неразобранный донор
 * ничего не меняет.
 */
final class Form3Requisites {

    /** Ключ конфига операции с текстом донора (выход узла реквизитов), проставляется исполнителем узла. */
    static final String OP_TEXT = "реквизиты_текст";
    private static final Pattern DIGITS = Pattern.compile("\\d+");
    private static final Pattern YEAR = Pattern.compile("^(?:19|20)(\\d{2})$");

    private Form3Requisites() {
    }

    /**
     * Строки формы с проверенными реквизитами модели.
     *
     * @param lines строки формы в порядке исходной формы
     * @param text      выход узла реквизитов (JSON-массив), может быть пустым
     * @param formLines строки исходной формы, по порядку которых модель нумерует «строка»
     * @return те же строки, у принятых значений — реквизиты модели
     */
    static List<Form3Form.Row> apply(List<Form3Form.Row> lines, String text, String formLines) {
        if (text == null || text.isBlank()) {
            return lines;
        }
        LlmJson.Parsed block = LlmJson.first(text, LlmJson.ARRAY_WITH_OBJECTS).first();
        if (block == null || !(block.value() instanceof List<?> items)) {
            return lines;
        }
        // «строка» N — номер строки исходной формы; строки без реквизитов акта в {@code lines} не попадают,
        // поэтому строка ищется по тексту, а не по позиции
        String[] source = formLines == null ? new String[0] : formLines.split("\n");
        List<Form3Form.Row> out = new ArrayList<>(lines);
        for (Object item : items) {
            if (!(item instanceof Map<?, ?> m)) {
                continue;
            }
            int index = index(m.get("строка"));
            if (index < 1 || index > source.length) {
                continue;
            }
            String line = source[index - 1].strip();
            for (int i = 0; i < out.size(); i++) {
                if (out.get(i).line().equals(line)) {
                    out.set(i, merge(out.get(i), m));
                    break;
                }
            }
        }
        return out;
    }

    private static int index(Object raw) {
        try {
            return (int) Double.parseDouble(String.valueOf(raw).strip());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Строка с принятыми значениями модели: договор, спецификация, акт, дата акта, сумма. */
    private static Form3Form.Row merge(Form3Form.Row row, Map<?, ?> m) {
        String contract = accept(row.contract(), m.get("договор"), false);
        String spec = accept(row.spec(), m.get("спецификация"), false);
        String act = accept(row.act(), m.get("акт"), false);
        String actDate = accept(row.actDate(), m.get("дата_акта"), false);
        String amount = accept(row.amount(), m.get("сумма"), true);
        // дата модели заменяет дату строки, только если разобралась («09.12.21» у модели без века остаётся датой строки)
        String date = actDate.isEmpty() ? "" : Form3Form.actDate(actDate, "");
        return new Form3Form.Row(row.line(), row.company(), row.executor(), row.customer(), contract, spec, act,
                date.isEmpty() ? row.actDate() : date,
                row.dates(), amount.isEmpty() ? row.amount() : Form3Form.amount(amount), row.claimedTechs(), row.techHeaders(),
                row.signDate());
    }

    /**
     * Значение модели, если оно подтверждено ячейкой, иначе ячейка (для даты и суммы — пусто: остаётся разбор ячейки).
     */
    static String accept(String cell, Object raw, boolean money) {
        String value = raw == null ? "" : String.valueOf(raw).strip();
        if (value.isEmpty() || cell == null) {
            return money ? "" : cell;
        }
        boolean ok = money ? sameMoney(cell, value) : digitsCovered(cell, value);
        if (!ok) {
            return money ? "" : cell;
        }
        return value;
    }

    /** Каждая группа цифр значения есть в ячейке (год «20xx» — и как «xx»). */
    static boolean digitsCovered(String cell, String value) {
        Set<String> groups = new HashSet<>();
        Matcher m = DIGITS.matcher(cell);
        while (m.find()) {
            groups.add(m.group());
        }
        Matcher v = DIGITS.matcher(value);
        boolean any = false;
        while (v.find()) {
            any = true;
            String group = v.group();
            Matcher year = YEAR.matcher(group);
            if (!groups.contains(group) && !(year.matches() && groups.contains(year.group(1)))) {
                return false;
            }
        }
        return any;
    }

    /** Сумма по цифрам без разрядов: «23 777 952» подтверждает «23777952,00». */
    static boolean sameMoney(String cell, String value) {
        String c = DIGITS.matcher(cell).results().map(r -> r.group()).reduce("", String::concat);
        String v = DIGITS.matcher(value).results().map(r -> r.group()).reduce("", String::concat);
        return !v.isEmpty() && (v.equals(c) || (c + "00").equals(v));
    }

    /** Текст донора из конфига операции (пусто, если узел реквизитов не задан). */
    static String donorText(Map<String, Object> op) {
        return String.valueOf(op.getOrDefault(OP_TEXT, ""));
    }
}
