package ru.sber.cs.ai.gigame.service.scenario.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunDoc;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Кодовые операции Формы 3 (опыт участника закупки) без участия LLM.
 * <p>
 * «реестр_документов» разбирает тексты комплекта: УПД (номер, дата, продавец,
 * покупатель, договор, сумма «Всего к оплате», дата приёмки и подпись
 * заказчика), спецификации (номер, договор, дата подписания, суммы, текст),
 * договоры (номер, дата, текст) и отчёты о выполненных работах (спецификация,
 * договор, номера, суммы, текст). «строки_формы3» по реестру и выверенным
 * критериям Шага 1 строит строки формы — см. {@link Form3Rows}. Форматы взяты
 * с УПД/спецификаций ЭДО СберКорус.
 */
// Бизнес-шаблоны регулярных выражений и служебные короткие ключи JSON-мап — правки нецелесообразны (Rules.md).
// S5852: шаблоны применяются к тексту документа ограниченной длины (TEXT_LIMIT) — риск ReDoS сведён к минимуму.
@SuppressWarnings({"java:S1192", "java:S5843", "java:S5852", "java:S5854", "java:S5869", "java:S5857", "java:S2479",
        "java:S5998"})
final class Form3Ops {

    static final ObjectMapper MAPPER = new ObjectMapper();
    static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    /** Текст документа в реестре: договор на сотню страниц несёт требования к ролям (технологии) в конце. */
    private static final int TEXT_LIMIT = 400000;
    private static final int MAX_SPEC_NUMBER = 8;

    /**
     * Заголовок счёта-фактуры УПД; номер бывает не указан: «Счет-фактура N б.н. от 24.03.2025», бывает с буквенным
     * префиксом учётной системы: «Счет-фактура N ИП-25-000492 от 12.12.2025» (комплект ИННО ПРО).
     */
    /**
     * Составной номер УПД поставщиков Сбера «ддмм/гг- NИД_спецификация»: «2507/25- 4ИД_5373971», «0804/253ТД»,
     * «3ТД_5608181» (комплект Инфодетали, письмо Суздальцева 30.09.2026) — пробел после дефиса и подчёркивание входят
     * в номер; сравнивается по буквам и цифрам ({@link Form3Match}).
     */
    static final String COMPOSITE_NUMBER = "(?:\\d{1,6}/\\d{1,4}-?\\s?)?\\d{0,3}[А-ЯЁA-Z]{1,6}_\\d{1,12}"
            + "|\\d{1,6}/\\d{1,4}-?\\s?\\d{0,3}[А-ЯЁA-Z]{1,6}(?:_?\\d{1,12})?";
    private static final Pattern UPD_HEAD = Pattern.compile(
            "Сч[её]т-?фактура\\s*[N№]\\s*(" + COMPOSITE_NUMBER
                    + "|[бБ]\\s*[./\\\\-]?\\s*[нН]\\.?|[А-ЯЁA-Z]{1,5}-?\\d[\\d-]*\\d|\\d+)"
                    // буквенный суффикс номера учётной системы — не часть номера: «N 1 ПСБР от 10.12.2025» (ППРБ Сбера),
                    // «№ 26 МСБ от 31.01.2026» (комплект Балакиревой, 29.09.2026)
                    // дата прописью — печатная форма Диадока 2026 года: «№ 347 от 02 февраля 2026» (ЭЦС, письмо Паньковой 30.09.2026)
                    + "(?:\\s+[А-ЯЁ]{2,5})?\\s+от\\s+(\\d{2}\\.\\d{2}\\.\\d{4}|\\d{1,2}\\s+[а-я]{3,8}\\s+\\d{4})");
    /** Мягкий перенос между буквой или цифрой и цифрой — дефис номера документа, а не перенос слова. */
    private static final Pattern SOFT_HYPHEN_IN_NUMBER = Pattern.compile("(?<=[\\p{L}\\d])\u00AD(?=\\d)");
    /** Дата приёмки печатной формы Контур (Диадок): «Дата получения (приемки) 29.05.2025 (18)». */
    private static final Pattern UPD_ACCEPT_NUMERIC = Pattern.compile("Дата получения \\(при[её]мки\\)\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*[\\[(]1[78][\\])]");
    /**
     * Титул покупателя Контур (Диадок) заполнен и подписан: дата приёмки [18] и «Электронная подпись» ответственного
     * лица покупателя до [21] — так видна подпись заказчика, когда штамп ЭДО в PDF не имеет текстового слоя.
     */
    private static final Pattern UPD_BUYER_TITLE = Pattern.compile(
            "Дата получения \\(при[её]мки\\)\\s*\\d{2}\\.\\d{2}\\.\\d{4}\\s*\\(1[78]\\)[\\s\\S]{0,400}?Электронная подпись[\\s\\S]{0,200}?\\(2[01]\\)");
    /** Номер спецификации в информационном поле УПД СберКорус: «Дог 050005270341_AGR_Договор вн. №_5028839_от …» → 5270341. */
    private static final Pattern AGR_SPEC = Pattern.compile("Дог\\s*\\d*?(\\d{7})_AGR_");
    /** Договор в том же поле: «…_AGR_Договор вн. №_5028839_от 07.08.2024». */
    private static final Pattern AGR_CONTRACT = Pattern.compile("_AGR_Договор\\s*вн\\.\\s*№_(\\d{5,12})_от\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
    private static final Pattern UPD_SELLER = Pattern.compile("Продавец:\\s*(.+?)\\s*\\(2\\)");
    private static final Pattern UPD_BUYER = Pattern.compile("Покупатель:\\s*(.+?)\\s*\\(6\\)");
    /** Итог печатной формы: «Всего к оплате (9) …»; у старой формы 2021–2022 годов — без «(9)» (комплект ВДКОМ). */
    private static final Pattern UPD_TOTAL = Pattern.compile(
            "Всего к оплате(?:\\s*\\(9\\))?((?:\\s*(?:[\\d ]+[,.]\\d{2}|×|без НДС|без налога|-))+)");
    /** Итог печатной формы СберКорус — целые рубли без копеек: «Всего к оплате (9) 4341149». */
    private static final Pattern UPD_TOTAL_WHOLE = Pattern.compile("Всего к оплате(?:\\s*\\(9\\))?\\s*(\\d{3,12})(?![\\d,.])");
    /** Подпись покупателя в штампе ЭДО: две и более подписи «Подпись соответствует файлу документа». */
    private static final int EDO_BOTH_SIDES = 2;
    /*
     * Графы титула покупателя печатной формы: у УПД 2021–2022 годов (старая форма, комплект ВДКОМ, письмо Егоровой
     * 30.09.2026) они пронумерованы на единицу меньше — дата приёмки [17], подпись [19], покупатель [20]; у новой формы —
     * [18], [20], [21]. Обе нумерации допускаются согласованно.
     */
    private static final Pattern UPD_ACCEPT = Pattern.compile(
            "\"\\s*(\\d{1,2})\\s*\"\\s*([а-яё]+)\\s*(\\d{4})\\s*г\\.\\s*\\[1[78]\\]");
    private static final Pattern UPD_BUYER_SIGN = Pattern.compile("Электронная подпись\\s+[А-ЯЁ][^\\[]{3,80}?\\[(?:19|20)\\]");
    /**
     * Титул покупателя печатной формы СберКорус заполнен: дата приёмки словами в [18] (как разбирает {@link #UPD_ACCEPT})
     * и непустое наименование покупателя в строке [21] — УПД № 402 Хинт (corp22, п. 1): «Дата получения (приёмки) " 20 "
     * ноября 2023 г. [18] … ПАО СБЕРБАНК 7707083893/773601001 [21]», слов «Электронная подпись» у [20] и штампа
     * «Подпись соответствует файлу документа» в этой форме нет. Пустой титул — «" " 20 г. [18]» и «[21]» без названия.
     */
    private static final String KORUS_BUYER_LINE = "[\\s\\S]{0,1000}?\\n[ \\t]*[^\\n\\[\\]]*[\\p{L}\\d][^\\n\\[\\]]*?[ \\t]*";
    /** Новая форма: дата приёмки [18], покупатель [21]; старая (2021–2022): [17] и [20] — нумерации не смешиваются. */
    private static final Pattern UPD_KORUS_BUYER_TITLE = Pattern.compile("(?:"
            + UPD_ACCEPT.pattern().replace("\\[1[78]\\]", "\\[18\\]") + KORUS_BUYER_LINE + "\\[21\\]|"
            + UPD_ACCEPT.pattern().replace("\\[1[78]\\]", "\\[17\\]") + KORUS_BUYER_LINE + "\\[20\\])");
    /** Поле реестра УПД: чем подтверждена подпись заказчика помимо штампа ЭДО (титул покупателя печатной формы или XML). */
    static final String SIGN_BASIS = "подпись_заказчика_основание";
    /**
     * Поле реестра УПД: дата подписания взята из титула покупателя (дата приёмки печатной формы либо «ДатаПрин» XML), а не
     * из штампа ЭДО — по нему {@link Form3Match#signSource} называет источник даты в аудите. Без признака УПД со штампом
     * только продавца и XML-титулом покупателя в том же архиве получал в аудите «штамп ЭДО 10.10.2024», хотя в штампе этой
     * даты нет (замечание ревью corp22 п. 1); ставится в {@link #putTitleSignDate}.
     */
    static final String SIGN_DATE_BY_TITLE = "дата_подписания_из_титула";
    /** Список реестра: титулы покупателя ЭДО (XML ON_NSCHFDOPPOK), см. {@link #parseBuyerTitle}. */
    static final String BUYER_TITLES = "титулы_покупателя";
    /** Титул покупателя ЭДО в строках «Ключ: значение» бэкенда: код формы «КНД: 1115132». */
    private static final Pattern BUYER_TITLE_KND = Pattern.compile("(?m)^КНД:\\s*1115132(?!\\d)");
    /** Имя файла XML титула покупателя: «ON_NSCHFDOPPOK_2BK-…_20240930_….xml». */
    private static final Pattern BUYER_TITLE_NAME = Pattern.compile("ON_NSCHFDOPPOK", Pattern.CASE_INSENSITIVE);
    /** Строка «Ключ: значение» XML титула; значение — до конца строки или до «[источник: …]». */
    private static final Pattern XML_LINE = Pattern.compile("(?m)^([А-Яа-яЁё]+):[ \\t]*([^\\n\\[]*)");
    static final Pattern CONTRACT_REF = Pattern.compile(
            "Договор[а-я]*\\s*№?\\s*(\\d{5,12})(?:[^\\n]{0,60}?от\\s*(\\d{2}\\.\\d{2}\\.\\d{4}))?");
    static final Pattern SPEC_REF = Pattern.compile("Спецификаци[а-я]*[^\\n№]{0,120}?№\\s*(\\d{6,8})");
    /**
     * Номер в заголовке самой спецификации: между словом и знаком номера бывают переводы строк — «Спецификация на
     * разработку программного обеспечения ⏎ № 4936013 к Договору № 4286544» (Хинт, corp22 п. 4). {@link #SPEC_REF} строку
     * не пересекает и брал номер договора из фразы ниже «Спецификация является неотъемлемой частью Договора № 4286544».
     * Только для документов-спецификаций ({@link #parseSpec}): в УПД и отчётах слово «Спецификация» и чужой номер могут
     * стоять на соседних строках, там остаётся {@link #SPEC_REF}.
     */
    private static final Pattern SPEC_TITLE_REF = Pattern.compile("Спецификаци[а-я]*[^№]{0,120}?№\\s*(\\d{6,8})");
    private static final Pattern SPEC_HEAD = Pattern.compile(Form3Acts.TYPE_LINE + "\\d?\\s*Спецификаци",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SPEC_CONTRACT = Pattern.compile("к\\s+Договору\\s*№?\\s*(\\d{5,12})");
    /** Заголовок договора в первых 60 знаках: «ДОГОВОР № …», «Рамочный Договор № …», «1 ДОГОВОР № …», «Тип документа: Договор». */
    private static final Pattern CONTRACT_HEAD = Pattern.compile(
            "^[\\s\\S]{0,60}?(?<![А-Яа-яЁё])(?<!к\\s)(?<!по\\s)Договор[а-яё]*\\s*№", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern REPORT_HEAD = Pattern.compile(Form3Acts.TYPE_LINE + "Отч[её]т\\s+о\\s+выполненн",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Заголовок отчёта с номером и датой перед предметом: «Отчет № 18 от «31» июля 2025 г. ⏎ о выполненных работах и
     * оказанных услугах» (отчёты Мосбиржи в склеенном PDF комплекта Балакиревой, 29.09.2026).
     */
    private static final Pattern REPORT_HEAD_NUMBERED = Pattern.compile(Form3Acts.TYPE_LINE
            + "Отч[её]т\\s*№\\s*\\S+(?:\\s+от\\s+[^\\n]{0,40}?\\d{4}\\s*г?\\.?)?\\s+о\\s+выполненн",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Заголовок отчёта отдельной строкой в любом месте текста: PDFBox отдаёт текст в порядке потока содержимого
     * страницы, и у части отчётов (комплект АпексТех, спецификация 5477057) «ОТЧЕТ О ВЫПОЛНЕННЫХ РАБОТАХ» идёт после
     * абзаца об итоговой сумме — якорный {@link #REPORT_HEAD} его не видит. Применяется только вместе с {@link #REPORT_NAME}.
     */
    private static final Pattern REPORT_LINE = Pattern.compile("^\\W*Отч[её]т\\s+о\\s+выполненн",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE | Pattern.MULTILINE);
    /** Слово «отчёт» в имени файла. */
    private static final Pattern REPORT_NAME = Pattern.compile("отч[её]т", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern SIGN_STAMP = Pattern.compile("(\\d{2}\\.\\d{2}\\.\\d{4})\\s+\\d{2}:\\d{2}:\\d{2}");
    static final Pattern AMOUNT = Pattern.compile("(?<![\\d,.])(\\d{1,3}(?: \\d{3})+|\\d{4,})[,.](\\d{2})(?![\\d])");
    private static final Pattern FILE_NUMBER = Pattern.compile("(?<!\\d)(\\d{7,8})(?!\\d)");
    /** Имя файла печатной формы УПД в формате ФНС («ON_NSCHFDOPPR_…», «ON_NSCHFDOPPOK_…»). */
    private static final Pattern FNS_UPD_NAME = Pattern.compile("^ON_NSCHF", Pattern.CASE_INSENSITIVE);
    /** Поле реестра УПД: номер спецификации взят из пути к файлу, а не из текста документа. */
    static final String SPEC_BY_NAME = "спецификация_из_имени";
    /** Номер документа в распознанном тексте: «Реквизиты документа: № 4801685». */
    private static final Pattern OCR_NUMBER = Pattern.compile("(?:Реквизиты документа|Номер документа|Номер)[^\\n]{0,40}?№\\s*(\\d{6,8})(?!\\d)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Буквенно-цифровой номер договора («Договор № АБ-С-ИТ-2020», «№ CN_1090_IT_19_134108_037544» — МЕТРО). */
    static final Pattern CONTRACT_ALNUM = Pattern.compile("Договор[а-яё]*\\s*№\\s*([A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9/\\-_]{2,40})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Имя файла договора: «Договор Метро № CN_….pdf», «Договор 5028839 от 07.08.2024.pdf» (скан без заголовка в тексте). */
    private static final Pattern CONTRACT_NAME = Pattern.compile("^\\W*Договор(?![А-Яа-яЁё])", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Номер договора после «№» с предметом между словом «Договор» и знаком номера — распознанный скан МЕТРО:
     * «Договор по разработке программного обеспечения и услугам консультирования №\n\nCN 1090 1Т 19 134108 037544».
     * Берётся хвост строки после «№» (до конца строки), ключ сравнения — {@link Form3Rows#contractKey}.
     */
    private static final Pattern CONTRACT_NUMBER_LINE = Pattern.compile(
            "Договор[^\\n№]{0,120}?№\\s*([A-Za-zА-Яа-яЁё0-9][^\\n]{2,60})", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /**
     * Заголовок договора без знака номера в начале текста: «ДОГОВОР 156/24/ДФЮ» (договор МТС-Банка, комплект Датафьюжн,
     * письмо Егоровой 25.09.2026). Слово сразу после «Договор»; дата («Договор 31.03.2025») номером не считается.
     */
    private static final Pattern CONTRACT_TITLE = Pattern.compile(
            "\\A[\\s«\"*]*Договор[а-яё]*[ \\t]+([A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9/\\-_]{2,40})(?!\\.\\d)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern DIGIT = Pattern.compile("\\d");
    /** Заголовок договора с предметом до знака номера в первых 200 знаках распознанного текста (после строки страницы). */
    private static final Pattern CONTRACT_HEAD_LOOSE = Pattern.compile(
            "^[\\s\\S]{0,200}?(?<![А-Яа-яЁё])(?<!к\\s)(?<!по\\s)Договор\\s+(?:по|на|о|об)\\s[^\\n№]{0,120}?№", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern CONTRACT_SIGNED = Pattern.compile("Дата подписания:\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
    /** Номера заказов (ЗНЗО, заказ, заявка) — связка отчёта с УПД; ИНН/КПП и номера договоров не берутся. */
    static final Pattern ORDER_REF = Pattern.compile(
            "(?:ЗНЗО|[Зз]аказ[а-я]*|[Зз]аявк[а-я]*)\\s*(?:на\\s+\\S+\\s+)?№?\\s*(\\d{6,14})(?!\\d)");
    private static final Pattern REPORT_UPD = Pattern.compile("УПД\\s*№?\\s*0*(\\d{3,10})");
    /** Номер договора в договоре/отчёте: заголовок бывает в верхнем регистре («ДОГОВОР № …»). */
    private static final Pattern CONTRACT_REF_CI = Pattern.compile(CONTRACT_REF.pattern(),
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Ключ реестра: входные файлы сценария (исходная Форма 3 участника, критерии Шага 1) — не документы комплекта. */
    static final String SCENARIO_INPUTS = "входные_файлы";
    /**
     * Шапка исходной Формы 3 участника — строка таблицы (три и более «|») со словами «Наименование компании»: по ней
     * узлы «Строки исходной формы» и «Шапка исходной формы» находят форму среди файлов, как бы файл ни назывался.
     */
    private static final Pattern FORM_HEADER = Pattern.compile("(?m)^(?=(?:[^|\\n]*\\|){3})[^\\n]*Наименование компании");
    /** Файл критериев Шага 1: узел «Критерии (текст)» берёт его по слову «критери» в имени файла. */
    private static final Pattern CRITERIA_NAME = Pattern.compile("критери", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** Методологии: упоминание в названии должности («Главный инженер DevOps») применение методологии не подтверждает. */
    private static final Pattern METHODOLOGY = Pattern.compile("^(DevOps|DevSecOps|Agile|Scrum|Kanban|Sbergile|ITIL|SAFe)$",
            Pattern.CASE_INSENSITIVE);
    private static final String ROLE_BEFORE =
            "(?<!(?:инженер|специалист|разработчик|архитектор|аналитик|тестировщик|engineer)\\s{1,3})";

    /** Общепринятые сокращения технологий: в документах «JavaScript» пишут «JS», «TypeScript» — «TS». */
    private static final Map<String, String> TECH_SYNONYMS = Map.ofEntries(
            Map.entry("javascript", "JS"), Map.entry("typescript", "TS"), Map.entry("kubernetes", "k8s"),
            Map.entry("postgresql", "Postgres"), Map.entry("golang", "Go"), Map.entry("python", "Py"),
            Map.entry("c#", "CSharp"), Map.entry("react", "ReactJS"), Map.entry("node.js", "NodeJS"));
    /** Альтернативы в значении технологии: «UniData или Tibco» — подходит любая из них. */
    private static final Pattern TECH_ALTERNATIVES = Pattern.compile("\\s+или\\s+", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    /** Служебные слова значения технологии — не технологии: «и/или», «на», «в» есть почти в любом тексте. */
    private static final Set<String> TECH_STOP_WORDS = Set.of("или", "и", "с", "на", "в", "для");
    /** Слова в скобках в значении технологии — синонимы: «Go (Golang)», «javascript (front end)». */
    private static final Pattern PARENTHESIZED = Pattern.compile("\\(([^)]*)\\)");
    /** Слово короче трёх знаков в названии из нескольких слов само по себе технологию не доказывает («AI», «ML»). */
    private static final int MIN_STANDALONE_WORD = 3;

    static final Map<String, String> MONTHS = Map.ofEntries(
            Map.entry("января", "01"), Map.entry("февраля", "02"), Map.entry("марта", "03"),
            Map.entry("апреля", "04"), Map.entry("мая", "05"), Map.entry("июня", "06"),
            Map.entry("июля", "07"), Map.entry("августа", "08"), Map.entry("сентября", "09"),
            Map.entry("октября", "10"), Map.entry("ноября", "11"), Map.entry("декабря", "12"));

    private Form3Ops() {
    }

    /** Документ комплекта: имя файла и текст. */
    record Source(String name, String text) {
    }

    // ------------------------------------------------------------------ реестр

    /**
     * Реестр документов комплекта в JSON: {@code {"упд": [...], "спецификации": [...],
     * "договоры": [...], "отчёты": [...], "акты": [...], "прочее": [...],
     * "титулы_покупателя": [...], "не_разобраны": [{"файл", "причина"}]}}. Нечитаемые документы (маркер ручной
     * проверки: скан без OCR, битый файл, нераспакованный архив) не классифицируются. Заявки
     * (заказы к рамочному договору) лежат среди спецификаций с полем «вид»,
     * акты сдачи-приёмки без структуры УПД — отдельным списком (см. {@link Form3Acts}), титулы покупателя ЭДО
     * (XML ON_NSCHFDOPPOK) — своим списком и подтверждают подпись заказчика на УПД с тем же номером и датой
     * ({@link #linkBuyerTitles}); титул без пары — ещё и в «прочее», как прежде.
     * <p>
     * Входные файлы сценария — исходная Форма 3 участника и критерии Шага 1 ({@link #inputFileReason}) — документами
     * комплекта не являются: они не классифицируются, а перечисляются в «входные_файлы» с причиной. Раньше реквизиты
     * актов формы («Счет-фактура N 346 от 25.03.2025») делали из неё УПД со всеми номерами заявок формы, и строки формы
     * «подтверждались» самой формой (комплект Иновью, письмо Борисова 24.09.2026).
     *
     * @param sources документы комплекта
     * @return JSON реестра
     */
    static String registry(List<Source> sources) {
        List<Source> documents = new ArrayList<>();
        List<Map<String, Object>> inputs = new ArrayList<>();
        // склеенный файл (договор + заказы + акты + отчёты одним PDF) — по документам (письмо Егоровой 29.09.2026)
        for (Source source : Form3Split.split(sources)) {
            String reason = inputFileReason(source.name(), source.text());
            if (reason.isEmpty()) {
                documents.add(source);
            } else {
                inputs.add(fileEntry(source.name(), reason));
            }
        }
        Map<String, Object> registry = documentRegistry(documents);
        registry.put(SCENARIO_INPUTS, inputs);
        return toJson(registry);
    }

    /**
     * Причина, по которой файл — вход сценария, а не документ комплекта: критерии Шага 1 («критери» в имени файла) или
     * исходная Форма 3 участника (строка шапки таблицы с «Наименование компании», см. {@link #FORM_HEADER}).
     *
     * @param name имя файла
     * @param text извлечённый текст файла
     * @return причина либо пусто, если это документ комплекта
     */
    static String inputFileReason(String name, String text) {
        if (CRITERIA_NAME.matcher(Form3Acts.baseName(name)).find()) {
            return "критерии Шага 1 (в имени файла «критери»)";
        }
        return text != null && FORM_HEADER.matcher(text).find()
                ? "исходная Форма 3 участника (строка шапки «Наименование компании»)" : "";
    }

    /** Реестр документов комплекта по спискам (см. {@link #registry}) — без входных файлов сценария. */
    private static Map<String, Object> documentRegistry(List<Source> sources) {
        List<Map<String, Object>> upds = new ArrayList<>();
        List<Map<String, Object>> specs = new ArrayList<>();
        List<Map<String, Object>> contracts = new ArrayList<>();
        List<Map<String, Object>> reports = new ArrayList<>();
        List<Map<String, Object>> acts = new ArrayList<>();
        List<Map<String, Object>> titles = new ArrayList<>();
        List<Map<String, Object>> unreadable = new ArrayList<>();
        List<String> other = new ArrayList<>();
        for (Source source : sources) {
            String text = normalize(source.text());
            // распознанный скан начинается со служебной строки OCR — заголовок документа ищется после неё
            String head = Form3Acts.body(text);
            if (ScenarioRunDoc.isUnreadable(text)) {
                // маркер ручной проверки — не документ: раньше слово «акт» в имени делало из него акт с пустой суммой
                unreadable.add(unreadableEntry(source.name(), text));
            } else if (UPD_HEAD.matcher(text).find()) {
                upds.add(parseUpd(source.name(), text));
            } else if (isBuyerTitle(source.name(), text)) {
                titles.add(parseBuyerTitle(source.name(), text));
            } else if (isReport(source.name(), head, text)) {
                reports.add(parseReport(source.name(), text));
            } else if (Form3Acts.isAct(source.name(), text)) {
                acts.add(Form3Acts.parseAct(source.name(), text));
            } else if (Form3Acts.isOrder(source.name(), text)) {
                specs.add(Form3Acts.parseOrder(source.name(), text));
            } else if (SPEC_HEAD.matcher(head).find() && (SPEC_TITLE_REF.matcher(text).find() || OCR_NUMBER.matcher(text).find())) {
                specs.add(parseSpec(source.name(), text));
            } else if (CONTRACT_HEAD.matcher(head).find() || CONTRACT_HEAD_LOOSE.matcher(head).find()
                    || CONTRACT_SIGNED.matcher(text).find() || CONTRACT_NAME.matcher(Form3Acts.baseName(source.name())).find()) {
                // договор-скан (МЕТРО): распознанный текст начинается не с заголовка, вид виден по имени файла
                contracts.add(parseContract(source.name(), text));
            } else {
                other.add(source.name());
            }
        }
        linkBuyerTitles(upds, titles, other);
        Map<String, Object> registry = new LinkedHashMap<>();
        registry.put("упд", upds);
        registry.put("спецификации", specs);
        registry.put("договоры", contracts);
        registry.put("отчёты", reports);
        registry.put("акты", acts);
        registry.put(BUYER_TITLES, titles);
        registry.put("прочее", other);
        registry.put("не_разобраны", unreadable);
        return registry;
    }

    /** Запись реестра о документе, который не удалось разобрать: имя файла и причина из маркера. */
    private static Map<String, Object> unreadableEntry(String name, String text) {
        Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("файл", name);
        entry.put("причина", ScenarioRunDoc.unreadableReason(text));
        return entry;
    }

    /** Запись реестра о файле, который не классифицируется: имя файла и причина. */
    private static Map<String, Object> fileEntry(String name, String reason) {
        Map<String, Object> entry = new LinkedHashMap<>();
        entry.put("файл", name);
        entry.put("причина", reason);
        return entry;
    }

    /**
     * Нормализация текста ЭДО-документа: неразрывные пробелы, мягкие переносы,
     * возвраты каретки. Мягкий перенос перед цифрой — дефис номера документа: печатная форма УПД «Сфера
     * Документы» пишет им «ИП-25-000492», и вырезанный он склеивал номер в «ИП25000492».
     */
    static String normalize(String text) {
        if (text == null) {
            return "";
        }
        String spaced = text.replace('\u00A0', ' ').replace('\u2002', ' ').replace('\u2009', ' ').replace('\u202F', ' ');
        return SOFT_HYPHEN_IN_NUMBER.matcher(spaced).replaceAll("-").replace("\u00AD", "").replace("\r", "");
    }

    /**
     * Дата заголовка УПД в виде «дд.мм.гггг»: печатная форма Диадока 2026 года пишет её прописью
     * («Счет-фактура № 347 от 02 февраля 2026», комплект ЭЦС, письмо Паньковой 30.09.2026).
     *
     * @param raw дата из заголовка
     * @return дата «дд.мм.гггг» или исходная строка, если месяц не распознан
     */
    static String headDate(String raw) {
        if (raw.matches("\\d{2}\\.\\d{2}\\.\\d{4}")) {
            return raw;
        }
        List<String> words = Form3Acts.wordDates(raw);
        return words.isEmpty() ? raw : words.get(0);
    }

    private static Map<String, Object> parseUpd(String name, String text) {
        Map<String, Object> upd = new LinkedHashMap<>();
        upd.put("файл", name);
        Matcher head = UPD_HEAD.matcher(text);
        head.find();
        upd.put("номер", head.group(1));
        upd.put("дата", headDate(head.group(2)));
        upd.put("продавец", firstGroup(UPD_SELLER, text));
        upd.put("покупатель", firstGroup(UPD_BUYER, text));
        Matcher contract = CONTRACT_REF.matcher(text);
        Matcher agreement = AGR_CONTRACT.matcher(text);
        String contractNumber = "";
        String contractDate = "";
        if (contract.find()) {
            contractNumber = contract.group(1);
            contractDate = contract.group(2) == null ? "" : contract.group(2);
        }
        // информационное поле СберКорус называет договор без пробела после «№»: «_AGR_Договор вн. №_5028839_от 07.08.2024»
        if (contractDate.isEmpty() && agreement.find()) {
            contractNumber = contractNumber.isEmpty() ? agreement.group(1) : contractNumber;
            contractDate = agreement.group(1).equals(contractNumber) ? agreement.group(2) : contractDate;
        }
        upd.put("договор", contractNumber);
        upd.put("договор_дата", contractDate);
        upd.put("сумма", totalAmount(text));
        upd.put("дата_приёмки", acceptanceDate(text));
        Form3Acts.putEdoStamp(upd, text);
        upd.put("подпись_заказчика", UPD_BUYER_SIGN.matcher(text).find() || Form3Acts.edoSignatures(text) >= EDO_BOTH_SIDES
                || UPD_BUYER_TITLE.matcher(text).find());
        putKorusBuyerTitle(upd, text);
        putSpecReference(upd, text, name, contractNumber);
        upd.put("заказы", orderNumbers(text));
        upd.put("текст", limit(text));
        return upd;
    }

    private static String totalAmount(String text) {
        String split = Form3Acts.payableTotal(text);
        if (!split.isEmpty()) {
            return split;
        }
        Matcher m = UPD_TOTAL.matcher(text);
        if (!m.find()) {
            Matcher whole = UPD_TOTAL_WHOLE.matcher(text);
            return whole.find() ? whole.group(1) + ".00" : "";
        }
        String last = "";
        Matcher amounts = AMOUNT.matcher(m.group(1));
        while (amounts.find()) {
            last = amounts.group(1).replace(" ", "") + "." + amounts.group(2);
        }
        return last;
    }

    private static String acceptanceDate(String text) {
        Matcher m = UPD_ACCEPT.matcher(text);
        if (!m.find()) {
            return firstGroup(UPD_ACCEPT_NUMERIC, text);
        }
        String month = MONTHS.get(m.group(2).toLowerCase(Locale.ROOT));
        if (month == null) {
            return "";
        }
        return String.format("%02d.%s.%s", Integer.parseInt(m.group(1)), month, m.group(3));
    }

    /**
     * Подпись заказчика по заполненному титулу покупателя печатной формы СберКорус без отметок ЭП (УПД № 402 Хинт,
     * corp22 п. 1): дата приёмки словами в [18] и наименование покупателя в [21] — покупатель принял документ через
     * ЭДО, но слов «Электронная подпись» у [20] и штампа «Подпись соответствует файлу документа» в форме нет, и строка
     * получала «акт не подписан заказчиком». По правилу методолога подписанный через ЭДО документ датируется последней
     * подписью, а приёмка покупателя и есть последняя — дата приёмки становится датой подписания по общему правилу титулов
     * {@link #putTitleSignDate} (как и у XML-титула в {@link #acceptByTitle}). Пустой титул ([18] без даты либо [21] без
     * названия) подписью не считается; подпись, найденная штампом или титулом Контур, не переопределяется.
     *
     * @param upd  запись реестра УПД (изменяется на месте)
     * @param text текст печатной формы
     */
    private static void putKorusBuyerTitle(Map<String, Object> upd, String text) {
        String accepted = str(upd.get("дата_приёмки"));
        if (Boolean.TRUE.equals(upd.get("подпись_заказчика")) || accepted.isEmpty() || !UPD_KORUS_BUYER_TITLE.matcher(text).find()) {
            return;
        }
        upd.put("подпись_заказчика", true);
        String stamp = Boolean.TRUE.equals(upd.get(Form3Acts.STAMP)) ? "подписи заказчика в штампе ЭДО нет" : "отметки ЭП нет";
        upd.put(SIGN_BASIS, "титул покупателя печатной формы (дата приёмки " + accepted + "), " + stamp);
        putTitleSignDate(upd, accepted);
    }

    /**
     * Дата подписания УПД по титулу покупателя — одно правило для печатной формы и XML: подпись заказчика через ЭДО
     * последняя, поэтому дата приёмки/принятия становится датой подписания, если имеющейся нет или она раньше (штамп
     * только с подписью продавца старее приёмки покупателя), и ставится признак {@link #SIGN_DATE_BY_TITLE} — в аудите
     * источник даты «титул покупателя», а не «штамп ЭДО». Дата штампа не раньше титула остаётся датой штампа без признака.
     *
     * @param upd      запись реестра УПД (изменяется на месте)
     * @param accepted дата приёмки/принятия из титула dd.MM.yyyy
     */
    private static void putTitleSignDate(Map<String, Object> upd, String accepted) {
        LocalDate acceptedDate = parseDate(accepted);
        LocalDate current = parseDate(str(upd.get("дата_подписания")));
        if (acceptedDate != null && (current == null || acceptedDate.isAfter(current))) {
            upd.put("дата_подписания", accepted);
            upd.put(SIGN_DATE_BY_TITLE, true);
        }
    }

    /**
     * Отчёт о выполненных работах: заголовок первой строкой текста, либо (порядок текста PDF нарушен) слово «отчёт» в имени
     * файла и заголовок отдельной строкой в тексте. Во втором случае документ не должен быть актом: объединённый
     * «акт + отчёт» остаётся актом, как раньше.
     *
     * @param name имя файла
     * @param head текст без служебных строк распознавания
     * @param text полный текст документа
     * @return документ — отчёт о выполненных работах
     */
    private static boolean isReport(String name, String head, String text) {
        if (REPORT_HEAD.matcher(head).find() || REPORT_HEAD_NUMBERED.matcher(head).find()) {
            return true;
        }
        return REPORT_NAME.matcher(Form3Acts.baseName(name)).find() && REPORT_LINE.matcher(head).find()
                && !Form3Acts.isAct(name, text);
    }

    /** Титул покупателя ЭДО (XML ON_NSCHFDOPPOK): в тексте «КНД: 1115132» либо имя файла с «ON_NSCHFDOPPOK». */
    private static boolean isBuyerTitle(String name, String text) {
        return BUYER_TITLE_KND.matcher(text).find() || BUYER_TITLE_NAME.matcher(Form3Acts.baseName(name)).find();
    }

    /**
     * Титул покупателя ЭДО из XML ON_NSCHFDOPPOK, который бэкенд отдаёт строками «Ключ: значение» (комплект Хинт,
     * corp22 п. 1): номер и дата счёта-фактуры («НомСчФИнфПр: 542», «ДатаСчФИнфПр: 30.09.2024»), дата принятия
     * («ДатаПрин: 10.10.2024», иначе «ДатаИнфПок»), организация подписанта (последний «НаимОрг» — первый называет
     * оператора ЭДО) и подписант («Фамилия Имя Отчество»). Раньше такой файл попадал в «прочее», и подпись заказчика
     * на УПД, чья печатная форма без штампа, была не видна.
     *
     * @param name имя файла
     * @param text текст титула
     * @return запись реестра титула
     */
    private static Map<String, Object> parseBuyerTitle(String name, String text) {
        Map<String, String> values = xmlValues(text);
        Map<String, Object> title = new LinkedHashMap<>();
        title.put("файл", name);
        title.put("номер", values.getOrDefault("НомСчФИнфПр", ""));
        title.put("дата", values.getOrDefault("ДатаСчФИнфПр", ""));
        String accepted = values.getOrDefault("ДатаПрин", "");
        title.put("дата_принятия", accepted.isEmpty() ? values.getOrDefault("ДатаИнфПок", "") : accepted);
        title.put("организация", values.getOrDefault("НаимОрг", ""));
        String signer = String.join(" ", values.getOrDefault("Фамилия", ""), values.getOrDefault("Имя", ""),
                values.getOrDefault("Отчество", ""));
        title.put("подписант", signer.strip().replaceAll("\\s{2,}", " "));
        title.put("упд", "");
        return title;
    }

    /** Значения строк «Ключ: значение»; повтор ключа даёт последнее значение (блок подписанта стоит в конце). */
    private static Map<String, String> xmlValues(String text) {
        Map<String, String> values = new LinkedHashMap<>();
        Matcher m = XML_LINE.matcher(text);
        while (m.find()) {
            values.put(m.group(1), m.group(2).strip());
        }
        return values;
    }

    /**
     * Титулы покупателя к УПД комплекта: титул с тем же номером (без ведущих нулей, как сравнивает {@link Form3Match})
     * и датой счёта-фактуры подтверждает подпись заказчика — {@link #acceptByTitle}. Титул без пары остаётся в «прочее»,
     * как прежде (в комплекте Хинт печатной формы УПД 542 нет — только XML титулов).
     *
     * @param upds   УПД реестра (изменяются на месте)
     * @param titles титулы покупателя (изменяются: поле «упд» — файл найденного УПД)
     * @param other  список «прочее» (пополняется титулами без пары)
     */
    private static void linkBuyerTitles(List<Map<String, Object>> upds, List<Map<String, Object>> titles, List<String> other) {
        for (Map<String, Object> title : titles) {
            boolean paired = false;
            for (Map<String, Object> upd : upds) {
                if (sameDocument(upd, title)) {
                    acceptByTitle(upd, title);
                    paired = true;
                }
            }
            if (!paired) {
                other.add(str(title.get("файл")));
            }
        }
    }

    /** УПД и титул — один документ: совпали непустые номер (без ведущих нулей) и дата счёта-фактуры. */
    private static boolean sameDocument(Map<String, Object> upd, Map<String, Object> title) {
        String number = plainNumber(str(title.get("номер")));
        String date = str(title.get("дата"));
        return !number.isEmpty() && number.equals(plainNumber(str(upd.get("номер")))) && !date.isEmpty() && date.equals(str(upd.get("дата")));
    }

    /** Номер без ведущих нулей: «0000118724» = «118724» (как номера формы и документа в {@link Form3Match}). */
    private static String plainNumber(String raw) {
        return raw.replaceFirst("^0+(?=\\d)", "");
    }

    /**
     * Подпись заказчика на УПД по титулу покупателя ЭДО: дата принятия («ДатаПрин») — последняя подпись документа,
     * поэтому она становится датой подписания по общему правилу титулов {@link #putTitleSignDate} (если имеющейся нет или
     * она раньше — штамп печатной формы только с подписью продавца старее титула — с признаком «из титула» для аудита).
     *
     * @param upd   УПД реестра (изменяется на месте)
     * @param title титул покупателя (изменяется: поле «упд»)
     */
    private static void acceptByTitle(Map<String, Object> upd, Map<String, Object> title) {
        String accepted = str(title.get("дата_принятия"));
        upd.put("подпись_заказчика", true);
        upd.put(SIGN_BASIS, "титул покупателя ЭДО (XML), принято " + accepted + ", " + str(title.get("подписант")));
        putTitleSignDate(upd, accepted);
        title.put("упд", str(upd.get("файл")));
    }

    /**
     * Номер спецификации УПД: из текста («Спецификация … № …», поле «Дог …_AGR_»), иначе из пути к файлу; признак
     * {@link #SPEC_BY_NAME} — номер взят из пути (запасной ход {@link Form3Match#ignoringDocSpec} только для таких).
     * Имя печатной формы УПД ФНС («ON_NSCHFDOPPR_2BK-7707083893-…_2BK-9709070357-6766351_20250714_….pdf») номера
     * спецификации не содержит: в нём ЭДО-идентификаторы участников и дата, поэтому номер ищется только в папках пути.
     */
    private static void putSpecReference(Map<String, Object> upd, String text, String fileName, String contractNumber) {
        String inText = firstGroup(SPEC_REF, text);
        // поле «Дог 0500053302 41_AGR_…» называет спецификацию документа точнее папки: дубль акта чужой спецификации
        String spec = inText.isEmpty() ? firstGroup(AGR_SPEC, text) : inText;
        String inName = spec.isEmpty() ? specInName(fileName, contractNumber) : "";
        upd.put("спецификация", spec.isEmpty() ? inName : spec);
        upd.put(SPEC_BY_NAME, !inName.isEmpty());
    }

    private static String specInName(String fileName, String contractNumber) {
        String base = Form3Acts.baseName(fileName);
        String path = FNS_UPD_NAME.matcher(base).find() ? fileName.substring(0, fileName.length() - base.length()) : fileName;
        Matcher inName = FILE_NUMBER.matcher(path);
        while (inName.find()) {
            if (!inName.group(1).equals(contractNumber) && inName.group(1).length() <= MAX_SPEC_NUMBER) {
                return inName.group(1);
            }
        }
        return "";
    }

    private static Map<String, Object> parseSpec(String name, String text) {
        Map<String, Object> spec = new LinkedHashMap<>();
        spec.put("файл", name);
        String contract = firstGroup(SPEC_CONTRACT, text);
        String number = specNumber(text, contract);
        if (number.isEmpty()) {
            number = firstGroup(OCR_NUMBER, text);
        }
        spec.put("номер", number.isEmpty() ? firstGroup(FILE_NUMBER, name) : number);
        spec.put("договор", contract);
        spec.put("дата", latestStamp(text));
        spec.put("суммы", amounts(text));
        spec.put("текст", limit(text));
        return spec;
    }

    /**
     * Номер спецификации из её текста: первое «Спецификация … № N», где N — не номер договора документа («к Договору № N»).
     * Спецификация Хинт 4936013 (corp22, п. 4): заголовок с переводом строки перед «№» не совпадал, и номером становился
     * договор 4286544 из фразы «Спецификация является неотъемлемой частью Договора № 4286544» — строки формы
     * «Спецификация №4936013» оставались не сопоставленными.
     *
     * @param text     текст спецификации
     * @param contract номер договора спецификации (пусто — не найден)
     * @return номер спецификации либо пусто
     */
    private static String specNumber(String text, String contract) {
        Matcher m = SPEC_TITLE_REF.matcher(text);
        while (m.find()) {
            if (!m.group(1).equals(contract)) {
                return m.group(1);
            }
        }
        return "";
    }

    private static Map<String, Object> parseContract(String name, String text) {
        Map<String, Object> contract = new LinkedHashMap<>();
        contract.put("файл", name);
        Matcher ref = CONTRACT_REF_CI.matcher(text);
        // скан без текстового слоя: номер договора берётся из имени файла («Договор № 4652269 от …»);
        // рамочные договоры банков бывают с буквенно-цифровым номером («АБ-С-ИТ-2020»)
        String number = ref.find() ? ref.group(1) : firstGroup(CONTRACT_ALNUM, text);
        if (number.isEmpty()) {
            number = firstGroup(CONTRACT_ALNUM, name);
        }
        if (number.isEmpty()) {
            number = titleNumber(Form3Acts.body(text));
        }
        if (number.isEmpty()) {
            // скан МЕТРО: предмет договора между «Договор» и «№», номер с пробелами на следующей строке
            number = numberAfterSign(Form3Acts.body(text));
        }
        if (number.isEmpty()) {
            number = numberAfterSign(Form3Acts.baseName(name));
        }
        contract.put("номер", number.isEmpty() ? firstGroup(FILE_NUMBER, name) : number);
        String signed = firstGroup(CONTRACT_SIGNED, text);
        contract.put("дата", signed.isEmpty() ? latestStamp(text) : signed);
        contract.put("текст", limit(text));
        return contract;
    }

    /**
     * Номер договора из хвоста строки после «№», когда между словом «Договор» и знаком стоит предмет договора:
     * длинный числовой фрагмент («134108» из «CN 1090 1Т 19 134108 037544»), иначе первое слово после «№». Слово без
     * цифр номером не считается: после пустого «№» шаблона приложения («к Договору № ⏎ от «  » _____ 2024 года») им
     * было «от» (договор МТС-Банка, комплект Датафьюжн).
     *
     * @param text распознанный текст или имя файла
     * @return номер либо пусто
     */
    static String numberAfterSign(String text) {
        String tail = firstGroup(CONTRACT_NUMBER_LINE, text);
        if (tail.isEmpty()) {
            return "";
        }
        String key = Form3Rows.contractKey(tail);
        String number = key.equals(tail) ? tail.split("\\s+")[0].replaceAll("[.,;:)]+$", "") : key;
        return DIGIT.matcher(number).find() ? number : "";
    }

    /**
     * Номер договора из заголовка без знака «№» в начале текста: «ДОГОВОР 156/24/ДФЮ». Номер — слово с цифрой сразу после
     * «Договор»; слово без цифр («Договор подряда») и дата («Договор 31.03.2025») номером не считаются.
     *
     * @param text текст договора без служебных строк распознавания
     * @return номер либо пусто
     */
    static String titleNumber(String text) {
        String number = firstGroup(CONTRACT_TITLE, text);
        return DIGIT.matcher(number).find() ? number : "";
    }

    /** Отчёт о выполненных работах: связки со спецификацией, договором, УПД, длинными номерами и суммами. */
    private static Map<String, Object> parseReport(String name, String text) {
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("файл", name);
        report.put("спецификация", firstGroup(SPEC_REF, text));
        report.put("договор", firstGroup(CONTRACT_REF_CI, text));
        report.put("упд", firstGroup(REPORT_UPD, text));
        report.put("заказы", orderNumbers(text));
        report.put("суммы", amounts(text));
        report.put("текст", limit(text));
        return report;
    }

    static List<String> amounts(String text) {
        Set<String> amounts = new LinkedHashSet<>();
        Matcher m = AMOUNT.matcher(text);
        while (m.find()) {
            amounts.add(m.group(1).replace(" ", "") + "." + m.group(2));
        }
        return new ArrayList<>(amounts);
    }

    private static List<String> orderNumbers(String text) {
        Set<String> numbers = new LinkedHashSet<>();
        Matcher m = ORDER_REF.matcher(text);
        while (m.find()) {
            numbers.add(m.group(1));
        }
        return new ArrayList<>(numbers);
    }

    static String limit(String text) {
        return text.length() > TEXT_LIMIT ? text.substring(0, TEXT_LIMIT) : text;
    }

    private static String latestStamp(String text) {
        LocalDate latest = null;
        Matcher m = SIGN_STAMP.matcher(text);
        while (m.find()) {
            LocalDate d = parseDate(m.group(1));
            if (d != null && (latest == null || d.isAfter(latest))) {
                latest = d;
            }
        }
        return latest == null ? "" : latest.format(DATE);
    }

    // ------------------------------------------------------------------ строки

    /**
     * Строки Формы 3 по реестру документов и критериям Шага 1 (см. {@link Form3Rows}).
     *
     * @param op           конфиг операции ({@code "заказчики_в_рейтинге"} — regex; {@code "без_договора_не_засчитывать"},
     *                     {@code "сканы_по_имени_файла"}, {@code "б/н_допуски"} — «true»/«false», по умолчанию выключены;
     *                     {@code "отчёт_как_акт"}, {@code "б/н_любая_подпись"} — «true»/«false», по умолчанию включены;
     *                     см. {@link Form3Rows})
     * @param registryJson реестр из «реестр_документов»
     * @param criteriaText текст выверенных критериев (строки «Критерий | Значение | …»)
     * @return JSON-массив строк
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText) {
        return rows(op, registryJson, criteriaText, "");
    }

    /**
     * То же с исходной формой участника ({@code "форма_из_узла"}): строки формы
     * подсказывают, какая спецификация относится к УПД, когда по сумме этапа
     * подходят несколько или ни одной.
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText, String formLines) {
        return rows(op, registryJson, criteriaText, formLines, "");
    }

    /**
     * То же с шапкой исходной формы ({@code "шапка_из_узла"}): при наличии шапки
     * форма первична — строки заключения строятся по строкам формы участника.
     */
    static String rows(Map<String, Object> op, String registryJson, String criteriaText, String formLines,
                       String headerLine) {
        List<Map<String, Object>> built = Form3Rows.build(op, parseRegistry(registryJson), Criteria.parse(normalize(criteriaText)),
                normalize(formLines), normalize(headerLine));
        Form3Rows.denyWithoutContract(op, built);
        return toJson(built);
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> parseRegistry(String text) {
        // первый разбираемый JSON-объект входа (общий разбор LlmJson: строго, терпимо, с починкой запятых)
        LlmJson.Selection selection = LlmJson.first(text, LlmJson.OBJECT);
        LlmJson.Parsed block = selection.first();
        if (block == null && selection.lastError() == null) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: во входе нет реестра документов");
        }
        if (block == null) {
            throw new ScenarioException("Узел «Трансформация», операция «строки_формы3»: реестр не разобран: " + selection.lastError());
        }
        return (Map<String, Object>) block.value();
    }

    /**
     * Технология в тексте. Значение «UniData или Tibco» делится по «или» на альтернативы:
     * технология найдена, если найдена любая альтернатива. Название вида «Go (Golang)»
     * ищется по любому из вариантов и общепринятых сокращений (JavaScript → JS), границы — не буквы;
     * служебные слова («или», «и», «с», «на», «в», «для») вариантами не считаются — иначе
     * «и/или» в тексте засчитывало бы технологию «UniData или Tibco».
     *
     * @param text       текст, в котором ищется технология
     * @param technology значение технологии из критериев
     * @return {@code true}, если найдена хотя бы одна альтернатива
     */
    static boolean containsTechnology(String text, String technology) {
        for (String alternative : TECH_ALTERNATIVES.split(technology.strip())) {
            if (containsAlternative(text, alternative)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Одна альтернатива значения технологии: найден любой её вариант или его сокращение.
     *
     * @param text        текст, в котором ищется технология
     * @param alternative альтернатива («Go (Golang)», «PL/SQL», «Java Spring/React»)
     * @return {@code true}, если найден хотя бы один вариант, кроме служебных слов
     */
    private static boolean containsAlternative(String text, String alternative) {
        // слова в скобках — самостоятельные синонимы («Go (Golang)»), остальное — название технологии
        List<String> synonyms = new ArrayList<>();
        Matcher paren = PARENTHESIZED.matcher(alternative);
        while (paren.find()) {
            synonyms.addAll(List.of(paren.group(1).strip().split("\\s+|/")));
        }
        List<String> words = new ArrayList<>(List.of(PARENTHESIZED.matcher(alternative).replaceAll(" ").strip().split("\\s+|/")));
        words.removeIf(word -> word.isBlank() || TECH_STOP_WORDS.contains(word.toLowerCase(Locale.ROOT)));
        List<String> variants = new ArrayList<>();
        if (words.size() > 1) {
            // «Agentic AI»: вся фраза; короткое слово («AI») само по себе технологию не доказывает — иначе «Сервисы AI Ассистента»
            // засчитывали Agentic AI (комплект Инфодетали, письмо Суздальцева 30.09.2026)
            variants.add(words.stream().map(Pattern::quote).reduce((a, b) -> a + "[\\s\\-/]*" + b).orElse(""));
            words.removeIf(word -> word.length() < MIN_STANDALONE_WORD);
        }
        List<String> plain = new ArrayList<>(words);
        plain.addAll(synonyms);
        for (String word : plain) {
            variants.add(Pattern.quote(word));
            String synonym = TECH_SYNONYMS.get(word.toLowerCase(Locale.ROOT));
            if (synonym != null) {
                variants.add(Pattern.quote(synonym));
            }
        }
        return variants.stream().anyMatch(variant -> foundVariant(text, variant));
    }

    /** Вариант (экранированный шаблон) найден в тексте по границам не букв и не цифр. */
    private static boolean foundVariant(String text, String variant) {
        String plain = variant.replace("\\Q", "").replace("\\E", "");
        if (plain.length() < 2) {
            return false;
        }
        String roleGuard = METHODOLOGY.matcher(plain).matches() ? ROLE_BEFORE : "";
        Pattern p = Pattern.compile(roleGuard + "(?<![A-Za-zА-Яа-я0-9])" + variant + "(?![A-Za-zА-Яа-я0-9])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        return p.matcher(text).find();
    }

    // ------------------------------------------------------------------ критерии

    /** Выверенные критерии Шага 1: периоды, технологии по лотам, признак мобильной закупки. */
    static final class Criteria {
        private static final Pattern PERIOD_QUAL = Pattern.compile(
                "(?m)^Период опыта участника по квалификационным требованиям\\s*[—-]\\s*календарные даты\\s*\\|\\s*"
                        + "с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern PERIOD_METHOD = Pattern.compile(
                "(?m)^Период опыта по методике оценки\\s*[—-]\\s*календарные даты\\s*\\|\\s*"
                        + "с\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s*по\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern QUAL_TEXT = Pattern.compile(
                "(?m)^Период опыта участника по квалификационным требованиям\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern METHOD_TEXT = Pattern.compile("(?m)^Период опыта по методике оценки\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern START_DATE = Pattern.compile(
                "(?m)^Дата начала срока подачи заявок\\s*\\|\\s*(\\d{2}\\.\\d{2}\\.\\d{4})");
        private static final Pattern SPAN = Pattern.compile(
                "(\\d{1,3})\\s*(?:\\([^)]*\\))?\\s*(год|лет|месяц)", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        private static final Pattern LOT = Pattern.compile("^ЛОТ\\s*№\\s*(\\d+)\\s*\\((Квалификационн|Методическ)");
        private static final Pattern TECH = Pattern.compile("^Технология\\s*\\d+\\s*\\|\\s*([^|]+?)\\s*\\|");
        private static final Pattern MOBILE = Pattern.compile(
                "(?m)^Признак\\s*[«\"]?Мобильная разработка[»\"]?\\s*\\|\\s*([^|\\n]+)");
        private static final Pattern MOBILE_EXCLUDED = Pattern.compile(
                "не\\s+засчит|не\\s+учит|исключ|не\\s+принима|не\\s+являет", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        private static final Pattern MOBILE_SUBJECT = Pattern.compile(
                "закупа|предмет|засчит|являет|учитыва|требует", Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        /** Технология лота — мобильная платформа (iOS, Android, Swift, Kotlin, Flutter, React Native, Objective-C, «мобильн…»). */
        private static final Pattern MOBILE_TECH = Pattern.compile(
                "(?<![\\p{L}\\d])(?:ios|android|swift|kotlin|flutter|react\\s*native|objective[-\\s]?c)(?![\\p{L}\\d])|мобильн",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        /** Признак о незачёте ТОЛЬКО мобильных работ: «содержится только работы по разработке … мобильных приложений». */
        private static final Pattern MOBILE_ONLY = Pattern.compile("только[^|]{0,120}?мобильн",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        /** Названия платформ в признаке: «…мобильных приложений iOS и Android». */
        private static final Pattern MOBILE_PLATFORM_NAMES = Pattern.compile("(?<![\\p{L}\\d])(?:ios|android)(?![\\p{L}\\d])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
        /** Признак описывает разработку мобильных приложений: «…внедрению мобильных приложений iOS и Android». */
        private static final Pattern MOBILE_DEVELOPMENT = Pattern.compile(
                "мобильн\\S*\\s+приложени|(?:разработ|модификац|внедрен)[^|]{0,120}?(?<![\\p{L}\\d])(?:ios|android)(?![\\p{L}\\d])",
                Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

        LocalDate qualFrom;
        LocalDate qualTo;
        LocalDate methodFrom;
        LocalDate methodTo;
        boolean mobileProcurement;
        /**
         * Признак не засчитывает ТОЛЬКО мобильную разработку («содержится только работы по … мобильных приложений»):
         * смешанная спецификация засчитывается ({@link Form3Mobility}; письмо Балакиревой 30.09.2026).
         */
        boolean mobileOnlyRule;
        final Map<String, List<String>> lots = new LinkedHashMap<>();
        private final Map<String, List<String>> methodLots = new LinkedHashMap<>();

        static Criteria parse(String text) {
            Criteria c = new Criteria();
            LocalDate start = parseDate(firstGroup(START_DATE, text));
            Matcher q = PERIOD_QUAL.matcher(text);
            if (q.find()) {
                c.qualFrom = parseDate(q.group(1));
                c.qualTo = parseDate(q.group(2));
            } else if (start != null) {
                c.qualFrom = minusSpan(start, firstGroup(QUAL_TEXT, text));
                c.qualTo = c.qualFrom == null ? null : start;
            }
            Matcher m = PERIOD_METHOD.matcher(text);
            if (m.find()) {
                c.methodFrom = parseDate(m.group(1));
                c.methodTo = parseDate(m.group(2));
            } else if (start != null) {
                c.methodFrom = minusSpan(start, firstGroup(METHOD_TEXT, text));
                c.methodTo = c.methodFrom == null ? null : start;
            }
            c.parseLots(text);
            c.mobileProcurement = c.isMobileProcurement(firstGroup(MOBILE, text));
            c.mobileOnlyRule = !c.mobileProcurement && MOBILE_ONLY.matcher(firstGroup(MOBILE, text)).find();
            return c;
        }

        /**
         * Закупка мобильной разработки (письмо Егоровой 16.09.2026): явный запрет в признаке («не засчитывается»,
         * «исключается») — мобильная разработка стоп-фактор; иначе закупка мобильная, если требуемые технологии
         * какого-либо лота (квалификационные или методические) — мобильные платформы, либо признак описывает
         * разработку мобильных приложений; иначе — по словам о предмете закупки, как прежде.
         *
         * @param mobile значение признака «Мобильная разработка» (пусто, если строки нет)
         * @return {@code true}, если мобильная разработка засчитывается
         */
        private boolean isMobileProcurement(String mobile) {
            if (MOBILE_EXCLUDED.matcher(mobile).find()) {
                return false;
            }
            if (mobileLot(lots) || mobileLot(methodLots)) {
                return true;
            }
            // технологии лотов заданы, ни одна не мобильная (Agentic AI, MCP, A2A, RAG — закупка AI, письмо Суздальцева
            // 30.09.2026), а признак называет платформы iOS и Android — шаблон документации, а не предмет закупки
            if ((anyTechnology(lots) || anyTechnology(methodLots)) && !mobileTechnology(lots) && !mobileTechnology(methodLots)
                    && MOBILE_PLATFORM_NAMES.matcher(mobile).find()) {
                return false;
            }
            return !mobile.isEmpty() && (MOBILE_DEVELOPMENT.matcher(mobile).find() || MOBILE_SUBJECT.matcher(mobile).find());
        }

        private static boolean anyTechnology(Map<String, List<String>> byLot) {
            return byLot.values().stream().anyMatch(techs -> !techs.isEmpty());
        }

        /** Хотя бы одна технология какого-либо лота — мобильная платформа. */
        private static boolean mobileTechnology(Map<String, List<String>> byLot) {
            return byLot.values().stream().flatMap(List::stream).anyMatch(tech -> MOBILE_TECH.matcher(tech).find());
        }

        /** Есть лот, все технологии которого — мобильные платформы. */
        private static boolean mobileLot(Map<String, List<String>> byLot) {
            return byLot.values().stream().anyMatch(techs -> !techs.isEmpty()
                    && techs.stream().allMatch(tech -> MOBILE_TECH.matcher(tech).find()));
        }

        /** Начало периода: дата начала подачи заявок минус «N (…) лет/месяцев» из текста критерия. */
        private static LocalDate minusSpan(LocalDate start, String periodText) {
            Matcher span = SPAN.matcher(periodText);
            if (!span.find()) {
                return null;
            }
            int n = Integer.parseInt(span.group(1));
            return span.group(2).toLowerCase(Locale.ROOT).startsWith("месяц") ? start.minusMonths(n) : start.minusYears(n);
        }

        private void parseLots(String text) {
            String lot = null;
            boolean qualification = true;
            for (String line : text.split("\n")) {
                Matcher head = LOT.matcher(line.strip());
                if (head.find()) {
                    lot = head.group(1);
                    qualification = head.group(2).startsWith("Квалификац");
                    continue;
                }
                Matcher tech = TECH.matcher(line.strip());
                if (lot != null && tech.find() && !tech.group(1).toLowerCase(Locale.ROOT).startsWith("не указано")) {
                    (qualification ? lots : methodLots).computeIfAbsent(lot, k -> new ArrayList<>()).add(tech.group(1));
                }
            }
            for (Map.Entry<String, List<String>> e : methodLots.entrySet()) {
                lots.putIfAbsent(e.getKey(), e.getValue());
            }
        }

        List<String> allTechnologies() {
            Set<String> all = new LinkedHashSet<>();
            lots.values().forEach(all::addAll);
            return new ArrayList<>(all);
        }
    }

    // ------------------------------------------------------------------ утилиты

    static String firstGroup(Pattern p, String text) {
        Matcher m = p.matcher(text);
        return m.find() ? m.group(1).strip() : "";
    }

    static LocalDate parseDate(String value) {
        try {
            return LocalDate.parse(value, DATE);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }

    static String str(Object value) {
        return value == null ? "" : String.valueOf(value).strip();
    }

    static String toJson(Object value) {
        try {
            return MAPPER.writerWithDefaultPrettyPrinter().writeValueAsString(value);
        } catch (Exception e) {
            throw new ScenarioException("Узел «Трансформация»: не удалось сериализовать результат: " + e.getMessage());
        }
    }
}
