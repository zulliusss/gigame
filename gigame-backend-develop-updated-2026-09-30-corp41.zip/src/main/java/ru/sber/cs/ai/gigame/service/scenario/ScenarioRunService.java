package ru.sber.cs.ai.gigame.service.scenario;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.OffsetDateTime;
import java.util.List;

@Service
@Slf4j
public class ScenarioRunService {
    private final ScenarioRunRepository scenarioRunRepository;
    /**
     * Помечать ли при старте FAILED прогоны, оставшиеся в БД в статусе RUNNING. При нескольких экземплярах
     * на одной БД так помечались бы и прогоны соседнего экземпляра — для многопода выключается
     * ({@code app.scenario.fail-orphaned-on-start}, env {@code SCENARIO_FAIL_ORPHANED_ON_START}); тогда
     * прогоны завершает graceful-остановка своего экземпляра ({@link ScenarioEngine#shutdown()}).
     */
    @Value("${app.scenario.fail-orphaned-on-start:true}")
    private boolean failOrphanedOnStart = true;

    public ScenarioRunService(ScenarioRunRepository scenarioRunRepository) {
        this.scenarioRunRepository = scenarioRunRepository;
    }

    public ScenarioRun setScenarioRunStatusRunning(ScenarioRun run) {
        log.info("[{}] setScenarioRunStatusRunning, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        run.setStatus(ScenarioStatus.RUNNING.getValue());
        return scenarioRunRepository.save(run);
    }

    public ScenarioRun setScenarioRunStatusFailed(ScenarioRun run) {
        log.info("[{}] setScenarioRunStatusFailed, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        run.setStatus(ScenarioStatus.FAILED.getValue());
        return scenarioRunRepository.save(run);
    }

    /**
     * Прогон завершён с ошибками узлов (on_error=continue/branch): статус FAILED,
     * но неполный итог сохраняется — пользователь видит, что успело посчитаться.
     *
     * @param run         прогон
     * @param finalResult неполный итог прогона
     * @return сохранённый прогон
     */
    public ScenarioRun setScenarioRunStatusFailed(ScenarioRun run, String finalResult) {
        log.info("[{}] setScenarioRunStatusFailed (с итогом), runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        run.setStatus(ScenarioStatus.FAILED.getValue());
        run.setResult(finalResult);
        run.setCompletedAt(OffsetDateTime.now());
        return scenarioRunRepository.save(run);
    }

    public ScenarioRun setScenarioRunStatusCompleted(ScenarioRun run, String finalResult) {
        log.info("[{}] setScenarioRunStatusCompleted, runId={}",
                CurrentUserHolder.getCurrentUser(), run.getId());
        run.setStatus(ScenarioStatus.COMPLETED.getValue());
        run.setResult(finalResult);
        run.setCompletedAt(OffsetDateTime.now());
        return scenarioRunRepository.save(run);
    }

    /**
     * Восстановление после рестарта: прогоны, оставшиеся в статусе RUNNING
     * (их поток выполнения умер вместе с JVM), помечаются FAILED — иначе
     * они вечно отображаются «выполняется» в интерфейсе. При graceful-остановке
     * ({@link ScenarioEngine#shutdown()}) прогоны получают FAILED ещё до выхода JVM с ошибкой узла
     * {@link ScenarioEngine#RESTART_REASON}; здесь дорабатываются только прерванные аварийно.
     * Выключается для нескольких экземпляров на одной БД ({@code app.scenario.fail-orphaned-on-start=false}).
     */
    @EventListener(ApplicationReadyEvent.class)
    public void failOrphanedRunningRuns() {
        if (!failOrphanedOnStart) {
            log.info("Прогоны в статусе RUNNING при старте не трогаются: app.scenario.fail-orphaned-on-start=false");
            return;
        }
        List<ScenarioRun> orphaned =
                scenarioRunRepository.findByStatus(ScenarioStatus.RUNNING.getValue());
        if (orphaned.isEmpty()) {
            return;
        }
        orphaned.forEach(run -> run.setStatus(ScenarioStatus.FAILED.getValue()));
        scenarioRunRepository.saveAll(orphaned);
        log.warn("Прогоны, прерванные рестартом сервера, помечены FAILED: {}", orphaned.size());
    }
}
