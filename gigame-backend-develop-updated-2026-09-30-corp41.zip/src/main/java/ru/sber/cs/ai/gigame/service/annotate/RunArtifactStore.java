package ru.sber.cs.ai.gigame.service.annotate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Склад бинарных артефактов прогона — ZIP размеченных документов выходного узла — только в памяти сервера.
 * <p>
 * Результаты шагов хранятся в БД текстом; ZIP с документами в текст не укладывается и нужен лишь при скачивании
 * файла узла. На диск и в базу данных артефакты не пишутся (требование безопасности контура, 30.09.2026): они
 * живут в памяти {@code app.annotate.artifact-ttl-hours} часов, суммарный объём ограничен
 * {@code app.annotate.artifact-max-mb} (самые старые вытесняются), перезапуск сервера склад очищает — тогда
 * скачивание файла узла с настроенной разметкой отвечает понятной ошибкой, а не Excel без разметки.
 */
@Slf4j
@Service
public class RunArtifactStore {

    private static final long MB = 1024L * 1024;
    private static final int DEFAULT_MAX_MB = 512;

    @Value("${app.annotate.artifact-ttl-hours:168}")
    private int ttlHours;

    /** Предел суммарного объёма артефактов, МБ; 0 и меньше — без предела. */
    @Value("${app.annotate.artifact-max-mb:512}")
    private int maxMb = DEFAULT_MAX_MB;

    /** Артефакты: прогон → (узел → артефакт). */
    private final Map<UUID, Map<String, Artifact>> runs = new LinkedHashMap<>();

    /** Артефакт узла: содержимое и момент сохранения. */
    private record Artifact(byte[] content, Instant savedAt) {
    }

    /** Конструктор для Spring (настройки внедряются в поля). */
    public RunArtifactStore() {
    }

    /**
     * Склад с заданным сроком жизни (тесты), предел объёма — по умолчанию.
     *
     * @param ttlHours срок жизни артефактов, часов
     */
    public RunArtifactStore(int ttlHours) {
        this.ttlHours = ttlHours;
    }

    /**
     * Сохраняет артефакт узла прогона; при превышении предела объёма самые старые прогоны вытесняются.
     *
     * @param runId   идентификатор прогона
     * @param nodeId  идентификатор узла
     * @param content содержимое ZIP
     */
    public synchronized void save(UUID runId, String nodeId, byte[] content) {
        if (content == null) {
            return;
        }
        reserve(runId, content.length);
        runs.computeIfAbsent(runId, r -> new LinkedHashMap<>()).put(nodeId, new Artifact(content, Instant.now()));
    }

    /**
     * Артефакт узла прогона.
     *
     * @param runId  идентификатор прогона
     * @param nodeId идентификатор узла
     * @return содержимое или пусто (не сохранялся, истёк, вытеснен, сервер перезапущен)
     */
    public synchronized Optional<byte[]> load(UUID runId, String nodeId) {
        Map<String, Artifact> nodes = runs.get(runId);
        Artifact artifact = nodes == null ? null : nodes.get(nodeId);
        return artifact == null ? Optional.empty() : Optional.of(artifact.content());
    }

    /** Плановая чистка артефактов старше срока жизни. */
    @Scheduled(fixedRateString = "${app.annotate.cleanup-rate-ms:3600000}")
    public synchronized void evictStale() {
        evictStale(Instant.now());
    }

    /**
     * Чистка относительно заданного момента (тесты).
     *
     * @param now момент, от которого отсчитывается срок жизни
     */
    synchronized void evictStale(Instant now) {
        Instant deadline = now.minus(Duration.ofHours(ttlHours));
        int removed = 0;
        for (Map<String, Artifact> nodes : runs.values()) {
            int before = nodes.size();
            nodes.values().removeIf(artifact -> artifact.savedAt().isBefore(deadline));
            removed += before - nodes.size();
        }
        runs.values().removeIf(Map::isEmpty);
        if (removed > 0) {
            log.info("Склад артефактов прогонов: вычищено {} артефактов старше {} ч", removed, ttlHours);
        }
    }

    /** Занятый объём, байт. */
    synchronized long usedBytes() {
        return runs.values().stream().flatMap(nodes -> nodes.values().stream()).mapToLong(a -> a.content().length).sum();
    }

    /** Вытесняет самые старые прогоны (кроме текущего), пока новый артефакт не помещается в предел объёма. */
    private void reserve(UUID keep, long size) {
        if (maxMb <= 0) {
            return;
        }
        long limit = maxMb * MB;
        while (usedBytes() + size > limit) {
            Optional<UUID> oldest = runs.entrySet().stream().filter(e -> !e.getKey().equals(keep))
                    .min(Comparator.comparing(e -> e.getValue().values().stream().map(Artifact::savedAt)
                            .min(Comparator.naturalOrder()).orElse(Instant.MAX)))
                    .map(Map.Entry::getKey);
            if (oldest.isEmpty()) {
                return;
            }
            runs.remove(oldest.get());
            log.warn("Склад артефактов прогонов: предел объёма {} МБ достигнут — вытеснены артефакты прогона {}", maxMb, oldest.get());
        }
    }
}
