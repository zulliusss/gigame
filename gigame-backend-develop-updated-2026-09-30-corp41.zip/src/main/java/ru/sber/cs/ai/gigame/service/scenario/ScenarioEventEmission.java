package ru.sber.cs.ai.gigame.service.scenario;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.service.annotate.AnnotationConfig;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioEventType;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioStatus;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public class ScenarioEventEmission {
    private static final String KEY_RUN_ID = "run_id";
    private static final String KEY_STATUS = "status";
    private static final String KEY_RESULT = "result";
    private static final String KEY_QUEUE_AHEAD = "queue_ahead";
    private static final String KEY_NODE_ID = "node_id";
    private static final String KEY_NODE_LABEL = "node_label";
    private static final String KEY_NODE_TYPE = "node_type";
    private static final String KEY_STEP = "step";
    private static final String KEY_TOTAL = "total";
    private static final String KEY_ERROR = "error";
    private static final String KEY_MATCHED_RULE = "matched_rule";
    private static final String KEY_ITERATION = "iteration";
    private static final String KEY_DETAIL = "detail";
    private static final String KEY_CONDITION_MET = "condition_met";
    private static final String KEY_BRANCH = "branch";
    private static final String KEY_KB_ID = "kb_id";
    private static final String KEY_CHUNKS_FOUND = "chunks_found";

    private static final String KEY_STEP_ID = "step_id";
    private static final String KEY_INPUT_DATA = "input_data";
    private static final String KEY_OUTPUT_DATA = "output_data";
    private static final String KEY_STEP_INDEX = "step_index";
    private static final String KEY_TOTAL_STEPS = "total_steps";
    private static final String KEY_PROMPT = "prompt_used";

    private static final String KEY_FILENAME = "filename";
    private static final String KEY_MIME_TYPE = "mime_type";
    private static final String KEY_FILE_READY = "file_ready";

    private static final String MSG_UNKNOWN_ERROR = "Неизвестная ошибка";
    /**
     * Подпись записи журнала о прогоне, ждущем в очереди пула прогонов.
     */
    private static final String QUEUE_LABEL = "В очереди";
    /**
     * Подпись записи журнала об итоге прогона (упавшие узлы, невыполненный выход).
     */
    private static final String RUN_SUMMARY_LABEL = "Итог прогона";

    /**
     * Лимиты превью данных шага в WS-событии STEP_COMPLETE: полные тексты
     * документов/промптов раздували кадр до мегабайт (корп. SOWA падала на
     * больших фреймах: «payload length exceeds the maximum array size»),
     * при этом UI показывает лишь первые сотни символов, а полные данные
     * шага и так доступны отдельной ручкой GET /api/scenarios/runs/{runId}.
     * Лимиты взяты с запасом к тому, что рисует панель шага.
     */
    static final int PREVIEW_DOCS = 1000;
    static final int PREVIEW_PREV = 1000;
    static final int PREVIEW_PROMPT = 2000;
    static final int PREVIEW_RESULT = 3000;
    private static final String PREVIEW_SUFFIX = "… [показано начало; полные данные — в отчёте прогона]";

    private ScenarioEventEmission() {
    }

    /** Обрезает значение до лимита превью с пометкой (null-безопасно). */
    static String preview(String value, int limit) {
        if (value == null || value.length() <= limit) {
            return value;
        }
        return value.substring(0, limit) + PREVIEW_SUFFIX;
    }

    /** Превью карты данных шага: каждое значение обрезано до лимита. */
    private static Map<String, String> previewMap(Map<String, String> data,
                                                  Map<String, Integer> limits) {
        if (data == null) {
            return Map.of();
        }
        Map<String, String> out = new LinkedHashMap<>();
        for (var e : data.entrySet()) {
            out.put(e.getKey(), preview(e.getValue(),
                    limits.getOrDefault(e.getKey(), PREVIEW_RESULT)));
        }
        return out;
    }

    public static void emitStatusEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                       UUID runId,
                                       ScenarioStatus status,
                                       String finalResult) {
        if (sink == null) {
            return;
        }
        sink.next(statusEvent(runId, status, finalResult));
    }

    /**
     * Событие STATUS прогона (тот же кадр, что шлёт {@link #emitStatusEvent}) — для повторной
     * подписки на прогон по run_id.
     *
     * @param runId       UUID прогона
     * @param status      статус
     * @param finalResult итог прогона (превью; пусто — без поля)
     * @return событие
     */
    public static ServerSentEvent<Map<String, Object>> statusEvent(UUID runId, ScenarioStatus status, String finalResult) {
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_RUN_ID, runId.toString(),
                KEY_STATUS, status));
        if (ObjectUtils.isNotEmpty(finalResult)) {
            // превью: UI показывает первые сотни символов, полный результат —
            // GET /runs/{id}; финальный кадр больших сценариев весил сотни КБ
            dataMap.put(KEY_RESULT, preview(finalResult, PREVIEW_RESULT));
        }
        return event(ScenarioEventType.STATUS, dataMap);
    }

    /**
     * События приёма прогона, совместимые с текущим фронтом. Первое — STATUS со
     * статусом RUNNING и run_id: клиент сразу запоминает id прогона (может его
     * остановить, получить id возобновления) и ждёт COMPLETED/FAILED; фаза панели
     * не меняется, сокет не закрывается. Поле queue_ahead справочное. Если прогон
     * ждёт свободного потока пула, второе событие — запись журнала
     * PROCESSING_PROGRESS с тем же run_id и текстом о положении в очереди (фронт
     * выводит detail в журнал прогона, как паузы повторов GigaChat).
     *
     * @param sink        поток событий
     * @param runId       UUID принятого прогона
     * @param queueAhead  сколько прогонов ждут запуска перед этим
     * @param queueNotice текст о положении в очереди; {@code null} — прогон стартует без очереди
     */
    public static void emitRunQueuedEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          UUID runId,
                                          int queueAhead,
                                          String queueNotice) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_RUN_ID, runId.toString(),
                KEY_STATUS, ScenarioStatus.RUNNING,
                KEY_QUEUE_AHEAD, queueAhead));
        emitEvent(sink, ScenarioEventType.STATUS, dataMap);
        if (queueNotice == null) {
            return;
        }
        Map<String, Object> noticeMap = new HashMap<>(Map.of(
                KEY_RUN_ID, runId.toString(),
                KEY_NODE_LABEL, QUEUE_LABEL,
                KEY_ITERATION, 0,
                KEY_TOTAL, 0,
                KEY_DETAIL, queueNotice));
        emitEvent(sink, ScenarioEventType.PROCESSING_PROGRESS, noticeMap);
    }

    /**
     * Запись журнала прогона уровня прогона, а не узла: PROCESSING_PROGRESS с run_id,
     * подписью «Итог прогона» и текстом — фронт выводит detail в журнал так же, как
     * паузы GigaChat и положение в очереди. Используется для перечня упавших узлов и
     * предупреждения о невыполненном узле «Выход».
     *
     * @param sink   поток событий
     * @param runId  UUID прогона
     * @param detail текст записи
     */
    public static void emitRunNoticeEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          UUID runId,
                                          String detail) {
        emitRunNoticeEvent(sink, runId, RUN_SUMMARY_LABEL, detail);
    }

    /**
     * Запись журнала уровня прогона с произвольной подписью (например, «Документы» — число документов,
     * с которыми пошёл прогон); формат тот же, что у {@link #emitRunNoticeEvent(FluxSink, UUID, String)}.
     *
     * @param sink   поток событий
     * @param runId  UUID прогона
     * @param label  подпись записи (node_label)
     * @param detail текст записи
     */
    public static void emitRunNoticeEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          UUID runId,
                                          String label,
                                          String detail) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_RUN_ID, runId.toString(),
                KEY_NODE_LABEL, label,
                KEY_ITERATION, 0,
                KEY_TOTAL, 0,
                KEY_DETAIL, detail));
        emitEvent(sink, ScenarioEventType.PROCESSING_PROGRESS, dataMap);
    }

    public static void emitNodeStatusEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                           ScenarioRunNode node,
                                           ScenarioStatus status) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_NODE_TYPE, node.getType(),
                KEY_STATUS, status,
                KEY_STEP, node.getIndex(),
                KEY_TOTAL, node.getTotal()));
        emitEvent(sink, ScenarioEventType.NODE_STATUS, dataMap);
    }

    public static void emitNodeErrorEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          ScenarioRunNode node,
                                          String errorMsg,
                                          int totalNodes) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_NODE_TYPE, node.getType(),
                KEY_STATUS, ScenarioStatus.FAILED,
                KEY_STEP, node.getIndex(),
                KEY_TOTAL, totalNodes,
                KEY_ERROR, errorMsg != null ? errorMsg : MSG_UNKNOWN_ERROR));
        emitEvent(sink, ScenarioEventType.NODE_STATUS, dataMap);
    }

    public static void emitSwitchResultEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             String matchStr) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_MATCHED_RULE, matchStr));
        emitEvent(sink, ScenarioEventType.SWITCH_RESULT, dataMap);
    }

    public static void emitLoopProgressEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             int iteration,
                                             int totalDoc,
                                             String detail) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_ITERATION, iteration,
                KEY_TOTAL, totalDoc));
        if (ObjectUtils.isNotEmpty(detail)) {
            dataMap.put(KEY_DETAIL, detail);
        }
        emitEvent(sink, ScenarioEventType.LOOP_PROGRESS, dataMap);
    }

    public static void emitIfResultEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                         ScenarioRunNode node,
                                         Boolean conditionMet,
                                         String branchName) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_CONDITION_MET, conditionMet,
                KEY_BRANCH, branchName));
        emitEvent(sink, ScenarioEventType.IF_RESULT, dataMap);
    }

    public static void emitRagSearchEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                          ScenarioRunNode node,
                                          int chunksFound) {
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_KB_ID, node.getKnowledgeBaseId().toString(),
                KEY_CHUNKS_FOUND, chunksFound));
        emitEvent(sink, ScenarioEventType.RAG_SEARCH, dataMap);
    }

    /**
     * Отправляет результат выходного узла в виде текстового файла через SSE.
     * <p>
     * Frontend может скачать файл с указанными именем, содержимым и MIME-типом.
     *
     * @param sink поток SSE-событий
     * @param node выходной узел сценария
     */
    public static void emitFileOutputEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                           ScenarioRunNode node) {
        ServerSentEvent<Map<String, Object>> event = fileOutputEvent(node.getId(), node.getLabel(), node.getMode(), node.getRules());
        if (event != null) {
            sink.next(event);
        }
    }

    /**
     * Событие FILE_OUTPUT «файл готов» выходного узла (тот же кадр, что шлёт {@link #emitFileOutputEvent}) —
     * для повторной подписки на прогон по run_id.
     *
     * @param nodeId идентификатор узла
     * @param label  метка узла
     * @param mode   режим узла (excel, text_file, text)
     * @param rules  правила узла (разметка документов — ZIP вместо XLSX)
     * @return событие либо {@code null}, если узел не файловый
     */
    public static ServerSentEvent<Map<String, Object>> fileOutputEvent(String nodeId, String label, String mode, String rules) {
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, nodeId,
                KEY_NODE_LABEL, label));
        if (mode == null) {
            return null;
        }
        String resolvedMode = "Excel".equals(label) ? "excel" : mode;
        // в кадр уходит только «файл готов» — байты клиент забирает ручкой
        // GET /runs/{runId}/files/{nodeId} (base64-XLSX в кадре раздувал
        // сокет для корп. шлюза)
        switch (resolvedMode.toUpperCase()) {
            case "EXCEL" -> {
                // с разметкой документов ручка отдаёт ZIP (Excel + размеченные исходники) — имя файла должно совпасть
                boolean annotated = AnnotationConfig.configured(rules);
                dataMap.put(KEY_FILENAME, annotated ? "result.zip" : "result.xlsx");
                dataMap.put(KEY_MIME_TYPE, annotated ? "application/zip"
                        : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            }
            // в живых сценариях встречаются оба варианта режима текстового файла
            case "TEXT_FILE", "TEXT" -> {
                dataMap.put(KEY_FILENAME, "result.txt");
                dataMap.put(KEY_MIME_TYPE, "text/plain");
            }
            default -> {
                return null;
            }
        }
        dataMap.put(KEY_FILE_READY, true);
        return event(ScenarioEventType.FILE_OUTPUT, dataMap);
    }

    public static void emitStepCompleteEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             ScenarioRunStep step) {
        if (step == null) {
            // шаг мог не сохраниться (например, под-сценарии не пишут шаги) — событие не шлём
            return;
        }
        // в сокет уходит ПРЕВЬЮ данных шага: полные тексты доступны ручкой
        // GET /runs/{id}, а мегабайтные кадры валили корп. SOWA
        Map<String, Object> dataMap = new LinkedHashMap<>();
        dataMap.put(KEY_STEP_ID, step.getId().toString());
        dataMap.put(KEY_NODE_ID, node.getId());
        dataMap.put(KEY_NODE_LABEL, node.getLabel());
        dataMap.put(KEY_NODE_TYPE, step.getNodeType());
        dataMap.put(KEY_INPUT_DATA, previewMap(step.getInputData(), Map.of(
                "documents_text", PREVIEW_DOCS,
                "previous_output", PREVIEW_PREV)));
        dataMap.put(KEY_OUTPUT_DATA, previewMap(step.getOutputData(), Map.of(
                KEY_RESULT, PREVIEW_RESULT)));
        dataMap.put(KEY_PROMPT, preview(step.getPromptUsed(), PREVIEW_PROMPT));
        dataMap.put(KEY_STEP_INDEX, node.getIndex());
        dataMap.put(KEY_TOTAL_STEPS, node.getTotal());
        // tokens_used может быть null (детерминированные узлы)
        dataMap.put("tokens_used", step.getTokensUsed());
        emitEvent(sink, ScenarioEventType.STEP_COMPLETE, dataMap);
    }

    public static void emitStepPausedEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                           ScenarioRunNode node,
                                           int totalNodes) {
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_NODE_TYPE, node.getType(),
                KEY_TOTAL_STEPS, totalNodes));
        emitEvent(sink, ScenarioEventType.STEP_PAUSED, dataMap);
    }

    public static void emitProcessingProgressEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                             ScenarioRunNode node,
                                             int iteration,
                                             int totalDoc,
                                             String detail) {
        if (sink == null) {
            return;
        }
        Map<String, Object> dataMap = new HashMap<>(Map.of(
                KEY_NODE_ID, node.getId(),
                KEY_NODE_LABEL, node.getLabel(),
                KEY_ITERATION, iteration,
                KEY_TOTAL, totalDoc));
        if (ObjectUtils.isNotEmpty(detail)) {
            dataMap.put(KEY_DETAIL, detail);
        }
        emitEvent(sink, ScenarioEventType.PROCESSING_PROGRESS, dataMap);
    }

    /**
     * Генерирует и отправляет SSE-событие.
     * <p>
     * Добавляет поле "type" в payload для идентификации типа события на frontend.
     *
     * @param sink      поток SSE-событий
     * @param eventType тип события (например, "status", "node_status", "rag_search")
     * @param data      данные события
     */
    private static void emitEvent(FluxSink<ServerSentEvent<Map<String, Object>>> sink,
                                  ScenarioEventType eventType,
                                  Map<String, Object> data) {
        sink.next(event(eventType, data));
    }

    /**
     * Событие с полем "type" в данных.
     *
     * @param eventType тип события
     * @param data      данные события
     * @return событие
     */
    private static ServerSentEvent<Map<String, Object>> event(ScenarioEventType eventType, Map<String, Object> data) {
        // Build mutable map that includes the "type" field
        Map<String, Object> payload = new LinkedHashMap<>(data);
        payload.put("type", eventType);

        // Don't set .event() — frontend uses generic onmessage handler
        // and parses "type" from the data JSON, not from SSE event field
        return ServerSentEvent.<Map<String, Object>>builder()
                .data(payload)
                .build();
    }
}
