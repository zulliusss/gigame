package ru.sber.cs.ai.gigame.service.scenario.executor;

import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.utils.LlmJson;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

/**
 * Добор реквизитов реестра Формы 3 агентом. Код разбирает документы комплекта ({@link Form3Ops#registry}); там, где
 * разбор не дал поля, нужного для сопоставления со строкой формы (итог и дата акта или УПД, номер УПД, дата подписания
 * при штампе ЭДО, номер договора), модель читает фрагменты документа и возвращает значение с дословной цитатой. Код
 * принимает значение, только если цитата есть в тексте документа, значение — в цитате и разбирается как сумма, дата
 * или номер; дописывает его в пустое поле и помечает запись. Сопоставление строк формы с документами, периоды, суммы
 * и вердикт остаются за кодом ({@link Form3Rows}); строка с добранным документом уходит на второе мнение агента.
 *
 * <p>Операции узла «Трансформация»: «проблемы_реестра» — пробелы разбора с фрагментами текста для агента,
 * «дополнить_реестр» — проверенные значения агента в реестр (конфиг «из_узла» — метка узла агента).
 */
final class Form3Gaps {

    /** Поле записи реестра: какие поля добраны агентом и по каким цитатам. */
    static final String ADD = "добор";
    static final String SUM = "сумма";
    static final String DATE = "дата";
    static final String NUMBER = "номер";
    static final String SIGN_DATE = "дата_подписания";
    private static final String CONTRACTS = "договоры";
    private static final String UPDS = "упд";
    private static final String TEXT = "текст";
    private static final int DEFAULT_LIMIT = 40;
    private static final int DEFAULT_CHARS = 1500;
    private static final int MIN_QUOTE = 8;
    private static final int LINES_PER_FIELD = 12;
    private static final int HEAD_LINES = 6;
    private static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    /** Строка с суммой: число с копейками (разряды через пробел) или «руб». */
    private static final Pattern MONEY_LINE = Pattern.compile("(?:\\d{1,3}(?: \\d{3})+|\\d{4,})[,.]\\d{2}(?!\\d)|руб", FLAGS);
    /** Строка с датой: числом, месяцем словом или подписью штампа ЭДО. */
    @SuppressWarnings("java:S5843") // 12 слов-месяцев — альтернативы не сводятся без потери распознавания дат словом
    private static final Pattern DATE_LINE = Pattern.compile("\\d{2}\\.\\d{2}\\.\\d{2,4}|января|февраля|марта|апреля|мая|июня|"
            + "июля|августа|сентября|октября|ноября|декабря|подпис", FLAGS);
    /** Строка с номером документа или договора. */
    private static final Pattern NUMBER_LINE = Pattern.compile("№|номер|договор|УПД|сч[её]т", FLAGS);
    private static final Pattern DIGIT = Pattern.compile("\\d");
    private static final Pattern NUMBER_VALUE = Pattern.compile("[A-Za-zА-Яа-яЁё0-9][A-Za-zА-Яа-яЁё0-9/\\-_.]{0,59}");
    private static final Pattern AMOUNT_VALUE = Pattern.compile("\\d+\\.\\d{2}");
    private static final Pattern WHITESPACE = Pattern.compile("\\s+");

    private Form3Gaps() {
    }

    /**
     * Пробел разбора: запись реестра и поля, которые код не прочитал.
     *
     * @param no     номер пробела для агента (с 1)
     * @param kind   раздел реестра: «упд», «акты», «договоры»
     * @param doc    запись реестра
     * @param fields незаполненные поля
     */
    record Gap(int no, String kind, Map<String, Object> doc, List<String> fields) {
    }

    /**
     * Операция «проблемы_реестра»: пронумерованные пробелы разбора реестра с фрагментами текста документа, где может
     * быть недостающее поле, — вход агента добора.
     *
     * @param op   конфиг операции: «макс_документов» (40), «макс_знаков» фрагментов одного документа (1500)
     * @param text вход с JSON-реестром
     * @return JSON-массив объектов «№», «файл», «вид», «не_хватает», «фрагменты»
     */
    static String gapsJson(Map<String, Object> op, String text) {
        int chars = intParam(op, "макс_знаков", DEFAULT_CHARS);
        List<Map<String, Object>> out = new ArrayList<>();
        for (Gap gap : gaps(registry(text), intParam(op, "макс_документов", DEFAULT_LIMIT))) {
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("№", gap.no());
            item.put("файл", Form3Ops.str(gap.doc().get("файл")));
            item.put("вид", gap.kind());
            item.put("не_хватает", String.join(", ", gap.fields()));
            item.put("фрагменты", excerpt(Form3Ops.str(gap.doc().get(TEXT)), gap.fields(), chars));
            out.add(item);
        }
        return Form3Ops.toJson(out);
    }

    /**
     * Операция «дополнить_реестр»: значения агента, прошедшие проверку ({@link #accept}), дописываются в пустые поля
     * реестра. Пробелы нумеруются так же, как в «проблемы_реестра», поэтому параметр «макс_документов» у обеих
     * операций должен совпадать.
     *
     * @param op     конфиг операции: «из_узла» (метка агента), «макс_документов»
     * @param text   вход с JSON-реестром
     * @param answer выход агента: JSON-массив объектов «№», «поле», «значение», «цитата»
     * @return реестр с добранными полями
     */
    static String fill(Map<String, Object> op, String text, String answer) {
        Map<String, Object> registry = registry(text);
        List<Gap> gaps = gaps(registry, intParam(op, "макс_документов", DEFAULT_LIMIT));
        for (Map<String, Object> item : answers(answer)) {
            Gap gap = gapOf(item, gaps);
            if (gap != null) {
                accept(gap, item);
            }
        }
        return Form3Ops.toJson(registry);
    }

    /**
     * Пробелы разбора в порядке разделов «упд», «акты», «договоры».
     *
     * @param registry реестр
     * @param limit    сколько пробелов взять
     * @return пробелы с номерами с 1
     */
    static List<Gap> gaps(Map<String, Object> registry, int limit) {
        List<Gap> out = new ArrayList<>();
        for (String kind : List.of(UPDS, "акты", CONTRACTS)) {
            for (Map<String, Object> doc : entries(registry, kind)) {
                List<String> fields = missing(kind, doc);
                if (!fields.isEmpty() && out.size() < limit) {
                    out.add(new Gap(out.size() + 1, kind, doc, fields));
                }
            }
        }
        return out;
    }

    /**
     * Поля записи, которые разбор не заполнил. У документа без текста (нераспознанный скан) агенту читать нечего —
     * пробелов нет. У договора — номер без цифр; у УПД и акта — сумма, дата, номер УПД, дата подписания при штампе ЭДО.
     *
     * @param kind раздел реестра
     * @param doc  запись реестра
     * @return незаполненные поля
     */
    static List<String> missing(String kind, Map<String, Object> doc) {
        List<String> fields = new ArrayList<>();
        if (Boolean.TRUE.equals(doc.get("без_текста")) || Form3Ops.str(doc.get(TEXT)).isEmpty()) {
            return fields;
        }
        if (CONTRACTS.equals(kind)) {
            addIf(fields, NUMBER, !DIGIT.matcher(Form3Ops.str(doc.get(NUMBER))).find());
            return fields;
        }
        addIf(fields, SUM, Form3Ops.str(doc.get(SUM)).isEmpty());
        addIf(fields, DATE, Form3Ops.str(doc.get(DATE)).isEmpty());
        addIf(fields, NUMBER, UPDS.equals(kind) && Form3Ops.str(doc.get(NUMBER)).isEmpty());
        addIf(fields, SIGN_DATE, Boolean.TRUE.equals(doc.get(Form3Acts.STAMP)) && Form3Ops.str(doc.get(SIGN_DATE)).isEmpty());
        return fields;
    }

    /**
     * Строки текста документа, где может быть недостающее поле, в порядке следования: для суммы — последние строки с
     * суммами (итог обычно в конце), для даты — первые строки с датами, для номера — начало документа и строки с «№».
     *
     * @param text   текст документа
     * @param fields недостающие поля
     * @param chars  предел длины фрагментов
     * @return фрагменты через перевод строки
     */
    static String excerpt(String text, List<String> fields, int chars) {
        String[] lines = Form3Ops.normalize(text).split("\n");
        Set<Integer> picked = new TreeSet<>();
        for (String field : fields) {
            pick(lines, field, picked);
        }
        StringBuilder out = new StringBuilder();
        for (int i : picked) {
            String line = lines[i].strip();
            if (!line.isEmpty() && out.length() + line.length() + 1 <= chars) {
                out.append(line).append('\n');
            }
        }
        return out.toString().strip();
    }

    private static void pick(String[] lines, String field, Set<Integer> picked) {
        Pattern pattern = patternFor(field);
        int head = NUMBER.equals(field) ? HEAD_LINES : 0;
        boolean fromEnd = SUM.equals(field);
        int found = 0;
        for (int k = 0; k < lines.length && found < LINES_PER_FIELD; k++) {
            int i = fromEnd ? lines.length - 1 - k : k;
            if (i < head || pattern.matcher(lines[i]).find()) {
                picked.add(i);
                found++;
            }
        }
    }

    private static Pattern patternFor(String field) {
        if (SUM.equals(field)) {
            return MONEY_LINE;
        }
        return NUMBER.equals(field) ? NUMBER_LINE : DATE_LINE;
    }

    /**
     * Проверка ответа агента: цитата не короче 8 знаков дословно есть в тексте документа, значение — в цитате (пробелы
     * и неразрывные пробелы не различаются), поле ещё не заполнено разбором, значение разбирается как сумма, дата или
     * номер. Принятое значение записывается в поле, в пометку «добор» — поле и цитата, запись — на проверку агенту.
     *
     * @param gap  пробел разбора
     * @param item ответ агента по пробелу
     * @return {@code true}, если значение принято
     */
    static boolean accept(Gap gap, Map<String, Object> item) {
        String field = Form3Ops.str(item.get("поле"));
        String quote = flat(Form3Ops.str(item.get("цитата")));
        String raw = flat(Form3Ops.str(item.get("значение")));
        String value = parse(field, raw);
        boolean ok = quote.length() >= MIN_QUOTE && !value.isEmpty() && quote.contains(raw)
                && flat(Form3Ops.str(gap.doc().get(TEXT))).contains(quote) && missing(gap.kind(), gap.doc()).contains(field);
        if (ok) {
            gap.doc().put(field, value);
            noteOf(gap.doc()).add(field + " «" + quote + "»");
            gap.doc().put(Form3Rows.AGENT_CHECK, Form3Rows.YES);
        }
        return ok;
    }

    /**
     * Значение поля из ответа агента в виде реестра: сумма «1234567.89», дата «dd.MM.yyyy», номер — слово с цифрой;
     * пусто, если не разбирается.
     *
     * @param field поле реестра
     * @param raw   значение из ответа агента
     * @return значение или пусто
     */
    static String parse(String field, String raw) {
        if (SUM.equals(field)) {
            // сумма скана словами («2 250 000 рублей 00 копеек») — разбором итога акта, если ячейка формы её не читает
            String amount = Form3Form.amount(raw);
            if (amount.isEmpty()) {
                amount = Form3Acts.scanAmount(raw);
            }
            return AMOUNT_VALUE.matcher(amount).matches() && !"0.00".equals(amount) ? amount : "";
        }
        if (NUMBER.equals(field)) {
            return NUMBER_VALUE.matcher(raw).matches() && DIGIT.matcher(raw).find() ? raw : "";
        }
        return Form3Form.actDate(raw, "");
    }

    /**
     * Пометка добора из акта — в запись строки: {@link Form3Rows} собирает её из акта заново.
     *
     * @param act запись акта реестра (может быть {@code null})
     * @param upd запись строки
     * @return запись строки
     */
    static Map<String, Object> carry(Map<String, Object> act, Map<String, Object> upd) {
        if (act != null && act.get(ADD) != null) {
            upd.put(ADD, act.get(ADD));
            upd.put(Form3Rows.AGENT_CHECK, Form3Rows.YES);
        }
        return upd;
    }

    /**
     * Пометка аудита строки: какие реквизиты её документа и договора добраны агентом.
     *
     * @param upd       документ строки
     * @param contracts договоры строки
     * @return «; реквизиты добраны агентом …» или пусто
     */
    static String note(Map<String, Object> upd, List<Map<String, Object>> contracts) {
        List<String> parts = new ArrayList<>(texts(upd.get(ADD)));
        for (Map<String, Object> contract : contracts) {
            texts(contract.get(ADD)).forEach(t -> parts.add("договор: " + t));
        }
        return parts.isEmpty() ? "" : "; реквизиты добраны агентом, цитаты проверены кодом: " + String.join("; ", parts);
    }

    private static List<String> texts(Object note) {
        return note instanceof Collection<?> values ? values.stream().map(String::valueOf).toList() : List.of();
    }

    @SuppressWarnings("unchecked")
    private static List<String> noteOf(Map<String, Object> doc) {
        if (doc.get(ADD) instanceof List<?> list) {
            return (List<String>) list;
        }
        List<String> fresh = new ArrayList<>();
        doc.put(ADD, fresh);
        return fresh;
    }

    private static Gap gapOf(Map<String, Object> item, List<Gap> gaps) {
        int no = number(item.get("№"));
        if (no < 1 || no > gaps.size()) {
            return null;
        }
        Gap gap = gaps.get(no - 1);
        return gap.fields().contains(Form3Ops.str(item.get("поле"))) ? gap : null;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> registry(String text) {
        LlmJson.Parsed block = LlmJson.first(text == null ? "" : text, LlmJson.OBJECT).first();
        if (block == null) {
            throw new ScenarioException("Узел «Трансформация», добор реквизитов: во входе нет реестра документов");
        }
        return (Map<String, Object>) block.value();
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> entries(Map<String, Object> registry, String kind) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (registry.get(kind) instanceof List<?> list) {
            list.stream().filter(Map.class::isInstance).forEach(o -> out.add((Map<String, Object>) o));
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> answers(String answer) {
        LlmJson.Parsed block = LlmJson.firstObjectArray(answer == null ? "" : answer).first();
        List<Map<String, Object>> out = new ArrayList<>();
        if (block != null && block.value() instanceof List<?> list) {
            list.stream().filter(Map.class::isInstance).forEach(o -> out.add((Map<String, Object>) o));
        }
        return out;
    }

    private static String flat(String text) {
        return WHITESPACE.matcher(Form3Ops.normalize(text)).replaceAll(" ").strip();
    }

    private static int number(Object value) {
        try {
            return (int) Double.parseDouble(Form3Ops.str(value));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static int intParam(Map<String, Object> op, String key, int fallback) {
        int value = number(op.get(key));
        return value > 0 ? value : fallback;
    }

    private static void addIf(List<String> fields, String field, boolean value) {
        if (value) {
            fields.add(field);
        }
    }
}
