package ru.sber.cs.ai.gigame.utils;

import lombok.NonNull;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.springframework.http.codec.multipart.FilePart;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.Objects;

/**
 * {@link FilePart} поверх массива байтов — для внутренних загрузок документов
 * (например, сохранение результата прогона сценария в базу знаний) без
 * HTTP-запроса.
 *
 * @param filename имя файла
 * @param bytes    содержимое
 */
public record InMemoryFilePart(String filename, byte[] bytes) implements FilePart {

    @Override
    @NonNull
    public String name() {
        return "files";
    }

    @Override
    @NonNull
    public HttpHeaders headers() {
        return new HttpHeaders();
    }

    @Override
    @NonNull
    public Flux<DataBuffer> content() {
        return Flux.just(new DefaultDataBufferFactory().wrap(bytes));
    }

    @Override
    @NonNull
    public Mono<Void> transferTo(@NonNull Path dest) {
        // файлы пользователей на диск сервера не пишутся (требование безопасности контура, 30.09.2026):
        // содержимое доступно только через content()
        return Mono.error(new UnsupportedOperationException("запись загруженного файла на диск запрещена"));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof InMemoryFilePart other)) {
            return false;
        }
        return filename.equals(other.filename) && Arrays.equals(bytes, other.bytes);
    }

    @Override
    public int hashCode() {
        int result = Objects.hashCode(filename);
        result = 31 * result + Arrays.hashCode(bytes);
        return result;
    }

    @Override
    @NonNull
    public String toString() {
        return "InMemoryFilePart{filename='" + filename + "', bytes=" + Arrays.toString(bytes) + "}";
    }
}
