package ru.sber.cs.ai.gigame.service.scenario;

import java.util.Arrays;

/**
 * Документ, подготовленный к прогону сценария: имя, извлечённый текст и исходное содержимое файла.
 * <p>
 * Для файлов из ZIP-архива имя содержит имя архива и путь внутри него
 * ("архив.zip/папка/файл.pdf") — по нему работает группировка документов.
 * Исходное содержимое нужно только складу оригиналов для разметки находок ({@code RawFileStore});
 * у документов-маркеров (нераспакованный архив, нечитаемый файл) его нет.
 *
 * @param filename имя документа
 * @param text     извлечённый текст
 * @param content  исходное содержимое файла (может быть {@code null})
 */
public record DocumentText(String filename, String text, byte[] content) {

    /**
     * Документ без исходного содержимого.
     *
     * @param filename имя документа
     * @param text     извлечённый текст
     */
    public DocumentText(String filename, String text) {
        this(filename, text, null);
    }

    /** Сравнение по содержимому массива байтов, а не по ссылке. */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof DocumentText that)) {
            return false;
        }
        return filename.equals(that.filename) && text.equals(that.text) && Arrays.equals(content, that.content);
    }

    @Override
    public int hashCode() {
        int result = filename.hashCode();
        result = 31 * result + text.hashCode();
        result = 31 * result + Arrays.hashCode(content);
        return result;
    }

    @Override
    public String toString() {
        return "DocumentText[filename=" + filename + ", text=" + text + ", content=" + Arrays.toString(content) + "]";
    }
}
