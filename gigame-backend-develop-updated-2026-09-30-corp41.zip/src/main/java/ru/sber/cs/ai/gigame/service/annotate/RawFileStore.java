package ru.sber.cs.ai.gigame.service.annotate;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.sber.cs.ai.gigame.service.DocumentService;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * Склад исходных файлов документов для разметки находок — только в памяти сервера.
 * <p>
 * Файлы пользователей на диск сервера и в базу данных не пишутся (требование безопасности контура, 30.09.2026):
 * содержимое загруженных документов хранится в памяти по ключу кэша документов (сценарий + пользователь) и живёт
 * {@code app.annotate.raw-ttl-hours} часов с последней загрузки, а также в снимках прогонов, закреплённых на момент
 * запуска ({@link #snapshotForRun}). Суммарный объём ограничен {@code app.annotate.raw-max-mb}: перед сохранением
 * самые старые ключи (затем снимки прогонов) вытесняются; файл больше предела не сохраняется — загрузка не падает,
 * разметка документа будет недоступна. Перезапуск сервера склад очищает.
 */
@Slf4j
@Service
public class RawFileStore {

    private static final long MB = 1024L * 1024;
    private static final int DEFAULT_MAX_MB = 2048;

    @Value("${app.annotate.raw-ttl-hours:24}")
    private int ttlHours;

    /** Предел суммарного объёма склада, МБ; 0 и меньше — без предела. */
    @Value("${app.annotate.raw-max-mb:2048}")
    private int maxMb = DEFAULT_MAX_MB;

    /** Файлы ключей загрузок: ключ кэша → (стем файла → файл). */
    private final Map<UUID, Bucket> keys = new LinkedHashMap<>();
    /** Снимки оригиналов прогонов: прогон → (стем файла → файл), файлы разделяются с ключом без копирования. */
    private final Map<UUID, Bucket> runs = new LinkedHashMap<>();

    /** Файл на складе: имя, содержимое и момент сохранения. */
    private record Stored(String name, byte[] content, Instant savedAt) {
    }

    /** Файлы одного ключа или снимка и момент последнего изменения. */
    private static final class Bucket {
        private final Map<String, Stored> files = new LinkedHashMap<>();
        private Instant touched;

        Bucket(Instant touched) {
            this.touched = touched;
        }
    }

    /** Конструктор для Spring (настройки внедряются в поля). */
    public RawFileStore() {
    }

    /**
     * Склад с заданным сроком жизни (тесты), предел объёма — по умолчанию.
     *
     * @param ttlHours срок жизни файлов ключа, часов
     */
    public RawFileStore(int ttlHours) {
        this(ttlHours, DEFAULT_MAX_MB);
    }

    /**
     * Склад с заданным сроком жизни и пределом объёма (тесты).
     *
     * @param ttlHours срок жизни файлов ключа, часов
     * @param maxMb    предел суммарного объёма, МБ (0 — без предела)
     */
    public RawFileStore(int ttlHours, int maxMb) {
        this.ttlHours = ttlHours;
        this.maxMb = maxMb;
    }

    /**
     * Сохраняет исходный файл документа под ключом «имя + хэш текста»: документ с тем же именем и текстом
     * перезаписывается, с тем же именем и другим текстом — хранится рядом.
     *
     * @param key     ключ кэша документов
     * @param name    имя документа
     * @param text    извлечённый текст документа (как в кэше документов; {@code null} — ключ только по имени)
     * @param content содержимое файла
     * @return {@code true}, если файл на складе (пустое содержимое — нечего сохранять, тоже {@code true});
     *         {@code false} — не сохранён (предел объёма): разметка документа будет недоступна
     */
    public synchronized boolean save(UUID key, String name, String text, byte[] content) {
        if (content == null || content.length == 0) {
            return true;
        }
        Instant now = Instant.now();
        if (!reserve(key, content.length)) {
            log.warn("Склад исходных файлов: «{}» ({} КБ) не сохранён — предел склада {} МБ — разметка этого документа "
                    + "будет недоступна", name, content.length / 1024, maxMb);
            return false;
        }
        Bucket bucket = keys.computeIfAbsent(key, k -> new Bucket(now));
        bucket.files.put(stem(name, text), new Stored(name, content, now));
        bucket.touched = now;
        return true;
    }

    /**
     * Исходный файл документа: сначала из снимка прогона, затем со склада ключа.
     *
     * @param key   ключ кэша документов
     * @param runId прогон ({@code null} — только склад ключа)
     * @param name  имя документа
     * @param text  текст документа (как при сохранении)
     * @return содержимое файла или пусто
     */
    public synchronized Optional<byte[]> load(UUID key, UUID runId, String name, String text) {
        String stem = stem(name, text);
        Stored stored = runId == null || !runs.containsKey(runId) ? null : runs.get(runId).files.get(stem);
        if (stored == null && keys.containsKey(key)) {
            stored = keys.get(key).files.get(stem);
        }
        return stored == null ? Optional.empty() : Optional.of(stored.content());
    }

    /**
     * Закрепляет оригиналы ключа за прогоном: снимок ссылается на файлы ключа на момент вызова (без копирования
     * содержимого). Повторный вызов для того же прогона ничего не меняет; если склад ключа пуст (очищен новой
     * загрузкой), источником служит снимок предыдущего прогона.
     *
     * @param key           ключ кэша документов
     * @param runId         прогон
     * @param previousRunId прогон-предшественник при возобновлении ({@code null} — нет)
     */
    public synchronized void snapshotForRun(UUID key, UUID runId, UUID previousRunId) {
        if (runs.containsKey(runId)) {
            return;
        }
        Bucket source = keys.get(key);
        if ((source == null || source.files.isEmpty()) && previousRunId != null) {
            source = runs.get(previousRunId);
        }
        if (source == null || source.files.isEmpty()) {
            return;
        }
        Bucket snapshot = new Bucket(Instant.now());
        snapshot.files.putAll(source.files);
        runs.put(runId, snapshot);
        log.info("Склад исходных файлов: снимок оригиналов прогона {} — {} файл(ов)", runId, snapshot.files.size());
    }

    /**
     * Удаляет все файлы ключа (новая загрузка без догрузки); снимки прогонов не трогает.
     *
     * @param key ключ кэша документов
     */
    public synchronized void clear(UUID key) {
        keys.remove(key);
    }

    /** Плановая чистка: ключи без загрузок дольше срока жизни и снимки прогонов старше срока жизни. */
    @Scheduled(fixedRateString = "${app.annotate.cleanup-rate-ms:3600000}")
    public synchronized void evictStale() {
        evictStale(Instant.now());
    }

    /**
     * Чистка относительно заданного момента (тесты).
     *
     * @param now момент, от которого отсчитывается срок жизни
     */
    synchronized void evictStale(Instant now) {
        Instant deadline = now.minus(Duration.ofHours(ttlHours));
        int before = keys.size() + runs.size();
        keys.values().removeIf(bucket -> bucket.touched.isBefore(deadline));
        runs.values().removeIf(bucket -> bucket.touched.isBefore(deadline));
        int removed = before - keys.size() - runs.size();
        if (removed > 0) {
            log.info("Склад исходных файлов: вычищено {} ключей/снимков старше {} ч", removed, ttlHours);
        }
    }

    /**
     * Занятый объём склада, байт: каждый файл считается один раз, даже если на него ссылаются ключ и снимки.
     *
     * @return занятый объём
     */
    public synchronized long usedBytes() {
        Set<byte[]> distinct = Collections.newSetFromMap(new IdentityHashMap<>());
        long total = 0;
        for (Bucket bucket : buckets()) {
            for (Stored stored : bucket.files.values()) {
                if (distinct.add(stored.content())) {
                    total += stored.content().length;
                }
            }
        }
        return total;
    }

    private List<Bucket> buckets() {
        List<Bucket> all = new ArrayList<>(keys.values());
        all.addAll(runs.values());
        return all;
    }

    /**
     * Резервирует место под файл: при превышении предела объёма вытесняет самые старые ключи (кроме текущего),
     * затем самые старые снимки прогонов.
     *
     * @return {@code false}, если файл не помещается даже в пустой склад
     */
    private boolean reserve(UUID key, long size) {
        if (maxMb <= 0) {
            return true;
        }
        long limit = maxMb * MB;
        if (size > limit) {
            return false;
        }
        while (usedBytes() + size > limit) {
            if (!evictOldest(key)) {
                return usedBytes() + size <= limit;
            }
        }
        return true;
    }

    /** Вытесняет самый старый ключ (кроме {@code keep}), иначе самый старый снимок; {@code false} — нечего вытеснять. */
    private boolean evictOldest(UUID keep) {
        Optional<UUID> oldestKey = keys.entrySet().stream().filter(e -> !e.getKey().equals(keep))
                .min(Comparator.comparing(e -> e.getValue().touched)).map(Map.Entry::getKey);
        if (oldestKey.isPresent()) {
            keys.remove(oldestKey.get());
            log.warn("Склад исходных файлов: предел объёма {} МБ достигнут — вытеснен ключ {}", maxMb, oldestKey.get());
            return true;
        }
        Optional<UUID> oldestRun = runs.entrySet().stream().min(Comparator.comparing(e -> e.getValue().touched))
                .map(Map.Entry::getKey);
        if (oldestRun.isPresent()) {
            runs.remove(oldestRun.get());
            log.warn("Склад исходных файлов: предел объёма {} МБ достигнут — вытеснен снимок прогона {}", maxMb, oldestRun.get());
            return true;
        }
        return false;
    }

    /** Стем файла на складе: SHA-256 от имени и SHA-256 текста (без текста — от имени). */
    private static String stem(String name, String text) {
        String base = text == null ? name : name + "\n" + DocumentService.sha256Hex(text.getBytes(StandardCharsets.UTF_8));
        return DocumentService.sha256Hex(base.getBytes(StandardCharsets.UTF_8));
    }
}
