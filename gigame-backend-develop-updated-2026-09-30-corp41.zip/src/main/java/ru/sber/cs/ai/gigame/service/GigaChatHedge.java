package ru.sber.cs.ai.gigame.service;

import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Consumer;

/**
 * Дублирующий запрос к GigaChat при зависшем ответе.
 * <p>
 * Прогоны 25.09.2026 на стенде: запрос к GigaChat изредка повисает — ответа нет до read-timeout клиента (600 с,
 * «EOF reached while reading»), а тот же запрос, отправленный заново, отвечает за десятки секунд. По логам стендов
 * 16–25.09 одиночный вызов модели дольше 240 с — 8 из 3390, почти все они — зависания (99-й процентиль — 162 с).
 * Узел терял до 3 × 660 с и падал: Форма 3 — «Второе мнение (агент)», ПЗД — «Кандидаты норм».
 * <p>
 * Если за {@code app.gigachat.hedge-after-seconds} (env {@code GIGACHAT_HEDGE_AFTER_SECONDS}, по умолчанию 240,
 * 0 — выключено) ответа нет, тот же запрос уходит второй раз в отдельном пуле. Первый успешный ответ побеждает,
 * другая попытка отменяется. Ошибка одной попытки не прерывает ожидание другой; ошибка обеих — ошибка первой из них.
 * Общий потолок ожидания — прежний страховочный ({@code app.gigachat.call-hard-timeout-seconds}), считается от начала
 * первой попытки, текст ошибки по его истечении — прежний: повторы клиента распознают его как таймаут ответа.
 * <p>
 * Дублей одновременно не больше {@code app.gigachat.hedge-max-concurrent} (env {@code GIGACHAT_HEDGE_MAX_CONCURRENT},
 * по умолчанию 2) — это размер пула дублей без очереди: при массовом замедлении GigaChat дубли не удваивают нагрузку
 * на ключ, а занятый пул (в том числе зависшими дублями) просто не даёт нового дубля.
 * <p>
 * Дубль берёт своё разрешение общего ограничителя запросов ({@link GigaChatConcurrencyLimiter#tryAcquire}) без ожидания:
 * нет свободного потока ключа — дубля нет. Стенд 25.09.2026: ключ с одним потоком на второй одновременный запрос
 * обрывал оба («EOF reached while reading») и отвечал 429, повтор первой попытки снова зависал до потолка — поэтому
 * {@code app.gigachat.max-concurrent} должен совпадать с числом потоков ключа.
 */
@Component
@Slf4j
public class GigaChatHedge {

    /** Порог дубля по умолчанию, с. */
    static final long DEFAULT_AFTER_SECONDS = 240L;
    /** Дублей одновременно по умолчанию. */
    static final int DEFAULT_MAX_CONCURRENT = 2;
    /** Ошибка прерванного ожидания — как у страховочного вызова клиента. */
    static final String INTERRUPTED = "LLM-вызов прерван";
    /** Ошибка попытки, завершившейся не исключением времени выполнения. */
    static final String FAILED = "Сбой LLM-вызова";

    /** Порог дубля, с; 0 и меньше — дублей нет. */
    @Value("${app.gigachat.hedge-after-seconds:240}")
    private long afterSeconds = DEFAULT_AFTER_SECONDS;
    /** Дублей одновременно (размер пула дублей). */
    @Value("${app.gigachat.hedge-max-concurrent:2}")
    private int maxConcurrent = DEFAULT_MAX_CONCURRENT;
    /** Порог дубля, мс, заданный конструктором (тесты); меньше нуля — из {@link #afterSeconds}. */
    private final long afterMillisOverride;
    /** Пул дублей: создаётся при первом дубле; volatile — безопасная публикация лениво создаваемого пула. */
    @SuppressWarnings("java:S3077")
    private volatile ThreadPoolExecutor pool;

    /** Конструктор для Spring: настройки приходят в поля из конфигурации. */
    public GigaChatHedge() {
        this.afterMillisOverride = -1;
    }

    /**
     * Конструктор с настройками в миллисекундах (тесты).
     *
     * @param afterMillis   порог дубля, мс; 0 — выключено
     * @param maxConcurrent дублей одновременно
     */
    GigaChatHedge(long afterMillis, int maxConcurrent) {
        this.afterMillisOverride = Math.max(0, afterMillis);
        this.maxConcurrent = maxConcurrent;
    }

    /**
     * Выключенный дубль: клиенты, созданные без Spring, работают как раньше.
     *
     * @return экземпляр без дублей
     */
    static GigaChatHedge disabled() {
        return new GigaChatHedge(0, 0);
    }

    /**
     * @return {@code true}, если дубль включён (порог больше нуля и пул не пустой)
     */
    public boolean enabled() {
        return afterMillis() > 0 && maxConcurrent > 0;
    }

    /**
     * Вызов с дублем при зависании.
     *
     * @param call          одна попытка вызова модели
     * @param primaryPool   пул первой попытки (страховочные LLM-вызовы клиента)
     * @param timeoutMillis общий потолок ожидания от начала первой попытки, мс
     * @param timeoutText   текст ошибки по истечении потолка
     * @param notice        уведомление в журнал прогона об отправленном дубле
     * @param limiter       общий ограничитель запросов: дубль берёт у него разрешение без ожидания (null — без проверки)
     * @param <T>           тип ответа
     * @return ответ первой успешной попытки
     * @throws GigaChatException потолок истёк или ожидание прервано; ошибка попыток — как есть
     */
    public <T> T call(Callable<T> call, ExecutorService primaryPool, long timeoutMillis, String timeoutText,
                      Consumer<String> notice, GigaChatConcurrencyLimiter limiter) {
        long start = System.nanoTime();
        Race<T> race = new Race<>(call);
        race.submit(primaryPool, null);
        try {
            return await(race, start, new Wait(timeoutMillis, timeoutText, notice, limiter));
        } finally {
            race.cancel();
        }
    }

    /**
     * Параметры ожидания одного вызова.
     *
     * @param timeoutMillis общий потолок ожидания, мс
     * @param timeoutText   текст ошибки по истечении потолка
     * @param notice        уведомление в журнал прогона об отправленном дубле
     * @param limiter       общий ограничитель запросов (null — без проверки)
     */
    private record Wait(long timeoutMillis, String timeoutText, Consumer<String> notice, GigaChatConcurrencyLimiter limiter) {
    }

    /** Ожидание первого успешного ответа до потолка; по порогу — один дубль. */
    private <T> T await(Race<T> race, long start, Wait wait) {
        long deadline = start + TimeUnit.MILLISECONDS.toNanos(wait.timeoutMillis());
        long hedgeAt = start + TimeUnit.MILLISECONDS.toNanos(afterMillis());
        boolean hedgeDecided = !enabled() || hedgeAt >= deadline;
        while (true) {
            long now = System.nanoTime();
            if (now >= deadline) {
                throw new GigaChatException(wait.timeoutText(), new TimeoutException(wait.timeoutText()));
            }
            Future<T> done = race.poll(Math.min(hedgeDecided ? deadline : hedgeAt, deadline) - now);
            if (done != null) {
                if (race.completed(done)) {
                    logWinner(race, start);
                    return race.result();
                }
            } else if (!hedgeDecided && System.nanoTime() >= hedgeAt) {
                hedgeDecided = true;
                hedge(race, start, wait);
            }
        }
    }

    /** Отправка дубля, если у ограничителя есть свободный поток ключа, а в пуле дублей — свободное место. */
    private <T> void hedge(Race<T> race, long start, Wait wait) {
        long waited = TimeUnit.NANOSECONDS.toSeconds(System.nanoTime() - start);
        GigaChatConcurrencyLimiter.Permit permit = wait.limiter() == null
                ? GigaChatConcurrencyLimiter.Permit.free() : wait.limiter().tryAcquire();
        if (permit == null) {
            log.info("[{}] GigaChat: ответ не получен за {} с, но свободного потока ключа нет — дубль не отправлен, "
                    + "ждём первую попытку", CurrentUserHolder.getCurrentUser(), waited);
            return;
        }
        try {
            race.submit(hedgePool(), permit);
        } catch (RejectedExecutionException e) {
            permit.close();
            log.info("[{}] GigaChat: ответ не получен за {} с, но свободных мест для дубля нет ({}) — ждём первую попытку",
                    CurrentUserHolder.getCurrentUser(), waited, maxConcurrent);
            return;
        }
        log.warn("[{}] GigaChat: ответ не получен за {} с — отправлен дублирующий запрос, засчитается первый ответ",
                CurrentUserHolder.getCurrentUser(), waited);
        if (wait.notice() != null) {
            wait.notice().accept("⚠ GigaChat не ответил за " + waited + " с — отправлен дублирующий запрос, будет взят первый ответ");
        }
    }

    private <T> void logWinner(Race<T> race, long start) {
        if (race.attempts() > 1) {
            log.info("[{}] GigaChat: ответила попытка {} из {} через {} с от начала", CurrentUserHolder.getCurrentUser(),
                    race.winner() + 1, race.attempts(), TimeUnit.NANOSECONDS.toSeconds(System.nanoTime() - start));
        }
    }

    private long afterMillis() {
        return afterMillisOverride >= 0 ? afterMillisOverride : TimeUnit.SECONDS.toMillis(Math.max(0, afterSeconds));
    }

    /**
     * Пул дублей без очереди: поток на дубль, занятый пул отклоняет новый дубль.
     *
     * @return пул дублей
     */
    private ThreadPoolExecutor hedgePool() {
        ThreadPoolExecutor current = pool;
        if (current == null) {
            synchronized (this) {
                if (pool == null) {
                    pool = new ThreadPoolExecutor(maxConcurrent, maxConcurrent, 60, TimeUnit.SECONDS,
                            new SynchronousQueue<>(), r -> {
                        Thread t = new Thread(r, "llm-hedge");
                        t.setDaemon(true);
                        return t;
                    });
                    pool.allowCoreThreadTimeOut(true);
                }
                current = pool;
            }
        }
        return current;
    }

    /** Останавливает пул дублей при выключении приложения. */
    @PreDestroy
    public void shutdown() {
        ThreadPoolExecutor current = pool;
        if (current != null) {
            current.shutdownNow();
        }
    }

    /**
     * Попытки одного вызова: общая очередь завершённых, счётчик незавершённых, первая ошибка и ответ.
     *
     * @param <T> тип ответа
     */
    private static final class Race<T> {
        private final Callable<T> call;
        private final BlockingQueue<Future<T>> done = new LinkedBlockingQueue<>();
        private final List<Future<T>> futures = new ArrayList<>();
        private final List<GigaChatConcurrencyLimiter.Permit> permits = new ArrayList<>();
        private int pending;
        private Throwable error;
        private T result;
        private int winner;

        private Race(Callable<T> call) {
            this.call = call;
        }

        /** Попытка в пул; разрешение дубля (null у первой попытки) закрывается по её завершении и при отмене гонки. */
        private void submit(ExecutorService executor, GigaChatConcurrencyLimiter.Permit permit) {
            Callable<T> attempt = permit == null ? call : () -> {
                try {
                    return call.call();
                } finally {
                    permit.close();
                }
            };
            futures.add(new ExecutorCompletionService<>(executor, done).submit(attempt));
            if (permit != null) {
                permits.add(permit);
            }
            pending++;
        }

        private Future<T> poll(long nanos) {
            try {
                return done.poll(Math.max(0, nanos), TimeUnit.NANOSECONDS);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new GigaChatException(INTERRUPTED, e);
            }
        }

        /**
         * Итог завершённой попытки.
         *
         * @param future завершённая попытка
         * @return {@code true}, если попытка успешна; ошибка последней незавершённой попытки — исключение
         */
        private boolean completed(Future<T> future) {
            pending--;
            try {
                result = future.get();
                winner = futures.indexOf(future);
                return true;
            } catch (ExecutionException e) {
                error = error == null ? e.getCause() : error;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new GigaChatException(INTERRUPTED, e);
            }
            if (pending == 0) {
                throw error instanceof RuntimeException re ? re : new GigaChatException(FAILED, error);
            }
            return false;
        }

        private T result() {
            return result;
        }

        private int attempts() {
            return futures.size();
        }

        private int winner() {
            return winner;
        }

        private void cancel() {
            futures.forEach(f -> f.cancel(true));
            permits.forEach(GigaChatConcurrencyLimiter.Permit::close);
        }
    }
}
