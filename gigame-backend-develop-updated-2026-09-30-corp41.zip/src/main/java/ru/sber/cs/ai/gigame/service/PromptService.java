package ru.sber.cs.ai.gigame.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.sber.cs.ai.gigame.dto.prompt.PromptCreate;
import ru.sber.cs.ai.gigame.dto.prompt.PromptResponse;
import ru.sber.cs.ai.gigame.dto.prompt.PromptUpdate;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.exception.ValidationException;
import ru.sber.cs.ai.gigame.model.Prompt;
import ru.sber.cs.ai.gigame.model.PromptRating;
import ru.sber.cs.ai.gigame.repository.PromptRatingRepository;
import ru.sber.cs.ai.gigame.repository.PromptRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.SchemaLimitUtils;
import ru.sber.cs.ai.gigame.utils.UserUtils;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * База промптов: проверенные формулировки, которые надёжно решают задачи.
 * Общие промпты видны всем; статистика (использования, рейтинг) помогает
 * находить лучшие. Изменять и удалять промпт может только владелец.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PromptService {

    /** maxLength поля title в спецификации (и VARCHAR(255) в БД). */
    static final int TITLE_MAX_LENGTH = 255;
    /** maxLength поля description в спецификации. */
    static final int DESCRIPTION_MAX_LENGTH = 1024;
    /** maxLength поля text в спецификации. */
    static final int TEXT_MAX_LENGTH = 500_000;
    /** maxLength поля model в спецификации (и VARCHAR(64) в БД). */
    static final int MODEL_MAX_LENGTH = 64;
    /** maxItems списка промптов в спецификации: хвост сверх лимита не отдаётся. */
    static final int RESPONSE_MAX_ITEMS = 1000;

    private final PromptRepository promptRepository;
    private final PromptRatingRepository promptRatingRepository;

    /**
     * Промпты, видимые пользователю (свои + общие), со статистикой. Не больше
     * {@link #RESPONSE_MAX_ITEMS} самых свежих (maxItems спецификации; каждый
     * промпт несёт полный текст, и список без предела рос вместе с базой).
     *
     * @return промпты, новые сверху
     */
    public List<PromptResponse> getPrompts() {
        String uid = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getPrompts", uid);
        List<Prompt> prompts = SchemaLimitUtils.firstItems(
                promptRepository.findByUserIdOrSharedTrueOrderByUpdatedAtDesc(uid), RESPONSE_MAX_ITEMS);
        List<UUID> ids = prompts.stream().map(Prompt::getId).toList();
        List<PromptRating> ratings = ids.isEmpty() ? List.of() : promptRatingRepository.findByPromptIdIn(ids);
        Map<UUID, long[]> sums = ratingSummaries(ratings);
        Map<UUID, Integer> mine = myRatings(ratings, uid);
        return prompts.stream()
                .map(p -> toResponse(p, uid, sums, mine))
                .toList();
    }

    /**
     * Создаёт промпт.
     *
     * @param body данные промпта
     * @return созданный промпт
     */
    @Transactional
    public PromptResponse createPrompt(PromptCreate body) {
        if (body.title() == null || body.title().isBlank() || body.text() == null || body.text().isBlank()) {
            throw new IllegalArgumentException("У промпта обязательны название и текст");
        }
        checkLengths(body.title(), body.description(), body.text(), body.model());
        log.info("[{}] createPrompt, title='{}'", CurrentUserHolder.getCurrentUser(), body.title());
        Prompt prompt = new Prompt();
        prompt.setUserId(CurrentUserHolder.getCurrentUser());
        prompt.setTitle(body.title().strip());
        prompt.setDescription(body.description());
        prompt.setText(body.text());
        prompt.setModel(normalizeModel(body.model()));
        prompt.setShared(body.shared() == null || body.shared());
        prompt = promptRepository.save(prompt);
        return toResponse(prompt, CurrentUserHolder.getCurrentUser(), Map.of(), Map.of());
    }

    /**
     * Обновляет промпт (только владелец); null-поля не меняются, пустое
     * название отклоняется.
     *
     * @param id   идентификатор промпта
     * @param body изменяемые поля
     * @return обновлённый промпт
     */
    @Transactional
    public PromptResponse updatePrompt(UUID id, PromptUpdate body) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] updatePrompt, id={}", CurrentUserHolder.getCurrentUser(), id);
        if (body.title() != null && body.title().isBlank()) {
            throw new IllegalArgumentException("Название промпта не может быть пустым");
        }
        checkLengths(body.title(), body.description(), body.text(), body.model());
        Prompt prompt = findPrompt(id);
        UserUtils.checkUserId(userId, prompt.getUserId());
        if (body.title() != null) {
            prompt.setTitle(body.title().strip());
        }
        if (body.description() != null) {
            prompt.setDescription(body.description());
        }
        if (body.text() != null) {
            prompt.setText(body.text());
        }
        if (body.model() != null) {
            prompt.setModel(normalizeModel(body.model()));
        }
        if (body.shared() != null) {
            prompt.setShared(body.shared());
        }
        prompt = promptRepository.save(prompt);
        return toResponse(prompt, CurrentUserHolder.getCurrentUser(), Map.of(), Map.of());
    }

    /**
     * Удаляет промпт (только владелец).
     *
     * @param id идентификатор промпта
     */
    @Transactional
    public void deletePrompt(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] deletePrompt, id={}", CurrentUserHolder.getCurrentUser(), id);
        Prompt prompt = findPrompt(id);
        UserUtils.checkUserId(userId, prompt.getUserId());
        promptRepository.delete(prompt);
    }

    /**
     * Ставит или обновляет оценку промпта (1..5).
     *
     * @param id     идентификатор промпта
     * @param rating оценка от 1 до 5
     */
    @Transactional
    public void ratePrompt(UUID id, int rating) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] ratePrompt, id={}, rating={}", CurrentUserHolder.getCurrentUser(), id, rating);
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Оценка должна быть от 1 до 5");
        }
        checkVisible(userId, findPrompt(id));
        PromptRating vote = new PromptRating();
        vote.setPromptId(id);
        vote.setUserId(CurrentUserHolder.getCurrentUser());
        vote.setRating(rating);
        promptRatingRepository.save(vote);
    }

    /**
     * Отмечает использование промпта (кнопка «использовать» в UI):
     * атомарный инкремент счётчика одним UPDATE (параллельные нажатия не
     * теряют инкременты; updated_at при этом не меняется) и возврат текста для вставки.
     *
     * @param id идентификатор промпта
     * @return текст промпта
     */
    @Transactional
    public String usePrompt(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] usePrompt, id={}", CurrentUserHolder.getCurrentUser(), id);
        Prompt prompt = findPrompt(id);
        checkVisible(userId, prompt);
        promptRepository.incrementUsageCount(id);
        return prompt.getText();
    }

    /** Пустая строка и пробелы считаются «модель не указана». */
    private String normalizeModel(String model) {
        if (model == null || model.isBlank()) {
            return null;
        }
        return model.strip();
    }

    /**
     * Проверяет длины полей по maxLength спецификации (null — поле не передано):
     * title длиннее 255 иначе падал бы в БД ошибкой 500, а text без предела
     * раздавал бы мегабайты всем в списке промптов.
     *
     * @param title       название
     * @param description описание
     * @param text        текст промпта
     * @param model       модель
     * @throws ValidationException поле длиннее лимита (422)
     */
    private static void checkLengths(String title, String description, String text, String model) {
        checkLength("Название промпта", title, TITLE_MAX_LENGTH);
        checkLength("Описание промпта", description, DESCRIPTION_MAX_LENGTH);
        checkLength("Текст промпта", text, TEXT_MAX_LENGTH);
        checkLength("Модель промпта", model, MODEL_MAX_LENGTH);
    }

    private static void checkLength(String field, String value, int maxLength) {
        if (value != null && value.length() > maxLength) {
            throw new ValidationException(field + " длиннее " + maxLength + " символов: " + value.length());
        }
    }

    private Prompt findPrompt(UUID id) {
        return promptRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Промпт не найден: " + id));
    }

    /** Личный промпт доступен только владельцу; общий — всем. */
    private void checkVisible(String userId, Prompt prompt) {
        log.info("[{}] checkVisible, promptId={}, shared={}",
                userId, prompt.getId(), prompt.getShared());
        if (!Boolean.TRUE.equals(prompt.getShared())) {
            UserUtils.checkUserId(userId, prompt.getUserId());
        }
    }

    /** Сводка оценок: id промпта — массив [сумма, количество]. */
    private Map<UUID, long[]> ratingSummaries(List<PromptRating> ratings) {
        Map<UUID, long[]> summary = new HashMap<>();
        for (PromptRating rating : ratings) {
            long[] acc = summary.computeIfAbsent(rating.getPromptId(), k -> new long[2]);
            acc[0] += rating.getRating();
            acc[1]++;
        }
        return summary;
    }

    /** Оценки текущего пользователя. */
    private Map<UUID, Integer> myRatings(List<PromptRating> ratings, String uid) {
        Map<UUID, Integer> mine = new HashMap<>();
        for (PromptRating rating : ratings) {
            if (uid.equals(rating.getUserId())) {
                mine.put(rating.getPromptId(), rating.getRating());
            }
        }
        return mine;
    }

    private PromptResponse toResponse(Prompt p, String uid,
                                      Map<UUID, long[]> sums, Map<UUID, Integer> mine) {
        long[] acc = sums.get(p.getId());
        Double avg = acc == null ? null : Math.round(acc[0] * 10.0 / acc[1]) / 10.0;
        // до flush новой записи @UpdateTimestamp ещё не заполнен — берётся текущее время;
        // дата в UTC с микросекундами укладывается в maxLength 32 схемы при любом поясе JVM
        OffsetDateTime updatedAt = p.getUpdatedAt();
        return new PromptResponse(
                p.getId(), p.getTitle(), p.getDescription(), p.getText(),
                p.getModel(),
                Boolean.TRUE.equals(p.getShared()),
                uid.equals(p.getUserId()),
                p.getUsageCount(),
                avg, acc == null ? 0L : acc[1],
                mine.get(p.getId()),
                SchemaLimitUtils.utcMicros(updatedAt != null ? updatedAt : OffsetDateTime.now()));
    }
}
