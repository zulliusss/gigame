package ru.sber.cs.ai.gigame.service.annotate;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Склады исходных файлов и артефактов прогонов в памяти (файлы на диск и в БД не пишутся, 30.09.2026):
 * сохранение и чтение, срок жизни, предел объёма, снимок прогона.
 */
class FileStoresTest {

    private static byte[] bytes(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }

    @Test
    void rawStoreSavesLoadsClearsAndEvictsStaleKeys() {
        RawFileStore store = new RawFileStore(1);
        UUID key = UUID.randomUUID();
        assertTrue(store.save(key, "Договор.pdf", "текст", bytes("pdf")));
        assertTrue(store.save(key, "пусто.pdf", "т", new byte[0]));

        assertArrayEquals(bytes("pdf"), store.load(key, null, "Договор.pdf", "текст").orElseThrow());
        assertTrue(store.load(key, null, "Договор.pdf", "другой текст").isEmpty());
        assertTrue(store.load(UUID.randomUUID(), null, "Договор.pdf", "текст").isEmpty());
        assertEquals(3, store.usedBytes());

        // срок жизни ещё не вышел — файл на месте; через два часа — вычищен
        store.evictStale(Instant.now().plus(Duration.ofMinutes(30)));
        assertTrue(store.load(key, null, "Договор.pdf", "текст").isPresent());
        store.evictStale(Instant.now().plus(Duration.ofHours(2)));
        assertTrue(store.load(key, null, "Договор.pdf", "текст").isEmpty());

        assertTrue(store.save(key, "Договор.pdf", "текст", bytes("pdf")));
        store.clear(key);
        assertTrue(store.load(key, null, "Договор.pdf", "текст").isEmpty());
        assertEquals(0, store.usedBytes());
    }

    @Test
    void rawStoreKeepsSameNameDocumentsWithDifferentText() {
        // cache-10: два «Договор.docx» разных лотов хранятся рядом, одинаковые имя и текст — перезаписываются
        RawFileStore store = new RawFileStore(24);
        UUID key = UUID.randomUUID();
        assertTrue(store.save(key, "Договор.docx", "лот 1", bytes("один")));
        assertTrue(store.save(key, "Договор.docx", "лот 2", bytes("два")));
        assertTrue(store.save(key, "Договор.docx", "лот 1", bytes("один-новый")));

        assertArrayEquals(bytes("один-новый"), store.load(key, null, "Договор.docx", "лот 1").orElseThrow());
        assertArrayEquals(bytes("два"), store.load(key, null, "Договор.docx", "лот 2").orElseThrow());
    }

    @Test
    void rawStoreEvictsOldestKeysOverVolumeLimitAndRejectsTooLargeFile() {
        // предел 1 МБ: файл больше предела не сохраняется; при заполнении вытесняется самый старый ключ
        RawFileStore store = new RawFileStore(24, 1);
        UUID old = UUID.randomUUID();
        UUID fresh = UUID.randomUUID();
        assertFalse(store.save(old, "огромный.pdf", "т", new byte[1024 * 1024 + 1]));
        assertTrue(store.save(old, "старый.pdf", "т", new byte[600 * 1024]));
        assertTrue(store.save(fresh, "новый.pdf", "т", new byte[600 * 1024]));

        assertTrue(store.load(old, null, "старый.pdf", "т").isEmpty());
        assertTrue(store.load(fresh, null, "новый.pdf", "т").isPresent());
        assertEquals(600 * 1024, store.usedBytes());
    }

    @Test
    void runSnapshotSurvivesClearAndNewUploadOfKey() {
        // оригиналы прогона закреплены на момент запуска: новая загрузка (clear + save) их не лишает;
        // повторный снимок не меняется, при пустом ключе источник — снимок предыдущего прогона
        RawFileStore store = new RawFileStore(1);
        UUID key = UUID.randomUUID();
        UUID run = UUID.randomUUID();
        UUID next = UUID.randomUUID();
        assertTrue(store.save(key, "Акт.pdf", "акт", bytes("v1")));
        store.snapshotForRun(key, run, null);
        store.clear(key);
        assertTrue(store.save(key, "Акт.pdf", "акт", bytes("v2")));
        store.snapshotForRun(key, run, null);

        assertArrayEquals(bytes("v1"), store.load(key, run, "Акт.pdf", "акт").orElseThrow());
        assertArrayEquals(bytes("v2"), store.load(key, null, "Акт.pdf", "акт").orElseThrow());
        // общий файл ключа и снимка считается один раз
        store.clear(key);
        store.snapshotForRun(key, next, run);
        assertArrayEquals(bytes("v1"), store.load(key, next, "Акт.pdf", "акт").orElseThrow());
        assertEquals(2, store.usedBytes());
        store.evictStale(Instant.now().plus(Duration.ofHours(2)));
        assertTrue(store.load(key, run, "Акт.pdf", "акт").isEmpty());
    }

    @Test
    void artifactStoreSavesLoadsAndEvictsOldArtifacts() {
        RunArtifactStore store = new RunArtifactStore(1);
        UUID run = UUID.randomUUID();
        store.save(run, "b9", bytes("zip"));
        store.save(run, "../b9", bytes("zip2"));

        assertArrayEquals(bytes("zip"), store.load(run, "b9").orElseThrow());
        assertArrayEquals(bytes("zip2"), store.load(run, "../b9").orElseThrow());
        assertTrue(store.load(run, "b1").isEmpty());
        assertTrue(store.load(UUID.randomUUID(), "b9").isEmpty());
        assertEquals(7, store.usedBytes());

        store.evictStale(Instant.now().plus(Duration.ofHours(2)));
        assertTrue(store.load(run, "b9").isEmpty());
        assertEquals(0, store.usedBytes());
    }
}
