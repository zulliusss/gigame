package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.model.Generation;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Клиент GigaChat с дублирующим запросом: зависший вызов модели дублируется, ответ берётся от дубля без ожидания
 * страховочного потолка и без повторов.
 */
@ExtendWith(MockitoExtension.class)
class GigaChatClientHedgeTest {

    @Mock
    private ChatModel chatModel;

    @Mock
    private EmbeddingModel embeddingModel;

    private GigaChatClient gigaChatClient;

    @BeforeEach
    void setUp() {
        gigaChatClient = new GigaChatClient(chatModel, embeddingModel);
        ReflectionTestUtils.setField(gigaChatClient, "callHardTimeoutSeconds", 20L);
        ReflectionTestUtils.setField(gigaChatClient, "retryMaxAttempts", 2);
        ReflectionTestUtils.setField(gigaChatClient, "retryDelayMillis", 1);
    }

    private static ChatResponse response(String text) {
        return new ChatResponse(List.of(new Generation(new AssistantMessage(text))));
    }

    @Test
    void hungCallIsAnsweredByHedge() {
        gigaChatClient.setHedge(new GigaChatHedge(200, 2));
        // первая попытка зависает (отменяется после ответа дубля), вторая отвечает сразу
        when(chatModel.call(any(Prompt.class)))
                .thenAnswer(inv -> {
                    boolean released = new CountDownLatch(1).await(60, TimeUnit.SECONDS);
                    return response(released ? "недостижимо" : "потолок");
                })
                .thenReturn(response("ответ дубля"));
        long start = System.currentTimeMillis();

        String result = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "Привет")));

        assertEquals("ответ дубля", result);
        assertTrue(System.currentTimeMillis() - start < 10_000, "дубль не сработал — ждали страховочный потолок");
        verify(chatModel, times(2)).call(any(Prompt.class));
    }

    @Test
    void nullHedgeKeepsPreviousBehaviour() {
        gigaChatClient.setHedge(null);
        when(chatModel.call(any(Prompt.class))).thenReturn(response("ответ"));

        String result = gigaChatClient.chatCompletion(List.of(Map.of("role", "user", "content", "Привет")));

        assertEquals("ответ", result);
        verify(chatModel, times(1)).call(any(Prompt.class));
    }
}
