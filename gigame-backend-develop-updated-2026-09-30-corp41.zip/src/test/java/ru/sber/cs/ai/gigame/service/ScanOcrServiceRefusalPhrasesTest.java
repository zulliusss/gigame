package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Отказ модели OCR в формулировке «нет текста для обработки… предоставь текст или файл» (К2-СТОЛЫ, пустая форма
 * таблицы на стр. 28) распознаётся как отказ, а не попадает в текст документа; обычный текст документа отказом не
 * считается.
 */
class ScanOcrServiceRefusalPhrasesTest {

    @Test
    void emptyContextRefusalIsRecognized() {
        assertTrue(ScanOcrService.isRefusal("Извини, но в данном контексте нет текста для обработки. Пожалуйста, предоставь "
                + "текст или файл с содержимым, которое нужно извлечь."));
        assertTrue(ScanOcrService.isRefusal("Извини, но в предоставленном контексте нет текста для обработки."));
        assertTrue(ScanOcrService.isRefusal("Предоставь, пожалуйста, текст документа."));
        assertTrue(ScanOcrService.isRefusal("Пожалуйста, предоставьте файл."));
    }

    @Test
    void documentTextIsNotRefusal() {
        assertFalse(ScanOcrService.isRefusal("Поставщик обязан предоставить текст технической документации на русском языке."));
        assertFalse(ScanOcrService.isRefusal("Заказчик предоставляет файл в формате PDF | 1 | 15.01.2025 | 1 500 000,00"));
        assertFalse(ScanOcrService.isRefusal("Прошу предоставить текст договора № 5147758 от 07.03.2025 для согласования."));
    }
}
