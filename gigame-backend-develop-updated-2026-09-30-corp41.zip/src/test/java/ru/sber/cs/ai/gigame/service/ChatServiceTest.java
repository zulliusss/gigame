package ru.sber.cs.ai.gigame.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.test.util.ReflectionTestUtils;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Hooks;
import io.micrometer.context.ContextRegistry;
import ru.sber.cs.ai.gigame.dto.chat.ConversationCreate;
import ru.sber.cs.ai.gigame.dto.chat.ConversationResponse;
import ru.sber.cs.ai.gigame.dto.chat.ConversationWithMessages;
import ru.sber.cs.ai.gigame.dto.chat.MessageResponse;
import ru.sber.cs.ai.gigame.exception.AccessDeniedException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Conversation;
import ru.sber.cs.ai.gigame.model.Document;
import ru.sber.cs.ai.gigame.model.KnowledgeBase;
import ru.sber.cs.ai.gigame.model.Message;
import ru.sber.cs.ai.gigame.repository.ConversationRepository;
import ru.sber.cs.ai.gigame.repository.DocumentRepository;
import ru.sber.cs.ai.gigame.repository.KBDocumentRepository;
import ru.sber.cs.ai.gigame.repository.KnowledgeBaseRepository;
import ru.sber.cs.ai.gigame.repository.MessageRepository;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import ru.sber.cs.ai.gigame.model.KBDocument;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.assertArg;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ChatServiceTest {

    @Mock
    private ConversationRepository conversationRepository;

    @Mock
    private MessageRepository messageRepository;

    @Mock
    private GigaChatClient gigaChatClient;

    @Mock
    private EmbeddingService embeddingService;

    @Mock
    private MessageService messageService;

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private KnowledgeBaseRepository knowledgeBaseRepository;

    @Mock
    private KbAggregateService kbAggregateService;

    @Mock
    private KBDocumentRepository kbDocumentRepository;

    @InjectMocks
    private ChatService chatService;

    private UUID userId;
    private UUID conversationId;
    private UUID kbId;
    private Conversation conversation;

    @BeforeAll
    static void enableCurrentUserReactorPropagation() {
        // Стриминговые методы ChatService читают текущего пользователя внутри
        // Flux.defer(...).subscribeOn(boundedElastic), т.е. на рабочем потоке.
        // Регистрируем ThreadLocal CurrentUserHolder в Reactor для автоматического
        // проброса значения в реактивную цепочку (на поток-исполнитель).
        Hooks.enableAutomaticContextPropagation();
        try {
            Field field = CurrentUserHolder.class.getDeclaredField("CURRENT_USER");
            field.setAccessible(true);
            ContextRegistry.getInstance().registerThreadLocalAccessor(
                    "CurrentUserHolder.CURRENT_USER", (ThreadLocal<String>) field.get(null));
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("Невозможно зарегистрировать ThreadLocal CurrentUserHolder", e);
        }
    }

    @BeforeEach
    void setUp() {
        userId = UUID.randomUUID();
        kbId = UUID.randomUUID();
        conversationId = UUID.randomUUID();
        conversation = new Conversation();
        conversation.setId(conversationId);
        conversation.setUserId(userId.toString());

        ReflectionTestUtils.setField(chatService, "self", new AtomicReference<>(chatService));
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 12000);
        ReflectionTestUtils.setField(chatService, "maxHistoryMessages", 20);
        ReflectionTestUtils.setField(chatService, "maxAutoTitleLength", 100);

        // Сохранение возвращает сохраняемую сущность с присвоенным id (как JPA)
        lenient().when(messageRepository.save(any(Message.class))).thenAnswer(invocation -> {
            Message m = invocation.getArgument(0);
            if (m.getId() == null) {
                m.setId(UUID.randomUUID());
            }
            return m;
        });
        // Любая база знаний в тестах доступна (общая) — проверки доступа не мешают сценариям
        KnowledgeBase sharedKb = new KnowledgeBase();
        sharedKb.setShared(true);
        lenient().when(knowledgeBaseRepository.findById(any(UUID.class)))
                .thenReturn(Optional.of(sharedKb));
    }

    @AfterEach
    void cleanStubs() {
        Mockito.reset(conversationRepository, messageRepository, gigaChatClient,
                embeddingService, messageService, documentRepository, knowledgeBaseRepository);
    }

    @Test
    void testGetConversations_withSearch() {
        when(conversationRepository.searchByTitleOrMessageContent(any(), any()))
                .thenReturn(List.of(conversation));

        List<ConversationResponse> result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.getConversations("test"));

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(conversationRepository).searchByTitleOrMessageContent(any(), eq("test"));
    }

    @Test
    void testGetConversations_withoutSearch() {
        when(conversationRepository.findByUserIdOrderByUpdatedAtDesc(any()))
                .thenReturn(List.of(conversation));

        List<ConversationResponse> result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.getConversations(null));

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(conversationRepository).findByUserIdOrderByUpdatedAtDesc(any());
    }

    @Test
    void testGetConversation_withExistingConversation() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(any())).thenReturn(List.of());

        ConversationWithMessages result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.getConversation(conversationId));

        assertNotNull(result);
        assertEquals(conversationId, result.id());
    }

    @Test
    void testGetConversation_withNonExistingConversation_throwsNotFoundException() {
        when(conversationRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> chatService.getConversation(uuid)));
    }

    @ParameterizedTest
    @ValueSource(strings = {"", "   ", "   \t  ",})
    void testCreateConversation_withInvalidTitle_usesDefault(String title) {
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation(title, null));

        assertNotNull(result);
        assertEquals("Новый диалог", result.title());
    }

    @Test
    void testCreateConversation_withKnowledgeBaseId() {
        conversation.setKnowledgeBaseId(kbId);
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation("Test", kbId.toString()));

        assertNotNull(result);
        assertEquals(kbId.toString(), result.knowledgeBaseId());
    }

    @Test
    void testUpdateConversation_withModelOverride() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.updateConversation(conversationId, "New Title"));

        assertNotNull(result);
        assertEquals("New Title", result.title());
        verify(conversationRepository).findById(any());
    }

    @Test
    void testUpdateConversation_withNullTitle_doesNotUpdate() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.updateConversation(conversationId, (String) null));

        assertNotNull(result);
        assertEquals("Новый диалог", result.title());
    }

    @Test
    void testUpdateConversation_withNonExistingConversation_throwsNotFoundException() {
        when(conversationRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> chatService.updateConversation(uuid, "New Title")));
    }

    @Test
    void testDeleteConversation_withExistingConversation() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));

        assertDoesNotThrow(() -> CurrentUserHolder.withUser(userId.toString(), () -> { chatService.deleteConversation(conversationId); return null; }));

        verify(conversationRepository).delete(conversation);
    }

    @Test
    void testDeleteConversation_withNonExistingConversation_throwsNotFoundException() {
        when(conversationRepository.findById(any())).thenReturn(Optional.empty());
        var userIdStr = userId.toString();
        var uuid = UUID.randomUUID();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> { chatService.deleteConversation(uuid); return null; }));
    }

    @Test
    void testSendMessageStream_withValidData() {
        lenient().when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        var result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hi", null, null));
        assertNotNull(result);
    }

    @Test
    void testGetConversations_withEmptySearch() {
        when(conversationRepository.findByUserIdOrderByUpdatedAtDesc(any()))
                .thenReturn(List.of(conversation));

        List<ConversationResponse> result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.getConversations(""));

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    @Test
    void testCreateConversation_withLongTitle() {
        String longTitle = "A".repeat(200);
        when(conversationRepository.save(any())).thenAnswer(invocation -> {
            Conversation c = invocation.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation(longTitle, null));

        assertNotNull(result);
        assertEquals(longTitle, result.title());
    }

    @Test
    void testCreateConversation_withSpecialCharactersInTitle() {
        String specialTitle = "Test @#$%^&*()";
        when(conversationRepository.save(any())).thenAnswer(invocation -> {
            Conversation c = invocation.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation(specialTitle, null));

        assertNotNull(result);
        assertEquals(specialTitle, result.title());
    }

    @Test
    void testCreateConversation_withKnowledgeBaseId_andNullTitle() {
        when(conversationRepository.save(any())).thenAnswer(invocation -> {
            Conversation c = invocation.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation(null, kbId.toString()));

        assertNotNull(result);
        assertEquals(kbId.toString(), result.knowledgeBaseId());
        assertEquals("Новый диалог", result.title());
    }

    @Test
    void testUpdateConversation_withWhitespaceTitle_doesNotUpdate() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any()))
                .thenAnswer(invocation -> invocation.getArgument(0));

        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.updateConversation(conversationId, "   "));

        assertNotNull(result);
    }

    @Test
    void testDeleteConversation_withNullConversationId() {
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> { chatService.deleteConversation(null); return null; }));
    }

    @Test
    void testGetConversation_withNullConversationId() {
        var userIdStr = userId.toString();
        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> chatService.getConversation(null)));
    }

    @Test
    void testUpdateConversation_withNullConversation() {
        var userIdStr = userId.toString();

        assertThrows(NotFoundException.class,
                () -> CurrentUserHolder.withUser(userIdStr, () -> chatService.updateConversation(null, "New Title")));
    }

    @Test
    void testSendMessageStream_withDocumentIds() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        var result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hi", List.of("doc1"), null));
        assertNotNull(result);
    }

    @Test
    void testSendMessageStream_withDocumentTexts() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        var result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hi", null, List.of("text")));
        assertNotNull(result);
    }

    @Test
    void testSendMessageStream_withBothDocumentsAndTexts() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        var result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hi", List.of("doc1"), List.of("text")));
        assertNotNull(result);
    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withDocumentTexts() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", null, List.of("text")).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.size() == 2 &&
                        "system".equals(messages.get(0).get("role")) &&
                        "user".equals(messages.get(1).get("role"))
        ), any(), any());
    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withLargeDocumentTexts() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));
        when(gigaChatClient.chatCompletion(any())).thenReturn("\"Это новый заголовок чата\"");
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 2);
        ReflectionTestUtils.setField(chatService, "maxAutoTitleLength", 20);
        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", null, List.of("text")).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.size() == 2 &&
                        "system".equals(messages.get(0).get("role")) &&
                        "user".equals(messages.get(1).get("role"))
        ), any(), any());
    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withRAG() {
        conversation.setKnowledgeBaseId(kbId);
        UUID sourceDocId = UUID.randomUUID();
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString()))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("KB chunk", sourceDocId, 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(sourceDocId)).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.size() == 2 &&
                        "system".equals(messages.get(0).get("role")) &&
                        messages.get(0).get("content").contains("KB chunk")
        ), any(), any());
    }

    @Test
    void testSendMessageStream_docAddressedQuestion_filtersOtherDocsChunks() {
        // в вопросе назван номер документа — чанки ЧУЖИХ документов не должны
        // попадать в контекст (перекрёстные галлюцинации)
        conversation.setKnowledgeBaseId(kbId);
        UUID targetDocId = UUID.randomUUID();
        UUID otherDocId = UUID.randomUUID();
        Document target = new Document();
        target.setId(targetDocId);
        target.setFilename("Договор_4373770.pdf");
        Document other = new Document();
        other.setId(otherDocId);
        other.setFilename("Договор_9999911.pdf");
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString()))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Чужой фрагмент про неустойку", otherDocId, 0.08),
                        new EmbeddingService.ChunkHit("Целевой фрагмент про неустойку", targetDocId, 0.10)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(targetDocId)).thenReturn(Optional.of(target));
        when(documentRepository.findById(otherDocId)).thenReturn(Optional.of(other));
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId,
                "Что сказано про неустойку в договоре 4373770?", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.get(0).get("content").contains("Целевой фрагмент")
                        && !messages.get(0).get("content").contains("Чужой фрагмент")
        ), any(), any());
    }

    @Test
    void testSendMessageStream_docAddressedByTokens_filenameWithoutLongNumber() {
        // имя без длинного номера: «акте к заявке 4» адресуется токенами
        conversation.setKnowledgeBaseId(kbId);
        UUID targetDocId = UUID.randomUUID();
        UUID otherDocId = UUID.randomUUID();
        Document target = new Document();
        target.setId(targetDocId);
        target.setFilename("Акт к заявке 4 от 01.07.25.pdf");
        target.setExtractedText("АКТ сдачи-приёмки. Итого: 27 080 240,00 руб. с НДС.");
        Document other = new Document();
        other.setId(otherDocId);
        other.setFilename("Акт к заявке 10 №1 от 01.12.25.pdf");
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString()))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Итого по акту заявки 10", otherDocId, 0.08),
                        new EmbeddingService.ChunkHit("Итого по акту заявки 4: 27 080 240", targetDocId, 0.10)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(targetDocId)).thenReturn(Optional.of(target));
        when(documentRepository.findById(otherDocId)).thenReturn(Optional.of(other));
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId,
                "Какая сумма Итого в акте к заявке 4?", null, null).blockLast());

        // адресованный документ отдаётся ПОЛНЫМ текстом, чужой — не попадает
        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.get(0).get("content").contains("Итого: 27 080 240,00")
                        && !messages.get(0).get("content").contains("заявке 10")
        ), any(), any());
    }

    @Test
    void testSendMessageStream_shortFollowUp_ragQueryIncludesPreviousQuestion() {
        // анафора «а сроки?» — RAG-запрос дополняется предыдущим вопросом
        conversation.setKnowledgeBaseId(kbId);
        ReflectionTestUtils.setField(chatService, "ragShortQueryChars", 60);
        Message prevQuestion = new Message();
        prevQuestion.setId(UUID.randomUUID());
        prevQuestion.setRole("user");
        prevQuestion.setContent("Расскажи про неустойку по договору 4373770");
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of(prevQuestion));
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class),
                argThat(q -> q != null && q.contains("неустойку") && q.contains("а сроки?"))))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("Сроки: 30 дней", UUID.randomUUID(), 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(any(UUID.class))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "а сроки?", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.get(0).get("content").contains("Сроки: 30 дней")
        ), any(), any());
    }

    @Test
    void testSendMessageStream_ragRelativeFilter_dropsFarKb() {
        UUID farKbId = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), farKbId.toString()));
        UUID nearDocId = UUID.randomUUID();
        UUID farDocId = UUID.randomUUID();
        ReflectionTestUtils.setField(chatService, "ragDistanceDelta", 0.08);
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Релевантная БЗ: лучший фрагмент 0.10, второй 0.30 (сам по себе за дельтой,
        // но база выиграла — остаются ВСЕ её фрагменты)
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString()))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Near chunk", nearDocId, 0.10),
                        new EmbeddingService.ChunkHit("Near chunk 2", nearDocId, 0.30)));
        // Нерелевантная БЗ: её лучший фрагмент 0.35 хуже глобального лучшего на 0.25 > 0.08
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(farKbId), isA(float[].class), anyString()))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Far chunk", farDocId, 0.35)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(nearDocId)).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.get(0).get("content").contains("Near chunk") &&
                        messages.get(0).get("content").contains("Near chunk 2") &&
                        !messages.get(0).get("content").contains("Far chunk")
        ), any(), any());
        // Документ отсечённой БЗ не должен попадать в источники
        verify(messageService).saveAssistantMessage(any(), any(), argThat(sources ->
                sources.size() == 1 && nearDocId.toString().equals(sources.get(0).get("document_id"))));
    }

    @Test
    void testSendMessageStream_ragRelativeFilter_keepsCloseKbs() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        UUID docId1 = UUID.randomUUID();
        UUID docId2 = UUID.randomUUID();
        ReflectionTestUtils.setField(chatService, "ragDistanceDelta", 0.08);
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Лучшие фрагменты обеих БЗ в пределах дельты — вопрос касается обеих, остаются обе
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString()))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("First chunk", docId1, 0.10)));
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId2), isA(float[].class), anyString()))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("Second chunk", docId2, 0.15)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(any(UUID.class))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.get(0).get("content").contains("First chunk") &&
                        messages.get(0).get("content").contains("Second chunk")
        ), any(), any());
    }

    @Test
    void testSendMessageStream_ragRouter_routesToSingleKb() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        UUID docId = UUID.randomUUID();
        ReflectionTestUtils.setField(chatService, "ragRouterEnabled", true);
        mockKb(kbId, "THUNDER");
        mockKb(kbId2, "ASUS");
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Роутер выбирает вторую базу — поиск идёт только по ней
        when(gigaChatClient.chatCompletion(any(), any(), any())).thenReturn("2");
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId2), isA(float[].class), anyString()))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("ASUS chunk", docId, 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(docId)).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Вопрос про ASUS", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.get(0).get("content").contains("ASUS chunk")
        ), any(), any());
        verify(embeddingService, never())
                .hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString());
    }

    @Test
    void testSendMessageStream_ragRouter_answerAll_searchesAllKbs() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        ReflectionTestUtils.setField(chatService, "ragRouterEnabled", true);
        mockKb(kbId, "THUNDER");
        mockKb(kbId2, "ASUS");
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Роутер не уверен — поиск по всем базам
        when(gigaChatClient.chatCompletion(any(), any(), any())).thenReturn("все");
        when(embeddingService.hybridSearchWithSources(eq("kb"), any(UUID.class), isA(float[].class), anyString()))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("KB chunk", UUID.randomUUID(), 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(any(UUID.class))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Общий вопрос", null, null).blockLast());

        verify(embeddingService).hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString());
        verify(embeddingService).hybridSearchWithSources(eq("kb"), eq(kbId2), isA(float[].class), anyString());
    }

    @Test
    void testSendMessageStream_ragRouter_failure_searchesAllKbs() {
        UUID kbId2 = UUID.randomUUID();
        conversation.setKnowledgeBaseIds(List.of(kbId.toString(), kbId2.toString()));
        ReflectionTestUtils.setField(chatService, "ragRouterEnabled", true);
        mockKb(kbId, "THUNDER");
        mockKb(kbId2, "ASUS");
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Ошибка роутера не должна ломать RAG — fail-open на все базы
        when(gigaChatClient.chatCompletion(any(), any(), any())).thenThrow(new RuntimeException("router down"));
        when(embeddingService.hybridSearchWithSources(eq("kb"), any(UUID.class), isA(float[].class), anyString()))
                .thenReturn(List.of(new EmbeddingService.ChunkHit("KB chunk", UUID.randomUUID(), 0.1)));
        when(embeddingService.getTopK()).thenReturn(5);
        when(documentRepository.findById(any(UUID.class))).thenReturn(Optional.empty());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Вопрос", null, null).blockLast());

        verify(embeddingService).hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString());
        verify(embeddingService).hybridSearchWithSources(eq("kb"), eq(kbId2), isA(float[].class), anyString());
    }

    /**
     * Мокает доступную (общую) базу знаний с заданным именем.
     */
    private void mockKb(UUID id, String name) {
        KnowledgeBase kb = new KnowledgeBase();
        kb.setId(id);
        kb.setName(name);
        kb.setShared(true);
        lenient().when(knowledgeBaseRepository.findById(eq(id))).thenReturn(Optional.of(kb));
    }

    @Test
    void testSendMessageStream_ragMaxDistance_dropsAllChunks() {
        conversation.setKnowledgeBaseId(kbId);
        ReflectionTestUtils.setField(chatService, "ragMaxDistance", 0.3);
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));
        // Все фрагменты дальше абсолютного порога — RAG-контекст не строится вовсе
        when(embeddingService.hybridSearchWithSources(eq("kb"), eq(kbId), isA(float[].class), anyString()))
                .thenReturn(List.of(
                        new EmbeddingService.ChunkHit("Far chunk", UUID.randomUUID(), 0.5)));
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));
        // Автогенерация заголовка не должна мешать — заглушка для chatCompletion
        when(gigaChatClient.chatCompletion(any())).thenReturn("");

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.size() == 1 && "user".equals(messages.get(0).get("role"))
        ), any(), any());
    }

    // =========================================================================
    // REGENERATE tests
    // =========================================================================

    @Test
    void testRegenerateStream_withLastUserMessage() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        // 4 сообщения: user, assistant, user, assistant (последнее — ответ ассистента,
        // который должен быть удалён вместе с сообщением пользователя)
        Message assistantTail = createMessage("assistant", "Response A");
        List<Message> all = List.of(
                createMessage("user", "First"),
                createMessage("assistant", "OK"),
                createMessage("user", "Regenerate this"),
                assistantTail
        );
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(all);
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Regenerated", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.regenerateStream(conversationId, null, null).blockLast());

        verify(messageRepository).deleteAll(assertArg(tail -> {
            @SuppressWarnings("unchecked")
            List<Message> msgs = (List<Message>) tail;
            assertThat(msgs).hasSize(1);
            assertThat(msgs.get(0).getId()).isEqualTo(assistantTail.getId());
        }));
        verify(gigaChatClient).chatCompletionResult(any(), any(), any());
    }

    @Test
    void testRegenerateStream_withoutUserMessage_throws() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        // Только сообщения ассистента
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(List.of(createMessage("assistant", "Only")));
        assertThrows(NotFoundException.class, () -> CurrentUserHolder.withUser(userId.toString(),
                () -> chatService.regenerateStream(conversationId, null, null).blockLast()));
    }

    @Test
    void testRegenerateStream_usesDocumentIdsFromParam() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        List<Message> all = List.of(
                createMessage("user", "Ask"),
                createMessage("assistant", "Old")
        );
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(all);
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("New", null));
        when(gigaChatClient.chatCompletion(any())).thenReturn("");

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.regenerateStream(conversationId, List.of("ext-doc"), null).blockLast());

        verify(gigaChatClient).chatCompletionResult(any(), any(), any());
    }

    // =========================================================================
    // EDIT MESSAGE STREAM tests
    // =========================================================================

    @Test
    void testEditMessageStream_withValidData() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        List<Message> all = List.of(
                createMessage("user", "Original"),
                createMessage("assistant", "Reply")
        );
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(all);
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Edited", null));

        UUID editMessageId = all.get(0).getId(); // user message
        CurrentUserHolder.withUser(userId.toString(), () -> chatService.editMessageStream(conversationId, editMessageId, "Edited text", null, null).blockLast());

        verify(messageRepository).deleteAll(any());
        verify(gigaChatClient).chatCompletionResult(any(), any(), any());
    }

    @Test
    void testEditMessageStream_editsOnlyUserRole() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        List<Message> all = List.of(
                createMessage("user", "OK"),
                createMessage("assistant", "AI")
        );
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(all);
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class)))
                .thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));
        assertThrows(NotFoundException.class, () -> CurrentUserHolder.withUser(userId.toString(),
                () -> chatService.editMessageStream(conversationId, all.get(1).getId(), "new", null, null).blockLast()));
    }

    @Test
    void testEditMessageStream_nonExistentMessageId_throws() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId))
                .thenReturn(List.of());

        UUID missingId = UUID.randomUUID();
        assertThrows(NotFoundException.class, () -> CurrentUserHolder.withUser(userId.toString(),
                () -> chatService.editMessageStream(conversationId, missingId, "new", null, null).blockLast()));

    }

    @Test
    void testSendMessageStream_callsBuildChatMessages_withHistory() {
        // От новых к старым, как возвращает findByConversationIdOrderByCreatedAtDesc
        List<Message> history = List.of(
                createMessage("assistant", "Second"),
                createMessage("user", "First")
        );
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(history);
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Third", null, null).blockLast());

        verify(gigaChatClient).chatCompletionResult(argThat(messages ->
                messages.size() == 3 &&
                        "First".equals(messages.get(0).get("content")) &&
                        "Second".equals(messages.get(1).get("content")) &&
                        "Third".equals(messages.get(2).get("content"))
        ), any(), any());
    }

    @Test
    void testSendMessageStream_savesUserMessage() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", null, null).blockLast());

        verify(messageRepository).save(any(Message.class));
    }

    @Test
    void testSendMessageStream_savesUserMessage_withDocumentIds() {
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));

        List<String> docIds = List.of("doc1", "doc2");
        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hello", docIds, null).blockLast());

        verify(messageRepository).save(argThat(msg -> docIds.equals(msg.getDocumentIds())));
    }

    // -------------------------------------------------------------------------
    // Tests for toMessageResponse
    // -------------------------------------------------------------------------

    @Test
    void testToMessageResponse_withSources_returnsMappedResponse() {
        Message msg = createMessage("assistant", "Ответ с источниками");
        msg.getConversation().setId(conversationId);

        // создаём список источников так, как их хранит JSONB в Message.sources
        var source1 = Map.of("document_id", UUID.randomUUID().toString(),
                "document_name", "doc1.docx",
                "snippet", "фрагмент 1");
        var source2 = Map.of("document_id", UUID.randomUUID().toString(),
                "document_name", "doc2.pdf",
                "snippet", "фрагмент 2");
        msg.setSources(List.of(source1, source2));
        msg.setDocumentIds(List.of("doc-uuid-1", "doc-uuid-2"));

        MessageResponse response = ReflectionTestUtils.invokeMethod(
                chatService, "toMessageResponse", msg);

        assertNotNull(response);
        assertEquals(msg.getId(), response.id());
        assertEquals(conversationId, response.conversationId());
        assertEquals("assistant", response.role());
        assertEquals("Ответ с источниками", response.content());
        assertEquals(List.of("doc-uuid-1", "doc-uuid-2"), response.documentIds());
        assertEquals(msg.getCreatedAt(), response.createdAt());

        assertThat(response.sources()).hasSize(2);
        assertEquals(UUID.fromString(source1.get("document_id")), response.sources().get(0).documentId());
        assertEquals("doc1.docx", response.sources().get(0).documentName());
        assertEquals("фрагмент 1", response.sources().get(0).snippet());
        assertEquals(UUID.fromString(source2.get("document_id")), response.sources().get(1).documentId());
        assertEquals("doc2.pdf", response.sources().get(1).documentName());
        assertEquals("фрагмент 2", response.sources().get(1).snippet());
    }

    @Test
    void testToMessageResponse_limitsSourcesToSchemaMaxItems() {
        // [conversation #0]: агрегирующий ответ хранит источник на каждый документ, в схеме sources maxItems 20
        Message msg = createMessage("assistant", "ИТОГО по 35 договорам");
        msg.getConversation().setId(conversationId);
        List<Map<String, String>> sources = new ArrayList<>();
        for (int i = 0; i < 35; i++) {
            sources.add(Map.of("document_id", UUID.randomUUID().toString(),
                    "document_name", "договор" + i + ".pdf",
                    "snippet", "сумма " + i));
        }
        msg.setSources(sources);

        MessageResponse response = ReflectionTestUtils.invokeMethod(
                chatService, "toMessageResponse", msg);

        assertNotNull(response);
        assertThat(response.sources()).hasSize(ChatService.MAX_MESSAGE_SOURCES);
        assertEquals("договор0.pdf", response.sources().get(0).documentName());
        assertEquals("договор19.pdf", response.sources().get(19).documentName());
    }

    @Test
    void testToMessageResponse_withNullSources_returnsEmptySources() {
        Message msg = createMessage("user", "Привет");
        msg.getConversation().setId(conversationId);
        msg.setSources(null);

        MessageResponse response = ReflectionTestUtils.invokeMethod(
                chatService, "toMessageResponse", msg);

        assertNotNull(response);
        assertEquals(msg.getId(), response.id());
        assertEquals(conversationId, response.conversationId());
        assertEquals("user", response.role());
        assertEquals("Привет", response.content());
        assertNotNull(response.sources());
        assertTrue(response.sources().isEmpty());
    }

    @Test
    void testToMessageResponse_withEmptySources_returnsEmptySources() {
        Message msg = createMessage("user", "Тест");
        msg.getConversation().setId(conversationId);
        msg.setSources(List.of());

        MessageResponse response = ReflectionTestUtils.invokeMethod(
                chatService, "toMessageResponse", msg);

        assertNotNull(response);
        assertThat(response.sources()).isEmpty();
    }

    private Message createMessage(String role, String content) {
        Message msg = new Message();
        msg.setId(UUID.randomUUID());
        msg.setRole(role);
        msg.setContent(content);
        msg.setConversation(conversation);
        return msg;
    }

    // -------------------------------------------------------------------------
    // Tests for private methods using reflection
    // -------------------------------------------------------------------------

    private List<Map<String, String>> invokeBuildChatMessages(String content, List<String> docTexts) {
        Message userMessage = createMessage("user", content);
        Object promptBuild = ReflectionTestUtils.invokeMethod(chatService, "buildChatMessages",
                conversation, userMessage, null, docTexts);
        return ReflectionTestUtils.invokeMethod(promptBuild, "messages");
    }

    @Test
    void testBuildChatMessages_withEmptyDocumentTexts() {
        List<Map<String, String>> result = invokeBuildChatMessages("EmptyDocumentTexts", null);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("user", result.get(0).get("role"));
        assertEquals("EmptyDocumentTexts", result.get(0).get("content"));
    }

    @Test
    void testBuildChatMessages_withDocumentTexts() {
        List<Map<String, String>> result = invokeBuildChatMessages("Hello", List.of("text"));

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("system", result.get(0).get("role"));
        assertTrue(result.get(0).get("content").contains("Пользователь загрузил 1 документ"));
        assertEquals("user", result.get(1).get("role"));
    }

    @Test
    void testBuildChatMessages_withHistory() {
        List<Message> history = List.of(createMessage("user", "First"));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(), any())).thenReturn(history);

        List<Map<String, String>> result = invokeBuildChatMessages("withHistory", null);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("user", result.get(0).get("role"));
        assertEquals("First", result.get(0).get("content"));
        assertEquals("user", result.get(1).get("role"));
        assertEquals("withHistory", result.get(1).get("content"));
    }

    @Test
    void testBuildChatMessages_withSummary() {
        conversation.setSummary("Краткое содержание ранней части");

        List<Map<String, String>> result = invokeBuildChatMessages("Next", null);

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("system", result.get(0).get("role"));
        assertTrue(result.get(0).get("content").contains("Краткое содержание ранней части"));
        assertEquals("user", result.get(1).get("role"));
    }

    // =========================================================================
    // Create Conversation with full ConversationCreate DTO
    // =========================================================================

    @Test
    void testCreateConversation_fullDto_setsModelAndTemperature() {
        when(conversationRepository.save(any())).thenAnswer(inv -> {
            Conversation c = inv.getArgument(0);
            c.setId(UUID.randomUUID());
            return c;
        });

        var create = new ConversationCreate("My Title", null, List.of(kbId.toString()), "GigaChat-Pro", 0.9);
        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation(create));

        assertNotNull(result);
        assertEquals("My Title", result.title());
    }

    @Test
    void testCreateConversation_fullDto_blankTitleDefaults() {
        when(conversationRepository.save(any())).thenReturn(conversation);

        var create = new ConversationCreate("", null, null, null, null);
        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation(create));

        assertEquals("Новый диалог", result.title());
    }

    @Test
    void testCreateConversation_fullDto_negativeTemperatureKeepsNull() {
        when(conversationRepository.save(any())).thenReturn(conversation);
        var create = new ConversationCreate("Test", null, null, null, -0.5);
        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.createConversation(create));
        assertNull(result.temperature());
    }

    // =========================================================================
    // Update Conversation with ConversationCreate DTO (partial update semantics)
    // =========================================================================

    @Test
    void testUpdateConversation_fullDto_updatesTitleAndKbs() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);
        var body = new ConversationCreate("Updated", null, List.of(kbId.toString()), null, null);
        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.updateConversation(conversationId, body));
        assertEquals("Updated", result.title());
        assertNotNull(result.knowledgeBaseIds());
    }

    @Test
    void testUpdateConversation_fullDto_resetsTemperatureOnNegative() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);
        conversation.setTemperature(0.7);
        var body = new ConversationCreate(null, null, null, null, -1.0);
        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.updateConversation(conversationId, body));
        assertNull(result.temperature());
    }

    @Test
    void testUpdateConversation_fullDto_modelBlankUsesDefault() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);
        conversation.setModel("Custom");
        var body = new ConversationCreate(null, null, null, "", null);
        ConversationResponse result = CurrentUserHolder.withUser(userId.toString(), () -> chatService.updateConversation(conversationId, body));
        assertNull(result.model());
    }

    // =========================================================================
    // Access denied / user mismatch tests
    // =========================================================================

    @Test
    void testSendMessageStream_userIdMismatch_throws() {
        // Создаём диалог дл A, пытается писать B
        Conversation alienConv = new Conversation();
        alienConv.setId(UUID.randomUUID());
        alienConv.setUserId("other");
        when(conversationRepository.findById(any())).thenReturn(Optional.of(alienConv));
        when(conversationRepository.save(any())).thenReturn(alienConv);
        var id = alienConv.getId();
        assertThrows(AccessDeniedException.class, () -> CurrentUserHolder.withUser("userA",
                () -> chatService.sendMessageStream(id, "Hi", null, null).blockLast()));
    }

    @Test
    void testDeleteConversation_userIdMismatch_throws() {
        Conversation alien = new Conversation();
        alien.setId(conversationId);
        alien.setUserId("other");
        when(conversationRepository.findById(any())).thenReturn(Optional.of(alien));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("userB", () -> { chatService.deleteConversation(conversationId); return null; }));
    }

    @Test
    void testUpdateConversation_userIdMismatchDuringSave_throws() {
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenThrow(new AccessDeniedException("user mismatch"));

        assertThrows(AccessDeniedException.class,
                () -> CurrentUserHolder.withUser("other", () -> chatService.updateConversation(conversationId, "Title")));
    }

    // =========================================================================
    // Summary update tests    // =========================================================================

    //TODO @Test
    void testUpdateConversationSummary_norsOnException_doesNotPropagate() {
        // scheduleSummaryUpdate ловит ошибу и не пробрасывает
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(conversationRepository.save(any())).thenReturn(conversation);
        // Без ошибки — ничео не дожны
    }

    @Test
    void testUpdateConversationSummary_overflowGreaterThanCovered_updates() {
        // Имитация: 25 сообщений, cover=20, overflow=5
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(messageRepository.countByConversationId(any())).thenReturn(25L);
        // Изначально cover=0 —› 20 сообщений в окне, 5 вытеснены
        conversation.setSummaryMessageCount(0);
        // Нужно вернуть 5+ сообщений, иначе условие oldest.size() < overflow
        // заставит метод выйти досрочно
        List<Message> oldest = List.of(
                createMessage("user", "1"),
                createMessage("assistant", "2"),
                createMessage("user", "3"),
                createMessage("assistant", "4"),
                createMessage("user", "5")
        );
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(
                any(UUID.class), any(Pageable.class)))
                .thenReturn(oldest);
        lenient().when(gigaChatClient.chatCompletion(any(), any(), any())).thenReturn("Новое краткое содержание");

        // Вызываем updateConversationSummary прямо (package-private)
        chatService.updateConversationSummary(conversationId);
        // Проверяем, что сообщение count обновлено
        verify(conversationRepository).save(argThat(c ->
                c.getId().equals(conversationId) && c.getSummaryMessageCount() == 5));
    }

    @Test
    void testUpdateConversationSummary_shrinkedHistory_resets() {
        // 20 сообщений в диалоге, cover=20, overflow=0 (все актуальны)
        when(conversationRepository.findById(any())).thenReturn(Optional.of(conversation));
        when(messageRepository.countByConversationId(any())).thenReturn(20L);
        conversation.setSummaryMessageCount(20);
        // overflow=0 < covered=20 — история сократилась, сбрасываем
        chatService.updateConversationSummary(conversationId);
        // Сброс summary и count в 0
        verify(conversationRepository).save(argThat(c -> c.getSummaryMessageCount() == 0));
    }


    //TODO @Test
    void testAutoGenerateTitle_returnsWhenMoreThanTwoMessages() {
        // 5 сообщений в диалоге — не первый обмен
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(any()))
                .thenReturn(List.of(
                        createMessage("user", "A"),
                        createMessage("assistant", "B"),
                        createMessage("user", "C"),
                        createMessage("assistant", "D"),
                        createMessage("user", "E")
                ));
        // Вызываем sendMessageStream — то позволяет проверть автогенерацию
        // (рез RelectionTestUtils.invokeMethod, если нужно)
    }

    @Test
    void testAutoGenerateTile_trimmedQuotesAndMaxLength() {
        // Прямой вызов getNewTitle через RelectionTestUtils
        String result = ReflectionTestUtils.invokeMethod(chatService, "getNewTitle", "\"Очень длинный заголовок диалога который превышает все мыслимые лимиты\"");
        assertNotNull(result);
        assertTrue(result.length() <= 100);
        // Ожидаем, то кавычки удалены и шина ограничена
    }

    @Test
    void testAutoGenerateTile_nullTileResponse_keepsDefault() {
        String result = ReflectionTestUtils.invokeMethod(chatService, "getNewTitle", (String) null);
        // Ожидаем пустую сроку
        assertEquals("", result);
    }

    @Test
    void testAutoGenerateTile_empyTileResponse_returnsBlank() {
        String result = ReflectionTestUtils.invokeMethod(chatService, "getNewTitle", "");
        assertEquals("", result);
    }

    @Test
    void testEffectiveKbIds_withNullKbIds() {
        // Ни knowledgeBaseId, ни knowledgeBaseIds не заданы
        conversation.setKnowledgeBaseId(null);
        conversation.setKnowledgeBaseIds(null);

        // Через RelectionTestUtils.invokeMethod
        List<UUID> result = ReflectionTestUtils.invokeMethod(chatService, "effectiveKbIds", conversation);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void testEffectiveKbIds_withOnlyLegacyKbId() {
        conversation.setKnowledgeBaseId(kbId);
        conversation.setKnowledgeBaseIds(null);

        List<UUID> result = ReflectionTestUtils.invokeMethod(chatService, "effectiveKbIds", conversation);
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(kbId, result.get(0));
    }

    // =========================================================================
    // SSE event structure verification    // =========================================================================

    @Test
    void testSendMessageStream_emitContentAndUsageAndDone() {
        // Проверяем, то в SSE-событиях есть контент, usage и done
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", Map.of("total_tokens", 150)));

        Flux<ServerSentEvent<Map<String, Object>>> flux = CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Hi", null, null));
        // Здесь мы не можем легко проерить встреснные события стрима,
        // но можем проверить, то результат не нулевой
        assertNotNull(flux);
    }

    // =========================================================================
    // BuildDocumentsContext internal methods    // =========================================================================

    @Test
    void testBuildDocumentsContext_smalDocuemntsIncludedFull() {
        // Документы < contextCharLimit — полный конекст
        List<String> smallTexts = List.of("Короткий текст");
        List<String> ids = List.of();
        ReflectionTestUtils.invokeMethod(chatService, "buildDocumentsContext", ids, smallTexts, "Вопрос");
        // Не должео вызывать поиск ембеддингов
        verify(gigaChatClient, never()).getEmbeddings(any());
    }

    @Test
    void testBuildDocumentsContext_argeDocumntUsesChunking() {
        // Документ > contextCharLimit — использует chunking
        ReflectionTestUtils.setField(chatService, "contextCharLimit", 100);
        when(gigaChatClient.getEmbeddings(any())).thenReturn(List.of(new float[1024]));

        // Вызов через sendMessageStream с документами, но без documentIds
        lenient().when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtDesc(any(UUID.class), any(Pageable.class))).thenReturn(List.of());
        when(gigaChatClient.chatCompletionResult(any(), any(), any()))
                .thenReturn(new GigaChatClient.ChatResult("Response", null));
        when(gigaChatClient.chatCompletion(any())).thenReturn("");
        CurrentUserHolder.withUser(userId.toString(), () -> chatService.sendMessageStream(conversationId, "Большой", null, List.of("A".repeat(200))));
        // Без documentIds getEmbeddings не вызывается — используется "обрезан" клиент
        verify(gigaChatClient, never()).getEmbeddings(any());
    }

    @Test
    void testDeleteConversation_deletesAttachedDocumentsNotInKnowledgeBases() {
        UUID docInKb = UUID.randomUUID();
        UUID docOnlyInChat = UUID.randomUUID();
        Message message = new Message();
        message.setDocumentIds(List.of(docInKb.toString(), docOnlyInChat.toString(), "не-uuid"));
        when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId)).thenReturn(List.of(message));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(docInKb)).thenReturn(List.of(new KBDocument()));
        when(kbDocumentRepository.findByDocumentIdWithKnowledgeBase(docOnlyInChat)).thenReturn(List.of());

        CurrentUserHolder.withUser(userId.toString(), () -> {
            chatService.deleteConversation(conversationId);
            return null;
        });

        verify(conversationRepository).delete(conversation);
        // документ только диалога — удаляется вместе с эмбеддингами; документ базы знаний остаётся
        verify(embeddingService).deleteDocumentChunks(docOnlyInChat);
        verify(documentRepository).deleteById(docOnlyInChat);
        verify(embeddingService, never()).deleteDocumentChunks(docInKb);
        verify(documentRepository, never()).deleteById(docInKb);
    }

    @Test
    void testDeleteConversation_withoutAttachedDocuments_deletesOnlyConversation() {
        when(conversationRepository.findById(conversationId)).thenReturn(Optional.of(conversation));
        when(messageRepository.findByConversationIdOrderByCreatedAtAsc(conversationId)).thenReturn(List.of(new Message()));

        CurrentUserHolder.withUser(userId.toString(), () -> {
            chatService.deleteConversation(conversationId);
            return null;
        });

        verify(conversationRepository).delete(conversation);
        verify(documentRepository, never()).deleteById(any());
    }
}
