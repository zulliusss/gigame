package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorTransformNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Проверка операций узлов «Трансформация» до создания прогона.
 */
class ScenarioOperationsValidatorTest {

    private static NodeDto node(String id, String type, String label, String rules) {
        return NodeDto.builder()
                .id(id)
                .type(type)
                .data(NodeDataDto.builder().label(label).rules(rules).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static GraphDataDto graph(NodeDto... nodes) {
        return new GraphDataDto(List.of(nodes), List.of());
    }

    private static String rules(String... operations) {
        return "{\"операции\": [" + Arrays.stream(operations)
                .map(op -> "{\"оп\": \"" + op + "\"}")
                .collect(Collectors.joining(", ")) + "]}";
    }

    private static NodeDto subScenario(String id, String value) {
        return NodeDto.builder()
                .id(id)
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label("Под-сценарий").value(value).build())
                .position(new PositionDto(0, 0))
                .build();
    }

    private static Scenario scenario(UUID id, String name, NodeDto... nodes) {
        Scenario scenario = new Scenario();
        scenario.setId(id);
        scenario.setName(name);
        scenario.setGraphData(GraphDataMapper.fromDto(graph(nodes)));
        return scenario;
    }

    /** Поиск сценария по id в памяти с журналом обращений. */
    private static Function<UUID, Optional<Scenario>> repository(List<UUID> calls, Scenario... scenarios) {
        Map<UUID, Scenario> byId = new HashMap<>();
        for (Scenario scenario : scenarios) {
            byId.put(scenario.getId(), scenario);
        }
        return id -> {
            calls.add(id);
            return Optional.ofNullable(byId.get(id));
        };
    }

    @Test
    void unknownOperationsRejectLaunchWithNodeLabels() {
        String transform = ScenarioNodeType.TRANSFORM_NODE.toString();
        GraphDataDto graphData = graph(
                node("in", "input", "Вход", null),
                node("t1", transform, "Свод находок", rules("заменить", "свести_риски")),
                node("t2", transform, "", rules("новая_операция", "свести_риски")),
                node("out", "output", "Выход", null));

        ScenarioException ex = assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(graphData));

        assertEquals("Сценарий использует операции, которых нет в этой версии бэкенда: «свести_риски» в узле «Свод находок»; "
                + "«новая_операция» в узле «t2»; «свести_риски» в узле «t2» — обновите дистрибутив бэкенда", ex.getMessage());
    }

    @Test
    void allSupportedOperationsPass() {
        List<NodeDto> nodes = new ArrayList<>();
        for (String operation : ScenarioExecutorTransformNode.SUPPORTED_OPERATIONS) {
            nodes.add(node("t-" + operation, ScenarioNodeType.TRANSFORM_NODE.toString(), operation, rules(operation)));
        }

        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(new GraphDataDto(nodes, List.of())));
    }

    @Test
    void transformWithoutRulesOrWithBrokenJsonDoesNotBreakValidation() {
        String transform = ScenarioNodeType.TRANSFORM_NODE.toString();
        NodeDto withoutData = NodeDto.builder().id("t0").type(transform).build();
        GraphDataDto graphData = graph(
                withoutData,
                node("t1", transform, "Без правил", null),
                node("t2", transform, "Битый JSON", "{\"операции\": [{\"оп\": \"новая"),
                node("p1", "processing", "Не трансформация", rules("новая_операция")));

        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(graphData));
        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(null));
        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(new GraphDataDto(null, null)));
    }

    @Test
    void operationWithoutNameRejectsLaunch() {
        GraphDataDto graphData = graph(node("t1", ScenarioNodeType.TRANSFORM_NODE.toString(), "Свод",
                "{\"операции\": [{\"шаблон\": \"x\"}, {\"оп\": null}, {}, {\"шаблон\": \"y\"}]}"));

        ScenarioException ex = assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(graphData));

        assertEquals("Ошибка в правилах узлов «Трансформация»: операция без ключа «оп» (найдены ключи: шаблон) в узле «Свод»; "
                + "операция без ключа «оп» (найдены ключи: оп: null) в узле «Свод»; операция без ключа «оп» (найдены ключи: нет) в узле «Свод» "
                + "— исправьте правила узла", ex.getMessage());
    }

    @Test
    void userRulesWithNameKeyInsteadOfOperationAskToFixNodeRules() {
        // прогон FIN-VSP-V1-USER-REPRO: сценарий «Извлечь ВСП из Финансовой структуры по Банкам» из GigaCode, узел s7 —
        // «имя» вместо «оп»; прежде отказ ««(не задана)» … — обновите дистрибутив бэкенда»
        String rules = "{\"операции\": [{\"имя\": \"извлечь_regex\", \"шаблон\": \"^(ВИП ВСП_|ВСП_)\\\\d{8}\", \"группа\": 0, \"все\": false, "
                + "\"разделитель\": \"\"}, {\"имя\": \"взять_символы\", \"от\": 1, \"до\": 8}, {\"имя\": \"json_поле\", \"путь\": \"наименование_ое\"}]}";
        String transform = ScenarioNodeType.TRANSFORM_NODE.toString();
        GraphDataDto graphData = graph(node("s7", transform, "Форматирование данных", rules));
        GraphDataDto mixed = graph(node("s7", transform, "Форматирование данных", rules),
                node("t2", transform, "Свод", rules("заменить", "новая_операция")));

        ScenarioException ex = assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(graphData));
        UUID scenarioId = UUID.randomUUID();
        Function<UUID, Optional<Scenario>> bothRepo = repository(new ArrayList<>());
        ScenarioException both = assertThrows(ScenarioException.class, () -> ScenarioOperationsValidator.validate(mixed, scenarioId,
                bothRepo));

        String noOperation = "операция без ключа «оп» (найдены ключи: имя, шаблон, группа, все, разделитель) в узле «Форматирование данных»; "
                + "операция без ключа «оп» (найдены ключи: имя, от, до) в узле «Форматирование данных»; "
                + "операция без ключа «оп» (найдены ключи: имя, путь) в узле «Форматирование данных»";
        assertEquals(ScenarioOperationsValidator.NO_OPERATION_PREFIX + noOperation + ScenarioOperationsValidator.NO_OPERATION_SUFFIX, ex.getMessage());
        assertFalse(ex.getMessage().contains("обновите дистрибутив"), ex.getMessage());
        assertEquals(ScenarioOperationsValidator.PREFIX + "«новая_операция» в узле «Свод»" + ScenarioOperationsValidator.SUFFIX + ". "
                + ScenarioOperationsValidator.NO_OPERATION_PREFIX + noOperation + ScenarioOperationsValidator.NO_OPERATION_SUFFIX, both.getMessage());
    }

    @Test
    void subScenariosAreCheckedToEngineDepth() {
        String transform = ScenarioNodeType.TRANSFORM_NODE.toString();
        UUID rootId = UUID.randomUUID();
        UUID level1 = UUID.randomUUID();
        UUID level2 = UUID.randomUUID();
        UUID level3 = UUID.randomUUID();
        List<UUID> calls = new ArrayList<>();
        Function<UUID, Optional<Scenario>> repository = repository(calls,
                scenario(level1, "Первый", node("a", transform, "Узел А", rules("новая_а")), subScenario("s", level2.toString())),
                scenario(level2, "", node("b", transform, "Узел Б", rules("заменить", "новая_б")), subScenario("s", level3.toString())),
                scenario(level3, "Третий", node("c", transform, "Узел В", rules("новая_в"))));
        GraphDataDto root = graph(node("t", transform, "Корень", rules("заменить")), subScenario("s1", level1.toString()));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> ScenarioOperationsValidator.validate(root, rootId, repository));

        // третий уровень движок не выполняет (предел вложенности) — он и не загружается
        assertEquals(ScenarioOperationsValidator.PREFIX + "«новая_а» в узле «Узел А» под-сценария «Первый»; "
                + "«новая_б» в узле «Узел Б» под-сценария «" + level2 + "»" + ScenarioOperationsValidator.SUFFIX, ex.getMessage());
        assertEquals(List.of(level1, level2), calls);
        assertEquals(2, ScenarioEngine.MAX_SUB_DEPTH);
    }

    @Test
    void subScenarioCyclesAndRepeatsAreLoadedOnce() {
        String transform = ScenarioNodeType.TRANSFORM_NODE.toString();
        UUID rootId = UUID.randomUUID();
        UUID subId = UUID.randomUUID();
        List<UUID> calls = new ArrayList<>();
        Function<UUID, Optional<Scenario>> repository = repository(calls,
                scenario(subId, "Цикл", node("a", transform, "Узел А", rules("новая_а")),
                        subScenario("self", subId.toString()), subScenario("back", rootId.toString())));
        GraphDataDto root = graph(subScenario("s1", subId.toString()), subScenario("s2", " " + subId + " "));

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> ScenarioOperationsValidator.validate(root, rootId, repository));

        assertEquals(ScenarioOperationsValidator.PREFIX + "«новая_а» в узле «Узел А» под-сценария «Цикл»"
                + ScenarioOperationsValidator.SUFFIX, ex.getMessage());
        assertEquals(List.of(subId), calls);
    }

    @Test
    void missingOrInvalidSubScenarioIsLeftToEngine() {
        UUID missing = UUID.randomUUID();
        List<UUID> calls = new ArrayList<>();
        GraphDataDto root = graph(
                subScenario("s1", missing.toString()),
                subScenario("s2", "не-uuid"),
                subScenario("s3", " "),
                subScenario("s4", null),
                NodeDto.builder().id("s5").type(ScenarioNodeType.SUBSCENARIO_NODE.toString()).build(),
                node("t1", ScenarioNodeType.TRANSFORM_NODE.toString(), "Свод", rules("заменить")));

        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(root, UUID.randomUUID(), repository(calls)));
        assertEquals(List.of(missing), calls);
        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(null, null, repository(calls)));
        assertDoesNotThrow(() -> ScenarioOperationsValidator.validate(new GraphDataDto(null, null), null, repository(calls)));
    }

    @Test
    void rootProblemsAreReportedEvenWithoutSubScenarios() {
        GraphDataDto root = graph(node("t1", ScenarioNodeType.TRANSFORM_NODE.toString(), "Свод", rules("новая")));
        List<UUID> calls = new ArrayList<>();
        UUID scenarioId = UUID.randomUUID();
        Function<UUID, Optional<Scenario>> repo = repository(calls);

        ScenarioException ex = assertThrows(ScenarioException.class,
                () -> ScenarioOperationsValidator.validate(root, scenarioId, repo));

        assertTrue(ex.getMessage().contains("«новая» в узле «Свод» —"), ex.getMessage());
        assertTrue(calls.isEmpty());
    }
}
