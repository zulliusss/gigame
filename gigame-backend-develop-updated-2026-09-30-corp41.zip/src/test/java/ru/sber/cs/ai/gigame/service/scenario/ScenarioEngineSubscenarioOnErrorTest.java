package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.EdgeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.exception.ScenarioException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.executor.AbstractScenarioExecutor;
import ru.sber.cs.ai.gigame.service.scenario.executor.ScenarioExecutorFactory;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunNode;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * on_error узлов под-сценария: continue — ошибка становится результатом узла и под-сценарий доходит до выхода,
 * branch — выполняется ветка «ошибка», stop (по умолчанию) — под-сценарий падает, как раньше. Упавший узел попадает
 * в перечень упавших узлов графа родительского узла.
 */
class ScenarioEngineSubscenarioOnErrorTest {

    private static final String PARENT_LABEL = "Кодовые проверки (под-сценарий)";

    private final ScenarioRepository scenarioRepository = mock(ScenarioRepository.class);
    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    @Test
    void continueTurnsErrorIntoResultAndReachesOutput() {
        ScenarioRunNode parent = parentWithSubScenario(List.of(input(), node("a-1", "Находки модели", "continue"),
                output()), List.of(edge("input-1", "a-1", null), edge("a-1", "out-1", null)));
        ScenarioEngine engine = engine(Map.of("a-1", n -> throwing(n, "GigaChat не ответил")));

        String result = engine.executeSubScenarioInline(subId(parent), parent, sink);

        assertTrue(result.contains(ScenarioEngine.NODE_ERROR_PREFIX + "Находки модели»: GigaChat не ответил]"), result);
        assertEquals(List.of(PARENT_LABEL + " → Находки модели"), List.copyOf(parent.getGraph().getFailedNodeLabels()));
    }

    @Test
    void stopByDefaultFailsSubScenarioAsBefore() {
        ScenarioRunNode parent = parentWithSubScenario(List.of(input(), node("a-1", "Находки модели", null), output()),
                List.of(edge("input-1", "a-1", null), edge("a-1", "out-1", null)));
        ScenarioEngine engine = engine(Map.of("a-1", n -> throwing(n, "GigaChat не ответил")));
        String id = subId(parent);

        ScenarioException e = assertThrows(ScenarioException.class, () -> engine.executeSubScenarioInline(id, parent, sink));

        assertEquals("GigaChat не ответил", e.getMessage());
        assertTrue(parent.getGraph().getFailedNodeLabels().isEmpty());
    }

    @Test
    void branchRunsOnlyErrorEdge() {
        ScenarioRunNode parent = parentWithSubScenario(
                List.of(input(), node("a-1", "Находки модели", "branch"), node("b-1", "Запасной путь", null),
                        node("c-1", "Обычный путь", null), output()),
                List.of(edge("input-1", "a-1", null), edge("a-1", "b-1", "ошибка"), edge("a-1", "c-1", null),
                        edge("b-1", "out-1", null), edge("c-1", "out-1", null)));
        ScenarioEngine engine = engine(Map.of("a-1", n -> throwing(n, "таймаут"),
                "b-1", n -> contributing(n, "запасной результат"),
                "c-1", n -> contributing(n, "обычный результат")));

        String result = engine.executeSubScenarioInline(subId(parent), parent, sink);

        assertTrue(result.contains("запасной результат"), result);
        assertFalse(result.contains("обычный результат"), result);
    }

    @Test
    void cancelledRunIsNotContinued() {
        ScenarioRunNode parent = parentWithSubScenario(List.of(input(), node("a-1", "Находки модели", "continue"),
                output()), List.of(edge("input-1", "a-1", null), edge("a-1", "out-1", null)));
        parent.getGraph().requestCancel("Прогон остановлен пользователем");
        ScenarioEngine engine = engine(Map.of("a-1", n -> throwing(n, "Запрос к GigaChat прерван: прогон остановлен")));
        String id = subId(parent);

        assertThrows(ScenarioException.class, () -> engine.executeSubScenarioInline(id, parent, sink));
        assertTrue(parent.getGraph().getFailedNodeLabels().isEmpty());
    }

    // -------------------------------------------------------------------------
    // helpers
    // -------------------------------------------------------------------------

    private ScenarioEngine engine(Map<String, Function<ScenarioRunNode, AbstractScenarioExecutor>> custom) {
        var real = new ScenarioExecutorFactory(null, null, null, null, null);
        var factory = mock(ScenarioExecutorFactory.class);
        when(factory.createExecutor(any(ScenarioRunNode.class))).thenAnswer(inv -> {
            ScenarioRunNode node = inv.getArgument(0);
            var maker = custom.get(node.getId());
            if (maker != null) {
                return maker.apply(node);
            }
            return node.getType() == ScenarioNodeType.INPUT_NODE ? contributing(node, "вход") : real.createExecutor(node);
        });
        var support = mock(ScenarioOutputSupportService.class);
        when(support.accumulateIfConfigured(any(), any(), any())).thenAnswer(inv -> inv.getArgument(2));
        return new ScenarioEngine(mock(ScenarioRunService.class), mock(ScenarioRunStepService.class), factory,
                mock(DocsTextCacheService.class), scenarioRepository, support);
    }

    /** Узел «Под-сценарий» с входом, чей сценарий — граф из аргументов. */
    private ScenarioRunNode parentWithSubScenario(List<NodeDto> nodes, List<EdgeDto> edges) {
        var sub = new Scenario();
        sub.setId(UUID.randomUUID());
        sub.setName("шаг 1");
        sub.setGraphData(GraphDataMapper.fromDto(new GraphDataDto(nodes, edges)));
        when(scenarioRepository.findById(sub.getId())).thenReturn(Optional.of(sub));
        NodeDto parentDto = NodeDto.builder()
                .id("sub1")
                .type(ScenarioNodeType.SUBSCENARIO_NODE.toString())
                .data(NodeDataDto.builder().label(PARENT_LABEL).value(sub.getId().toString()).build())
                .position(new PositionDto(0, 0))
                .build();
        var graph = new ScenarioRunGraph(new GraphDataDto(List.of(input(), parentDto), List.of(edge("input-1", "sub1", null))));
        ScenarioRunNode parent = graph.getNodeMap().get("sub1");
        parent.getInput().add("текст комплекта");
        return parent;
    }

    private static String subId(ScenarioRunNode parent) {
        return parent.getValue();
    }

    private static AbstractScenarioExecutor throwing(ScenarioRunNode runNode, String message) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> eventSink) {
                throw new ScenarioException(message);
            }
        };
    }

    private static AbstractScenarioExecutor contributing(ScenarioRunNode runNode, String text) {
        return new AbstractScenarioExecutor(runNode) {
            @Override
            public String execute(FluxSink<ServerSentEvent<Map<String, Object>>> eventSink) {
                runNode.getOutput().add(text);
                for (var child : runNode.getChildNodeList()) {
                    child.setSkip(false);
                    child.addInput(runNode.getId(), "=== РЕЗУЛЬТАТ ОТ \"" + runNode.getLabel() + "\" ===\n" + text);
                }
                return text;
            }
        };
    }

    private static NodeDto input() {
        return NodeDto.builder().id("input-1").type(ScenarioNodeType.INPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Вход").build()).position(new PositionDto(0, 0)).build();
    }

    private static NodeDto output() {
        return NodeDto.builder().id("out-1").type(ScenarioNodeType.OUTPUT_NODE.toString())
                .data(NodeDataDto.builder().label("Выход").build()).position(new PositionDto(0, 0)).build();
    }

    private static NodeDto node(String id, String label, String onError) {
        return NodeDto.builder().id(id).type(ScenarioNodeType.PROCESSING_NODE.toString())
                .data(NodeDataDto.builder().label(label).prompt("p").onError(onError).build())
                .position(new PositionDto(0, 0)).build();
    }

    private static EdgeDto edge(String source, String target, String label) {
        return new EdgeDto(source + "-" + target, source, target, new EdgeDataDto(label));
    }
}
