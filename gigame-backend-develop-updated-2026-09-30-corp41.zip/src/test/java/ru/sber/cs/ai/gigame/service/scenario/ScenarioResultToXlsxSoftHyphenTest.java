package ru.sber.cs.ai.gigame.service.scenario;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Сопоставление строк исходной формы со строками данных по «исходная_строка» при мягких переносах и узких пробелах
 * (комплект Иновью, шаблон «Форма опыта Сбербанк»): код строк Формы 3 пишет «исходная_строка» уже без мягкого переноса,
 * а узел «Строки исходной формы» отдаёт строки как в файле — раньше 71 строка из 93 становилась заглушкой.
 */
class ScenarioResultToXlsxSoftHyphenTest {

    private static final String SHY = "\u00AD";

    private static Map<String, Object> dataRow(String act, String reason, String sourceLine) {
        Map<String, Object> row = new LinkedHashMap<>();
        row.put("к6", act);
        row.put("к15", reason);
        row.put("исходная_строка", sourceLine);
        return row;
    }

    @Test
    void formLineWithSoftHyphensMatchesNormalizedSourceLine() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Строки исходной формы\", "
                + "\"ключ_регекс\": \"УПД\\\\s*№?\\\\s*0*(\\\\d{5,10})\", "
                + "\"ключ_регекс_данных\": \"0*(\\\\d{5,10})\", \"ключ_данных\": \"к6\", "
                + "\"ключ_строка\": \"исходная_строка\", \"колонка_исходной\": \"к0\", "
                + "\"заглушки\": {\"к15\": \"Подтверждающие документы не найдены\"}}}";
        String line1 = "ООО | Договор № 4000001 от 27.02.2024 | Счет-" + SHY + "фактура N 346 от 25.03.2025 | 2765664,00";
        String line2 = "ООО | Договор № 4000001 от 27.02.2024 | Счет" + SHY + "-фактура N 347 от 25.03.2025 | 11547360,00";
        List<Map<String, Object>> data = new ArrayList<>(List.of(
                dataRow("УПД № 346 от 25.03.2025", "-", line1.replace(SHY, "")),
                dataRow("", "технология не найдена", line2.replace(SHY, ""))));

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(data, rules, line1 + "\n" + line2);

        assertEquals(2, out.size());
        assertEquals("-", out.get(0).get("к15"));
        assertEquals("технология не найдена", out.get(1).get("к15"));
        assertEquals(line1, out.get(0).get("к0"));
    }

    @Test
    void softHyphenInsideNumberAndThinSpacesAreNormalizedLikeFormCode() {
        String rules = "{\"обогащение_формы\": {\"из_узла\": \"Строки исходной формы\", "
                + "\"ключ_регекс\": \"УПД\\\\s*№?\\\\s*0*(\\\\d{5,10})\", "
                + "\"ключ_регекс_данных\": \"0*(\\\\d{5,10})\", \"ключ_данных\": \"к6\", "
                + "\"ключ_строка\": \"исходная_строка\", \"колонка_исходной\": \"к0\", "
                + "\"заглушки\": {\"к15\": \"Подтверждающие документы не найдены\"}}}";
        String form = "ООО | УПД № ИП" + SHY + "25" + SHY + "000492 от 12.12.2025 |\u00A01\u2009884\u202F931,02";
        String normalized = "ООО | УПД № ИП-25-000492 от 12.12.2025 | 1 884 931,02";
        List<Map<String, Object>> data = new ArrayList<>(List.of(dataRow("ИП-25-000492", "-", normalized)));

        List<Map<String, Object>> out = ScenarioResultToXlsx.enrichAgainstForm(data, rules, form);

        assertEquals(1, out.size());
        assertEquals("-", out.get(0).get("к15"));
        assertEquals("ИП-25-000492", out.get(0).get("к6"));
    }
}
