package ru.sber.cs.ai.gigame.service.scenario;

import lombok.Getter;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Flux;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunDetailResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunResponse;
import ru.sber.cs.ai.gigame.dto.scenario.ScenarioRunStepResponse;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataMapper;
import ru.sber.cs.ai.gigame.exception.FileException;
import ru.sber.cs.ai.gigame.exception.NotFoundException;
import ru.sber.cs.ai.gigame.model.Scenario;
import ru.sber.cs.ai.gigame.model.ScenarioRating;
import ru.sber.cs.ai.gigame.model.ScenarioRun;
import ru.sber.cs.ai.gigame.model.ScenarioRunStep;
import ru.sber.cs.ai.gigame.model.ScenarioVersion;
import ru.sber.cs.ai.gigame.repository.ScenarioRatingRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioRunStepRepository;
import ru.sber.cs.ai.gigame.repository.ScenarioVersionRepository;
import ru.sber.cs.ai.gigame.service.DocumentService;
import ru.sber.cs.ai.gigame.service.ScanOcrService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;
import ru.sber.cs.ai.gigame.utils.FileUtils;
import ru.sber.cs.ai.gigame.utils.UserUtils;
import ru.sber.cs.ai.gigame.utils.ZipExtractor;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicReference;
import java.util.zip.ZipEntry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipInputStream;

/**
 * Сервис управления сценариями.
 * <p>
 * Реализует простые операции CRUD для сценариев, запусков и шагов.
 * Логика выполнения сценариев находится в {@link ScenarioEngine}.
 *
 * @see Scenario
 * @see ScenarioRun
 * @see ScenarioRunStep
 */
@Service
@Slf4j
@SuppressWarnings("java:S1192") // String literals should not be duplicated
public class ScenarioService {

    /**
     * Лимиты длин полей из OpenAPI-схемы ответа списка сценариев: корп. шлюз
     * валидирует ОТВЕТЫ по схеме, и один сценарий с более длинным name или
     * description ломает выдачу списка для ВСЕХ пользователей — поэтому
     * значения мягко обрезаются при создании и обновлении.
     */
    static final int MAX_NAME_LENGTH = 64;
    static final int MAX_DESCRIPTION_LENGTH = 255;

    /** Одиночное число в записи с точкой либо запятой (эталоны сумм из transform-узла). */
    private static final Pattern REFERENCE_NUMBER =
            Pattern.compile("(?<!\\d)(\\d{2,}[.,]\\d{1,2}|\\d{4,})(?!\\d)");

    /**
     * Максимум документов на прогон после распаковки архивов
     * ({@code app.scenario.max-documents-per-run}, env {@code SCENARIO_MAX_DOCUMENTS}).
     * Большие наборы догружаются частями: POST /upload?append=true.
     */
    @Value("${app.scenario.max-documents-per-run:500}")
    @Getter
    private int maxDocumentsPerRun = 500;

    /**
     * Параллельность извлечения текста документов при загрузке: большие комплекты
     * (сотни страниц PDF, OCR сканов) при последовательном парсинге превышают
     * таймауты корпоративных шлюзов.
     */
    @Value("${app.document.parse-parallelism:4}")
    private int parseParallelism = 4;

    /**
     * Лимит распакованного размера одной внутренней записи OOXML-файла
     * (docx/xlsx/pptx): защита от «XML-бомб», которые POI минутами раздувает
     * перед отказом.
     */
    @Value("${app.document.max-ooxml-entry-mb:50}")
    private int maxOoxmlEntryMb = 50;

    /**
     * Порог длины текста PDF, ниже которого документ считается сканом без текстового слоя.
     */
    @Value("${app.document.min-parsed-chars:40}")
    private int minParsedChars;

    private final ScenarioRepository scenarioRepository;
    private final ScenarioRunRepository scenarioRunRepository;
    private final ScenarioRunStepRepository scenarioRunStepRepository;
    private final ScenarioVersionRepository scenarioVersionRepository;
    private final ScenarioEngine scenarioEngine;
    private final DocumentService documentService;
    private final ScanOcrService scanOcrService;
    private final ScenarioRatingRepository scenarioRatingRepository;

    /**
     * Self-injection для вызова @Transactional-методов через AOP-прокси.
     * Без этого вызов {@code this.updateScenario(...)} внутри того же бина
     * не создаёт транзакцию, аннотация игнорируется.
     */
    private final AtomicReference<ScenarioService> self = new AtomicReference<>();

    public ScenarioService(ScenarioRepository scenarioRepository,
                           ScenarioRunRepository scenarioRunRepository,
                           ScenarioRunStepRepository scenarioRunStepRepository,
                           ScenarioVersionRepository scenarioVersionRepository,
                           ScenarioEngine scenarioEngine,
                           DocumentService documentService,
                           ScanOcrService scanOcrService,
                           ScenarioRatingRepository scenarioRatingRepository) {
        this.scenarioRepository = scenarioRepository;
        this.scenarioRunRepository = scenarioRunRepository;
        this.scenarioRunStepRepository = scenarioRunStepRepository;
        this.scenarioVersionRepository = scenarioVersionRepository;
        this.scenarioEngine = scenarioEngine;
        this.documentService = documentService;
        this.scanOcrService = scanOcrService;
        this.scenarioRatingRepository = scenarioRatingRepository;
    }

    @Autowired
    public void setSelf(@Lazy ScenarioService self) {
        this.self.set(self);
    }

    // -------------------------------------------------------------------------
    // CRUD сценариев
    // -------------------------------------------------------------------------

    /**
     * Возвращает список всех сценариев, отсортированных по дате обновления.
     *
     * @return список сценариев пользователя
     */
    public List<ScenarioResponse> getScenarios() {
        String uid = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getScenarios", uid);
        List<Scenario> scenarios = scenarioRepository.findAllByUserIdOrSharedTrueOrderByUpdatedAtDesc(uid);
        List<UUID> ids = scenarios.stream().map(Scenario::getId).toList();
        List<ScenarioRating> allRatings = ids.isEmpty()
                ? List.of()
                : scenarioRatingRepository.findByScenarioIdIn(ids);
        Map<UUID, long[]> ratingSums = ratingSummaries(allRatings);
        Map<UUID, Integer> myRatings = myRatings(allRatings, uid);
        Map<UUID, Long> runCounts = runCounts(ids);
        return scenarios.stream()
                .map(s -> toStatisticsResponse(s, uid, ratingSums, myRatings, runCounts))
                .toList();
    }

    /**
     * Сводка оценок по сценариям: id — массив [сумма оценок, количество].
     */
    private Map<UUID, long[]> ratingSummaries(List<ScenarioRating> ratings) {
        Map<UUID, long[]> summary = new HashMap<>();
        for (ScenarioRating rating : ratings) {
            long[] acc = summary.computeIfAbsent(rating.getScenarioId(), k -> new long[2]);
            acc[0] += rating.getRating();
            acc[1]++;
        }
        return summary;
    }

    /**
     * Оценки текущего пользователя по сценариям.
     */
    private Map<UUID, Integer> myRatings(List<ScenarioRating> ratings, String uid) {
        Map<UUID, Integer> mine = new HashMap<>();
        for (ScenarioRating rating : ratings) {
            if (uid.equals(rating.getUserId())) {
                mine.put(rating.getScenarioId(), rating.getRating());
            }
        }
        return mine;
    }

    /**
     * Количество запусков по сценариям.
     */
    private Map<UUID, Long> runCounts(List<UUID> ids) {
        Map<UUID, Long> counts = new HashMap<>();
        if (ids.isEmpty()) {
            return counts;
        }
        for (Object[] row : scenarioRunRepository.countByScenarioIds(ids)) {
            counts.put((UUID) row[0], (Long) row[1]);
        }
        return counts;
    }

    /**
     * Собирает DTO сценария со статистикой (рейтинг, запуски, владение).
     */
    private ScenarioResponse toStatisticsResponse(Scenario s, String uid,
                                                  Map<UUID, long[]> ratingSums,
                                                  Map<UUID, Integer> myRatings,
                                                  Map<UUID, Long> runCounts) {
        long[] acc = ratingSums.get(s.getId());
        Double avg = acc == null ? null : Math.round(acc[0] * 10.0 / acc[1]) / 10.0;
        Long count = acc == null ? 0L : acc[1];
        return new ScenarioResponse(
                s.getId(), s.getName(), s.getDescription(), s.getCreatedAt(), s.getUpdatedAt(),
                Boolean.TRUE.equals(s.getShared()),
                uid.equals(s.getUserId()),
                avg, count,
                myRatings.get(s.getId()),
                runCounts.getOrDefault(s.getId(), 0L));
    }

    /**
     * Ставит или обновляет оценку сценария текущим пользователем (1..5).
     * Оценивать можно общие сценарии и собственные.
     *
     * @param id     UUID сценария
     * @param rating оценка от 1 до 5
     */
    @Transactional
    public void rateScenario(UUID id, int rating) {
        log.info("[{}] rateScenario, id={}, rating={}", CurrentUserHolder.getCurrentUser(), id, rating);
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Оценка должна быть от 1 до 5");
        }
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Scenario not found: " + id));
        String uid = CurrentUserHolder.getCurrentUser();
        if (!Boolean.TRUE.equals(scenario.getShared())) {
            UserUtils.checkUserId(uid, scenario.getUserId());
        }
        ScenarioRating vote = new ScenarioRating();
        vote.setScenarioId(id);
        vote.setUserId(uid);
        vote.setRating(rating);
        scenarioRatingRepository.save(vote);
    }

    /**
     * Возвращает один сценарий с полными данными графа.
     * Выбрасывает исключение, если сценарий не найден.
     *
     * @param userId идентификатор пользователя
     * @param id     UUID сценария
     * @return подробная информация о сценарии
     */
    public ScenarioDetailResponse getScenario(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getScenario, id={}", userId, id);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Scenario not found: " + id));
        if (!Boolean.TRUE.equals(scenario.getShared())) {
            // общий сценарий доступен всем на чтение и запуск; личный — только владельцу
            UserUtils.checkUserId(userId, scenario.getUserId());
        }
        return ScenarioMapper.toDetailResponse(scenario);
    }

    /**
     * Создаёт новый сценарий.
     *
     * @param name        имя сценария
     * @param description описание сценария (опционально)
     * @param graphData   данные графа (узлы и рёбра)
     * @return созданный сценарий
     */
    @Transactional
    public ScenarioResponse createScenario(String name, String description, GraphDataDto graphData) {
        log.info("[{}] createScenario, name='{}'", CurrentUserHolder.getCurrentUser(), name);
        Scenario scenario = new Scenario();
        scenario.setName(clip(name, MAX_NAME_LENGTH));
        scenario.setDescription(clip(description, MAX_DESCRIPTION_LENGTH));
        scenario.setGraphData(graphData != null ? GraphDataMapper.fromDto(graphData) : Map.of());
        scenario.setUserId(CurrentUserHolder.getCurrentUser());
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Обновляет существующий сценарий.
     *
     * @param id          UUID сценария
     * @param name        новое имя (опционально)
     * @param description новое описание (опционально)
     * @param graphData   новые данные графа (опционально)
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse updateScenario(UUID id, String name, String description,
                                           GraphDataDto graphData) {
        return self.get().updateScenario(id, name, description, graphData, null);
    }

    /**
     * Обновляет существующий сценарий, включая признак общего доступа.
     *
     * @param id          UUID сценария
     * @param name        новое имя (опционально)
     * @param description новое описание (опционально)
     * @param graphData   новые данные графа (опционально)
     * @param shared      признак общего доступа (null — не менять)
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse updateScenario(UUID id, String name, String description,
                                           GraphDataDto graphData, Boolean shared) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] updateScenario, id={}", CurrentUserHolder.getCurrentUser(), id);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        var version = new ScenarioVersion();
        version.setId(UUID.randomUUID());
        version.setScenarioId(scenario.getId());
        version.setVersionNo(
                scenarioVersionRepository
                        .findFirstByScenarioIdOrderByVersionNoDesc(scenario.getId())
                        .map(v -> v.getVersionNo() + 1)
                        .orElse(1));
        version.setName(scenario.getName());
        version.setDescription(scenario.getDescription());
        version.setGraphData(scenario.getGraphData());
        version.setCreatedAt(OffsetDateTime.now());
        scenarioVersionRepository.save(version);
        if (name != null) {
            scenario.setName(clip(name, MAX_NAME_LENGTH));
        }
        if (description != null) {
            scenario.setDescription(clip(description, MAX_DESCRIPTION_LENGTH));
        }
        if (graphData != null) {
            scenario.setGraphData(GraphDataMapper.fromDto(graphData));
        }
        if (shared != null) {
            scenario.setShared(shared);
        }
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Мягкая обрезка строки до лимита схемы ответа (с многоточием).
     *
     * @param value исходное значение (может быть null)
     * @param max   максимальная длина по схеме
     * @return значение не длиннее лимита
     */
    private static String clip(String value, int max) {
        if (value == null || value.length() <= max) {
            return value;
        }
        return value.substring(0, max - 1) + "…";
    }

    /**
     * Список версий сценария (метаданные, без графов).
     *
     * @param id UUID сценария
     * @return версии от новых к старым
     */
    public List<Map<String, Object>> getVersions(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        return scenarioVersionRepository.findByScenarioIdOrderByVersionNoDesc(id).stream()
                .map(v -> Map.<String, Object>of(
                        "version_no", v.getVersionNo(),
                        "name", v.getName() == null ? "" : v.getName(),
                        "created_at", v.getCreatedAt()))
                .toList();
    }

    /**
     * Восстанавливает сценарий из версии. Текущее состояние предварительно
     * сохраняется как новая версия — откат отката возможен.
     *
     * @param id        UUID сценария
     * @param versionNo номер версии
     * @return обновлённый сценарий
     */
    @Transactional
    public ScenarioResponse restoreVersion(UUID id, int versionNo) {
        var userId = CurrentUserHolder.getCurrentUser();
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        var version = scenarioVersionRepository.findByScenarioIdAndVersionNo(id, versionNo)
                .orElseThrow(() -> new NotFoundException("Версия " + versionNo + " не найдена"));
        var snapshot = new ScenarioVersion();
        snapshot.setId(UUID.randomUUID());
        snapshot.setScenarioId(scenario.getId());
        snapshot.setVersionNo(
                scenarioVersionRepository
                        .findFirstByScenarioIdOrderByVersionNoDesc(scenario.getId())
                        .map(v -> v.getVersionNo() + 1)
                        .orElse(1));
        snapshot.setName(scenario.getName());
        snapshot.setDescription(scenario.getDescription());
        snapshot.setGraphData(scenario.getGraphData());
        snapshot.setCreatedAt(OffsetDateTime.now());
        scenarioVersionRepository.save(snapshot);
        scenario.setName(version.getName());
        scenario.setDescription(version.getDescription());
        scenario.setGraphData(version.getGraphData());
        scenario = scenarioRepository.save(scenario);
        return ScenarioMapper.toResponse(scenario);
    }

    /**
     * Возобновляет упавший прогон с места сбоя: создаёт новый прогон, восстанавливая
     * результаты завершённых LLM-узлов из шагов исходного (без повторных обращений
     * к GigaChat за уже полученными ответами).
     *
     * @param runId  идентификатор упавшего прогона
     * @return поток SSE-событий нового прогона
     */
    public Flux<ServerSentEvent<Map<String, Object>>> resumeScenarioRun(UUID runId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] resumeScenarioRun, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        ScenarioRun oldRun = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new IllegalArgumentException("Запуск сценария не найден: " + runId));
        Scenario model = scenarioRepository.findById(oldRun.getScenarioId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        // общий сценарий может возобновить любой пользователь
        if (!Boolean.TRUE.equals(model.getShared())) {
            UserUtils.checkUserId(userId, model.getUserId());
        }
        List<ScenarioRunStep> oldSteps = scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(runId);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(oldRun.getScenarioId());
        run.setStatus("running");
        run.setStartedAt(OffsetDateTime.now());
        run = scenarioRunRepository.save(run);
        return scenarioEngine.resumeScenario(run, GraphDataMapper.toDto(model.getGraphData()),
                oldSteps, userId);
    }

    /**
     * Создаёт копию сценария с суффиксом "(копия)".
     *
     * @param id UUID сценария
     * @return дубликат сценария
     */
    @Transactional
    public ScenarioResponse duplicateScenario(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] duplicateScenario, id={}", CurrentUserHolder.getCurrentUser(), id);
        Scenario original = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Scenario not found: " + id));
        if (!Boolean.TRUE.equals(original.getShared())) {
            // общий сценарий может клонировать себе любой пользователь
            UserUtils.checkUserId(userId, original.getUserId());
        }
        Scenario copy = new Scenario();
        copy.setName(original.getName() + " (копия)");
        copy.setDescription(original.getDescription());
        copy.setGraphData(original.getGraphData());
        copy.setUserId(CurrentUserHolder.getCurrentUser());
        copy = scenarioRepository.save(copy);
        return ScenarioMapper.toResponse(copy);
    }

    /**
     * Удаляет сценарий по идентификатору.
     *
     * @param id UUID сценария
     */
    @Transactional
    public void deleteScenario(UUID id) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] deleteScenario, id={}", CurrentUserHolder.getCurrentUser(), id);
        Scenario scenario = scenarioRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + id));
        UserUtils.checkUserId(userId, scenario.getUserId());
        scenarioRepository.delete(scenario);
    }

    // -------------------------------------------------------------------------
    // Запросы запусков сценариев
    // -------------------------------------------------------------------------

    /**
     * Возвращает список запусков для указанного сценария.
     *
     * @param scenarioId UUID сценария
     * @return список запусков, отсортированных по дате начала
     */
    public List<ScenarioRunResponse> getScenarioRuns(UUID scenarioId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getScenarioRuns, scenarioId={}", CurrentUserHolder.getCurrentUser(), scenarioId);
        Scenario scenario = scenarioRepository.findById(scenarioId)
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + scenarioId));
        UserUtils.checkUserId(userId, scenario.getUserId());
        return scenarioRunRepository.findByScenarioIdOrderByStartedAtDesc(scenarioId).stream()
                .map(ScenarioMapper::toRunResponse)
                .toList();
    }

    /**
     * Возвращает детальную информацию о запуске сценария со всеми шагами.
     *
     * @param runId  UUID запуска
     * @return детальная информация о запуске
     */
    public ScenarioRunDetailResponse getScenarioRun(UUID runId) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] getScenarioRun, runId={}", CurrentUserHolder.getCurrentUser(), runId);
        ScenarioRun run = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new IllegalArgumentException("Запуск сценария не найден: " + runId));
        Scenario scenario = scenarioRepository.findById(run.getScenarioId())
                .orElseThrow(() -> new IllegalArgumentException("Сценарий не найден: " + run.getScenarioId()));
        UserUtils.checkUserId(userId, scenario.getUserId());
        List<ScenarioRunStepResponse> stepResponses = scenarioRunStepRepository
                .findByRunIdOrderByStartedAtAsc(run.getId()).stream()
                .map(ScenarioMapper::toStepResponse)
                .toList();
        return new ScenarioRunDetailResponse(
                run.getId(),
                run.getScenarioId(),
                run.getStatus(),
                run.getInputDocumentIds(),
                run.getResult(),
                run.getStartedAt(),
                run.getCompletedAt(),
                stepResponses
        );
    }

    /**
     * Сохраняет запуск сценария.
     *
     * @param run запуск сценария
     * @return сохраненный запуск
     */
    @Transactional
    @SuppressWarnings("unused")
    public ScenarioRun saveScenarioRun(ScenarioRun run) {
        return scenarioRunRepository.save(run);
    }

    public Flux<ServerSentEvent<Map<String, Object>>> runScenario(UUID id, Boolean stepMode) {
        var userId = CurrentUserHolder.getCurrentUser();
        log.info("[{}] runScenario, scenarioId={}, stepMode={}", CurrentUserHolder.getCurrentUser(), id, stepMode);
        var model = scenarioRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        // общий сценарий доступен для запуска всем пользователям
        if (!Boolean.TRUE.equals(model.getShared())) {
            UserUtils.checkUserId(userId, model.getUserId());
        }
        var scenario = ScenarioMapper.toDetailResponse(model);
        ScenarioRun run = new ScenarioRun();
        run.setScenarioId(id);
        run.setStatus("running");
        run.setStartedAt(OffsetDateTime.now());
        run = scenarioRunRepository.save(run);

        if (Boolean.TRUE.equals(stepMode)) {
            scenarioEngine.enableStepMode(run.getId().toString());
        }

        run = scenarioRunRepository.save(run);
        return scenarioEngine.executeScenario(run, scenario.graphData(), userId);
    }

    public List<String> getDocumentsText(List<FilePart> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        return getDocuments(files, uploadEvents).stream().map(DocumentText::text).toList();
    }

    /**
     * Превращает загруженные файлы в документы для прогона сценария.
     * <p>
     * ZIP- и 7z-архивы распаковываются ({@link ZipExtractor}): служебные файлы ЭДО
     * отфильтровываются, а имя каждого документа включает путь внутри архива.
     * PDF без текстового слоя (скан) не отбрасывается — его текст заменяется
     * маркером «ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА», который проходит по конвейеру
     * до итоговой таблицы. Извлечение текста идёт параллельно
     * ({@code app.document.parse-parallelism}) с сохранением порядка документов.
     *
     * @param files        загруженные файлы (в т.ч. ZIP/7z)
     * @param uploadEvents накопитель SSE-событий прогресса (может быть {@code null})
     * @return документы: имя + извлечённый текст
     */
    public List<DocumentText> getDocuments(List<FilePart> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        return parseFiles(readFiles(files), uploadEvents);
    }

    /**
     * Загруженный файл до разбора: имя + байты содержимого (архив ещё не распакован).
     */
    public record RawFile(String name, byte[] content) {
        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof RawFile rawFile)) {
                return false;
            }
            return name.equals(rawFile.name) && java.util.Arrays.equals(content, rawFile.content);
        }

        @Override
        public int hashCode() {
            int result = name.hashCode();
            result = 31 * result + java.util.Arrays.hashCode(content);
            return result;
        }

        @Override
        @NonNull
        public String toString() {
            return "RawFile[" + "name=" + name + ", content=" + java.util.Arrays.toString(content) + ']';
        }
    }

    /**
     * Быстрая фаза загрузки: читает байты всех файлов из HTTP-запроса.
     * Медленный разбор ({@link #parseFiles}) можно выполнять уже вне запроса —
     * на этом построен асинхронный режим загрузки
     * ({@link ScenarioUploadTaskService}).
     *
     * @param files загруженные файлы
     * @return файлы: имя + содержимое
     */
    public List<RawFile> readFiles(List<FilePart> files) {
        List<RawFile> raw = new ArrayList<>();
        for (FilePart file : files) {
            String filename = FileUtils.getFilename(file);
            raw.add(new RawFile(filename, readFileContent(file, filename)));
        }
        return raw;
    }

    /**
     * Медленная фаза загрузки: распаковка архивов и параллельное извлечение
     * текста документов (правила — см. {@link #getDocuments}).
     *
     * @param files        файлы: имя + байты содержимого
     * @param uploadEvents накопитель SSE-событий прогресса (может быть {@code null})
     * @return документы: имя + извлечённый текст
     */
    public List<DocumentText> parseFiles(List<RawFile> files, List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        List<RawDocument> raws = collectRawDocuments(files, uploadEvents);
        List<DocumentText> documents = parseAllParallel(raws, uploadEvents);
        if (documents.size() > maxDocumentsPerRun) {
            throw new FileException("Слишком много документов после распаковки архивов: "
                    + documents.size() + ". Максимум: " + maxDocumentsPerRun);
        }
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_done", "count", documents.size()))
                    .build());
        }
        return documents;
    }

    /**
     * Собирает сырые документы: архивы (ZIP/7z) распаковываются, остальные
     * файлы попадают в накопитель как есть.
     *
     * @param files        файлы: имя + содержимое
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return сырые документы для извлечения текста
     */
    private List<RawDocument> collectRawDocuments(List<RawFile> files,
                                                  List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        List<RawDocument> raws = new ArrayList<>();
        for (int i = 0; i < files.size(); i++) {
            RawFile file = files.get(i);
            emitUploadProgress(uploadEvents, file.name(), i + 1, files.size());
            String lower = file.name().toLowerCase();
            if (lower.endsWith(".zip") || lower.endsWith(".7z")) {
                appendArchiveDocuments(raws, file.name(), file.content());
            } else {
                raws.add(new RawDocument(file.name(), file.content()));
            }
        }
        return raws;
    }

    /**
     * Отправляет SSE-событие прогресса загрузки файла (если накопитель задан).
     *
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @param filename     имя загружаемого файла
     * @param current      номер текущего файла (с 1)
     * @param total        общее количество файлов
     */
    private void emitUploadProgress(List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                    String filename, int current, int total) {
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_progress",
                            "file", filename, "current", current, "total", total))
                    .build());
        }
    }

    /**
     * Читает содержимое загруженного файла в массив байт.
     *
     * @param file     загруженный файл
     * @param filename имя файла (для сообщения об ошибке)
     * @return содержимое файла
     */
    private byte[] readFileContent(FilePart file, String filename) {
        try (InputStream inputStream = FileUtils.toInputStream(file).block()) {
            if (inputStream == null) {
                throw new FileException("Не удалось прочитать файл: " + filename);
            }
            return inputStream.readAllBytes();
        } catch (Exception e) {
            throw new FileException("Не удалось прочитать файл: " + filename, e);
        }
    }

    /**
     * Сырой документ до извлечения текста: имя + байты содержимого.
     */
    private record RawDocument(String name, byte[] content) {
        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof RawDocument rawDocument)) {
                return false;
            }
            return name.equals(rawDocument.name) && java.util.Arrays.equals(content, rawDocument.content);
        }

        @Override
        public int hashCode() {
            int result = name.hashCode();
            result = 31 * result + java.util.Arrays.hashCode(content);
            return result;
        }

        @Override
        @NonNull
        public String toString() {
            return "RawDocument[" + "name=" + name + ", content=" + java.util.Arrays.toString(content) + ']';
        }
    }

    /**
     * Распаковывает ZIP/7z-архив и добавляет его файлы в накопитель сырых документов.
     *
     * @param raws     накопитель сырых документов прогона (пополняется)
     * @param filename имя архива
     * @param content  содержимое архива
     */
    private void appendArchiveDocuments(List<RawDocument> raws, String filename, byte[] content) {
        var extraction = ZipExtractor.extract(filename, content);
        if (extraction.files().isEmpty()) {
            throw new FileException("Архив не содержит поддерживаемых документов: " + filename);
        }
        for (var extracted : extraction.files()) {
            raws.add(new RawDocument(extracted.name(), extracted.content()));
        }
    }

    /**
     * Извлекает текст всех документов параллельно (пул
     * {@code app.document.parse-parallelism} потоков) с сохранением порядка:
     * синхронная загрузка больших комплектов (сотни страниц PDF, OCR сканов)
     * при последовательном парсинге превышает таймауты корпоративных шлюзов.
     *
     * @param raws         документы: имя + сырое содержимое (текст ещё не извлечён)
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return распарсенные документы в исходном порядке
     */
    private List<DocumentText> parseAllParallel(List<RawDocument> raws,
                                                List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        List<DocumentText> documents = new ArrayList<>();
        List<ServerSentEvent<Map<String, Object>>> events = uploadEvents == null
                ? null
                : Collections.synchronizedList(uploadEvents);
        ExecutorService pool = Executors.newFixedThreadPool(
                Math.max(1, Math.min(parseParallelism, Math.max(raws.size(), 1))));
        try {
            List<Callable<DocumentText>> tasks = new ArrayList<>();
            for (RawDocument raw : raws) {
                tasks.add(() -> parseDocument(raw.name(), raw.content(), events));
            }
            for (Future<DocumentText> future : pool.invokeAll(tasks)) {
                documents.add(future.get());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new FileException("Обработка файлов прервана", e);
        } catch (ExecutionException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            // причина обязана попасть в лог: Error (OOM и т.п.) минует мягкую
            // деградацию parseDocument, и без стека инцидент не диагностируется
            log.error("Ошибка обработки файлов при загрузке", cause);
            throw cause instanceof RuntimeException runtime
                    ? runtime
                    : new FileException("Ошибка обработки файлов", cause);
        } finally {
            pool.shutdownNow();
        }
        return documents;
    }

    /**
     * Парсит один документ. Нечитаемый файл (повреждён, XML-бомба внутри docx,
     * неподдержанное содержимое) НЕ роняет загрузку всего комплекта — документ
     * получает маркер ручной проверки и проходит по конвейеру, а в лог загрузки
     * уходит предупреждение.
     */
    private DocumentText parseDocument(String filename, byte[] content,
                                       List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        String text;
        String contentType;
        try {
            contentType = FileUtils.detectContentType(filename);
            rejectOoxmlBomb(filename, contentType, content);
            text = documentService.parseText(new ByteArrayInputStream(content), contentType);
        } catch (Exception e) {
            log.warn("Не удалось обработать файл «{}» ({}) — маркер ручной проверки",
                    filename, e.getMessage());
            emitUploadWarning(uploadEvents, filename,
                    "файл не обработан (повреждён или неподдерживаемое содержимое) — требуется ручная проверка");
            return new DocumentText(filename, "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «" + filename
                    + "» не удалось обработать: файл повреждён или содержит неподдерживаемое "
                    + "содержимое. Автоматический анализ невозможен — проверьте документ вручную.");
        }
        if ("pdf".equals(contentType) && text.strip().length() < minParsedChars) {
            text = handleScanPdf(filename, content, uploadEvents);
        }
        return new DocumentText(filename, text);
    }

    /**
     * Быстрая отсечка «XML-бомб» в OOXML-файлах (docx/xlsx/pptx) ДО парсинга POI:
     * если любая внутренняя запись при распаковке превышает
     * {@code app.document.max-ooxml-entry-mb}, файл отклоняется сразу — иначе POI
     * минутами раздувает сотни мегабайт XML и лишь затем падает (реальный кейс:
     * docx со сжатием x112, document.xml 207 МБ). Записи распаковываются потоково
     * со счётчиком байт и ранним выходом по лимиту — без построения DOM.
     *
     * @param filename    имя файла
     * @param contentType определённый тип контента
     * @param content     содержимое файла
     */
    private void rejectOoxmlBomb(String filename, String contentType, byte[] content) throws IOException {
        if (!"docx".equals(contentType) && !"xlsx".equals(contentType) && !"pptx".equals(contentType)) {
            return;
        }
        long limitBytes = maxOoxmlEntryMb * 1024L * 1024L;
        byte[] buf = new byte[64 * 1024];
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(content))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                // getSize() у ZipInputStream часто -1: считаем реально распакованные байты
                long total = 0;
                int read;
                while ((read = zip.read(buf)) > 0) {
                    total += read;
                    if (total > limitBytes) {
                        throw new FileException("Внутренняя часть «" + entry.getName() + "» файла «"
                                + filename + "» распаковывается более чем в " + maxOoxmlEntryMb
                                + " МБ — похоже на повреждённый или аномальный документ");
                    }
                }
            }
        }
    }

    /**
     * PDF без текстового слоя: при включённом OCR ({@code app.document.ocr-via-gigachat})
     * скан распознаётся через файловое хранилище GigaChat, при выключенном или при
     * ошибке распознавания — маркер ручной проверки (прежнее поведение).
     *
     * @param filename     имя файла
     * @param content      содержимое PDF
     * @param uploadEvents накопитель SSE-событий (может быть {@code null})
     * @return распознанный текст либо маркер ручной проверки
     */
    private String handleScanPdf(String filename, byte[] content,
                                 List<ServerSentEvent<Map<String, Object>>> uploadEvents) {
        if (scanOcrService.isEnabled()) {
            try {
                String recognized = scanOcrService.recognize(filename, content);
                emitUploadWarning(uploadEvents, filename,
                        "PDF-скан распознан через GigaChat — проверьте суммы");
                return recognized;
            } catch (Exception e) {
                log.warn("OCR скана «{}» не удался ({}) — маркер ручной проверки", filename, e.getMessage());
            }
        }
        log.warn("PDF без текстового слоя (скан): {} — документ помечен для ручной проверки", filename);
        emitUploadWarning(uploadEvents, filename,
                "PDF без текстового слоя (скан) — требуется ручная проверка");
        return "[ТРЕБУЕТСЯ РУЧНАЯ ПРОВЕРКА] Документ «" + filename
                + "» не распознан: PDF без текстового слоя (скан). "
                + "Автоматический анализ содержимого невозможен — проверьте документ вручную.";
    }

    private void emitUploadWarning(List<ServerSentEvent<Map<String, Object>>> uploadEvents,
                                   String filename, String message) {
        if (uploadEvents != null) {
            uploadEvents.add(ServerSentEvent.<Map<String, Object>>builder()
                    .data(Map.of("type", "upload_warning", "file", filename, "message", message))
                    .build());
        }
    }

    public ResponseEntity<Resource> extractToDocx(UUID runId, boolean includeSteps) {
        var userId = CurrentUserHolder.getCurrentUser();
        ScenarioRunDetailResponse runDetail = getScenarioRun(runId);
        var model = scenarioRepository.findById(runDetail.scenarioId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        UserUtils.checkUserId(userId, model.getUserId());
        return ExportToDocx.generateDocx(runId, runDetail, includeSteps);
    }

    /**
     * Отдаёт файл output-узла завершённого прогона: XLSX/текст генерируется
     * из сохранённого результата шага. WS-событие FILE_OUTPUT несёт только
     * «файл готов» — сами байты клиент забирает этой ручкой (base64-файлы
     * в кадре раздували сокет для корп. шлюза).
     *
     * @param runId  идентификатор прогона
     * @param nodeId идентификатор output-узла сценария
     * @return файл с корректным именем и MIME-типом
     */
    public ResponseEntity<Resource> downloadRunFile(UUID runId, String nodeId) {
        var userId = CurrentUserHolder.getCurrentUser();
        ScenarioRun run = scenarioRunRepository.findById(runId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Run not found"));
        Scenario model = scenarioRepository.findById(run.getScenarioId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Scenario not found"));
        if (!Boolean.TRUE.equals(model.getShared())) {
            UserUtils.checkUserId(userId, model.getUserId());
        }
        GraphDataDto graph = GraphDataMapper.toDto(model.getGraphData());
        var node = graph.nodes().stream()
                .filter(n -> nodeId.equals(n.id()))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Node not found"));
        String result = scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(runId).stream()
                .filter(s -> nodeId.equals(s.getNodeId()))
                .findFirst()
                .map(s -> s.getOutputData() == null ? null : s.getOutputData().get("result"))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Step not found"));
        String mode = node.data() == null || node.data().mode() == null
                ? "" : node.data().mode().toUpperCase();
        return switch (mode) {
            case "EXCEL" -> fileResponse("result.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    ScenarioResultToXlsx.jsonToXlsx(result, node.data().rules(),
                            referenceNumbers(runId, graph, node.data().rules()),
                            enrichmentLines(runId, graph, node.data().rules())));
            // в живых сценариях встречаются оба варианта режима текстового файла
            case "TEXT_FILE", "TEXT" -> fileResponse("result.txt", "text/plain",
                    result.getBytes(StandardCharsets.UTF_8));
            default -> throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Узел не является файловым выходом");
        };
    }

    /**
     * Эталонные числа для кодовой выверки Excel: конфиг {@code "сверка_чисел":
     * {"из_узла": "<метка>"}} указывает узел (обычно transform, извлекающий суммы
     * из документов кодом), из результата которого собираются все числа.
     * LLM теряет разряды при переписывании сумм — эталон из кода закрывает это.
     *
     * @param runId     идентификатор прогона
     * @param graph     граф сценария
     * @param rulesJson правила выходного узла
     * @return числа в записи с точкой или {@code null}, если сверка не настроена
     */
    private Set<String> referenceNumbers(UUID runId, GraphDataDto graph, String rulesJson) {
        String sourceResult = donorNodeResult(runId, graph, rulesJson, "сверка_чисел");
        if (sourceResult == null) {
            return null;
        }
        Set<String> numbers = new LinkedHashSet<>();
        Matcher m = REFERENCE_NUMBER.matcher(sourceResult);
        while (m.find()) {
            numbers.add(m.group(1).replace(",", "."));
        }
        log.info("Сверка чисел Excel: эталонов {}", numbers.size());
        return numbers;
    }

    /**
     * Строки исходной формы участника для кодового обогащения Excel: конфиг
     * {@code "обогащение_формы": {"из_узла": "<метка>"}} указывает transform-узел,
     * извлёкший строки исходной таблицы кодом. Выход строится ПОВЕРХ этих строк:
     * каждая строка формы сохраняется, сопоставленные получают данные анализа,
     * остальные — заглушки (незачёт «Нет данных»). Так исходная форма участника
     * не затирается результатом.
     *
     * @param runId     идентификатор прогона
     * @param graph     граф сценария
     * @param rulesJson правила выходного узла
     * @return результат узла-донора или {@code null}, если обогащение не настроено
     */
    private String enrichmentLines(UUID runId, GraphDataDto graph, String rulesJson) {
        return donorNodeResult(runId, graph, rulesJson, "обогащение_формы");
    }

    /**
     * Результат узла, указанного в rules как {@code "<configKey>": {"из_узла": "<метка>"}}.
     *
     * @param runId     идентификатор прогона
     * @param graph     граф сценария
     * @param rulesJson правила выходного узла
     * @param configKey ключ настройки в rules
     * @return результат узла-донора или {@code null}, если не настроен или не найден
     */
    private String donorNodeResult(UUID runId, GraphDataDto graph, String rulesJson,
                                   String configKey) {
        if (rulesJson == null || rulesJson.isBlank()) {
            return null;
        }
        String sourceLabel = donorLabel(rulesJson, configKey);
        if (sourceLabel == null) {
            return null;
        }
        String sourceNodeId = graph.nodes().stream()
                .filter(n -> n.data() != null && sourceLabel.equals(n.data().label()))
                .map(n -> n.id())
                .findFirst().orElse(null);
        if (sourceNodeId == null) {
            log.warn("{}: узел-донор «{}» не найден в графе", configKey, sourceLabel);
            return null;
        }
        return scenarioRunStepRepository.findByRunIdOrderByStartedAtAsc(runId).stream()
                .filter(step -> sourceNodeId.equals(step.getNodeId()))
                .findFirst()
                .map(step -> step.getOutputData() == null ? null : step.getOutputData().get("result"))
                .orElse(null);
    }

    /**
     * Метка узла-донора из rules ({@code "<configKey>": {"из_узла": "<метка>"}}).
     *
     * @param rulesJson правила выходного узла
     * @param configKey ключ настройки
     * @return метка узла или {@code null}, если механизм не настроен
     */
    private static String donorLabel(String rulesJson, String configKey) {
        try {
            Map<String, Object> rules = new ObjectMapper()
                    .readValue(rulesJson, new TypeReference<>() { });
            if (!(rules.get(configKey) instanceof Map<?, ?> check)
                    || check.get("из_узла") == null) {
                return null;
            }
            return String.valueOf(check.get("из_узла"));
        } catch (Exception e) {
            // rules без валидного JSON — механизм просто не настроен
            return null;
        }
    }

    private static ResponseEntity<Resource> fileResponse(String filename, String mime, byte[] bytes) {
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=\"" + filename + "\"")
                .header("Content-Type", mime)
                .body(new ByteArrayResource(bytes));
    }
}
