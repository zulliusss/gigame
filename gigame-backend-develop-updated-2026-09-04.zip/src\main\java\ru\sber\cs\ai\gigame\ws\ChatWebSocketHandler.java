package ru.sber.cs.ai.gigame.ws;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;
import ru.sber.cs.ai.gigame.ws.enums.ActionType;
import ru.sber.cs.ai.gigame.service.ChatService;
import ru.sber.cs.ai.gigame.service.DocsTextCacheService;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * WebSocket обработчик для чата.
 * <p>
 * Реализует WebFlux WebSocket Handler для потоковой передачи сообщений
 * между клиентом и сервером в реальном времени через WebSocket.
 * <p>
 * Принимает сообщения от клиентов в формате:
 * {
 * "conversation_id": "uuid",
 * "content": "text",
 * "document_ids": ["uuid1", "uuid2"]
 * }
 * и отправляет ответы в формате StreamEvent:
 * {
 * "conversation_id": "uuid",
 * "content": "text",
 * "usage": { "prompt_tokens": n, "completion_tokens": n, "total_tokens": n },
 * "document_ids": ["uuid1", "uuid2"],
 * "done": true,
 * "error": "message"
 * }
 *
 * @see WebSocketSessionManager
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ChatWebSocketHandler implements WebSocketHandler {

    private final ChatService chatService;
    private final WebSocketSessionManager sessionManager;
    private final ObjectMapper objectMapper;
    private final DocsTextCacheService documentTextCache;

    @Override
    @NonNull
    public Mono<Void> handle(@NonNull WebSocketSession session) {
        try {
            return doHandle(session);
        } finally {
            CurrentUserHolder.clear();
        }
    }

    private Mono<Void> doHandle(WebSocketSession session) {
        String sessionId = session.getId();
        var userId = WebSocketSessionManager.extractUserIdFromWebSocketSession(session);
        log.info("[{}] connected, sessionId={}", userId, sessionId);
        sessionManager.addSession(session);

        return Mono.defer(() ->
                session.receive()
                        .doOnNext(msg -> log.info("[{}]Received WebSocket message, payload: {}", userId, msg.getPayloadAsText()))
                        .flatMap(message -> handleIncomingMessage(session, message, userId))
                        .then()
                        .doOnTerminate(() -> {
                            sessionManager.removeSession(session);
                            // Кэш текстов документов НЕ чистим здесь: фронтенд закрывает и
                            // переоткрывает сокет между сообщениями, и очистка по closing старой
                            // сессии затирала бы файлы, только что загруженные для следующего
                            // сообщения того же диалога (гонка). Кэш живёт по TTL/maxSize
                            // (DocsTextCacheService) и чистится при удалении диалога.
                            log.info("WebSocket chat connection closed: sessionId={}", sessionId);
                        })).subscribeOn(Schedulers.boundedElastic());
    }

    private Mono<Void> handleIncomingMessage(WebSocketSession session,
                                             WebSocketMessage message,
                                             String userId) {
        CurrentUserHolder.setCurrentUser(userId);
        String payload = message.getPayloadAsText();
        log.info("[{}] Received chat message: sessionId={}, payload={}", userId, session.getId(), payload);

        try {
            ChatMessage chatMessage = objectMapper.readValue(
                    payload,
                    ChatMessage.class
            );

            return processChatMessage(chatMessage, session.getId())
                    .then(Mono.empty());
        } catch (Exception e) {
            log.error("[{}] Error handling message: sessionId={}", userId, session.getId(), e);
            return sendErrorMessage(session, "Ошибка обработки сообщения: " + e.getMessage());
        }
    }

    private Mono<Void> processChatMessage(ChatMessage message, String sessionId) {
        UUID conversationId = message.conversationId();
        String content = message.content();
        List<String> documentIds = message.documentIds();
        var userId = CurrentUserHolder.getCurrentUser();
        String action = message.action() != null ? message.action() : "send";

        log.info("[{}] processChatMessage, conversationId={}, action={}", userId, conversationId, action);

        WebSocketSession wsSession = sessionManager.getSession(sessionId);
        if (wsSession == null || !wsSession.isOpen()) {
            log.warn("WebSocket session not found or closed: sessionId={}", sessionId);
            return Mono.empty();
        }
        var documentsText = documentTextCache.getCachedDocumentTexts(conversationId);
        var docIds = documentTextCache.getCachedDocIds(conversationId);

        Flux<ServerSentEvent<Map<String, Object>>> stream;
        switch (ActionType.valueOf(action.toUpperCase())) {
            case REGENERATE -> stream = chatService.regenerateStream(
                    conversationId, docIds, documentsText);
            case EDIT -> stream = chatService.editMessageStream(
                    conversationId, message.messageId(), content, docIds, documentsText);
            default -> {
                // Имена прикреплённых файлов добавляются к сообщению читаемым списком
                // конкатенация List + String давала префикс "[]" у каждого сообщения
                var fileNames = documentTextCache.getCachedFileNames(conversationId);
                var prefix = fileNames.isEmpty()
                        ? ""
                        : "Прикреплённые файлы: " + String.join(", ", fileNames) + "\n";
                stream = chatService.sendMessageStream(
                        conversationId, prefix + (content != null ? content : ""),
                        docIds, documentsText);
            }
        }
        return Flux.from(stream
                        .map(serverSentEvent -> createStreamEvent(conversationId, serverSentEvent.data()))
                        .doOnNext(event -> log.info("[{}]Sending to client: {}", userId, event))
                        .doOnComplete(() -> log.info("[{}]Chat stream completed for sessionId={}", userId, sessionId)))
                .map(wsSession::textMessage)
                .delayElements(Duration.ofMillis(10))
                .as(wsSession::send)
                .then();
    }

    /**
     * Преобразует данные SSE в формат StreamEvent.
     *
     * @param conversationId UUID диалога
     * @param data           данные SSE
     * @return Map в формате StreamEvent
     */
    private String createStreamEvent(UUID conversationId, Map<String, Object> data) {
        Map<String, Object> event = new HashMap<>();

        if (conversationId != null) {
            event.put("conversation_id", conversationId.toString());
        }

        if (data.containsKey(ChatService.CONTENT)) {
            event.put("content", data.get(ChatService.CONTENT));
        }

        if (data.containsKey(ChatService.USAGE)) {
            event.put("usage", data.get(ChatService.USAGE));
        }

        if (data.containsKey(ChatService.SOURCES)) {
            event.put("sources", data.get(ChatService.SOURCES));
        }

        if (data.containsKey(ChatMessage.DOCUMENT_ID_KEY)) {
            event.put("document_ids", data.get(ChatMessage.DOCUMENT_ID_KEY));
        }

        if (data.containsKey(ChatService.DONE)) {
            event.put("done", data.get(ChatService.DONE));
        }

        if (data.containsKey(ChatService.ERROR)) {
            event.put("error", data.get(ChatService.ERROR));
        }

        try {
            return objectMapper.writeValueAsString(event);
        } catch (Exception e) {
            log.error("Error serializing StreamEvent", e);
            return "{}";
        }
    }

    private Mono<Void> sendErrorMessage(WebSocketSession session, String errorMessage) {
        if (session != null && session.isOpen()) {
            try {
                Map<String, Object> errorEvent = Map.of(
                        "session_id", session.getId(),
                        "error", errorMessage
                );
                String json = objectMapper.writeValueAsString(errorEvent);
                return session.send(Flux.just(json).map(session::textMessage));
            } catch (Exception e) {
                log.error("Error serializing error message", e);
                return Mono.error(e);
            }
        }
        return Mono.empty();
    }

    /**
     * Сообщение WebSocket от клиента.
     *
     * @param conversationId UUID диалога
     * @param content         текст сообщения (для edit — новый текст)
     * @param documentIds    список UUID документов (опционально)
     * @param action          действие: send (по умолчанию), regenerate, edit
     * @param messageId      UUID редактируемого сообщения (для action=edit)
     */
    @JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
    public record ChatMessage(
            UUID conversationId,
            String content,
            List<String> documentIds,
            String action,
            UUID messageId
    ) {
        static String DOCUMENT_ID_KEY = "document_ids";
    }
}
