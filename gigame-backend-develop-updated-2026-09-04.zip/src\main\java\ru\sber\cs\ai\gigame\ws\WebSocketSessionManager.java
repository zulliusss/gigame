package ru.sber.cs.ai.gigame.ws;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.WebSocketSession;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Менеджер WebSocket сессий.
 * <p>
 * Отвечает за хранение и удаление WebSocket сессий для WebFlux.
 * Каждую минуту фоново проверяет сессии на закрытие и чистит зависшие.
 * Закрытие сессий выполняется реактивно (subscribe), без .block() —
 * чтобы не блокировать потоки boundedElastic при исчерпании пула.
 *
 * @see WebSocketSession
 */
@Component
@Slf4j
public class WebSocketSessionManager {

    private final Map<String, WebSocketSession> sessions = new ConcurrentHashMap<>();
    private final Map<String, String> sessionIdToUserId = new ConcurrentHashMap<>();

    /**
     * Добавляет новую сессию.
     *
     * @param session экземпляр WebSocketSession
     */
    public void addSession(WebSocketSession session) {
        var userId = extractUserIdFromWebSocketSession(session);
        sessions.put(session.getId(), session);
        sessionIdToUserId.put(session.getId(), userId);
        log.info("[{}]New WS connection: sessionId={}", userId, session.getId());
    }

    /**
     * Удаляет сессию.
     *
     * @param session экземпляр WebSocketSession
     */
    public void removeSession(WebSocketSession session) {
        String sessionId = session.getId();
        WebSocketSession webSocketSession = sessions.remove(sessionId);
        // Always clean up userId mapping, even if sessions.remove returned null (idempotent call)
        String removedUserId = sessionIdToUserId.remove(sessionId);
        if (webSocketSession != null) {
            try {
                if (webSocketSession.isOpen()) {
                    webSocketSession.close().subscribe(null, t ->
                            log.warn("Error closing session: sessionId={}", sessionId, t));
                }
            } catch (Exception e) {
                log.warn("[{}]Error closing session: sessionId={}", removedUserId, sessionId, e);
            }
        }

        log.info("[{}]Session closed: sessionId={}, hadUserId={}", removedUserId, sessionId, removedUserId != null);
    }

    /**
     * Возвращает сессию по ID.
     *
     * @param sessionId ID сессии
     * @return WebSocketSession или null если не найдена
     */
    public WebSocketSession getSession(String sessionId) {
        return sessions.get(sessionId);
    }

    /**
     * Возвращает ID пользователя по ID сессии.
     *
     * @param sessionId ID сессии
     * @return userId или null если не найден
     */
    public String getUserId(String sessionId) {
        return sessionIdToUserId.get(sessionId);
    }

    /**
     * Возвращает все активные сессии.
     *
     * @return коллекция всех WebSocket сессий
     */
    public Collection<WebSocketSession> getAllSessions() {
        return sessions.values();
    }

    /**
     * Проверяет наличие сессии по ID.
     *
     * @param sessionId ID сессии
     * @return true если сессия существует
     */
    public boolean hasSession(String sessionId) {
        return sessions.containsKey(sessionId);
    }

    /**
     * Фоновая задача: раз в минуту проверяет все сессии и удаляет закрытые.
     * Защита от утечки сессий при аварийном разрыве соединения (краш браузера, обрыв сети).
     */
    @Scheduled(fixedRateString = "${websocket.stale-session-eviction-ms:60000}")
    void evictStaleSessions() {
        int removed = 0;
        for (var it = sessions.entrySet().iterator(); it.hasNext(); ) {
            var entry = it.next();
            WebSocketSession session = entry.getValue();
            if (!session.isOpen()) {
                it.remove();
                sessionIdToUserId.remove(entry.getKey());
                removed++;
                log.info("Evicted stale WebSocket session: sessionId={}", entry.getKey());
            }
        }
        if (removed > 0) {
            log.info("Evicted {} stale WebSocket session(s)", removed);
        }
    }

    public static String extractUserIdFromWebSocketSession(WebSocketSession session) {
        var userId = session.getHandshakeInfo()
                .getHeaders()
                .getFirst("X-UserId");
        userId = userId == null ? "anonymous" : userId;
        log.info("{{}] Extracted userId from WebSocket session", userId);
        return userId;
    }
}
