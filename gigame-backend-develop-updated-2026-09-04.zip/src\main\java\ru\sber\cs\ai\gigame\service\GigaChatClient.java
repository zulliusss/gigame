package ru.sber.cs.ai.gigame.service;

import chat.giga.springai.GigaChatEmbeddingOptions;
import chat.giga.springai.GigaChatModel;
import chat.giga.springai.GigaChatOptions;
import chat.giga.springai.api.chat.GigaChatApi;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.ToolResponseMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.content.Media;
import org.springframework.ai.embedding.Embedding;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.embedding.EmbeddingRequest;
import org.springframework.ai.embedding.EmbeddingResponse;
import org.springframework.ai.tool.ToolCallback;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import ru.sber.cs.ai.gigame.exception.GigaChatException;
import ru.sber.cs.ai.gigame.utils.CurrentUserHolder;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;

/**
 * Тонкая обёртка над Spring AI моделями (авто-настроенные GigaChat).
 * <p>
 * Сохраняет те же сигнатуры публичных методов, чтобы ChatService и ScenarioEngine
 * не требовали изменений.
 *
 * @see ChatModel
 * @see EmbeddingModel
 */
@Service
@Slf4j
public class GigaChatClient {

    /** Предохранитель раундов tool-цикла (инструменты лимитируются раньше). */
    static final int TOOL_ROUNDS_LIMIT = 60;
    /** Потоки страховочных LLM-вызовов (daemon — не держат остановку JVM). */
    private static final ExecutorService LLM_CALL_POOL =
            Executors.newCachedThreadPool(r -> {
                Thread t = new Thread(r, "llm-call");
                t.setDaemon(true);
                return t;
            });
    /** Последние K tool-ответов остаются полными при сжатии истории. */
    static final int COMPACT_KEEP_LAST = 2;
    /** Tool-ответы короче порога не сжимаются (сжимать нечего). */
    static final int COMPACT_MIN_CHARS = 1500;

    private final ChatModel chatModel;
    private final EmbeddingModel embeddingModel;
    /**
     * API файлового хранилища GigaChat (может отсутствовать в тестовом контексте).
     */
    private final ObjectProvider<GigaChatApi> gigaChatApiProvider;
    @Value("${app.embedding.text-max-length:800}")
    private int textMaxLength;
    @Value("${app.embedding.batch-size:50}")
    private int batchSize;
    /**
     * Повторные попытки вызова GigaChat при временных сбоях (429, 5xx, сеть).
     * Дорогие многоузловые сценарии не должны падать из-за разового сбоя API.
     */
    @Value("${app.gigachat.retry.max-attempts:3}")
    private int retryMaxAttempts;
    @Value("${app.gigachat.retry.delay-millis:3000}")
    private long retryDelayMillis;
    @Value("${app.gigachat.retry.delay-429-millis:30000}")
    private long retryDelay429Millis;
    /**
     * Страховочный потолок одного сетевого LLM-вызова, секунд (больше
     * read-timeout клиента): read-timeout изредка не срабатывает — после
     * волны 429 JDK-клиент повисал в CompletableFuture.get() без отмены,
     * и поток узла висел часами. По истечении потолка вызов прерывается
     * и уходит в общий retry.
     */
    @Value("${app.gigachat.call-hard-timeout-seconds:660}")
    private long callHardTimeoutSeconds;

    /**
     * Стек счётчиков токенов текущего потока: движок сценариев открывает кадр
     * перед выполнением узла и закрывает после — все LLM-вызовы узла суммируются.
     * Стек (а не одиночный счётчик) нужен для вложенных под-сценариев:
     * закрытый кадр вливается в родительский.
     */
    private static final ThreadLocal<Deque<long[]>> USAGE_CAPTURE =
            ThreadLocal.withInitial(ArrayDeque::new);
    /**
     * Проверка остановки прогона для потока узла: при взведённом флаге
     * ретраи прерываются — иначе отмена ждала бы весь бюджет повторов
     * (наблюдалось: cancel при мёртвой сети ждал 3×10-минутных таймаута).
     */
    private static final ThreadLocal<java.util.function.BooleanSupplier> RUN_CANCEL_CHECK =
            ThreadLocal.withInitial(() -> () -> false);

    @Autowired
    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel,
                          ObjectProvider<GigaChatApi> gigaChatApiProvider) {
        this.chatModel = chatModel;
        this.embeddingModel = embeddingModel;
        this.gigaChatApiProvider = gigaChatApiProvider;
    }

    public GigaChatClient(ChatModel chatModel,
                          EmbeddingModel embeddingModel) {
        this(chatModel, embeddingModel, null);
    }

    /**
     * Открывает кадр учёта токенов для текущего потока.
     */
    public static void beginUsageCapture() {
        USAGE_CAPTURE.get().push(new long[1]);
    }

    /** Ставит проверку остановки прогона для текущего потока (ретраи прерываются). */
    public static void setRunCancelCheck(java.util.function.BooleanSupplier check) {
        RUN_CANCEL_CHECK.set(check == null ? () -> false : check);
    }

    /** Снимает проверку остановки прогона с текущего потока. */
    public static void clearRunCancelCheck() {
        RUN_CANCEL_CHECK.remove();
    }

    /**
     * Закрывает кадр учёта и возвращает суммарные токены кадра.
     * Токены вливаются в родительский кадр (вложенные под-сценарии).
     *
     * @return суммарные total_tokens кадра или {@code null}, если токенов не было
     */
    public static Integer endUsageCapture() {
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            return null;
        }
        long total = stack.pop()[0];
        if (!stack.isEmpty()) {
            stack.peek()[0] += total;
        } else {
            USAGE_CAPTURE.remove();
        }
        return total > 0 ? (int) Math.min(total, Integer.MAX_VALUE) : null;
    }

    /**
     * Добавляет usage LLM-вызова в открытый кадр учёта (если он есть).
     */
    public static void addCapturedUsage(Map<String, Object> usage) {
        if (usage == null) {
            return;
        }
        var stack = USAGE_CAPTURE.get();
        if (stack.isEmpty()) {
            USAGE_CAPTURE.remove();
            return;
        }
        Object total = usage.get("total_tokens");
        if (total instanceof Number number && stack.peek() != null) {
            stack.peek()[0] += number.longValue();
        }
    }

    // -------------------------------------------------------------------------
    // Chat completion (synchronous)
    // -------------------------------------------------------------------------

    /**
     * Синхронное выполнение чат-запроса.
     *
     * @param messages список сообщений в формате {role, content}
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages) {
        log.info("[{}] chatCompletion, messages={}",
                CurrentUserHolder.getCurrentUser(), messages.size());
        return chatCompletion(messages, null, null);
    }

    /**
     * Синхронный чат-запрос с переопределением модели и температуры
     * (настройки конкретного узла сценария).
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа ассистента
     */
    public String chatCompletion(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletion, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        return chatCompletionResult(messages, model, temperature).text();
    }

    /**
     * Результат чат-запроса: текст ответа и статистика использования токенов.
     *
     * @param text  текст ответа ассистента
     * @param usage {prompt_tokens, completion_tokens, total_tokens} или {@code null},
     *              если провайдер не вернул статистику
     */
    public record ChatResult(String text, Map<String, Object> usage) {
    }

    /**
     * Синхронный чат-запрос с переопределением модели/температуры,
     * возвращающий текст ответа вместе со статистикой usage.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionResult(List<Map<String, String>> messages, String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionResult, messages={}, model={}, temperature={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model, temperature);
        return chatCompletionSplitting(messages, model, temperature, 0);
    }

    /**
     * Обёртка над одиночным вызовом: если GigaChat отвечает 422 «context too
     * long» (документ больше контекстного окна модели), самое длинное сообщение
     * режется пополам по границе строки и обе половины обрабатываются отдельными
     * вызовами, ответы конкатенируются. Глубина деления — до 3 (максимум 8
     * частей); дальше ошибка отдаётся как есть.
     */
    private ChatResult chatCompletionSplitting(List<Map<String, String>> messages, String model,
                                               Double temperature, int depth) {
        try {
            return chatCompletionOnce(messages, model, temperature);
        } catch (RuntimeException e) {
            if (depth >= 3 || !isContextTooLong(e)) {
                throw e;
            }
            int idx = -1;
            int max = 0;
            for (int i = 0; i < messages.size(); i++) {
                int len = String.valueOf(messages.get(i).get("content")).length();
                if (len > max) {
                    max = len;
                    idx = i;
                }
            }
            if (idx < 0 || max < 20_000) {
                throw e;
            }
            String content = String.valueOf(messages.get(idx).get("content"));
            int cut = content.lastIndexOf('\n', content.length() / 2);
            if (cut < max / 4) {
                cut = content.length() / 2;
            }
            log.warn("GigaChat: запрос превышает контекст модели ({} символов) — "
                    + "делю сообщение на 2 части (глубина {})", max, depth + 1);
            ChatResult r1 = callWithReplacedContent(messages, idx, content.substring(0, cut),
                    model, temperature, depth);
            ChatResult r2 = callWithReplacedContent(messages, idx, content.substring(cut),
                    model, temperature, depth);
            return new ChatResult(r1.text() + "\n\n" + r2.text(),
                    mergeUsage(r1.usage(), r2.usage()));
        }
    }

    private ChatResult callWithReplacedContent(List<Map<String, String>> messages, int idx,
                                               String part, String model, Double temperature,
                                               int depth) {
        List<Map<String, String>> copy = new ArrayList<>();
        for (int i = 0; i < messages.size(); i++) {
            copy.add(i == idx
                    ? Map.of("role", messages.get(i).getOrDefault("role", "user"), "content", part)
                    : messages.get(i));
        }
        return chatCompletionSplitting(copy, model, temperature, depth + 1);
    }

    static boolean isContextTooLong(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            String msg = String.valueOf(t.getMessage()).toLowerCase();
            if (msg.contains("context too long")
                    || (msg.contains("422") && msg.contains("invalid params"))) {
                return true;
            }
        }
        return false;
    }

    static Map<String, Object> mergeUsage(Map<String, Object> a, Map<String, Object> b) {
        if (a == null || a.isEmpty()) {
            return b;
        }
        if (b == null || b.isEmpty()) {
            return a;
        }
        Map<String, Object> sum = new HashMap<>();
        for (String k : a.keySet()) {
            long va = a.get(k) instanceof Number n ? n.longValue() : 0;
            long vb = b.get(k) instanceof Number n ? n.longValue() : 0;
            sum.put(k, va + vb);
        }
        return sum;
    }

    private ChatResult chatCompletionOnce(List<Map<String, String>> messages, String model, Double temperature) {
        Prompt prompt;
        if (model == null && temperature == null) {
            prompt = toPrompt(messages);
        } else {
            var options = GigaChatOptions.builder();
            if (model != null) {
                options.model(model);
            }
            if (temperature != null) {
                options.temperature(temperature);
            }
            prompt = new Prompt(toPrompt(messages).getInstructions(), options.build());
        }
        ChatResponse response = callWithRetry(prompt);
        if (response == null) {
            throw new GigaChatException("GigaChat вернул пустой ответ");
        }
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        return new ChatResult(response.getResult().getOutput().getText(), usage);
    }

    /**
     * Агентский чат-запрос с инструментами (function calling GigaChat).
     * <p>
     * Модель сама решает, какие инструменты вызвать; цикл
     * «модель → инструмент → модель» выполняет {@code GigaChatModel}
     * (internal tool execution), финальный текст возвращается одним ответом.
     * Ограничение числа обращений — на стороне самих инструментов.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param tools       инструменты, доступные модели
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return финальный текст ответа и usage последнего вызова
     */
    public ChatResult chatCompletionWithTools(List<Map<String, String>> messages,
                                              List<ToolCallback> tools,
                                              String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionWithTools, messages={}, tools={}, model={}",
                CurrentUserHolder.getCurrentUser(), messages.size(),
                tools == null ? 0 : tools.size(), model);
        var options = GigaChatOptions.builder();
        if (model != null) {
            options.model(model);
        }
        if (temperature != null) {
            options.temperature(temperature);
        }
        GigaChatOptions built = options.build();
        built.setToolCallbacks(tools);
        // цикл ведём сами (не internal execution): это позволяет сжимать
        // историю между раундами — старые тяжёлые результаты инструментов
        // не пересылаются моделью заново на каждом раунде
        built.setInternalToolExecutionEnabled(false);
        Map<String, ToolCallback> byName = new HashMap<>();
        for (ToolCallback tool : tools) {
            byName.put(tool.getToolDefinition().name(), tool);
        }
        List<Message> history = new ArrayList<>(toPrompt(messages).getInstructions());
        Map<String, Object> usage = null;
        for (int round = 0; round < TOOL_ROUNDS_LIMIT; round++) {
            ChatResponse response = callWithRetry(new Prompt(history, built));
            if (response == null || response.getResult() == null
                    || response.getResult().getOutput() == null) {
                throw new GigaChatException("GigaChat вернул пустой ответ");
            }
            usage = extractUsage(response);
            addCapturedUsage(usage);
            AssistantMessage out = response.getResult().getOutput();
            if (!out.hasToolCalls()) {
                return new ChatResult(sanitizeToolText(out.getText()), usage);
            }
            history.add(out);
            history.add(executeToolCalls(out, byName));
            compactToolHistory(history);
        }
        throw new GigaChatException("Лимит раундов инструментов ("
                + TOOL_ROUNDS_LIMIT + ") исчерпан без финального ответа");
    }

    /** Исполняет вызовы инструментов раунда; ошибка инструмента — ответ модели. */
    private static ToolResponseMessage executeToolCalls(AssistantMessage out,
                                                        Map<String, ToolCallback> byName) {
        List<ToolResponseMessage.ToolResponse> responses = new ArrayList<>();
        for (AssistantMessage.ToolCall call : out.getToolCalls()) {
            ToolCallback tool = byName.get(call.name());
            String result;
            try {
                result = tool == null
                        ? "{\"error\": \"неизвестный инструмент " + call.name() + "\"}"
                        : tool.call(call.arguments());
            } catch (Exception e) {
                result = "{\"error\": \"" + String.valueOf(e.getMessage())
                        .replace('"', '\'') + "\"}";
            }
            responses.add(new ToolResponseMessage.ToolResponse(
                    call.id(), call.name(), result));
        }
        return ToolResponseMessage.builder().responses(responses).build();
    }

    /**
     * Сжатие истории цикла (по мотивам deepagents summarization): все
     * tool-ответы, кроме последних {@link #COMPACT_KEEP_LAST}, длиннее
     * {@link #COMPACT_MIN_CHARS} заменяются коротким маркером — тяжёлые
     * фрагменты чтения не пересылаются на каждом последующем раунде
     * (наблюдалось: узел жёг 400-700k токенов на росте истории).
     * Нужное агент всегда может перечитать инструментом заново.
     */
    static void compactToolHistory(List<Message> history) {
        List<Integer> toolIdx = new ArrayList<>();
        for (int i = 0; i < history.size(); i++) {
            if (history.get(i) instanceof ToolResponseMessage) {
                toolIdx.add(i);
            }
        }
        for (int k = 0; k < toolIdx.size() - COMPACT_KEEP_LAST; k++) {
            int i = toolIdx.get(k);
            ToolResponseMessage msg = (ToolResponseMessage) history.get(i);
            List<ToolResponseMessage.ToolResponse> compacted = new ArrayList<>();
            boolean changed = false;
            for (ToolResponseMessage.ToolResponse r : msg.getResponses()) {
                if (r.responseData() != null && r.responseData().length() > COMPACT_MIN_CHARS) {
                    compacted.add(new ToolResponseMessage.ToolResponse(r.id(), r.name(),
                            "{\"note\": \"[сжато] результат " + r.name() + " ("
                                    + r.responseData().length() + " симв) уже обработан "
                                    + "ранее; при необходимости вызови инструмент снова\"}"));
                    changed = true;
                } else {
                    compacted.add(r);
                }
            }
            if (changed) {
                history.set(i, ToolResponseMessage.builder().responses(compacted).build());
            }
        }
    }

    /**
     * После вызовов функций GigaChat может вернуть служебный токен
     * {@code <|superquote|>} вместо кавычек в финальном тексте (артефакт
     * function calling) — восстанавливаем обычные кавычки.
     *
     * @param text финальный текст ответа
     * @return текст с обычными кавычками
     */
    static String sanitizeToolText(String text) {
        return text == null ? null : text.replace("<|superquote|>", "\"");
    }

    /**
     * Чат-запрос с файлом-вложением: файл загружается в файловое хранилище
     * GigaChat (это делает {@code GigaChatModel} автоматически для Media без id),
     * модель распознаёт содержимое (включая сканы), после ответа файл удаляется
     * из хранилища.
     *
     * @param userText    текст запроса к модели
     * @param filename    имя файла (для хранилища)
     * @param content     содержимое файла
     * @param mimeType    MIME-тип файла (например, application/pdf)
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @param maxTokens   лимит токенов ответа (null — значение по умолчанию;
     *                    для полной перепечатки многостраничного скана нужен запас)
     * @return текст ответа и usage
     */
    public ChatResult chatCompletionWithFile(String userText, String filename, byte[] content,
                                             String mimeType, String model, Double temperature,
                                             Integer maxTokens) {
        log.info("[{}] GigaChatClient.chatCompletionWithFile, filename='{}', contentType={}, size={}, model={}",
                CurrentUserHolder.getCurrentUser(), filename, mimeType,
                content == null ? 0 : content.length, model);
        // имя файла уходит в Content-Disposition хранилища GigaChat: кириллица,
        // пути и пробелы ломают обработку файла — передаётся безопасное ASCII-имя
        var media = Media.builder()
                .mimeType(MimeType.valueOf(mimeType))
                .data(content)
                .name(safeAttachmentName(filename))
                .build();
        var userMessage = UserMessage.builder().text(userText).media(media).build();
        var options = GigaChatOptions.builder();
        if (model != null) {
            options.model(model);
        }
        if (temperature != null) {
            options.temperature(temperature);
        }
        if (maxTokens != null) {
            options.maxTokens(maxTokens);
        }
        Prompt prompt = new Prompt(List.of(userMessage), options.build());
        ChatResponse response = callWithRetry(prompt);
        if (response == null || response.getResult() == null || response.getResult().getOutput() == null) {
            throw new GigaChatException("GigaChat вернул пустой ответ");
        }
        deleteUploadedMedia(response);
        Map<String, Object> usage = extractUsage(response);
        addCapturedUsage(usage);
        return new ChatResult(response.getResult().getOutput().getText(), usage);
    }

    /**
     * Безопасное ASCII-имя вложения для файлового хранилища GigaChat:
     * расширение сохраняется, остальное заменяется хэшем исходного имени.
     *
     * @param filename исходное имя файла (может содержать путь и кириллицу)
     * @return имя вида {@code attachment-1a2b3c4d.pdf}
     */
    static String safeAttachmentName(String filename) {
        if (filename == null || filename.isBlank()) {
            return "";
        }
        String ext = "";
        int dot = filename.lastIndexOf('.');
        if (dot >= 0 && filename.substring(dot + 1).matches("[A-Za-z0-9]{1,8}")) {
            ext = "." + filename.substring(dot + 1).toLowerCase(Locale.ROOT);
        }
        return "attachment-" + Integer.toHexString(filename.hashCode()) + ext;
    }

    /**
     * Удаляет из файлового хранилища GigaChat файлы, загруженные моделью
     * для этого запроса (их id — в метаданных ответа). Ошибка удаления не
     * прерывает обработку: файлы приватные и лишь занимают квоту хранилища.
     *
     * @param response ответ модели
     */
    private void deleteUploadedMedia(ChatResponse response) {
        try {
            var api = gigaChatApiProvider != null ? gigaChatApiProvider.getIfAvailable() : null;
            if (api == null || response.getMetadata() == null) {
                return;
            }
            Object ids = response.getMetadata().get(GigaChatModel.UPLOADED_MEDIA_IDS);
            if (!(ids instanceof Collection<?> list)) {
                return;
            }
            for (Object id : list) {
                api.deleteFile(String.valueOf(id));
            }
        } catch (Exception e) {
            log.warn("Не удалось удалить файлы из хранилища GigaChat: {}", e.getMessage());
        }
    }

    /**
     * Извлекает статистику использования токенов из ответа модели.
     *
     * @param response ответ Spring AI
     * @return map с ключами prompt_tokens/completion_tokens/total_tokens или {@code null}
     */
    private Map<String, Object> extractUsage(ChatResponse response) {
        try {
            var metadata = response.getMetadata();
            if (metadata == null || metadata.getUsage() == null) {
                return Map.of();
            }
            var usage = metadata.getUsage();
            Map<String, Object> map = new HashMap<>();
            map.put("prompt_tokens", usage.getPromptTokens());
            map.put("completion_tokens", usage.getCompletionTokens());
            map.put("total_tokens", usage.getTotalTokens());
            return map;
        } catch (Exception e) {
            log.debug("Не удалось извлечь usage из ответа GigaChat: {}", e.getMessage());
            return Map.of();
        }
    }

    /**
     * Вызов чат-модели с повторными попытками при временных сбоях.
     * <p>
     * Повторяются: 429 (превышение лимита — увеличенная задержка), 5xx, сетевые
     * таймауты. Не повторяются: 4xx-ошибки данных (400, 401, 402, 413) —
     * повтор их не исправит. Задержка растёт линейно с номером попытки.
     * Используется реактивный retryWhen — без блокировки потоков boundedElastic
     * в ожидании повтора.
     *
     * @param prompt промпт
     * @return ответ модели
     */
    private ChatResponse callWithRetry(Prompt prompt) {
        return withRetry(() -> callWithHardTimeout(prompt));
    }

    /**
     * Вызов модели на отдельном потоке с жёстким потолком ожидания
     * {@code callHardTimeoutSeconds}: по истечении вызов прерывается,
     * а ошибка (в тексте — «timeout») уходит в общий retry как временная.
     * Поток узла при любом поведении сети освобождается гарантированно.
     */
    private ChatResponse callWithHardTimeout(Prompt prompt) {
        if (callHardTimeoutSeconds <= 0) {
            return chatModel.call(prompt);
        }
        Future<ChatResponse> future = LLM_CALL_POOL.submit(() -> chatModel.call(prompt));
        try {
            return future.get(callHardTimeoutSeconds, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            future.cancel(true);
            throw new GigaChatException("Страховочный timeout LLM-вызова: ответ не получен за "
                    + callHardTimeoutSeconds + " с", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            future.cancel(true);
            throw new GigaChatException("LLM-вызов прерван", e);
        } catch (ExecutionException e) {
            throw e.getCause() instanceof RuntimeException re
                    ? re
                    : new GigaChatException("Сбой LLM-вызова", e.getCause());
        }
    }

    private <T> T withRetry(Supplier<T> call) {
        int maxAttempts = Math.max(1, retryMaxAttempts);
        // снимок с потока узла: ретраи исполняются на таймер-потоках Reactor,
        // где ThreadLocal узла не виден — проверку замыкаем в фильтр
        var cancelled = RUN_CANCEL_CHECK.get();
        return Mono.fromCallable(call::get)
                .retryWhen(Retry.fixedDelay(maxAttempts, Duration.ofMillis(retryDelayMillis))
                        .doBeforeRetry(rs -> {
                            long attempt = rs.totalRetries() + 1;
                            if (attempt >= maxAttempts) {
                                return;
                            }
                            RuntimeException e = (RuntimeException) rs.failure();
                            String msg = String.valueOf(e.getMessage());
                            boolean rateLimited = isRateLimited(msg);
                            boolean retryable = rateLimited || isTransientFailure(msg);
                            long delay = (rateLimited ? retryDelay429Millis : retryDelayMillis) * attempt;
                            log.warn("GigaChat: временный сбой (попытка {}/{}), повтор через {} мс: {}",
                                    attempt, maxAttempts, delay, msg);
                            if (!retryable) {
                                throw e;
                            }
                        })
                        .filter(e -> {
                            if (cancelled.getAsBoolean()) {
                                log.info("GigaChat: прогон остановлен — повторы прерваны");
                                return false;
                            }
                            String msg = String.valueOf(e.getMessage());
                            return isRateLimited(msg) || isTransientFailure(msg);
                        })
                )
                .onErrorMap(RuntimeException.class,
                        e -> new GigaChatException("Не удалось выполнить запрос к GigaChat", e))
                .block();
    }

    /**
     * Превышение лимита запросов (429) — повторяется с увеличенной задержкой.
     *
     * @param msg текст ошибки
     * @return {@code true}, если ошибка — превышение лимита
     */
    private static boolean isRateLimited(String msg) {
        return msg.contains("429") || msg.contains("Too Many Requests");
    }

    /**
     * Временный сбой (5xx, сетевой таймаут, обрыв соединения) — повторяется.
     * 4xx-ошибки данных (400, 401, 402, 413) не повторяются: повтор их не исправит.
     *
     * @param msg текст ошибки
     * @return {@code true}, если сбой временный
     */
    private static boolean isTransientFailure(String msg) {
        boolean serverError = msg.contains("50") && (msg.contains("500") || msg.contains("502")
                || msg.contains("503") || msg.contains("504"));
        return serverError
                || msg.contains("timed out") || msg.contains("timeout")
                || msg.contains("Connection") || msg.contains("connection");
    }

    // -------------------------------------------------------------------------
    // Завершение чата (последовательное)
    // -------------------------------------------------------------------------

    /**
     * Потоковое выполнение чат-запроса, возвращает Flux текстовых фрагментов.
     * <p>
     * Использует синхронный вызов, обёрнутый в Flux — у GigaChat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ.
     *
     * @param messages список сообщений в формате {role, content}
     * @return Flux строк текста
     */
    public Flux<String> chatCompletionStream(List<Map<String, String>> messages) {
        return chatCompletionStreamResult(messages, null, null).map(ChatResult::text);
    }

    /**
     * Потоковый чат-запрос с переопределением модели/температуры и usage в результате.
     * <p>
     * Используется синхронный вызов, обёрнутый в Flux — у spring-ai-gigachat streaming есть
     * проблемы совместимости с JDK HttpClient + Reactor в WebFlux контексте.
     * Синхронный вызов надёжен и возвращает полный ответ одним элементом.
     *
     * @param messages    список сообщений в формате {role, content}
     * @param model       модель GigaChat (null — модель по умолчанию)
     * @param temperature температура генерации (null — значение по умолчанию)
     * @return Flux с единственным ChatResult
     */
    public Flux<ChatResult> chatCompletionStreamResult(List<Map<String, String>> messages,
                                                       String model, Double temperature) {
        log.info("[{}] GigaChatClient.chatCompletionStreamResult, messages={}, model={}",
                CurrentUserHolder.getCurrentUser(), messages.size(), model);
        return Flux.defer(() -> {
            log.debug("Start chat completion (synchronous)");
            ChatResult result = chatCompletionResult(messages, model, temperature);
            log.debug("Chat completion completed, {} characters", result.text().length());
            return Flux.just(result);
        });
    }

    // -------------------------------------------------------------------------
    // эмбеддинги
    // -------------------------------------------------------------------------

    /**
     * Получает векторные эмбеддинги для списка текстов.
     * <p>
     * Пакетная обработка: по 50 текстов за раз. Текст усекается до 800 символов
     * (ограничение GigaChat ~514 токенов).
     *
     * @param texts список текстов для эмбеддинги
     * @return список массивов float[] векторных эмбеддингов
     */
    public List<float[]> getEmbeddings(List<String> texts) {
        log.info("[{}] GigaChatClient.getEmbeddings, texts={}",
                CurrentUserHolder.getCurrentUser(),
                texts == null ? 0 : texts.size());
        List<String> truncated = texts.stream()
                .map(t -> t.length() > textMaxLength ? t.substring(0, textMaxLength) : t)
                .toList();

        List<float[]> results = new ArrayList<>();
        for (int i = 0; i < truncated.size(); i += batchSize) {
            List<String> batch = truncated.subList(i, Math.min(i + batchSize, truncated.size()));
            // Используются специфичные для GigaChat опции, чтобы избежать NPE при getModel()
            try {
                var opts = GigaChatEmbeddingOptions.builder()
                        .withModel("Embeddings").withDimensions(1024).build();
                EmbeddingResponse response = withRetry(() -> embeddingModel.call(
                        new EmbeddingRequest(batch, opts)));
                if (response == null) {
                    log.warn("Embedding batch {} вернул null, пропускаем", i / batchSize);
                    results.addAll(Collections.nCopies(batch.size(), new float[1024]));
                    continue;
                }
                results.addAll(response.getResults().stream()
                        .map(Embedding::getOutput)
                        .toList());
            } catch (Exception e) {
                log.error("Embedding batch {} failed {}", i / batchSize, e.getMessage());
                // Return nulls or empty arrays for failed batch
                results.addAll(Collections.nCopies(batch.size(), new float[1024]));
            }
        }
        return results;
    }

    // -------------------------------------------------------------------------
    // Внутренние вспомогательные методы
    // -------------------------------------------------------------------------

    /**
     * Преобразует наш формат List&lt;Map&lt;role,content&gt;&gt; в Spring AI Prompt.
     *
     * @param messages список сообщений
     * @return объект Prompt для Spring AI
     */
    private Prompt toPrompt(List<Map<String, String>> messages) {
        List<Message> aiMessages = new ArrayList<>();
        for (Map<String, String> msg : messages) {
            String role = msg.get("role");
            String content = msg.get("content");
            switch (role) {
                case "system" -> aiMessages.add(new SystemMessage(content));
                case "assistant" -> aiMessages.add(new AssistantMessage(content));
                default /*user*/ -> aiMessages.add(new UserMessage(content));
            }
        }
        return new Prompt(aiMessages);
    }
}
