package ru.sber.cs.ai.gigame.service.scenario.executor;

import org.junit.jupiter.api.Test;
import org.springframework.http.codec.ServerSentEvent;
import reactor.core.publisher.FluxSink;
import ru.sber.cs.ai.gigame.dto.scenario.graph.GraphDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDataDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.NodeDto;
import ru.sber.cs.ai.gigame.dto.scenario.graph.PositionDto;
import ru.sber.cs.ai.gigame.service.scenario.enums.ScenarioNodeType;
import ru.sber.cs.ai.gigame.service.scenario.graph.ScenarioRunGraph;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

/**
 * Тесты новых операций узла «Трансформация»: пустые массивы и дедупликация
 * в «слить_json_массивы», «проверить_цитаты», «сверить_суммы»,
 * «извлечь_из_документов».
 */
class ScenarioExecutorTransformNodeOpsTest {

    @SuppressWarnings("unchecked")
    private final FluxSink<ServerSentEvent<Map<String, Object>>> sink = mock(FluxSink.class);

    private static ScenarioRunGraph graph(String rules) {
        var dto = NodeDto.builder()
                .id("t1")
                .type(ScenarioNodeType.TRANSFORM_NODE.toString())
                .data(NodeDataDto.builder()
                        .label("Трансформация")
                        .rules(rules)
                        .build())
                .position(new PositionDto(0, 0))
                .build();
        return new ScenarioRunGraph(new GraphDataDto(List.of(dto), List.of()));
    }

    @Test
    void mergeAcceptsEmptyArrays() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\"}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("{\"находки\": []} и ещё {\"находки\": []}");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals("[ ]", result.trim().replaceAll("\\s+", " "));
    }

    @Test
    void mergeDeduplicatesByConfiguredKeys() {
        var graph = graph("{\"операции\": [{\"оп\": \"слить_json_массивы\", "
                + "\"дедуп_по\": [\"тип\", \"цитата\"]}]}");
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "бренд", "цитата": "HP 100"}]
                [{"номер": 2, "тип": "Бренд", "цитата": " hp 100 "},
                 {"номер": 3, "тип": "сроки", "цитата": "7 дней"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertEquals(2, result.split("\"цитата\"").length - 1);
        assertTrue(result.contains("7 дней"));
    }

    @Test
    void verifyCitationsMarksFoundAndAbsenceFindings() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_цитаты\"}]}");
        graph.addDocs(
                List.of("Техническое задание. Поставка серверов HP ProLiant 380 в сборе."),
                List.of("ТЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("""
                [{"номер": 1, "тип": "бренд", "цитата": "Поставка серверов HP ProLiant 380"},
                 {"номер": 2, "тип": "нмц", "цитата": "Отсутствует обоснование НМЦ"},
                 {"номер": 3, "тип": "фантом", "цитата": "Все участники обязаны молчать о ценах"}]
                """);

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("\"точно\""));
        assertTrue(result.contains("ТЗ.docx"));
        assertTrue(result.contains("н/п (об отсутствии)"));
        assertTrue(result.contains("НЕ НАЙДЕНА"));
    }

    @Test
    void compareAmountsReportsValuesPerDocument() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_суммы\", \"метка\": \"НМЦД?\"}]}");
        graph.addDocs(
                List.of("Пояснительная. НМЦД составляет 289523339,14 руб.",
                        "Раздел обоснования. НМЦД: 349669037,34 руб."),
                List.of("ПЗ.docx", "Обоснование.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("289523339.14"));
        assertTrue(result.contains("349669037.34"));
        assertTrue(result.contains("Различных значений: 2"));
    }

    @Test
    void extractFromDocsPrefersMatchingFilenames() {
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", "
                + "\"имя\": \"ПЗ|[Ии]звещени\", "
                + "\"шаблон\": \"Способ закупки[\\\\s:|]*\\\\n?\\\\s*([^\\\\n|>]{4,120})\"}]}");
        graph.addDocs(
                List.of("Протокол 2022. Способ закупки\nЗакупка у единственного поставщика",
                        "ПЗ текущая. Способ закупки\nАдресный запрос предложений"),
                List.of("Протокол-2022.pdf", "ПЗ рамка.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Адресный запрос предложений"));
        assertTrue(result.contains("ПЗ рамка.docx"));
        assertFalse(result.contains("единственного"));
    }

    @Test
    void extractFromDocsFallsBackToOtherDocuments() {
        var graph = graph("{\"операции\": [{\"оп\": \"извлечь_из_документов\", "
                + "\"имя\": \"[Ии]звещени\", "
                + "\"шаблон\": \"Способ закупки[\\\\s:|]*\\\\n?\\\\s*([^\\\\n|>]{4,120})\"}]}");
        graph.addDocs(
                List.of("Документация. Способ закупки\nОткрытый конкурс"),
                List.of("Документация.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("Открытый конкурс"));
    }

    @Test
    void checkPercentagesFlagsMismatchAndAcceptsCorrectValue() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_проценты\"}]}");
        graph.addDocs(
                List.of("НМЦ закупки составляет 1770719375,04 рублей. "
                        + "Размер обеспечения договора не более 1 % от НМЦ договора – "
                        + "2 500 000,00 руб. "
                        + "Аванс составляет 10 % от цены договора: 177 071 937,50 руб."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // 1% от 1,77 млрд = 17,7 млн, а указано 2,5 млн — расхождение попадает в отчёт
        assertTrue(result.contains("расхождение"));
        assertTrue(result.contains("17707193.75"));
        // корректный аванс (ровно 10%) расхождением не считается
        assertFalse(result.contains("177071937.50, но"));
    }

    @Test
    void checkPercentagesSkipsWhenBaseMissing() {
        var graph = graph("{\"операции\": [{\"оп\": \"проверить_проценты\"}]}");
        graph.addDocs(List.of("Обеспечение 5 % — 100 000,00 руб., базы нет."),
                List.of("Письмо.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("проверка пропущена"));
    }

    @Test
    void compareDatesFlagsContractSignedAfterServicePeriodStart() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\"}]}");
        graph.addDocs(
                List.of("Был заключен новый договор № 72/5619206 от 12.05.2026 на оказание "
                        + "услуг на период с 01.01.2026 по 31.05.2026.",
                        "Договор № 7 от 10.01.2026, срок оказания услуг с 15.01.2026."),
                List.of("ПЗ.docx", "Договор7.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        assertTrue(result.contains("12.05.2026"));
        assertTrue(result.contains("раньше заключения договора"));
        // корректный договор (подписан до начала услуг) в отчёт не попадает
        assertFalse(result.contains("Договор7.docx"));
    }

    @Test
    void compareDatesHandlesReversedPhraseOrder() {
        var graph = graph("{\"операции\": [{\"оп\": \"сверить_даты\"}]}");
        graph.addDocs(
                List.of("Ввиду необходимости непрерывности оказания услуг на период "
                        + "с 01.01.2026г. по 31.05.2026 (на время подготовки документов) "
                        + "с поставщиком был заключен новый договор № 72/5619206 от 12.05.2026."),
                List.of("ПЗ.docx"));
        var node = graph.getNodeMap().get("t1");
        node.getInput().add("вход не используется");

        String result = new ScenarioExecutorTransformNode(node).execute(sink);

        // период упомянут ДО договора — обратный порядок фраз тоже распознаётся
        assertTrue(result.contains("12.05.2026"));
        assertTrue(result.contains("01.01.2026"));
        assertTrue(result.contains("раньше заключения договора"));
    }
}
